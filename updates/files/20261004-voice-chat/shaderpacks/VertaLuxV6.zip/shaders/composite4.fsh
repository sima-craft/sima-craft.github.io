#version 120
/*
    composite4: TAA + optional TAAU (temporal upscaling).
    Reads colortex0 (scene, sub-rect when TAAU) and colortex7 (full-res
    history); writes both. Design points:
      (a) History sampled with Catmull-Rom (optimized 5-bilinear-fetch
          variant): avoids the cumulative blur/wobble of naive bilinear
          history resampling.
      (b) Neighborhood variance clipping in YCoCg: mu +- 1.15*sigma box of
          the 3x3, history VECTOR clipped toward the box (not a per-channel
          clamp, which teleports history into an AABB corner).
      (c) Velocity dilation: reprojection uses the CLOSEST depth of the 3x3
          so silhouettes get the motion of the front object.
      (d) Base blend 0.10, modulated by a luma anti-flicker weight (and by
          sample confidence when TAAU).
    CONSTRAINT: reprojection starts at the pixel CENTER (uv), NOT the
    de-jittered position. Both frames use the same center convention, so the
    jitter cancels exactly (static camera: histUV == uv). Reintroducing a
    jitter offset here brings back global wobble.
    TAAU (TAA_UPSCALING=1): the scene renders in the bottom-left sub-rect
    [0..TAAU_S]^2; each full-res pixel is reconstructed from the 3x3 render
    texels around uv*TAAU_S, weighted by distance to the jittered sample
    (gaussian, sigma ~0.4 render texel). History stays FULL RES. At
    TAAU_S=1.0 the code path is strictly identical to plain TAA.
    TAA off: pass-through, colortex7 = current frame.

    TAA_V2 (settings.glsl, out of menu, default 1; 0 = everything below
    compiles away and this file is the shipped resolve VERBATIM):
      (e) The box above is a SPATIAL statistic. On a spatially smooth surface
          that varies in TIME (denoised GI/SSR, cloud residue) sigma is ~0, the
          box collapses onto the current frame and the resolve is inert -- that
          is the reported flicker, and lowering the blend cannot fix it because
          the clip runs BEFORE the blend. So each pixel now measures its own
          temporal instability (exponential average of |dLuma| against the RAW
          history) and stores it in colortex7.a -- a channel nothing else in
          the pack reads (composite1 takes .rgb only) and which rides along the
          5 Catmull-Rom fetches for free. Next frame it becomes an ADDITIVE
          half-width on the box, so the box can open where sigma is zero.
          Capped (TAA_INST_CAP): past that, a change is a real change.
      (f) The history weight no longer falls off a cliff at the screen border
          (blend 1.0 == raw aliased current frame, one texel from a converged
          neighbour); it fades over TAA_EDGE_PX pixels.
      (g) The ghost-rejection distance is measured the way its own comment
          always claimed: against the LUMA extent of the box, chroma at half
          weight, instead of a 3-vector norm divided by a 1-D range.
    TAA_QUALITY (menu axis): 0 = min/max box + bilinear history (4 fewer
    fetches), 1 = the shipped resolve + the zero-cost fixes (f) and (g),
    2 = + (e) and the velocity/silhouette weighting. Default 2.

    TAA_V3 (settings.glsl, out of menu, default 1; acts ONLY at TAA_V2 == 1 and
    TAA_QUALITY == 2, so TAA_V2 = 0 stays the shipped resolve verbatim and
    TAA_QUALITY 1 stays the (e)-free resolve verbatim). Fixes the regression
    (e) caused ON THE SKY, where it was catastrophic instead of beneficial:
      (h) THE ROOT CAUSE. A pixel whose whole 3x3 is sky never enters the
          reprojection block (dClose == 1.0): the shipped resolve reads its
          history at histUV == uv, i.e. at the wrong screen position as soon as
          the camera turns. It survived because the variance box clipped that
          stale history away -- and (e) opens precisely that box. The sky now
          reprojects rotation-only at infinity, the way MOTION_BLUR already
          rebuilt its own sky velocity below (same formula: the blur is
          unchanged). It also gives the sky a non-zero mvPx, without which
          every velocity guard in this file was blind exactly where it was
          needed. Measured on the cloud chain (1D model, scratchpad cl_*.py),
          camera panning 45 deg/s while walking: mean error 0.344 -> 0.026,
          ghost energy 72% -> 10%, trail 2.14 -> 0.27 frames.
          A static camera reprojects to ITSELF exactly (same matrices both
          frames, so histUV == uv to the bit): no permanent sky blur.
          ONE side effect, deliberate: on the newly revealed sky strip at the
          LEADING screen edge (mvPx pixels wide) histUV now leaves [0,1], the
          confidence ramp takes blendFactor to 1.0, and MOTION_BLUR skips that
          strip -- which is already exactly how terrain behaves at every screen
          edge, so the two now agree instead of the sky being a special case.
      (i) (e) is now bounded on three sides: OFF on the sky (no denoised
          GI/SSR lives there, and the silhouette guard of (e) can never fire on
          open sky since d0 == dClose == 1.0), faded out past TAA_INST_V1 px of
          screen motion (that far, a history must be rejected, not
          accommodated), and hard-capped by TAA_INST_MAX -- TAA_INST_CAP bounds
          the MEAN cost, never the local one. Chroma widens at half weight: the
          statistic is a luma delta.
      (j) The instability EMA is zeroed in proportion to how little the
          reprojection can be trusted (screen edge, disocclusion, silhouette
          crown, fast motion): what it measures there is a reprojection error,
          not this pixel's instability.
      (k) The ghost-rejection score is divided by the UN-widened neighbourhood
          extent. It used to be divided by the widened box, so (e) switched off
          the very guard meant to bound its cost, right where (e) was largest.
*/

#include "/lib/settings.glsl"
#include "/lib/common.glsl"

uniform mat4 gbufferModelViewInverse;
uniform vec3 cameraPosition;

// Iris parses the const directives INSIDE the block comment below.
// Do NOT uncomment them (error C1503). See composite1.fsh.
/*
const int   colortex7Format  = RGBA16F;
const bool  colortex7Clear   = false;
*/

uniform sampler2D colortex0;
uniform sampler2D colortex7;
uniform sampler2D depthtex0;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferPreviousProjection;
uniform mat4 gbufferPreviousModelView;
uniform vec3 previousCameraPosition;
uniform float viewWidth;
uniform float viewHeight;
uniform int frameCounter;   // current jitter (TAAU confidence weighting only; reprojection does not use it)
#ifdef MOTION_BLUR
// MB_V2 only (see settings.glsl): frameTime normalizes the trail length,
// near/far linearize depth for the near-field fade and the tap weights.
uniform float frameTime;
uniform float near;
uniform float far;
#endif
#ifdef DISTANT_HORIZONS
uniform sampler2D dhDepthTex0;      // DH LOD depth (separate from depthtex0)
uniform mat4 dhProjectionInverse;   // DH frustum (extended near/far)
#endif

varying vec2 uv;

vec3 taaTM(vec3 c)   { return c / (1.0 + max(c, 0.0)); }
vec3 taaTMinv(vec3 c){ return c / max(1.0 - c, 1e-4); }

// coord = VISIBLE screen UV [0..1] full res, NOT the sub-rect framebuffer UV.
// TAAU: depth is READ at uv*TAAU_S but the pixel NDC stays in visible screen
// space (the matrices know nothing about the sub-rect).
vec3 toView(vec2 coord, float depth) {
    vec4 ndc = vec4(coord, depth, 1.0) * 2.0 - 1.0;
    vec4 v = gbufferProjectionInverse * ndc;
    return v.xyz / v.w;
}

#ifdef TAA
// YCoCg: decorrelated luma/chroma gives a much tighter variance box than RGB
// (less ghosting) without extra instability.
vec3 taaRGB2YCC(vec3 c) {
    return vec3( c.r * 0.25 + c.g * 0.5 + c.b * 0.25,
                 c.r * 0.5              - c.b * 0.5,
                -c.r * 0.25 + c.g * 0.5 - c.b * 0.25);
}
vec3 taaYCC2RGB(vec3 c) {
    return vec3(c.x + c.y - c.z, c.x + c.z, c.x - c.y - c.z);
}

// Clip the history vector to the box surface (Playdead): history slides along
// its own direction instead of being clamped per channel (which projects into
// an AABB corner -> hue jumps, shimmer).
vec3 taaClipBox(vec3 bMin, vec3 bMax, vec3 h) {
    vec3 ctr = 0.5 * (bMax + bMin);
    vec3 ext = 0.5 * (bMax - bMin) + 1e-5;
    vec3 v = h - ctr;
    vec3 a = abs(v / ext);
    float m = max(a.x, max(a.y, a.z));
    if (m > 1.0) return ctr + v / m;
    return h;   // already inside the box
}

// Catmull-Rom history fetch, 5-bilinear-fetch variant (Jimenez): the 16 tap
// weights factor into 5 filtered reads. Sharp sub-pixel reconstruction, no
// cumulative blur. colortex7 is FULL RES.
vec3 taaHistory(vec2 uvH) {
    vec2 res = vec2(viewWidth, viewHeight);
    vec2 samplePos = uvH * res;
    vec2 tp1 = floor(samplePos - 0.5) + 0.5;
    vec2 f  = samplePos - tp1;
    vec2 w0 = f * (-0.5 + f * (1.0 - 0.5 * f));
    vec2 w1 = 1.0 + f * f * (-2.5 + 1.5 * f);
    vec2 w2 = f * (0.5 + f * (2.0 - 1.5 * f));
    vec2 w3 = f * f * (-0.5 + 0.5 * f);
    vec2 w12 = w1 + w2;
    vec2 off12 = w2 / max(w12, vec2(1e-5));
    vec2 tp0  = (tp1 - 1.0)   / res;
    vec2 tp3  = (tp1 + 2.0)   / res;
    vec2 tp12 = (tp1 + off12) / res;
    vec3 r = texture2D(colortex7, vec2(tp12.x, tp0.y)).rgb  * (w12.x * w0.y)
           + texture2D(colortex7, vec2(tp0.x,  tp12.y)).rgb * (w0.x  * w12.y)
           + texture2D(colortex7, vec2(tp12.x, tp12.y)).rgb * (w12.x * w12.y)
           + texture2D(colortex7, vec2(tp3.x,  tp12.y)).rgb * (w3.x  * w12.y)
           + texture2D(colortex7, vec2(tp12.x, tp3.y)).rgb  * (w12.x * w3.y);
    float wsum = w12.x * w0.y + w0.x * w12.y + w12.x * w12.y
               + w3.x * w12.y + w12.x * w3.y;
    // renormalize (4 corners dropped) and guard >= 0 (negative CR lobes)
    return max(r / wsum, vec3(0.0));
}

#if TAA_V2 == 1 && TAA_QUALITY >= 1
// V2, same kernel and the SAME 5 fetches as taaHistory(), but the whole vec4
// comes back: colortex7.a is this pass's temporal-instability channel, so the
// statistic costs zero extra taps. Two differences beyond the alpha:
//   - tap coordinates are clamped to the buffer. The kernel reaches +-2 texels
//     and histUV legitimately lands on the border, where the raw version
//     depended on the sampler's wrap mode.
//   - nothing else: at TAA_QUALITY 1 with a valid interior histUV this returns
//     exactly what taaHistory() returns.
vec4 taaHistory4(vec2 uvH) {
    vec2 res = vec2(viewWidth, viewHeight);
    vec2 samplePos = uvH * res;
    vec2 tp1 = floor(samplePos - 0.5) + 0.5;
    vec2 f  = samplePos - tp1;
    vec2 w0 = f * (-0.5 + f * (1.0 - 0.5 * f));
    vec2 w1 = 1.0 + f * f * (-2.5 + 1.5 * f);
    vec2 w2 = f * (0.5 + f * (2.0 - 1.5 * f));
    vec2 w3 = f * f * (-0.5 + 0.5 * f);
    vec2 w12 = w1 + w2;
    vec2 off12 = w2 / max(w12, vec2(1e-5));
    vec2 lo = 0.5 / res;
    vec2 hi = 1.0 - 0.5 / res;
    vec2 tp0  = clamp((tp1 - 1.0)   / res, lo, hi);
    vec2 tp3  = clamp((tp1 + 2.0)   / res, lo, hi);
    vec2 tp12 = clamp((tp1 + off12) / res, lo, hi);
    vec4 r = texture2D(colortex7, vec2(tp12.x, tp0.y))  * (w12.x * w0.y)
           + texture2D(colortex7, vec2(tp0.x,  tp12.y)) * (w0.x  * w12.y)
           + texture2D(colortex7, vec2(tp12.x, tp12.y)) * (w12.x * w12.y)
           + texture2D(colortex7, vec2(tp3.x,  tp12.y)) * (w3.x  * w12.y)
           + texture2D(colortex7, vec2(tp12.x, tp3.y))  * (w12.x * w3.y);
    float wsum = w12.x * w0.y + w0.x * w12.y + w12.x * w12.y
               + w3.x * w12.y + w12.x * w3.y;
    return max(r / wsum, vec4(0.0));
}
#endif
#endif

void main() {
#ifdef TAA
    vec2 px = 1.0 / vec2(viewWidth, viewHeight);
    // TAAU: scene buffers (pre-TAA colortex0, depthtex0) live in the sub-rect
    // [0..TAAU_S] -> the full-res pixel uv reads them at uvScene.
    // At TAAU_S = 1.0: uvScene == uv (folds away at compile time).
    vec2 uvScene = uv * TAAU_S;

    // Current-frame jitter in framebuffer UV: the net offset applied by the
    // vertex shaders ends up as jNDC * px, TAAU or not.
    vec2 jitterUV = taaJitterNDC(frameCounter) * TAA_JITTER * px;

    // ---- Velocity dilation: closest depth of the 3x3 ----
    // Camera-only reprojection depends only on depth: the closest one gives
    // silhouette edges the motion of the FRONT object -> stable contours.
    // half-texel inset: same TAAU sub-rect edge guard as the MB taps below --
    // at suv = 1 the raw read sits ON the boundary (harmless while depthtex0
    // is GL_NEAREST, wrong the day the filtering changes).
    float d0 = texture2D(depthtex0, min(uvScene, vec2(TAAU_S) - 0.5 * px)).r;
    float dClose = d0;
    for (int cx = -1; cx <= 1; cx++) {
        for (int cy = -1; cy <= 1; cy++) {
            if (cx == 0 && cy == 0) continue;
#if TAA_V2 == 1
            // Same half-texel sub-rect inset as d0 above and as the MB taps
            // below: the shipped loop read the neighbours RAW, so at the
            // right/top TAAU render edge they landed in the dead framebuffer
            // zone. Benign today (the dead zone clears to 1.0 and min() ignores
            // it) but the guard belongs here for the same reason the comment on
            // d0 gives, and it costs one min().
            float dn = texture2D(depthtex0, min(uvScene + vec2(float(cx), float(cy)) * px,
                                                vec2(TAAU_S) - 0.5 * px)).r;
#else
            float dn = texture2D(depthtex0, uvScene + vec2(float(cx), float(cy)) * px).r;
#endif
            dClose = min(dClose, dn);
        }
    }

    // ---- Reprojection: full-res UV of this pixel in the previous frame ----
    // Reconstructed at the pixel CENTER (uv), NOT de-jittered (see header:
    // jitter cancels exactly; static camera gives histUV == uv).
    vec2 histUV = uv;
    bool histValid = true;

    if (dClose < 1.0) {
        vec3 viewPos = toView(uv, dClose);
        vec3 wpos = (gbufferModelViewInverse * vec4(viewPos, 1.0)).xyz + cameraPosition;
        vec4 prevClip = gbufferPreviousProjection
                      * (gbufferPreviousModelView * vec4(wpos - previousCameraPosition, 1.0));
        if (prevClip.w > 0.001) {
            histUV = (prevClip.xy / prevClip.w) * 0.5 + 0.5;
            if (histUV.x < 0.0 || histUV.x > 1.0 || histUV.y < 0.0 || histUV.y > 1.0)
                histValid = false;
        } else {
            histValid = false;
        }
    }
#ifdef DISTANT_HORIZONS
    else {
        // DH pixels (depth in dhDepthTex0, not depthtex0): without this block
        // they reproject as sky (zero offset) -> TAA ghosting on LODs when the
        // camera moves. Position via dhProjectionInverse; the previous vanilla
        // projection .xy is fine for the history UV (same fov/aspect, only
        // near/far differ). Same CENTER convention as the vanilla branch.
        float dhDT = texture2D(dhDepthTex0, uvScene).r;
        if (dhDT < 1.0) {
            vec4 ndcDH = vec4(uv, dhDT, 1.0) * 2.0 - 1.0;
            vec4 vDH = dhProjectionInverse * ndcDH;
            vec3 wposDH = (gbufferModelViewInverse * vec4(vDH.xyz / vDH.w, 1.0)).xyz + cameraPosition;
            vec4 prevClipDH = gbufferPreviousProjection
                            * (gbufferPreviousModelView * vec4(wposDH - previousCameraPosition, 1.0));
            if (prevClipDH.w > 0.001) {
                histUV = (prevClipDH.xy / prevClipDH.w) * 0.5 + 0.5;
                if (histUV.x < 0.0 || histUV.x > 1.0 || histUV.y < 0.0 || histUV.y > 1.0)
                    histValid = false;
            } else {
                histValid = false;
            }
        }
    }
#endif

#if TAA_V2 == 1 && TAA_V3 == 1 && TAA_QUALITY == 2
    // ---- SKY: rotation-only reprojection at infinity (TAA_V3) --------------
    // A pixel whose whole 3x3 is sky never enters the block above (dClose is
    // 1.0), so the shipped resolve reads its history at histUV == uv: the sky
    // is the ONE region of the frame where the history is knowingly fetched at
    // the WRONG screen position the moment the camera turns. It survived that
    // only because the variance box clipped the stale history away -- and the
    // instability widening of TAA_QUALITY 2 opens exactly that box. That is the
    // reported regression: the clouds smear and a second, offset copy of them
    // shows through ("les nuages derriere les nuages"). Two more consequences:
    // mvPx is 0 over the whole sky, so every velocity-driven guard in this file
    // is BLIND there, and the clouds -- already temporally resolved in
    // prepare1 -- get a second, un-reprojected accumulation on top of it.
    // Translation is negligible at cloud distance (a 250-block slab shifts
    // ~0.5 px/frame at walking speed, which the shipped code assumed to be 0
    // anyway), so mat3() drops it: same rotation-only sky velocity MOTION_BLUR
    // rebuilds for itself below, computed identically, so the blur is
    // unchanged. Cost: one mat3 and one mat4 product, on sky pixels only.
    bool isSky = false;
    vec2 dmvSky = uv - histUV;
    if (dClose >= 1.0 && dot(dmvSky, dmvSky) < 1e-12) {
        isSky = true;   // sky AND nothing else has reprojected it (DH included)
        vec3 wdirSky = mat3(gbufferModelViewInverse) * toView(uv, 0.9999);
        vec4 pcSky = gbufferPreviousProjection
                   * vec4(mat3(gbufferPreviousModelView) * wdirSky, 1.0);
        if (pcSky.w > 0.001) {
            histUV = (pcSky.xy / pcSky.w) * 0.5 + 0.5;
        } else {
            histValid = false;  // in bounds and unusable: the histConf test below
        }
    }
#endif

    // ---- 3x3 neighborhood: YCoCg moments for variance clipping ----
    // TAA_CLAMP_TONEMAP=1: stats and clip in TONEMAPPED space (bounded [0..1])
    // so HDR highlights near the sun/glints do not dominate the box.
    // The final blend stays in linear HDR.
#if TAA_UPSCALING == 1
    // TAAU: neighborhood anchored on render-texel CENTERS around uvScene
    // (snapping required: the real sample position carries the sub-texel
    // jitter information).
    vec2 spx  = uvScene / px;                    // position in render texels
    vec2 tcUV = (floor(spx) + 0.5) * px;         // center of the texel containing uvScene
    vec3 curAcc = vec3(0.0);
    float wAcc = 0.0;
    float wMax = 0.0;
#else
    vec2 tcUV = uvScene;                         // == uv: same neighborhood as plain TAA
#endif
    vec3 m1 = vec3(0.0);
    vec3 m2 = vec3(0.0);
    vec3 curCenter = vec3(0.0);
#if TAA_V2 == 1 && TAA_QUALITY == 0
    // Tier "Bas" builds a raw min/max AABB instead of the variance box.
    vec3 nMin = vec3( 1e30);
    vec3 nMax = vec3(-1e30);
#endif
    for (int ox = -1; ox <= 1; ox++) {
        for (int oy = -1; oy <= 1; oy++) {
            vec2 sUV = tcUV + vec2(float(ox), float(oy)) * px;
#if TAA_UPSCALING == 1
            // clamp to the sub-rect: at the right/top render edge the neighbor
            // texel would fall into the dead framebuffer zone (garbage)
            sUV = min(sUV, vec2(TAAU_S) - 0.5 * px);
#endif
            vec3 raw = texture2D(colortex0, sUV).rgb;
            if (ox == 0 && oy == 0) curCenter = raw;
#if TAA_CLAMP_TONEMAP == 1
            vec3 ycc = taaRGB2YCC(taaTM(raw));
#else
            vec3 ycc = taaRGB2YCC(raw);
#endif
            m1 += ycc;
            m2 += ycc * ycc;
#if TAA_V2 == 1 && TAA_QUALITY == 0
            nMin = min(nMin, ycc);
            nMax = max(nMax, ycc);
#endif
#if TAA_UPSCALING == 1
            // Distance (render texels) from this texel's JITTERED sample to
            // the target pixel center: texel at C holds the scene seen at
            // C - jitter -> d = (C - jitter - uvScene)/px.
            vec2 dTex = (sUV - jitterUV - uvScene) / px;
            float w = exp(-dot(dTex, dTex) * 3.125);   // gaussian, sigma ~0.4 texel
            curAcc += raw * w;
            wAcc   += w;
            wMax    = max(wMax, w);
#endif
        }
    }
    vec3 mu    = m1 / 9.0;
    vec3 sigma = sqrt(max(m2 / 9.0 - mu * mu, vec3(0.0)));
    // gamma 1.15: mu +- gamma*sigma follows the actual neighborhood
    // distribution better than a raw min/max AABB.
    vec3 bMin = mu - 1.15 * sigma;
    vec3 bMax = mu + 1.15 * sigma;

#if TAA_UPSCALING == 1
    // TAAU: current = weighted 3x3 mean (reconstruction); confidence wMax
    // drives the blend below (sample far from target center -> lean on the
    // full-res history).
    vec3 current = curAcc / max(wAcc, 1e-6);
#else
    vec3 current = curCenter;
#endif

#if TAA_V2 == 1
    // ================= TAA_V2 resolve (see the file header) =================
    // The history is fetched BEFORE the box is finalised: at TAA_QUALITY 2 the
    // box width depends on colortex7.a, which only this fetch brings back.
#if TAA_QUALITY == 0
    // Bas: one bilinear tap. Half-texel inset so the tap never straddles the
    // border. colortex7 is FULL RES even under TAAU, hence no TAAU_S here.
    vec4 histT = texture2D(colortex7, clamp(histUV, 0.5 * px, 1.0 - 0.5 * px));
#else
    vec4 histT = taaHistory4(histUV);
#endif
    vec3 histRaw = histT.rgb;
#if TAA_CLAMP_TONEMAP == 1
    vec3 histYCC = taaRGB2YCC(taaTM(histRaw));
#else
    vec3 histYCC = taaRGB2YCC(histRaw);
#endif

    // ---- Reprojection confidence: a RAMP, not the old 1-texel cliff --------
    // Shipped behaviour: histUV leaves [0,1] -> blendFactor 1.0 -> the raw,
    // un-antialiased current frame, immediately next to a fully converged
    // neighbour. On the trailing screen edge of any camera move that is a band
    // of pure aliasing that crawls. Ramp it instead.
    // edgePx is the distance INSIDE the frame in pixels, and goes NEGATIVE
    // once histUV is out of bounds. The ramp therefore lives entirely on the
    // OUTSIDE: a history that is merely close to the border is still worth
    // full confidence (a static camera must not lose its edge pixels), and
    // only the overshoot is faded, over TAA_EDGE_PX pixels.
    float edgePx = min(min(histUV.x, 1.0 - histUV.x) / px.x,
                       min(histUV.y, 1.0 - histUV.y) / px.y);
    float histConf = clamp(1.0 + edgePx / TAA_EDGE_PX, 0.0, 1.0);
    // histValid is false in TWO cases. Out of bounds: the ramp above already
    // covers it. prevClip.w <= 0 (the point sits behind the previous camera):
    // nothing usable, hard reject -- and that case leaves histUV at uv, i.e.
    // IN bounds, which the ramp would otherwise trust completely. In bounds
    // AND invalid can only be the second case, hence the test.
    if (!histValid && edgePx >= 0.0) histConf = 0.0;

    // ---- Box ---------------------------------------------------------------
#if TAA_QUALITY == 0
    // Bas: raw min/max AABB of the 3x3 (no variance, no adaptation).
    bMin = nMin;
    bMax = nMax;
#else
    float gammaV = 1.15;
#if TAA_QUALITY == 2
    // Reprojection distance, in pixels: the further the history travelled the
    // less its resample can be trusted, so let the box breathe. Saturates at
    // 2 px/frame -- past that the ghost rejection is the operative guard.
    float mvPx = length((uv - histUV) / px);
    gammaV += TAA_VEL_GAMMA * clamp(mvPx, 0.0, 2.0);
#endif
    vec3 halfW = gammaV * sigma;
#if TAA_QUALITY == 2
    // ADDITIVE widening from this pixel's own measured temporal instability
    // (colortex7.a, written at the bottom of this pass). Additive and not a
    // factor on sigma, because a factor on sigma is zero exactly where sigma
    // is zero -- the spatially smooth, temporally noisy surfaces this term
    // exists for. Clamped on read: the channel is never cleared, and a frame
    // written by TAA_QUALITY 0/1 (or with TAA off) leaves 1.0 in there.
    float instPrev = clamp(histT.a, 0.0, TAA_INST_CAP);
    // Silhouette guard: d0 > dClose means the velocity dilation handed this
    // pixel a NEARER neighbour's motion, so the history it is about to read
    // belongs to another object. Reproject this pixel's OWN depth and kill the
    // widening as the two disagree. The branch is taken only on the 1-px
    // dilation crown along silhouettes, so most waves skip it entirely.
    float silW = 1.0;
    if (d0 > dClose) {
        vec3 vSelf = toView(uv, d0);
        vec3 wSelf = (gbufferModelViewInverse * vec4(vSelf, 1.0)).xyz + cameraPosition;
        vec4 pSelf = gbufferPreviousProjection
                   * (gbufferPreviousModelView * vec4(wSelf - previousCameraPosition, 1.0));
        if (pSelf.w > 0.001) {
            vec2 uSelf = (pSelf.xy / pSelf.w) * 0.5 + 0.5;
            silW = 1.0 - clamp(length((uSelf - histUV) / px) / TAA_SIL_PX, 0.0, 1.0);
        } else {
            silW = 0.0;
        }
    }
#if TAA_CLAMP_TONEMAP == 1
    float widScale = 1.0;   // the box already lives in tonemapped units
#else
    // The box lives in LINEAR HDR here but the instability is measured (and
    // stored) in tonemapped luma, which is the only bounded space available.
    // Convert with the derivative of the inverse tonemap, d/dy [y/(1-y)].
    float yTM = clamp(luma(taaTM(current)), 0.0, 0.99);
    float widScale = 1.0 / max((1.0 - yTM) * (1.0 - yTM), 1e-2);
#endif
#if TAA_V3 == 1
    // ---- TAA_V3: the additive term, bounded on three sides ----------------
    // (1) SKY. The widening exists for surfaces that are spatially smooth and
    //     temporally noisy (denoised GI / SSR). There are none on the sky, and
    //     the model measures no benefit there (flicker 0.3680 -> 0.3669 with
    //     the term on, i.e. nothing) for the entire cost of the regression.
    //     Note that silW below can NEVER fire on open sky: d0 == dClose == 1.0,
    //     so the silhouette guard leaves the widening at full strength over the
    //     whole cloud layer -- it only ever protected the 1-px crown where sky
    //     touches terrain. TAA_INST_SKY is the guard the sky actually needed.
    // (2) SCREEN VELOCITY. Past TAA_INST_V1 px/frame the history is too far
    //     away to be accommodated: it must be REJECTED, not welcomed in by a
    //     wider box. (This guard was inert before (1)'s reprojection existed,
    //     because mvPx was identically 0 on the sky.)
    // (3) A HARD CEILING on the term itself, in tonemapped luma. TAA_INST_CAP
    //     bounds the MEAN cost, not the local one: measured on the cloud chain,
    //     the shipped term multiplies the mean error by 3.9 but drives the p99
    //     to 1.22 and the peak to 1.89 -- the ghost reaches full cloud
    //     contrast. TAA_INST_MAX is the bound on the worst case, and the only
    //     bound at all on the TAA_CLAMP_TONEMAP = 0 path, where widScale is
    //     1/(1-y)^2 and reaches 100. Calibrated (settings.glsl) to keep the
    //     whole smooth-surface gain and 78% of the high-frequency one while
    //     halving the ghosting the term costs.
    // Chroma at half weight: the statistic in colortex7.a is a LUMA delta, so
    // nothing justifies opening Co/Cg by the same absolute amount (their range
    // is far narrower, so the same number opens them proportionally much
    // wider). Same convention as the ghost-rejection distance below.
    float instAtt = mix(1.0, TAA_INST_SKY, float(isSky))
                  * (1.0 - smoothstep(TAA_INST_V0, TAA_INST_V1, mvPx));
    float instW = min(TAA_INST_K * instPrev * silW * instAtt * widScale,
                      TAA_INST_MAX);
    halfW += vec3(instW, instW * TAA_INST_CHROMA, instW * TAA_INST_CHROMA);
#else
    halfW += vec3(TAA_INST_K * instPrev * silW * widScale);
#endif
#endif
    bMin = mu - halfW;
    bMax = mu + halfW;
#endif

    vec3 clipYCC = taaClipBox(bMin, bMax, histYCC);
#if TAA_CLAMP_TONEMAP == 1
    vec3 history = taaTMinv(max(taaYCC2RGB(clipYCC), vec3(0.0)));
#else
    vec3 history = max(taaYCC2RGB(clipYCC), vec3(0.0));
#endif

    // ---- Blend factor: 0.10 base + luma anti-flicker ----
    float blendFactor = 0.10;
#else
    // ---- History: Catmull-Rom fetch + variance clipping ----
    vec3 histRaw = taaHistory(histUV);
#if TAA_CLAMP_TONEMAP == 1
    vec3 histYCC = taaRGB2YCC(taaTM(histRaw));
#else
    vec3 histYCC = taaRGB2YCC(histRaw);
#endif
    vec3 clipYCC = taaClipBox(bMin, bMax, histYCC);
#if TAA_CLAMP_TONEMAP == 1
    vec3 history = taaTMinv(max(taaYCC2RGB(clipYCC), vec3(0.0)));
#else
    vec3 history = max(taaYCC2RGB(clipYCC), vec3(0.0));
#endif

    // ---- Blend factor: 0.10 base + luma anti-flicker ----
    float blendFactor = 0.10;
#endif
    // Anti-flicker: |luma delta| measured in tonemapped (bounded) space; when
    // the pixel flickers, lengthen the history instead of letting it pump.
    float lumaC = luma(taaTM(current));
    float lumaH = luma(taaTM(history));
    blendFactor *= 1.0 / (1.0 + abs(lumaC - lumaH) * 4.0);
#if TAA_UPSCALING == 1
    // TAAU sample confidence: far from the target center the current frame
    // weighs less and the full-res history carries the detail.
    blendFactor *= wMax;
#endif

#if TAA_GHOST_REJECT == 1
    // Ghost rejection: history clip distance relative to the luma extent of
    // the box (YCoCg Y channel). Targets moving silhouettes against the sky.
#if TAA_V2 == 1 && TAA_V3 == 1 && TAA_QUALITY == 2
    // V3 fix, and it compounds with the one above: this range is the
    // DENOMINATOR of the ghost test, so the instability term widened the box
    // AND divided the ghost score by that same widened box -- the term
    // switched off the very guard that was supposed to bound its cost, exactly
    // where the term was largest. Score the clip against the NEIGHBOURHOOD
    // extent, which is what "the luma extent of the box" was always meant to
    // be. Identical to the line below at TAA_QUALITY 1 (no additive term).
    float boxRange = 2.0 * gammaV * sigma.x;
#else
    float boxRange = bMax.x - bMin.x;
#endif
#if TAA_V2 == 1
    // V2 fix: the shipped line was length(histYCC - clipYCC), a 3-component
    // norm, divided by the LUMA extent the comment above names -- so a purely
    // CHROMATIC clip was scored against a range that never described it, and a
    // saturated pixel over a same-luma background could reject a perfectly good
    // history. Measure the distance the same way the range is measured: luma,
    // plus chroma at half weight (the eye's lower chroma acuity).
    float clipDist = abs(histYCC.x - clipYCC.x)
                   + 0.5 * length(histYCC.yz - clipYCC.yz);
#else
    float clipDist = length(histYCC - clipYCC);
#endif
#if TAA_CLAMP_TONEMAP == 1
    float ghostRej = smoothstep(0.6, 2.0, clipDist / max(boxRange, 0.020));
#else
    float ghostRej = smoothstep(0.6, 2.0, clipDist / max(boxRange, 0.05));
#endif
    blendFactor = mix(blendFactor, 1.0, ghostRej);
#endif

#if TAA_V2 == 1
    // Screen-edge / invalid-reprojection ramp (histConf above) replaces the
    // shipped hard "if (!histValid) blendFactor = 1.0;".
    blendFactor = mix(1.0, blendFactor, histConf);
#if TAA_QUALITY == 2
    // Update the instability channel for the NEXT frame: |dLuma| between the
    // current sample and the RAW history. Raw and not clipped -- the clipped
    // value has already been dragged inside the box, so it would measure the
    // clip instead of the flicker it is meant to detect.
    float taaInstNew = mix(instPrev, abs(lumaC - luma(taaTM(histRaw))),
                           TAA_INST_RATE);
#if TAA_V3 == 1
    // V3: the EMA must not survive a reprojection it cannot trust. Off screen,
    // on a disocclusion, on the silhouette crown, in fast screen motion or on
    // the sky, the |dLuma| just measured is a REPROJECTION error, not this
    // pixel's own temporal instability -- and letting it charge the channel
    // there is what allowed a single fast pan to leave every box on screen
    // open for the next ~4 frames (TAA_INST_RATE). Same weights that gate the
    // widening itself, so a pixel whose widening is off never banks a value it
    // could not use anyway.
    taaInstNew *= histConf * silW * instAtt;
#endif
#endif
#else
    // off-screen / w <= 0: history unusable -> full current frame
    if (!histValid) blendFactor = 1.0;
#endif

    vec3 result = mix(history, current, clamp(blendFactor, 0.0, 1.0));

#ifdef MOTION_BLUR
{
    // mv is in full-res UV (uv and histUV both are); scene reads from
    // colortex0 (pre-TAA, sub-rect) go through * TAAU_S.
    vec2 mv = uv - histUV;
#if MB_V2 == 1
    // --- MB_V2 (settings.glsl): framerate-normalized, dithered, depth-aware. ---
    // Sky never reprojects above (histUV stays uv when the whole 3x3 is sky):
    // rebuild a ROTATION-ONLY velocity at the far plane, else a fast pan
    // leaves a razor-sharp sky glued to blurred terrain. Translation is
    // irrelevant at infinity, so mat3() drops it on purpose. The dot(mv,mv)
    // guard keeps the DH branch's reprojection when it did run.
    if (dClose >= 1.0 && dot(mv, mv) < 1e-12) {
        vec3 wdir = mat3(gbufferModelViewInverse) * toView(uv, 0.9999);
        vec4 pcSky = gbufferPreviousProjection
                   * vec4(mat3(gbufferPreviousModelView) * wdir, 1.0);
        if (pcSky.w > 0.001) mv = uv - (pcSky.xy / pcSky.w * 0.5 + 0.5);
    }
    // blendFactor >= 0.999: disocclusion/offscreen (TAA dropped the history).
    // 0.25 raw length: teleport/dimension warp. Both cut the blur outright.
    // V1 cut at 0.05 instead, which also killed legitimate fast pans (blur
    // popped off past 5% of the screen); V2 clamps those to the cap below.
    if (blendFactor < 0.999 && length(mv) < 0.25) {
        // Framerate normalization: mv is a PER-FRAME offset, so the raw trail
        // shrinks as fps rises. Rescale to a fixed 1/60 s shutter; the clamp
        // guards hitches and timer glitches AND bounds the validity domain:
        // same trail between 15 and 240 fps (the 0.25..4.0 clamp saturates
        // outside -- at 480 fps the trail is back to half of 60 fps's, below
        // 15 fps it stretches past the shutter). Widen to (0.25, 8.0) if
        // coverage up to 480 fps is ever needed. Note the 0.25 teleport guard
        // above tests the RAW per-frame vector, so its threshold scales with
        // framerate too -- acceptable: it only exists to catch warps.
        mv *= MOTION_BLUR_STRENGTH * clamp((1.0 / 60.0) / max(frameTime, 1e-4), 0.25, 4.0);
        // Hard cap: never more than 3% of the screen, whatever the dial says.
        float mvLen = length(mv);
        if (mvLen > 0.03) mv *= 0.03 / mvLen;
        // Near-field fade on the DILATED depth (dClose) -- the depth mv was
        // actually reprojected from (toView(uv, dClose) above). The hand (raw
        // depth < ~0.56 linearizes below 0.2 blocks) drops to zero and
        // geometry within arm's reach keeps only part of its blur -- no hand
        // smear. Using the pixel's OWN d0 here left the 1-px dilation crown
        // around the hand at FULL blur (d0 = the far background) while mv
        // still carried the hand's bogus world velocity: the crown got up to
        // the 3% cap in a wrong direction. min(d0, dClose) == dClose by
        // construction, so the crown now fades exactly like the hand itself.
        float linC = 2.0 * near * far / (far + near - (dClose * 2.0 - 1.0) * (far - near));
        mv *= smoothstep(0.35, 1.5, linC);
        if (dot(mv, mv) > 1e-10) {
            // Symmetric dithered gather along mv. The jitter is a SPATIAL
            // hash: this pass runs after its own TAA resolve, temporal noise
            // would shimmer. Each tap is weighted by relative depth so a much
            // NEARER tap (hand, mob silhouette) is not dragged into the trail
            // of a far pixel; same-or-farther taps keep full weight (floor
            // gradients stay blurred). Weights renormalize -> no dark rim.
            float jit = hash12(gl_FragCoord.xy) - 0.5;
            vec3  mbAcc = result;
            float mbW   = 1.0;
            for (int s = 0; s < MOTION_BLUR_SAMPLES; s++) {
                float t  = (float(s) + 0.5 + jit) / float(MOTION_BLUR_SAMPLES) - 0.5;
                vec2  sc = clamp(uv + mv * t, vec2(0.0), vec2(1.0));
                // half-texel inset: at the TAAU sub-rect edge a bilinear tap
                // would blend the dead zone (V1 sampled it raw).
                vec2  scr = min(sc * TAAU_S, vec2(TAAU_S) - 0.5 * px);
                float dT   = texture2D(depthtex0, scr).r;
                float linT = 2.0 * near * far / (far + near - (dT * 2.0 - 1.0) * (far - near));
                float w    = smoothstep(0.25, 0.5, linT / max(linC, 0.05));
                mbAcc += texture2D(colortex0, scr).rgb * w;
                mbW   += w;
            }
            result = mbAcc / mbW;
        }
    }
#else
    if (blendFactor < 0.999 && length(mv) < 0.05) {
        vec2 stepM = mv * MOTION_BLUR_STRENGTH / float(MOTION_BLUR_SAMPLES);
        vec3 mb = result;
        for (int s = 1; s <= MOTION_BLUR_SAMPLES; s++) {
            vec2 sc = clamp(uv - stepM * float(s), vec2(0.0), vec2(1.0));
            mb += texture2D(colortex0, sc * TAAU_S).rgb;
        }
        result = mb / float(MOTION_BLUR_SAMPLES + 1);
    }
#endif
}
#endif
#else
    // TAA off: pass-through (TAAU_S is 1.0 via the "defined TAA" gate in common.glsl)
    vec3 result = texture2D(colortex0, uv).rgb;
#endif

    // colortex0 = composited image, colortex7 = TAA history
    // (TAA off: result == current, so history = current frame)
/* DRAWBUFFERS:07 */
    gl_FragData[0] = vec4(result, 1.0);
#if defined TAA && TAA_V2 == 1 && TAA_QUALITY == 2
    // colortex7.a = this pixel's temporal instability, read back next frame to
    // widen its clip box. Free channel: nothing else in the pack reads the
    // alpha of colortex7 (composite1 takes .rgb only), and colortex0's alpha,
    // written just above, is untouched.
    gl_FragData[1] = vec4(result, taaInstNew);
#else
    gl_FragData[1] = vec4(result, 1.0);
#endif
}
