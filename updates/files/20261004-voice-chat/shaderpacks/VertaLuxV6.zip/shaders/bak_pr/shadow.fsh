#version 430 compatibility
/* Shadow pass (fragment) + VOXELIZATION. CORPS PARTAGE : tout le programme vit
   dans /lib/program_shadow_fragment.glsl (details la-bas), compile une seconde
   fois par physics_ocean_shadow_v2.fsh (ombre de l'ocean PHYSICS MOD PRO).
   Ici : chemin normal. */

#include "/lib/program_shadow_fragment.glsl"
