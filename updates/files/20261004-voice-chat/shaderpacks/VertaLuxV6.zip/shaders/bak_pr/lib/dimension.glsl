/*
    VertaLux - dimension detection + dimensional palettes (DIMENSION_FX,
    lib/settings.glsl). RUNTIME detection from the Iris biome uniforms, no
    world-1 / world1 shader folders.
    DOUBLE detection, each term robust on its own:
      (1) biome_category == CAT_NETHER / CAT_THE_END (Iris tags IS_NETHER /
          IS_END; CAT_* macros are injected by Iris from its BiomeCategories
          enum: NETHER = 16, THE_END = 8 - fallback values below if a build
          does not inject them);
      (2) biome == BIOME_<registry path upper-cased> for the five vanilla
          biomes of each dimension (macros injected by Iris from the biome
          registry; each one is #ifdef-guarded so a missing macro just drops
          its term).
    dimNether() / dimEnd() return EXACTLY 0.0 or 1.0 (uniform branches, zero
    per-pixel cost). OVERWORLD INTACT BY CONSTRUCTION: every consumer weights
    its dimensional term by these values, which are 0.0 everywhere outside the
    Nether / End, and the whole file compiles down to constant 0.0 stubs when
    DIMENSION_FX = 0 (every call site is gated as well).
    Included by every program that reads lighting/sky (BEFORE lib/lighting.glsl,
    after lib/common.glsl: the palette helpers need toLinear/luma), by
    composite5.fsh, final.fsh (debug view 25) and by shadow.fsh (lava height
    map; detection only, see VL_DIMENSION_DETECT_ONLY).
    END_STORM (lib/settings.glsl): the End palette switches to blue-night and
    the END_STORM_ACTIVE helpers at the bottom (lightning state, haze
    profile, reprojection anchor) serve the storm of lib/end_storm.glsl.
*/
#ifndef VL_DIMENSION_GLSL
#define VL_DIMENSION_GLSL

// Vanilla fogColor (per-biome fog color: in the Nether each biome has its
// own - crimson red, warped teal, soul-sand blue, basalt grey). Declared
// under the same guard in lib/lighting.glsl, so include order never matters.
#ifndef VL_FOGCOLOR_DECL
#define VL_FOGCOLOR_DECL
uniform vec3 fogColor;
#endif

#if DIMENSION_FX == 1
uniform int biome;            // Iris: registry id of the camera biome (compare with BIOME_*)
// Garde purement preprocesseur : PHYSICS_FIELD_SYNC (lib/water.glsl) declare le
// meme uniforme sous son propre gate, et un uniforme en double est une erreur
// GLSL. Le texte emis est identique dans tous les cas - une seule declaration.
#ifndef VL_BIOMECAT_DECL
#define VL_BIOMECAT_DECL
uniform int biome_category;   // Iris: BiomeCategories ordinal (compare with CAT_*)
#endif

// Iris injects CAT_* for every BiomeCategories constant; these fallbacks are
// the ordinals of the Iris enum (NONE 0 .. MUSHROOM 15, NETHER 16; THE_END 8)
// and are only reached if a build does not inject the macros.
#ifndef CAT_NETHER
#define CAT_NETHER 16
#endif
#ifndef CAT_THE_END
#define CAT_THE_END 8
#endif

// 1.0 in the Nether (category OR one of its vanilla biomes), else 0.0.
float dimNether() {
    bool n = (biome_category == CAT_NETHER);
#ifdef BIOME_NETHER_WASTES
    n = n || (biome == BIOME_NETHER_WASTES);
#endif
#ifdef BIOME_SOUL_SAND_VALLEY
    n = n || (biome == BIOME_SOUL_SAND_VALLEY);
#endif
#ifdef BIOME_CRIMSON_FOREST
    n = n || (biome == BIOME_CRIMSON_FOREST);
#endif
#ifdef BIOME_WARPED_FOREST
    n = n || (biome == BIOME_WARPED_FOREST);
#endif
#ifdef BIOME_BASALT_DELTAS
    n = n || (biome == BIOME_BASALT_DELTAS);
#endif
    return n ? 1.0 : 0.0;
}

// 1.0 in the End (category OR one of its vanilla biomes), else 0.0.
float dimEnd() {
    bool e = (biome_category == CAT_THE_END);
#ifdef BIOME_THE_END
    e = e || (biome == BIOME_THE_END);
#endif
#ifdef BIOME_END_HIGHLANDS
    e = e || (biome == BIOME_END_HIGHLANDS);
#endif
#ifdef BIOME_END_MIDLANDS
    e = e || (biome == BIOME_END_MIDLANDS);
#endif
#ifdef BIOME_SMALL_END_ISLANDS
    e = e || (biome == BIOME_SMALL_END_ISLANDS);
#endif
#ifdef BIOME_END_BARRENS
    e = e || (biome == BIOME_END_BARRENS);
#endif
    return e ? 1.0 : 0.0;
}

// Palettes need lib/common.glsl (toLinear / luma / vnoiseTex). shadow.fsh
// defines VL_DIMENSION_DETECT_ONLY before including this file: it only needs
// the detection above and does not include common.glsl.
#ifndef VL_DIMENSION_DETECT_ONLY
// ---------------- Nether palette (all driven by the vanilla fogColor) ----------------
// Luma-normalized linear chroma of the biome fog (clamped: a pure-red fog
// would otherwise explode on its R channel).
vec3 dimFogChroma() {
    vec3 f = toLinear(fogColor);
    return min(f / max(luma(f), 1e-4), vec3(4.0));
}
// Fully-fogged radiance: the volumetric in-scatter limit, the horizon of the
// Nether dome and the distance-fog color all share it (one source -> the fog
// wall and the sky never mismatch). NETHER_FOG_BRIGHT scales its luminance.
vec3 dimNetherFog() {
    return dimFogChroma() * (0.03 * NETHER_FOG_BRIGHT);
}
// Nether sky dome: fog color, zenith x0.6 -> horizon x1.0 (no sun, moon,
// stars, clouds or aurora there).
vec3 dimNetherSky(vec3 dir) {
    return dimNetherFog() * mix(1.0, 0.6, clamp(dir.y, 0.0, 1.0));
}
// Nether ambient (BEFORE the AMBIENT_INTENSITY multiply of getAmbientColor):
// fog chroma x NETHER_AMBIENT, independent of the (zero) skylight.
vec3 dimNetherAmbient() {
    return dimFogChroma() * (0.25 * NETHER_AMBIENT);
}
// NETHER_VOLUMETRIC density field: per-step multiplier for the Nether VL
// march (called by composite1.fsh and its lib/vl_halfres.glsl mirror;
// t = frameTimeCounter, passed as a parameter like the END helpers below -
// no uniform is declared here). Two decorrelated slices of the shared 2D
// value noise blended in y (lattice ~24 blocks in xz, 16 blocks per slice in
// y) drift at (1.2, 0.5) blocks/s - rolling smoke sheets, never a uniform
// soup - plus one 3x finer octave at 0.3 amplitude for wispy edges (skipped
// below VOLUMETRIC_QUALITY 2: 2 noise taps per step instead of 3).
// MEAN 1.0 TO WITHIN ~0.2 %, NOT BY CONSTRUCTION: the normalization assumes
// E[vnoiseTex] = 0.5, so the raw field is divided by that mean (0.5 alone,
// 0.65 with the fine octave). The baked texture (textures/vl_noise.bin,
// 256x256) actually averages 0.5015, hence E[field] = 1.003 and, at the
// default A = 0.45, E[(1-A) + A*field] = 1.0013. Measured against a uniform
// fog that is +0.03..0.11 % of marched optical depth and +0.3..1.0 % of mean
// transmittance (Jensen, exp being convex) - physically nil, but an
// approximation rather than an identity. The multiplier still spans
// [1-A, 1+A]; with the default A = NETHER_VOLUMETRIC_NOISE = 0.45 it reads
// 0.55 + 0.45*field in [0.55, 1.45]; at A = 0.0 it folds to exactly 1.0.
// TIME BASE: t = frameTimeCounter, which Iris resets to 0 every 3600 s. The
// drift then jumps 180 (x) / 75 (y) noise units in a single frame and the
// sheets re-organize at once - the same wrap the Overworld sites sharing
// this clock already have (patchy banks, SEALEVEL_MIST, VL_RAIN). Exact
// re-alignment is possible only if the hourly travel is a multiple of the
// 256-unit texture period on BOTH axes (and on the 3x octave), which forces
// a 45-degree 2.4 blocks/s wind; the calibrated (1.2, 0.5) drift is kept and
// the once-an-hour pop accepted. cloudWorldTime() is NOT used here: the
// Nether freezes its own day cycle, so a world clock could stall the field.
#if NETHER_VOLUMETRIC == 1
float netherFogNoise(vec3 wp, float t) {
    // Shared slow drift: both octaves ride the same wind (smoke rolls).
    vec2 pw = (wp.xz + t * vec2(1.2, 0.5)) * (1.0 / 24.0);
    float sy = wp.y * (1.0 / 16.0);
    float y0 = floor(sy);
    // Two y-slices of the 2D noise, decorrelated by a fixed per-slice
    // offset, blended by the y fraction (pseudo-3D field).
    float field = mix(vnoiseTex(pw + y0 * vec2(17.0, 31.0)),
                      vnoiseTex(pw + (y0 + 1.0) * vec2(17.0, 31.0)), sy - y0);
#if VOLUMETRIC_QUALITY >= 2
    // 3x finer octave (one extra tap; y-free, so no seams at slice bounds).
    field = (field + 0.3 * vnoiseTex(pw * 3.0 + 43.0)) * (1.0 / 0.65);
#else
    // Low VL budget: base octave alone, same mean (x2 renormalization).
    field *= 2.0;
#endif
#if VOLUMETRIC_QUALITY == 0
    // POTATO tier only (VL_SAMPLES = 4 -> dt ~40 blocks against a 24-block
    // lattice): the field is far under-sampled, so the blue-noise march
    // jitter makes the transmittance swim frame to frame (~5 % rms, ~16 % on
    // the worst ray, vs ~1.5 % at VQ 1 and ~0.4 % at VQ 3). HALF amplitude
    // here - same 1.0 mean, so the fog keeps its density: the sheets stay
    // readable and the flicker halves instead of the feature being cut.
    return (1.0 - NETHER_VOLUMETRIC_NOISE * 0.5) + (NETHER_VOLUMETRIC_NOISE * 0.5) * field;
#else
    return (1.0 - NETHER_VOLUMETRIC_NOISE) + NETHER_VOLUMETRIC_NOISE * field;
#endif
}
#endif

// ---------------- End palette ----------------
// Violet-black gradient: dark at the zenith AND toward the void (nadir), a
// brighter band at the horizon. Fog / reflections / sky share it.
// END_STORM_ACTIVE: blue-night dome (deep blue zenith, blue-violet horizon
// band, violet-black under the horizon where the storm sea lies).
vec3 dimEndSkyBase(vec3 dir) {
    float hw = 1.0 - abs(dir.y);
    hw *= hw;
#ifdef END_STORM_ACTIVE
    vec3 c = mix(vec3(0.012, 0.016, 0.042), vec3(0.036, 0.040, 0.088), hw);
    return mix(c, vec3(0.010, 0.007, 0.022), smoothstep(0.0, -0.35, dir.y));
#else
    return mix(vec3(0.010, 0.006, 0.020), vec3(0.050, 0.032, 0.080), hw);
#endif
}
// Thin violet haze radiance (volumetric in-scatter limit + distance tail).
// END_STORM_ACTIVE: blue-night haze.
vec3 dimEndFog() {
#ifdef END_STORM_ACTIVE
    return vec3(0.030, 0.036, 0.082);
#else
    return vec3(0.040, 0.026, 0.070);
#endif
}
// Soft violet nebula: two octaves of the shared value noise on a FIXED
// world-space projection of the view direction (never rotates: the world
// clock must not show in the End), confined to a band around a tilted axis.
vec3 dimEndNebula(vec3 dir) {
    vec3 ax = normalize(vec3(0.30, 0.62, 0.72));
    vec3 eu = normalize(cross(ax, vec3(0.0, 1.0, 0.0)));
    vec3 ev = cross(ax, eu);
    vec2 np = vec2(dot(dir, eu), dot(dir, ev)) * 2.6;
    float n1 = vnoiseTex(np * 1.5 + 37.0);
    float n2 = vnoiseTex(np * 3.7 + 91.0);
    float band = dot(dir, ax) * 1.4;
    float neb = smoothstep(0.38, 0.80, n1 * 0.65 + n2 * 0.35) * exp(-band * band);
    vec3 tint = mix(vec3(0.06, 0.03, 0.10), vec3(0.08, 0.045, 0.12), n2);
    return tint * neb * END_NEBULA;
}
// Fixed cold directional light (the End sun is frozen at noon: stable
// shadowLightPosition, shadows kept) and its skylight-independent ambient.
// END_STORM_ACTIVE: same luminance, electric blue hue / blue-cyan ambient.
vec3 dimEndLight() {
    // ONE declaration, outside every preprocessor block (the #if only picks
    // the initializer): nothing here can be stranded by a gate.
    vec3 c =
#ifdef END_STORM_ACTIVE
        vec3(0.38, 0.52, 0.92)
#else
        vec3(0.58, 0.52, 0.75)
#endif
        * END_LIGHT;
#ifdef END_BLACKHOLE_ACTIVE
    // BLACKHOLE_LIGHT (lib/blackhole.glsl): the hole is now ANCHORED on the
    // shadow axis (endBlackHoleDir reads shadowLightPosition), so this fixed
    // directional light IS the light of the accretion disk - every End
    // shadow points away from the hole and every lit face faces it. The
    // CHROMA is blended toward the ACTUAL unit-luma disk colour: the
    // flux-weighted mean of the rendered slab at the 7000 K default is
    // vlBlackbody(~4600 K) = (1.051, 1.007, 0.776) (lib/blackhole.glsl,
    // same rational-Planck fit; the constant below is that vector
    // renormalised to luma 1.0000). The previous constant (1.504, 0.902,
    // 0.486) was ~3x more saturated than the disk it claimed to copy and
    // sits OFF the Planckian locus at every temperature. Luminance is
    // preserved EXACTLY at every dial value - the dial recolors, never dims
    // (the old multiplicative tint lost 1.6% of luma at its default).
    // mix(c, ., 0.0) returns c bit-for-bit, so BLACKHOLE_LIGHT 0 is the
    // previous palette.
    c = mix(c, dot(c, vec3(0.2126, 0.7152, 0.0722)) * vec3(1.0512, 1.0074, 0.7759),
            BLACKHOLE_LIGHT * 0.70);
#endif
    return c;
}
vec3 dimEndAmbient() {
    vec3 c =
#ifdef END_STORM_ACTIVE
        vec3(0.09, 0.15, 0.28)
#else
        vec3(0.16, 0.12, 0.24)
#endif
        * END_AMBIENT;
#ifdef END_BLACKHOLE_ACTIVE
    // Same disk bleed on the skylight-independent ambient, weaker (the
    // ambient wraps the whole dome, only part of which holds the disk) and
    // luma-preserving like the light above: the same true disk chroma
    // desaturated 25% toward white (the same family relation the old pair
    // carried), luma(1.0384, 1.0055, 0.8320) = 1.000.
    c = mix(c, dot(c, vec3(0.2126, 0.7152, 0.0722)) * vec3(1.0384, 1.0055, 0.8320),
            BLACKHOLE_LIGHT * 0.45);
#endif
    return c;
}

// ---------------- END STORM helpers (END_STORM_ACTIVE) ----------------
// The storm volume and its march live in lib/end_storm.glsl (included after
// lib/clouds.glsl by prepare / deferred / composite1). The helpers below are
// needed earlier or by programs without the march (gbuffers lighting, VL
// march + its half-res mirror, composite5 flash, prepare1 reprojection), so
// they take every input as a parameter (no uniform is declared here).
#ifdef END_STORM_ACTIVE
// Lightning state, STATELESS: everything derives from the 1-s slot floor(t)
// of frameTimeCounter through hash12, so every program of a frame (prepare
// bake, gbuffers, VL march, deferred sky, composite5 flash) sees the same
// strike from the same inputs. Per slot: a strike with probability
// 0.10 x END_LIGHTNING_RATE (never more than one per second), its onset
// drawn so the whole window fits in the slot, envelope = sharp 4% rise x
// squared decay x 2-3 cosine sub-pulses, first peak ~0.88, followed by a
// REMANENCE of the same length as the pulse (the window is 2 x the 0.15-0.4 s
// duration, <= 0.8 s). Bolt: past the END_ISLAND_CLEAR ramp and up to 180
// blocks farther out (polar draw), world y in [30, 150] (the
// pillar band), following the camera during the pulse (< 1 block of drift at
// walking speed). Returns the flash intensity (0 = idle) and fills the bolt
// world position and color. camPos = vec3(0) yields the horizontal offset
// in boltPos.xz (composite5 has no cameraPosition).
float endLightningState(float t, vec3 camPos, out vec3 boltPos, out vec3 boltCol) {
    boltPos = camPos;
    boltCol = vec3(END_LIGHTNING_R, END_LIGHTNING_G, END_LIGHTNING_B);
#if END_LIGHTNING == 1
    float slot = floor(t);
    if (hash12(vec2(slot, 3.1)) >= 0.10 * END_LIGHTNING_RATE) return 0.0;
    float dur = 0.15 + 0.25 * hash12(vec2(slot, 11.3));
    // The window is now 2 x dur: the pulse plus a REMANENCE of the same length
    // again, so the storm keeps glowing for a beat instead of snapping back to
    // night in one frame. 2 x dur <= 0.8 s and the onset is drawn out of
    // (1 - 2 dur) >= 0.2, so the whole window still fits inside the 1-s slot
    // and the "never more than one strike per second" contract is untouched.
    float x = (t - slot - hash12(vec2(slot, 7.9)) * (1.0 - 2.0 * dur)) / dur; // 0..2
    if (x < 0.0 || x > 2.0) return 0.0;
    // Bolt distance: with the default END_ISLAND_CLEAR = 100 the old 110-260
    // draw put 27 % of the strikes INSIDE the island clearing ramp, where the
    // storm density multiplier is 0.03 at 110 blocks and 0.16 at 150 - those
    // bolts lit empty air. Starting the draw past the clearing takes the mean
    // density around the bolt from 0.73 to 0.96, and the range follows the
    // dial so a wide arena still gets its strikes on the storm wall.
    float r = max(140.0, END_ISLAND_CLEAR * 1.55) + 180.0 * hash12(vec2(slot, 19.7));
    float a = hash12(vec2(slot, 23.1)) * 6.2831853;
    float hy = hash12(vec2(slot, 29.3));
    boltPos = vec3(camPos.x + cos(a) * r, 30.0 + 120.0 * hy, camPos.z + sin(a) * r);
    // Envelope over the doubled window: same sharp onset and squared decay as
    // before (first peak ~0.88 near x = 0.07, against ~0.83, so every consumer
    // keeps its calibration), with a second squared factor that drops the tail
    // fast and then lets it linger - ~8 % left at x = 1, where the old pulse
    // was already exactly 0. The sub-pulse rate is halved in x so the doubled
    // window still holds the same 2-3 sub-flashes.
    float sub = 0.55 + 0.45 * cos((x - 0.06) * 3.1415927 * (2.0 + hy));
    float dec = 1.0 - 0.5 * x;
    dec *= dec;
    return smoothstep(0.0, 0.04, x) * dec * (0.25 + 0.75 * dec) * sub;
#else
    return 0.0;
#endif
}
// Haze altitude profile (multiplies END_HAZE_DENSITY / 450): 1.0 at island
// altitude (y ~ 70), 0.5 high above, ~1.0 again toward the void.
float endHazeProfile(float y) {
    float dy = (y - 70.0) / 55.0;
    return 0.5 + 0.5 * exp(-0.5 * dy * dy) + 0.5 * smoothstep(30.0, -40.0, y);
}
// Representative storm distance of a sky ray (prepare1 reprojection anchor):
// the pillars ring the camera from ~90 blocks out and the END_STORM_SCALE
// features push the visual mass farther, so a fixed 240 blocks inside the
// band; above it, the hit on the y = 100 plane (clamped to the march range).
float endStormRepDistance(vec3 dir, vec3 camPos) {
    float tRep = 240.0;
    if (camPos.y > 230.0 && dir.y < -1e-4) tRep = clamp((100.0 - camPos.y) / dir.y, 90.0, END_STORM_RANGE);
    return tRep;
}
#endif // END_STORM_ACTIVE
#endif // VL_DIMENSION_DETECT_ONLY
#else
// DIMENSION_FX = 0: constant stubs (every call site is gated out anyway).
float dimNether() { return 0.0; }
float dimEnd() { return 0.0; }
#endif

#endif // VL_DIMENSION_GLSL
