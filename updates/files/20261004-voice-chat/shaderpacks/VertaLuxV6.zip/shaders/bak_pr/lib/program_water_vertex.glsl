/* CORPS PARTAGE des translucides (vertex) : water, glass, ice.
   Compile deux fois :
     - gbuffers_water.vsh          -> chemin normal (eau vanilla, WAVES_V3) ;
     - physics_ocean_v2.vsh        -> variante ocean de PHYSICS MOD PRO
       (marqueur VLX_PHYSICS_OCEAN_PROGRAM), ou la geometrie suit les vagues
       SIMULEES du mod au lieu de notre champ.
   La surface d'eau est deplacee verticalement par le champ de vagues
   (chemin v2 uniquement ; v3 = quad plat, cf. note plus bas). */

#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/water.glsl"

/* ===== PHYSICS MOD PRO : ocean dynamique ====================================
   PHYSICS_OCEAN n'existe que si ce corps est compile DEPUIS le wrapper
   physics_ocean_v2.vsh (VLX_PHYSICS_OCEAN_PROGRAM) ET si PHYSICS_MOD_SUPPORT
   vaut 1 (lib/settings.glsl). gbuffers_water.vsh ne definit jamais le
   marqueur : l'eau vanilla (lacs, rivieres, tout ce que l'ocean du mod ne
   remplace pas) garde le chemin WAVES_V3 strictement intact. */
#if defined VLX_PHYSICS_OCEAN_PROGRAM && PHYSICS_MOD_SUPPORT == 1
    #define PHYSICS_OCEAN
#endif
#ifdef PHYSICS_OCEAN
#include "/lib/physicsmod_ocean.glsl"
    // Attribut par sommet du maillage ocean du mod : facteur cote/profondeur
    // (0 pres du rivage -> 1 au large), meme source que le facteur CPU qui
    // fait flotter les entites.
    attribute float physics_waviness;
    // Interpolants exiges par physics_wavePixel cote fragment.
    varying vec3 physics_localPosition;
    varying float physics_localWaviness;
#endif

attribute vec4 mc_Entity;

uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
uniform vec3 cameraPosition;
uniform float frameTimeCounter;
uniform int frameCounter;   // drives the TAA jitter sequence
uniform float viewWidth;
uniform float viewHeight;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 normal;
varying vec3 viewPos;
varying vec3 worldPos;
varying float mat;

void main() {
    mat = mc_Entity.x;

#ifdef PHYSICS_OCEAN
    // Ocean du mod : la hauteur est celle de PHYSICS MOD (le meme champ est
    // evalue cote CPU pour faire flotter entites et bateaux - ne PAS
    // re-echelonner) + le micro-relief des ripples (sillages, impacts).
    // gl_Vertex est le maillage LOCAL du mod ; physics_waveOffset /
    // physics_modelOffset (UBO par chunk) recalent le champ, donc tout se
    // calcule en espace maillage, JAMAIS en worldPos. Notre deplacement
    // WATER_DISPLACEMENT est coupe plus bas (garde !defined PHYSICS_OCEAN) :
    // aucun double deplacement possible.
    physics_localWaviness = physics_waviness;
    vec4 vlxVertex = vec4(gl_Vertex.x,
                          gl_Vertex.y
                        + physics_waveHeight(gl_Vertex.xz, PHYSICS_ITERATIONS_OFFSET,
                                             physics_localWaviness, physics_gameTime)
                        + physics_rippleVertexHeight(gl_Vertex.xz),
                          gl_Vertex.z, gl_Vertex.w);
    physics_localPosition = vlxVertex.xyz;
#else
    vec4 vlxVertex = gl_Vertex;
#endif

    vec4 pos = gl_ModelViewMatrix * vlxVertex;
    vec4 wp = gbufferModelViewInverse * pos;
    vec3 absW = wp.xyz + cameraPosition;

    #ifdef WATER_WAVES
    #ifdef WATER_DISPLACEMENT
    #if WAVES_V3 == 0 && !defined PHYSICS_OCEAN
        // Only the top face of the water block waves (mat 8), never the block bottom
        if (mat > 7.5 && mat < 8.5 && fract(absW.y - 0.01) > 0.7) {
            // PERF: distance LOD on the displacement. Past ~48 blocks the
            // amplitude (<0.11 block) is sub-pixel, 3 octaves are enough; the
            // full chop (5 octaves) is kept for the foreground.
            float vDistW = length(pos.xyz);
            int octW = (vDistW < 48.0) ? 5 : ((vDistW < 128.0) ? 4 : 3);
            float h = waveHeightLOD(absW.xz, frameTimeCounter, octW);
            // Upper clamp kept low: a higher ceiling pins the crests against the
            // top of the block and flattens them. The -0.02 bias lowers the whole
            // sheet slightly.
            wp.y += clamp((h - 0.45) * 0.18 * WAVE_STRENGTH, -0.16, 0.05) - 0.02;
            pos = gbufferModelView * wp;
        }
    #else
        // WAVES_V3 keeps the quad strictly FLAT - the whole relief lives in the
        // normal plus the parallax march - so the displacement is skipped here.
        // It is not merely redundant under v3, it is harmful: wave3Pos() is
        // wpos.xz - wpos.y (the decorrelation that stops two ponds at different
        // altitudes being clones), and gbuffers_water.fsh and composite1.fsh
        // both sample it at the DISPLACED world position, so a vertex offset
        // shears the sampling plane with the field's own coarse height.
        // MEASURED at the shipped defaults: a dy span of 0.210 block, 85% of the
        // finest rung's 0.247 block crest pitch, for RMS 3.45 deg / p99
        // 10.90 deg of undesigned normal perturbation against a field mean tilt
        // of 4.56 deg. WATER_DISPLACEMENT still drives the v2 path above.
        // Sous PHYSICS_OCEAN ce bloc est coupe aussi (le mod deplace deja).
    #endif
    #endif
    #endif

    viewPos = pos.xyz;
    worldPos = wp.xyz + cameraPosition;
    gl_Position = gl_ProjectionMatrix * pos;
    #ifdef TAA
        // TAAU: jitter measured in RENDER BUFFER texels (see gbuffers_terrain.vsh).
        gl_Position.xy += taaJitterNDC(frameCounter) * TAA_JITTER * gl_Position.w * vec2(2.0 / (viewWidth * TAAU_S), 2.0 / (viewHeight * TAAU_S));
    #endif
    // TAAU: bottom-left sub-rect mapping, AFTER the jitter (see gbuffers_terrain.vsh).
    // At TAAU_S = 1.0 this folds away at compile time (no-op).
    gl_Position.xy = gl_Position.xy * TAAU_S + gl_Position.w * (TAAU_S - 1.0);

    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord  = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    glcolor  = gl_Color;
    normal   = normalize(gl_NormalMatrix * gl_Normal);
}
