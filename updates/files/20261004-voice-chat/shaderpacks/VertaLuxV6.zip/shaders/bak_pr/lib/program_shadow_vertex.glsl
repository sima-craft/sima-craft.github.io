/* CORPS PARTAGE du shadow pass (vertex) + world position used by voxelization.
   Compile deux fois :
     - shadow.vsh                  -> chemin normal ;
     - physics_ocean_shadow_v2.vsh -> variante ocean de PHYSICS MOD PRO
       (VLX_PHYSICS_OCEAN_PROGRAM) : l'ombre portee de l'ocean suit les vagues
       SIMULEES du mod (meme deplacement que physics_ocean_v2.vsh).
   Needs GLSL 430 compatibility so the fragment stage can write the voxel image.
   CL_V3 (lib/settings.glsl): the colored-lights voxelization moved HERE, per block id.
   Every vertex of a TERRAIN block computes its block CENTER from at_midBlock, snaps it
   into the 128^3 block-aligned grid (cl3VoxImg, r32ui) and stores ONE integer: the
   emissive family id of mc_Entity, or 1 = solid, 0 = air (never written, clear value).
   All vertices of one block write the IDENTICAL integer -> no write race can exist
   (the fragment-side races that made the tint dance die structurally).
   ENTITIES ARE EXCLUDED FAIL-CLOSED, twice over:
     (a) at_midBlock only exists in the TERRAIN vertex format; entities/hand read the
         default attribute (0,0,0), rejected by the validity test below - so even a
         renderStage uniform stuck on a terrain stage cannot voxelize the player;
     (b) when renderStage IS live, any known non-terrain stage vetoes the write.
   In doubt nothing is written: air stays air, the player can never become a wall -
   this is THE fix for "je fais une ombre ??" (the old fragment path failed OPEN:
   renderStage never changing meant EVERYTHING was voxelized, player included, who
   then occluded the flood and dragged a colored shadow around).
   L'ocean du mod est lui aussi fail-closed ici : son maillage n'a pas de
   at_midBlock valide (0,0,0 rejete par midValid) et son id est l'eau (8),
   exclue de toute facon -> jamais voxelise. */

#include "/lib/settings.glsl"
#include "/lib/distort.glsl"

/* ===== PHYSICS MOD PRO : ocean dynamique (voir program_water_vertex.glsl) == */
#if defined VLX_PHYSICS_OCEAN_PROGRAM && PHYSICS_MOD_SUPPORT == 1
    #define PHYSICS_OCEAN
#endif
#ifdef PHYSICS_OCEAN
#include "/lib/physicsmod_ocean.glsl"
in float physics_waviness;
#if PHYSICS_FIELD_SYNC == 1
// PHYSICS_FIELD_SYNC (lib/settings.glsl) : le pass OMBRE publie lui aussi le
// battement et les parametres du champ, parce qu'il tourne MEME QUAND LA
// SURFACE N'EST PAS A L'ECRAN - c'est lui qui garde le canal vivant en plongee
// ou quand la camera regarde le fond. Le drift (monde absolu - maillage local)
// se calcule ici : gl_Vertex.xz est le maillage du mod, voxelPos + cameraPosition
// le monde absolu. FLAT : c'est une constante par chunk, pas une quantite a
// interpoler (et la valeur du sommet provoquant est deterministe).
flat out vec2 vlxPhysDriftV;
flat out float vlxPhysWavV;
#ifndef VL_CAMERAPOS_DECL
#define VL_CAMERAPOS_DECL
uniform vec3 cameraPosition;
#endif
#endif
#endif

out vec2 texcoord;
out vec4 glcolor;
out float matS;
out vec3 voxelPos;   // world position RELATIVE TO CAMERA (feet), used to index the voxel grid

in vec4 mc_Entity;
uniform mat4 shadowModelViewInverse;

#if EMISSIVE_LPV == 1 && CL_V3 == 1
// Harness fallback only: Iris always injects the MC_RENDER_STAGE_* macros at runtime,
// so these #ifndef bodies are dead in game and only feed the offline compile checks.
#ifndef MC_RENDER_STAGE_TERRAIN_SOLID
#define MC_RENDER_STAGE_NONE 0
#define MC_RENDER_STAGE_TERRAIN_SOLID 8
#define MC_RENDER_STAGE_TERRAIN_CUTOUT_MIPPED 9
#define MC_RENDER_STAGE_TERRAIN_CUTOUT 10
#define MC_RENDER_STAGE_ENTITIES 11
#define MC_RENDER_STAGE_BLOCK_ENTITIES 12
#define MC_RENDER_STAGE_DESTROY 13
#define MC_RENDER_STAGE_OUTLINE 14
#define MC_RENDER_STAGE_DEBUG 15
#define MC_RENDER_STAGE_HAND_SOLID 16
#define MC_RENDER_STAGE_TERRAIN_TRANSLUCENT 17
#define MC_RENDER_STAGE_PARTICLES 19
#define MC_RENDER_STAGE_HAND_TRANSLUCENT 23
#endif
in vec3 at_midBlock;       // offset vertex -> block center, 1/64 block units (terrain only)
uniform int renderStage;   // live Iris render stage (veto only - see fail-closed note above)
// Garde purement preprocesseur (PHYSICS_FIELD_SYNC declare le meme uniforme
// sous son propre gate) : le texte emis est identique, un seul uniforme.
#ifndef VL_CAMERAPOS_DECL
#define VL_CAMERAPOS_DECL
uniform vec3 cameraPosition;
#endif
layout(r32ui) uniform uimage3D cl3VoxImg;   // CL3 id grid (shaders.properties, clear=0=air)
#endif

void main() {
#ifdef PHYSICS_OCEAN
    // Ombre de l'ocean PHYSICS MOD : meme deplacement que physics_ocean_v2.vsh
    // (hauteur simulee du mod + micro-relief des ripples), pour que l'ombre
    // portee ET le tag eau de shadowcolor0 suivent les vagues visibles.
    // gl_Vertex est le maillage LOCAL du mod (voir program_water_vertex.glsl).
    vec4 vlxVertex = vec4(gl_Vertex.x,
                          gl_Vertex.y
                        + physics_waveHeight(gl_Vertex.xz, PHYSICS_ITERATIONS_OFFSET,
                                             physics_waviness, physics_gameTime)
                        + physics_rippleVertexHeight(gl_Vertex.xz),
                          gl_Vertex.z, gl_Vertex.w);
#else
    vec4 vlxVertex = gl_Vertex;
#endif

    // Camera-relative world position = inverse shadow modelview applied to view space
    vec4 viewPos = gl_ModelViewMatrix * vlxVertex;
    voxelPos = (shadowModelViewInverse * viewPos).xyz;

#if defined PHYSICS_OCEAN && PHYSICS_FIELD_SYNC == 1
    // PHYSICS_FIELD_SYNC : drift monde -> maillage du mod, calcule au sommet.
    // physics_waveOffset (UBO par chunk) recale deja le champ dans le maillage,
    // donc pos_champ = worldXZ - drift avec drift constant par chunk. Le
    // deplacement du mod est purement vertical : gl_Vertex.xz est le meme xz que
    // le sommet non deplace, exactement comme cote gbuffer.
    vlxPhysDriftV = (voxelPos.xz + cameraPosition.xz)
                  - (gl_Vertex.xz - vec2(physics_waveOffsetX, physics_waveOffsetZ));
    vlxPhysWavV = clamp(physics_waviness, 0.0, 1.0);
#endif

#ifdef PHYSICS_OCEAN
    // ftransform() relirait gl_Vertex NON deplace : projection explicite du
    // sommet deplace (strictement equivalente apres le patch core d'Iris).
    gl_Position = gl_ProjectionMatrix * viewPos;
#else
    gl_Position = ftransform();
#endif
    float f = getDistortFactor(gl_Position.xy);
    gl_Position.xyz = distortShadow(gl_Position.xyz, f);

    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    glcolor  = gl_Color;
    matS     = mc_Entity.x;

#if EMISSIVE_LPV == 1 && CL_V3 == 1
    // ---- CL_V3 block-id voxelization (see header). Runs per vertex; the store is
    // cheap (4 bytes) and every vertex of a block hits the same cell with the same id.
    // VALIDITY: a real terrain vertex sits within half a block of its center (|mb|
    // <= 0.5, tolerance 0.76 for oversized models), and at least one component is
    // nonzero (cube/cross vertices never sit exactly ON the center; the (0,0,0)
    // default of a vertex format WITHOUT the attribute is rejected here). Losing a
    // hypothetical dead-center vertex is harmless: its block's other vertices write.
    vec3 mb = at_midBlock * (1.0 / 64.0);
    bool midValid = all(lessThan(abs(mb), vec3(0.76)))
                 && (abs(mb.x) + abs(mb.y) + abs(mb.z) > 0.001);
    // STAGE VETO (belt to the at_midBlock braces): when renderStage is live, any
    // known non-terrain stage blocks the write outright. A stage value that never
    // changes cannot fail open - midValid already rejected everything non-terrain.
    bool stageVeto = renderStage == MC_RENDER_STAGE_ENTITIES
                  || renderStage == MC_RENDER_STAGE_BLOCK_ENTITIES
                  || renderStage == MC_RENDER_STAGE_HAND_SOLID
                  || renderStage == MC_RENDER_STAGE_HAND_TRANSLUCENT
                  || renderStage == MC_RENDER_STAGE_PARTICLES
                  || renderStage == MC_RENDER_STAGE_DESTROY
                  || renderStage == MC_RENDER_STAGE_OUTLINE
                  || renderStage == MC_RENDER_STAGE_DEBUG;
    if (midValid && !stageVeto) {
        float idF = mc_Entity.x;
        // Non-occluders stay AIR (no write): water 8, portal 25, glass 30 - light
        // must pass through them (same exclusions as the legacy fragment path).
        bool skipT = (idF > 7.5 && idF < 8.5) || (idF > 24.5 && idF < 25.5)
                  || (idF > 29.5 && idF < 30.5);
        if (!skipT) {
            // Emissive CANDIDATE ranges only - the per-family glow toggles
            // (REDSTONE_BLOCK_GLOW & co) are applied ONCE, in composite.csh
            // (cl3Emissive): a disabled family is treated as plain solid there.
            // Block-state gating (lit torches/lamps/campfires, berried vines,
            // active sculk) lives in block.properties: the unlit states carry no
            // id and land in the solid branch here. Everything else (foliage 10,
            // smooth stones 40/41, snow 42, unmatched -1) is a plain occluder.
            bool emisT = (idF > 16.5 && idF < 24.5)
                      || (idF > 25.5 && idF < 29.5)
                      || (idF > 30.5 && idF < 38.5);
            uint idOut = emisT ? uint(idF + 0.5) : 1u;
            // Block center, camera-relative -> block-aligned 128^3 grid. SAME snap
            // family as lib/lighting.glsl sampleLPVForward (s = 1.0, +CL3_HALF):
            // cell = floor(p + fract-of-camera-block) + 64. Block centers sit at
            // *.5 world coordinates, so the floor is stable (no boundary jitter).
            vec3 bc = voxelPos + mb;
            ivec3 camB = ivec3(floor(cameraPosition));
            ivec3 cell = ivec3(floor(bc + (cameraPosition - vec3(camB)))) + CL3_HALF;
            if (all(greaterThanEqual(cell, ivec3(0))) && all(lessThan(cell, ivec3(CL3_RES))))
                imageStore(cl3VoxImg, cell, uvec4(idOut, 0u, 0u, 0u));
        }
    }
#endif
}
