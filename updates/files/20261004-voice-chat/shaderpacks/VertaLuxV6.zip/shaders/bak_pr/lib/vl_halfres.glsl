/*
    VL_HALF_RES march (composite.fsh, lower-left quadrant, v120-safe).

    ADAPTED VERBATIM from the composite1.fsh VOLUMETRIC_LIGHT march (the
    VL_HALF_RES=0 reference path): any tuning there MUST be mirrored here.
    Differences vs the reference, and nothing else:
      1. Runs per HALF-RES sample (uvF = represented full-res pixel center),
         one march per 2x2 pixel block; composite1 upsamples bilaterally.
      2. wMirror (water-branch mirror dominance of the RECEIVING pixel) is
         unknown in this pass. The only wMirror-dependent term in the whole
         march is the submerged step density  uw * 0.008 * (1 - wMirror*0.85),
         so the integral is carried at BOTH endpoints:
           Hi = wMirror 0 (full submerged coefficient kUW)
           Lo = wMirror 1 (0.15 residual, floor of the receiver weight)
         plus odUW = sum(kUW * dt) (unweighted submerged optical depth).
         composite1 recombines: transF = transHi * exp(0.85*wMirror*odUW)
         (EXACT: equals transAir * exp(-odUW*(1-0.85*wMirror))) and
         scat = mix(scatHi, scatLo, wMirror) (exact at both endpoints; the
         validated sunset mirror sits at wMirror ~0.9-0.98, next to Lo).
      3. The VL_BLOCKLIGHT term (additive on final color, wMirror/transF
         independent) is folded into BOTH stored scats; the VL_HALF_RES=0
         apply in composite1 is gated off accordingly.
      4. DIMENSION_FX blocks (skyExpo gate, dimensional densities, light /
         ambient override, per-step lava term) are copied from the reference
         march too - the four "MIRROR of composite1" blocks below, plus the
         END_STORM_ACTIVE trio (haze dial + bolt state, per-step haze
         profile, per-step lightning in-scatter).
      5. DAWN_MIST_VOL: the marched dawn-mist term (per-ray scalars + the
         per-step density added to densBase) is mirrored from the reference
         march as well. Its FIELD lives in lib/common.glsl
         (dawnMistHourW / dawnMistDens) and is SHARED by both paths on
         purpose - a copied noise field would let the half-res and the
         full-res mist drift apart.
    Outputs: outA = vec4(scatHi, transHi), outB = vec4(scatLo, odUW)
    -> colortex13 / colortex14 (RGBA16F, quadrant texels only).

    Requires (included before this file by composite.fsh): settings, common,
    distort, dimension (DIMENSION_FX weights + palettes), lighting (shadow
    samplers/matrices, cloudShadow, getLightColor, lavaGlowAt),
    water (causticShaftMask / causticSmall / waveCausticFull, plus
    vlCa4Vol / vlCa4Offset when CAUSTICS_V4 == 1), the local
    toView()/toViewDH() helpers and the depthtex1/far/isEyeInWater/
    eyeBrightnessSmooth uniforms.
*/
#if defined VOLUMETRIC_LIGHT && VL_HALF_RES == 1

void vlHalfResMarch(vec2 uvF, out vec4 outA, out vec4 outB) {
    // Per-sample context (mirror of the composite1 main() trunk). The ray
    // direction through a pixel is depth-independent: unproject at z = 1.
    vec3 viewDir = normalize(toView(uvF, 1.0));
    vec3 worldDir = mat3(gbufferModelViewInverse) * viewDir;
    vec3 lightW = normalize(mat3(gbufferModelViewInverse) * shadowLightPosition);
    vec3 gLightC = getLightColor();
    vec3 gAmbC = getAmbientColor();
#if BLUE_NOISE == 1
    // Same jitter family as the reference march (blue noise, TAA-averaged)
    float vlDither = blueDither(gl_FragCoord.xy, frameCounter);
#else
    float vlDither = bayer8(gl_FragCoord.xy);
#endif
    // Screen-probe submerged-glass detection is disabled pack-wide (see
    // composite1): constant false keeps the copied blocks compiled.
    bool inGlassUW = false;

#if VLX_PHYS_SYNC == 1
    // ===== PHYSICS_FIELD_SYNC : lecture du canal lateral ======================
    // MIRROR du tronc de composite1.fsh, adapte au #version 120 de composite.fsh :
    // pas de texelFetch ni de usampler ici, donc les DEUX texels absolus de
    // physOceanParams sont lus par texture2D a leur centre exact (0.25 / 0.75 sur
    // une texture 2x1 : la valeur est la meme en NEAREST comme en LINEAR).
    // L'estampille par pixel n'est PAS lue : la marche est volumetrique, aucun de
    // ses pas n'est la surface - c'est la meme regle "ambiante" que le site
    // immerge de composite1, et elle ne demande que le battement.
    vec4 vlxPP0 = texture2D(physOceanParamsSampler, vec2(0.25, 0.5));
    vec4 vlxPP1 = texture2D(physOceanParamsSampler, vec2(0.75, 0.5));
    // Meme tolerance d'une frame que dans composite1 (voir son tronc).
    float vlxHB = float(frameCounter) - vlxPP0.w;
    bool vlxPhysLive = (vlxPP0.w > 0.5) && (vlxHB > -0.5) && (vlxHB < 1.5);
    if (vlxPhysLive) {
        vlxPhysT     = vlxPP0.x;
        vlxPhysScale = max(vlxPP0.z, 1e-3);
        vlxPhysDrift = vlxPP1.xy;
    }
#if VLX_PHYS_BIOME == 1
    bool vlxPhysCat = (biome_category == CAT_OCEAN) || (biome_category == CAT_BEACH)
                   || (biome_category == CAT_RIVER) || (biome_category == CAT_NONE);
#else
    // VLX_PHYS_BIOME 0 (defaut, lib/settings.glsl) : pas de test de biome, le
    // battement et les tests d'altitude decident (le mapping biome_category
    // d'Iris sur cette version n'est pas verifiable, et un faux negatif
    // eteint le site immerge en silence).
    bool vlxPhysCat = true;
#endif
    bool vlxPhysAmb = vlxPhysLive && vlxPhysCat;
    float vlxPhysAmbWav = clamp(vlxPP1.z, 0.0, 1.0);
#endif

    // The march runs to OPAQUE terrain (depthtex1), not to glass or the water
    // surface: shafts and fog therefore cross transparent surfaces.
    float d1v = texture2D(depthtex1, uvF).r;
#ifdef DISTANT_HORIZONS
    // DH terrain: bound by the LOD (dhDepthTex1) when depthtex1 is empty.
    float dhD1v = texture2D(dhDepthTex1, uvF).r;
    float distVol = (d1v < 1.0) ? length(toView(uvF, d1v))
                  : ((dhD1v < 1.0) ? length(toViewDH(uvF, dhD1v)) : far);
#else
    float distVol = (d1v >= 1.0) ? far : length(toView(uvF, d1v));
#endif
    // F5 GHOST fix (translucent skins): bound the march by the VISIBLE surface
    // (depthtex0) for the entity flag band ONLY -- water (0.95+) and glass
    // stay traversed. Mirror of the reference march; keep bands in sync.
    {
        float d0vF5 = texture2D(depthtex0, uvF).r;
        if (d0vF5 < 1.0 && d0vF5 < d1v - 1e-6) {
            float matBvF5 = texture2D(colortex2, uvF).b;
            if (matBvF5 > 0.01 && matBvF5 < 0.30) distVol = min(distVol, length(toView(uvF, d0vF5)));
        }
    }
    float marchEnd = min(distVol, (isEyeInWater == 1) ? UW_RAY_DISTANCE : 160.0);
#if PERF_VL_ADAPTIVE == 1
    // PERF_VL_ADAPTIVE (LOT B, B5): effective step count follows the ray
    // length; the submerged eye keeps VL_SAMPLES (calibrated UW slab). MIRROR
    // of the composite1.fsh reference march -- keep the two blocks identical
    // (full rationale at that site and in the LOT B block of settings.glsl).
    int vlN = (isEyeInWater == 1) ? VL_SAMPLES
            : int(clamp(floor(marchEnd * 0.1),
                        (VL_SAMPLES < 6) ? float(VL_SAMPLES) : 6.0,
                        float(VL_SAMPLES)));
    float dt = marchEnd / float(vlN);
#else
    float dt = marchEnd / float(VL_SAMPLES);
#endif
    vec3 stepV = viewDir * dt;
    // Init at (dither-1): the loop increments BEFORE sampling -> positions
    // dt*(i+dither) in [0..marchEnd[ (see the reference march for why).
    vec3 p = stepV * (vlDither - 1.0);
    #ifdef VOLUMETRIC_CLOUDS
    #ifdef VC_GROUND_SHADOWS
#ifndef CLOUD_SHAFTS_ACTIVE
    // 2 cloud-shadow probes interpolated along the ray (reference pattern).
    // PERF_CSHADOW_CHEAP: cloudShadowCheap (5-tap field, lib/lighting.glsl;
    // pure pass-through at 0) -- MIRROR of the composite1.fsh csA/csB pair,
    // keep the two call pairs identical.
    float csA = cloudShadowCheap(cameraPosition + worldDir * (marchEnd * 0.25), lightW);
    float csB = cloudShadowCheap(cameraPosition + worldDir * (marchEnd * 0.75), lightW);
#endif
    #endif
    #endif
    // Dual-endpoint accumulators (see file header)
    vec3 scatHi = vec3(0.0);
    vec3 scatLo = vec3(0.0);
    float transHi = 1.0;
    float transLo = 1.0;
    float odUW = 0.0;
    vec3 blockFog = vec3(0.0);

    float duskF = clamp(1.0 - abs(sunHeight()) * 4.0, 0.0, 1.0) * smoothstep(-0.14, -0.04, sunHeight()); // asymmetric: keeps it off at night
    float eyeSky = float(eyeBrightnessSmooth.y) / 240.0;
    // Sky exposure of the EYE: gates every sky/dusk chroma applied below.
    float skyExpo = smoothstep(0.02, 0.40, eyeSky);
    // Nether fog is legitimately warm (same heuristic as the sky pass).
    if (fogColor.r > fogColor.g * 1.4) skyExpo = 1.0;
#if DIMENSION_FX == 1
    // ---- DIMENSION_FX (MIRROR of the composite1 reference march, keep in sync) ----
    // Nether / End have no skylight: the eye gate is forced open so the
    // fog keeps its chroma. dimN / dimE are exactly 0.0 in the Overworld.
    float dimN = dimNether();
    float dimE = dimEnd();
    skyExpo = max(skyExpo, max(dimN, dimE));
#endif
    float hfDens = 0.0;
    #ifdef HEIGHT_FOG
        hfDens = HEIGHT_FOG_DENSITY * (0.004 + duskF * 0.009 + rainStrength * 0.012)
               * (0.35 + 0.65 * eyeSky)
               * (1.0 + duskF * 0.35 * ATMO_FOG_DUSK_BOOST); // height fog reinforced at dusk
    #endif
    float airDens = 0.0008 * VL_STRENGTH;
#if DIMENSION_FX == 1
    // Height fog (patchy banks) off in both dimensions; the air density
    // becomes the dimensional fog: Nether dense warm 1/110 blocks
    // (NETHER_FOG_DENSITY), End thin violet END_HAZE_DENSITY/450 (dial live
    // with or without the storm; the altitude profile is storm-only).
    // (MIRROR of composite1)
    hfDens *= (1.0 - dimN) * (1.0 - dimE);
    airDens = mix(airDens, NETHER_FOG_DENSITY / 110.0, dimN);
    airDens = mix(airDens, END_HAZE_DENSITY / 450.0, dimE);
#endif

    float cosT = dot(viewDir, normalize(shadowLightPosition));
    float gP = (isEyeInWater == 1) ? 0.58 : 0.60;
    // The 0.86 CLAMP IS MANDATORY: the HG phase degenerates (NaN/inf) as g -> 1.
    if (isEyeInWater == 0) gP = min(gP + 0.10 * duskF * VL_DUSK_BOOST, 0.86);
    float phase = (1.0 - gP * gP) / (12.566 * pow(1.0 + gP * gP - 2.0 * gP * cosT, 1.5));
#if UW_SUN_COHERENT == 1
    // ---- UW_SUN_COHERENT: the ONE underwater light direction ----
    // (MIRROR of composite1.fsh, keep in sync)
    // cosT above is dot(view, AIR sun): correct for every air term, wrong for
    // every submerged one. Below the surface the light arrives REFRACTED, at
    // asin(sin(theta_air)/1.3333) -- 44.8 deg off vertical for a 20-deg sun
    // against the air's 70 deg, and never past the 48.59 deg Snell cone.
    // uwSunRefract (lib/water.glsl) is that direction, and its xz/y slide is
    // EXACTLY vlCa4Offset's, i.e. the geometry the shaft lookup already rides.
#if UW_SHAFT_FIX3 == 1
    // ---- UW_SHAFT_FIX3 (A): the SHADOW MAP's axis, both generations ----
    // (MIRROR of composite1.fsh, keep in sync)
    // uwShaftAxis(lightW) IS normalize(lightW) above 8.63 deg of elevation, so
    // everything built on uwLightW below -- the beam HG lobe (phaseU), its
    // pedestal, the striation phase floor, the UW_SUNGAZE_SOFT vanishing point
    // and the LOCK==0 blade basis -- points exactly where the shadow map
    // projects, i.e. where the diver's own shadow goes. The v4 / v3 split
    // disappears here on purpose: uwShaftAxis IS the v3 slope, so the two
    // generations now agree by construction instead of needing a branch.
    vec3 uwLightW = uwShaftAxis(lightW);
#elif CAUSTICS_V4 == 1
    vec3 uwLightW = uwSunRefract(lightW);
#else
    // MIRROR of composite1: with CAUSTICS_V4 off the v3 caustic keeps the
    // AIR-axis projection, so the shared underwater direction must fall
    // back to that same slope or the shadow probe and the floor spot end
    // up 25 deg apart. xz / y == lightW.xz / max(lightW.y, 0.15) == cprjOff.
    vec3 uwLightW = normalize(vec3(lightW.x, max(lightW.y, 0.15), lightW.z));
#endif
    float cosTU = dot(worldDir, uwLightW);
    // Water HG (g = 0.58) on the REFRACTED axis.
    float phaseU = (1.0 - 0.3364) / (12.566 * pow(1.3364 - 1.16 * cosTU, 1.5));
#if UW_SHAFT_V4 == 1
    // ---- UW_SHAFT_V4 (B): the phase of a beam SEEN FROM THE BANK ----------
    // (MIRROR of composite1.fsh, keep in sync)
    // cosTU is dot(AIR view, beam axis): right for a diver (no interface
    // between his eye and the step), wrong twice over for a dry eye -- the
    // scattering happens UNDER the surface, between the REFRACTED view ray and
    // the REFRACTED sun ray, and both vectors above are air vectors.
    // Refraction steepens both, and seen from the bank they sit on opposite
    // sides of the horizontal, so their angles ADD. With both inside the
    // 48.59 deg Snell cone, cos(dev) <= 0.563 - 0.437: the in-water scattering
    // deviation from a dry eye is ALWAYS >= 82.8 deg, i.e. the forward lobe of
    // the water HG is unreachable from above the surface -- and it is exactly
    // where the air cosT lands (2.15x too bright at this pack's noon, 3.29x at
    // a 20-deg sun, 9.43x at a 5-deg one). No dial: a wrong vector, not a
    // taste. worldDir is unit, so its xz length IS sin(theta_i), the identity
    // uwSunRefract already relies on for lightW. cosTU itself is left alone --
    // UW_SUNGAZE_SOFT's vanishing point must stay where the COLUMNS converge.
    if (isEyeInWater == 0 && !inGlassUW) {
        float cosTP = dot(-uwSunRefract(-worldDir), uwSunRefract(lightW));
        phaseU = (1.0 - 0.3364) / (12.566 * pow(1.3364 - 1.16 * cosTP, 1.5));
    }
#endif
#endif
    vec3 lightC = gLightC;
    lightC = max(lightC, vec3(0.10, 0.15, 0.26) * smoothstep(0.04, 0.30, lightHeight()));
    vec3 ambC = gAmbC;
    #ifdef FOG_BIOME_TINT
    // Biome tint - AIR ONLY (the UW path applies UW_BIOME_TINT itself).
    if (isEyeInWater == 0 && !inGlassUW && luma(fogColor) > 0.001) {
        vec3 fbCh = toLinear(fogColor) / max(luma(toLinear(fogColor)), 0.04);
        fbCh = min(fbCh, vec3(2.0));
        ambC *= mix(vec3(1.0), fbCh, FOG_BIOME_TINT_STRENGTH);
    }
    #endif
    // AIR PATH ONLY: underground, fade the fog chroma to a neutral cool gray.
#if UW_SHAFTS_UNIFIED == 1
    // MIRROR of composite1: beam colour reference taken BEFORE that
    // desaturation (a submerged eye never runs the branch below, so rebuilding
    // the beam from the desaturated lightC would leave it side-dependent under
    // an overhang). Identical to lightC in the open air, where skyExpo is 1.0.
    vec3 lightCraw = lightC;
#endif
    if (isEyeInWater == 0 && !inGlassUW) {
        vec3 coolN = vec3(0.85, 0.95, 1.10);
        lightC = mix(vec3(luma(lightC)) * coolN, lightC, skyExpo);
        ambC   = mix(vec3(luma(ambC))   * coolN, ambC,   skyExpo);
    }
    if (isEyeInWater == 1 || inGlassUW) {
        // Saturated blue-green tint (glass slightly dimmed vs direct water)
        float uwMult = (isEyeInWater == 1) ? 1.05 : 0.85;
        vec3 uwLightTint = vec3(0.32, 0.68, 0.92);
        vec3 uwAmbTint   = vec3(0.08, 0.28, 0.48);
        #ifdef UW_BIOME_TINT
          if (luma(fogColor) > 0.001) {
            vec3 fbN = toLinear(fogColor) / max(luma(toLinear(fogColor)), 0.04);
            float s = UW_BIOME_TINT_STRENGTH;
            uwLightTint = mix(uwLightTint, uwLightTint * fbN, s);
            uwAmbTint   = mix(uwAmbTint,   uwAmbTint   * fbN, s);
          }
        #endif
        lightC *= uwLightTint * uwMult;
        ambC   *= uwAmbTint;
    }
    // Directional shafts only exist when the star is up; window widened at dusk.
    float lightUp = smoothstep(-0.04, 0.14, lightHeight());
    lightUp = max(lightUp, smoothstep(-0.12, -0.02, lightHeight()) * 0.55);
#if DIMENSION_FX == 1
    // DIMENSION_FX light terms (MIRROR of composite1): Nether -> no sun/moon
    // shafts (the shadow map is the lava height map there), ambient
    // in-scatter = the fog limit dimNetherFog() (ambM is 0.22 in air); End ->
    // shafts at 65% (was 50%: +30% of the DIRECT term the island shadows
    // carve, same pass as the storm's x1.30 direct), ambient = dimEndFog().
    lightC = mix(lightC, vec3(0.0), dimN);
    lightC *= 1.0 - 0.35 * dimE;
    ambC = mix(ambC, dimNetherFog() * (1.0 / 0.22), dimN);
    ambC = mix(ambC, dimEndFog() * (1.0 / 0.22), dimE);
    float lightWyN = abs(lightW.y); // vertical share of the light axis (lava height map)
#ifdef END_STORM_ACTIVE
    // END STORM lightning (MIRROR of composite1): one bolt state per ray for
    // the per-step point-light in-scatter (the END_HAZE_DENSITY dial now sits
    // on the base End air density above; only the altitude profile stays
    // storm-only).
    vec3 bPE = vec3(0.0);
    vec3 bCE = vec3(0.0);
    float flE = 0.0;
    if (dimE > 0.5) flE = endLightningState(frameTimeCounter, cameraPosition, bPE, bCE);
#endif
#endif

#ifdef DAWN_MIST_VOL_ACTIVE
    // ---- DAWN_MIST_VOL per-ray scalars (MIRROR of composite1) ----
    // All camera-uniform, so the per-step test below is a UNIFORM branch:
    // the two noise taps are paid only during the MIST HOURS OR THE
    // AFTER-RAIN WINDOW, and cost nothing the rest of the time. (The hour
    // weight is not purely hourly: dawnMistHourW adds
    // wetness * (1 - rainStrength), and wetness lags rainStrength by minutes,
    // so dmOn stays true at any hour for a while after a shower -- which is
    // when the damp haze is meant to show.) Same hour / humidity weight, same
    // 2-blocks-under-the-eye anchor, same eye sky-exposure gate
    // (smoothstep(0.02, 0.40, eyeSky) IS fogEyeGate, WITHOUT the Nether
    // override skyExpo carries) and the same lowlands altitude weight as
    // the analytic layer. The VIEW-ELEVATION fade of that layer is
    // deliberately NOT reproduced here: a marched ray climbing out of the
    // layer loses the mist on its own, through the height profile.
    float dmK = 1.0 / DAWN_MIST_HEIGHT;
    float dmAnchorY = cameraPosition.y - 2.0;
    float dmD0 = 0.0030 * dawnMistHourW(float(worldTime), wetness, rainStrength)
               * DAWN_MIST_STRENGTH * smoothstep(0.02, 0.40, eyeSky)
               * exp(-max(cameraPosition.y - (WATER_LEVEL + 30.0), 0.0) / 40.0);
    bool dmOn = (isEyeInWater == 0) && (dmD0 > 1e-6);
    // WORLD clock for the bank drift (MIRROR of composite1): the field is
    // driven by the world HOUR, so /time set and sleeping move the banks WITH
    // the world, and the 3600 s frameTimeCounter wrap no longer jumps them.
    // 1.0/s in normal play -> the drift speeds need no rescaling.
    float dmT = cloudWorldTime();
    // NYQUIST guard on the bank amplitude (MIRROR of composite1): the step is
    // marchEnd / VL_SAMPLES = 20 blocks at the shipped VOLUMETRIC_QUALITY 1,
    // against a ~42 / ~11 block lattice, and this path is ALSO half-res --
    // full amplitude there makes the banks crawl until TAA dissolves them.
    // The remap in dawnMistDens keeps the mean at 1.0 whatever this is, so the
    // analytic tail stays joined at 160 blocks.
#if PERF_VL_ADAPTIVE == 1
    // B5: the guard follows the EFFECTIVE step count (MIRROR of composite1).
    float dmPatchy = DAWN_MIST_PATCHY * clamp(float(vlN) / 12.0, 0.35, 1.0);
#else
    float dmPatchy = DAWN_MIST_PATCHY * clamp(float(VL_SAMPLES) / 12.0, 0.35, 1.0);
#endif
#endif
#if UW_SHAFTS_UNIFIED == 1
    // ---- UNIFIED UNDERWATER BEAM: side-independent per-ray scalars ----
    // (MIRROR of composite1.fsh, keep in sync)
    // The beam must read the same on both sides of the surface. With the eye
    // submerged, lightC already carries the water tint and gP is already the
    // water 0.58; with a dry eye lightC is the AIR colour and gP carries the
    // dusk boost, so the very same water column produced a cold, neutral,
    // sharper beam seen from the bank. Rebuilt from the WATER values here, for
    // the beam term ONLY.
    // EAU5: WATER_TINT palier (WT_SHAFT_*, lib/settings.glsl). EXACT MIRROR of
    // the full-res line in composite1.fsh -- the two marches must not drift.
    // Palier 2 keeps vec3(0.32, 0.68, 0.92) * 1.05, bit-identical.
    vec3 uwShaftTint = vec3(WT_SHAFT_R, WT_SHAFT_G, WT_SHAFT_B) * 1.05; // = uwLightTint * uwMult(water)
    #ifdef UW_BIOME_TINT
      if (luma(fogColor) > 0.001) {
        vec3 fbNS = toLinear(fogColor) / max(luma(toLinear(fogColor)), 0.04);
        uwShaftTint = mix(uwShaftTint, uwShaftTint * fbNS, UW_BIOME_TINT_STRENGTH);
      }
    #endif
#if UW_SUN_COHERENT == 1
    // Water HG on the REFRACTED axis. phaseU (trunk) IS this expression at
    // g = 0.58 against cosTU, so the pedestal, the striation floor and the
    // submerged in-scatter read ONE lobe, and no second pow() is paid.
    // (MIRROR of composite1.fsh)
    float phaseW = phaseU;
#else
    // Water HG phase (g = 0.58), never the dusk-boosted air one.
    float gPW = 0.58;
    float phaseW = (1.0 - gPW * gPW) / (12.566 * pow(1.0 + gPW * gPW - 2.0 * gPW * cosT, 1.5));
#endif
    // World-space march step, for the sub-sampling of the caustic field.
    vec3 wStepU = mat3(gbufferModelViewInverse) * stepV;
    // Ray entry into the water: 0 with the eye submerged (a diver's look is
    // unchanged), otherwise the first submerged step. Turns
    // UW_SHAFT_RENDER_DIST into a WATER-PATH limit, not a camera one.
    float uwEntryT = (isEyeInWater == 1) ? 0.0 : -1.0;
#endif
#if PERF_VL_ADAPTIVE == 1
    for (int i = 0; i < vlN; i++) {   // B5: effective count (see dt above)
#else
    for (int i = 0; i < VL_SAMPLES; i++) {
#endif
        p += stepV;
        vec3 wp = mat3(gbufferModelViewInverse) * p + cameraPosition;

        // Submerged segment: either the eye IS in water, or this ray point is
        // BEHIND a water surface seen from outside (screen projection check).
        float uw = (isEyeInWater == 1) ? 1.0 : 0.0;
        // World Y of the water surface actually crossed by this march step.
        float uwSurfY = WATER_LEVEL;
        // Screen projection + colortex2 tap SHARED with the lava halo.
        vec2 puvS = vec2(-1.0);
        float matBS = 0.0;
        bool onScrS = false;
        if (isEyeInWater == 0) {
            vec4 pc = gbufferProjection * vec4(p, 1.0);
            puvS = ((pc.xy / pc.w) * 0.5 + 0.5) * TAAU_S; // TAAU: shared projection (VL water + lava halo)
            onScrS = (puvS.x > 0.0 && puvS.x < TAAU_S && puvS.y > 0.0 && puvS.y < TAAU_S);
            if (onScrS) matBS = texture2D(colortex2, puvS).b;
            vec2 puv = puvS;
            if (onScrS) {
                float matB = matBS;
                bool isWater = matB > 0.95;
                // Submerged-glass water proxy disabled (see reference march).
                bool isGlass = false;
                if (isWater || isGlass) {
                    vec3 wsv = toView(puv, texture2D(depthtex0, puv).r);
                    if (p.z < wsv.z) {
                        uw = isWater ? 1.0 : 0.55;
#if PIXEL_WATER_FIX == 1
                        // Real Y of the seen water surface replaces Y63 for
                        // god rays viewed from outside (no extra cost).
                        if (isWater) uwSurfY = (mat3(gbufferModelViewInverse) * wsv + cameraPosition).y;
#endif
                    }
                }
                // Submerged glass: areas below water level keep the shafts
                if (inGlassUW && uw < 0.5 && wp.y < WATER_LEVEL - 0.2) uw = 0.60;
            }
        }
        // Density split (VL_HALF_RES): densBase = every wMirror-INDEPENDENT
        // term, kUW = the submerged coefficient the receiver scales by
        // (1 - wMirror*0.85). MUST stay in sync with the VL_HALF_RES=0 term
        //   uw * 0.008 * (1.0 - wMirror * 0.85)
        // and with the wMirror export in the composite1 water branch.
        float densBase;
        float kUW = 0.0;
#ifdef DAWN_MIST_VOL_ACTIVE
        // Share of this step's density that IS dawn mist (MIRROR of
        // composite1): kept so the in-scatter below can give the mist its own
        // ambient weight. Declared at the same scope as densBase because the
        // consumer sits OUTSIDE the air / water branch. Stays 0 underwater.
        float dmAdd = 0.0;
#endif
        if (isEyeInWater == 1 || (inGlassUW && uw > 0.4)) {
            densBase = 0.026 * WATER_FOG_DENSITY * UW_DENSITY_BOOST;
            #ifdef UW_VOLUMETRICS
#if PIXEL_WATER_FIX == 1
            // Estimated local surface >= submerged eye (high-lake fix)
            float uwY = clamp((max(WATER_LEVEL, cameraPosition.y + 0.4) - wp.y) / 16.0, 0.0, 1.0);
#else
            float uwY = clamp((WATER_LEVEL - wp.y) / 16.0, 0.0, 1.0);
#endif
            densBase *= (0.6 + 0.9 * uwY);
            #endif
            // A march step ABOVE the surface returns to AIR density.
            float subVL = smoothstep(0.0, 0.4, max(WATER_LEVEL, cameraPosition.y + 0.4) - wp.y);
            densBase = mix(airDens, densBase, subVL);
        } else {
            // PATCHY fog: irregular drifting banks
#if DIMENSION_FX == 1
            // patchy has ONE consumer, the hfDens term below, and hfDens is
            // forced to 0.0 in the Nether (airDens block above), so the tap is
            // paid for a product that is identically zero. Folded into the same
            // uniform ternary: Overworld bit-identical (dimN = 0.0 -> the legacy
            // expression), Nether bit-identical too (0.0 * exp(...) * patchy ==
            // 0.0 for any patchy), one texture fetch per march step saved there.
            // (MIRROR of composite1, keep in sync)
            float patchy = (dimN > 0.5) ? 0.0 : 0.45 + 1.10 * vnoiseTex(wp.xz * 0.012 + frameTimeCounter * 0.015);
#else
            float patchy = 0.45 + 1.10 * vnoiseTex(wp.xz * 0.012 + frameTimeCounter * 0.015);
#endif
#if DIMENSION_FX == 1 && NETHER_VOLUMETRIC == 1
            // NETHER_VOLUMETRIC (MIRROR of composite1): the Nether air
            // density rolls through the animated smoke field
            // (lib/dimension.glsl netherFogNoise, mean 1.0 -> same average
            // transmittance); the shared Beer-Lambert step makes the ambient
            // in-scatter follow the same pockets, so the sheets read
            // everywhere and the lava columns pierce them brighter. Exactly
            // airDens outside the Nether (dimN = 0.0).
            float dimAirD = (dimN > 0.5) ? airDens * netherFogNoise(wp, frameTimeCounter) : airDens;
#else
            float dimAirD = airDens;
#endif
            densBase = dimAirD + hfDens * exp(-max(wp.y - WATER_LEVEL, 0.0) * 0.025 / HEIGHT_FOG_FALLOFF) * patchy;
            kUW = uw * 0.008;
#ifdef END_STORM_ACTIVE
            // End haze altitude profile (MIRROR of composite1)
            if (dimE > 0.5) densBase += airDens * (endHazeProfile(wp.y) - 1.0);
#endif
            // Mist sheet just above the water, at dawn and dusk
            #ifdef SEALEVEL_MIST
#if DIMENSION_FX == 1
            // EXPLICIT dimensional lock (MIRROR of composite1): the mist no
            // longer relies on duskF = 0 (vanilla frozen suns) to vanish in the
            // Nether / End - it carries the same dimN/dimE weight as every
            // neighbouring term. Both factors are exactly 1.0 in the Overworld,
            // so the render there is bit-identical.
            densBase += exp(-abs(wp.y - (WATER_LEVEL + 1.3)) * 0.55) * duskF * 0.012 * HEIGHT_FOG_DENSITY
                      * (0.3 + 0.7 * vnoiseTex(wp.xz * 0.025 + frameTimeCounter * 0.02))
                      * (1.0 - dimN) * (1.0 - dimE);
#else
            densBase += exp(-abs(wp.y - (WATER_LEVEL + 1.3)) * 0.55) * duskF * 0.012 * HEIGHT_FOG_DENSITY
                      * (0.3 + 0.7 * vnoiseTex(wp.xz * 0.025 + frameTimeCounter * 0.02));
#endif
            #endif
            // DAWN MIST as a REAL medium (DAWN_MIST_VOL): one more per-step
            // density term, exactly like the SEALEVEL_MIST sheet above, so
            // it inherits the per-step shadow taps, the cloud shadows, the
            // phase and the dither of this march -- banks carved by trees
            // and hills instead of a flat veil. (1 - uw): no dawn mist
            // inside a water column (uw goes to 1 as soon as the step sits
            // behind a water surface). An AIR term, hence wMirror-
            // INDEPENDENT -> it belongs to densBase, never to kUW.
            // (MIRROR of composite1, keep in sync)
#ifdef DAWN_MIST_VOL_ACTIVE
            if (dmOn) {
                dmAdd = dawnMistDens(wp, dmD0, dmAnchorY, dmK, dmT,
                                     dmPatchy) * (1.0 - uw);
                densBase += dmAdd;
            }
#endif
            // Precipitation: downward-animated rain filaments in the shafts
            #ifdef VL_RAIN
#if DIMENSION_FX == 1
            // Vanilla syncs the global rain state into every dimension
            // (the Nether / End level data derive from the Overworld's):
            // no rain filaments inside the dimensional fog. Uniform
            // branch, exact legacy test in the Overworld.
            // (MIRROR of composite1)
            if (rainStrength > 0.01 && dimN < 0.5 && dimE < 0.5) {
#else
            if (rainStrength > 0.01) {
#endif
                vec3 rp3 = vec3(wp.x * 3.5 + wp.z * 3.5,
                                wp.y * 0.05 - frameTimeCounter * 5.0,
                                wp.x * 2.1 - wp.z * 2.1);
                float rn = vnoise3(rp3);
                densBase += rainStrength * smoothstep(0.80, 0.94, rn) * 0.0028;
            }
            #endif
        }

        // Sun visibility (cast shadows in the haze, stained glass colors)
        vec3 vis = vec3(1.0);
#if UW_SUN_COHERENT == 1
        // ---- UW_SUN_COHERENT: SUBMERGED shadow probe ----
        // (MIRROR of composite1.fsh, keep in sync)
        // The shadow map is an AIR structure: sampled at a submerged step it
        // answers "is the star visible from here ALONG THE AIR RAY?", so the
        // light/dark bands it carves into the beam tilt at theta_air (70 deg
        // for a 20-deg sun) while the beam rides the 44.8-deg refracted ray.
        // Two directional structures 25 deg apart, multiplied together: that is
        // the shaft system that visibly does not follow the sun.
        // The light landing on this step crossed the surface at ONE point, and
        // it is THAT point's air occlusion that decides the beam: probe there,
        // with the same wLev the shaft term uses and the same refracted slide.
        // Zero extra taps. Trade-off, deliberate: an occluder BETWEEN the step
        // and the surface no longer shadows the beam (it used to, at the wrong
        // angle), and the two probes only separate as the column grows.
        // AIR steps keep the EXACT legacy call; the mat3 is paid on submerged
        // steps only, and it is used instead of (wp - cameraPosition) because
        // that subtraction cancels significant digits far from spawn.
        vec3 sc;
#if UW_SHAFT_FIX3 == 1
        // ---- UW_SHAFT_FIX3 (B): the probe comes back TO THE STEP ----
        // (MIRROR of composite1.fsh, keep in sync)
        // The surface probe below only existed because the beam rode an axis
        // the shadow map does not know. It no longer does (A), so the shadow
        // map's own bands ARE the beam's bands when read AT the step: one
        // structure instead of two multiplied together.
        // That is the whole of symptom (B): the PLAYER is rasterized into the
        // shadow map (shadowEntities / shadowPlayer), and so is every submerged
        // wreck, hull and coral head. Probing at the step tests them; probing
        // at the surface crossing point could NOT, by construction -- the
        // segment between the step and the surface was never sampled, which is
        // why the beams went through the diver. The dark notch this cuts is now
        // the SAME OBJECT as the shadow he casts on the floor.
        // It also removes the (C) half of that probe: the slide pushed the tap
        // up to 1.42x the column length away from the step, i.e. out of the
        // shadow map, where the fog fail-open relit the beam.
        // Cost: NEGATIVE -- the exact legacy call, minus the mat3 and the
        // divide the surface probe paid on every submerged step.
        sc = toShadowClip(p, vec3(0.0));
#else
        if (uw > 0.25 && lightW.y > 0.05) {
#if PIXEL_WATER_FIX == 1
            float wLevV = (isEyeInWater == 1) ? max(WATER_LEVEL, cameraPosition.y + 0.4) : uwSurfY;
#else
            float wLevV = (isEyeInWater == 1) ? max(WATER_LEVEL, cameraPosition.y + 0.4) : WATER_LEVEL;
#endif
            float toSurfV = max(wLevV - wp.y, 0.0);
            // uwLightW.xz / uwLightW.y * depth is the caustic slide under BOTH
            // generations (vlCa4Offset with CAUSTICS_V4 on, the raw v3 cprjOff
            // with it off -- uwLightW falls back to that slope):
            // the probe lands on the very texel the caustic lookup reads.
            vec2 slideV = uwLightW.xz * (toSurfV / uwLightW.y);
            sc = toShadowClipWorld(mat3(gbufferModelViewInverse) * p
                                   + vec3(slideV.x, toSurfV, slideV.y));
        } else {
            sc = toShadowClip(p, vec3(0.0));
        }
#endif
#else
        vec3 sc = toShadowClip(p, vec3(0.0));
#endif
        float f = getDistortFactor(sc.xy);
        vec3 sp = distortShadow(sc, f) * 0.5 + 0.5;
        // ---- UW_SHAFT_FIX3 (C): does this probe have any DATA? ----
        // (MIRROR of composite1.fsh, keep in sync)
        // Declared in the COMMON trunk, before the #if that fills it: the
        // consumer is the beam term far below. 1.0 = the probe answered from
        // real shadow-map data. The two fail-open cases below (outside the map,
        // past the frustum Z) are RIGHT for the fog and are a LIGHT LEAK on the
        // beam -- the sun claimed at full strength precisely where nothing is
        // known about occlusion. Weights the underwater beam ONLY.
        float shOK = 1.0;
#if UW_SHAFT_FIX3 == 1
        shOK = 0.0; // no tap at all -> no claimed sunlight
#endif
        if (sp.x > 0.0 && sp.x < 1.0 && sp.y > 0.0 && sp.y < 1.0) {
            float zb = sp.z - 0.0008 * (VLX_SHADOW_ZSCALE * 2.0); // constant world-space bias
            float s1 = step(zb, texture2D(shadowtex1, sp.xy).r);
            // z0G hoisted out of the step(): WCOL_V3 prices the VOLUMETRIC light
            // leg from the RAW depth of the translucent blocker, like
            // sampleShadowPCF does for the surface one. No extra tap.
            float z0G = texture2D(shadowtex0, sp.xy).r;
            float s0 = step(zb, z0G);
            vec3 c = vec3(1.0);
#if SHADOW_TEX1_GATE_FIX == 1
            // RGB tag bands: mirror of the receiver in lighting.glsl and of the
            // reference march; encoding documented in shadow.fsh.
            // WCOL_V3 (MIRROR of composite1.fsh): the WATER band is a
            // TRANSMITTANCE now, not an albedo read as a tint - the reference
            // march carries the measurement (the decoded tag was 3.77x darker
            // and 4.2x bluer than the light the same beam deposits on the floor
            // it lights, at every depth, because the tag is constant). The
            // thickness is read from the SAME biased zb the tap already holds,
            // exactly as waterAboveShadow does with its own 0.0009.
            if (s0 < s1) {
                vec4 scG = texture2D(shadowcolor0, sp.xy);
                float tagMxG = max(max(scG.r, scG.g), scG.b);
#if WCOL_V3 == 1
                if (tagMxG < 0.325)      c = vlxWaterShadowT(zb - z0G);
#else
                if (tagMxG < 0.325)      c = clamp(scG.rgb / 0.30, 0.0, 1.0);
#endif
                else if (tagMxG < 0.675) c = clamp((scG.rgb - 0.35) / 0.30, 0.0, 1.0);
                else s1 = 0.0;
            }
#else
            if (s0 < s1) c = texture2D(shadowcolor0, sp.xy).rgb;
#endif
            vis = vec3(s1) * mix(c, vec3(1.0), s0);
            // Beyond the shadow frustum Z range: fail-open.
            vis = mix(vis, vec3(1.0), step(1.0, zb));
#if UW_SHAFT_FIX3 == 1
            // ---- UW_SHAFT_FIX3 (C): validity of THIS tap ----
            // (MIRROR of composite1.fsh, keep in sync)
            // Same two data-free cases as the line above, read as a weight
            // instead of as light: 0 past the frustum Z, and a smooth ramp over
            // the last 0.02 of the DISTORTED map.
            // WHY 0.02 -- DERIVED ON THE EXACT ACTIVE DISTORTION, not
            // linearised: 1 - sp = 0.02 means u = sc/f = 0.96, so the ramp
            // spans (1 - h(0.96)) * shadowDistance with h the inverse curve
            // of lib/distort.glsl. Plateau curve (SHADOW_LOD_V2 1, shipped),
            // default L2/R0: 31.5 / 32.1 / 37.0 / 48.8 blocks at
            // SHADOW_QUALITY 0/1/2/3 (64-couple span: 15.2, L0/R0 at SQ0, to
            // 122.7, L2/R3 at SQ3); legacy curve (S = 0.90): 37.6 / 56.5 /
            // 75.3 / 112.9.
            // CRITERION: the ramp must be at least as wide as the widest
            // feature the beam draws or it cuts a hard ring across the shafts.
            // causticShaftMask draws 3-6 block blades spaced 4-10
            // (lib/water.glsl:887-888), 2-4 block shafts separated by 10-20 of
            // penumbra at the shipped UW_SHAFT_FINESSE: the narrowest couple
            // (15.2 blocks) clears the 6-block blades everywhere. COST at the
            // end of the march (default L2/R0): shOK 1.00 at marchEnd 160 /
            // SQ1 (legacy paid 0.818); at UW_RAY_DISTANCE 128 / SQ0 (VQ3
            // re-stage) the ray ends exactly at the map's world span, so
            // shOK dissolves to 0 over the march's last ~31 blocks (pre-VQ3
            // range 112 paid 0.47; legacy curve 0.537).
            // Full derivation in composite1.fsh at the mirrored site.
            shOK = (1.0 - step(1.0, zb))
                 * smoothstep(0.0, 0.02, min(min(sp.x, 1.0 - sp.x),
                                             min(sp.y, 1.0 - sp.y)));
#endif
        }

        // Clouds above shade the haze (sky/ground consistency)
        #ifdef VOLUMETRIC_CLOUDS
        #ifdef VC_GROUND_SHADOWS
#ifdef CLOUD_SHAFTS_ACTIVE
                // ---- CLOUD_SHAFTS : ombre des nuages PAR PAS ----
                // (MIRRORED in lib/vl_halfres.glsl -- blocs textuellement
                // identiques, diff obligatoire)
                // Les 2 sondes csA/csB interpolees lineairement ne pouvaient
                // dessiner aucune structure LE LONG du rayon -- et en
                // fabriquaient une FAUSSE en travers. MESURE (marche 0-160 b,
                // ombre pure, phase retiree) : a 10 et 45 deg de soleil leur
                // ecart-type vaut 0.0933 / 0.0809 contre 0.0093 / 0.0218 pour
                // la meme marche prise pas a pas avec le proxy exact -- 10 a 4
                // fois TROP de "structure", parce que ce sont deux silhouettes
                // de nuage tamponnees sur le ciel. Un tap bilineaire de la
                // carte cuite par prepare2 remplace la paire, AU PAS COURANT,
                // et restitue 96.6 a 99.5 % de l'amplitude de structure de
                // la reference SANS grille (proxy exact au point projete),
                // sur les 8 des 9 vues (3 hauteurs de soleil x 3 azimuts,
                // champ de vue entier) qui portent une structure -- la 9e
                // est un ciel uniforme des DEUX cotes. Biais de moyenne
                // nul a 1e-4 pres, 0.00 % du poids hors carte.
                // ctmShadow n'a PAS de sunUpF : a 1/2/3 deg de soleil les
                // sondes rendaient 1.000 (aucune ombre du tout) ; ici la
                // visibilite moyenne tombe a 0.989 / 0.987 / 0.560. C'est
                // exactement la demande du createur. Le fondu au ras de
                // l'horizon reste porte par lightUp, plus bas.
                // Cout : 1 tap bilineaire d'un R8 de 1 MiB par pas, contre
                // 2 evaluations completes du champ (~2 taps + ~40 ALU + un
                // pow() chacune) par rayon.
                vis *= ctmShadow(wp, lightW, CLOUD_SHADOW_DARKNESS);
#else
#if PERF_VL_ADAPTIVE == 1
            // B5: index -> ray-fraction over the EFFECTIVE count (MIRROR of
            // composite1), so the two probes still span [0, marchEnd].
            vis *= mix(csA, csB, clamp((float(i) + 0.5) / float(vlN), 0.0, 1.0));
#else
            vis *= mix(csA, csB, clamp((float(i) + 0.5) / float(VL_SAMPLES), 0.0, 1.0));
#endif
#endif
        #endif
        #endif

        // Underwater ambient is near zero (directional shafts); eye outside,
        // the water column DIFFUSES sky light in blue-green (reference notes).
        float eyeDry = (isEyeInWater == 1 || inGlassUW) ? 0.0 : 1.0;
#if UW_SHAFTS_UNIFIED == 1
        // MIRROR of composite1: the eye-dry 0.15 was ALSO paying, implicitly,
        // for the direct light a submerged step loses when the eye is dry --
        // the stated reason for keeping the beam PEDESTAL out of the out-gain.
        // (d3)/(d4) below now carry that half explicitly, so this ambient goes
        // back to its own job (sky diffusion in the column, never black water)
        // at about half the weight; compensating twice would wash the distant
        // column out. UW_SHAFTS_UNIFIED 0 keeps 0.15.
        float ambM = (uw > 0.25) ? mix(0.008, 0.08, eyeDry) : 0.22;
#else
        float ambM = (uw > 0.25) ? mix(0.008, 0.15, eyeDry) : 0.22;
#endif
#ifdef DAWN_MIST_VOL_ACTIVE
        // RADIANCE continuity with the analytic tail (MIRROR of composite1):
        // blend the ambient weight toward DAWN_MIST_AMB in proportion to the
        // mist's share of this step, so the marched mist is no longer 4-5x
        // darker than the tail that continues it past 160 blocks. Denominator:
        // densBase + kUW is the Hi endpoint (wMirror = 0) -- wMirror is not
        // known in this pass, and kUW = uw * 0.008 is negligible wherever
        // dmAdd is not (dmAdd carries a (1 - uw) factor), so the two paths
        // agree. Only the in-scatter changes; densBase is untouched.
        float dmShare = clamp(dmAdd / max(densBase + kUW, 1e-6), 0.0, 1.0);
        ambM = mix(ambM, DAWN_MIST_AMB, dmShare);
#endif
        vec3 ambTint = (uw > 0.25 && eyeDry > 0.5) ? vec3(0.42, 0.75, 0.80) : vec3(1.0);
#if UW_SUN_COHERENT == 1
        // ---- UW_SUN_COHERENT: phase of the GENERIC direct in-scatter ----
        // (MIRROR of composite1.fsh, keep in sync)
        // Same gate the shaft term uses: a submerged step reads the REFRACTED
        // lobe, an air step keeps its own (dusk boost included).
        float phaseD = (uw > 0.25) ? phaseU : phase;
#else
        float phaseD = phase;
#endif
#if UW_SHAFTS_UNIFIED == 1
        // ---- UNIFIED UNDERWATER BEAM (a): kill the SECOND shaft family ----
        // (MIRROR of composite1.fsh, keep in sync)
        // A submerged step used to get the generic direct in-scatter
        // lightC*vis*phase*lightUp -- an unmodulated beam family carved by the
        // shadow map alone -- AND, right below, the caustic shaft term: two
        // additive sun beams of comparable magnitude with different geometry.
        // The direct light of a submerged step is now carried by the single
        // beam term below, whose surface window is subW; uwDirW is its exact
        // complement, so the handover is continuous across the surface and
        // total once submerged. Air steps, a sunk star and UW_VOLUMETRICS off
        // all keep uwDirW = 1, i.e. the legacy term.
        float uwDirW = 1.0;
#ifdef UW_VOLUMETRICS
        if (uw > 0.25 && lightW.y > 0.05) {
#if UW_SURFACE_CLAMP == 1
#if PIXEL_WATER_FIX == 1
            float wLevD = (isEyeInWater == 1) ? max(WATER_LEVEL, cameraPosition.y + 0.4) : uwSurfY;
#else
            float wLevD = (isEyeInWater == 1) ? max(WATER_LEVEL, cameraPosition.y + 0.4) : WATER_LEVEL;
#endif
            uwDirW = 1.0 - smoothstep(0.0, 0.8, wLevD - wp.y);
#else
            uwDirW = 0.0; // no surface window in legacy clamp mode: subW is 1 there
#endif
            // Water entry of this ray; stays 0 when the eye is submerged.
            if (uwEntryT < 0.0) uwEntryT = length(p);
        }
#endif
        vec3 S = lightC * vis * phaseD * lightUp * uwDirW + ambC * ambM * ambTint;
#else
        vec3 S = lightC * vis * phaseD * lightUp + ambC * ambM * ambTint;
#endif
#if DIMENSION_FX == 1
        // Nether lava columns (MIRROR of composite1): height-map glow at this
        // step, same distorted shadow position as the visibility taps above.
        if (dimN > 0.5) S += lavaGlowAt(sp, f, lightWyN) * (0.30 * NETHER_VL);
#ifdef END_STORM_ACTIVE
        // End lightning in the haze (MIRROR of composite1): point light at
        // the bolt, soft inverse square, scaled by END_LIGHTNING_POWER like
        // the full-res march and the three other consumers of the dial.
        if (flE > 0.001) {
            vec3 tbE = bPE - wp;
            S += bCE * (flE * (1.2e4 * END_LIGHTNING_POWER) / (dot(tbE, tbE) + 2500.0));
        }
#endif
#endif
        // Caustic god-ray striations, computed PER MARCH STEP (uw > 0.25 gate,
        // NOT isEyeInWater: submerged steps of a bank ray get them too).
        #ifdef UW_VOLUMETRICS
        if (uw > 0.25 && lightW.y > 0.05) {
#if UW_SURFACE_CLAMP == 1
            // Anti-starburst (a): LOCAL surface level; the caustic term only
            // applies to the REALLY submerged segment (subW).
#if PIXEL_WATER_FIX == 1
            float wLev = (isEyeInWater == 1) ? max(WATER_LEVEL, cameraPosition.y + 0.4) : uwSurfY;
#else
            float wLev = (isEyeInWater == 1) ? max(WATER_LEVEL, cameraPosition.y + 0.4) : WATER_LEVEL;
#endif
            float toSurf = max(wLev - wp.y, 0.0);
            // 0.8 window: softer ENTER/EXIT fade right at the surface.
            float subW = smoothstep(0.0, 0.8, wLev - wp.y);
#else
            float toSurf = max(WATER_LEVEL - wp.y, 0.0);
            float subW = 1.0;
#endif
            // ---- UW_SHAFT_BOUND: render limit hoisted ABOVE the taps ----
            // (MIRROR of composite1.fsh, keep in sync)
            // Same fade as ever (0.7x..1.0x, submerged path under
            // UW_SHAFTS_UNIFIED, camera distance otherwise), computed BEFORE
            // the caustic taps so a step past the bound can SKIP them:
            // shaftFade is exactly 0 there and the filament term it multiplies
            // is exactly 0 whatever the taps would have returned. The fade
            // lives inside the paid zone -> no wall at the bound.
            float uwPathB = length(p);
#if PERF_OCEAN == 1
            // PERF_OCEAN (1): camera distance of the STEP, captured before
            // the submerged-path subtraction below. Consumed by the view
            // bound right after shaftFade and by the nSubU decay (2).
            // (MIRROR of composite1.fsh, keep in sync)
            float uwCamB = uwPathB;
#endif
#if UW_SHAFTS_UNIFIED == 1
            uwPathB -= max(uwEntryT, 0.0);
#endif
            float shaftFade = 1.0 - smoothstep(UW_SHAFT_RENDER_DIST * 0.7, UW_SHAFT_RENDER_DIST, uwPathB);
#if PERF_OCEAN == 1
            // PERF_OCEAN (1): seen from the bank the filaments ALSO die by
            // CAMERA distance -- a 0.3-block striation is ~2 px at
            // UW_SHAFT_VIEW_DIST 96 (see MESURE 4, lib/settings.glsl).
            // Honest cost: the filament term weighs ~2x the pedestal in
            // the beam bracket (outGU already doubles the step amplitude
            // by construction), so this fade removes ~2/3 of the beam
            // luminosity over 69..96 blocks -- a few % of a grazing ocean
            // pixel's luminance, with NO discontinuity (continuous fade,
            // and 96 = 12*dt at VOLUMETRIC_QUALITY 3 so the skip frontier
            // lands on a whole step index). Multiplying shaftFade keeps
            // the existing shaftFade > 0 skip (UW_SHAFT_BOUND) as the REAL
            // early-out past the bound, filament term only (the pedestal
            // UW_SHAFT_BASE and the fog continue, as with the path bound).
            // A diver (isEyeInWater == 1) keeps the pure path bound.
            // (MIRROR of composite1.fsh, keep in sync)
            if (isEyeInWater == 0)
                shaftFade *= 1.0 - smoothstep(UW_SHAFT_VIEW_DIST * 0.72, UW_SHAFT_VIEW_DIST, uwCamB);
#endif
            // PER-STEP projection along the sun/moon axis: columns parallel to
            // that axis by construction. Under CAUSTICS_V4 the axis is the
            // REFRACTED ray (Snell, 48.6 deg cone) and is shared with the fine
            // net; the v3 path keeps the raw projection its own floor sites
            // use. MIRROR of composite1.fsh - keep in sync.
            // UW_SUN_COHERENT deliberately does NOT touch this v3 line: the v3
            // FLOOR sites slide the same raw way, so refracting the column
            // alone would separate the beam from the spot it lights.
            vec2 cprjOff = lightW.xz / max(lightW.y, 0.15) * toSurf;
#if UW_SHAFT_FIX3 == 1
            // ---- UW_SHAFT_FIX3 (A): THE anchor that sets the axis ----
            // (MIRROR of composite1.fsh, keep in sync)
            // cprj is CONSTANT along the direction it slides, so the columns
            // are parallel to that direction by construction -- this is the
            // term the eye reads as "the direction of the shafts".
            // vlCa4Offset slid it along the Snell ray: a beam at 44.81 deg
            // beside a shadow at 70.00 deg for a 20-deg sun. uwShaftSlide is
            // the SHADOW MAP projection of a vertical drop, and it IS the v3
            // expression on the line above, floor included -- not a new
            // constant. The three CAUSTICS_V4 floor sites in composite1 move
            // with it, so a beam still lands on the spot it lights.
            cprjOff = uwShaftSlide(lightW, toSurf);
#elif CAUSTICS_V4 == 1
            cprjOff = vlCa4Offset(lightW, toSurf);
#endif
            vec2 cprj = wp.xz + cprjOff;
#if UW_GODRAY_CAUSTIC_LOCK == 1
            float beerR = exp(-toSurf * 0.06); // extended range
#else
            float beerR = exp(-toSurf * 0.07); // legacy LOCK=0 extinction
#endif
            // Phase and tint DEDICATED to the striation term -- declared HERE,
            // in the COMMON trunk. #if trap: used after the LOCK #endif, so
            // they must never be declared inside a gated block.
            // phaseD is `phase` when UW_SUN_COHERENT is 0 and the refracted
            // lobe otherwise; this block only runs inside the uw > 0.25 gate.
            float phaseShaft = phaseD;
            vec3 teinteShaft = vec3(0.80, 1.0, 0.94);
#if UW_GODRAY_CAUSTIC_LOCK == 1
            // The shaft pattern IS the projected caustic (fine striations x
            // wide sheaves); see the reference march for the full rationale.
#if UW_SHAFTS_UNIFIED == 1 && CAUSTICS_V4 == 1
            // ---- UNIFIED UNDERWATER BEAM (b): SUB-SAMPLED wavefront ----
            // (MIRROR of composite1.fsh, keep in sync)
            // Same field, same shaping and the same SHARED Snell lookup as the
            // reference branch below (under v4 cprjOff IS vlCa4Offset); the
            // only difference is that the step is BOX-AVERAGED instead of
            // point-sampled, because seen from the bank the march is bounded by
            // the OPAQUE floor and a whole water column can fall inside one
            // step. nSubU = 1 lands exactly on wp, i.e. on the reference
            // expression, and a submerged eye always takes that single tap.
            // TAP COUNT follows the STEP LENGTH (MIRROR of composite1): the
            // aliasing these taps fix scales with the column one step spans,
            // and dt is 5 blocks at VOLUMETRIC_QUALITY 3 (VQ3 re-stage)
            // against 20-40 at quality 0/1. One tap per ~4 blocks, capped by
            // the dial. Float
            // clamp then cast: the integer overloads of clamp are GLSL 1.30+
            // and this file is included by a #version 120 pass.
            int nSubU = (isEyeInWater == 0)
                      ? int(clamp(floor(dt / 4.0) + 1.0, 1.0, float(UW_SHAFT_SUBSTEPS)))
                      : 1;
#if PERF_OCEAN == 1
            // PERF_OCEAN (2): the box average exists for aliasing where the
            // filaments are RESOLVED on screen -- decay the tap count with
            // the step's camera distance. Window ALIGNED BEHIND the
            // amplitude fade (1): full budget below
            // max(0.55 * UW_SHAFT_VIEW_DIST, 30) = ~53 blocks (steps there
            // are bit-identical), taps only start dropping once the
            // filament amplitude is itself falling (fade starts at 0.72x),
            // so the added estimator variance lands where the signal is
            // already dimming -- the single tap still lands exactly on wp,
            // i.e. on the reference expression. int(x + 0.5) rounds
            // (x >= 0). The skip stays wavefront-granular (SIMD pays the
            // max nSubU of the lanes; thresholds are not multiples of dt).
            // (MIRROR of composite1.fsh, keep in sync)
            if (isEyeInWater == 0 && nSubU > 1) {
                float subKU = 1.0 - smoothstep(max(UW_SHAFT_VIEW_DIST * 0.55, 30.0),
                                               max(UW_SHAFT_VIEW_DIST * 0.95, 60.0), uwCamB);
                nSubU = 1 + int(float(nSubU - 1) * subKU + 0.5);
            }
#endif
            float caAccU = 0.0;
            float wAccU = 0.0;
            // UW_SHAFT_BOUND (MIRROR of composite1): past the render limit the
            // whole box average is skipped (caShaft falls to 0 through the
            // wAccU guard); its term is multiplied by shaftFade == 0 anyway.
#if UW_SHAFT_BOUND == 1
            if (shaftFade > 0.0)
#endif
            for (int ks = 0; ks < UW_SHAFT_SUBSTEPS; ks++) {
                if (ks >= nSubU) break;
                vec3 wpU = wp + wStepU * ((float(ks) + 0.5) / float(nSubU) - 0.5);
#if UW_SURFACE_CLAMP == 1
                float toSurfU = max(wLev - wpU.y, 0.0);
                // PER-TAP surface window, same curve as subW: the box sweeps
                // +-dt/2 around the step centre, so a tap can land ABOVE the
                // surface, exactly where the field is sharpest and strongest --
                // what the anti-starburst clamp forbids everywhere else. The
                // weight is renormalised out below. nSubU == 1 keeps weight 1.
                float wSubU = (nSubU > 1) ? smoothstep(0.0, 0.8, wLev - wpU.y) : 1.0;
#else
                float toSurfU = max(WATER_LEVEL - wpU.y, 0.0);
                float wSubU = (nSubU > 1) ? smoothstep(0.0, 0.8, WATER_LEVEL - wpU.y) : 1.0;
#endif
                float shrpU = clamp(1.0 - toSurfU / 45.0, 0.20, 1.0);
                // (A) same anchor as cprj above, per sub-tap.
                // (MIRROR of composite1.fsh, keep in sync)
#if UW_SHAFT_FIX3 == 1
                vec2 lookU = wpU.xz + uwShaftSlide(lightW, toSurfU);
#else
                vec2 lookU = wpU.xz + vlCa4Offset(lightW, toSurfU);
#endif
#if VLX_PHYS_SYNC == 1
                // PHYSICS_FIELD_SYNC, PUITS DE LUMIERE (sous-tap du box
                // average). Le pas n'a pas d'estampille (il est dans le
                // volume, pas sur la surface) : meme regle ambiante que le
                // site immerge, plus le test d'altitude sur la nappe a
                // laquelle CE tap se projette. causticShaftMask lit lookU
                // BRUT (aucun VL_CA5_REG) -> reg 0 ; vlCa4Vol lit la meme
                // position moins le REG -> on le lui rend.
                // (MIRROR of composite1.fsh, keep in sync)
                bool vlxPhU = vlxPhysAmb && abs((wpU.y + toSurfU) - WATER_LEVEL) < 1.5;
                VLX_PHYS_SET(vlxPhU, vlxPhysAmbWav, 0.0);
#endif
                float caWideU = causticShaftMask(lookU, frameTimeCounter, toSurfU);
#if VLX_PHYS_SYNC == 1
                VLX_PHYS_SET(vlxPhU, vlxPhysAmbWav, VL_CA5_REG(wpU.y + toSurfU));
#endif
                // CA5 registration: wpU.y + toSurfU IS the sheet altitude
                // this tap projects to (VL_CA5_REG is 0.0 under v4).
                float caFineU = vlCa4Vol(lookU - VL_CA5_REG(wpU.y + toSurfU),
                                         frameTimeCounter, shrpU, lightW);
                float fineU = clamp((caFineU - 0.42) * 1.45, 0.0, 1.5);
                float openU = fineU * (0.38 + 0.62 * caWideU);
                float gmaU = mix(1.30, 1.10, clamp(toSurfU * 0.045, 0.0, 1.0));
                caAccU += wSubU * clamp(0.02 + 2.9 * pow(clamp(openU, 0.0, 1.3), gmaU), 0.0, 3.0);
                wAccU += wSubU;
            }
            // caAccU <= 3 * wAccU, so the guard can only return 0 when every
            // tap is emerged -- a step whose own subW already fades the beam.
            float caShaft = caAccU / max(wAccU, 1e-4);
            // The flat 0.22 floor of the legacy mix moves to UW_SHAFT_BASE (ONE
            // pedestal, not two): UW_GODRAY_DIRECTIONAL is now purely contrast.
            float caDir = caShaft * UW_GODRAY_DIRECTIONAL;
#else
            // UW_SHAFT_BOUND (MIRROR of composite1): past the render limit the
            // point-sample of the field is not paid; caDir = 0 meets
            // shaftFade == 0 in the S term, so the skip changes no pixel.
            float caDir = 0.0;
#if UW_SHAFT_BOUND == 1
            if (shaftFade > 0.0)
#endif
            {
#if VLX_PHYS_SYNC == 1
            // PHYSICS_FIELD_SYNC, PUITS DE LUMIERE (branche point-sample) :
            // meme regle que la branche box-average ci-dessus.
            // (MIRROR of composite1.fsh, keep in sync)
            bool vlxPhS = vlxPhysAmb && abs((wp.y + toSurf) - WATER_LEVEL) < 1.5;
            VLX_PHYS_SET(vlxPhS, vlxPhysAmbWav, 0.0);
#endif
            float caWide = causticShaftMask(cprj, frameTimeCounter, toSurf);
            float shrpU = clamp(1.0 - toSurf / 45.0, 0.20, 1.0);
#if CAUSTICS_V4 == 1
#if VLX_PHYS_SYNC == 1
            // VL_CA5_REG n'existe QUE sous CAUSTICS_V4 == 1 (bloc v4 de
            // lib/water.glsl) : le SET qui le porte doit vivre ici, pas
            // au-dessus du #if. Sous CAUSTICS_V4 == 0 les striations fines
            // restent causticSmall, le champ du pack, et seules les gerbes
            // larges suivent le mod - documente.
            VLX_PHYS_SET(vlxPhS, vlxPhysAmbWav, VL_CA5_REG(wp.y + toSurf));
#endif
            // MIRROR of composite1: the fine striations ARE the photon-density
            // net (lib/water.glsl), read at the same world lookup as the floor
            // sites (projected along the REFRACTED sun ray) - cprj carries that
            // slide under v4, so the sheaves and the net cannot drift apart.
            // CA5 registration: wp.y + toSurf IS the sheet altitude cprj
            // projects to (VL_CA5_REG is 0.0 under v4).
            float caFine = vlCa4Vol(cprj - VL_CA5_REG(wp.y + toSurf),
                                    frameTimeCounter, shrpU, lightW);
#else
            float caFine = causticSmall(cprj, frameTimeCounter, shrpU);
#endif
            // Subtract the flat base (0.42): REAL penumbra between striations.
            float fineM = clamp((caFine - 0.42) * 1.45, 0.0, 1.5);
            float caOpen = fineM * (0.38 + 0.62 * caWide);
            float gmaD = mix(1.30, 1.10, clamp(toSurf * 0.045, 0.0, 1.0));
            float caShaft = clamp(0.02 + 2.9 * pow(clamp(caOpen, 0.0, 1.3), gmaD), 0.0, 3.0);
            caDir = mix(0.22, caShaft, UW_GODRAY_DIRECTIONAL);
            }
#endif
            // Isotropic floor for the STRIATION TERM ONLY (readable facing away).
#if UW_SHAFTS_UNIFIED == 1
            // (c) side-independent phase: the WATER HG (g = 0.58) whatever the
            // camera does; identical to `phase` with the eye submerged.
            phaseShaft = mix(phaseW, 0.30, 0.35);
#else
            // UW_SUN_COHERENT folds into phaseD (refracted axis when on).
            phaseShaft = mix(phaseD, 0.30, 0.35);
#endif
            // Golden surface tint cooling to cyan-green at depth.
            vec3 shChroma = min(gLightC / max(luma(gLightC), 1e-3), vec3(2.0));
            teinteShaft = mix(vec3(0.80, 1.0, 0.94), shChroma,
                              0.45 * clamp(1.0 - toSurf / 20.0, 0.0, 1.0));
#else
            // UW_SHAFT_BOUND (MIRROR of composite1): the legacy blades pay
            // waveCausticFull per step; past the render limit the whole term
            // is multiplied by shaftFade == 0, so the field is skipped too.
            float caDir = 0.0;
#if UW_SHAFT_BOUND == 1
            if (shaftFade > 0.0)
#endif
            {
            vec2 caF = waveCausticFull(cprj, frameTimeCounter, toSurf);
            float caLarge = caF.y;
            float caSmall = clamp(caF.x - 0.20, 0.0, 1.0);
            float caM = clamp((0.35 + 0.65 * caLarge) * (0.4 + 1.1 * caSmall), 0.0, 1.5);
            // Light blades ALIGNED on the sun/moon axis (degeneracy-guarded).
#if UW_SUN_COHERENT == 1
            // LOCK == 0 legacy blades, on the ONE refracted axis like every
            // other underwater term (uwLightW is already unit).
            vec3 Ldir = uwLightW;
#else
            vec3 Ldir = normalize(lightW);
#endif
            vec3 upRef = (abs(Ldir.y) > 0.95) ? vec3(1.0, 0.0, 0.0) : vec3(0.0, 1.0, 0.0);
            vec3 baxA = normalize(cross(Ldir, upRef));
            vec3 baxB = cross(Ldir, baxA);
            vec3 rel = wp - cameraPosition;
            float sa = dot(rel, baxA);
            float sb = dot(rel, baxB);
            float shaftDir = 0.55 + 0.45 * sin(sa * UW_GODRAY_TILT
                           + sin(sb * UW_GODRAY_TILT * 0.7) * 1.3
                           + frameTimeCounter * 0.25);
            caDir = caM * mix(1.0, shaftDir, UW_GODRAY_DIRECTIONAL);
            }
#endif
#if UW_SUNGAZE_SOFT == 1
            // Anti-starburst (b): fade the caustic modulation near the axis.
#if UW_SUN_COHERENT == 1
            // The columns converge on the REFRACTED axis, so that is where the
            // vanishing point sits and where the softening belongs. On the air
            // cosT it blurred empty water 25 deg away and left the real
            // starburst untouched. (MIRROR of composite1.fsh)
            float gazeW = smoothstep(0.955, 0.9985, cosTU);
#else
            float gazeW = smoothstep(0.955, 0.9985, cosT);
#endif
            caDir = mix(caDir, 0.55, gazeW * 0.75);
#endif
#if UW_SHAFTS_UNIFIED == 1
            // ---- UNIFIED UNDERWATER BEAM: the SINGLE additive term ----
            // (MIRROR of composite1.fsh, keep in sync)
            // (d1) render limit along the SUBMERGED path (uwEntryT = 0 with the
            //      eye in the water, so a diver keeps the legacy fade), and it
            //      still weights the CAUSTIC part only.
            // (d2) water light tint whatever the camera side, rebuilt from
            //      lightCraw -- the value BEFORE the eye-dry underground
            //      desaturation, a branch a diver never runs. Same value in the
            //      open air (skyExpo = 1.0).
            // (d3) out gain: the march weights the step with the step's OWN
            //      density, densBase + 0.008/block with a dry eye (the air haze
            //      is ~40% of that at the defaults, not negligible) against the
            //      water's ~0.026/block for the diver. The equalising gain is
            //      therefore the RATIO: UW_SHAFT_OUT_GAIN counts in units of
            //      0.008/block (3.0 ~= the water coefficient), divided by what
            //      the step really weighs. densBase excludes kUW on purpose ->
            //      wMirror-INDEPENDENT, so both stored endpoints agree and the
            //      grazing mirror keeps its tuned transmittance.
            // (d4) UW_SHAFT_BASE takes over from the generic in-scatter term
            //      removed by uwDirW, inside the SAME product, riding the true
            //      water HG (phaseW) and not the striation floor phaseShaft --
            //      that floor exists for the FILAMENTS and, on the pedestal,
            //      rescaled the diver's background light from x0.40 facing the
            //      sun to x4.25 with his back to it. 1.0 = the removed term as
            //      written. outGU multiplies the WHOLE bracket: on the caustic
            //      half alone it made the filament/background contrast exactly
            //      outGU times higher from the bank than from inside.
            // shaftFade: computed in the common trunk above (UW_SHAFT_BOUND
            // hoist), same submerged-path expression as before -- it also
            // gates the caustic taps now.
            vec3 lightCw = (isEyeInWater == 1 || inGlassUW) ? lightC : lightCraw * uwShaftTint;
            float outGU = (isEyeInWater == 1 || inGlassUW)
                        ? 1.0
                        : UW_SHAFT_OUT_GAIN * 0.008 / max(densBase + 0.008, 1e-6);
            // ---- UW_SHAFT_FIX3 (C): the beam claims no unknown light ----
            // (MIRROR of composite1.fsh, keep in sync)
            // shOK is the shadow probe validity (declared at the probe): 0
            // where the tap fell outside the shadow map or past its frustum Z,
            // i.e. where vis was failed OPEN for the fog. Right for haze, a
            // light leak on a beam -- the sun asserted at full strength exactly
            // where occlusion is unknown, which is how a wide shaft ends up
            // crossing solid terrain. The BEAM alone is weighted by it.
#if UW_SHAFT_FIX3 == 1
            vec3 visBeam = vis * shOK;
#else
            vec3 visBeam = vis;
#endif
#if UW_SHAFT_V4 == 1
            // ---- UW_SHAFT_V4 (C)+(D) (MIRROR of composite1.fsh) -----------
            // (C) Only ONE half of the bracket knew about depth: the filaments
            //     carry beerR, the PEDESTAL (the submerged direct light
            //     UW_SHAFT_BASE took over from the removed generic in-scatter,
            //     d4) carried nothing. At 30 blocks the filaments are at 16%
            //     and the pedestal still at 100%, so the deep column reads as
            //     ~80% flat glow with its structure dissolved out -- which a
            //     bank observer sees whole and a diver never does. Putting the
            //     pedestal on the filaments' OWN curve (no second extinction
            //     constant) makes the SHAPE of the bracket depth-independent:
            //     surface-to-30-blocks contrast 4.55:1 before, 16.45:1 after.
            // (D) beerR is achromatic, so the shipped beam keeps a frozen
            //     chroma at any depth (R/G = 0.800 at the surface and at 40
            //     blocks). Applied NORMALISED on the green so R and B can only
            //     darken: no invented luminance, ~15% lost at 20 blocks.
            // Eye-dry ONLY, by the branch: a diver stays bit-identical. The
            // factor is wMirror-INDEPENDENT, so both stored endpoints
            // (scatHi/scatLo) carry it and composite1's mix() stays exact.
            vec3 uwBeamK = vec3(1.0);
            float uwPed = UW_SHAFT_BASE;
            if (isEyeInWater == 0 && !inGlassUW) {
                uwPed *= mix(1.0, beerR, UW_SHAFT_PED_FALL);
                uwBeamK = vec3(exp(-toSurf * (UW_SHAFT_SPEC_KR * UW_SHAFT_SPECTRAL)),
                               1.0,
                               exp(-toSurf * (UW_SHAFT_SPEC_KB * UW_SHAFT_SPECTRAL)));
            }
            S += lightCw * visBeam * lightUp * subW * teinteShaft * outGU * uwBeamK
               * (phaseW * uwPed
                  + phaseShaft * caDir * beerR * 0.9 * UW_GODRAY_STRENGTH * shaftFade);
#else
            S += lightCw * visBeam * lightUp * subW * teinteShaft * outGU
               * (phaseW * UW_SHAFT_BASE
                  + phaseShaft * caDir * beerR * 0.9 * UW_GODRAY_STRENGTH * shaftFade);
#endif
#else
            // God-ray term ONLY, with the eye-distance render limit fade --
            // shaftFade computed in the common trunk above (UW_SHAFT_BOUND
            // hoist), camera distance in this legacy branch as before.
            // (C) see the UW_SHAFTS_UNIFIED == 1 branch above.
#if UW_SHAFT_FIX3 == 1
            vec3 visBeam = vis * shOK;
#else
            vec3 visBeam = vis;
#endif
            S += lightC * visBeam * phaseShaft * lightUp * caDir * beerR * 0.9 * UW_GODRAY_STRENGTH * subW
               * teinteShaft * shaftFade;
#endif
        }
        #endif
        // Dual-endpoint integration (see file header). kUW = 0 (eye in water /
        // pure air step) keeps both endpoints identical.
        float aHi = exp(-(densBase + kUW) * dt);
        float aLo = exp(-(densBase + kUW * 0.15) * dt);
        scatHi += transHi * S * (1.0 - aHi);
        scatLo += transLo * S * (1.0 - aLo);
        transHi *= aHi;
        transLo *= aLo;
        odUW += kUW * dt;
        // Slowest-decaying endpoint below 0.5% -> the rest of the march is
        // invisible for every wMirror (Hi decays even faster).
        if (transLo < 0.005) break;

        // Thermal halo of incandescent blocks (lava, fire, torches)
        #ifdef LAVA_ANIMATE
        // reuses the shared projection/tap from the top of the step (puvS/matBS)
        if (isEyeInWater == 0 && onScrS) {
            vec2 lvuv = puvS;
            {
                float matB = matBS;
                // Strict LAVA band around 0.58 (see reference march)
                if (matB > 0.55 && matB < 0.62) {
                    float lvd = texture2D(depthtex0, lvuv).r;
                    if (lvd < 1.0) {
                        float emDist = length(p - toView(lvuv, lvd));
                        vec3 lavaS = vec3(0.92, 0.36, 0.08) * exp(-emDist * 0.60)
                                   * 0.009 * LAVA_GLOW;
                        scatHi += lavaS * transHi;
                        scatLo += lavaS * transLo;
                    }
                }
            }
        }
        #endif

        #if defined VL_BLOCKLIGHT && (defined SS_LIGHTS || defined RTGI)
            vec4 fc = gbufferProjection * vec4(p, 1.0);
            vec2 fuv = ((fc.xy / fc.w) * 0.5 + 0.5) * TAAU_S; // TAAU: NDC -> sub-rect UV
            if (fuv.x > 0.0 && fuv.x < TAAU_S && fuv.y > 0.0 && fuv.y < TAAU_S) {
                float fd = texture2D(depthtex0, fuv).r;
                if (fd >= 1.0 || p.z > toView(fuv, fd).z) {
#if GI_HALF_RES == 1
                    // Half-res GI quadrant layout (1-frame-old colortex4 here:
                    // this pass writes it; fine for a temporally-smoothed fog).
                    blockFog += texture2D(colortex4,
                        min(fuv * 0.5, 0.5 * TAAU_S - 1.5 / vec2(viewWidth, viewHeight))).rgb;
#else
                    blockFog += texture2D(colortex4, fuv).rgb;
#endif
                }
            }
        #endif
    }
#ifdef SHAFT_FAR_ACTIVE
        // ---- CLOUD_SHAFTS (ROUND 2) : SEGMENT LOINTAIN ---------------------
        // (MIRRORED in lib/vl_halfres.glsl -- bloc textuellement IDENTIQUE,
        //  indentation comprise ; diff obligatoire. Le CORPS du segment vit
        //  dans vlShaftFar (lib/lighting.glsl) : SOURCE UNIQUE, donc il n'y a
        //  aucune arithmetique a tenir en phase entre les deux chemins.)
        // POURQUOI. La boucle ci-dessus s'arrete a marchEnd = min(distVol, 160)
        // et son milieu est airDens. Sans brouillard analytique (ATMO_FOG,
        // HEIGHT_FOG, DAWN_MIST, AERIAL_PERSPECTIVE eteints) plus rien n'existe
        // au-dela : MESURE, soleil 10 deg, bande d'horizon, en fraction de
        // lightC, l'amplitude des colonnes vaut 0.00453 face au soleil,
        // 0.00026 a 90 deg et 0.00001 DE DOS. Le segment lointain porte son
        // PROPRE milieu d'aerosols (SHAFT_TAU) et une phase melant le HG du
        // tronc et un terme Rayleigh (SHAFT_ISO) : au palier Naturel
        // l'amplitude des colonnes est multipliee par 1.3 face au soleil, 2.1 a
        // 90 deg et 34 DE DOS. Doc, constantes et mesures : bloc "ROUND 2 :
        // SEGMENT LOINTAIN" de lib/settings.glsl.
        // PORTEE. Pixel de ciel : SHAFT_FAR_END (= CTM_RANGE, la portee de la
        // carte, au-dela de laquelle il n'y a plus d'ombre a lire). Pixel
        // terrain ou LOD DH : min(distVol, SHAFT_FAR_END) -- la longueur du
        // segment croit donc CONTINUMENT depuis 0 quand distVol franchit
        // 160 blocs, il n'y a pas de couture au raccord.
        // OEIL SEC uniquement : sous l'eau ou derriere une base vitree le
        // milieu est l'eau, et la marche proche le traite deja.
        vec3 scatFar = vec3(0.0);
        if (isEyeInWater == 0 && !inGlassUW) {
#ifdef DISTANT_HORIZONS
            float farEndS = (d1v >= 1.0 && dhD1v >= 1.0) ? SHAFT_FAR_END
                                                         : min(distVol, SHAFT_FAR_END);
#else
            float farEndS = (d1v >= 1.0) ? SHAFT_FAR_END : min(distVol, SHAFT_FAR_END);
#endif
            scatFar = vlShaftFar(worldDir, lightW, lightC, phase, cosT, lightUp,
                                 marchEnd, farEndS, vlDither);
        }
#endif
#ifdef SHAFT_FAR_ACTIVE
        // Le segment est de l'AIR PUR au-dessus de toute colonne d'eau : il ne
        // depend pas de wMirror, donc la MEME valeur va aux DEUX points de
        // sortie, chacun avec sa propre transmittance -- le mix() de composite1
        // reste exact. transHi / transLo / odUW sont intacts : le segment
        // n'attenue rien (voir le site de composite1 et le bloc "ROUND 2").
        scatHi += scatFar * transHi;
        scatLo += scatFar * transLo;
#endif

    // VL_BLOCKLIGHT fold: additive on final color and wMirror/transF
    // independent -> baked into BOTH stored endpoints (mix() preserves it
    // exactly). The VL_HALF_RES=0 apply in composite1 is gated off.
    #if defined VL_BLOCKLIGHT && (defined SS_LIGHTS || defined RTGI)
#if PERF_VL_ADAPTIVE == 1
        blockFog /= float(vlN);   // B5: mean over the steps actually paid (MIRROR)
#else
        blockFog /= float(VL_SAMPLES);
#endif
        vec3 bfAdd = blockFog * (1.0 - exp(-marchEnd * 0.04)) * 0.30 * VL_BLOCK_STRENGTH;
        scatHi += bfAdd;
        scatLo += bfAdd;
    #endif

    outA = vec4(scatHi, transHi);
    outB = vec4(scatLo, odUW);
}

#endif
