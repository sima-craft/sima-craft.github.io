/*
    Procedural ocean: domain-warped choppy octaves for
    the wave field, plus fully analytic caustics derived from the same wave
    trains. Requires lib/common.glsl included first.
*/

/* ============ PHYSICS MOD PRO - CHAMP D'ONDE, PARAMETRES EXPLICITES ========
   PHYSICS_FIELD_SYNC (lib/settings.glsl). Reimplementation de la fonction
   d'onde de PHYSICS MOD PRO (auteur : Haubna, https://minecraftphysicsmod.com/,
   v185g) : MEME recurrence et MEMES constantes que physics_waveHeight de
   lib/physicsmod_ocean.glsl (la copie attribuee de l'include que le mod fournit
   pour etre embarque), mais a PARAMETRES EXPLICITES - l'original lit les UBO
   PhysicsOcean / PhysicsOceanChunk, que le mod ne lie qu'aux programmes ocean ;
   ici les memes valeurs arrivent par les globales vlxPhys*, remplies par
   composite1 depuis les images physOceanParams / physOceanPix
   (shaders.properties). C'est ce qui permet a composite1 d'echantillonner le
   champ du mod A UNE POSITION MONDE ARBITRAIRE, ce que la limite documentee en
   tete de physics_ocean_v2.fsh appelait "chantier futur".

   TROIS DIFFERENCES ASSUMEES avec l'original, toutes mesurees :
   1. DERIVEES ANALYTIQUES EN UNE PASSE. physics_waveHeight ne rend que la
      hauteur ; une pente par differences finies couterait 4 evaluations. Ici la
      boucle porte aussi J_i = dp_i/dp_0 (mise a jour de rang 1 par octave), donc
      la CHAINE DU DRAG (position -= force*0.048*adj) est derivee exactement.
      MESURE (pf_m1_grad.py, 3 patchs x 3 instants x 260^2 points) : erreur RMS
      contre les differences finies 0.012 % et correlation 1.000000, contre
      15.06 % / +0.9886 si l'on ignore la chaine du drag. Le critere de 5 % du
      cahier des charges REFUTE donc la version sans drag : elle n'est pas
      livree.
   2. NORMALISATION D'AMPLITUDE. Le facteur physics_oceanHeight * waviness *
      hscale se simplifie exactement entre la chaine de derivation et la
      renormalisation VLX_PHYS_K : la pente RENDUE ne depend que de la FORME du
      champ. C'est le contrat de l'estimateur de photons (dont toute la mise en
      forme - CA5_FLOOR/KNEE/ASYM/GAIN, CA5_VOL_A/B, le clamp +-3 du jacobien -
      est calee sur une statistique de pente donnee), et c'est aussi ce que fait
      deja le chemin du pack : CA5_NORM = 0.2275/WAVE3_STEEP annule exactement
      la pente du champ v3. Consequence assumee : une mer plate (waviness 0)
      garde des caustiques, exactement comme aujourd'hui avec le champ du pack.
      La waviness continue de FACONNER le champ par le terme de drag (adj).
   3. RIDES DU MOD ABSENTES. physics_wavePixel ajoute physics_ripples (sillages,
      impacts) a la hauteur ; cette texture n'est liee qu'aux programmes ocean
      et n'est pas publiable a cout raisonnable. Les caustiques suivent donc la
      HOULE du mod, pas ses sillages de bateau. Assume et documente.

   Pur ALU, aucun uniforme, aucune fonction 130+ : compile en 120
   (gbuffers_water.vsh, composite.fsh) comme en 430 (composite1.fsh). */
// VLX_PHYS_CONSUMER : pose par les DEUX seuls programmes qui lisent le champ
// republie (composite1.fsh et composite.fsh, pour lib/vl_halfres.glsl) juste
// avant d'inclure ce fichier. Sans lui, tout ce bloc disparait : les deux
// autres inclusions de water.glsl (program_water_vertex / _fragment, donc
// gbuffers_water et les wrappers physics) restent TEXTUELLEMENT inchangees et
// ne portent pas de code mort - le pack reste autonome au sens strict.
#if PHYSICS_MOD_SUPPORT == 1 && PHYSICS_FIELD_SYNC == 1 && defined VLX_PHYS_CONSUMER
    #define VLX_PHYS_SYNC 1
#else
    #define VLX_PHYS_SYNC 0
#endif

#if VLX_PHYS_SYNC == 1
// Constantes de la fonction d'onde du mod (memes valeurs que les PHYSICS_*
// de lib/physicsmod_ocean.glsl ; renommees parce que ce fichier ne peut pas
// l'inclure - cet include n'existe que sous PHYSICS_OCEAN, donc uniquement
// dans les programmes ocean).
#define VLX_PF_ITERS 13     // PHYSICS_ITERATIONS_OFFSET (le deplacement vertex)
#define VLX_PF_XZ    0.035  // PHYSICS_XZ_SCALE
#define VLX_PF_TMUL  0.45   // PHYSICS_TIME_MULTIPLICATOR
#define VLX_PF_F0    6.0    // PHYSICS_FREQUENCY
#define VLX_PF_S0    2.0    // PHYSICS_SPEED
#define VLX_PF_WD    0.8    // PHYSICS_WEIGHT
#define VLX_PF_FM    1.18   // PHYSICS_FREQUENCY_MULT
#define VLX_PF_SM    1.07   // PHYSICS_SPEED_MULT
#define VLX_PF_INC   12.0   // PHYSICS_ITER_INC
#define VLX_PF_DRAG  0.048  // PHYSICS_DRAG_MULT
// = CA5_K, defini plus bas dans ce fichier pour le champ du pack (il n'existe
// pas encore ici). Meme expression, une seule constante de compilation.
#define VLX_PF_CA5K  (0.5 / CA4_SCALE)
// RENORMALISATION DE PENTE. Le cahier des charges proposait d'egaliser la RMS
// de |g| avec celle de vlCa5Slope (0.64671 mesuree -> K = 16.59). MESURE, ce
// critere est REFUTE (pf_m3b_k.py) : a K 16.59 le terme livre perd 32.5 % de
// son exposition moyenne et gagne 34 % de contraste - une marche d'exposition
// visible quand l'ocean du mod entre dans le champ. Le critere retenu est
// celui que la calibration du pack ancre elle-meme ("solved for a mean of
// exactly 1.000000", vlCa4Mean / CA5_GAIN) : la MOYENNE du terme livre.
//   K = 12.00 -> moyenne +0.7 %, contraste 0.9096 contre 0.8962, et la
//   correlation avec les cretes du mod est MEILLEURE (+0.807 contre +0.699).
// Le facteur VLX_PF_CA5K fait suivre les dials : la pente rendue par
// vlCa5Slope est proportionnelle a CA5_K (mesure : lineaire a 5.5 % pres sur
// tout l'axe CA4_SCALE 0.5..3.0), et CA4_DEV porte le facteur reciproque, donc
// la deflexion d0 = g * CA4_DEV reste invariante des deux cotes.
// WAVE3_STEEP n'y entre PAS : CA5_NORM = 0.2275/WAVE3_STEEP annule exactement
// la dependance du champ v3 en steepness, la pente rendue en est deja
// independante.
#if CAUSTICS_V5 == 1 && WAVES_V3 == 1
    #define VLX_PHYS_K (12.00 * VLX_PF_CA5K)   // cible = vlCa5Slope (CA5_ON 1)
#else
    #define VLX_PHYS_K (11.60 * VLX_PF_CA5K)   // cible = vlCa4Slope (CA5_ON 0)
#endif
// Gain du Laplacien fenetre, resolu sur la RMS du `lap` de causticShaftMask
// (pf_m4_mask.py) : 2.495 / 2.491 / 2.457 aux profondeurs 1 / 8 / 24 blocs,
// soit une constante a +-1.5 % pres -> 2.50.
#define VLX_PHYS_LAPK 2.50
// Hauteur physics par unite (amp * waviness) : moyenne et ecart-type mesures
// (pf_m4_mask.py, 3 patchs x 500^2 points) -0.03380 / 0.10779. Le brief citait
// -0.034 / 0.1064 : confirme. Sert a remapper la crete dans la plage v2 de
// wave3Height (W3_V2_MEAN / W3_V2_STD, definis plus bas), pour que la porte
// WHITECAPS de composite1 (1.02) garde son sens.
#define VLX_PF_HMEAN (-0.03380)
#define VLX_PF_HSTD    0.10779

// ---- GLOBALES DE BRANCHEMENT (valeur par defaut = "off" partout) -----------
// Remplies par composite1 / composite depuis les images physOcean* ; lues par
// vlCa4Net, vlCa4Vol et causticShaftMask. Branche UNIFORME par pixel.
float vlxPhysOn    = 0.0;        // > 0.5 = ce pixel lit le champ du mod
float vlxPhysT     = 0.0;        // physics_gameTime : L'HORLOGE DU MOD
float vlxPhysScale = 1.0;        // physics_oceanWaveHorizontalScale
vec2  vlxPhysDrift = vec2(0.0);  // monde -> maillage : pos_champ = pw - drift
float vlxPhysWav   = 0.0;        // waviness locale (0 cote calme .. 1 large)
// Decalage de registration que le SITE a deja soustrait a sa position de
// lecture (VL_CA5_REG, une convention propre au champ du pack : wave3Pos
// soustrait l'altitude du point). Le champ du mod n'a pas cette convention :
// vlxPhysSlope le rajoute pour lire au VRAI xz monde. Les sites qui n'appliquent
// pas VL_CA5_REG (causticShaftMask, WHITECAPS) laissent la globale a 0.
float vlxPhysReg   = 0.0;
// Amplitude PHYSIQUE du champ (physics_oceanHeight, blocs) : le filet n'en a
// pas besoin (pente normalisee), la focalisation PHYS_SWELL si (hessienne en
// blocs^-1). Remplie par composite1 depuis physOceanParams.
#if PHYS_SWELL == 1
float vlxPhysAmp   = 1.0;
#endif
// Arme les globales juste avant un appel au filet / aux puits / au masque de
// gerbes. A ecrire a CHAQUE site (y compris pour l'eteindre) : les globales
// persistent d'un site a l'autre dans le meme pixel.
#define VLX_PHYS_SET(on_, wav_, reg_) { vlxPhysOn = (on_) ? 1.0 : 0.0; vlxPhysWav = (wav_); vlxPhysReg = (reg_); }

// PENTE (xz monde) du champ du mod, dans les unites qu'attend l'estimateur de
// photons - drop-in de vlCa5Slope. L'amplitude, la waviness et l'echelle
// horizontale se simplifient (voir la note 2 de l'en-tete), il ne reste que la
// forme : le facteur final est une seule constante de compilation.
vec2 vlxPhysSlope(vec2 pw) {
    float adj = clamp(vlxPhysWav * 2.0, 0.1, 1.0);
    vec2 p = (pw + vec2(vlxPhysReg) - vlxPhysDrift) * (VLX_PF_XZ * vlxPhysScale);
    float mt = vlxPhysT * VLX_PF_TMUL;
    float it = 0.0;
    float freq = VLX_PF_F0;
    float spd = VLX_PF_S0;
    float w = 1.0;
    float wsum = 0.0;
    vec2 g = vec2(0.0);
    // J = dp_i / dp_0, identite au depart. j0 = ligne x, j1 = ligne z.
    vec2 j0 = vec2(1.0, 0.0);
    vec2 j1 = vec2(0.0, 1.0);
    for (int i = 0; i < VLX_PF_ITERS; i++) {
        // it = 12*i : une CONSTANTE. Un compilateur qui deroule les 13
        // iterations la plie ; MESURE (pf_m5_cost.py) : glslc -O ne deroule pas,
        // et paie donc 5 transcendantes par octave au lieu de 3. Un pilote GPU
        // reel deroule une boucle a borne constante de cette taille. Ecrire la
        // recurrence de rotation a la place (4 mul + 2 add par octave) vaudrait
        // ~3 % de creneaux et introduirait un ecart numerique avec la formule du
        // mod : non fait, volontairement.
        vec2 d = vec2(sin(it), cos(it));
        float x = dot(d, p) * freq + mt * spd;
        float sx = sin(x);
        float cx = cos(x);
        float wv = exp(sx - 1.0);
        // u = J^T d ; d(x_i)/d(p_0) = freq * u
        vec2 u = vec2(j0.x * d.x + j1.x * d.y, j0.y * d.x + j1.y * d.y);
        g += (w * wv * cx * freq) * u;
        // J -= (DRAG*adj*w*freq) * wv * (cos^2 - sin) * outer(d, u)
        float cc = (VLX_PF_DRAG * adj * w * freq) * wv * (cx * cx - sx);
        j0 -= (cc * d.x) * u;
        j1 -= (cc * d.y) * u;
        p -= ((VLX_PF_DRAG * adj * w) * wv * cx) * d;
        it += VLX_PF_INC;
        wsum += w;
        w *= VLX_PF_WD;
        freq *= VLX_PF_FM;
        spd *= VLX_PF_SM;
    }
    return g * (VLX_PHYS_K * VLX_PF_XZ / wsum);
}

// HAUTEUR du champ du mod, PAR UNITE de (physics_oceanHeight * waviness).
// Sert a la porte WHITECAPS et a la vue de debug 30. Aucune derivee : pas de
// jacobien a porter, c'est la boucle la moins chere des trois.
float vlxPhysHeightU(vec2 pw) {
    float adj = clamp(vlxPhysWav * 2.0, 0.1, 1.0);
    vec2 p = (pw - vlxPhysDrift) * (VLX_PF_XZ * vlxPhysScale);
    float mt = vlxPhysT * VLX_PF_TMUL;
    float it = 0.0;
    float freq = VLX_PF_F0;
    float spd = VLX_PF_S0;
    float w = 1.0;
    float wsum = 0.0;
    float h = 0.0;
    for (int i = 0; i < VLX_PF_ITERS; i++) {
        vec2 d = vec2(sin(it), cos(it));
        float x = dot(d, p) * freq + mt * spd;
        float wv = exp(sin(x) - 1.0);
        p -= ((VLX_PF_DRAG * adj * w) * wv * cos(x)) * d;
        h += wv * w;
        it += VLX_PF_INC;
        wsum += w;
        w *= VLX_PF_WD;
        freq *= VLX_PF_FM;
        spd *= VLX_PF_SM;
    }
    return h / wsum - 0.5;
}

// LAPLACIEN SPECTRALEMENT FENETRE du champ du mod, deja normalise pour etre
// compare aux MEMES seuils que le `lap` de causticShaftMask (0.022 / 0.080 x
// UW_SHAFT_FINESSE). Positif sous les DOMES de crete (lentille convergente),
// comme l'original.
// POURQUOI UNE FENETRE : le Laplacien brut du champ du mod est domine par ses
// octaves fines (poids x freq^2 = 1.11^i), donc par des details de ~2 blocs,
// alors que les gerbes visent des paquets de 3-6 blocs espaces de 4-10.
// causticShaftMask obtient cette geometrie par un flou spectral gaussien
// exp(-k^2 sigma^2/2) ; ici la meme idee avec une lorentzienne 1/(1+(k sigma)^2)
// - meme role, mais 3 ALU par octave au lieu d'une exponentielle de plus.
// MESURE (pf_m4_mask.py, 3 patchs x 500^2 points, aux profondeurs 1/8/24 bl) :
// masque moyen 0.0848 / 0.0748 / 0.0547 contre 0.0927 / 0.0780 / 0.0495 pour
// l'original, aire touchee 19.8 / 18.6 / 15.9 % contre 24.4 / 22.8 / 19.8 %.
// depthM : meme argument que causticShaftMask (colonne d'eau au-dessus du point).
float vlxPhysShaftLap(vec2 pw, float depthM) {
    float adj = clamp(vlxPhysWav * 2.0, 0.1, 1.0);
    float sg = (1.15 + min(depthM * 0.019, 0.45)) * UW_SHAFT_SCALE; // sync causticShaftMask
    vec2 p = (pw - vlxPhysDrift) * (VLX_PF_XZ * vlxPhysScale);
    float mt = vlxPhysT * VLX_PF_TMUL;
    float it = 0.0;
    float freq = VLX_PF_F0;
    float spd = VLX_PF_S0;
    float w = 1.0;
    float wsum = 0.0;
    float lap = 0.0;
    vec2 j0 = vec2(1.0, 0.0);
    vec2 j1 = vec2(0.0, 1.0);
    for (int i = 0; i < VLX_PF_ITERS; i++) {
        vec2 d = vec2(sin(it), cos(it));
        float x = dot(d, p) * freq + mt * spd;
        float sx = sin(x);
        float cx = cos(x);
        float wv = exp(sx - 1.0);
        vec2 u = vec2(j0.x * d.x + j1.x * d.y, j0.y * d.x + j1.y * d.y);
        // Hessienne de Gauss-Newton : seul le terme (dx/dp)(dx/dp)^T est garde
        // (la derivee seconde de la chaine du drag est ignoree). MESURE : erreur
        // RMS 11.0 % pour une correlation +0.994 avec le Laplacien par
        // differences finies - largement suffisant pour un masque a seuil, et
        // le tenseur d'ordre 2 couterait 8 registres de plus par octave.
        float kw = freq * (VLX_PF_XZ * vlxPhysScale);      // frequence angulaire monde
        float lp = 1.0 / (1.0 + (kw * sg) * (kw * sg));    // fenetre lorentzienne
        lap += (w * wv * (cx * cx - sx) * freq * freq * lp) * dot(u, u);
        float cc = (VLX_PF_DRAG * adj * w * freq) * wv * (cx * cx - sx);
        j0 -= (cc * d.x) * u;
        j1 -= (cc * d.y) * u;
        p -= ((VLX_PF_DRAG * adj * w) * wv * cx) * d;
        it += VLX_PF_INC;
        wsum += w;
        w *= VLX_PF_WD;
        freq *= VLX_PF_FM;
        spd *= VLX_PF_SM;
    }
    return -lap * (VLX_PHYS_LAPK * VLX_PF_XZ * VLX_PF_XZ / wsum);
}
#endif
/* ================= FIN DU CHAMP PHYSICS MOD ============================== */

// One sea octave: choppy waves on a noise-warped domain (curved, irregular
// wave fronts; no diamond artifacts)
float seaOctave(vec2 uv, float choppy) {
    uv += vnoise(uv) * 2.0 - 1.0;
    vec2 wv = 1.0 - abs(sin(uv));
    vec2 swv = abs(cos(uv));
    wv = mix(wv, swv, wv);
    return pow(1.0 - pow(wv.x * wv.y, 0.65), choppy);
}

// ============================ WAVES_V2 ============================
// Coherent directional spectrum: dominant ANALYTIC Gerstner-lite swell
// (long wavelength, fixed wind direction) + wind-aligned anisotropic chop
// (waveChopLOD). Total height = chop + swell; normal = finite differences
// on the CHOP only + ANALYTIC swell slope, barely attenuated at distance
// (the far ocean keeps rolling). SELF-CONTAINED: needs only common.glsl +
// settings.glsl (gbuffers_water.vsh includes water.glsl WITHOUT
// lighting.glsl - no uniforms here, time t is passed as an argument).
#if WAVES_V2 == 1
// Swell: height AND slope share one evaluator (declared BEFORE any use).
// Stokes-lite trains (cos + in-phase 2nd harmonic: pinched crests, wide
// troughs, ZERO mean -> shifts neither displacement nor the whitecap
// threshold); wave groups from very low-frequency vnoise (group gradient
// neglected: ~0.01 cycle/block, invisible in slope).
// WAVE_ITERATIONS swell trains: the 1st at full strength (lambda ~26), each
// next one disperses (+-30 deg around the wind, sin(i*2.4)*0.52), shortens
// (x0.58), weakens (x0.55) and speeds up (x1.35) -> rich crossed sea.
// Non-parallel fronts via domain warp (~9 blocks on ~50-block noise: crests
// undulate instead of being straight lines). The warp gradient is neglected
// in the slope (slow) - same approximation as the groups. The analytic
// caustics below derive from the SAME train set and follow these waves by
// construction: KEEP BOTH SUMS SYNCHRONIZED.
void swellEval(vec2 p, float t, out float height, out vec2 slope) {
    float ang = WIND_DIRECTION * 0.017453293;
    float amp = 0.38 * SWELL_AMOUNT; // swell IS the wave; chop is only detail on top
    float lambda = 26.0;
    float spd = 0.60 * WAVE_SPEED;
    float grp = 0.62 + 0.38 * vnoise(p * 0.013 + vec2(t * 0.009, -t * 0.007));
    vec2 wp2 = p + (vec2(vnoise(p * 0.020 + 3.7), vnoise(p * 0.020 + 9.1)) - 0.5) * 6.5;
    float q = 0.30; // Gerstner crest pinch (lower = softer crests)
    height = 0.0;
    slope = vec2(0.0);
    for (int i = 0; i < WAVE_ITERATIONS; i++) {
        // Directional spectrum: +-30 deg spread around the WIND. i=0 is
        // dead downwind; the sea rolls one way with variety, like a real
        // sea state (wide crossing angles made it unreadable).
        float aI = ang + sin(float(i) * 2.4) * 0.52;
        vec2 d = vec2(cos(aI), sin(aI));
        float k = 6.2831853 / lambda;
        float ph = dot(wp2, d) * k - t * spd;
        float a = amp * grp;
        height += a * (cos(ph) + q * cos(2.0 * ph));
        slope  += d * (a * k * (-sin(ph) - 2.0 * q * sin(2.0 * ph)));
        amp *= 0.60;
        lambda *= 0.58;
        spd *= 1.35;
    }
}
float swellHeight(vec2 p, float t) {
    float h; vec2 s;
    swellEval(p, t, h, s);
    return h;
}
vec2 swellSlope(vec2 p, float t) {
    float h; vec2 s;
    swellEval(p, t, h, s);
    return s;
}
#endif

// CHOP height, variable detail level (oct = 3 far ... 5 near).
// WAVES_V2=1: chop is ANISOTROPIC in wind space (field varies faster downwind
// than across = crests stretched perpendicular to the wind), 2 trains both
// drifting DOWNWIND, reduced octave rotation (~16 deg vs ~37) so the alignment
// survives across octaves. WAVES_V2=0 keeps the legacy isotropic body.
float waveChopLOD(vec2 p, float t, int oct) {
#if WAVES_V2 == 1
    float ang = WIND_DIRECTION * 0.017453293;
    vec2 wx = vec2(cos(ang), sin(ang));
    vec2 pw = vec2(dot(p, wx), dot(p, vec2(-wx.y, wx.x)));
    vec2 uv = vec2(pw.x * 1.06, pw.y * 0.78); // wind-aligned anisotropy
    // Tuning knobs: freq = base shape size (0.115 ~ 9 blocks), amp/choppy =
    // crest sharpness, decay 0.22 = how fast fine octaves die out. Raising
    // freq or the decay brings back a rough "gravel" look.
    float freq = 0.115;
    float amp = 0.40;
    float choppy = 2.4;
    float tt = 1.0 + t * 0.8 * WAVE_SPEED;

    float h = 0.0;
    for (int i = 0; i < 5; i++) {
        if (i >= oct) break;
        float d = seaOctave((uv - vec2(tt, tt * 0.14)) * freq, choppy)
                + seaOctave((uv - vec2(tt * 0.55, -tt * 0.09)) * freq * 1.13, choppy);
        h += d * amp;
        uv = mat2(1.92, 0.55, -0.55, 1.92) * uv;
        freq *= 1.9;
        amp *= 0.22;
        choppy = mix(choppy, 1.0, 0.3);
    }
    return h;
#else
    float freq = 0.14;
    float amp = 0.62;
    float choppy = 4.0;
    vec2 uv = p;
    uv.x *= 0.75;
    float tt = 1.0 + t * 0.8 * WAVE_SPEED;

    float h = 0.0;
    for (int i = 0; i < 5; i++) {
        if (i >= oct) break;
        float d = seaOctave((uv + tt) * freq, choppy)
                + seaOctave((uv - tt * 0.8) * freq, choppy);
        h += d * amp;
        uv = mat2(1.6, 1.2, -1.2, 1.6) * uv;
        freq *= 1.9;
        amp *= 0.28;
        choppy = mix(choppy, 1.0, 0.2);
    }
    return h;
#endif
}

// Total sea height = chop (+ swell when WAVES_V2). KEEP THIS SIGNATURE:
// consumers are gbuffers_water.vsh (displacement), composite1 (whitecaps),
// gbuffers_water.fsh (normals).
float waveHeightLOD(vec2 p, float t, int oct) {
#if WAVES_V2 == 1
    return waveChopLOD(p, t, oct) + swellHeight(p, t);
#else
    return waveChopLOD(p, t, oct);
#endif
}

float waveHeight(vec2 p, float t) {
    return waveHeightLOD(p, t, 5);
}

#if WAVE_NORMALS_V3 == 1
// Height field used for NORMALS ONLY (two-texture approach): layer A broad
// (~3.3 blocks) drifting downwind, layer B medium (~1.4 blocks) at ~22 deg
// with slight lateral counter-drift -> soft interference, round lobes, no
// choppy crests. Displacement (waveHeightLOD), whitecaps and caustics keep
// using their own fields.
float waterTexV3(vec2 p, float t) {
    float ang = WIND_DIRECTION * 0.017453293;
    vec2 wdir = vec2(cos(ang), sin(ang));
    vec2 pw = vec2(dot(p, wdir), dot(p, vec2(-wdir.y, wdir.x)) * 0.82);
    vec2 uvA = pw * 0.30 - vec2(t * 0.16 * WAVE_SPEED, 0.0);
    float hA = vnoise(uvA) * 0.72 + vnoise(uvA * 2.15 + 7.3) * 0.28;
    vec2 pb = mat2(0.927, 0.375, -0.375, 0.927) * pw;
    vec2 uvB = pb * 0.72 - vec2(t * 0.34 * WAVE_SPEED, -t * 0.05 * WAVE_SPEED);
    float hB = vnoise(uvB) * 0.70 + vnoise(uvB * 2.3 + 3.1) * 0.30;
    // Layer C: ripple built from seaOctave (self-warped domain -> organic
    // curved fronts, no perlin grid, soft choppy profile). 2 scales (~1.3 and
    // ~0.65 block) drifting downwind = the dense living surface texture.
    vec2 uvC = vec2(pw.x * 2.2, pw.y * 2.9) - vec2(t * 0.9 * WAVE_SPEED, t * 0.13 * WAVE_SPEED);
    float hC = seaOctave(uvC, 1.8) * 0.62
             + seaOctave(uvC * 2.05 + 3.7, 1.6) * 0.38;
    return hA * 0.50 + hB * 0.24 + hC * 0.26;
}
#endif

// World-space normal by finite differences, detail fading with distance
vec3 waveNormalWorld(vec2 p, float t, float strength, float chopFade) {
#if WAVE_NORMALS_V3 == 1
    // Soft 2-layer normals; the analytic WAVES_V2 swell (~26-block rollers) is
    // added on top -> the ocean ROLLS while the surface stays SMOOTH (clean
    // reflections, tidy sunset glint).
    // epsilon 0.22 resolves the ~0.65-block seaOctave ripple; slope gain 0.62
    float e = 0.22;
    float h0 = waterTexV3(p, t);
    float hx = waterTexV3(p + vec2(e, 0.0), t);
    float hz = waterTexV3(p + vec2(0.0, e), t);
    float slopeAtt3 = mix(0.45, 1.0, clamp(chopFade, 0.0, 1.0));
    vec2 slope = vec2(h0 - hx, h0 - hz) / e * strength * slopeAtt3 * 0.62;
    #if WAVES_V2 == 1
        float swellAtt3 = mix(0.75, 1.0, clamp(chopFade, 0.0, 1.0));
        slope -= swellSlope(p, t) * strength * swellAtt3;
    #endif
    #ifdef WATER_MICRONORMAL
        // Fine grain kept but reduced (x0.10) so the surface stays smooth
        float mf3 = smoothstep(0.45, 0.95, chopFade);
        if (mf3 > 0.001) {
            float md3 = 0.06;
            vec2 q3 = p * 3.7 + vec2(t * 0.45, -t * 0.33);
            float n03 = vnoise(q3);
            float nx3 = vnoise(q3 + vec2(md3, 0.0));
            float nz3 = vnoise(q3 + vec2(0.0, md3));
            slope += vec2((n03 - nx3) / md3, (n03 - nz3) / md3) * strength * mf3 * 0.10;
        }
    #endif
    return normalize(vec3(slope.x, 1.0, slope.y));
#else
    // Legacy normals. Octave count 4/3/2 by distance, widened epsilon and a
    // chop slope gain capped at 0.85 keep the micro-chop from resolving into
    // a gravel-like grain; the swell (x1.25 below) draws the surface shape.
    int oct = (chopFade > 0.5) ? 4 : ((chopFade > 0.15) ? 3 : 2);
    float e = mix(0.16, 0.11, clamp(chopFade, 0.0, 1.0));
    // Finite differences on the CHOP only: the long swell is added
    // ANALYTICALLY below (a short epsilon cannot resolve a 26-block wave).
    float h0 = waveChopLOD(p, t, oct);
    float hx = waveChopLOD(p + vec2(e, 0.0), t, oct);
    float hz = waveChopLOD(p + vec2(0.0, e), t, oct);
    // Slope attenuation with distance: kills far specular shimmer
    float slopeAtt = mix(0.30, 0.85, clamp(chopFade, 0.0, 1.0));
    vec2 slope = vec2((h0 - hx) / e, (h0 - hz) / e) * strength * slopeAtt;
    #if WAVES_V2 == 1
        // ANALYTIC swell slope, barely attenuated at distance so the far ocean
        // keeps rolling instead of flattening. Sign convention: slope = -dh/dxz
        // (final normal is (slope.x, 1.0, slope.y)).
        float swellAtt = mix(0.75, 1.0, clamp(chopFade, 0.0, 1.0));
        slope -= swellSlope(p, t) * strength * swellAtt * 1.25;
    #endif
    #ifdef WATER_MICRONORMAL
        // High-frequency grain, near-field only (faded by chopFade)
        float mf = smoothstep(0.45, 0.95, chopFade);
        if (mf > 0.001) {
            float md = 0.06;
            vec2 q = p * 3.7 + vec2(t * 0.45, -t * 0.33);
            float n0 = vnoise(q);
            float nx = vnoise(q + vec2(md, 0.0));
            float nz = vnoise(q + vec2(0.0, md));
            slope += vec2((n0 - nx) / md, (n0 - nz) / md) * strength * mf * 0.07; // faint surface shiver; above ~0.12 it reads as rock
        }
    #endif
    return normalize(vec3(slope.x, 1.0, slope.y));
#endif
}

/*
    ==================== WAVES_V3 - FORMED SEA ====================
    WAVES_V3 == 0 compiles NOTHING of this block and leaves every v2 entry
    point above untouched (bit-identical render) - the gate exists to A/B the
    two seas in game.

    WHAT IT IS. A wind sea, not a swell: a ladder of value-noise rungs, one
    octave apart, each one squeezed into long crest LINES by an anisotropic
    sampling transform and each drifting at its own deep-water phase speed.
    The two coarsest rungs are ridge-folded, which gives them straight flanks,
    a marked crest and wide troughs - the asymmetric profile of a real gravity
    wave. There is no trigonometry in the field, so it has no period, no
    parallel fronts and no residual lattice.

    WHY IT IS NOT v2. v2 is a sum of cosine trains (mathematically periodic,
    26-block dominant swell, symmetric crests) plus a self-warped short-wave
    chop; its far slope is deliberately NOT attenuated. v3 replaces all of it.

    THREE THINGS DECIDE THE LOOK, in order:
      (a) the grazing-angle flattening (wave3NormalWorld): the far sea becomes
          a mirror with a clean horizon instead of a shimmering field;
      (b) the parallax occlusion: a strictly flat quad reads as a volume;
      (c) the ridge fold + strong anisotropy: long crossed crest lines with a
          credible asymmetric profile, instead of a round grain.

    DERIVATION POLICY. Every constant below carries its criterion. Numbers
    tagged MEASURED were produced by a numpy port of THIS field (the same
    vnoiseD, the same ladder); numbers tagged DERIVED come from a physical
    relation. Nothing here was transcribed from another shader.
*/
#if WAVES_V3 == 1

// ---- the noise brick ----------------------------------------------------
// MEASURED: energy-weighted mean wavenumber of common.glsl vnoise over a
// 16x16-cell window -> characteristic wavelength 2.4263 lattice cells. This is
// what converts a target crest SPACING in blocks into a sampling scale.
// CAVEAT: the answer depends on the definition. The same lattice measures 2.53
// cells by rms wavenumber and 3.01 cells by mean local-maxima spacing - the
// definition that actually means "crest pitch". Keeping 2.4263 therefore
// stretches the delivered pitch to ~1.24 x each rung's nominal lambda. It is a
// single uniform factor on the whole ladder (visually the same as
// WAVE3_PEAK_LEN one notch higher), so every rung ratio, the spectrum shape and
// the amplitude shares are untouched; only the absolute lambda -> pitch mapping
// carries the 24%. The measured pitches quoted downstream are the delivered
// ones, not lambda.
#define W3_LQ 2.4263
// MEASURED on the same window: plain vnoise has mean 0.50197, sigma 0.21397.
#define W3_PLAIN_MU 0.50197
#define W3_PLAIN_SD 0.21397

// ---- ridge fold ---------------------------------------------------------
// t = 2n-1 ; F = G * (sqrt(1+m^2) - sqrt(t^2+m^2)) with G = 1/(sqrt(1+m^2)-m).
// F(0) = 1, F(+-1) = 0, and dF/dn = -2*G*t/sqrt(t^2+m^2) is continuous
// EVERYWHERE - a raw |2n-1| kink would put a gradient discontinuity on the
// crest line itself and TAA would read it as a hairline of aliasing.
// m = 0.13 CRITERION: the crest must never be sharper than a pixel. MEASURED
// crest rounding at m = 0.13 is 0.71 block on rung 0 and 0.37 block on rung 1,
// against a pixel ground footprint of 0.18 block at 16 blocks (1080p, fov 70,
// eye 1.8 above the sheet). m = 0.09 is the smallest value that still clears
// that footprint (0.26 block); 0.13 keeps a 2x margin and matches the fold
// already used by CAUSTICS_V4 below.
#define W3_RIDGE_M2 0.0169
#define W3_RIDGE_S1 1.0084146   // sqrt(1 + m^2)
#define W3_RIDGE_G  1.138415    // 1 / (sqrt(1+m^2) - m)
// MEASURED distribution of that fold over plain vnoise: mean 0.70050, sigma
// 0.24289. Both are needed to keep the rung's contribution zero-mean and to
// give it exactly the sigma its amplitude asks for.
#define W3_RIDGE_MU 0.70050
#define W3_RIDGE_SD 0.24289

// ---- spectrum -----------------------------------------------------------
// DERIVED - Pierson-Moskowitz. In wavenumber the PM elevation spectrum is
// S(k) ~ k^-4 exp(-1.25 (kp/k)^2), so the amplitude of an octave band goes as
// k^-1 exp(-0.625 (kp/k)^2) = lambda * exp(-0.625 (lambda/lambda_p)^2). The
// k^-4 saturation alone would give amplitude ~ lambda (constant steepness per
// octave, i.e. Phillips equilibrium); the exponential is what puts a PEAK in
// the ladder and drops the rungs LONGER than the peak.
#define W3_PMB 0.625
// Rung 0 sits at 1.6 x the peak wavelength, so its PM factor is a pure number:
// exp(-0.625 * 1.6^2) = exp(-1.6). Because each rung halves lambda, the
// exponent quarters, i.e. the factor is raised to the power 1/4 - two sqrt per
// rung instead of an exp. The resulting amplitude ladder is fixed by the
// physics, NOT by the dials: MEASURED shares 20.6 / 34.3 / 23.1 / 12.5 / 6.3 /
// 3.2 %, i.e. the mode on the 3-block rung with the 6-block rung second and the
// four fine rungs together at 45% - the "3-to-6 block trame, fine detail
// present but at low contrast" the look asks for. No spectral hole anywhere.
#define W3_PM_E0 0.2018965
#define W3_LADDER_TOP 1.6

// ---- amplitude ----------------------------------------------------------
// A sinusoid of crest-to-trough H has sigma H/(2*sqrt(2)). Each rung is scaled
// so its own sigma equals that, whatever the fold does to the noise shape.
#define W3_H2S 0.35355339

// ---- anisotropy taper ---------------------------------------------------
// DERIVED - directional spreading. In a wind sea the spreading function
// narrows toward the spectral peak and the LONG waves are long-crested while
// the short wind ripple is short-crested. Modelled as aspect ~ lambda^beta with
// beta = 0.175, i.e. one factor 2^-0.175 per rung. CRITERION: the finest rung
// must still land inside the "long crest" family (aspect ~3) when the coarsest
// is at 5.5, over the 32x span of the ladder: 5.5 * 32^-0.175 = 3.0.
#define W3_ANISO_STEP 0.88585

// ---- time ---------------------------------------------------------------
// DERIVED - deep-water dispersion c = sqrt(g*lambda/2pi), so c halves in
// sqrt(2) steps down the ladder. g_eff = 4.40 block/s^2 CRITERION: the sea we
// draw is a scale model (a 3-block chop stands in for a ~7 m real wind sea);
// under Froude similitude periods go as sqrt(length), so the model runs at
// g/2.23. Same value falls out of the look target directly - it is the gravity
// that lands the two dominant rungs' apparent periods T = sqrt(2*pi*lambda/g)
// inside the 1.2-3.5 s window: MEASURED 3.02 s at 6.4 blocks and 2.14 s at 3.2.
#define W3_GRAV 4.40
#define W3_INV_TAU 0.15915494
// Each rung translates along ITS OWN crest normal, which is why the layers
// slide over one another instead of scrolling as one rigid texture; and since
// every crest normal sits within +-WAVE3_SPREAD of the wind axis, the sea as a
// whole still rolls one way. NOTE this is a phase velocity applied to a noise
// field: there is no separate group velocity, the rung simply translates.
// A common wind-drift current was left out on purpose - PM gives U10 = 2.2 m/s
// at a 4-block peak, and the classic 3% surface drift is 0.04 block/s, under 2%
// of the slowest rung's phase speed.

// ---- grazing-angle flattening ------------------------------------------
// W3_FLAT_NOTE. The tilt kept is (1+K)*c/(c+K) with c = |cos(view)| - the same
// curve as (1+K)/(1+K/c), written multiplicatively because that form has no
// pole and reaches 0 cleanly at the horizon. On a horizontal sheet
// c ~ eye_height/distance, so this is a 1/distance attenuation; solving
// (1+K)*c/(c+K) = 0.5 gives c = K/(1+2K), i.e. a HALF-POINT at eye*(1+2K)/K,
// which is ~25 blocks at the default K (not eye/K - the (1+K) factor pushes it
// out). K = 0.085 CRITERION: the knee of the 1/distance curve, eye/K, is placed
// at the distance where one pixel's ground footprint d^2/(f*eye) equals the
// MEASURED crest pitch of the FINEST rung (0.33 block, taken as the
// zero-crossing spacing along the crest normal) - the point past which that
// rung can no longer be resolved at all. At 1080p / fov 70 (f = 771 px) with
// the eye 1.8 above the sheet that is d = sqrt(0.33*f*eye) = 21 blocks, hence
// K = eye/d = 0.085. The (1+K) factor normalises the curve so nothing is lost
// when looking straight down.
// The cosine is deliberately NOT clamped. A floor on c turns the tail into a
// plateau - a 0.02 floor pins the retained tilt at 20.7% from ~90 blocks out to
// the horizon, which is exactly the constant far-field shimmer this dial exists
// to remove, and it hands TAA ~50% more jitter-driven normal movement in the
// mid field for nothing.
// MEASURED tilt retained: 50% at 25 bl, 32% at 50, 19% at 100, 10% at 200,
// 4% at 500 - the far sea is a mirror, the horizon line is clean and the sun
// glitter path closes into a ribbon.
// MEASURED ALIASING THRESHOLD (requirement: do not shimmer under TAA). Summing
// only the rungs whose crest pitch has dropped under two pixel footprints -
// i.e. the slope energy that can actually alias - the worst case over all
// distances is 3.37 deg of tilt at 61 blocks with K = 0, 1.71 deg with
// K = 0.04, and 1.13 deg at 46 blocks with K = 0.085. 0.085 is the first value
// that pushes the aliasing-capable residue under a quarter of the field's own
// 4.6 deg mean tilt, and it keeps falling afterwards (0.35 deg at 200 blocks,
// 0.13 at 600) instead of sitting flat at 3.37 deg all the way to the horizon.
// TAA absorbs what is left in the near/mid field.

// ---- parallax -----------------------------------------------------------
// Half-band of the height field, in sigma. MEASURED: p1..p99 of the elevation
// is 0.1274 block against 2 * 2.2 * sigma = 0.1244, so +-2.2 sigma is the
// crest-to-trough envelope the march has to cover.
#define W3_PAR_BAND 2.2
// Horizontal slide cap, in blocks of xz per block of depth. This is a
// STYLISTIC cap on how far one crest may occlude, not a physical threshold:
// slide = 6 means cos(view) = 1/sqrt(37) = 0.164, i.e. ~11 blocks at eye 1.8,
// where the flattening still KEEPS 72% of the tilt. So it binds over most of
// the march's active disc (from ~11 blocks out to the gate at ~25) and
// deliberately under-shifts the occlusion there rather than let a single crest
// smear across the lower screen.
#define W3_PAR_MAXSLIDE 6.0
// Rungs walked by the march. The coarsest three carry 78% of the amplitude and
// are the only ones whose relief is thick enough to occlude anything.
#define W3_PAR_OCT 3
// Gate: run the march only while the flattening still keeps half the tilt
// (the half-attenuation point eye*(1+2K)/K, ~25 blocks at the default K), so
// the two always move together. The BRANCH is hard, but the applied offset is
// ramped over W3_PAR_FADE of att above it: uHit does not tend to 0 at the
// boundary, so switching the offset would leave a distance-locked ring on the
// water.
#define W3_PAR_GATE 0.5
// Width of that ramp, in att. 0.12 spans att 0.62 down to 0.50, i.e. ~16 to
// ~25 blocks at the default K - nine blocks of view distance to spread a jump
// that was up to 0.70 block of sampling offset, and still leaving the whole
// near field (under 16 blocks, where the relief actually reads) at full offset.
#define W3_PAR_FADE 0.12

// ---- ladder sigma, as compile-time constants ----------------------------
// The field's sigma is needed per water fragment (the parallax band) and per
// vertex / per composite1 fragment (the wave3Height remap). wave3Sigma() below
// computes it correctly but is a runtime loop with a break and two sqrt per
// iteration, which no driver folds - the -O'd default build still carried the
// loop and 21 sqrt. Everything in it is known at compile time, so it is written
// out here instead and wave3Sigma() is kept only as the readable derivation.
//
// Per rung i: sd_i = W3_H2S * WAVE3_STEEP * lam_i * pmE_i, with lam_i halving
// and pmE_i = W3_PM_E0^(4^-i). W3_PM_E0 is exp(-1.6) by construction (rung 0
// sits at W3_LADDER_TOP = 1.6 peak wavelengths), so the exponent simply
// quarters: pmE_i = exp(-1.6 * 4^-i). Those eight values, written flat rather
// than as nested sqrt so the expansion stays readable:
#define W3_E0 0.20189652   // exp(-1.6)          = W3_PM_E0
#define W3_E1 0.67032005   // exp(-0.4)
#define W3_E2 0.90483742   // exp(-0.1)
#define W3_E3 0.97530991   // exp(-0.025)
#define W3_E4 0.99376950   // exp(-0.00625)
#define W3_E5 0.99843872   // exp(-0.0015625)
#define W3_E6 0.99960945   // exp(-0.000390625)
#define W3_E7 0.99990235   // exp(-0.00009765625)
// Variance contribution of rung i, factored out of the common
// (W3_H2S * WAVE3_STEEP * W3_LADDER_TOP * WAVE3_PEAK_LEN): (0.5^i * pmE_i)^2.
#define W3_V0 (W3_E0 * W3_E0)
#define W3_V1 (0.25 * W3_E1 * W3_E1)
#define W3_V2 (0.0625 * W3_E2 * W3_E2)
#define W3_V3 (0.015625 * W3_E3 * W3_E3)
#define W3_V4 (0.00390625 * W3_E4 * W3_E4)
#define W3_V5 (0.0009765625 * W3_E5 * W3_E5)
#define W3_V6 (0.000244140625 * W3_E6 * W3_E6)
#define W3_V7 (0.00006103515625 * W3_E7 * W3_E7)
#if WAVE3_SCALES >= 8
    #define W3_VSUM (W3_V0+W3_V1+W3_V2+W3_V3+W3_V4+W3_V5+W3_V6+W3_V7)
#elif WAVE3_SCALES == 7
    #define W3_VSUM (W3_V0+W3_V1+W3_V2+W3_V3+W3_V4+W3_V5+W3_V6)
#elif WAVE3_SCALES == 6
    #define W3_VSUM (W3_V0+W3_V1+W3_V2+W3_V3+W3_V4+W3_V5)
#elif WAVE3_SCALES == 5
    #define W3_VSUM (W3_V0+W3_V1+W3_V2+W3_V3+W3_V4)
#elif WAVE3_SCALES == 4
    #define W3_VSUM (W3_V0+W3_V1+W3_V2+W3_V3)
#else
    #define W3_VSUM (W3_V0+W3_V1+W3_V2)
#endif
// Common amplitude factor of the whole ladder, in blocks.
#define W3_SIG_A (W3_H2S * WAVE3_STEEP * W3_LADDER_TOP * WAVE3_PEAK_LEN)
// sigma of the full ladder == wave3Sigma(WAVE3_SCALES).
#define W3_SIG_N (W3_SIG_A * sqrt(W3_VSUM))
// sigma of the coarsest three rungs == wave3Sigma(3) == wave3Sigma(W3_PAR_OCT).
// WAVE3_SCALES bottoms out at 3, so this term count is always available.
#define W3_SIG3  (W3_SIG_A * sqrt(W3_V0 + W3_V1 + W3_V2))

// Analytic sigma of the first nOct rungs, in blocks. THE DERIVATION, kept
// readable; the shipped code uses the W3_SIG_N / W3_SIG3 constants above, which
// are this same sum written out. MEASURED agreement with the field's own sigma:
// 98.0% (the rungs are near-independent but not exactly).
float wave3Sigma(int nOct) {
    float lam = W3_LADDER_TOP * WAVE3_PEAK_LEN;
    float pmE = W3_PM_E0;
    float v = 0.0;
    for (int i = 0; i < WAVE3_SCALES; i++) {
        if (i >= nOct) break;
        float sd = W3_H2S * WAVE3_STEEP * lam * pmE;
        v += sd * sd;
        lam *= 0.5;
        pmE = sqrt(sqrt(pmE)); // exponent quarters when lambda halves
    }
    return sqrt(v);
}

// THE FIELD. p = horizontal sampling position in blocks, t = seconds.
// Returns the elevation in BLOCKS (already zero-mean) and its EXACT world
// gradient (dh/dx, dh/dz) - no finite differences anywhere, so there is no
// epsilon to trade against sharpness and no built-in low-pass.
// Cost: one vnoiseD (4 hash12) per rung, zero trig, zero pow.
void wave3Eval(vec2 p, float t, int nOct, out float elev, out vec2 grad) {
    // Ladder state, all of it running multipliers so a driver that refuses to
    // unroll still only pays a handful of mul/add per rung.
    float lam = W3_LADDER_TOP * WAVE3_PEAK_LEN; // rung crest spacing, blocks
    float pmE = W3_PM_E0;                       // Pierson-Moskowitz factor
    float s1  = W3_LQ / lam;                    // lattice cells per block, across the crests
    float ani = WAVE3_ANISO;
    float cph = sqrt(W3_GRAV * lam * W3_INV_TAU); // deep-water phase speed, block/s
    // The two alternating crest-normal directions. WIND_DIRECTION and
    // WAVE3_SPREAD are defines, so both cos/sin pairs fold at compile time.
    float aA = (WIND_DIRECTION + WAVE3_SPREAD) * 0.017453293;
    float aB = (WIND_DIRECTION - WAVE3_SPREAD) * 0.017453293;
    vec2 ra = vec2(cos(aA), sin(aA));
    vec2 rb = vec2(cos(aB), sin(aB));
    // Per-rung lattice offset: without it every rung would share the same
    // lattice cell at the world origin and their crests would all meet there.
    vec2 off = vec2(0.0);
    elev = 0.0;
    grad = vec2(0.0);
    for (int i = 0; i < WAVE3_SCALES; i++) {
        if (i >= nOct) break;
        float aH = WAVE3_STEEP * lam * pmE;  // crest-to-trough of this rung, blocks
        float s2 = s1 / ani;
        // Sampling transform M = diag(s1, s2) * R(-theta). Its SVD is exactly
        // (s1, s2) along (theta, theta+90): the noise's wavevector cloud is
        // stretched to s1 across the crests and s2 along them, so the crest
        // SPACING is L_Q/s1 = lambda (delivered ~1.24 x that - see the W3_LQ
        // caveat) and the crest RUN is that same spacing times ani. That is
        // the whole anisotropy mechanism - one 2x2 map, no per-octave rotation
        // matrix stack, and the gradient comes back through M^T exactly.
        vec2 q = vec2(s1 * (p.x * ra.x + p.y * ra.y) - t * s1 * cph,
                      s2 * (p.y * ra.x - p.x * ra.y)) + off;
        vec3 n = vnoiseD(q);
        float f;   // shaped rung value
        float fp;  // d(shaped)/d(noise)
        float mu;  // its mean
        float sd;  // its sigma
        if (i < WAVE3_RIDGE) {
            float tt = 2.0 * n.x - 1.0;
            float rr = sqrt(tt * tt + W3_RIDGE_M2);
            f  = W3_RIDGE_G * (W3_RIDGE_S1 - rr);
            fp = -2.0 * W3_RIDGE_G * tt / rr;
            mu = W3_RIDGE_MU;
            sd = W3_RIDGE_SD;
        } else {
            f  = n.x;
            fp = 1.0;
            mu = W3_PLAIN_MU;
            sd = W3_PLAIN_SD;
        }
        float a = W3_H2S * aH / sd; // gives this rung exactly sigma = aH/(2*sqrt(2))
        elev += a * (f - mu);
        float k = a * fp;
        // Chain rule through M: grad_p = M^T * grad_q.
        grad += k * vec2(s1 * ra.x * n.y - s2 * ra.y * n.z,
                         s1 * ra.y * n.y + s2 * ra.x * n.z);
        // next rung: one octave down
        lam *= 0.5;
        s1  *= 2.0;
        cph *= 0.70710678;          // c ~ sqrt(lambda)
        ani *= W3_ANISO_STEP;
        pmE  = sqrt(sqrt(pmE));
        off += vec2(17.3, 41.7);
        vec2 sw = ra; ra = rb; rb = sw; // alternate the crest-normal side
    }
}

// Sampling position. The block height is subtracted from BOTH horizontal
// coordinates: two water planes at different altitudes then never share a
// pattern (neighbouring ponds stop being clones) and a waterfall keeps a
// coherent one. Costs one subtract.
vec2 wave3Pos(vec3 wpos) {
    return wpos.xz - wpos.y;
}

// Height in the SAME numeric range as the v2 waveHeight(), so every downstream
// threshold keeps working untouched - chiefly the composite1 whitecap gate at
// 1.02. MEASURED over 400x400 blocks at
// four times and two sites, v2 waveHeight has mean 0.5662 / sigma 0.2862 and
// puts 6.17% of the sheet above the whitecap gate; this remap lands the v3
// field at mean 0.559 / sigma 0.291 and 4.44% above the same gate. (The other
// consumer of that range, the gbuffers_water.vsh displacement clamp, is no
// longer reached under v3 - see the NOTE on WATER_DISPLACEMENT below - but the
// remap is kept so the composite1 whitecap gate stays exactly where v2 put it.)
// Because the division is by the field's OWN sigma, WAVE3_STEEP moves the
// normals without ever moving those thresholds.
#define W3_V2_MEAN 0.5662
#define W3_V2_STD  0.2862
float wave3Height(vec3 wpos, float t) {
    float elev;
    vec2 g;
    wave3Eval(wave3Pos(wpos), t * WAVE_SPEED, WAVE3_SCALES, elev, g);
    return W3_V2_MEAN + W3_V2_STD * elev / max(W3_SIG_N, 1e-6);
}

// World normal. wpos = ABSOLUTE world position of the fragment, vdirW = unit
// world direction from the eye to it, flatK = the grazing-angle constant
// (WAVE3_FLATTEN normally; a larger one would suit Distant Horizons geometry,
// which currently renders flat water and does not call this).
// NO vertex displacement is involved anywhere: the quad stays perfectly flat
// and the whole relief lives in this normal plus the parallax below.
// NOTE on WATER_DISPLACEMENT: the vertex displacement is DISABLED under v3
// (see gbuffers_water.vsh). It fed straight back into the sampling plane -
// wave3Pos subtracts wpos.y, and both the fsh and composite1 read wave3Pos at
// the DISPLACED position - so the vertex offset sheared the field by its own
// coarse height. MEASURED at the shipped defaults: a dy span of 0.210 block,
// 85% of the finest rung's 0.247 block crest pitch, perturbing the normal by
// RMS 3.45 deg / p99 10.90 deg against the field's own 4.56 deg mean tilt.
// v3 is designed for a strictly flat quad anyway: the relief is all normal
// plus parallax.
#if WAVE_LOD == 1
// Nombre de barreaux encore VISIBLES a la distance de vue vdist (derivation
// complete au bloc WAVE_LOD de lib/settings.glsl). Garde le barreau i tant que
// lambda_i >= WAVE_LOD_K empreintes de pixel, soit 2^i <= W3_LOD_C / vdist.
// Un seul log2, pas de palier fige : suit WAVE3_PEAK_LEN automatiquement.
// Plancher a 2 barreaux : la houle porteuse et sa premiere harmonique sont la
// FORME de la mer, jamais du detail - elles ne se coupent jamais.
#define W3_LOD_C ((771.0 / WAVE_LOD_K) * (1.24 * W3_LADDER_TOP * WAVE3_PEAK_LEN))
int wave3OctForDist(float vdist) {
    float n = floor(log2(max(W3_LOD_C / max(vdist, 1.0), 1.0))) + 1.0;
    return int(clamp(n, 2.0, float(WAVE3_SCALES)));
}
#endif

// vdist = distance de vue du fragment, en blocs (WAVE_LOD ; ignore a 0).
vec3 wave3NormalWorld(vec3 wpos, vec3 vdirW, float t, float strength, float flatK, float vdist) {
    float ts = t * WAVE_SPEED;
    vec2 p = wave3Pos(wpos);
    // cos of the view angle against the sheet's geometric normal (+Y).
    // Multiplicative form of the W3_FLAT_NOTE law - no pole, so no clamp on the
    // cosine and att -> 0 cleanly at the horizon. The max() guards ONLY the
    // 0/0 that flatK = 0 (WAVE3_FLATTEN off) would give at exactly grazing.
    float cAtt = abs(vdirW.y);
    float att = (1.0 + flatK) * cAtt / max(cAtt + flatK, 1e-5);
    #if WAVE3_PARALLAX > 0
        // Parallax occlusion, linear search. The ray enters at the crest
        // ceiling (+band) and descends to the trough floor (-band) while
        // sliding along the view direction; the first rung sample that rises
        // above it is the visible point. Because the offset is applied BEFORE
        // the normal is evaluated, shading and occlusion agree.
        if (att > W3_PAR_GATE) {
            float band = W3_PAR_BAND * W3_SIG3;
            // The gate already forces cAtt > flatK/(1+2*flatK) (0.0726 at the
            // default K), so this clamp only ever fires with WAVE3_FLATTEN = 0,
            // where att is 1 everywhere and the gate never closes.
            vec2 slide = vdirW.xz / max(cAtt, 0.02);
            float sl = length(slide);
            if (sl > W3_PAR_MAXSLIDE) slide *= W3_PAR_MAXSLIDE / sl;
            float du = 1.0 / float(WAVE3_PARALLAX);
            float uPrev = 0.0;
            // ray-minus-field at the entry point, taken at the field MEAN
            // (elev = 0) so no extra sample is paid. It only feeds the
            // sub-step refine when the very first probe already hits.
            float dPrev = band;
            float uHit = 0.0;
            for (int k = 1; k <= WAVE3_PARALLAX; k++) {
                float u = float(k) * du;
                float e;
                vec2 gg;
                wave3Eval(p + slide * (2.0 * band * u), ts, W3_PAR_OCT, e, gg);
                float d = band * (1.0 - 2.0 * u) - e; // >0 while the ray is above
                if (d < 0.0) {
                    // C0 refine between the last two probes - no extra sample
                    uHit = uPrev + (u - uPrev) * (dPrev / max(dPrev - d, 1e-5));
                    break;
                }
                uPrev = u;
                dPrev = d;
                uHit = u;
            }
            // Ramp the applied offset across the gate instead of switching it.
            // uHit is nowhere near 0 at the boundary, so the hard switch moved
            // the sampling point by up to 0.70 block and the shading normal by
            // RMS 3.08 deg / p99 7.74 deg (against the field's own 4.56 deg mean
            // tilt) on a ring locked to view distance - it swept over the water
            // as the camera walked and TAA ghosted it rather than resolving it.
            // One smoothstep, zero extra noise samples.
            p += slide * (2.0 * band * uHit)
                 * smoothstep(W3_PAR_GATE, W3_PAR_GATE + W3_PAR_FADE, att);
        }
    #endif
    float elev;
    vec2 g;
#if WAVE_LOD == 1
    // LOD par distance : les barreaux passes sous l'empreinte de pixel ne
    // portent plus que du crenelage (voir wave3OctForDist ci-dessus). La
    // boucle de wave3Eval sort deja sur `i >= nOct` - aucun code mort.
    wave3Eval(p, ts, wave3OctForDist(vdist), elev, g);
#else
    wave3Eval(p, ts, WAVE3_SCALES, elev, g);
#endif
    // Sign convention of this file: slope = -dh/dxz, normal = (slope.x, 1, slope.y).
    // The flattening is applied as a scalar on the tangential part, which is
    // algebraically identical to pushing the normal toward +Y by flat/cos and
    // renormalising, minus one normalize.
    vec2 slope = -g * (strength * att);
    return normalize(vec3(slope.x, 1.0, slope.y));
}
#endif

// Animated Voronoi edges (cell points dancing).
// NOT used by the caustics anymore (the cellular net was decorative: it did
// not derive from the wave field). Kept as a generic building block.
float voroEdge(vec2 p, float t) {
    vec2 ip = floor(p);
    vec2 fp = fract(p);
    float f1 = 8.0;
    float f2 = 8.0;
    for (int x = -1; x <= 1; x++) {
        for (int y = -1; y <= 1; y++) {
            vec2 g = vec2(float(x), float(y));
            vec2 o = vec2(hash12(ip + g), hash12(ip + g + 19.7));
            o = 0.5 + 0.42 * sin(t * 0.7 + o * 6.2831853);
            float d = length(g + o - fp);
            if (d < f1) { f2 = f1; f1 = d; }
            else if (d < f2) { f2 = d; }
        }
    }
    return f2 - f1;
}

/*
    ==================== FULLY ANALYTIC CAUSTICS ====================
    A caustic is the convergence of rays refracted by a SUM OF COSINE WAVE
    TRAINS. The Hessian of a sum of cosines is exact and smooth by
    construction, so there is no finite differencing and no noise. Two train
    families:
      - SWELL: the WAVE_ITERATIONS trains, constants STRICTLY in sync with
        swellEval (amp 0.38*SWELL_AMOUNT, lambda 26, decay 0.60/0.58/1.35,
        q=0.30, spread ang+sin(i*2.4)*0.52, spd 0.60*WAVE_SPEED, warp wp2,
        groups grp) -> the broad pattern rolls with the RENDERED swell.
      - 6 SHORT trains (lambda 5.30/3.70/2.60/1.90/1.35/0.95, NON harmonic
        ratios): the fine net. Directions spread around the wind (alternating
        offsets, +-~52 deg, no two neighbours aligned), distinct initial
        phases, steepness a*k = 0.16..0.10 as a decreasing spectrum, speeds
        from GRAVITY DISPERSION omega ~ sqrt(k) (calibrated on the reference
        train: lambda 26 at 0.60*WAVE_SPEED) -> ripples oscillate faster than
        the swell, as in reality.
    ANTI-GRID: well-spread directions + non-harmonic lambdas + offset phases
    + shared slow warp wp2 (curved fronts) + very-low-frequency PER-TRAIN
    amplitude modulation (gradient neglected, like the swell groups) + the
    swell on top -> rich living interference, no visible lattice.
    EXACT SPECTRAL BLUR: gaussian-blurring the field with radius sigma is
    exactly weighting each train by exp(-0.5*(k*sigma)^2) (Fourier transform
    of the kernel; the filtering happens IN the spectrum). Zero extra taps:
    with depth/distance the fine filaments MELT into wide soft blobs instead
    of switching off.
    PERF: one Hessian per call = WAVE_ITERATIONS+6 trains of a few cos/sin
    each. CAUSTIC_SCALE is INERT (caustic scale IS the wave scale). Pure ALU,
    no uniforms, no 430-only functions: safe in both v120 (gbuffers_water.vsh)
    and v430 (composite1).
*/

// SWELL trains -> Hessian accumulation. h = a*(cos(ph) + q*cos(2ph)) along d
// gives d2h/dd2 = -a*k^2*(cos + 4q*cos2); in world space the contribution is
// (d outer d) * c2. SAME constants as swellEval - KEEP IN SYNC (at
// CAUSTIC_SPEED=1 the phases match the rendered surface exactly).
// sigma = spectral blur radius (see header). Warp and groups are passed in
// (shared with the short trains; their gradients are neglected, they are slow).
void causticSwellH(vec2 wp2, float grp, float t, float sigma,
                   inout float hxx, inout float hzz, inout float hxz) {
    float ang = WIND_DIRECTION * 0.017453293;
    float amp = 0.38 * SWELL_AMOUNT; // sync swellEval
    float lambda = 26.0;
    float spd = 0.60 * WAVE_SPEED;   // sync swellEval - holds at any WAVE_SPEED
    float q = 0.30;                  // sync swellEval (pinched crests)
    for (int i = 0; i < WAVE_ITERATIONS; i++) {
        float aI = ang + sin(float(i) * 2.4) * 0.52; // sync directional spectrum
        vec2 d = vec2(cos(aI), sin(aI));
        float k = 6.2831853 / lambda;
        float ph = dot(wp2, d) * k - t * spd;
        float w1 = exp(-0.5 * k * k * sigma * sigma); // exact spectral blur (fundamental, wavenumber k)
        float w2 = w1 * w1 * w1 * w1;                 // 2nd Stokes harmonic lives at 2k -> exp(-0.5*(2k*sigma)^2) = w1^4
        float c2 = -(amp * grp) * k * k * (cos(ph) * w1 + 4.0 * q * cos(2.0 * ph) * w2);
        hxx += d.x * d.x * c2;
        hzz += d.y * d.y * c2;
        hxz += d.x * d.y * c2;
        amp *= 0.60;
        lambda *= 0.58;
        spd *= 1.35;
    }
}

// One SHORT train: pure cosine (short ripples are nearly sinusoidal, and it
// is cheaper). steep = a*k (steepness) -> the Hessian contribution is
// -steep*k*cos(ph), the amplitude alone is never needed. The amplitude
// modulation (vnoise ~0.02-0.04/block + slow drift, gradient neglected) makes
// the net live region by region instead of looking statistically uniform.
// omg is multiplied by WAVE_SPEED here.
void causticTrainH(vec2 wp2, vec2 p, float t, float ang, float sigma,
                   float lam, float omg, float dOff, float ph0, float steep,
                   float mFrq, vec2 mOff,
                   inout float hxx, inout float hzz, inout float hxz) {
    float k = 6.2831853 / lam;
    float aT = ang + dOff;
    vec2 d = vec2(cos(aT), sin(aT));
    float ph = dot(wp2, d) * k - t * (omg * WAVE_SPEED) + ph0;
    float m = 0.55 + 0.90 * vnoise(p * mFrq + mOff + vec2(t * 0.011, -t * 0.008));
    float w = exp(-0.5 * k * k * sigma * sigma); // exact spectral blur
    float c2 = -steep * k * cos(ph) * m * w;
    hxx += d.x * d.x * c2;
    hzz += d.y * d.y * c2;
    hxz += d.x * d.y * c2;
}

// FULL caustic field: slow warp + groups (sync swellEval), swell, then the 6
// short trains. Columns: lambda | omega (= 0.60*sqrt(26/lambda), gravity
// dispersion) | direction offset (rad, alternating, no two neighbouring
// lambdas aligned) | initial phase | steepness a*k | frequency and offset of
// the amplitude modulation. All constant -> the compiler folds the direction
// cos/sin and the weights.
void causticFieldH(vec2 p, float t, float sigma,
                   out float hxx, out float hzz, out float hxz) {
    float ang = WIND_DIRECTION * 0.017453293;
    vec2 wp2 = p + (vec2(vnoise(p * 0.020 + 3.7), vnoise(p * 0.020 + 9.1)) - 0.5) * 6.5; // sync swellEval
    float grp = 0.62 + 0.38 * vnoise(p * 0.013 + vec2(t * 0.009, -t * 0.007));           // sync swellEval
    hxx = 0.0;
    hzz = 0.0;
    hxz = 0.0;
    causticSwellH(wp2, grp, t, sigma, hxx, hzz, hxz);
    //                                   lam    omega    dir    ph0   a*k    mFrq   mOff
    causticTrainH(wp2, p, t, ang, sigma, 5.30, 1.3289, -0.82, 1.7, 0.160, 0.021, vec2(11.3,  3.1), hxx, hzz, hxz);
    causticTrainH(wp2, p, t, ang, sigma, 3.70, 1.5905,  0.55, 4.2, 0.150, 0.026, vec2( 7.9, 21.4), hxx, hzz, hxz);
    causticTrainH(wp2, p, t, ang, sigma, 2.60, 1.8974, -0.28, 0.9, 0.140, 0.031, vec2( 2.6, 15.8), hxx, hzz, hxz);
    causticTrainH(wp2, p, t, ang, sigma, 1.90, 2.2195,  0.91, 5.5, 0.130, 0.036, vec2(17.2,  8.5), hxx, hzz, hxz);
    causticTrainH(wp2, p, t, ang, sigma, 1.35, 2.6331,  0.16, 2.6, 0.115, 0.024, vec2( 5.4, 27.7), hxx, hzz, hxz);
    causticTrainH(wp2, p, t, ang, sigma, 0.95, 3.1389, -0.61, 3.9, 0.100, 0.033, vec2(23.1, 12.9), hxx, hzz, hxz);
}

// Optics (paraxial refraction, eta = 1/1.33): a vertical refracted ray hits
// the bottom displaced by ~cf*grad(h), with cf ~ (1-eta)*column ~ 0.25*depth.
// Jacobian of the surface->bottom map: J = I + cf*H; received irradiance is
// 1/|det J|. det->0: rays CONVERGE (filament); det>1: divergence (penumbra
// between filaments). Floor 0.10 is the anti-firefly clamp (I caps at 10;
// the soft remap does the rest, no hard clamp here).
float causticIllum(float hxx, float hzz, float hxz, float cf) {
    float a11 = 1.0 + cf * hxx;
    float a22 = 1.0 + cf * hzz;
    float det = a11 * a22 - cf * cf * hxz * hxz;
    return 1.0 / max(abs(det), 0.10);
}

// SOFT anti-firefly remap, CALIBRATED against the fixed thresholds in
// composite1 (site 1: clamp(X*cscale - 0.22..0.30, 0, 1) with cscale
// 0.70..1.30; chroma sites: clamp(X - 0.20..0.25, 0, 1) * exp(-depth*0.13)).
// Reference points (keep them if you retune):
//   flat water det=1 -> I=1 -> base 0.36: clears the thresholds as a DISCREET
//   glow (site 1: 0.03..0.25 before gain) without ever blowing out sand;
//   divergence I<1 -> linear ramp 0.36*I down to 0 (DARK between filaments -
//   light is redistributed, not added); never negative;
//   convergence I ~ 1.6..2.5 (typical) -> 0.87..1.42: crisp filament that
//   saturates downstream at peak cscale;
//   above that: C1 exponential knee (slope continuous at x=1.05) toward the
//   1.65 asymptote - progressive compression, no hard plateau (a flat clamp
//   produces white blotches).
float causticTone(float I) {
    float x = 0.36 * min(I, 1.0) + 0.85 * max(I - 1.0, 0.0);
    float over = max(x - 1.05, 0.0);
    return min(x, 1.05) + 0.60 * (1.0 - exp(-over / 0.60));
}

// LARGE octave (god-rays / modulation): the SAME sum reduced to the SWELL
// trains, wide sigma (0.9) -> big smooth cells that roll with the swell.
// Normalization (floor 0.20, -0.9, saturate, then ^2) must stay: consumers
// (UW_GODRAY_CAUSTIC_LOCK shafts, the 0.55+0.90*large modulation in
// causticCombine) expect a [0..1] value.
float causticLarge(vec2 p, float t) {
    float tt = t * CAUSTIC_SPEED;
    vec2 wp2 = p + (vec2(vnoise(p * 0.020 + 3.7), vnoise(p * 0.020 + 9.1)) - 0.5) * 6.5;
    float grp = 0.62 + 0.38 * vnoise(p * 0.013 + vec2(tt * 0.009, -tt * 0.007));
    float hxx = 0.0;
    float hzz = 0.0;
    float hxz = 0.0;
    causticSwellH(wp2, grp, tt, 0.9, hxx, hzz, hxz);
    // Long focal length of the large octave, driven by CAUSTIC_LARGE_SCALE
    // (default 0.28 -> cf 1.35), floored at 0.3.
    float cf = 4.5 * max(CAUSTIC_LARGE_SCALE, 0.3);
    float a11 = 1.0 + cf * hxx;
    float a22 = 1.0 + cf * hzz;
    float det = a11 * a22 - cf * cf * hxz * hxz;
    float w = clamp(1.0 / max(abs(det), 0.20) - 0.9, 0.0, 1.0);
    return w * w;
}

// GOD-RAY APERTURE MASK - dedicated to the volumetric shafts (composite1,
// UW_GODRAY_CAUSTIC_LOCK==1). DO NOT wire it into the caustic render sites:
// causticLarge (determinant 1/|det J| -> convergence folds are thin LINES by
// nature) stays the source of waveCausticFull/.y. Here we want the opposite
// geometry: well-separated 6-15 block PATCHES with 5-20 blocks of penumbra.
// Principle: curvature (Laplacian hxx+hzz) of a VERY smooth swell field -
// spectral blur sigma grows with the water column (real defocus): only the
// lambda 26/15 trains survive, so the field varies over ~8-16 blocks. Under a
// crest DOME (negative Laplacian = converging lens) the whole sheet focuses
// -> a WIDE light column; under troughs, penumbra. Soft smoothstep threshold,
// no determinant.
// /SWELL_AMOUNT normalization keeps the column geometry independent of the
// amplitude slider (0 = flat sea -> null mask, consistent).
// Calibration (normalized, WAVE_ITERATIONS=3, mean grp 0.81): per-train
// curvature amplitudes ~0.030/0.034/0.024 -> RMS ~0.029; low threshold 0.015
// (~0.5 sigma, ~30% of the area lightly touched), full 0.055 (~1.9 sigma, ~3%
// = dome cores). At WAVE_QUALITY 0 (2 trains) RMS ~0.024, slightly rarer
// columns. Animated by the SAME phases as the rendered swell (warp, groups,
// speeds in sync) so columns drift ~2.5 blocks/s and breathe with the wave
// groups. COST: identical to causticLarge - it is a replacement, not an add.
float causticShaftMask(vec2 p, float t, float depthM) {
#if VLX_PHYS_SYNC == 1
    // PHYSICS_FIELD_SYNC : sous l'ocean du mod, les gerbes larges viennent du
    // Laplacien fenetre de SON champ, pas de la houle du pack. MEMES seuils,
    // donc meme geometrie de gerbes (aires mesurees dans vlxPhysShaftLap) et
    // aucun retunage des dials UW_SHAFT_FINESSE / UW_SHAFT_SCALE. Branche
    // uniforme par pixel. `t` n'est pas lu : l'horloge est celle du mod
    // (vlxPhysT), c'est ce qui synchronise les gerbes aux cretes visibles.
    if (vlxPhysOn > 0.5) {
        return smoothstep(0.022 * UW_SHAFT_FINESSE, 0.080 * UW_SHAFT_FINESSE,
                          vlxPhysShaftLap(p, depthM));
    }
#endif
    float tt = t * CAUSTIC_SPEED;
    vec2 wp2 = p + (vec2(vnoise(p * 0.020 + 3.7), vnoise(p * 0.020 + 9.1)) - 0.5) * 6.5; // sync swellEval
    float grp = 0.62 + 0.38 * vnoise(p * 0.013 + vec2(tt * 0.009, -tt * 0.007));         // sync swellEval
    float hxx = 0.0;
    float hzz = 0.0;
    float hxz = 0.0;
    // Base sigma 1.15 keeps the lambda~8.75 train alive (weight ~0.71) -> fine
    // 3-6 block BLADES elongated along the swell, spaced 4-10 blocks, rather
    // than round 8-16 block blobs. Raise it for wider, rounder patches.
    float sigma = (1.15 + min(depthM * 0.019, 0.45)) * UW_SHAFT_SCALE; // UW_SHAFT_SCALE = spacing between blades; depth term = soft defocus with the water column
    causticSwellH(wp2, grp, tt, sigma, hxx, hzz, hxz);
    float lap = -(hxx + hzz) / max(SWELL_AMOUNT, 0.25); // >0 under crests (converging lens)
    // Thresholds scaled by UW_SHAFT_FINESSE (default 1.3) -> 2-4 block shafts
    // separated by 10-20 blocks of penumbra.
    return smoothstep(0.022 * UW_SHAFT_FINESSE, 0.080 * UW_SHAFT_FINESSE, lap);
}

// SMALL caustic (high frequency). sharp in [0..1]: 1=crisp, 0=soft.
// KEEP THIS SIGNATURE (composite1 god-rays; sharp decreases with toSurf).
// No depth is passed, so a proxy column is used: crisp ~ 1.6 blocks (short
// ripple focal length), soft ~ 6 blocks. The blur lives in sigma (spectral).
float causticSmall(vec2 p, float t, float sharp) {
    // CAUSTIC_SPEED 1.0 = EXACT sync with the surface (the swell trains land
    // on swellEval's phases); != 1.0 deliberately desyncs the caustic from the
    // waves (stylized).
    float tt = t * CAUSTIC_SPEED;
    float s = clamp(sharp, 0.0, 1.0);
    float hxx, hzz, hxz;
    causticFieldH(p, tt, mix(0.85, 0.12, s), hxx, hzz, hxz); // sigma capped at 0.85 (see causticCombine)
    float cf = 0.25 * clamp(mix(6.0, 1.6, s), 1.2, 8.0) * CAUSTIC_FOCUS; // 1.2 floor matches causticCombine (inert here, mix >= 1.6)
    return causticTone(causticIllum(hxx, hzz, hxz, cf));
}
// Compat entry point, behaviour IDENTICAL to causticSmall(sharp=1).
float waveCaustic(vec2 p, float t) {
    return causticSmall(p, t, 1.0);
}

// Shared worker for Full/Soft: ONE field blurred by blurTotal (sigma =
// mix(0.12, 0.85, blurTotal)), focal length from the REAL depth (cf = 0.25 *
// column * CAUSTIC_FOCUS), large octave used as MODULATION (never additive).
// .x = combined net (render), .y = large octave alone (god-rays).
// The 0.85 sigma cap matters: at sigma 1.8 the short-train spectral weights
// collapse (0.10 at lambda 5.3, 0.009 at 3.7, ~0 below) leaving only the
// lambda-26 swell -> flat 0.36 output, under composite1's 0.20..0.30
// thresholds, i.e. nothing on screen. At 0.85: lambda 5.3 keeps w ~ 0.60, 3.7
// ~ 0.35, 2.6 ~ 0.12 -> credible defocus (wide soft dancing blobs) instead of
// extinction. Typical values at defaults (2-3 block column): filaments
// causticTone ~ 1.1..1.5, flat zone ~ 0.36.
vec2 causticCombine(vec2 p, float t, float depthM, float blurTotal) {
    float tt = t * CAUSTIC_SPEED; // 1.0 = exact sync (see causticSmall)
    float hxx, hzz, hxz;
    causticFieldH(p, tt, mix(0.12, 0.85, blurTotal), hxx, hzz, hxz);
    // Focal floor 1.2: the ripple focus sits at ~1 block of column, where real
    // filaments are already sharp; a lower floor makes them timid.
    float cf = 0.25 * clamp(depthM, 1.2, 8.0) * CAUSTIC_FOCUS;
    float fine = causticTone(causticIllum(hxx, hzz, hxz, cf));
    float large = causticLarge(p, t);
    // The large octave MODULATES the fine net around 1.0 (never an additive
    // cyan patch). lm saturates at 1.0 once CAUSTIC_LARGE_STRENGTH >= 2.0.
    float lm = clamp(CAUSTIC_LARGE_STRENGTH * 0.5, 0.0, 1.0);
    return vec2(fine * mix(1.0, 0.55 + 0.90 * large, lm), large);
}
// Depth defocus window. Real caustics are SHARPEST at 1-4 blocks of column
// (ripple focal length) and only defocus beyond ~8-15 m. So: full sharpness
// up to 2.5 blocks, then a fade over a window of 4x the slider (min 8 blocks)
// - at the 3.0 default, full blur around ~14.5 blocks, where the water already
// hides the bottom anyway. A window narrower than this puts full sigma inside
// the physically sharp zone (invisible caustics, milky bottom).
// Slider semantics: higher = later/softer defocus, lower = earlier/stronger.
float causticDepthBlur(float depthM) {
    return clamp((depthM - 2.5) / max(CAUSTIC_DEPTH_BLUR * 4.0, 8.0), 0.0, 1.0);
}
// Small + large + depth blur. depthM = water column in blocks.
// The depth blur removes the short trains SPECTRALLY (fine filaments melt
// into wide swell-borne blobs): the caustic widens and softens physically
// instead of fading out.
vec2 waveCausticFull(vec2 p, float t, float depthM) {
    float blurTotal = causticDepthBlur(depthM);
    return causticCombine(p, t, depthM, blurTotal);
}
// Distance fade-to-blur: like waveCausticFull but with blurX [0..1] driven by
// EYE DISTANCE. The 1-(1-a)(1-b) combination stays bounded by 1, so far away
// the caustic is WIDE and SOFT but still present. blurX=0 == Full exactly.
vec2 waveCausticSoft(vec2 p, float t, float depthM, float blurX) {
    float dB = causticDepthBlur(depthM);
    float blurTotal = 1.0 - (1.0 - dB) * (1.0 - clamp(blurX, 0.0, 1.0));
    return causticCombine(p, t, depthM, blurTotal);
}
// TRUE chromatic dispersion, nearly free: the index of water varies with
// wavelength -> the FOCAL LENGTH varies per channel. ONE field, 3 determinants
// with a scaled cf (x0.975 R / 1.0 G / x1.035 B ~ n(lambda)): near the focus
// (det->0) the per-channel gap blows up, giving a subtle spectral fringe on
// the EDGE of the filaments, exactly where it shows in reality.
// chromOff is IGNORED (legacy spatial offset of the voronoi net); dispersion
// now lives in the focal length. Signature kept for composite1.
vec3 waveCausticChroma(vec2 p, float t, float depthM, float blurX, vec2 chromOff) {
    float dB = causticDepthBlur(depthM);
    float blurTotal = 1.0 - (1.0 - dB) * (1.0 - clamp(blurX, 0.0, 1.0));
    float tt = t * CAUSTIC_SPEED;
    float hxx, hzz, hxz;
    causticFieldH(p, tt, mix(0.12, 0.85, blurTotal), hxx, hzz, hxz); // sigma capped at 0.85
    float cf = 0.25 * clamp(depthM, 1.2, 8.0) * CAUSTIC_FOCUS;      // focal floor 1.2
    float large = causticLarge(p, t);
    float lm = clamp(CAUSTIC_LARGE_STRENGTH * 0.5, 0.0, 1.0);
    float lgMod = mix(1.0, 0.55 + 0.90 * large, lm);
    vec3 disp = vec3(0.975, 1.0, 1.035); // n(red) < n(green) < n(blue)
    vec3 outC;
    for (int c = 0; c < 3; c++) {
        outC[c] = causticTone(causticIllum(hxx, hzz, hxz, cf * disp[c])) * lgMod;
    }
    return outC;
}
// Anti-repetition foam pattern: 2-pass domain warp + octave rotation.
float foamPattern(vec2 p, float t, float s) {
    p *= s;
    vec2 w1 = vec2(fbm(p * 0.35 + vec2(t * 0.05, -t * 0.04)),
                   fbm(p * 0.35 + vec2(5.2 - t * 0.045, 1.7 + t * 0.05)));
    p += (w1 - 0.5) * 2.4;
    p = mat2(0.80, 0.60, -0.60, 0.80) * p;
    vec2 w2 = vec2(fbm(p * 0.9 - vec2(t * 0.07, t * 0.05)),
                   fbm(p * 0.9 + vec2(t * 0.06, 3.1 - t * 0.055)));
    p += (w2 - 0.5) * 1.1;
    return fbm(p * 1.6 + t * 0.10);
}

// ================= CACHED CAUSTIC PATH (manual CSE) =================
// Same math as waveCausticFull/Soft, but the work the original path pays
// TWICE per pixel (once in causticFieldH, once in causticLarge, both with
// the SAME p and tt) is evaluated ONCE:
//   - wp2 slow warp (2 vnoise) and grp groups (1 vnoise): hoisted, 3 vnoise
//     saved per pixel;
//   - the WAVE_ITERATIONS swell trains: per train d, k, ph, cos(ph) and
//     cos(2*ph) are sigma-independent; only the spectral weights w1/w2
//     differ between the fine sigma and the large sigma (0.9). One loop
//     accumulates BOTH Hessians -> WAVE_ITERATIONS train phase/trig
//     evaluations saved per pixel.
// Every arithmetic expression matches the originals term for term (same
// parse tree), so the output is bit-identical -- no gate needed. Consumed
// by composite1 water site 1 only; the UW caustic sites and the VL keep
// the original entry points.

// Dual-sigma swell Hessian: one phase evaluation, two spectral weightings.
// Constants sync swellEval / causticSwellH - KEEP ALL THREE IN SYNC.
void causticSwellH2_cached(vec2 wp2, float grp, float t, float sigmaA, float sigmaB,
                           inout float hxxA, inout float hzzA, inout float hxzA,
                           inout float hxxB, inout float hzzB, inout float hxzB) {
    float ang = WIND_DIRECTION * 0.017453293;
    float amp = 0.38 * SWELL_AMOUNT; // sync swellEval
    float lambda = 26.0;
    float spd = 0.60 * WAVE_SPEED;   // sync swellEval
    float q = 0.30;                  // sync swellEval (pinched crests)
    for (int i = 0; i < WAVE_ITERATIONS; i++) {
        float aI = ang + sin(float(i) * 2.4) * 0.52; // sync directional spectrum
        vec2 d = vec2(cos(aI), sin(aI));
        float k = 6.2831853 / lambda;
        float ph = dot(wp2, d) * k - t * spd;
        // Shared per-train terms (sigma-independent)
        float cp  = cos(ph);
        float cp2 = cos(2.0 * ph);
        float base = -(amp * grp) * k * k;
        // Per-sigma spectral weights (2nd harmonic at 2k -> w^4, see causticSwellH)
        float w1A = exp(-0.5 * k * k * sigmaA * sigmaA);
        float w2A = w1A * w1A * w1A * w1A;
        float w1B = exp(-0.5 * k * k * sigmaB * sigmaB);
        float w2B = w1B * w1B * w1B * w1B;
        float cA = base * (cp * w1A + 4.0 * q * cp2 * w2A);
        float cB = base * (cp * w1B + 4.0 * q * cp2 * w2B);
        hxxA += d.x * d.x * cA;
        hzzA += d.y * d.y * cA;
        hxzA += d.x * d.y * cA;
        hxxB += d.x * d.x * cB;
        hzzB += d.y * d.y * cB;
        hxzB += d.x * d.y * cB;
        amp *= 0.60;
        lambda *= 0.58;
        spd *= 1.35;
    }
}

// Large octave from a PRECOMPUTED swell Hessian (math sync causticLarge).
float causticLargeH_cached(float hxx, float hzz, float hxz) {
    float cf = 4.5 * max(CAUSTIC_LARGE_SCALE, 0.3); // sync causticLarge
    float a11 = 1.0 + cf * hxx;
    float a22 = 1.0 + cf * hzz;
    float det = a11 * a22 - cf * cf * hxz * hxz;
    float w = clamp(1.0 / max(abs(det), 0.20) - 0.9, 0.0, 1.0);
    return w * w;
}

// Cached worker: math sync causticCombine (fine sigma mix(0.12,0.85), large
// sigma 0.9, focal floor 1.2, large-octave modulation) and causticFieldH
// (short train table VERBATIM). wp2/grp computed once, swell trains walked
// once for both Hessians.
vec2 causticCombine_cached(vec2 p, float t, float depthM, float blurTotal) {
    float tt = t * CAUSTIC_SPEED; // 1.0 = exact sync (see causticSmall)
    float ang = WIND_DIRECTION * 0.017453293;
    vec2 wp2 = p + (vec2(vnoise(p * 0.020 + 3.7), vnoise(p * 0.020 + 9.1)) - 0.5) * 6.5; // sync swellEval
    float grp = 0.62 + 0.38 * vnoise(p * 0.013 + vec2(tt * 0.009, -tt * 0.007));         // sync swellEval
    float sigma = mix(0.12, 0.85, blurTotal); // sigma capped at 0.85 (see causticCombine)
    float hxx = 0.0; float hzz = 0.0; float hxz = 0.0; // fine field
    float lxx = 0.0; float lzz = 0.0; float lxz = 0.0; // large octave
    causticSwellH2_cached(wp2, grp, tt, sigma, 0.9, hxx, hzz, hxz, lxx, lzz, lxz);
    //                                    lam    omega    dir    ph0   a*k    mFrq   mOff   (VERBATIM causticFieldH)
    causticTrainH(wp2, p, tt, ang, sigma, 5.30, 1.3289, -0.82, 1.7, 0.160, 0.021, vec2(11.3,  3.1), hxx, hzz, hxz);
    causticTrainH(wp2, p, tt, ang, sigma, 3.70, 1.5905,  0.55, 4.2, 0.150, 0.026, vec2( 7.9, 21.4), hxx, hzz, hxz);
    causticTrainH(wp2, p, tt, ang, sigma, 2.60, 1.8974, -0.28, 0.9, 0.140, 0.031, vec2( 2.6, 15.8), hxx, hzz, hxz);
    causticTrainH(wp2, p, tt, ang, sigma, 1.90, 2.2195,  0.91, 5.5, 0.130, 0.036, vec2(17.2,  8.5), hxx, hzz, hxz);
    causticTrainH(wp2, p, tt, ang, sigma, 1.35, 2.6331,  0.16, 2.6, 0.115, 0.024, vec2( 5.4, 27.7), hxx, hzz, hxz);
    causticTrainH(wp2, p, tt, ang, sigma, 0.95, 3.1389, -0.61, 3.9, 0.100, 0.033, vec2(23.1, 12.9), hxx, hzz, hxz);
    float cf = 0.25 * clamp(depthM, 1.2, 8.0) * CAUSTIC_FOCUS; // focal floor 1.2 (sync causticCombine)
    float fine = causticTone(causticIllum(hxx, hzz, hxz, cf));
    float large = causticLargeH_cached(lxx, lzz, lxz);
    float lm = clamp(CAUSTIC_LARGE_STRENGTH * 0.5, 0.0, 1.0);
    return vec2(fine * mix(1.0, 0.55 + 0.90 * large, lm), large);
}

// Drop-in cached entry points -- output identical to waveCausticFull/Soft.
vec2 waveCausticFull_cached(vec2 p, float t, float depthM) {
    float blurTotal = causticDepthBlur(depthM);
    return causticCombine_cached(p, t, depthM, blurTotal);
}
vec2 waveCausticSoft_cached(vec2 p, float t, float depthM, float blurX) {
    float dB = causticDepthBlur(depthM);
    float blurTotal = 1.0 - (1.0 - dB) * (1.0 - clamp(blurX, 0.0, 1.0));
    return causticCombine_cached(p, t, depthM, blurTotal);
}

// ================= FAST WATER NORMALS (WAVE_FAST_NORMALS) =================
// ADDITIVE fast path for the legacy choppy V2 normals (WAVES_V2=1,
// WAVE_NORMALS_V3=0). Two savings over waveNormalWorld:
//   (a) manual CSE: the wind-space transform of waveChopLOD (rotation +
//       anisotropy) is LINEAR in p, so it is applied ONCE and the two
//       finite-difference offsets become constant vectors in wind space
//       (the per-octave warps/rotations depend on the SHIFTED uv and stay
//       per-call - they cannot be fused);
//   (b) tighter octave LOD, measured at 1080p (fov 70 -> focal ~771 px, eye
//       ~1.8 bl above water; ground footprint per pixel along view ~
//       d^2/(771*1.8)). Per octave the uv domain scales x~2.0 AND freq x1.9,
//       so wavelengths are ~8.7 / 2.3 / 0.61 / 0.16 bl. Nyquist (lambda/2 per
//       pixel): octave 3 is sub-pixel past ~11 bl, octave 2 past ~21-45 bl.
//       New tiers: 4 octaves < ~17 bl (chopFade > 0.60), 3 < ~58 (> 0.30),
//       2 < ~288 (> 0.08), 1 beyond (slopeAtt floor 0.30 hides the residue).
//       Legacy tiers were 4 < 25 bl and 3 < 142 bl.
// NOTE a 2-call chop gradient is NOT offered: the field is scalar and a 2D
// gradient needs 3 samples minimum (forward differences are already in use;
// "central on one axis" would ADD a 4th sample, not remove one).
// Epsilon, slope attenuation, swell and micro-grain match waveNormalWorld
// term for term - at equal octave count the output is bit-identical.
#if WAVE_FAST_NORMALS == 1 && WAVES_V2 == 1
// Chop with PRE-TRANSFORMED wind-space uv. Body sync waveChopLOD (WAVES_V2
// branch) minus the transform - KEEP IN SYNC.
float waveChopUVFast(vec2 uv, float t, int oct) {
    float freq = 0.115;
    float amp = 0.40;
    float choppy = 2.4;
    float tt = 1.0 + t * 0.8 * WAVE_SPEED;

    float h = 0.0;
    for (int i = 0; i < 5; i++) {
        if (i >= oct) break;
        float d = seaOctave((uv - vec2(tt, tt * 0.14)) * freq, choppy)
                + seaOctave((uv - vec2(tt * 0.55, -tt * 0.09)) * freq * 1.13, choppy);
        h += d * amp;
        uv = mat2(1.92, 0.55, -0.55, 1.92) * uv;
        freq *= 1.9;
        amp *= 0.22;
        choppy = mix(choppy, 1.0, 0.3);
    }
    return h;
}

vec3 waveNormalWorldFast(vec2 p, float t, float strength, float chopFade) {
    float ang = WIND_DIRECTION * 0.017453293;
    vec2 wx = vec2(cos(ang), sin(ang)); // compile-time constants (WIND_DIRECTION is a define)
    // uv(p) = (dot(p,wx)*1.06, dot(p,(-wx.y,wx.x))*0.78) - sync waveChopLOD
    vec2 uv0 = vec2(dot(p, wx) * 1.06, dot(p, vec2(-wx.y, wx.x)) * 0.78);
    // Tight LOD tiers (see header). chopFade 0.60/0.30/0.08 = ~17/58/288 bl.
    int oct = (chopFade > 0.60) ? 4 : ((chopFade > 0.30) ? 3 : ((chopFade > 0.08) ? 2 : 1));
    float e = mix(0.16, 0.11, clamp(chopFade, 0.0, 1.0)); // sync waveNormalWorld
    // World-space finite-difference offsets mapped through the linear transform
    vec2 dux = vec2(wx.x * 1.06, -wx.y * 0.78) * e; // +x world step in uv space
    vec2 duz = vec2(wx.y * 1.06,  wx.x * 0.78) * e; // +z world step in uv space
    float h0 = waveChopUVFast(uv0, t, oct);
    float hx = waveChopUVFast(uv0 + dux, t, oct);
    float hz = waveChopUVFast(uv0 + duz, t, oct);
    float slopeAtt = mix(0.30, 0.85, clamp(chopFade, 0.0, 1.0)); // sync waveNormalWorld
    vec2 slope = vec2((h0 - hx) / e, (h0 - hz) / e) * strength * slopeAtt;
    // ANALYTIC swell slope, sync waveNormalWorld (WAVES_V2 guaranteed here)
    float swellAtt = mix(0.75, 1.0, clamp(chopFade, 0.0, 1.0));
    slope -= swellSlope(p, t) * strength * swellAtt * 1.25;
    #ifdef WATER_MICRONORMAL
        // High-frequency grain, near-field only (sync waveNormalWorld)
        float mf = smoothstep(0.45, 0.95, chopFade);
        if (mf > 0.001) {
            float md = 0.06;
            vec2 q = p * 3.7 + vec2(t * 0.45, -t * 0.33);
            float n0 = vnoise(q);
            float nx = vnoise(q + vec2(md, 0.0));
            float nz = vnoise(q + vec2(0.0, md));
            slope += vec2((n0 - nx) / md, (n0 - nz) / md) * strength * mf * 0.07;
        }
    #endif
    return normalize(vec3(slope.x, 1.0, slope.y));
}
#endif

/*
    ================= CAUSTICS V4 - PHOTON DENSITY NET =================
    CAUSTICS_V4 == 0 compiles NOTHING of this and leaves every v3 entry point
    above untouched (bit-identical render) - the gate exists to A/B the two in
    game.

    TECHNIQUE AND ATTRIBUTION. The METHOD is forward photon splatting read as a
    kernel density estimate: photons are pushed through a refracting interface,
    and the arrival density at a receiver is estimated by summing a compact
    kernel over the photons that land near it. That method is public and free to
    use. Its three ingredients each have a standard published source - forward
    light tracing for caustics (J. Arvo, "Backward Ray Tracing", SIGGRAPH 1986
    course notes 12), the photon map, whose radiance estimate IS this density
    estimate (H. W. Jensen, "Global Illumination using Photon Maps",
    Eurographics Rendering Workshop 1996), and the quadratic max(0, 1 - r^2/h^2)
    splat, which is Epanechnikov's kernel (1969), the minimum-variance choice
    among compact kernels.
    EVERYTHING ELSE HERE IS DERIVED IN THIS FILE. The wave FIELD (four
    value-noise octaves, the two dominant ones ridged, analytic gradients from
    vnoiseD, no lookup texture anywhere), the AFFINE three-evaluation kernel
    that replaces per-photon field lookups, the Jacobian clamp, the distance
    defocus, the refraction slide, and EVERY calibration constant - photon
    spacing, photon count, splat radius, output floor, gain, knee, asymptote,
    out-of-water gain, Jacobian probe, ridge width and both renormalisation
    curves - were measured on THIS field. The CALIBRATION section below gives,
    for each one, the criterion used, the measurement made and the value it
    produced; no constant here is taken from another shader.
    ONE EXCEPTION, named rather than glossed over: CA4_DEV (1.60) is a TASTE
    DIAL. No threshold selects 1.60 over 1.4 or 1.9 - entry 1 documents its
    measured CONSEQUENCE (58.7% of the floor dark), not a derivation, and
    settings.glsl presents it as a dial. Everything else below is either solved
    for a stated constraint or selected by a written numeric criterion.

    v3 DRAWS a caustic: the Hessian of a sum of wave trains feeds a brightness
    curve, so brightness is a formula evaluated at the shade point. v4
    MEASURES one. It is a FORWARD PHOTON SPLATTING density estimator: a patch
    of a virtual water surface one block above the shade point is sampled by 9
    photons, each photon is deflected by the LOCAL WAVE SLOPE, dropped one
    block, and the estimator COUNTS how many land inside a 0.144-block disc
    around the point. Brightness is never written anywhere - it IS the arrival
    density. Closed cells, forking filaments, loops and hard cusps come out of
    that on their own; a sum of wave trains can only ever produce streaks
    correlated with slope or curvature, never a fold and never a cusp.

    WHERE THE LIGHT COMES FROM (the whole term hangs on ONE direction).
    Every site that reads this estimator passes lightW =
    normalize(mat3(gbufferModelViewInverse) * shadowLightPosition), i.e. the
    active star in WORLD space, already carrying sunPathRotation (-35 deg,
    lib/settings.glsl) - literally the vector the shadow map is built on, so
    the net, the shadows and the god-ray columns are all cast by the same sun.
    That direction enters in three places, and all three are Snell at a flat
    air/water dioptre with eta = 1/1.3333:
      - vlCa4Offset slides the LOOKUP on the virtual surface one block up, by
        tan(theta_t) * depth along the sun azimuth. Zero with the sun
        overhead, 1.134 * depth at the horizon (the refracted ray tops out at
        48.6 deg, so the slide can never run away).
      - vlCa4Aniso stretches the photon THROW along that same azimuth, at
        constant area: identity overhead, 1.512 along / 0.661 across at the
        horizon. This is what makes the mesh elongate toward the low sun
        instead of staying a fixed isotropic pattern.
      - the same offset positions the volumetric shafts AND the wide sheaf
        mask in composite1.fsh / lib/vl_halfres.glsl, so a beam in the water
        and the spot it lights on the floor are one filament. Underwater light
        columns therefore respect the 48.6 deg Snell cone, which the older raw
        lightW.xz/lightW.y projection did not.

    WHY THE NET IS A NETWORK (read this before retuning anything).
    A photon launched at s lands at s + G*grad(h)(s). A receiver at x0 is lit
    when photons launched inside its own +-0.15 block neighbourhood come back
    down on it, i.e. when |G*grad h| is small: THE FILAMENTS ARE THE LEVEL SET
    {|grad h| small}. For an ordinary noise field that set is a handful of
    isolated blobs (the critical points) and looks like nothing. RIDGING an
    octave changes its topology: the ridge fold multiplies that octave's
    gradient by a factor that passes through ZERO on the crease, and the
    crease is the level set {n = 0.5}, i.e. a CURVE. So a ridged octave turns
    the "flat" set one-dimensional - a mesh of closed curves spaced by its own
    lattice. Two ridged octaves (1.75 and 3.70 blocks here) give a two-scale
    mesh whose crossings are the cusps; the two fine octaves are held to ~17%
    of the gradient budget on purpose, which is exactly enough to bend, break
    and reconnect the curves without erasing them. The ridge is not a
    decoration, it is what makes the pattern a net.
    Second job of the ridge: on the crease the octave's gradient vanishes
    while its CURVATURE spikes (the fold is rounded over a width m). So on the
    filament, and only there, the photons both land on target AND get squeezed
    together by the fold - that is what lifts the peak from ~3 photons to 9
    and produces the measured 10.1:1 contrast. Both halves of the look come
    from one trick.

    HOW IT IS MADE CHEAP. grad(h) is evaluated three times (centre + two
    offsets) to get the deflection AND its Jacobian; all 9 photons are then
    pushed through that affine model and splatted analytically. 3 field
    evaluations instead of 9, no precomputed world tile: no buffer, no tile
    seam, nothing to store, and the net is the same at every scale. The
    gradient itself is analytic (vnoiseD, lib/common.glsl), so no finite
    differencing of the height is paid either - the height is never computed.
    HONEST ABOUT ITS ACCURACY: the affine model is a SURROGATE, not a valid
    Taylor expansion. Measured over the 0.33-block aperture against the true
    field, its landing point is 0.253 block from the true one (RMS), i.e. 1.76
    splat radii, because the deflection field decorrelates over roughly the
    aperture itself. What it does preserve is the structure that makes the
    pattern: the affine estimator correlates 0.859 with the exact 9-lookup
    estimator ON THE CONVERGED FIELD, and 0.79 per frame at the same dither -
    both are written here because the two denominators differ by 0.07 and the
    number is meaningless without one. Against a 5.76M photon reference it
    reaches 0.395 with the true density (the exact one reaches 0.538). So this
    is a STYLISED density estimator - the folds, the cusps and the level-set
    topology are real, the per-pixel value is a cheap surrogate.
    Anything read off it (see CALIBRATION) is calibrated against the true
    density, never assumed equal to it.

    CALIBRATION. Every constant below was derived from a measurement on THIS
    field, at the default dials and at CA4_SCALE 0.5 (the smallest the dial
    allows, therefore the binding case: the field's wavelengths scale with the
    dial, the photon grid does not). Each entry gives the criterion, then the
    number it produced.
      1. CA4_DEV, the photon throw per unit of slope (1.60). THIS ONE IS THE
         TASTE DIAL - what follows is its measured consequence, not a
         derivation, because no threshold is fixed that would pick 1.60 over
         1.4 or 1.9. Measured slope RMS 0.290 at CA4_SCALE 1.0, so a typical
         photon is thrown 0.464 block, well outside the 0.144-block catch
         radius: 58.7% of the floor sits exactly on the floor value, PER
         FRAME (re-measured 58.6% over six independent patches). That
         qualifier matters: the jitter fills the dark plains in as TAA
         accumulates, and the same fraction measures 44% after 8 frames and
         41% after 96. Only where the slope collapses (the
         crease curves) do the photons land back on target. Raise it: rarer,
         thinner, more dramatic - and, thanks to entry 7, at nearly the same
         exposure (see the drift budget at vlCa4Mean).
      2. PHOTON SPACING 0.110 block. Criterion: sample the wavefront at a fixed
         fraction of its smallest significant wavelength. Measured by FFT of
         the slope field (four Hann-windowed 16x16-block patches, 1024^2):
         50% of the slope variance lies above 0.916 block, 90% above 0.543,
         98% above 0.3305. The dominant gradient is the RIDGED 1.75*CA4_SCALE
         octave with 81.2% of the variance (13.6% / 2.7% / 0.7% for the other
         three); its ridge crease is what puts energy below its own lattice.
         Taking 3 samples per shortest significant wavelength - Nyquist's 2
         plus the usual quadrature margin, since the field is not band-limited
         - gives 0.3305 / 3 = 0.110 block. Residual: 0.49% of the slope
         variance sits above this grid's Nyquist, which misplaces a photon by
         0.033 block RMS, 23% of the splat radius.
      3. PHOTON COUNT 3x3 = 9. Swept at the spacing and radius above. NOISE IS
         the RMS residual after an 8-frame BOX average, as a percentage of the
         term's own PEAK-TO-FLOOR RANGE (0.259..2.61, span 2.35). The
         denominator is spelled out because "% of contrast" is not a defined
         quantity: measured against the field's standard deviation (0.860)
         instead, the same residual reads 20%, not 7.2%. Note also that the
         pack's TAA is an exponential accumulator, not a box average over 8, so
         these are a floor on the residual, not a prediction of it. Cost is
         splat ALU on top of the ~600 ALU the three field evaluations cost:
              n     contrast/mean   TAA-8 noise/contrast   splats   corr. with truth
             2x2        3.30              9.9%                4          0.369
             3x3        2.94              7.2%                9          0.395
             4x4        2.72              5.9%               16          0.404
             5x5        2.57              5.1%               25          0.403
         The aperture is n * spacing, and it is a low-pass on the caustic: past
         3x3 the extra photons buy smoothing, not accuracy - correlation with
         the true density is flat from 3x3 on (0.395 / 0.404 / 0.403) while
         contrast keeps falling (-7.6% then -5.4%). 2x2 saves only 7% of the
         term's total cost and gives up 37% in noise. 3x3 is the knee.
      4. SPLAT RADIUS 0.1439 block, ratio 1.3085. Criterion: the estimator must
         be unbiased and hole-free, i.e. the kernels of an UNDEFLECTED regular
         grid must sum to a constant. Measured RMS ripple of that lattice sum
         across one cell against the ratio radius/spacing: 3.02% at 1.280,
         crossing under 2% first at 1.3085 (1.99% RMS, 8.9% peak-to-peak),
         staying under until 1.361 (1.9975% at 1.361, 2.0083% at 1.3615), with
         an interior minimum of 1.65% at 1.330. Criterion = the FIRST ratio
         under 2%, i.e. the smallest radius that is already unbiased: 1.3085,
         hence 1.3085 * 0.110 = 0.1439 block.
         A quadratic kernel on a square lattice never reaches a true partition
         of unity: swept on a 0.001 grid with 512^2 points per cell, the best
         over [1, 2] is 1.31% RMS at ratio 1.882 (1.43% at 1.924), at 2.1x the
         kernel overlap and a visibly fatter estimator - so "first under
         threshold" is the right reading, not "global minimum". This is
         geometry, not taste: any quadratic-kernel square-lattice estimator
         lands near 1.3.
      5. GROUND TRUTH, used by entries 6 to 8. 5.76M jittered photons launched
         over 12x12 blocks, deflected by the true field, splatted with the same
         kernel. Mean 1.021 (photon conservation to 2%, a boundary effect).
         Normalised to mean 1: p1 0.107, p5 0.192, p10 0.259, p25 0.421,
         p50 0.751, p75 1.290, p90 2.050, p95 2.623, p99 4.186, max 9.37. The
         top 5% of the area carries 18.1% of the light.
      6. OUTPUT FLOOR 0.2594 = the true density's tenth percentile. The floor
         is what the term returns when all 9 photons miss, so it must be the
         level a real fold-free cell actually receives - not zero, and not the
         estimator's own blind spot. KNEE 2.0498 = the true p90 and ASYMPTOTE
         2.6233 = the true p95: above the true 90th percentile the map
         compresses, and the ceiling is the true 95th. The 5% clipped there
         carries 18% of the light and reaches 9.4x the mean unclipped, which no
         exposure carries - that clip is the one deliberate departure from the
         measured density, and this is it stated plainly.
      7. GAIN 1.5037 / vlCa4S0(de). Not chosen - SOLVED: it is the single value
         that makes the mean of the shaped term exactly 1.000000 on the
         calibration set at the default deflection (1.011 when the finished
         term is re-measured on an independent patch). Exposure neutrality is
         therefore a solved constraint, not a gain picked by eye. Resulting
         distribution at the defaults, submerged, PER FRAME (see entry 1 on why
         that qualifier is here): floor 0.259 over 58.7% of the
         area, p75 2.32, p90 2.53, p95 2.56, max 2.61 - a 10.1:1 range and a
         BIMODAL histogram (large dark plains, a few very bright peaks). A sum
         of wave trains cannot produce that: its own histogram is near-gaussian
         and reads as a modulation, not as a net. Filament width 0.26 block and
         mesh pitch 1.66 block, both from the autocorrelation of the converged
         field.
      8. OUT-OF-WATER GAIN 0.733. Criterion: the contrast the interface has
         already destroyed before the eye sees it. Seen from the bank, the
         floor is viewed through the wavy surface; the part of the refraction
         displacement that is common to a whole filament is a warp and costs no
         contrast, the part that VARIES across one filament is a blur. Measured
         here: slope RMS 0.294 at unit scale, its increment over one splat
         radius 0.121; the small-angle bend at an air/water dioptre is
         (1 - 1/1.3333) = 0.25 of the slope; and the two from-outside call
         sites weight depth by their own exp(-0.13d) attenuation times the
         green transmittance exp(-0.30d) of their own Beer tint over their own
         0.5..8 block clamp, which puts the visibility-weighted depth at 2.515
         block. Blur sigma = 2.515 * 0.25 * 0.121 = 0.076 block, 0.53 splat
         radii; the RMS contrast surviving it is 0.733 of the unblurred field.
         (Full curve: 0.88 at 1 block, 0.78 at 2, 0.69 at 3, 0.51 at 6.) From
         outside the term therefore runs 0.46..2.18, 4.8:1.
      9. RIDGE WIDTH m = 0.13 (CA4_RIDGE_M2 = m*m). Criterion: m is the value
         that MINIMISES the measured filament width, subject to the crease
         staying wider than the Jacobian probe. Swept with the same
         autocorrelation FWHM as entry 7, same dither seed, 0.01-block grid:
              m       0.06    0.09    0.11    0.13    0.15    0.18    0.24
              width  0.2778  0.2705  0.2685  0.2679  0.2680  0.2687  0.2708
         a real but shallow minimum at 0.13-0.15, +3.7% at 0.06 and +1.1% at
         0.24. "Narrower = thinner filaments" is therefore FALSE below 0.13:
         the width turns back up, because a crease narrower than the splat
         stops being resolved by it. Contrast is flat across the whole sweep
         (p99.9/floor 10.04 to 10.05), so m does not buy contrast either.
         What m does move is E[S] (0.369 at m 0.06 to 0.466 at 0.24), and E[S]
         is what entries 6 to 8 and both renormalisation curves are calibrated
         against - so m cannot be retuned on its own.
         The probe constraint, now in ONE unit instead of two: the fold is
         rounded over |2n-1| < m, which along the gradient of the dominant
         ridged octave measures 1.067 * m * (CA4_SCALE / 0.5) block. At
         m = 0.13 that is 0.139 block = 2.5 x CA4_DL, and the constraint would
         only bind at m = 0.052. Comparing m with CA4_DL directly (0.13 vs
         0.11) is meaningless - m is in units of n, CA4_DL in blocks.
         CA4_RIDGE_G is NOT free once m is chosen: renormalising the fold
         1 - sqrt(t*t + m*m) back to a unit range gives, in closed form,
         G = 2 / (sqrt(1 + m*m) - m) = 2.2768 at m = 0.13.
     10. The two renormalisation curves are fitted, not guessed, and their
         residuals are stated at vlCa4S0 and vlCa4Mean below. The term
         MULTIPLIES the pixel's already-composed lighting (not the solar term
         in isolation - see the call sites in composite1.fsh) and is centred on
         1.0. NOT EXACTLY 1.0 EVERYWHERE, and the measured budget is at
         vlCa4Mean: 0.85..1.05 over the whole reachable dial space, i.e. up to
         15%, worst at CA4_SHARP 0.5 combined with maximum distance defocus. At
         the DEFAULT CA4_SHARP the worst is -7.0%. Switching caustics on does
         not move the exposure; moving the dials moves it by that much.
     11. JACOBIAN PROBE CA4_DL = 0.11 * CA4_SCALE. Criterion: the LARGEST probe
         whose photon placement error is still within ~1% of the dl -> 0
         (analytic-Jacobian) limit, since a longer probe is cheaper in nothing
         and only smears the fold. Placement error = RMS distance between where
         the affine model puts a photon and where the true field puts it, over
         the aperture the estimator actually uses, four patches x 3 dither
         draws x 9 photons:
              dl/CA4_SCALE   0.02   0.05   0.09   0.11   0.14   0.18   0.24
              RMS (block)   0.2504 0.2505 0.2523 0.2533 0.2557 0.2598 0.2680
         Flat to 1.2% up to 0.11, then climbing: 0.11 is the last value on the
         plateau. NOT justified by float precision - the earlier "long enough
         to be quiet" reading does not survive measurement: the float32 ulp
         noise of the Jacobian entries is below 1e-4 % of their own RMS at
         every probe length in this range, so quantisation never binds.
         CA4_DL is not a free knob even so: changing it from 0.11 to 0.02
         rearranges the pattern by 33% of its own RMS while leaving mean,
         contrast, floor fraction and filament width within 0.5%. It moves the
         net around; it does not change what the net looks like.
    Everything else (per-octave rotation, mild anisotropy, small shear,
    opposed drift vectors) exists only to kill any direction, period or
    lattice in the field. The first version of this used strong shear and no
    rotation: it produced clean parallel hatching, not a net.
*/

// ================= UW_SUN_COHERENT: THE underwater sun direction =============
// DELIBERATELY OUTSIDE the CAUSTICS_V4 gate below: its consumers (the VL march
// in composite1.fsh and its mirror lib/vl_halfres.glsl) read it on every water
// path, including CAUSTICS_V4 == 0 builds.
//
// lightW is the AIR direction toward the star,
// normalize(mat3(gbufferModelViewInverse) * shadowLightPosition) -- the exact
// vector the shadow map is built on, sunPathRotation (-35 deg) included.
// Returned: the direction toward the star as seen FROM INSIDE the water, unit
// length, y > 0. Snell at a flat air->water dioptre with the pack's own index
// (n = 1.3333, eta = 0.75: the value composite1's waterColumn refract() call
// and vlCa4Offset / vlCa4Aniso already use; no other index exists in the pack).
//
// WHY IT MATTERS: sin(theta_t) = sin(theta_air) / 1.3333 saturates at 0.75, so
// this vector NEVER leaves the 48.59 deg Snell cone, whatever the elevation.
// Fed a raw lightW instead, a beam term draws structure at theta_air: 70 deg
// off vertical for a 20-deg sun, 21 deg outside the cone, which is exactly how
// a shaft ends up visibly beside the caustic it is supposed to be the beam of.
//
// EXACT AGREEMENT WITH THE CAUSTIC SLIDE - this is the point of the function,
// not a coincidence: vlCa4Offset returns normalize(lightW.xz) * tan(theta_t) *
// depth, and this vector's own xz / y * depth is normalize(lightW.xz) *
// (sin/cos)(theta_t) * depth, the same expression with the same clamps. So a
// point projected to the surface with vlCa4Offset and a point projected with
// this direction land on the SAME texel, and the fine net, the sheaf mask, the
// beam phase and the shadow probe cannot drift apart by construction.
vec3 uwSunRefract(vec3 lightW) {
    vec2 hxz = lightW.xz;
    float hLen = length(hxz);
    if (hLen < 1e-4) return vec3(0.0, 1.0, 0.0);         // star at the zenith
    float sinT = min(hLen / 1.3333, 0.999);              // sin(theta_t), same clamp as vlCa4Offset
    float cosT = sqrt(max(1.0 - sinT * sinT, 1e-4));     // cos(theta_t) >= 0.0316
    vec2 h = hxz * (sinT / hLen);
    return vec3(h.x, cosT, h.y);
}

// ============ UW_SHAFT_FIX3: THE axis the underwater beams are drawn on ======
// Same placement rule as uwSunRefract above: OUTSIDE the CAUSTICS_V4 gate, its
// consumers (composite1.fsh and its mirror lib/vl_halfres.glsl) read it on
// every water path.
//
// WHY THIS AND NOT uwSunRefract. Snell is right about where the light comes
// from and irrelevant to what the observer can check. The only directional
// object a diver can see is his own CAST SHADOW, and that shadow is drawn by
// the shadow map, which is rasterized along shadowLightPosition -- lightW, the
// AIR direction, sunPathRotation included. Every occlusion this pack owns lives
// in that one structure. A beam drawn on any other axis is a second geometry
// multiplied onto the first, and it reads as "the rays do not come from the
// sun" however physical its own derivation is. Measured gap between the two
// axes, elevation only (the azimuth is normalize(lightW.xz) on both):
//   sun 20 deg -> 70.00 deg air vs 44.81 deg refracted = 25.19 deg
//   sun 45 deg -> 45.00 deg air vs 32.03 deg refracted = 12.97 deg
//   sun 55 deg (this pack's noon, sunPathRotation -35) -> 35.00 vs 25.48 = 9.52
// All three re-measured on the SHIPPED expression -- sinT = sin(theta_air)/1.3333
// with uwSunRefract's own clamp, theta_t = asin(sinT). The noon line read
// "25.87 = 9.13" before and was simply wrong: sin(35)/1.3333 = 0.430197 ->
// asin = 25.48 deg, gap 9.52. The 20-deg and 45-deg lines check out unchanged
// (0.704787 -> 44.81, 0.530330 -> 32.03). The argument only gets stronger.
//
// THE y FLOOR. max(lightW.y, 0.15) is NOT a new constant: it is the floor the
// pack's own v3 projection already carries (cprjOff = lightW.xz /
// max(lightW.y, 0.15) * toSurf, both marches), and this function returns
// exactly that slope so the two agree by construction. It caps the horizontal
// slide at |lightW.xz| / 0.15 <= 6.60 block per block of column, which is what
// keeps the lookup inside the range where the caustic field still resolves and
// stops the pattern racing to infinity at the horizon. Cost, stated: below
// lightW.y = 0.15 (8.63 deg) the returned axis is FLATTER than the shadow map's
// -- at the beam's own cut-off, lightW.y = 0.05 (2.87 deg), the shadow map
// projects at 87.13 deg and this returns 81.47 deg, a 5.66 deg residual. Above
// 8.63 deg the two are the SAME vector to the last bit. Compare with the 25.19
// deg the refracted axis carried at a 20-deg sun and 9.52 deg at this pack's
// own noon: the worst case here is smaller than the old best case.
#if UW_SHAFT_V4 == 1
// ---- UW_SHAFT_V4 (A): ONE slope, shared by the axis and the slide ---------
// The two functions below used to write the same quotient twice; the gate
// needs it in one place so the vector and the offset can never disagree.
// Returns the horizontal slide per block of water column, i.e. tan(angle from
// the vertical) of the direction the beam columns are drawn along.
// UW_SHAFT_AXIS_MODE (lib/settings.glsl) picks the answer; the full rationale,
// the measured table and the honest cost of each mode live in that block.
//   0 -> the shipped air axis, hLen / max(lightW.y, 0.15), unbounded (6.64 at
//        the beam's cut-off). Reproduces the pre-V4 expression.
//   1 -> the same, CLAMPED to UW_SHAFT_CONE_TAN = tan(48.59 deg): the Snell
//        cone, which is a hard wall (total internal reflection), not a taste.
//        Inert for any sun at or above 41.4 deg of elevation, this pack's noon
//        (55 deg) included -- and inert BIT FOR BIT, not merely algebraically:
//        both callers below build the pre-V4 vector first and only SHRINK it
//        when it is outside the cone, so nothing is re-associated on the path
//        that used to be taken. That is the whole reason mode 1 does not read
//        this function.
//   2 -> the true refracted slope, tan(asin(sin(theta_air) / 1.3333)). Same
//        clamp on sinT as uwSunRefract / vlCa4Offset, so all three agree.
// Used by mode 2 only; modes 0 and 1 keep the pre-V4 expression verbatim in
// their own callers, and the compiler drops this function there.
float uwShaftSlope(vec3 lightW) {
    float hLen = length(lightW.xz);
    float sinT = min(hLen / 1.3333, 0.999);
    return sinT * inversesqrt(max(1.0 - sinT * sinT, 1e-4));
}
#endif

vec3 uwShaftAxis(vec3 lightW) {
#if UW_SHAFT_V4 == 1 && UW_SHAFT_AXIS_MODE == 2
    // Refracted axis. Zenith guard as in uwSunRefract: the axis degenerates to
    // straight up, which is what the pre-V4 normalize() returned there too.
    vec2 hxz = lightW.xz;
    float hLen = length(hxz);
    if (hLen < 1e-4) return vec3(0.0, 1.0, 0.0);
    vec2 h = hxz * (uwShaftSlope(lightW) / hLen);
    return normalize(vec3(h.x, 1.0, h.y));
#elif UW_SHAFT_V4 == 1 && UW_SHAFT_AXIS_MODE == 1
    // The pre-V4 vector, THEN the cone. Everything reading this axis -- the
    // beam HG lobe (phaseU), the striation phase floor, the UW_SUNGAZE_SOFT
    // vanishing point and the LOCK == 0 blade basis -- has to converge where
    // the COLUMNS converge, so it takes exactly the clamp uwShaftSlide takes.
    // ax is untouched inside the cone, so normalize(ax) is the pre-V4
    // expression to the last bit for any sun at or above 41.4 deg.
    vec3 ax = vec3(lightW.x, max(lightW.y, 0.15), lightW.z);
    float lim = UW_SHAFT_CONE_TAN * ax.y;
    float hl = length(ax.xz);
    if (hl > lim) ax.xz *= lim / hl;
    return normalize(ax);
#else
    return normalize(vec3(lightW.x, max(lightW.y, 0.15), lightW.z));
#endif
}

// Horizontal slide of the beam / caustic lookup for a point `depth` blocks
// under the surface, along uwShaftAxis. IDENTICAL to axis.xz / axis.y * depth
// (the normalize cancels), written without the normalize so it costs one
// divide. This is the term that sets the COLUMN AXIS: the lookup is constant
// along the direction it slides, so the bright/dark columns are parallel to
// uwShaftAxis by construction -- and therefore parallel to the shadow map's
// projection, which is the whole point of UW_SHAFT_FIX3.
vec2 uwShaftSlide(vec3 lightW, float depth) {
#if UW_SHAFT_V4 == 1 && UW_SHAFT_AXIS_MODE == 2
    // SAME slope as uwShaftAxis above, by construction. Every consumer moves
    // together: the volumetric beam columns (composite1.fsh cprjOff / lookU
    // and their lib/vl_halfres.glsl twins) AND the six floor-caustic sites of
    // composite1's water branch, which all call this function -- so a beam
    // still lands exactly on the spot it lights, whatever the mode.
    vec2 hxz = lightW.xz;
    float hLen = length(hxz);
    if (hLen < 1e-4) return vec2(0.0);
    return hxz * (uwShaftSlope(lightW) * depth / hLen);
#elif UW_SHAFT_V4 == 1 && UW_SHAFT_AXIS_MODE == 1
    // The pre-V4 offset, THEN the cone -- same clamp, same azimuth and the
    // same resulting slope as uwShaftAxis above, so the vector and the offset
    // still cannot disagree. sl is returned UNTOUCHED whenever the slope is
    // inside the cone (|sl| <= tan * depth), which is the bit-identity claim
    // for any sun at or above 41.4 deg. depth is a max(..., 0.0) at every
    // caller, so depth = 0 gives lim = 0 and the false branch, no divide.
    vec2 sl = lightW.xz * (depth / max(lightW.y, 0.15));
    float lim = UW_SHAFT_CONE_TAN * depth;
    float ln = length(sl);
    return (ln > lim) ? sl * (lim / ln) : sl;
#else
    return lightW.xz * (depth / max(lightW.y, 0.15));
#endif
}

// ============ CAUSTICS V6 GATE - see CALIBRATION V6 at vlCa6Shape ============
// v6 changes the SHAPING of the photon estimator and nothing else: the 9
// photons, the 0.110 spacing, the 0.1439 splat, the affine Jacobian, the Snell
// slide, the sun obliquity and the field are v5's, untouched and unread by this
// gate. It is therefore bit-identical at 0 BY CONSTRUCTION and not merely by
// verification - the only thing it switches is which of two shaping functions
// vlCa4Net's last line calls.
// IT NEEDS CA5's FIELD. Every v6 constant is a percentile of a 40 M-photon
// ground truth measured ON THE WAVES_V3 FIELD; the v4 ridge field has its own
// (p10 0.2594 / p90 2.0498 / p95 2.6233, CALIBRATION 5) and re-using v5's
// numbers there would move the exposure by an amount nobody measured. So v6
// degrades to v5 exactly the way v5 degrades to v4 - silently, never as a
// compile error, and through the same two-branch #define so the macro can
// never disappear from a build.
#if CAUSTICS_V6 == 1 && CAUSTICS_V5 == 1 && WAVES_V3 == 1 && CAUSTICS_V4 == 1
    #define CA6_ON 1
#else
    #define CA6_ON 0
#endif
// Hard ceiling composite1.fsh clamps the finished term to. It is a GUARD, and
// it cannot fire AT CA4_CONTRAST <= 1.0: 9.0 sits above the shaping's own
// asymptote (CA6_ASYM = 8.9506 under v6, CA4_ASYM/CA5_ASYM = 2.62/2.47 under v5
// and v4), so the cusps keep their relief instead of being flattened to a
// uniform white by a clamp.
// THE CONDITION IS NOT UNCONDITIONAL, and an earlier note here said it was by
// comparing the wrong two quantities. composite1 clamps ca4, not the shape, and
//   ca4 = 1 + (shape - 1) * CA4_CONTRAST * mix(CA_OUTGAIN, 1, subm)
// so the SUBMERGED ceiling is 1 + 7.9506 * CA4_CONTRAST, which crosses 9.0 at
// CA4_CONTRAST 1.25 (10.94) and reaches 16.90 at the slider's top; from outside
// CA_OUTGAIN 0.7740 pushes the crossing to 1.50 (10.23). MEASURED area actually
// clipped, submerged, per frame, knee compensation included:
//     defaults (de 1.60)     CONTRAST 1.25  0.000% of the area, 0.000% of light
//                                     1.50  0.018%              0.006%
//                                     2.00  0.202%              0.249%
//     corner de 6.40         CONTRAST 1.25  4.478%              6.811%
//     (STEEP 2 x SHARP 2)             1.50  4.772%             15.880%
//                                     2.00  5.750%             36.146%
// So at the defaults the clamp is still effectively a guard even at the top of
// CA4_CONTRAST; at the far corner of the deflection dials it is a real clip and
// CA4_CONTRAST, not this constant, is what puts it there. One consequence worth
// knowing: composite1 clamps ca4 * caTint4 and caTint4 has B = 1 with R and G
// below it, so the BLUE channel clips first and the brightest cusps take a hue
// shift rather than a clean roll-off. (v5 had the same structure against its
// 2.7, so this is not new - only the claim was.)
// MEASURED, which is why the number had to move at all: with the v6
// shaping in place the shipped 2.7 would clip 3.49% of the sea floor and throw
// away 2.58% of the caustic's light at the SUBMERGED site (1.82% / 1.00% at the
// two from-outside sites, where CA_OUTGAIN has already compressed the term) -
// it would re-flatten exactly the cusps v6 exists to restore. The finished term
// runs 0.014..6.86 submerged and 0.237..5.53 from outside, against asymptotes
// of 8.95 and 7.15, so 9.0 is above both and cannot fire from either side.
#if CA6_ON == 1
    #define CA_CLAMP_HI 9.0
#else
    #define CA_CLAMP_HI 2.7
#endif

#if CAUSTICS_V4 == 1
// Photon throw per unit of wave slope, in blocks. Scales with CA4_SCALE
// because the field's slope scales as 1/lattice, so the DEFLECTION IN BLOCKS
// is the same at every mesh size. The LOOK is not: an earlier note here said
// it "stays put when the mesh is resized", and measurement says otherwise -
// the whole pattern magnifies with the lattice and the filaments widen
// linearly with CA4_SCALE (0.25 block at 0.5, 1.69 at 3.0; the sweep is at
// CA4_SCALE in lib/settings.glsl). What IS scale-invariant is the deflection
// in blocks, the photon aperture and the floor/ceiling of the output
// (0.2594..2.611 at every mesh size). What is NOT: the feature size, and, by a
// little, the exposure - measured mean 0.993 / 0.977 / 0.956 / 0.945 and
// contrast 0.872 / 0.930 / 0.953 / 0.955 at CA4_SCALE 0.5 / 1 / 2 / 3, because
// the finite-difference Jacobian is taken over a probe that grows with the
// lattice while the throw does not.
#define CA4_DEV (1.60 * CA4_STEEP * CA4_SCALE)
// Jacobian probe length, blocks. CRITERION (CALIBRATION 11): the largest probe
// whose photon placement error is still within ~1% of the dl -> 0 analytic
// limit. Measured RMS placement error 0.2504 block at dl -> 0, 0.2533 at
// 0.11 * CA4_SCALE (+1.2%), 0.2557 at 0.14 (+2.1%), 0.2680 at 0.24 (+7.0%):
// 0.11 is the last value on the plateau. Float precision plays no part - the
// float32 ulp noise of the Jacobian entries is under 1e-4 % of their own RMS
// at every probe length in this range.
#define CA4_DL (0.11 * CA4_SCALE)
// Ridge fold width m = 0.13 -> m*m. CRITERION (CALIBRATION 9): m minimises the
// measured filament width (0.2679 block at 0.13 against 0.2778 at 0.06 and
// 0.2708 at 0.24) while keeping the rounded crease - 0.139 block here - wider
// than the Jacobian probe, which it is by 2.5x. G is then fixed, not chosen:
// renormalising 1 - sqrt(t*t + m*m) to a unit range gives
// G = 2 / (sqrt(1 + m*m) - m) = 2.2768 at m = 0.13 (2.278 as shipped, a
// 0.05% rounding kept so the look does not move).
#define CA4_RIDGE_M2 0.0169
#define CA4_RIDGE_G  2.278

// ---- the estimator's own geometry (CALIBRATION entries 2 and 4) ----------
// Photon spacing: 3 samples per the field's smallest significant wavelength.
// FFT of this field's slope puts 98% of the variance above 0.3305 block, and
// 0.3305 / 3 = 0.110. Leaves 0.49% of the slope variance above the grid's
// Nyquist = 0.033 block of photon misplacement, 23% of the splat radius.
#define CA4_PSPACE 0.110
// Splat radius / photon spacing. First ratio whose lattice-sum RMS ripple
// falls under 2% (1.99% at 1.3085, 3.02% at 1.280, back over 2% past 1.3615):
// the smallest radius at which an undeflected grid already sums flat, i.e. the
// sharpest unbiased estimator. Pure geometry of the quadratic kernel.
#define CA4_PRATIO 1.3085
// = 0.1439 block. Both scale together with CA4_SHARP and with the distance
// defocus, so the ratio - and with it the grain of the estimator - is fixed.
#define CA4_PRAD (CA4_PSPACE * CA4_PRATIO)

// ---- the shaping anchors (CALIBRATION entries 6 to 8) --------------------
// Floor = p10 of the true photon density on this field: what a real fold-free
// cell receives, which is what the term must return when all 9 photons miss.
#define CA4_FLOOR 0.2594
// Knee = true p90, asymptote = true p95. Above the true 90th percentile the
// map compresses; the ceiling is the true 95th. The clipped 5% carries 18% of
// the light and would otherwise reach 9.4x the mean.
#define CA4_KNEE 2.0498
#define CA4_ASYM 2.6233
// Solved, not chosen: the one value that puts the mean of the shaped term at
// exactly 1.000000 on this field at the default deflection.
#define CA4_GAIN 1.5037
// Contrast the wavy interface has already destroyed before the eye sees it,
// measured on this field at the from-outside sites' own visibility-weighted
// depth of 2.515 block (blur sigma 0.076 block = 0.53 splat radii).
#define CA4_OUTGAIN 0.733

// One PLAIN octave -> its contribution to the world-space slope (blocks^-1).
// lat = lattice size in BLOCKS, w = weight, (cs, sn) = the octave's own
// rotation (compile-time constants), aq = mild anisotropy in that frame,
// shr = a small shear, dr = world-space drift. Rotation is what decorrelates
// the octaves; the shear only breaks the square lattice of the value noise.
vec2 vlCa4Oct(vec2 p, float lat, float w, float cs, float sn, float aq, float shr, vec2 dr) {
    float inv = 1.0 / lat;
    float rx = p.x * cs + p.y * sn;
    float ry = (p.y * cs - p.x * sn) * aq + rx * shr;
    vec3 n = vnoiseD(vec2(rx + dr.x, ry + dr.y) * inv);
    // Chain rule through (rotation, anisotropy, shear) and the 1/lat scale.
    return vec2(n.y * cs + n.z * (cs * shr - sn * aq),
                n.y * sn + n.z * (sn * shr + cs * aq)) * (w * inv);
}

// One RIDGED octave. The fold is 1 - sqrt((2n-1)^2 + m^2): a crest whose
// derivative is continuous everywhere and reaches EXACTLY zero on the crease.
// A raw |2n-1| kink would put a gradient discontinuity on the very curve the
// filament is drawn along, and TAA would read it as a hairline of aliasing
// every frame. Only the derivative is ever needed - the height is not.
vec2 vlCa4OctR(vec2 p, float lat, float w, float cs, float sn, float aq, float shr, vec2 dr) {
    float inv = 1.0 / lat;
    float rx = p.x * cs + p.y * sn;
    float ry = (p.y * cs - p.x * sn) * aq + rx * shr;
    vec3 n = vnoiseD(vec2(rx + dr.x, ry + dr.y) * inv);
    float t = 2.0 * n.x - 1.0;
    float rd = -CA4_RIDGE_G * t * inversesqrt(t * t + CA4_RIDGE_M2); // d(fold)/dn
    return vec2(n.y * cs + n.z * (cs * shr - sn * aq),
                n.y * sn + n.z * (sn * shr + cs * aq)) * (w * rd * inv);
}

// Wave-field SLOPE in world space, measured RMS 0.290 at CA4_SCALE 1.0 (0.595
// at the default 0.5, but the DEFLECTION in blocks is the same either way).
// Measured variance split over the four octaves: 13.6% / 81.2% / 2.7% / 0.7%,
// so the ridged 1.75*CA4_SCALE octave carries the gradient. Four octaves,
// the two dominant ones ridged; each has its own rotation (0 / 1.10 / 2.35 /
// 0.55 rad, cos-sin folded in as literals), its own mild anisotropy, its own
// shear and its own drift, two of them running against the others. Drift
// magnitudes 0.06 / 0.08 / 0.17 / 0.28 block/s: the fine detail scurries, the
// mesh breathes, nothing scrolls, and the four periods share no common
// multiple so the pattern never repeats in time.
vec2 vlCa4Slope(vec2 p, float t) {
    float ts = t * CAUSTIC_SPEED * CA4_SPEED;
    float L = CA4_SCALE;
    vec2 g  = vlCa4OctR(p, 3.70 * L, 0.420,  1.0000, 0.0000, 0.85,  0.35, vec2( 0.052,  0.031) * ts);
    g += vlCa4OctR(p, 1.75 * L, 0.400,  0.4536, 0.8912, 1.20, -0.30, vec2(-0.071,  0.045) * ts);
    g += vlCa4Oct (p, 0.85 * L, 0.075, -0.7027, 0.7115, 1.00,  0.25, vec2( 0.145, -0.082) * ts);
    g += vlCa4Oct (p, 0.47 * L, 0.022,  0.8525, 0.5227, 0.80, -0.40, vec2(-0.230, -0.160) * ts);
    return g;
}

/*
    ============ CAUSTICS V5 - THE NET IS THE SEA THAT IS DRAWN ============
    CAUSTICS_V5 == 0 leaves every v4 path above bit-identical; the gate exists
    to A/B the two in game. CAUSTICS_V5 also needs the v3 sea to read: with
    WAVES_V3 == 0 there IS no such field, so the gate silently degrades to v4
    instead of failing to compile (see CA5_ON below).

    THE DEFECT IT FIXES, STATED AS A MEASUREMENT. v4 deflects its photons with
    a field of its OWN - vlCa4Slope, four value-noise octaves at 3.70 / 1.75 /
    0.85 / 0.47 x CA4_SCALE - while the surface the player is looking at is
    drawn by wave3Eval, a six-rung Pierson-Moskowitz ladder with a different
    spectrum, a different anisotropy and a different wind axis. Two different
    fields cannot produce a caustic that matches the waves, and measurably they
    do not. Correlation between the TAA-converged finished term and the VISIBLE
    surface's own -|grad h|, six sites x three times, both fields through one
    harness, +- one standard deviation over the eighteen samples. ONE reference
    in both columns - the SIX-rung surface the player actually sees, never the
    four-rung sub-field the estimator itself reads:
                             unfiltered      low-passed to 0.35 block
         v4 as shipped     +0.004 +-0.022      -0.003 +-0.064
         v5, this block    +0.351 +-0.016      +0.546 +-0.029
    (CORRECTION. An earlier revision of this block published +0.757 in the
    right-hand cell. That number is real, but its reference is the FOUR-rung
    field the estimator reads, not the visible surface - so the comparison was
    partly self-referential. Against that four-rung field the pair reads v5
    +0.736 +-0.023 / v4 -0.034 +-0.057: same verdict, different reference. The
    honest headline for "the net is a picture of the visible sea" is +0.35 raw
    and +0.55 low-passed, and that is what the menu text now quotes.)
    v4's is zero to three decimals at both scales, with a scatter larger than
    the mean - not a weak relationship, no relationship, and it stays zero at
    every filter width and under an oblique sun (35 deg of elevation: v5 +0.349,
    v4 +0.001). A caustic IS the image of the wavefront above it; v4's was a
    decoration that happened to sit under the water.

    WHAT IS REPLACED, AND WHAT IS NOT. The ESTIMATOR is kept whole - the 9
    photons, the 0.110 spacing, the 0.1439 splat, the Epanechnikov kernel, the
    affine three-evaluation Jacobian and its +-3 clamp, the Snell lookup slide
    (vlCa4Offset) and the sun-obliquity map (vlCa4Aniso). Its geometry
    (CALIBRATION 2 and 4) is a property of the ESTIMATOR, not of the field, so
    none of it moves. What is replaced is the FIELD the estimator reads, and
    with it everything that was calibrated on that field's statistics:
    CALIBRATION 5 to 8 and both renormalisation curves are re-derived below
    from scratch, by the same method (numpy port of THIS field, ground truth by
    massive splatting, percentiles, gain solved for a mean of 1.000).

    WHY THE NET IS STILL A NET. The v4 header's argument transfers unchanged:
    the filaments are the level set {|grad h| small}, and RIDGING an octave
    turns that set one-dimensional, because the fold's derivative passes
    through zero on the crease {n = 0.5}, which is a CURVE. wave3Eval ridges
    its WAVE3_RIDGE coarsest rungs with exactly the same fold (m = 0.13 - the
    two blocks already shared that constant), so the mechanism is the same one,
    but the crease it draws along IS the wave crest line now. That is the whole
    visual change: the filaments run along the crests, inherit WAVE3_ANISO's
    long-crested stretch, and turn with WIND_DIRECTION.

    ---- CALIBRATION V5 ----------------------------------------------------
    Measured on a numpy port of wave3Eval at the shipped wave defaults
    (WAVE3_SCALES 6, PEAK_LEN 4.0, STEEP 0.026, ANISO 5.5, SPREAD 20, RIDGE 2,
    WIND_DIRECTION 25). The harness is validated against numbers this file
    already ships: it re-measures v4's filament width at 0.2677 block
    (CALIBRATION 9 says 0.2679), v4's true-density p10/p90/p95 at 0.2498 /
    2.0443 / 2.5731 (CALIBRATION 5 says 0.2594 / 2.0498 / 2.6233, so this
    harness reads 3.6% / 0.3% / 1.9% low and the v5 anchors below carry that
    same offset), v4's exposure budget at -15.5% (CALIBRATION 10 says -15%) and
    the v3 field's mean tilt at 4.60 deg (the WAVES_V3 block says 4.56). Those
    agreements are why the v5 numbers below can be trusted.

     A. RUNG COUNT CA5_OCT = 4. The wave ladder's SLOPE is not dominated by the
        rungs its ELEVATION is: measured slope-variance shares 2.2 / 23.2 /
        15.2 / 18.9 / 19.8 / 20.6 % over rungs 0..5, i.e. the fine half of the
        ladder carries 59% of the gradient. Feeding all six to the estimator is
        physically wrong AND unusable. Wrong, because a surface component of
        slope s and wavenumber k folds the light sheet at its own focal depth
        D_f = 1/(0.25*s*k): at a fixed throw only a BAND of the spectrum is in
        focus, and shorter rungs are far past their own focus, where they
        contribute a wash and not a pattern. Truncating the ladder for the
        CAUSTICS is a depth filter, not a cost trick.
        Unusable, because of what it does to the filament width. Measured as
        CALIBRATION 9 does it (FWHM of the radial autocorrelation of the
        converged net), against the pack's own pixel ground footprint of 0.18
        block at 16 blocks (1080p, fov 70, eye 1.8):
            CA5_OCT      3       4       5       6
            width     0.4356  0.2709  0.1583  0.0817   block
            /footprint  2.42    1.51    0.88    0.45
            corr with the visible surface  0.551 / 0.685 / 0.817 / 0.893
        (that last row is on the RAW converged estimator, before shaping, which
        is the fair comparison between rung counts; the shipped shaped term at
        CA5_OCT 4 reads +0.55 against the VISIBLE surface on the larger
        six-site sample above, and +0.74 against the four-rung field it reads
        itself - see the correction under the table at the head of this block.)
        CRITERION: the LAST rung count whose filament is still wider than one
        pixel footprint - past it the net cannot be resolved at all and becomes
        TAA noise. That is 4, and it lands the width on 0.2709 block against
        v4's own 0.2677 measured through the same pipeline (+1.2%): the GRAIN
        of the term does not move, only what it is a picture of.
        Correlation keeps climbing to 0.893 at six rungs. Not taken: what rises
        there is agreement with structure no pixel can show.
     B. CA5_NORM = 0.2275 / WAVE3_STEEP (= 8.75 at the default 0.026). The v3
        field's slope is 8x weaker than v4's - RMS 0.0719 block^-1 on four
        rungs against 0.586 - so the throw has to be renormalised or the whole
        estimator sits inside one splat radius and returns a flat sheet.
        Dividing by WAVE3_STEEP is the idiom wave3Height already uses to keep
        the whitecap gate fixed, and it is what keeps THIS calibration valid
        across the wave menu: the field's slope is exactly linear in
        WAVE3_STEEP, so the normalised slope RMS measures 0.6231 at 0.008,
        0.013, 0.018, 0.026, 0.040 AND 0.075 - the same four decimals - while
        E[S] moves +-1.9%, which is the patch-to-patch scatter. WAVE_STRENGTH
        and the murk factor gbuffers_water.fsh passes into wave3NormalWorld are
        deliberately NOT read here: they scale a SHADING normal per fragment,
        and a world-space caustic cannot depend on which pixel looks at it.
        The 8.75 itself: CRITERION = the largest throw whose TAA-8 residual PER
        UNIT OF CONTRAST is no worse than the shipped v4 term. Measured
        (residual after an 8-frame box average, over the field's own sd):
            CA5_NORM   8.00   8.75   9.50  10.50  11.50   (v4 = 0.118)
            noise/sd  0.119  0.119  0.141  0.134  0.148
            contrast  1.589  1.693  1.792  1.918  2.042
        8.75 is the last value on the plateau; 9.50 buys 6% more contrast for
        19% more grain. It independently lands E[S] on 0.445 and the per-frame
        floor fraction on 58.8%, against v4's 0.433 and 59.1%, so the term
        starts from the same bimodal split the pack is exposure-calibrated
        around. Resulting throw 0.5033 block = 3.50 splat radii (v4: 0.4692 and
        3.26).
     C. REGISTRATION, AND WHY THE ALTITUDE IS NOT WATER_LEVEL. The lookup is
        already slid to the point on the virtual surface where the sun ray
        entered (vlCa4Offset, unchanged), and CA5 then subtracts an ALTITUDE
        from it to land on wave3Pos of that point - because wave3Pos(wpos) is
        wpos.xz - wpos.y, i.e. the field is sheared by the sheet's OWN y.
        The altitude to subtract is therefore the altitude of the WATER SURFACE
        at this site, and not WATER_LEVEL. Subtracting WATER_LEVEL registers
        the ocean and nothing else: MEASURED, a sheet at y = 63 gives
        net/-|grad h| = +0.351 +-0.016, and the SAME code on a lake at y = 70
        gives +0.025 +-0.023 - zero, exactly the v4 level. Every lake, river,
        pond, flooded cave and aquarium off sea level would lose the one
        property this block exists for. Worse, WATER_LEVEL is a 15-stop player
        slider that does not move the water at all (it is an altitude
        REFERENCE), so turning it would have unregistered the OCEAN too. The
        pack already knows the surface is not always at WATER_LEVEL - that is
        what PIXEL_WATER_FIX's max(WATER_LEVEL, cameraPosition.y + 0.4) is for.
        So the surface altitude is passed IN, from the call site, which has it
        in every case (composite1: world0.y at the surface site,
        world0.y + wdepAbove in a water shadow, world0.y + wdepUW submerged,
        wp.y + toSurf and wpU.y + toSurfU in the volumetric march, plus the
        same two in the lib/vl_halfres.glsl mirror). VL_CA5_REG below carries
        it without changing a single signature: the call site pre-shifts its
        own lookup by (surfY - WATER_LEVEL) and vlCa5Slope's internal
        - WATER_LEVEL completes it to - surfY. Exactly 0.0 for a sheet at sea
        level, so the ocean does not move by one bit, and 0.0 by construction
        when CA5 is off, so the v4 lookup cannot move either. The net is now
        read at the SAME field position the surface above it is drawn from ON
        ANY WATER PLANE: not merely the same family of pattern, the same
        realisation.
     D. TIME. The field is stepped on the surface's own clock, t * WAVE_SPEED,
        times CAUSTIC_SPEED * CA4_SPEED so both caustic speed dials keep
        working. At their defaults (all three 1.0) the caustics and the waves
        are exactly synchronous - the same wavefront at the same instant, which
        is the other half of "it looks like the waves".
     E. THE DISTANCE LOD IS NOT INHERITED, ON PURPOSE (and this is a trap).
        wave3NormalWorld multiplies the slope by `att`, the grazing-angle
        flattening, and offsets its sampling point by the parallax march. CA5
        calls wave3Eval DIRECTLY and takes neither.
        `att` is an anti-aliasing measure on a SPECULAR NORMAL - it exists so
        the far sea stops shimmering under TAA. The caustics are not on the
        surface, they are on the FLOOR, and their distance treatment already
        exists and is a different physical thing: `soft`, which widens the
        photon FOOTPRINT (a real defocus at constant mean). Stacking `att` on
        top would shrink the throw with view distance, which reads as the mesh
        growing and the contrast collapsing toward a flat lit sheet - two
        contradictory distance laws on one term.
        The parallax offset is worse: it is VIEW-DEPENDENT. A world-space
        pattern on the sea bed that moves when the camera moves is the one
        artefact this whole term is built to avoid, and it would break the
        volume/surface continuity with the shafts (vlCa4Vol has no view vector
        at all). Neither omission is a cost decision; both would be bugs.
     F. GROUND TRUTH, this field. 24M jittered photons launched over 18x18
        blocks, deflected by the TRUE four-rung field, splatted with the same
        kernel, density read on the inner 12x12 and normalised to mean 1:
        p1 0.0678, p5 0.1243, p10 0.1987, p25 0.4546, p50 0.8297, p75 1.3535,
        p90 1.9992, p95 2.4728, p99 3.4996, max 6.53. The top 5% of the area
        carries 15.7% of the light (v4: 17.0% on the same harness).
        FLOOR / KNEE / ASYMPTOTE are that truth's p10 / p90 / p95, exactly as
        CALIBRATION 6 defines them. Against v4's, the plains are 20% darker
        (0.1987 vs 0.2498) and the ceiling 3.9% lower, so the term's own
        dynamic range p95/p10 goes from 10.30 to 12.44: +21% of contrast, out
        of the MEASURED density and not out of a taste knob. That is the honest
        answer to "make them harder" - the wave field really is more bimodal
        than the ridge field was. Delivered range of the finished term,
        submerged: 12.4:1, against 9.99:1 re-measured for v4 through the same
        harness (v4's own note claims 10.1:1, so the two agree).
     G. GAIN 2.5635. Solved, not chosen: the single value that puts the mean of
        the shaped term at 1.000000 at the default deflection, over 175
        reachable dial pairs x 6 patches x 4 dither draws.
     H. THE TWO RENORMALISATION CURVES, refitted on this field over the same
        reachable space CALIBRATION 10 defines (CA4_STEEP 0.5..2.0, CA4_SHARP
        0.5..2.0, soft 0.35..1.0, de = 1.60*CA4_STEEP*sf, so de 0.14..6.40).
        E[S] fit residual max 24.0% / mean 4.2% (v4's own is 23%), and the
        EXPOSURE BUDGET after dividing by the Mean curve is
            v5  0.849 .. 1.067, worst -15.1%
            v4  0.845 .. 1.055, worst -15.5%   (same harness, same grid)
        so the drift is not made worse by the change. Its visible form, the
        near-to-far brightness gradient over composite1's smoothstep(30,110)
        window, measures -2.3% at the defaults against the 8.2% documented for
        v4. Both curves are anchored so the default is EXACTLY 1.000000:
        turning CAUSTICS_V5 on does not move the exposure.
     I. WHAT v5 NEWLY COUPLES, AND ITS PRICE. The caustics now follow the WAVE
        menu. The two dials a player actually turns are safe: WAVE3_STEEP is
        normalised out (B), and WAVE3_PEAK_LEN moves the lattice without moving
        the slope statistics (grad ~ STEEP * pmE, independent of lambda -
        measured normalised slope RMS 0.62..0.68 across the whole 1.5..16
        dial), so it magnifies the mesh the way CA4_SCALE used to. The SHAPE
        dials are not free. Measured drift of E[S] against the defaults. TWO
        independent harnesses agree on every SIGN and on the ranking but differ
        on the MAGNITUDES by up to 2x, the first always the harsher, so read
        these as orders of magnitude and not as calibration constants. Second
        harness (3 sites x 2 times x 2 draws) first, first harness after it:
        -46% at WAVE3_ANISO 1.0 (-72%) - an isotropic sea has a far larger
        gradient; +21% at WAVE3_SCALES 3 (+50%) - the one setting that steals a
        rung from CA5 itself, since the field gives it min(WAVE3_SCALES,
        CA5_OCT); +16% at WAVE3_RIDGE 0 and -26% at 4 (+28% / -42%); +17% at
        WAVE3_SPREAD 0 and -13% at 45 (+23% / -19%). WAVE3_PEAK_LEN is the one
        entry the second harness OVERTURNS rather than merely rescales: +3.8%
        at 1.5 and +5.6% at 16, i.e. near-neutral - which is also what the
        paragraph above predicts from grad ~ STEEP * pmE, so the earlier
        -24% / -13% pair is withdrawn. The shaping absorbs part of each, but
        none of them is visible to vlCa4Mean(de).
        CA5 wants WAVE3_SCALES >= 4; the default is 6.
        This is a real cost of the design, and it is the correct trade: the
        alternative is v4's, where the caustics could not be wrong about the
        waves because they knew nothing about them.
     J. THE ESTIMATOR'S GEOMETRY IS UNCHANGED AND STILL RIGHT HERE. Probe
        length, re-run with CALIBRATION 11's measurement (RMS distance between
        the affine model's landing point and the true one), PAIRED - same
        patches, same photons, same dither for every probe:
            dl (block)  0.002  0.020  0.055  0.080  0.110  0.140  0.240
            RMS error   0.1912 0.1859 0.1801 0.1798 0.1837 0.1916 0.2321
        On this field the curve has a real INTERIOR MINIMUM at 0.055..0.080 and
        beats the dl -> 0 analytic limit by 5.8%, because a finite probe
        averages the Jacobian over roughly the aperture the photons use. And
        CA4_DL = 0.11 * CA4_SCALE delivers exactly 0.055 block in FIELD
        coordinates at every CA4_SCALE (the dial scales the probe and the
        lookup by reciprocal factors), so the shipped constant already sits on
        the measured optimum and is left alone.
        Surrogate accuracy on this field: the affine estimator correlates 0.843
        with the exact 9-lookup estimator on the converged field and 0.769 per
        frame at the same dither (v4: 0.859 and 0.79), and its RMS placement
        error is 0.1801 block = 1.25 splat radii against v4's 0.253 = 1.76 -
        the surrogate is 29% MORE faithful on the wave field than on the ridge
        field.
     K. CA4_SCALE IS LESS EXPOSURE-NEUTRAL THAN IN v4, and the reason is
        structural, not a fit. The throw is held constant in blocks while the
        lattice grows, so the Jacobian falls as 1/CA4_SCALE; with a small
        Jacobian the nine photons stay clustered around a displacement that is
        3.5 splat radii long, and they all miss. Measured mean of the FINISHED
        term, both versions through the same harness (v4's own column in this
        file reads 0.993 / 0.977 / 0.956 / 0.945; this harness is harsher on
        both, which is why the comparison is made inside it and not across):
            CA4_SCALE     0.5     1.0     2.0     3.0
            v5 mean     0.9918  0.8751  0.6721  0.5791
            v4 mean     0.9819  0.9549  0.8715  0.7213
            v5 contrast 0.916   1.034   1.191   1.310
            v4 contrast 0.881   0.965   1.042   1.138
        The SECOND harness of (I) is far kinder to v5 and reverses the sign of
        the gap at 2.0: v5 1.040 / 0.994 / 0.990 / 0.763 against v4 1.033 /
        1.016 / 0.849 / 0.872 over the same four stops - v5 BETTER than v4 at
        2.0 and worse only at 3.0. The table above is therefore the PESSIMISTIC
        reading of a harness-dependent effect. What both harnesses agree on is
        the direction at 3.0 and the usage note below, which is all the dial
        advice rests on.
        v5 is the more sensitive of the two because its fold density rests on
        the Jacobian rather than on the throw. CONSEQUENCE, a usage note rather
        than a defect: under v5 the dial that resizes the mesh is
        WAVE3_PEAK_LEN, which IS nearly exposure-neutral around the default
        (+0.4% at 4.0, +3.7% at 7.0), and CA4_SCALE should be left at 0.5.
        This is stated rather than papered over; the v5 lookup is at 1:1 with
        the sea at 0.5, which is where the term is meant to run.
     L. COST. THE FIELD-EVALUATION BUDGET IS IDENTICAL. Both versions evaluate
        the slope three times per pixel and both fields cost one vnoiseD per
        octave/rung, so both pay 3 x 4 = 12 vnoiseD = 48 hash12 per pixel for
        the surface net, and 4 vnoiseD for the volumetric one. Nothing was
        traded away for the correspondence, and no rung-count compromise is
        needed: CA5_OCT = 4 is simultaneously the quality optimum (A) and cost
        parity.
        ALU, straight-line, measured on isolated probes compiled to SPIR-V and
        run through spirv-opt -O (whole vlCa4Net, splat included):
            v4                     1474 ops  192 FMul  311 FAdd/Sub  7 sqrt  108 Fract
            v5, unrolled           1433 ops  191 FMul  295 FAdd/Sub  7 sqrt  108 Fract
        i.e. v5 is 2.8% CHEAPER, because vlCa4Oct carries a per-octave shear
        that costs two extra multiplies in the chain rule and wave3Eval's rung
        does not.
        ONE CAVEAT, measured rather than assumed: glslc emits wave3Eval's
        ladder as a ROLLED loop (the `if (i >= nOct) break;` defeats its
        unroller, and spirv-opt --loop-unroll refuses it too), which makes the
        naive static count read 692 ops / 27 Fract - an UNDER-count, not a win.
        The 1433 figure above is from a hand-unrolled probe with the ladder
        state folded to literals, which is what any driver that unrolls a
        constant-trip loop produces. A driver that does NOT unroll pays the
        ladder-state updates as well (lam, s1, cph, ani, off and the two sqrt
        of pmE per rung): measured 199 static ops per loop iteration, so ~796
        per slope evaluation against v4's ~459, i.e. +73% in that worst case.
        Whole-shader static SPIR-V after -O, for scale: composite1 goes from
        50590 ops to 48218 (-4.7%) and composite from 3956 to 3689 (-6.8%).
     M. WHAT THE FINISHED TERM DELIVERS, with the constants below, TAA-
        converged (E[shape(S)] - the shader shapes per frame and TAA averages
        the shaped output, never the other way round):
            exposure     v5 1.0008 over 8 independent 20x20 patches (v4 1.0208)
            range        0.199 .. 2.468, p99/p10 = 12.38  (v4: 10.07)
            floor        61.8% of the area per frame, 46.5% after 8 TAA
                         frames, 43.1% converged - the jitter fills the dark
                         plains in exactly as it does under v4, whose own note
                         reads 58.7 / 44 / 41 (and which this harness
                         re-measures at 59.1% per frame)
        And the point of the whole exercise, per wave rung, converged and
        low-passed to 0.35 block, six sites x three times - WHICH PART OF THE
        SEA THE NET IS A PICTURE OF:
            rung          0      1      2      3      4      5
            pitch (bl)  7.94   3.97   1.98   0.99   0.50   0.25
            v5         +0.112 +0.515 +0.445 +0.212 +0.023 -0.021
            v4         +0.018 -0.006 +0.011 -0.008 +0.002 -0.006
        v5 peaks on rungs 1 and 2 - the 2-to-4 block trame that IS the sea's
        visible pattern and the one the WAVES_V3 spectrum was tuned to put the
        energy in - and correctly falls to zero on the sub-block ripple that no
        caustic at this depth could image. It is weakest on rung 0 (+0.112),
        which is right too: an 8-block swell is far from focus at this throw
        and shows up as a slow modulation of the mesh, not as filaments. v4 is
        flat zero on every rung. THAT is the difference the creator was looking
        at, and it is why the answer to "the caustic images the wavefront at a
        given depth, so it is shifted and re-scaled" is: yes - the shift is
        vlCa4Offset's Snell slide and the re-scaling is this focal band, and
        the FAMILY of pattern is now the same one, which it was not before.
*/
// CA5 reads wave3Eval. With WAVES_V3 off there is no such field, so the gate
// degrades to v4 rather than failing to compile - a menu combination must
// never be a compile error.
#if CAUSTICS_V5 == 1 && WAVES_V3 == 1
    #define CA5_ON 1
#else
    #define CA5_ON 0
#endif
// Registration shift for a water sheet that is NOT at sea level (CALIBRATION
// V5 C). wave3Pos subtracts a point's OWN altitude, so a sheet at surfY is
// drawn from p.xz - surfY, while vlCa5Slope subtracts WATER_LEVEL internally.
// The call site therefore pre-shifts its lookup by this scalar and the two
// subtractions compose to - surfY. Zero for an ocean at WATER_LEVEL, and zero
// by construction when CA5 is off, which is what keeps the v4 lookup - and so
// the whole v4 look - bit-identical. Both branches define the macro, so it can
// never disappear from a build.
#if CA5_ON == 1
    #define VL_CA5_REG(surfY) ((surfY) - WATER_LEVEL)
#else
    #define VL_CA5_REG(surfY) 0.0
#endif
// Rungs of the wave ladder the estimator may see (CALIBRATION V5 A). wave3Eval
// clamps this to WAVE3_SCALES on its own, so a 3-rung sea gives CA5 3 rungs.
#define CA5_OCT 4
// Slope renormalisation (CALIBRATION V5 B). 0.2275 / 0.026 = 8.75.
#define CA5_NORM (0.2275 / WAVE3_STEEP)
// Lookup scale. 1.0 at the default CA4_SCALE 0.5, i.e. the caustics read the
// sea at 1:1. CA4_DEV carries the reciprocal factor, so the throw in blocks,
// the probe in field coordinates and `de` stay CA4_SCALE-invariant even though
// the Jacobian does not (CALIBRATION V5 K).
#define CA5_K (0.5 / CA4_SCALE)
// Deep-water dispersion under that rescale: a rung whose world wavelength is
// divided by K must run at c/sqrt(K), and the field's clock is in its own
// coordinates, so the time argument carries sqrt(K). Exactly 1.0 at the
// default, and all literals - one compile-time constant.
#define CA5_TK sqrt(CA5_K)

// The wave field's slope, in the units the photon estimator expects.
// One wave3Eval at CA5_OCT rungs -> CA5_OCT vnoiseD, the same count
// vlCa4Slope pays. NO grazing attenuation and NO parallax (CALIBRATION V5 E):
// this is the world-space wavefront, not a shading normal.
// The elevation comes back unused on purpose - wave3Eval accumulates it in one
// mad per rung and the compiler drops the chain; adding a slope-only variant
// would fork the field again, which is the exact mistake v5 exists to undo.
// DECLARED UNDER THE SAME CA5_ON AS ITS ONLY TWO CALL SITES (vlCa4Net and
// vlCa4Vol below), because wave3Eval itself only exists under WAVES_V3 == 1 -
// declaration and use are gated on one condition, never on two.
#if CA5_ON == 1
vec2 vlCa5Slope(vec2 p, float t) {
    float elev;
    vec2 g;
    // p is already the point on the virtual surface where the sun ray entered
    // (vlCa4Offset), pre-shifted by VL_CA5_REG(surfY) at the call site. Minus
    // WATER_LEVEL the two shifts compose to minus the SURFACE altitude, which
    // IS wave3Pos of that point, so the net is read at the same field position
    // the surface is drawn from - on any water plane, not only on the ocean.
    wave3Eval((p - WATER_LEVEL) * CA5_K,
              t * (WAVE_SPEED * CAUSTIC_SPEED * CA4_SPEED * CA5_TK),
              CA5_OCT, elev, g);
    // Chain rule through the CA5_K rescale, then the slope renormalisation.
    return g * (CA5_K * CA5_NORM);
}
#endif

// ---- v5 shaping anchors (CALIBRATION V5 F, G) ---------------------------
// True density p10 / p90 / p95 of THIS field. The plains are 20% darker than
// v4's and the ceiling 3.9% lower: dynamic range 12.44:1 against 10.07:1.
// (10.07 is the re-measured v4 figure. 10.30 here and 9.99 in (M) were two
// readings of that same quantity in earlier drafts; all three are unified.)
#define CA5_FLOOR 0.1987
#define CA5_KNEE  1.9992
#define CA5_ASYM  2.4728
// Solved for a mean of exactly 1.000000 at the default deflection.
#define CA5_GAIN  2.5635
// Contrast the wavy interface destroys before the eye sees it. Re-measured
// with CALIBRATION 8's criterion but on the RIGHT field: the blur comes from
// the surface the eye looks THROUGH, which is the v3 sea, not the caustic
// field (v4 measured its own field's slope here, which is the same conflation
// v5 exists to remove). Visible-surface slope RMS 0.0929, its increment over
// one splat radius 0.1022, small-angle bend 0.25, the from-outside sites' own
// visibility-weighted depth 2.515 block -> blur sigma 0.0643 block = 0.45
// splat radii, and the RMS contrast surviving it is 0.774. Full curve: 0.922
// at 1 block, 0.821 at 2, 0.734 at 3, 0.554 at 6. From outside the term
// therefore runs 0.38..2.14, 5.6:1 (v4: 0.46..2.18, 4.8:1).
#define CA5_OUTGAIN 0.7740
// Volumetric remap (see vlCa4Vol). Threshold = CA5_VOL_A + CA5_VOL_B * soft.
// CRITERION, restated from v4's two anchor points into the form that actually
// holds the band: the threshold tracks the 82nd percentile of xn - the level
// that leaves 18% of the volume lit, which is the band causticShaftMask and
// the FINESSE / SPACING sliders are tuned against - fitted by least squares
// over the whole reachable soft range 0.20..1.00 rather than pinned on two
// ends. MEASURED p82 of xn: 1.2526 / 1.3429 / 1.5792 / 2.0827 / 2.5270 /
// 2.5418 / 2.6507 at soft 0.20 / 0.25 / 0.35 / 0.50 / 0.70 / 0.85 / 1.00.
// Delivered lit fraction 0.0 / 0.0 / 8.3 / 25.2 / 20.6 / 17.9 / 16.7 % - the
// shafts CLOSE below soft 0.25 and the same mid-depth bump v4 has is still
// there. CA5_VOL_GAIN 0.6056 is solved, not chosen: xn's p99.9 at soft 1.0 is
// 5.5768, and 0.6056 is the value that lands it on 1.45 after the 1.20 knee
// (measured band p99 1.444, peak 1.451).
#define CA5_VOL_A    0.9612
#define CA5_VOL_B    1.8827
#define CA5_VOL_GAIN 0.6056

// Horizontal slide of the lookup for a point `depth` blocks under the virtual
// surface. Snell at a flat air->water dioptre, with the SAME index the rest of
// the pack uses for water: composite1.fsh refracts the sun with eta 0.75, i.e.
// n = 1.3333, so that is the value here too. (An earlier revision used 1.2 and
// justified it as "the pack IOR"; no such value exists anywhere in the pack.)
// The refracted ray tops out at 48.6 deg, so the slide caps at ~1.13 block per
// block of depth. THIS TERM ALONE carries the
// depth information - the net keeps the same scale and the same sharpness at
// every depth and only its POSITION moves. That is what makes a stepped or
// sloping bottom read as depth (the mesh jumps from one ledge to the next)
// and what shears the mesh into oblique bands on a vertical wall, without
// ever paying the blur a physically correct propagation would cost. It also
// keeps the slide gentle at sunset, where a raw lightW.xz/lightW.y projection
// races the pattern across the floor.
vec2 vlCa4Offset(vec3 lightW, float depth) {
    vec2 hxz = lightW.xz;
    float hLen = length(hxz);
    if (hLen < 1e-4) return vec2(0.0);
    float sinT = min(hLen / 1.3333, 0.999);
    float tanT = sinT * inversesqrt(max(1.0 - sinT * sinT, 1e-4));
    return hxz * (tanT * depth / hLen);
}

// OBLIQUITY of the photon throw - the SAME sun the shadow map uses.
// vlCa4Offset above moves the LOOKUP along the refracted ray; this is the
// other half of the same geometry. How far sideways a given wave slope throws
// a photon is not the same at noon and at sunset, and it is not the same along
// the sun's azimuth as across it: the net has to stretch along that azimuth,
// and the azimuth that counts is the ROTATED one (sunPathRotation = -35 deg,
// lib/settings.glsl), because lightW reaches here as
// normalize(mat3(gbufferModelViewInverse) * shadowLightPosition) - the exact
// vector the shadow map is built on. Without this the deflection was
// direction-free, i.e. the net was projected as if the sun were always
// straight overhead while its shadows came from somewhere else.
// DERIVATION. Vector Snell at a flat air->water dioptre, first order in the
// slope g, with eta = 1/1.3333 = 0.75 (the index vlCa4Offset already uses),
// L = lightW, mu = L.y = cos(theta_i), s = L.xz so |s| = sin(theta_i), and
// k0 = cos(theta_t) = sqrt(1 - eta^2 + eta^2*mu^2):
//     t = eta*d + (eta*c - k)*N,  c = dot(L, N),  k = sqrt(1 - eta^2 + eta^2*c^2)
// Perturb the normal by the wave slope, N = (0,1,0) + (-g.x, 0, -g.y), and
// re-project the transmitted ray onto a plane D below the surface:
//     dP/D = ((k0 - eta*mu)/k0) * ( g + (eta^2/k0^2) * dot(s,g) * s )
// an ISOTROPIC gain (0.25 with the sun at the zenith, 1.00 at the horizon)
// times a STRETCH along the sun azimuth (1.00 at the zenith, 2.286 at the
// horizon).
// ONLY THE STRETCH IS APPLIED, renormalised to unit determinant:
//     A = (I + w*s*s^T) / sqrt(1 + w*dot(s,s)),   w = eta^2/k0^2
// The isotropic 0.25 -> 1.00 gain is deliberately NOT applied, for the same
// reason CA4_DEV carries no depth: the throw is a fixed stylised constant
// (CALIBRATION 1). Letting it grow 4x toward the horizon would drive `de` from
// 1.60 to 6.4, far outside the range vlCa4S0 and vlCa4Mean were fitted over,
// and would simply erase the caustic at low sun.
// UNIT DETERMINANT IS WHAT KEEPS THE CALIBRATION VALID. A is EXACTLY the
// identity when the sun is overhead, and its two eigenvalues stay inside
// 0.6614 .. 1.5119 everywhere else (sqrt(1+w) along the azimuth, its inverse
// across), so the photon aperture is sheared, never inflated, and `de` is
// untouched - the computed determinant is 1.000000 at every elevation.
// Consequence on the exposure, from sqrt(tr(A^T A)/2): the RMS deflection
// moves +1.1% at this pack's own noon (sunPathRotation caps the sun at 55 deg,
// mu = 0.819 -> 1.108 along / 0.903 across, aspect 1.23), then +2.7% at 45 deg,
// +7.4% at 30, +11.6% at 20 and +15.7% at 8 deg, which is the LOWEST elevation
// where lightUp = smoothstep(-0.04, 0.14, lightHeight()) is still exactly 1.0
// (lightW.y = 0.139): the drift reaches the edge of the +-15% budget
// documented at vlCa4Mean at FULL intensity, not only at a horizon that is
// already gated off (+16.7% there, aspect 2.286). No calibrated constant
// changes.
// Returned packed as (a11, a12, a22); A is symmetric by construction.
vec3 vlCa4Aniso(vec3 lightW) {
    const float eta2 = 0.5625;                                     // (1/1.3333)^2
    float k2 = max(1.0 - eta2 + eta2 * lightW.y * lightW.y, 1e-4); // cos^2(theta_t)
    float w  = eta2 / k2;
    vec2  s  = lightW.xz;   // |s| = sin(theta_i) already, no normalise needed
    float inv = inversesqrt(1.0 + w * dot(s, s));
    return vec3(1.0 + w * s.x * s.x, w * s.x * s.y, 1.0 + w * s.y * s.y) * inv;
}

// Expected photon count of the SURFACE estimator. Shape from the physics (the
// splat has a finite volume V and the deflection spreads as `de`, so
// E[S] = V / (2*pi*sigma^2 + V/Smax) with sigma proportional to de), constants
// from MEASUREMENT: E[S] sampled over 30 (CA4_STEEP, CA4_SHARP*soft) pairs on
// this field, 460^2 points each.
// E[S] is NOT a function of `de` alone. `de` folds CA4_STEEP and the defocus
// together, but the Jacobian spread depends on CA4_STEEP on its own (the probe
// CA4_DL scales with the lattice, the throw does not), so at a single de the
// measured E[S] spans 0.35 .. 0.48. Hence the CA4_STEEP^2 term, GROUPED with
// the constant below so the whole 0.1893 + 0.0799*CA4_STEEP*CA4_STEEP is one
// compile-time literal by construction, not merely after the driver decides to
// reassociate. Fit residual: 23% max over de 0.3..3.4 (a de-only fit of the
// same shape was 38% off), and the residual is a SYSTEMATIC, monotone bias,
// not noise: measured -23.1% at de 0.30, -18.8% at 0.40, -5.2% at 0.80,
// +2.1% at the shipped default de 1.60, -1.4% at 3.36. The under-correction at
// small de is the mechanism behind the exposure drift documented at vlCa4Mean.
// What reaches the image is vlCa4Mean's residual, not this one.
// DIVIDING BY THIS IS NOT COSMETIC: the distance defocus below widens the
// photon footprint, which without the correction would light the whole
// distant sea floor to white.
float vlCa4S0(float de) {
#if CA5_ON == 1
    // Refitted on the WAVES_V3 field (CALIBRATION V5 H). Same form, same
    // grouping, same reason for the CA4_STEEP^2 term; only the three literals
    // move. Residual max 24.0% / mean 4.2% over de 0.14..6.40, against v4's
    // own 23% - and, as in v4, the residual is a systematic monotone bias at
    // small de, not noise. Measured span over the whole reachable space
    // 0.0369..1.9523, so the clamp below is a GUARD that never fires.
    return clamp(0.3465 / (0.2200 * de * de
                           + (0.15969 + 0.05391 * CA4_STEEP * CA4_STEEP)),
                 0.030, 2.20);
#else
    return clamp(0.3465 / (0.1954 * de * de
                           + (0.1893 + 0.0799 * CA4_STEEP * CA4_STEEP)),
                 0.035, 1.60);
#endif
}

// Same, for the VOLUMETRIC grid below. That one is centred and un-jittered and
// carries no Jacobian, so it collects more - measured 1.20x the surface
// estimator at soft 1.0 rising to 1.59x at soft 0.2, which is why a single
// scalar times vlCa4S0 cannot track it and it gets its own fit. Measured over
// de = 0.08 .. 6.4 and, having no Jacobian, it IS a function of de alone
// (re-verified across CA4_STEEP 0.5 / 1 / 2 at de 0.80 / 1.60 / 3.20: identical
// to 5 decimals, so `de` really is the only argument this one needs).
// Fit residual 17% over that whole range: re-measured on two independent
// patches the worst is 16.5% (at de 0.32), and at the top of the reachable
// range, de 6.4, it is -0.3% on one patch and -6.5% on the other - the
// estimator collects so little there that the patch-to-patch scatter, not the
// fit, dominates. Reported as 17% because that is what the fit does; a single
// patch at de 6.4 can read much worse without the fit being at fault.
float vlCa4V0(float de) {
#if CA5_ON == 1
    // Refitted on the WAVES_V3 field. This one really IS a function of `de`
    // alone and the measurement proves it exactly rather than approximately:
    // the volumetric grid carries no Jacobian, so E[S] depends only on the
    // product CA4_STEEP * sf, and at de 0.80 / 1.60 / 3.20 across CA4_STEEP
    // 0.5 / 1.0 / 2.0 the measured E[S] is 1.2760 / 0.4999 / 0.1484 with a
    // spread of 0.00% - identical to four decimals. Fit residual max 9.4% /
    // mean 2.7% (v4's own is 17%). The centred grid still collects more than
    // the jittered one, 1.16x at soft 1.0 rising to 1.45x at soft 0.2 (v4:
    // 1.20x and 1.59x), which is why it keeps its own curve.
    // Measured span 0.0390..2.4432, so the clamp is a GUARD that never fires.
    return clamp(0.3465 / (0.2135 * de * de + 0.13764), 0.030, 2.60);
#else
    return clamp(0.3465 / (0.1892 * de * de + 0.1504), 0.035, 2.60);
#endif
}

// Mean of the SHAPED estimator at deflection `de` - what vlCa4Shape below
// averages to before this correction. Measured over 30 dial pairs and fitted;
// anchored so that it is EXACTLY 1.0 at the default (de = 1.60, CA4_STEEP = 1).
// EXPOSURE DRIFT, MEASURED OVER THE WHOLE REACHABLE SPACE. An earlier revision
// of this comment claimed 7%, from two ONE-DIMENSIONAL sweeps: CA4_STEEP x
// CA4_SHARP at soft = 1 (0.941..1.048 - reproduced) and soft alone at
// CA4_SHARP = 1 (0.930..1.040 - reproduced). Their PRODUCT was never swept,
// and that is where the drift lives. Re-measured end to end - six independent
// 20-block patches, three dither draws each, all 7x7x4 reachable
// (CA4_STEEP, CA4_SHARP, soft) triples, soft bounded below at 0.35 by
// composite1.fsh:859 / 2592 / 2687 with CAUSTIC_DIST_FADE <= 1:
//     mean over the whole space  0.851 .. 1.048, i.e. up to 15%, NOT 7%
//     worst  0.8511 +- 0.0120 at CA4_STEEP 1.25, CA4_SHARP 0.5, soft 0.35
//     at the DEFAULT CA4_SHARP 1.0 the worst is 0.9301 (soft 0.35), i.e. -7.0%
// That budget is measured at CA4_SCALE 0.5. The mesh dial is not exposure-free
// either and shifts the whole budget down with it: mean 0.993 / 0.977 / 0.956
// / 0.945 at CA4_SCALE 0.5 / 1 / 2 / 3 (see CA4_DEV).
// So the default column is sound and the 7% figure was true of it; the global
// bound was not. The visible form is a near-to-far brightness gradient that
// follows the camera over the smoothstep(30,110) window: 8.2% at the defaults,
// worst 14.5% at CA4_STEEP 1.5 / CA4_SHARP 0.5.
// WHY THIS IS NOT SIMPLY REFITTED. The drift is mostly structural, not fit
// error: E[shaped] is not a function of `de` (measured spread up to 9.6% at
// equal de across CA4_STEEP), so the best de-only denominator of ANY
// coefficients still leaves 7.0%. A minimax refit of THIS form, anchored so
// the default does not move, reaches 7.8% - but it makes the camera-following
// gradient WORSE at high CA4_SHARP (-11.7% against -6.8% today) while
// improving it at low CA4_SHARP: it moves the artefact, it does not remove it.
// A five-term denominator does better - 5.3% overall and 6.6% gradient, still
// entirely compile-time - but at the price of changing the look at every
// non-default setting AND at every distance, on a fit whose own patch-to-patch
// scatter is 0.5-0.7%, with no GPU available to check it. That is a deliberate
// look change, so it is written down here and NOT taken. If it is ever wanted:
//     2.1478 / (0.9431 + 0.1075*S + (0.7433 - 0.1049*S)*de + 0.0296*de*de)
// with S = CA4_STEEP, minimax-fitted on the measurements above and anchored on
// the current default. Re-measure before shipping it.
// Dividing by this curve is still what keeps the term near-neutral at every
// dial setting AND at every distance: the defocus below widens the photon
// footprint, which without the correction would light the whole distant sea
// floor to white. 15% of drift is the price of a two-literal divide; no
// correction at all is not bounded.
// The CA4_STEEP term is GROUPED with the leading 1.0 so the denominator folds
// by construction rather than by driver reassociation. Verified, not assumed:
// compiled to SPIR-V, this grouping and the matching one in vlCa4S0 remove
// exactly one OpFAdd and one OpFSub against the ungrouped form - which means
// the ungrouped form did NOT fold. Numerically the two are bit-identical at
// the default and within 2 ulp of float32 over the whole reachable de range.
float vlCa4Mean(float de) {
#if CA5_ON == 1
    // Refitted on the WAVES_V3 field (CALIBRATION V5 H), same form and same
    // grouping. Fitted by iteratively reweighted least squares toward a
    // minimax over the 175 reachable (CA4_STEEP, CA4_SHARP, soft) triples, and
    // ANCHORED so the default is exactly 1.000000 - switching CAUSTICS_V5 on
    // must not move the exposure by so much as a rounding.
    // Budget over the whole reachable space: 0.849..1.067, worst -15.1%,
    // against 0.845..1.055 / -15.5% measured for the SHIPPED v4 constants on
    // the same harness and the same grid. The near-to-far gradient over
    // composite1's smoothstep(30,110) window is -2.3% at the defaults, against
    // the 8.2% documented for v4 above.
    // Measured span 0.3371..2.4190, so the clamp is a GUARD that never fires.
    return clamp(2.6047 / ((1.0 - 0.1543 * CA4_STEEP) + 1.0994 * de),
                 0.28, 2.60);
#else
    return clamp(2.1478 / ((1.0 - 0.0965 * CA4_STEEP) + 0.7777 * de),
                 0.30, 2.20);
#endif
}

// [0..9] photons -> a sun multiplier centred on 1.0. The floor is reached when
// all 9 photons miss - the splat has a finite radius, so "no photon" is EXACTLY
// zero, never a soft residue, and that is what makes the dark plains read as
// plains. Floor, knee and asymptote are the true density's p10 / p90 / p95 and
// CA4_GAIN is solved for a mean of exactly 1 (CALIBRATION 6 and 7).
// The non-linearity of this estimator is the finite splat radius - a
// GEOMETRIC clip - never a pow() on a brightness, which is why the filaments
// stay stable in motion and never throw fireflies.
// Under CA5 the three anchors and the gain are the WAVES_V3 field's own
// (CALIBRATION V5 F, G) - the curve shape and the code are untouched.
#if CA5_ON == 1
    #define CA_FLOOR CA5_FLOOR
    #define CA_KNEE  CA5_KNEE
    #define CA_ASYM  CA5_ASYM
    #define CA_GAIN  CA5_GAIN
    #define CA_OUTGAIN CA5_OUTGAIN
#else
    #define CA_FLOOR CA4_FLOOR
    #define CA_KNEE  CA4_KNEE
    #define CA_ASYM  CA4_ASYM
    #define CA_GAIN  CA4_GAIN
    #define CA_OUTGAIN CA4_OUTGAIN
#endif
float vlCa4Shape(float S, float de) {
    float x = CA_FLOOR + S * (CA_GAIN / vlCa4S0(de));
    float over = max(x - CA_KNEE, 0.0);
    x = min(x, CA_KNEE) + over / (1.0 + over / (CA_ASYM - CA_KNEE));
    return x / vlCa4Mean(de);
}

/*
    ======== CAUSTICS V6 - THE FLOOR WAS THE POSTERISATION ==================
    CA6_ON == 0 leaves every v5 path above bit-identical.

    THE DEFECT, AND IT WAS WRITTEN DOWN HERE AS IF IT WERE A FEATURE.
    vlCa4Shape starts at CA_FLOOR and adds the photons. When all 9 photons miss
    - which is not the exception, it is the MAJORITY CASE - the term returns
    CA_FLOOR exactly, the same number on every such pixel. Re-measured on this
    harness at the shipped constants, submerged, defaults:
        S == 0 on 60.9% of the pixels PER FRAME
        still EXACTLY on the floor after 32 TAA frames: 44.1%
        of the pixels that DO see a photon, 84.1% are already past the knee
        (S only has to reach 0.313 out of a possible 9 to get there)
    So the finished term is very nearly TWO-VALUED: 0.1987 on 44% of the area
    and 2.43..2.47 on most of the rest. Its own median IS the floor. That is
    exactly the "you rounded the colours to 2 values" the pack was told about,
    and CA4_STEEP's menu text ("how much of the floor should be dark") was
    selling the defect as a dial.
    IT IS NOT WHAT IS THERE. On those same floor pixels the TRUE density runs
    p10 0.150, p25 0.331, p50 0.712, p75 1.181, p90 1.712, mean 0.848, max 8.04
    - an interquartile ratio of 3.57 painted with one number.

    ---- CALIBRATION V6 ----------------------------------------------------
    Ground truth: 40 M photons launched over an 18-block square, displaced by
    the TRUE field (no affine surrogate, no Jacobian clamp), binned at 0.01
    block and convolved with the SAME quadratic splat of radius CA4_PRAD, on
    the same patch and the same instant every candidate is scored on. Same
    protocol as CALIBRATION 5 / V5, re-run because v6 needs the whole
    distribution and not four percentiles. It reads, normalised to mean 1:
        p1 0.054  p5 0.118  p10 0.187  p25 0.415  p50 0.839  p75 1.379
        p90 1.993 p95 2.460 p99 3.592  p99.9 5.474  max 8.951
        top 5% of the area carries 15.9% of the light
    (The v4-field figures this file already ships - p10 0.259, p90 2.050,
    p95 2.623, max 9.37 - are the same measurement on the OTHER field.)

     A. THE FLOOR IS DELETED, NOT LOWERED. A constant cannot be made to vary,
        so the bottom of the range has to come from somewhere else. The one
        quantity that is (i) already in registers, (ii) continuous everywhere
        and (iii) actually ordered like the truth is the packet's own THROW,
        u = ksp * dot(d0, d0) - the deflection in splat radii squared. Measured
        conditional mean of the true density given u, the whole patch:
            u          0    0.25     1      2      4      8     16     32    64
            |d0|/rad  0.00  0.50   1.00   1.41   2.00   2.83  4.00   5.66  8.00
            E[truth]  1.674 1.439  1.232  1.078  0.942  0.841 0.803  0.701 0.686
        A clean monotone 3.0:1 curve, and it does not flatten on the pixels the
        splat cannot see (the same table restricted to them reads 1.251 / 1.143
        / 0.953 / 0.845 / 0.797 / 0.701). SHAPE: 1/(1 + k*u)^2 beat 1/(1 + k*u)
        and 1/(1 + k*u)^0.5 on the quantile cost below by 14x and 82x - the
        squared form is what puts enough weight in the dark tail to reach the
        true p1 of 0.054.
        THIS IS A KERNEL TAIL, NOT A NEW MECHANISM. Summing the same rational
        tail over the 9 photons individually and evaluating it ONCE at the
        packet centre agree to corr 0.999357, rms difference 3.65% of the
        signal's own sd, worst 1.47% of its range - because the tail's scale
        (1..2 block) is an order over the packet's (0.33 block). So v6 pays ONE
        reciprocal per pixel where the honest form would pay nine, and the
        2.08% mean offset between them is absorbed by the gain solve.
     B. WHAT WAS TRIED AND REJECTED, with the numbers.
        - RE-CENTRING the gather on the linearised preimage (e = M o + d0 - M d0,
          one 2x2 matvec, free): rank correlation with the truth FALLS from
          0.252 to 0.218 / 0.197 / 0.195 / 0.199 at r = 0.25 / 0.5 / 0.75 / 1.0,
          and the atom at S == 0 does not go away (0.37..0.51). The
          linearisation is asked to hold over |d0| ~ 0.48 block against a finest
          rung of 0.99 block, and it does not. Rejected.
        - THE JACOBIAN DETERMINANT, 1/(a + |det M|), the classic fold caustic
          and three ALU from registers this function already holds. It is a
          density at the point the packet LANDS on, not at p: scattered to
          p + d0 it correlates +0.917 with the truth (low-passed 0.20 block),
          left at p only +0.542. A fragment shader cannot scatter, so drawing
          it at p would lay a SECOND net 0.48 block off the splat's own.
          Added to the sum anyway it improves the quantile cost (3.72% -> 2.78%)
          and moves the per-pixel agreement by +0.0002 - i.e. it buys histogram
          cosmetics and a ghost network for the price of a divide. Rejected.
     C. THE THREE FITTED CONSTANTS. CA6_BG / CA6_BGK / CA6_GAIN are fitted by
        minimising the sum of squared log errors of the TAA-converged term's
        quantile curve (p1, 5, 10, 25, 50, 75, 90, 95, 99, 99.9) against the
        ground truth above - the DISTRIBUTION is the target, because the
        estimator's rank agreement with the truth (0.34 at best over every
        candidate kernel) caps how much per-pixel accuracy is even available.
        Result: every quantile inside 0.935..1.054 of the truth, RMS log error
        3.72%. Verified on 18 scenes (6 sites x 3 times) held out of the fit:
        0.939..1.049.
     D. THE COMPRESSOR IS APPLIED AFTER THE EXPOSURE DIVIDE, which is the one
        structural change to the curve's ORDER against v5, and it is what makes
        the two remaining constants readable: CA6_KNEE and CA6_ASYM are in units
        of the mean, so they can be taken straight off the ground truth -
        KNEE = its p99.9, ASYM = its maximum. The map is therefore EXACTLY
        LINEAR over 99.9% of the area and only rolls off above the true p99.9,
        toward a ceiling that is the true peak. Cost of that choice, same fit:
        3.72% RMS at p99.9/max, 5.06% if the knee is dropped to the true p99,
        6.88% at the true p95. v5's own knee sat at the p90 and its asymptote at
        the p95, which is why 84% of its lit pixels were past the knee.
     E. WHAT IT DELIVERS, TAA-converged, defaults, submerged (v5 -> v6, truth):
            fraction EXACTLY on the minimum   0.4365 -> 0.000002   (0)
            contrast in the dark half, sd/mean 0.209 -> 0.517      (0.541)
            cusp over filament, p99.9 / p90    1.02  -> 2.61       (2.75)
            top 5% of the area carries         12.3% -> 16.0%      (15.9%)
            range                        0.199..2.468 -> 0.014..6.86 (0.029..8.95)
            median                             0.479 -> 0.798      (0.839)
            corr with the truth, per pixel     +0.255 -> +0.367
            same, low-passed to 0.20 block     +0.293 -> +0.397
        The first line is the mission: 44% of the sea floor stops being one
        number. The third is the other half of it - under v5 a cusp was 1.02x a
        filament, i.e. there were no cusps, only a mask.
        AND IT DOES NOT COME BACK ANYWHERE ON THE DIALS, which is the claim a
        deleted floor has to survive. Fraction on the exact minimum, TAA-16 over
        three patches:
            CA4_STEEP  0.5    0.7   0.85    1.0   1.25    1.5    2.0
            v6       0.001% 0.001% 0.001% 0.001% 0.001% 0.001% 0.001%
            v5        17.2%  28.8%  36.8%  44.9%  54.4%  62.3%  72.0%
            CA4_SHARP 0.5 / 1.0 / 2.0   v6 0.001% each,  v5 12.7 / 44.9 / 77.6%
            soft 0.35 / 0.5 / 1.0       v6 0.001% each,  v5  4.8 / 12.6 / 44.3%
            worst corner (2.0, 2.0, 1.0)  v6 0.002%,     v5 91.3%
        0.001% is one pixel in 102400 - the single darkest sample and nothing
        else. There is no flat area left at any reachable setting.
     F. TAA. v6 is QUIETER, not louder, even though its ceiling is 2.8x higher:
        the background carries no jitter at all, and one photon's worth of S
        moves the OUTPUT by 0.76 against v5's 5.75, so the 9-photon shot noise
        reaches the image divided by 7.6. Measured on 32 frames at the defaults:
            per-frame sd per pixel       v5 0.2858  ->  v6 0.1252
            TAA-8 residual / spatial sd  v5 12.2%   ->  v6 4.5%
            TAA-8 residual / range       v5 4.9%    ->  v6 0.5%
            per-frame max vs converged   v6 6.87 vs 6.85 - no firefly headroom
        Filament width (FWHM of the CROSS-correlation of two independent
        16-frame averages, so the estimator's own grain cannot pose as a
        filament): v5 0.2744, v6 0.3397, ground truth 0.4358 block - v6 moves
        TOWARD the truth, and stays well over the pack's 0.18-block pixel
        footprint at 16 blocks. v5's narrower reading is an artefact of its own
        binarity, not resolution it had.
     G. EXPOSURE IS A CONSTRAINT, NOT A DIAL, as in v5: vlCa6Mean is SOLVED so
        the finished output averages exactly 1.000000, anchored over 6
        independent 12-block patches at 6 different times. Its SHAPE is fitted
        over all 245 reachable (CA4_STEEP, CA4_SHARP, soft) triples - soft
        bounded below at 0.35 by composite1's own distance defocus - on 3
        patches x 3 dither draws. Form chosen by minimax over that space:
            A + B/(1 + C*de*de)                 worst +4.1% / -6.2%, rms 2.85%
            A/((1-B*STEEP) + C*de)   [v5's]     worst +20.0% / -16.7%
            A + B/(1+C de^2) + D*STEEP          worst +10.2% / -9.2%
            A/((1-B*ST)+C*de) + D/(1+E de^2)    worst +19.7% / -16.4%
        de^2 is not a guess: u scales EXACTLY as de^2 (u = (de * CA4_SCALE *
        |A g| / CA4_PRAD)^2 and CA4_SCALE cancels against CA5_K), so the
        background's mean is a function of de alone and needs no CA4_STEEP term
        at all. The budget ON THE PRE-KNEE MEAN is therefore +4.1% / -6.2%
        against the -15.1% v5 documents at CALIBRATION V5 M - not because the
        fit is cleverer but because vlCa4S0's residual now drives only the 34%
        of the mean the splat contributes instead of all of it.
        THOSE FOUR LINES SCORE THE PRE-KNEE MEAN ONLY. What reaches the image is
        the mean AFTER the compressor, and until CALIBRATION V6 K that was a
        very different number at the corners of the menu - read K before quoting
        any of these figures as the exposure of the finished term.
     H. COST, MEASURED, not argued. composite1 compiled to SPIR-V and run
        through spirv-opt -O, whole shader, the three vlCa4Net call sites
        inlined:
            CAUSTICS_V6 0   49299 ops   5091 FMul   7477 FAdd/Sub   472 FDiv
            CAUSTICS_V6 1   49327 ops   5100 FMul   7480 FAdd/Sub   481 FDiv
        i.e. +28 static ops on the whole pass, +0.06%, and +9 FDiv = exactly the
        three divides v6 adds (the background's reciprocal, the exposure divide
        moved out of vlCa4Shape, and the compressor's) times the three inlined
        sites. No new field evaluation, no new noise tap, no new texture read,
        and the 9 photons with their 12 vnoiseD are untouched - which is the
        whole reason the gate can be bit-identical rather than merely close.
        BIT-IDENTITY, VERIFIED THE SAME WAY v5's WAS: composite1 built at
        CAUSTICS_V6 = 0 and composite1 built from a copy of the tree with the v6
        code PHYSICALLY DELETED produce the same optimised SPIR-V, SHA-256
        2D967F16A9FA761BCAE77C8AAF21E0EA68BF46043A74B2574CB03CE12B1E18C7 both
        ways (CAUSTICS_V6 = 1 gives C5E2A0090D09821014BB0FD422D33B0BB5B91108).
     I. ITEM: MORE RUNGS? NO, AND THE WATER SAYS SO BEFORE THE ESTIMATOR DOES.
        The 40 M-photon ground truth of a SIX-rung sea, same throw, same
        protocol: p50 0.937, p90 1.618, p99 2.331, max 3.52, top 5% carries
        10.7% - against 0.839 / 1.993 / 3.592 / 8.95 / 15.9% at four rungs.
        The true caustic of the rougher surface has 42% LESS peak-to-median
        contrast and 2.5x less peak. Sub-block ripple scatters photons; it does
        not draw with them, and that is a property of the water, not of the
        estimator. On the finished v6 term, measuring DETAIL as the contrast
        that survives one pixel (0.18 block ground footprint at 16 blocks,
        1080p, fov 70, eye 1.8 - CALIBRATION V5 A's own figure):
            CA5_OCT       4        5        5        6        6
            CA5_NORM    8.75     8.75    7.553    8.75    6.670   (matched = same throw)
            width (bl)  0.339    0.222    0.224    0.125    0.129
            visible     +0.0%   -15.5%   -21.7%   -34.0%   -43.8%
            TAA-8 resid 0.069    0.075    0.097    0.065    0.098
        A fifth rung costs 3 more vnoiseD per pixel on the surface net (three
        slope evaluations, one rung each, 12 -> 15, +25% of the term's whole
        noise budget) and one on the volumetric one, and it DELETES 15.5% of the
        contrast a pixel can actually show - 21.7% once the extra throw it
        smuggles in is normalised away. The STATIC op count does not move
        (49327 both ways, verified: CA5_OCT is a loop bound and glslc emits
        wave3Eval's ladder rolled, the caveat CALIBRATION V5 L already
        documents), so the price is paid per iteration at run time - ~199 ops
        per rung by V5 L's own measurement, i.e. ~600 dynamic ALU per pixel for
        the three slope evaluations. CA5_OCT stays 4. What
        does rise with more rungs is agreement with structure no pixel can
        resolve (+0.828 -> +0.893 -> +0.950 against the visible sea), which is
        the same trap CALIBRATION V5 A named and refused.
     J. CORRESPONDENCE WITH THE VISIBLE SEA DOES NOT REGRESS - it improves,
        which was not the goal but follows from the background being a function
        of the wave slope. Six sites x three times, converged, against the FULL
        six-rung sea's own -|grad h|:
            low-passed 0.35 block   v5 +0.762 +-0.024  ->  v6 +0.813 +-0.019
            unfiltered              v5 +0.359          ->  v6 +0.411
            per rung (pitch 7.94 / 3.97 / 1.98 / 0.99 / 0.50 / 0.25 block)
              v5  +0.103 +0.495 +0.461 +0.210 -0.027 +0.017
              v6  +0.091 +0.528 +0.454 +0.272 -0.025 +0.016
        Same peak on the 2-to-4 block trame, same zero on the sub-block ripple,
        and a firmer hold on rung 3. (This harness reads v5 higher than the
        +0.55 CALIBRATION V5 A quotes because it uses 12-block patches and its
        own site/time sample; the COMPARISON is same-harness, which is the only
        thing a regression check needs.)
     K. THE COMPRESSOR HAD TO SCALE WITH `de` TOO - a real exposure bug, found
        by audit and fixed here, and the paragraph that corrects G's headline.
        WHAT WAS WRONG. CA6_KNEE / CA6_ASYM were written "in units of the mean".
        Only the MEAN of x is a function of de (vlCa6Mean); the SPREAD in units
        of that mean is not, and it grows fast, because vlCa4S0 (the expected
        photon count) collapses as the throw widens while CA6_GAIN is fixed. A
        knee frozen at 5.4737 therefore walks down the distribution, and it does
        not stop at the tail. Measured on the same harness G used (3 patches x 3
        dither draws, per-pixel jitter, all 245 reachable triples), the light
        the compressor removed:
            de 1.60 (default)   0.01%
            de 3.20             8.2%
            de 4.80            26.7%
            de 6.40            44.0%     <- CA4_STEEP 2.0 x CA4_SHARP 2.0
        i.e. the sea floor lost nearly half its sunlight at a corner two menu
        clicks away, and 0.50% of the area piled up within 5% of CA6_ASYM: a
        NEW flat plateau at the BRIGHT end, the same defect v6 exists to remove
        at the dark end. v5 over the identical corners stays inside 0.85..0.91,
        so this was a v6 regression, not an inherited one.
        THE FIX, and why it is this one. Three properties cannot all hold at
        once at de 6.40, where p99.9(x) is 48.3 and max(x) is 105.4: exposure
        neutral, linear over 99.9% of the area, and a top under CA_CLAMP_HI.
        Scaling KNEE and ASYM with de - the obvious move - keeps linearity and
        loses the third: composite1 clamps the finished term at 9.0, so the soft
        knee would simply be replaced by a HARD clip at the same place, which is
        strictly worse. So the divisor is lowered instead (CA6_KC): the map
        keeps its shape and its 8.95 ceiling, and the light the knee removes is
        given back to the 99% of the area below it. SOLVED per triple by
        bisection on E[knee(x/k)] = E[x], then fitted by minimax on the
        post-knee mean itself. kc = 1.0 EXACTLY for de <= 1.60, which covers
        the whole shipped profile (de = 1.60 * soft there), so the default look
        is bit-identical - the fix only exists off the default.
        DELIVERED, over the 245 triples (mean of the finished term, raw-fit
        residual included - this is the number G's four lines do NOT give):
            st   sh    de     kc      before   after
           0.50 0.50  0.40  1.00000   0.9829   0.9829
           1.00 1.00  1.60  1.00000   0.9935   0.9935   (default, unchanged)
           2.00 0.50  1.60  1.00000   1.0062   1.0062
           0.85 2.00  2.72  0.97397   0.9923   1.0159
           1.00 2.00  3.20  0.92771   0.9447   1.0036
           1.50 1.50  3.60  0.86791   0.9078   1.0104
           1.25 2.00  4.00  0.79178   0.8368   0.9777
           2.00 1.50  4.80  0.61601   0.7471   0.9854
           1.50 2.00  4.80  0.61601   0.7212   0.9529
           2.00 2.00  6.40  0.32218   0.5286   0.9737
        WHOLE-SPACE BUDGET OF THE FINISHED TERM: 0.5286..1.0236 (rms deviation
        5.75%) becomes 0.9529..1.0372, i.e. +3.7% / -4.7%, rms 2.80%. The knee's
        own share of that is +-3.20% worst case, rms 0.49% - the rest is
        vlCa6Mean's pre-knee fit residual, unchanged. Max of the finished term
        over the whole space 8.9092, still under CA6_ASYM 8.9506 and under
        CA_CLAMP_HI 9.0, so that guard keeps the property it is documented with.
        WHAT IT COSTS, stated because it IS a cost. Giving the light back
        pushes more area into the roll-off at the corners:
            area within 5% of CA6_ASYM   worst 0.498% -> 3.376% (de 6.40)
            area the map leaves linear   worst 94.31% -> 92.76% (de 4.08)
        The default is untouched at 99.936% linear and 0.000% plateau. That
        trade is deliberate: a 3.4% saturated area at the single most extreme
        triple in the menu against a 47% exposure error at the same triple.
        And G's "the map is EXACTLY linear over 99.9% of the area" was never a
        whole-space statement even before this fix - measured, it was already
        94.31% at the worst corner. It holds at the default, and only there.
*/
#if CA6_ON == 1
// Weight of the background, i.e. the tail of the splat kernel evaluated once at
// the packet centre (CALIBRATION V6 A). Fitted with CA6_BGK and CA6_GAIN to the
// ground truth's quantile curve; it alone sets the whole bottom of the range,
// which is why deleting the floor costs nothing in dynamic range.
#define CA6_BG   0.23114
// Curvature of that background against the throw u = ksp*dot(d0,d0). Fitted,
// like the other two - but worth a consistency check: 1/(1+k*u)^2 falls to 0.5
// at u = 7.56, i.e. at 2.75 splat radii, against this field's own MEASURED mean
// deflection of 2.84 radii (RMS 3.35, CALIBRATION V5 B's 3.50 is the same
// quantity on its own patch). The fit put the background's half-point on the
// typical throw without being told to.
#define CA6_BGK  0.054807
// Weight of the 9 photons. 0.0633 against v5's 2.5635 for the same S: v5 had to
// shout because it was starting from a floor and clipping at 2.47.
#define CA6_GAIN 0.06330
// Knee and asymptote of the compressor, in units of the mean-normalised term x
// (the compressor runs after the exposure divide, CALIBRATION V6 D): the ground
// truth's own p99.9 and maximum AT THE DEFAULT DEFLECTION de = CA6_DE0.
// NOT "in units of the mean" full stop - that reading was wrong and cost 44% of
// the light at the far corner of the menu. Only the MEAN of x is normalised at
// every de (vlCa6Mean); its SPREAD is not, so a knee frozen at 5.4737 walks down
// the distribution as de grows. CA6_KC below is what puts it back.
// MEASURED area the map leaves exactly linear (output within 0.5% of x), knee
// compensation included: 99.936% at the default, never below 92.8% (worst at
// de 4.08) over the 245 reachable triples. CALIBRATION V6 K.
#define CA6_KNEE 5.4737
#define CA6_ASYM 8.9506
// Deflection the two constants above were read off: CA4_DEV * CA4_SHARP * soft
// / CA4_SCALE at the shipped defaults, i.e. 1.60 splat radii. Not a new number -
// it is CA4_DEV's own 1.60, written here as the anchor of the compensation so
// both sides move together if that ever changes.
#define CA6_DE0  1.60
// Strength of the knee compensation. SOLVED, not chosen: for each of the 245
// reachable (CA4_STEEP, CA4_SHARP, soft) triples the exact k satisfying
// E[knee(x/k)] = E[x] was found by bisection on the measured distribution, then
// 1/(1 + K*(de/CA6_DE0 - 1)^3) was fitted to those k by MINIMAX on the resulting
// post-knee mean - the quantity that actually reaches the image, not on k.
// Cubic because the exponent is free: the minimax optimum is 2.88 (worst-case
// drift +-2.55%) and 3 costs 0.65 points of that (+-3.20%) while removing a
// pow() from the per-pixel path. CALIBRATION V6 K.
#define CA6_KC   0.077920
// vlCa6Mean's three literals (CALIBRATION V6 G). A + B/(1 + C*de*de), fitted by
// minimax over the 245 reachable dial triples then scaled so the DEFAULT lands
// on exactly 1.000000. Spans 0.0943 (de 6.4) .. 0.3075 (de 0), so the clamp
// below is a GUARD that cannot fire.
#define CA6_M0   0.082864
#define CA6_M1   0.224654
#define CA6_M2   0.45500

// Mean of the shaped term at deflection `de`, SOLVED and not chosen - the same
// rule vlCa4Mean follows. No CA4_STEEP term is needed here and that is a
// measurement, not an omission: u scales exactly as de*de, so the background's
// mean is a function of de alone, and the only STEEP-dependent part left is
// vlCa4S0's own residual acting on the 34% of the mean the photons carry.
float vlCa6Mean(float de) {
    return clamp(CA6_M0 + CA6_M1 / (1.0 + CA6_M2 * de * de), 0.060, 0.360);
}

// [0..9] photons + the packet's own throw -> a sun multiplier centred on 1.0.
//   bgu = ksp * dot(d0, d0), the deflection in splat radii squared.
// NOTHING here is a pow() on a brightness and nothing is a clamp on a colour:
// the bottom is the kernel's tail, the top is the estimator's own photon count,
// and the only non-linearity is a soft roll-off that starts above the true
// p99.9. That is what keeps the filaments stable in motion (CALIBRATION V6 F).
float vlCa6Shape(float S, float bgu, float de) {
    float b = 1.0 / (1.0 + CA6_BGK * bgu);
    // KNEE COMPENSATION (CALIBRATION V6 K). vlCa6Mean normalises the MEAN of x
    // at every de; nothing normalised its SPREAD, which grows with de because
    // vlCa4S0 collapses while CA6_GAIN is fixed - so the fixed knee below ate a
    // growing share of the light: MEASURED 0.01% at de 1.60, 8.2% at 3.20,
    // 26.7% at 4.80, 44.0% at 6.40 (that last one is CA4_STEEP 2.0 x
    // CA4_SHARP 2.0, a reachable menu corner). Lowering the divisor by kc puts
    // the POST-knee mean back on the pre-knee one vlCa6Mean aimed at.
    // dr = 0 and kc = 1.0 EXACTLY for every de <= CA6_DE0, so the whole DEFAULT
    // profile is bit-identical: default de = 1.60 * soft, and soft <= 1.
    // The clamp inside vlCa6Mean is a guard on the FIT and stays where it is;
    // kc multiplies its result, so the effective divisor reaches 0.0304 at the
    // worst corner (0.0943 * 0.3222) by design, not by the guard failing.
    float dr = max(de * (1.0 / CA6_DE0) - 1.0, 0.0);
    float kc = 1.0 / (1.0 + CA6_KC * dr * dr * dr);
    float x = (CA6_BG * b * b + S * (CA6_GAIN / vlCa4S0(de))) / (vlCa6Mean(de) * kc);
    float over = max(x - CA6_KNEE, 0.0);
    return min(x, CA6_KNEE) + over / (1.0 + over / (CA6_ASYM - CA6_KNEE));
}
#endif

// SURFACE estimator - the render path.
//   pw   = world XZ of the lookup point (already slid by vlCa4Offset)
//   dth  = temporal blue-noise dither in [0,1)^2. The 9 photons jitter inside
//          their cell every frame; with the pack TAA that turns 9 photons per
//          frame into the equivalent of ~100 over 8-16 frames, which is what
//          buys 0.26-block filaments with no visible grain for the price of 9
//          samples. The budget is paid in TIME, not in space. Measured residual
//          after an 8-frame BOX average: 7.2% of the term's PEAK-TO-FLOOR RANGE
//          (0.259..2.61, span 2.35) - the same residual is 20% of the field's
//          standard deviation (0.860), so the denominator is not optional.
//          The pack's TAA is an exponential accumulator, not a box average over
//          8, so treat this as a floor on the residual rather than a forecast.
//   subm = 1 when the eye is submerged (full 10.1:1 range), 0 when looking in
//          from outside (the same signal at CA4_OUTGAIN, 4.8:1). That gain is
//          not taste: it is the contrast the wavy interface has already blurred
//          away before the eye sees it - CALIBRATION 8.
//   soft = 1 near, down to ~0.35 far. It widens the splat disc AND the photon
//          spacing together (ratio preserved), i.e. it widens the photon
//          FOOTPRINT: a real defocus, not an alpha fade. Distant filaments
//          melt into a soft glow of the same average brightness instead of
//          aliasing into TAA noise.
// Measured at the defaults, submerged: mean 1.00 (exact by construction),
// min 0.259, median 0.259, p75 2.32, p90 2.53, max 2.61, 58.7% of the area on
// the floor PER FRAME (44% after 8 TAA frames - the jitter fills the plains
// in). From outside: 0.46..2.18.
// TWO DISTANCE LODs WERE TRIED HERE AND MEASURED DOWN, 2026-09 (protocol and
// full numbers in the PERF_CAUSTIC_LOD block of lib/settings.glsl). Both would
// have paid: the three slope evaluations below are 1785 of this function's 2166
// dynamic ALU (82.4%), so the 9 photons cannot fund an optimisation and the
// slopes can. Neither is invisible at ANY distance the term is still alive at.
//   - DROP THE JACOBIAN far away (M = identity, ONE slope evaluation, i.e. what
//     vlCa4Vol already does): -60.2% ALU, but the pattern agrees with the
//     shipped term at only +0.883..+0.954 against a +0.999 TAA noise floor, the
//     error never falls under 36% of the term's own rms, and the result is
//     4.6..9.3% BRIGHTER (vlCa4S0 is fitted on the WITH-Jacobian distribution),
//     i.e. an exposure step at whatever line you cut on. And it gets WORSE with
//     distance, for a reason visible right here in the splat and MEASURED on
//     this field: the displacement the Jacobian adds, |(M - I) o| / rad, is
//     EXACTLY INVARIANT in `soft` (o and rad both carry the same 1/sf) at 1.533
//     splat radii rms, while the deflection |d0| / rad shrinks with `soft` -
//     3.426 / 2.741 / 2.056 / 1.713 / 1.370 / 1.199 at soft 1.00 / 0.80 / 0.60
//     / 0.50 / 0.40 / 0.35. Their ratio therefore climbs 0.45 -> 1.28: by the
//     time the defocus is fully open the Jacobian is the DOMINANT term, not the
//     negligible one. A far-field Jacobian LOD is backwards.
//   - CA5_OCT 4 -> 2 far away: -40.7% ALU, agreement +0.23..+0.43 and an error
//     ~200% of rms - not "less detail", a DIFFERENT SEA, because d0 is the SUM
//     of every rung's slope and rungs 2-3 carry the correlation with the
//     visible sea (+0.445 / +0.212, CALIBRATION V5 M). CA5_OCT 3 only reaches
//     +0.70. The pixel-footprint criterion agrees: the finest rung CA5_OCT 4
//     carries has a 0.99-block pitch, which needs 382 blocks to fall under two
//     1080p footprints - 2.5x past the term's own 150-block cut. No cut
//     distance satisfies either test, and the volumetric shafts (which keep
//     CA5_OCT 4) would lose their registration with the spots they light.
// What CAN be removed is the cost of running this function on a pixel whose
// weight is already zero, which is what PERF_CAUSTIC_LOD ships instead.
float vlCa4Net(vec2 pw, float t, vec2 dth, float subm, float soft, vec3 lightW) {
    float dl = CA4_DL;
    // THE ONE LINE THE WHOLE v5 MISSION IS ABOUT: which field the photons are
    // deflected by. Everything downstream is v4's, unchanged. CA4_DL is kept
    // because it lands on the v5 field's measured probe optimum too
    // (CALIBRATION V5 J).
#if VLX_PHYS_SYNC == 1
    // PHYSICS_FIELD_SYNC : sur un pixel d'ocean PHYSICS MOD, LA SEULE CHOSE qui
    // change est la SOURCE du champ. Tout l'aval - jacobien, splat des 9
    // photons, mise en forme v4/v5/v6, anisotropie solaire - est celui du pack,
    // inchange. Branche uniforme (vlxPhysOn est constant sur toute la surface
    // du mod). `t` n'est pas lu du cote physics : l'horloge est celle du mod
    // (vlxPhysT), ce qui est exactement ce qui fait glisser les caustiques AVEC
    // les cretes visibles.
    bool vlxPh = (vlxPhysOn > 0.5);
#if CA5_ON == 1
    vec2 g0 = vlxPh ? vlxPhysSlope(pw)                 : vlCa5Slope(pw, t);
    vec2 gx = vlxPh ? vlxPhysSlope(pw + vec2(dl, 0.0)) : vlCa5Slope(pw + vec2(dl, 0.0), t);
    vec2 gz = vlxPh ? vlxPhysSlope(pw + vec2(0.0, dl)) : vlCa5Slope(pw + vec2(0.0, dl), t);
#else
    vec2 g0 = vlxPh ? vlxPhysSlope(pw)                 : vlCa4Slope(pw, t);
    vec2 gx = vlxPh ? vlxPhysSlope(pw + vec2(dl, 0.0)) : vlCa4Slope(pw + vec2(dl, 0.0), t);
    vec2 gz = vlxPh ? vlxPhysSlope(pw + vec2(0.0, dl)) : vlCa4Slope(pw + vec2(0.0, dl), t);
#endif
#else
#if CA5_ON == 1
    vec2 g0 = vlCa5Slope(pw, t);
    vec2 gx = vlCa5Slope(pw + vec2(dl, 0.0), t);
    vec2 gz = vlCa5Slope(pw + vec2(0.0, dl), t);
#else
    vec2 g0 = vlCa4Slope(pw, t);
    vec2 gx = vlCa4Slope(pw + vec2(dl, 0.0), t);
    vec2 gz = vlCa4Slope(pw + vec2(0.0, dl), t);
#endif
#endif
    // Sun obliquity, from the SAME rotated direction the shadow map is built
    // on: the throw stretches along the sun azimuth and shrinks across it, at
    // constant area. Exactly the identity with the sun overhead, so the
    // calibration point does not move (see vlCa4Aniso).
    vec3 ca4A = vlCa4Aniso(lightW);
    vec2 d0 = vec2(ca4A.x * g0.x + ca4A.y * g0.y,
                   ca4A.y * g0.x + ca4A.z * g0.y) * CA4_DEV;
    float ik = CA4_DEV / dl;
    // Jacobian of the photon map, clamped: on a crease the curvature spikes
    // and an unclamped term would fling all 9 photons out of every disc at
    // once - a one-pixel dead seam running down the middle of the filament.
    // The clamp still lets the determinant cross zero, which IS the fold.
    // NOT A RARE CASE, and worth knowing before retuning: at the defaults the
    // +-3.0 clamp binds on 21.8% of pixels and det(M) < 0 on 39.3%. It is part
    // of the shape of the look, not a safety net that never fires.
    // The +-3.0 itself, the 1.20 knee / 1.55 asymptote of vlCa4Vol, and the
    // clamp ranges of vlCa4S0 (0.035..1.60), vlCa4V0 (0.035..2.60) and
    // vlCa4Mean (0.30..2.20) are GUARDS, not calibrated constants: they exist
    // so a future dial cannot divide by something near zero. Swept over the
    // reachable space the three curves run 0.0407..1.6260, 0.0439..2.2484 and
    // 0.3713..2.0250, so only ONE guard ever fires - vlCa4S0's upper 1.60, at
    // the single corner CA4_STEEP 0.5 / CA4_SHARP 0.5 / soft 0.35, and it
    // truncates by 1.6%. The rest never bind.
    // The clamp stays on the RAW curvature term, BEFORE the obliquity map: the
    // guard bounds the physical quantity it was written for, and ca4A (unit
    // determinant) only shears what survives it - it cannot inflate the
    // aperture, so the guard keeps the meaning it had.
    float j00 = clamp((gx.x - g0.x) * ik, -3.0, 3.0);
    float j10 = clamp((gx.y - g0.y) * ik, -3.0, 3.0);
    float j01 = clamp((gz.x - g0.x) * ik, -3.0, 3.0);
    float j11 = clamp((gz.y - g0.y) * ik, -3.0, 3.0);
    float m00 = 1.0 + (ca4A.x * j00 + ca4A.y * j10);
    float m10 =       (ca4A.y * j00 + ca4A.z * j10);
    float m01 =       (ca4A.x * j01 + ca4A.y * j11);
    float m11 = 1.0 + (ca4A.y * j01 + ca4A.z * j11);
    float sf  = max(CA4_SHARP * soft, 0.05);
    float sc  = 1.0 / sf;
    float stp = CA4_PSPACE * sc;            // photon spacing, 0.110 block
    float rad = CA4_PRAD * sc;              // splat radius, 0.1439 block
    float ksp = 1.0 / (rad * rad);
    float S = 0.0;
    for (int i = -1; i <= 1; i++) {
        for (int j = -1; j <= 1; j++) {
            vec2 o = (vec2(float(i), float(j)) + dth - 0.5) * stp;
            // Affine photon map, then the QUADRATIC splat: full core, hard
            // zero at the rim. Not a gaussian - the hard rim is what makes
            // the filaments read as drawn lines rather than smudges.
            vec2 e = vec2(m00 * o.x + m01 * o.y, m10 * o.x + m11 * o.y) + d0;
            S += max(0.0, 1.0 - ksp * dot(e, e));
        }
    }
    float gain = CA4_CONTRAST * mix(CA_OUTGAIN, 1.0, clamp(subm, 0.0, 1.0));
    // de = the deflection expressed in splat radii: CA4_SCALE cancels out (it
    // scales the lattice AND CA4_DEV, so the deflection in blocks is
    // unchanged), CA4_SHARP and the defocus do not.
#if CA6_ON == 1
    // v6: the shaping also reads the packet's OWN throw, in splat radii
    // squared. Both operands are already in registers - d0 was built above the
    // loop and ksp is the splat's own 1/rad^2 - so this is one dot and one
    // multiply, and no part of the estimator above it changes (CALIBRATION V6).
    return 1.0 + (vlCa6Shape(S, ksp * dot(d0, d0),
                             CA4_DEV * sf / CA4_SCALE) - 1.0) * gain;
#else
    return 1.0 + (vlCa4Shape(S, CA4_DEV * sf / CA4_SCALE) - 1.0) * gain;
#endif
}

#if VLX_PHYS_SYNC == 1 && PHYS_SWELL == 1
// ---- PHYS_SWELL : focalisation paraxiale par la HOULE VISIBLE du mod --------
// Doc et mesures : bloc PHYS_SWELL de lib/settings.glsl. Hessienne de
// Gauss-Newton (meme approximation que vlxPhysShaftLap : la derivee seconde de
// la chaine du drag est ignoree, 11 % RMS) des PHYS_SWELL_OCT premieres octaves,
// normalisee par la somme des poids des 13 octaves (VLX_PF_WSUM13) pour garder
// l'amplitude physique de ces octaves, puis 1/|det(I + c d A H)| borne.
// Meme convention de lecture que vlxPhysSlope : pw est la position du site
// (deja diminuee de VL_CA5_REG), vlxPhysReg la lui rend.
#define VLX_PF_WSUM13 4.72505   // sum_{i<13} 0.8^i
float vlxPhysSwellFocus(vec2 pw, float depthM, vec3 lightW) {
    float adj = clamp(vlxPhysWav * 2.0, 0.1, 1.0);
    float s = VLX_PF_XZ * vlxPhysScale;
    vec2 p = (pw + vec2(vlxPhysReg) - vlxPhysDrift) * s;
    float mt = vlxPhysT * VLX_PF_TMUL;
    float it = 0.0;
    float freq = VLX_PF_F0;
    float spd = VLX_PF_S0;
    float w = 1.0;
    float hxx = 0.0;
    float hxz = 0.0;
    float hzz = 0.0;
    vec2 j0 = vec2(1.0, 0.0);
    vec2 j1 = vec2(0.0, 1.0);
    for (int i = 0; i < PHYS_SWELL_OCT; i++) {
        vec2 d = vec2(sin(it), cos(it));
        float x = dot(d, p) * freq + mt * spd;
        float sx = sin(x);
        float cx = cos(x);
        float wv = exp(sx - 1.0);
        vec2 u = vec2(j0.x * d.x + j1.x * d.y, j0.y * d.x + j1.y * d.y);
        float c2 = w * wv * (cx * cx - sx) * freq * freq;   // d2/dx2 de exp(sin x - 1)
        hxx += c2 * u.x * u.x;
        hxz += c2 * u.x * u.y;
        hzz += c2 * u.y * u.y;
        float cc = (VLX_PF_DRAG * adj * w * freq) * wv * (cx * cx - sx);
        j0 -= (cc * d.x) * u;
        j1 -= (cc * d.y) * u;
        p -= ((VLX_PF_DRAG * adj * w) * wv * cx) * d;
        it += VLX_PF_INC;
        w *= VLX_PF_WD;
        freq *= VLX_PF_FM;
        spd *= VLX_PF_SM;
    }
    // Hessienne MONDE : positions p = pw * s (facteur s^2), hauteur = somme
    // ponderee / WSUM13 * amp * waviness (la convention de physics_waveHeight).
    float hk = (vlxPhysAmp * vlxPhysWav / VLX_PF_WSUM13) * s * s;
    hxx *= hk;
    hxz *= hk;
    hzz *= hk;
    // J = I + c d (A H), c = 1 - 1/n (deviation paraxiale a l'entree dans l'eau),
    // A = matrice d'obliquite symetrique (x y ; y z) du filet, d x GAIN.
    vec3 A = vlCa4Aniso(lightW);
    float cd = 0.25 * depthM * PHYS_SWELL_GAIN;
    float m00 = 1.0 + cd * (A.x * hxx + A.y * hxz);
    float m01 =       cd * (A.x * hxz + A.y * hzz);
    float m10 =       cd * (A.y * hxx + A.z * hxz);
    float m11 = 1.0 + cd * (A.y * hxz + A.z * hzz);
    float det = abs(m00 * m11 - m01 * m10);
    return clamp(1.0 / max(det, 1e-3), PHYS_SWELL_MIN, PHYS_SWELL_MAX);
}
#endif

// ---- CAUSTIC_DEPTH_BLUR_V4: the surface net, defocused BY WATER DEPTH -------
// Full derivation, the measured contrast profile and the exposure budget are in
// the CAUSTIC_DEPTH_BLUR_V4 block of lib/settings.glsl. Short version: `soft`
// above already widens the splat disc AND the photon spacing together (a real
// defocus, ratio preserved), it was only ever driven by the EYE distance, and
// the depth law r(d) = r0*sqrt(1 + (d/CDB_DREF)^2) is exactly soft *=
// inversesqrt(1 + (d/CDB_DREF)^2) because r ~ 1/soft.
// THE ONE SYMBOL THIS FILE ALREADY OWNS: CAUSTIC_DEPTH_BLUR (no _V4) is the
// LEGACY v3 dial read by causticDepthBlur() at the top of this file, and it is
// untouched. The two do not meet: causticDepthBlur feeds the analytic arm,
// this feeds the photon net.
#if CAUSTIC_DEPTH_BLUR_V4 == 1
// Measured ensemble mean of vlCa4Net at `soft` = s, normalised to s = 1. Only
// the RATIO of two evaluations is ever read, so the overall scale is free.
// The clamp is the measurement domain, not a guard on a divide.
float vlCaDepthRho(float s) {
    s = clamp(s, 0.055, 1.0);
    return ((CDB_E3 * s + CDB_E2) * s + CDB_E1) * s + CDB_E0;
}
// Drop-in for vlCa4Net at the six caustic sites of composite1, plus the water
// column `wd` in blocks. Everything vlCa4Net does is unchanged; this only
// chooses the `soft` it is called with and rescales the result.
//   sd = the depth defocus, 1.0 at the surface down to CDB_SMIN.
//   e  = the exposure ratio. EXACTLY 1.0 when sd == 1.0, which is what makes
//        shallow water bit-identical to the pre-gate pixel.
//   k  = the contrast roll-off that continues past the widening's own 1.89
//        floor (see settings). It pulls the term toward 1.0, i.e. toward "no
//        caustic left", which is where a deep column belongs.
// vlCaDepthRho reads CA4_STEEP * CA4_SHARP * soft and not soft, because THAT is
// the variable the fit was measured against: de = CA4_DEV * sf / CA4_SCALE =
// 1.60 * CA4_STEEP * CA4_SHARP * soft, and rho was swept over `soft` with both
// dials at 1.0, i.e. over de / 1.60. Both dials are compile-time constants, so
// the product folds to a literal and is free -- and it is exactly 1.0 at the
// defaults, so the default path is unchanged to the bit.
// IT IS WORTH THE MULTIPLY, MEASURED. Ensemble exposure drift at 8 blocks of
// column with the CA4_SHARP-only argument against this one:
//     CA4_STEEP 0.5          +6.56%  ->  +1.93%
//     CA4_STEEP 2.0          -3.60%  ->  -3.51%
//     STEEP 2.0 / SHARP 2.0  +4.82%  ->  +2.21%
// Worst over the 14 dial/depth pairs swept: 6.56% -> 3.51%. The fit's own field
// still moves with CA4_STEEP (the sea itself changes, not just de), so this
// does not make the corners exact -- it puts the correction on the right axis.
float vlCaNetD(vec2 pw, float t, vec2 dth, float subm, float soft, vec3 lightW,
               float wd) {
    float r  = wd * (1.0 / CDB_DREF);
    float sd = max(inversesqrt(1.0 + r * r), CDB_SMIN);
    float st = soft * sd;
    float ds = CA4_STEEP * CA4_SHARP;
    float e  = vlCaDepthRho(ds * soft) / vlCaDepthRho(ds * st);
    float k  = mix(1.0, sqrt(sd), CDB_CSTR);
#if VLX_PHYS_SYNC == 1 && PHYS_SWELL == 1
    // PHYS_SWELL : le filet (normalise) x la focalisation de la houle visible
    // (physique, moyenne 1) ; wd EST la profondeur de propagation des photons.
    float r1 = 1.0 + (vlCa4Net(pw, t, dth, subm, st, lightW) * e - 1.0) * k;
    if (vlxPhysOn > 0.5) r1 *= vlxPhysSwellFocus(pw, wd, lightW);
    return r1;
#else
    return 1.0 + (vlCa4Net(pw, t, dth, subm, st, lightW) * e - 1.0) * k;
#endif
}
#else
// Gate off: a pure forward. The six call sites are textually the old call.
float vlCaNetD(vec2 pw, float t, vec2 dth, float subm, float soft, vec3 lightW,
               float wd) {
#if VLX_PHYS_SYNC == 1 && PHYS_SWELL == 1
    float r1 = vlCa4Net(pw, t, dth, subm, soft, lightW);
    if (vlxPhysOn > 0.5) r1 *= vlxPhysSwellFocus(pw, wd, lightW);
    return r1;
#else
    return vlCa4Net(pw, t, dth, subm, soft, lightW);
#endif
}
#endif

// VOLUMETRIC variant - the underwater shafts. ONE field evaluation, no
// Jacobian and NO temporal jitter: the god-ray march already jitters its own
// steps, and a second noise source there shows up as grain inside the beams,
// so the 9 photons sit on the centred 3x3 grid (an exact quadrature of the
// converged estimator). The field, the lookup and therefore the MESH are the
// same as the surface net, so a beam and the spot it lights on the floor are
// the same filament at the same world position - that volume/surface
// continuity is most of what sells a dive.
// soft: 1 = crisp near the surface, 0.2 = wide and dissolved deep down; the
// threshold follows it so the shafts thin out with depth instead of flooding.
// Output is remapped onto causticSmall's band (base 0.42, peaks ~1.45) so the
// shaft shaping downstream (-0.42, x1.45, pow, gain) needs no change. The two
// remap constants are anchored on that band, measured on this field:
//   - threshold 1.1203 + 1.4222*soft. Both ends measured, not shaped by eye:
//     at soft 1 it sits on the 82nd percentile of xn, which leaves 18.0% of the
//     volume lit (v3's causticSmall sat at 10-20%, so the shaft gain, the
//     FINESSE / SPACING sliders and causticShaftMask need no retuning); at
//     soft 0.25 it sits on the 99.9th percentile, so the shafts CLOSE there
//     (0.1% left, 0.0% by soft 0.20). The taper is real: xn's spread collapses
//     as the splat widens, so deep shafts dissolve into haze by amplitude, they
//     do not switch off.
//   - gain 0.6289, solved so the p99.9 peak lands on 1.45 after the knee.
//     Measured band: peak 1.451, p99 1.445, and 18.0 / 17.6 / 18.0 / 17.3% lit
//     at CA4_SCALE 0.5 / 1 / 2 / 3 - the mesh dial does not move the band.
//     Full curve of the lit fraction, since it is not flat in between:
//     0.0% at soft 0.20, 0.1% at 0.25, 18% at 0.35, 28% at 0.50, 22% at 0.70,
//     18% at 1.0. The mid-depth bump is wide-and-faint, not bright: p99 there
//     is 0.65 against 1.45 at the surface, so it reaches the shaft shaping at
//     about a fifth of the amplitude.
float vlCa4Vol(vec2 pw, float t, float soft, vec3 lightW) {
    // Same obliquity map as the surface net, from the same rotated light
    // direction: a shaft and the spot it lights stay the same filament. And
    // the same FIELD as the surface net, whichever gate is on - that is what
    // keeps the beam and its lit spot one filament.
#if VLX_PHYS_SYNC == 1
    // PHYSICS_FIELD_SYNC : meme substitution qu'au filet de surface, une seule
    // ligne. C'est ce qui garde le faisceau et la tache qu'il eclaire sur le
    // MEME filament, maintenant celui du mod.
    vec2 g0 = (vlxPhysOn > 0.5) ? vlxPhysSlope(pw)
#if CA5_ON == 1
                                : vlCa5Slope(pw, t);
#else
                                : vlCa4Slope(pw, t);
#endif
#else
#if CA5_ON == 1
    vec2 g0 = vlCa5Slope(pw, t);
#else
    vec2 g0 = vlCa4Slope(pw, t);
#endif
#endif
    vec3 ca4A = vlCa4Aniso(lightW);
    vec2 d0 = vec2(ca4A.x * g0.x + ca4A.y * g0.y,
                   ca4A.y * g0.x + ca4A.z * g0.y) * CA4_DEV;
    float sf  = max(CA4_SHARP * soft, 0.05);
    float sc  = 1.0 / sf;
    float stp = CA4_PSPACE * sc;
    float rad = CA4_PRAD * sc;
    float ksp = 1.0 / (rad * rad);
    float S = 0.0;
    for (int i = -1; i <= 1; i++) {
        for (int j = -1; j <= 1; j++) {
            vec2 e = vec2(float(i), float(j)) * stp + d0;
            S += max(0.0, 1.0 - ksp * dot(e, e));
        }
    }
    // Its OWN expected count, not the surface one scaled: the centred grid
    // collects 1.20x at soft 1 rising to 1.59x at soft 0.2, so no single
    // scalar tracks it (see vlCa4V0).
    float xn = S / vlCa4V0(CA4_DEV * sf / CA4_SCALE);
#if CA5_ON == 1
    // Same band, same knee, same asymptote - re-solved on the v5 field so the
    // shaft shaping downstream (-0.42, x1.45, pow, gain), causticShaftMask and
    // the FINESSE / SPACING sliders need no retuning. See CA5_VOL_A above.
    float v = 0.42 + (xn - (CA5_VOL_A + CA5_VOL_B * clamp(soft, 0.0, 1.0)))
                     * CA5_VOL_GAIN;
#else
    float v = 0.42 + (xn - (1.1203 + 1.4222 * clamp(soft, 0.0, 1.0))) * 0.6289;
#endif
    float over = max(v - 1.20, 0.0);
    return min(v, 1.20) + over / (1.0 + over / 0.35); // asymptote 1.55
}
#endif
