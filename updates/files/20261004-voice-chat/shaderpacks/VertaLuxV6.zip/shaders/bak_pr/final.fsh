#version 120
/* Final pass: FXAA + sharpen + debug views + vignette + debanding.
   Input colortex0 is LDR with its luminance stored in alpha. */

#include "/lib/settings.glsl"
#include "/lib/common.glsl"
// DIMENSION_FX detection (debug view 25). NEVER put a comment after an #include:
// Iris takes the whole rest of the line as the path ("Illegal char" crash).
#include "/lib/dimension.glsl"

uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform sampler2D colortex2;
uniform sampler2D colortex3;
uniform sampler2D colortex4;
uniform sampler2D colortex5;
uniform sampler2D colortex6;
uniform sampler2D depthtex0;
#ifdef DISTANT_HORIZONS
uniform sampler2D dhDepthTex0;   // debug view 11: distinguish sky vs DH terrain
#endif
#if DEBUG_VIEW >= 19
uniform sampler2D shadowtex0;   // debug view 20: shadow map depth
uniform sampler2D shadowtex1;   // debug view 19: tex0-only texel detection
uniform sampler2D shadowcolor0; // debug view 19: shadow map color
#endif
#if DEBUG_VIEW == 29
// View 29 (MISSION CL3, colored-lights autopsy): raw LPV field + applied tint.
// The field is read through its Iris SAMPLER (image.lightImg directives are not
// gatable, so lightSampler exists even at EMISSIVE_LPV=0 - the top half then just
// shows a black/stale field, which is itself the diagnosis). Everything below is
// used ONLY inside the DEBUG_VIEW == 29 branch of main().
uniform sampler3D lightSampler;
uniform vec3 cameraPosition;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
#if CL_V3 == 1
// CL_V3: the diffusion ping-pongs lightImg/lightImgB by frame parity (composite.csh);
// mirror the reader convention of sampleLPVForward (lib/lighting.glsl): sample the
// volume COMPLETED last frame - odd frame -> A, even frame -> B. v120-safe parity.
uniform sampler3D lightSamplerB;
uniform int frameCounter;
vec4 dbgLpvTex(vec3 uvw) {
    int par29 = frameCounter - 2 * (frameCounter / 2);
    if (par29 == 1) return texture3D(lightSampler, uvw);
    return texture3D(lightSamplerB, uvw);
}
#else
vec4 dbgLpvTex(vec3 uvw) { return texture3D(lightSampler, uvw); }
#endif
// Grid scale of the field volume: CL_V3 = fixed 1.0 block/cell (block-aligned CL3
// grid), legacy = LPV_SCALE (VOXEL_SCALE * 2). Alpha encoding is identical in both
// chains (0 air / 1 solid / 2 source), so the display logic below needs no gate.
#if CL_V3 == 1
#define DBG_LPV_S 1.0
#else
#define DBG_LPV_S (VOXEL_SCALE * 2.0)
#endif

// ONE nearest LPV texel at camera-relative world position p (raw field, top half).
// Same world-aligned snap as sampleLPVForward (lib/lighting.glsl) - keep in sync.
vec4 dbgLpvCell(vec3 p) {
    float s = DBG_LPV_S;                                // 128^3 grid
    vec3 camBlock = floor(cameraPosition / s);
    vec3 cell = floor((p + (cameraPosition - camBlock * s)) / s) + 64.0;
    if (cell.x < 0.0 || cell.y < 0.0 || cell.z < 0.0 ||
        cell.x > 127.5 || cell.y > 127.5 || cell.z > 127.5) return vec4(0.0);
    return dbgLpvTex((cell + 0.5) / 128.0);
}

// Compact copy of sampleLPVForward (lib/lighting.glsl, not includable from this
// v120 post pass). Keep addressing and decode in sync with the original:
// CL_V3 = PLAIN trilinear (solids hold zero, no skip/renormalize), sqrt decode,
// Chebyshev fade; legacy = manual trilinear skipping SOLID cells, v2 sqrt decode.
vec3 dbgLpvForward(vec3 worldRelCam, vec3 normalW) {
    float s = DBG_LPV_S;
    vec3 p = worldRelCam + normalW * (0.55 * s);
    vec3 camBlock = floor(cameraPosition / s);
    vec3 g = (p + (cameraPosition - camBlock * s)) / s + 64.0 - 0.5;
    vec3 b = floor(g);
    vec3 f = g - b;
    vec3 acc = vec3(0.0);
    float ws = 0.0;
    for (int ix = 0; ix < 2; ix++)
    for (int iy = 0; iy < 2; iy++)
    for (int iz = 0; iz < 2; iz++) {
        vec3 c = b + vec3(float(ix), float(iy), float(iz));
        if (c.x < 0.0 || c.y < 0.0 || c.z < 0.0 || c.x > 127.5 || c.y > 127.5 || c.z > 127.5) continue;
        vec4 L = dbgLpvTex((c + 0.5) / 128.0);
#if CL_V3 == 0
        if (L.a > 0.5 && L.a < 1.5) continue;   // legacy only: skip SOLID cells
#endif
        float w = ((ix == 1) ? f.x : 1.0 - f.x)
                * ((iy == 1) ? f.y : 1.0 - f.y)
                * ((iz == 1) ? f.z : 1.0 - f.z);
        acc += L.rgb * w;
        ws  += w;
    }
#if CL_V3 == 1
    // CL_V3 decode (mirror of sampleLPVForward): no renormalization, v120-safe scrub,
    // sqrt after the trilinear, quadratic Chebyshev fade from half the 64-block reach.
    acc = max(acc, vec3(0.0));
    if (!(acc.x + acc.y + acc.z < 1.0e6)) acc = vec3(0.0);
    vec3 vD = sqrt(acc) * LPV_STRENGTH;
    vec3 apD = abs(p);
    float chebD = max(apD.x, max(apD.y, apD.z)) / (64.0 * s);
    float kD = clamp((chebD - CLV2_FADE_HALF) / (CLV2_FADE_END - CLV2_FADE_HALF), 0.0, 1.0);
    return vD * (1.0 - kD * kD);
#elif CL_V2 == 1
    if (ws <= 1e-4) return vec3(0.0);
    vec3 vD = sqrt(max(acc / ws, vec3(0.0))) * LPV_STRENGTH;
    vec3 apD = abs(p);
    float chebD = max(apD.x, max(apD.y, apD.z)) / (64.0 * s);
    float kD = clamp((chebD - CLV2_FADE_HALF) / (CLV2_FADE_END - CLV2_FADE_HALF), 0.0, 1.0);
    return vD * (1.0 - kD * kD);
#else
    if (ws <= 1e-4) return vec3(0.0);
    return (acc / ws) * LPV_STRENGTH;
#endif
}
#endif
uniform float viewWidth;
uniform float viewHeight;

varying vec2 uv;

#ifdef FXAA
// FXAA: smooths jaggies along the edge direction (luma read from alpha)
vec3 applyFxaa(vec2 coord, vec2 px) {
    float lC = texture2D(colortex0, coord).a;
    float lN = texture2D(colortex0, coord + vec2(0.0, px.y)).a;
    float lS = texture2D(colortex0, coord - vec2(0.0, px.y)).a;
    float lE = texture2D(colortex0, coord + vec2(px.x, 0.0)).a;
    float lW = texture2D(colortex0, coord - vec2(px.x, 0.0)).a;

    float lMin = min(lC, min(min(lN, lS), min(lE, lW)));
    float lMax = max(lC, max(max(lN, lS), max(lE, lW)));

    // no local contrast: nothing to smooth
    if (lMax - lMin < max(0.0312, lMax * 0.125)) {
        return texture2D(colortex0, coord).rgb;
    }

    float lNW = texture2D(colortex0, coord + vec2(-px.x,  px.y)).a;
    float lNE = texture2D(colortex0, coord + vec2( px.x,  px.y)).a;
    float lSW = texture2D(colortex0, coord + vec2(-px.x, -px.y)).a;
    float lSE = texture2D(colortex0, coord + vec2( px.x, -px.y)).a;

    vec2 dir = vec2(-((lNW + lNE) - (lSW + lSE)), (lNW + lSW) - (lNE + lSE));
    float dirReduce = max((lNW + lNE + lSW + lSE) * 0.03125, 0.0078125);
    float rcpDirMin = 1.0 / (min(abs(dir.x), abs(dir.y)) + dirReduce);
    dir = clamp(dir * rcpDirMin, vec2(-8.0), vec2(8.0)) * px;

    vec3 rgbA = 0.5 * (texture2D(colortex0, coord + dir * (1.0 / 3.0 - 0.5)).rgb
                     + texture2D(colortex0, coord + dir * (2.0 / 3.0 - 0.5)).rgb);
    vec3 rgbB = rgbA * 0.5 + 0.25 * (texture2D(colortex0, coord - dir * 0.5).rgb
                                   + texture2D(colortex0, coord + dir * 0.5).rgb);

    float lB = luma(rgbB);
    if (lB < lMin || lB > lMax) return rgbA;
    return rgbB;
}
#endif

void main() {
    #ifdef FXAA
        vec3 color = applyFxaa(uv, 1.0 / vec2(viewWidth, viewHeight));
    #else
        vec3 color = texture2D(colortex0, uv).rgb;
    #endif

    // adaptive sharpen: restores texture crispness after FXAA
    #ifdef SHARPEN_ACTIVE
    {
        vec2 pxS = 1.0 / vec2(viewWidth, viewHeight);
        vec3 blurS = (texture2D(colortex0, uv + vec2(0.0,  pxS.y)).rgb
                    + texture2D(colortex0, uv - vec2(0.0,  pxS.y)).rgb
                    + texture2D(colortex0, uv + vec2(pxS.x, 0.0)).rgb
                    + texture2D(colortex0, uv - vec2(pxS.x, 0.0)).rgb) * 0.25;
        color = clamp(color + (color - blurS) * SHARPEN_STRENGTH, 0.0, 1.0);
    }
    #endif

    // ---- Debug views (Debug menu) ----
    #if DEBUG_VIEW > 0
        bool dbg = true;
        #ifdef DEBUG_SPLIT
            // split screen: final image left, debug view right
            dbg = uv.x > 0.5;
            if (abs(uv.x - 0.5) < 0.0015) color = vec3(1.0, 0.8, 0.0);
        #endif
        if (dbg) {
            // TAAU: views reading SCENE buffers (gbuffers/depth/bloom, still
            // in the sub-rect) sample at uv * TAAU_S; colortex0 (post-TAA,
            // full res) and the shadow map stay at uv.
            #if DEBUG_VIEW == 1
                color = texture2D(colortex1, uv * TAAU_S).rgb;          // normals
            #elif DEBUG_VIEW == 2
#if GI_HALF_RES == 1
                // half-res GI/AO live in the lower-left quadrant -> extra *0.5
                color = vec3(texture2D(colortex6, uv * (0.5 * TAAU_S)).r); // SSAO
#else
                color = vec3(texture2D(colortex6, uv * TAAU_S).r);      // SSAO
#endif
            #elif DEBUG_VIEW == 3
#if GI_HALF_RES == 1
                color = texture2D(colortex4, uv * (0.5 * TAAU_S)).rgb * 0.25; // GI buffer
#else
                color = texture2D(colortex4, uv * TAAU_S).rgb * 0.25;   // GI buffer
#endif
            #elif DEBUG_VIEW == 4
                float dd = texture2D(depthtex0, uv * TAAU_S).r;
                color = vec3(pow(dd, 64.0));                            // depth
            #elif DEBUG_VIEW == 5
                float fl = texture2D(colortex2, uv * TAAU_S).b;         // material flags
                color = vec3(0.0);
                if (fl > 0.9) color = vec3(0.1, 0.3, 1.0);              // water
                else if (fl > 0.6) color = vec3(0.2, 1.0, 0.8);         // glass
                else if (fl > 0.4) color = vec3(1.0, 0.6, 0.1);         // emissive
            #elif DEBUG_VIEW == 6
                color = vec3(texture2D(colortex2, uv * TAAU_S).rg, 0.0); // lightmap
            #elif DEBUG_VIEW == 7
                color = texture2D(colortex5, uv * TAAU_S).rgb;          // albedo
            #elif DEBUG_VIEW == 8
                #if BLOOM_HALF_RES == 1
                color = texture2D(colortex3, uv * (0.5 * TAAU_S)).rgb;  // bloom (half-res quadrant)
                #else
                color = texture2D(colortex3, uv * TAAU_S).rgb;          // bloom
                #endif
            #elif DEBUG_VIEW == 9
                color = vec3(texture2D(colortex2, uv * TAAU_S).g);      // skylight
            #elif DEBUG_VIEW == 10
                color = vec3(texture2D(colortex2, uv * TAAU_S).r) * vec3(1.0, 0.55, 0.2); // torchlight
            #elif DEBUG_VIEW == 11
                float dM = texture2D(depthtex0, uv * TAAU_S).r;
                color = (dM >= 1.0) ? vec3(0.1, 0.2, 0.5) : vec3(0.05); // sky mask
#ifdef DISTANT_HORIZONS
                // DH terrain in GREEN: quick check that LODs are not
                // treated as sky by the pipeline.
                if (dM >= 1.0 && texture2D(dhDepthTex0, uv * TAAU_S).r < 1.0)
                    color = vec3(0.1, 0.5, 0.2);
#endif
            #elif DEBUG_VIEW == 12
                color = vec3(luma(texture2D(colortex0, uv).rgb));       // luminance
            #elif DEBUG_VIEW == 19
                // View 19: shadow map color + tex0/tex1 overlay. Where
                // tex1 > tex0 the geometry exists only in shadowtex0 (Iris
                // translucent phase): RED = tex0-only not tagged water/glass,
                // BLUE = tagged water/glass (tinted shadows expected).
                vec4 sc19 = texture2D(shadowcolor0, uv);
#if SHADOW_TEX1_GATE_FIX == 1
                // Decode the banded color (water/glass/solid, see shadow.fsh)
                // for display, then overlay tex0-only texels.
                float mx19 = max(max(sc19.r, sc19.g), sc19.b);
                color = (mx19 < 0.325) ? clamp(sc19.rgb / 0.30, 0.0, 1.0)
                      : (mx19 < 0.675) ? clamp((sc19.rgb - 0.35) / 0.30, 0.0, 1.0)
                                       : clamp((sc19.rgb - 0.70) / 0.30, 0.0, 1.0);
                if (texture2D(shadowtex1, uv).r - texture2D(shadowtex0, uv).r > 0.000001) {
                    color = (mx19 < 0.675) ? mix(color, vec3(0.15, 0.35, 1.0), 0.55)
                                           : mix(color, vec3(1.0, 0.0, 0.0), 0.85);
                }
#else
                color = sc19.rgb;
                if (texture2D(shadowtex1, uv).r - texture2D(shadowtex0, uv).r > 0.000001) {
                    color = (sc19.a > 0.2) ? mix(color, vec3(0.15, 0.35, 1.0), 0.55)
                                            : mix(color, vec3(1.0, 0.0, 0.0), 0.85);
                }
#endif
            #elif DEBUG_VIEW == 20
                float sdD = texture2D(shadowtex0, uv).r;                // shadow map depth
                color = vec3(clamp((sdD - 0.25) * 2.0, 0.0, 1.0));      // exact remap of the z*0.25 packing -> [0,1]
            #elif DEBUG_VIEW == 21
                // View 21: raw per-pixel shadow factor (sampleShadowPCF luma),
                // written by gbuffers_terrain/entities into colortex5, no
                // post-processing.
                color = texture2D(colortex5, uv * TAAU_S).rgb;          // TAAU
            #elif DEBUG_VIEW == 22
                // View 22: shadow receiver classification - WHITE lit / BLACK
                // opaque shadow / RED solid tex0-only band / BLUE water band /
                // CYAN glass-portal band / GREEN partial-alpha solid /
                // YELLOW s0>s1 anomaly / MAGENTA outside map.
                color = texture2D(colortex5, uv * TAAU_S).rgb;          // TAAU
            #elif DEBUG_VIEW == 23
                // View 23: final water reflection RGB (composite1 -> colortex5);
                // outside water: attenuated albedo.
                color = texture2D(colortex5, uv * TAAU_S).rgb;          // TAAU
            #elif DEBUG_VIEW == 24
                // View 24: R = SSR hit confidence, G = reflection weight,
                // B = fresnel.
                color = texture2D(colortex5, uv * TAAU_S).rgb;          // TAAU
            #elif DEBUG_VIEW == 25
                // View 25: dimension detection (lib/dimension.glsl) - full
                // screen tint: RED = Nether, VIOLET = End, GREEN = Overworld
                // (grey when DIMENSION_FX is off: detection compiled out).
#if DIMENSION_FX == 1
                vec3 dimTint = (dimNether() > 0.5) ? vec3(1.0, 0.1, 0.1)
                             : (dimEnd() > 0.5)    ? vec3(0.7, 0.2, 1.0)
                                                   : vec3(0.1, 1.0, 0.2);
#else
                vec3 dimTint = vec3(0.5);
#endif
                color = mix(color, dimTint, 0.5);
            #elif DEBUG_VIEW == 26
                // View 26: END BLACK HOLE contributions in false colour. It is
                // painted by deferred.fsh straight onto the End sky pixels
                // (endBlackHoleDebug, lib/blackhole.glsl) and then rides the
                // NORMAL chain - storm, haze, tonemap - so nothing has to be
                // done here: RED = photon ring, GREEN = lensed far slab,
                // BLUE = near slab in front of the shadow, MAGENTA = shadow,
                // and any bright shape that is NOT neon is an END STORM tower
                // rather than a second black hole.
            #elif DEBUG_VIEW == 27
                // View 27: the UNDERWATER SHAFT probe, written by composite1
                // into colortex5 and displayed raw (no tonemap, no post)
                // exactly like views 21..24. Legend, kept in sync with
                // lang/*.lang value.DEBUG_VIEW.27 and with the painting site in
                // composite1.fsh:
                //
                // UW_SHAFT_FIX3 == 1 -- the THREE CAUSES, one screenshot.
                // BLACK WATER = all three healthy; dry land is black too.
                //   RED   (A) angle between the axis the BEAMS are drawn on and
                //         the axis the SHADOW MAP projects on, full red at 30
                //         deg. Exactly 0 above 8.63 deg of sun elevation, up to
                //         a dark 0.19 at the beam's cut-off (lightW.y = 0.05).
                //         Brighter red than that = a term escaped and the beams
                //         are aimed where the cast shadow does not point.
                //   GREEN (B) this pixel is OCCLUDED in the shadow map, read
                //         with the same probe the march now runs. Put your own
                //         shadow on the sea floor: the green patch IS it. Beams
                //         staying bright across it = the march is not consulting
                //         the map and (B) is alive.
                //   BLUE  (C) the shadow probe has NO DATA here (outside the
                //         map, or past its frustum Z) -- where vis fails OPEN
                //         and a beam would invent sunlight. Blue under a visible
                //         shaft is the leak; the shaft must fade across it.
                //   Purple = a leak zone that is also shadowed, i.e. (C) hiding
                //         behind (B).
                //
                // UW_SHAFT_FIX3 == 0 -- the legacy DIRECTION readout: RGB =
                // dir * 0.5 + 0.5, water and a submerged eye carrying the beam
                // direction and everything else the raw air lightW, so the two
                // read side by side. With UW_SUN_COHERENT on the water is
                // visibly GREENER (a larger +y) than the land and stops moving
                // past 48.59 deg of air incidence -- the Snell cone made
                // visible; with it off the two are the SAME colour.
                color = texture2D(colortex5, uv * TAAU_S).rgb;          // TAAU
            #elif DEBUG_VIEW == 28
                // View 28: GLASS_SEE_THROUGH probe, written by composite1 into
                // colortex5 on the GLASS and WATER branches, displayed raw (no
                // tonemap, no post) exactly like views 21..24. Legend, kept in
                // sync with lang/*.lang option.GLASS_SEE_THROUGH.comment:
                //   BLACK          neither glass nor water on this pixel
                //   DARK BLUE      plain water, dressed by the water branch
                //   CYAN           glass, but CUTOUT glass (the pane owns
                //                  depthtex1): nothing behind it to rebuild
                //   RED            translucent pane, no water measured behind
                //   YELLOW         water measured, no submerged span crossed
                //   WHITE / PINK   column applied, blue amount = span length
                color = texture2D(colortex5, uv * TAAU_S).rgb;          // TAAU
            #elif DEBUG_VIEW == 30
                // View 30: PHYSICS_FIELD_SYNC probe, written by composite1 into
                // colortex5, displayed raw exactly like views 21..24/27/28.
                // Legend, kept in sync with the PHYSICS_FIELD_SYNC and DEBUG
                // blocks of lib/settings.glsl:
                //   BLACK   the PHYSICS MOD ocean heartbeat is STALE this frame
                //           (mod absent / ocean off / gate 0) - every water
                //           effect stays on the pack's own field.
                //   RED     heartbeat alive, but this pixel does not carry the
                //           current frame's stamp: it is not a mod ocean surface.
                //   GREEN   this pixel IS a mod ocean surface this frame; the
                //           green LEVEL is the local waviness (0 calm shore,
                //           1 open sea).
                //   BLUE    height of the REIMPLEMENTED physics field sampled at
                //           the pixel's world xz. THE DRIFT TEST: the blue
                //           fringes must slide CONTINUOUSLY across chunk borders.
                //           A 16-block staircase means the per-chunk drift is not
                //           global and would have to be published per chunk.
                color = texture2D(colortex5, uv * TAAU_S).rgb;          // TAAU
            #elif DEBUG_VIEW == 29
                // View 29 (MISSION CL3): COLORED-LIGHTS AUTOPSY, two halves.
                //   TOP    = RAW LPV field on the horizontal plane at EYE level,
                //            64x64 blocks around the camera squeezed 2:1 into the
                //            half-height band (Z compressed - a circular halo shows
                //            up squashed; distances are only true along X; map is
                //            axis-aligned, not view-aligned; magenta cross = camera).
                //            False
                //            colors: hue = field chroma, brightness = decoded
                //            luma; DARK GRAY = SOLID cells (walls as the LPV
                //            sees them); sources ping as whitened bright spots.
                //   BOTTOM = the tint the application ACTUALLY multiplies into
                //            the torch term (torchCol * vanilla lightmap curve,
                //            NO albedo) for the lower half's own pixels; sky
                //            stays black.
                // Diagnosis: TOP black around the cross with torches nearby =
                // compute side dead (voxelization/injection/flood). TOP colored
                // but BOTTOM gray/white/burnt = application side (normalization
                // or bridges). One-sentence source note (comment only, DEBUG_VIEW
                // is off-menu so it never reaches the UI): lang/*.lang, # DEBUG_VIEW 29.
                if (uv.y > 0.5) {
                    vec2 m = vec2((uv.x - 0.5) * 64.0, (uv.y - 0.75) * 128.0); // +-32 blocks
                    vec4 Lc = dbgLpvCell(vec3(m.x, 0.0, m.y));
                    vec3 dec = sqrt(max(Lc.rgb, vec3(0.0)));   // v2 squared-space decode
                    float lu29 = luma(dec);
                    float mx29 = max(dec.r, max(dec.g, dec.b));
                    vec3 hue = (mx29 > 1e-4) ? dec / mx29 : vec3(0.0);
                    color = hue * clamp(lu29 * 1.5, 0.0, 1.0);
                    if (Lc.a > 0.5 && Lc.a < 1.5) color = vec3(0.18);      // SOLID cell
                    else if (Lc.a > 1.5) color = mix(color, vec3(1.0), 0.35); // SOURCE
                    if ((abs(m.x) < 0.5 && abs(m.y) < 2.0) || (abs(m.y) < 0.5 && abs(m.x) < 2.0))
                        color = mix(color, vec3(1.0, 0.05, 0.9), 0.8);     // camera cross
                } else {
                    float d29 = texture2D(depthtex0, uv * TAAU_S).r;
                    if (d29 >= 1.0) color = vec3(0.0);                      // sky
                    else {
                        vec4 ndc29 = vec4(uv * 2.0 - 1.0, d29 * 2.0 - 1.0, 1.0);
                        vec4 vp29 = gbufferProjectionInverse * ndc29;
                        vec3 viewP29 = vp29.xyz / vp29.w;
                        vec3 wrel29 = (gbufferModelViewInverse * vec4(viewP29, 1.0)).xyz;
                        vec3 nV29 = texture2D(colortex1, uv * TAAU_S).rgb * 2.0 - 1.0;
                        vec3 nW29 = mat3(gbufferModelViewInverse) * nV29;
                        vec3 lpv29 = dbgLpvForward(wrel29, nW29);
                        vec2 lm29 = texture2D(colortex2, uv * TAAU_S).rg;
                        // = getTorchColor() (lib/lighting.glsl, not includable here)
                        vec3 torch29 = vec3(1.0 * TORCH_R, 0.52 * TORCH_G, 0.18 * TORCH_B);
#if CL_V2 == 1 || CL_V3 == 1
                        vec3 cl29 = lpv29 + torch29 * CLV2_WARM_FLOOR;
                        torch29 = cl29 * (luma(torch29) / max(luma(cl29), 1e-3));
#else
                        float lpvL29 = luma(lpv29);
                        if (lpvL29 > 1e-4)
                            torch29 = mix(torch29, lpv29 * (luma(torch29) / lpvL29),
                                          CL_TINT_MIX * smoothstep(0.0005, 0.004, lpvL29));
#endif
                        float t29 = lm29.x * lm29.x * lm29.x * 2.0 + lm29.x * 0.08;
                        color = torch29 * t29;
                    }
                }
            #endif
        }
    #endif

    vec2 vc = uv - 0.5;
    color *= 1.0 - dot(vc, vc) * VIGNETTE * 2.2; // single vignette (intensity moved from composite5)

    #if DEBAND == 1
    // Debanding: triangular +-1/255 noise before 8-bit quantization. Two
    // independent noises summed give a triangular distribution (no visible
    // pattern), removing gradient banding.
    float dbn = bayer8(gl_FragCoord.xy) + hash12(gl_FragCoord.xy + 17.31) - 1.0;
    color = max(color + vec3(dbn) * (1.0 / 255.0), vec3(0.0));
    #endif

    gl_FragColor = vec4(color, 1.0);
}
