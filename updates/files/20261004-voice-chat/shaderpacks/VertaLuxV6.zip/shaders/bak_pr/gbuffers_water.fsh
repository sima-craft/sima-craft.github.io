#version 120
/* Translucents (fragment) : eau quasi transparente avec vagues, verre a
   micro-relief, portail du Nether. CORPS PARTAGE : tout le programme vit dans
   /lib/program_water_fragment.glsl (details, DRAWBUFFERS et contrat des
   colortex la-bas), compile une seconde fois par physics_ocean_v2.fsh
   (variante ocean de PHYSICS MOD PRO - PHYSICS_MOD_SUPPORT, lib/settings.glsl).
   Ici : chemin normal, aucun bloc PHYSICS_OCEAN actif. */

#include "/lib/program_water_fragment.glsl"
