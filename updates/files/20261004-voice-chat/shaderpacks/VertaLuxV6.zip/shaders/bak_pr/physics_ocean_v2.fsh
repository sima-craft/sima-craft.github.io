#version 430 compatibility
/* PHYSICS MOD PRO - programme ocean (fragment).
   Compagnon de physics_ocean_v2.vsh (voir son en-tete pour le mecanisme
   officiel du mod). Meme corps que gbuffers_water.fsh ; sous PHYSICS_OCEAN la
   normale ecrite au gbuffer (colortex1) est celle du champ de vagues simule
   du mod (physics_wavePixel), donc SSR / Fresnel / glint GGX / wMirror de
   composite1 eclairent les vagues du mod, et son ecume s'ajoute a la surface.
   SANS le mod, Iris ignore totalement ce fichier.

   POURQUOI 430 ET PLUS 120 (PHYSICS_FIELD_SYNC, lib/settings.glsl) : ce
   programme PUBLIE le champ du mod dans deux images Iris (physOceanParams /
   physOceanPix, shaders.properties) pour que composite1 puisse le lire, et
   imageStore exige GL 4.2. Le corps partage compile deja sous 430 sans rien
   changer (gbuffers_water.fsh, lui, RESTE en 120 et est bit-identique : il ne
   definit jamais VLX_PHYSICS_OCEAN_PROGRAM, donc ni PHYSICS_OCEAN ni le bloc
   d'images n'y existent). Un vsh 120 avec un fsh 430 est deja le montage de
   composite1 (composite1.vsh 120 + composite1.fsh 430 compatibility) et de
   toute la chaine composite du pack.

   LIMITES CONNUES (documentees) :
   - RESOLU par PHYSICS_FIELD_SYNC : les caustiques v4/v5/v6, les puits de
     lumiere sous-marins et l'ecume WHITECAPS de composite1 lisent maintenant
     le champ DU MOD (lib/water.glsl vlxPhysSlope, alimente par les images
     ci-dessus). La note "chantier futur" qui vivait ici disait qu'il faudrait
     que le mod expose son champ globalement : le canal lateral ci-dessus EST
     cette exposition, faite par le pack lui-meme.
   - PAS RESOLU : la REFRACTION de composite1 suivait deja le mod (elle lit la
     normale gbuffer) ; en revanche les RIDES du mod (physics_ripples :
     sillages de bateau, impacts) n'entrent pas dans le champ republie - seule
     la houle est reconstruite. Les caustiques suivent donc les vagues, pas les
     sillages.
   - Nos rides pluie/plongeon s'appliquent aussi ici (meme curseur que l'eau
     normale) ; le ring de plongeon peut legerement doubler les ripples
     propres du mod. Cosmetique et assume. */

#define VLX_PHYSICS_OCEAN_PROGRAM

#include "/lib/program_water_fragment.glsl"
