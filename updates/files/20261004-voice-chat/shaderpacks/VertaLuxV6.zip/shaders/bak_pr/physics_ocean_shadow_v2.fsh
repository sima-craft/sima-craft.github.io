#version 430 compatibility
/* PHYSICS MOD PRO - programme ombre de l'ocean (fragment).
   Compagnon de physics_ocean_shadow_v2.vsh. Identique a shadow.fsh (le
   deplacement de vague est 100 % vertex ; ici l'ocean recoit juste le tag eau
   de shadowcolor0 via matS = 8, et l'eau n'est jamais voxelisee - vxSkip).
   Le marqueur est pose par symetrie mais n'active aucun bloc dans ce corps. */

#define VLX_PHYSICS_OCEAN_PROGRAM

#include "/lib/program_shadow_fragment.glsl"
