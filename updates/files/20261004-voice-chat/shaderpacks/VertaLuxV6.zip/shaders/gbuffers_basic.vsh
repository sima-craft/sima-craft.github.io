#version 120
/* Basic geometry (vertex): lines, leash, world border. */

// TAAU: settings must be included first, it defines TAAU_S.
#include "/lib/settings.glsl"
#include "/lib/common.glsl"

varying vec4 glcolor;

void main() {
    gl_Position = ftransform();
    // TAAU: bottom-left sub-rect mapping, same as every other gbuffer pass.
    // ALL geometry must land inside the sub-rect or it drifts outside the
    // reconstructed image. Intentionally no TAA jitter on line geometry.
    // At TAAU_S = 1.0 this folds away at compile time (no-op).
    gl_Position.xy = gl_Position.xy * TAAU_S + gl_Position.w * (TAAU_S - 1.0);
    glcolor = gl_Color;
}
