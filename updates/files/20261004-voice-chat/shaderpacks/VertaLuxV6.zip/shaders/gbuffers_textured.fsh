#version 120
/* Particles and misc textured geometry. Lightmap shading + real sun shadow
   on the direct term (PARTICLE_SHADOWS).
   Writes: colortex0 = lit albedo, colortex1 = flat normal/material, colortex2 = lightmap. */

#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/distort.glsl"
#include "/lib/biome.glsl"
#include "/lib/dimension.glsl"
#include "/lib/lighting.glsl"

uniform sampler2D gtexture;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 viewPos;

void main() {
    vec4 col = texture2D(gtexture, texcoord) * glcolor;
    if (col.a < 0.05) discard;

    vec3 albedo = toLinear(col.rgb);
    // Sun visibility for the direct term. Declared OUTSIDE the gate (used below).
    vec3 sunVis = vec3(1.0);
#if PARTICLE_SHADOWS == 1
    // Real shadow on the SUN term only: a particle in tree shade goes dark like
    // the terrain around it. Same helpers/energy path as shadeSurface (PCSS with
    // blocker early-out, fail-open outside the map, lightmap fallback past the
    // shadow range). Billboards have no normal: the anti-acne offset in
    // toShadowClip is taken along the LIGHT direction instead (particles are not
    // in the shadow map, so self-shadowing is impossible anyway).
    if (lmcoord.y > 0.01) {
        vec3 Lv = normalize(shadowLightPosition);
        float pDist = length(viewPos);
        float sfade = smoothstep(0.85, 1.0, pDist / shadowDistance);
        vec3 sh;
        if (sfade >= 1.0) sh = vec3(lmcoord.y * lmcoord.y);
#if PARTICLE_FAST_SHADOWS == 1
        // Far particles (> 24 blocks = 2-6 px on screen): the PCSS penumbra is
        // sub-pixel there, so ONE hard shadowtex1 tap replaces the blocker
        // search + SHADOW_SAMPLES PCF. Same clip mapping, distortion, bias and
        // fail-open as sampleShadowPCF; translucent-caster tint is dropped
        // (invisible at that size). Near particles keep the full soft shadow.
        else if (pDist > 24.0) {
            vec3 scF = toShadowClip(viewPos, Lv);
            float fF = getDistortFactor(scF.xy);
            vec3 spF = distortShadow(scF, fF) * 0.5 + 0.5;
            float hardF = 1.0; // fail-open outside the map, like sampleShadowPCF
            if (spF.x > 0.0 && spF.x < 1.0 && spF.y > 0.0 && spF.y < 1.0) {
                float zF = spF.z - (0.00012 + 0.00010 * fF) * (VLX_SHADOW_ZSCALE * 2.0); // bias sync sampleShadowPCF
                if (zF < 1.0) hardF = step(zF, texture2D(shadowtex1, spF.xy).r);
            }
            sh = mix(vec3(hardF), vec3(lmcoord.y * lmcoord.y), sfade);
        }
#endif
        else sh = mix(getShadow(viewPos, Lv, bayer8(gl_FragCoord.xy)), vec3(lmcoord.y * lmcoord.y), sfade);
        #ifdef VOLUMETRIC_CLOUDS
        #ifdef VC_GROUND_SHADOWS
        // Cloud shadow parity with the terrain (soft penumbra - this is the only
        // shadow rain/snow effectively sees, the hard map term is sun-gated).
        vec3 wpP = (gbufferModelViewInverse * vec4(viewPos, 1.0)).xyz + cameraPosition;
        sh *= cloudShadow(wpP, normalize(mat3(gbufferModelViewInverse) * shadowLightPosition));
        #endif
        #endif
        sunVis = sh;
    }
#endif
#if EMISSIVE_LPV == 1
    // Colored lights bridge (parity with terrain/entities/hand and
    // gbuffers_textured_lit): ONE trilinear LPV read at the fragment's WORLD position
    // tints the torch term. Billboards have no normal, so no offset is passed
    // (sampleLPVForward skips SOLID cells and renormalizes; 0 = vanilla fallback).
    vec3 torchP = getTorchColor();
    {
        vec3 wrelP = (gbufferModelViewInverse * vec4(viewPos, 1.0)).xyz;
        vec3 lpvP  = sampleLPVForward(wrelP, vec3(0.0));
#if CL_V2 == 1 || CL_V3 == 1
        // v2/v3 (parity with shadeSurface): field colour + warm floor, luminance-normalized.
        vec3 clP = lpvP + torchP * CLV2_WARM_FLOOR;
        // Guard 1e-3 (CL3): never fires in normal operation (floor luma 0.0299); bounds
        // the blow-up on NaN/garbage frames. Keep in sync with shadeSurface.
        torchP = clP * (luma(getTorchColor()) / max(luma(clP), 1e-3));
#else
        float lpvPL = luma(lpvP);
        if (lpvPL > 1e-4)
            torchP = mix(torchP, lpvP * (luma(getTorchColor()) / lpvPL), CL_TINT_MIX * smoothstep(0.0005, 0.004, lpvPL));
#endif
    }
    vec3 light = getAmbientColor() * (lmcoord.y * lmcoord.y * 0.9 + 0.1)
               + getLightColor() * 0.25 * lmcoord.y * sunVis
               + torchP * (lmcoord.x * lmcoord.x * 1.5);
#else
    vec3 light = getAmbientColor() * (lmcoord.y * lmcoord.y * 0.9 + 0.1)
               + getLightColor() * 0.25 * lmcoord.y * sunVis
               + getTorchColor() * (lmcoord.x * lmcoord.x * 1.5);
#endif
#if DIMENSION_FX == 1
    // Nether / End have no skylight: complete the dimensional ambient to its
    // full share and add the End's fixed light (both exactly 0 in the Overworld).
    light += getAmbientColor() * (0.9 * (1.0 - lmcoord.y * lmcoord.y) * max(dimNether(), dimEnd()))
           + getLightColor() * (0.25 * dimEnd());
#endif
    light = max(light, vec3(0.05));

/* DRAWBUFFERS:012 */
    gl_FragData[0] = vec4(albedo * light, col.a);
    gl_FragData[1] = vec4(0.5, 0.5, 0.0, 1.0);
    gl_FragData[2] = vec4(lmcoord, 0.0, 0.0);
}
