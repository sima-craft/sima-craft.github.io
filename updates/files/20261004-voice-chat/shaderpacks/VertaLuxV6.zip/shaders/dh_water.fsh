#version 330 compatibility
/* VertaLux — Distant Horizons : eau LOD (fragment).
   L'eau LOD est AUTONOME : meme teinte desaturee que gbuffers_water + reflet
   de ciel analytique en Fresnel + glint soleil — le chemin "l'eau doit etre
   belle par elle-meme" du pack (gbuffers_water.fsh:458), applique aux LODs.

   DECISION FLAG (colortex2.b) : PAS 1.0. La branche eau de composite1
   (data2.b > 0.95) repose entierement sur depthtex0/depthtex1 (refraction,
   absorption par epaisseur, caustiques, SSR ray-marche) — pour un pixel LOD
   ces depths vanilla valent 1.0 : epaisseur d'eau fausse, SSR sans scene a
   toucher -> artefacts garantis. Les sondes-ecran "waterNear" (composite1
   lignes ~171/702/991) scannent aussi b > 0.95 et reconstruiraient des
   positions-ciel. On ecrit donc 0.2 : INERTE pour TOUS les tests existants
   (>0.95 eau, 0.6-0.8 verre, 0.82-0.93 portail, <0.01 overlays, <0.05 opaque
   GI) tout en marquant "eau DH" si l'integration composite veut un jour la
   distinguer (test abs(b - 0.2) < 0.05). Le reflet SSR reste donc du ressort
   de CE programme (repli ciel analytique honnete, pas de SSR aveugle).
   La brume DH de composite1 lit colortex2.g (skylight) : ecrit ici. */

// Opt-out de la compensation d'ambiante SSGI/RSM de shadeSurface (GI-RSM) :
// meme raison que dh_terrain.fsh — composite1 ne reinjecte jamais le rebond
// sur un pixel DH (isDHpix), donc la compensation assombrirait le LOD sans
// contrepartie. Voir le bloc GI_BOUNCE_AMBIENT dans lib/lighting.glsl.
#define VLX_DH_NO_GI_COMP

#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/water_sky_tint.glsl"
#include "/lib/distort.glsl"
#include "/lib/biome.glsl"
#include "/lib/dimension.glsl"
#include "/lib/lighting.glsl"

uniform float far;
// DH_WATER_CLIP (declares hors gate expres, style deferred.fsh : une
// declaration gated ne peut pas rendre un usage orphelin, et un uniform
// inutilise est sans cout) :
uniform sampler2D depthtex1;            // opaque vanilla, fige avant la phase translucide
uniform mat4 gbufferProjectionInverse;  // frustum VANILLA (pas dhProjectionInverse)
uniform float viewWidth;
uniform float viewHeight;

varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 normal;
varying vec3 viewPos;

void main() {
    // Anti-double-rendu : l'eau vanilla (gbuffers_water) couvre deja la zone
    // sous far-32 ; une nappe DH par-dessous doublerait l'alpha-blend (eau
    // deux fois plus sombre sur la couture).
    if (length(viewPos) < max(far - 32.0, 32.0)) discard;

#if DH_WATER_CLIP == 1
    // DH_WATER_CLIP -- « l'eau qu'on voit a travers les murs ». Les programmes
    // dh_* passent leur test de profondeur MATERIEL contre le SEUL depth
    // buffer DH (dhDepthTex*) : la geometrie vanilla n'y existe pas, et ce
    // pass blende directement dans colortex0 (pack forward — la couleur du
    // gbuffer est deja eclairee, composite1 ne re-arbitre jamais un pixel
    // blende). Une nappe d'ocean LOD a 600 blocs se composait donc PAR-DESSUS
    // un mur vanilla a 5 blocs. Parade standard : discard de tout fragment
    // LOD situe DERRIERE l'opaque vanilla du meme pixel. depthtex1 (opaque
    // SEUL) et pas depthtex0 : l'ocean LOD doit RESTER visible a travers une
    // vitre ou l'eau vanilla. Comparaison en Z VUE — l'espace vue est COMMUN
    // aux deux frustums (seule la projection differe), et la reconstruction
    // (0,0,ndcZ) est exacte pour une projection MC standard (le jitter TAA ne
    // deplace que ndc.xy, gl_FragCoord et depthtex1 vivent dans le meme
    // sous-rect TAAU -> l'UV se lit telle quelle, sans remap TAAU_S).
    // Marge 2.0 blocs vers le MAINTIEN de l'eau : dans l'anneau de couture
    // [far-32, far] ou LOD et vanilla coexistent a profondeur voisine, un
    // TROU dans l'ocean se verrait ; 1-2 blocs d'eau LOD par-dessus une berge
    // a 300+ blocs (sub-pixel) ne se voient pas. Un mur, lui, est des
    // CENTAINES de blocs devant : la marge ne le concerne jamais.
    {
        float d1w = texture2D(depthtex1, gl_FragCoord.xy / vec2(viewWidth, viewHeight)).r;
        if (d1w < 1.0) {
            vec4 vzW = gbufferProjectionInverse * vec4(0.0, 0.0, d1w * 2.0 - 1.0, 1.0);
            if (vzW.z / vzW.w > viewPos.z + 2.0) discard; // vanilla devant -> le mur gagne
        }
    }
#endif

    // Teinte de surface identique a gbuffers_water (desaturation biome).
    // HORS PALIER WATER_TINT, ASSUME - nomme ici parce que l'audit EAU5 avait
    // oublie ce chemin dans son enumeration des sites qui teintent un pixel
    // d'eau. Ce pass a son propre albedo, son propre Fresnel et son propre
    // reflet (reflDH plus bas) : ni WT_*, ni WCOL_*, ni WATER_REFLECTIVITY. Et
    // composite1 ne lit jamais le flag 0.2 que ce pass ecrit, donc ces pixels ne
    // passent ni par waterColumn ni par reflW. Impact nul aux defauts : le
    // discard ci-dessus cantonne ce pass au-dela de far-32, ou le clamp 0.98 de
    // reflW sature deja le miroir vanilla aux deux crans du palier - WATER_TINT
    // y est de toute facon muet (voir la limite de portee, lib/settings.glsl).
    // NE VAUT QUE POUR WATER_TINT (le MILIEU). WATER_SKY_TINT, lui, EST
    // applique ici : voir le site 5 dans le bloc reflDH plus bas. Le meme
    // raisonnement de portee ne s'y transpose pas — un miroir sature est
    // l'endroit ou un changement de couleur porte le PLUS, pas le moins.
    vec3 tintLin = toLinear(glcolor.rgb);
    vec3 albedo = mix(tintLin, vec3(luma(tintLin)), 0.5 * WATER_TINT_DESAT) * 0.18;

    vec3 normalV = normalize(normal);
    float dither = bayer8(gl_FragCoord.xy);
    vec3 color = shadeSurface(albedo, normalV, lmcoord, viewPos, dither, 0.0);

    // Reflet du ciel en Fresnel + opacite montante en angle rasant : memes
    // formules que le chemin autonome de gbuffers_water (coherence exacte de
    // teinte de part et d'autre de la couture vanilla/DH).
    float ndv = clamp(dot(normalV, -normalize(viewPos)), 0.0, 1.0);
    float fresG = 0.02 + 0.98 * pow(1.0 - ndv, 5.0);
    float skyl2 = lmcoord.y * lmcoord.y;
    #ifdef WATER_SKY_REFLECT
        // WATER_SKY_TINT — SITE 5, l'ocean DH. Ce chemin avait ete ecarte a
        // l'audit EAU6 sur le motif "n'appelle aucune fonction de ciel" : vrai
        // a la lettre (le reflet est bati sur getAmbientColor/getLightColor,
        // donc invisible a un grep getSky*), faux sur le fond — c'est un ciel
        // reflechi dans de l'eau, exactement ce que le palier existe pour
        // teinter. MESURE A LA COUTURE VANILLA/DH (midi, discard far-32 ligne
        // ~38), teinte du miroir vanilla livre contre teinte du reflet DH
        // (216.9 deg) AVANT ce correctif : ecart -6.4 deg au cran 0, +12.9 au
        // cran 2 (LE DEFAUT LIVRE), +30.3 au cran 3 — l'ecart doublait et
        // CHANGEAIT DE SIGNE au defaut. La justification "au-dela de far-32 le
        // clamp 0.98 de reflW sature deja le miroir" ne sauvait rien : un
        // miroir sature a ~98 % est precisement l'endroit ou un changement de
        // COULEUR est MAXIMAL. Et DISTANCE_FOG vaut 0 par defaut, donc rien ne
        // masque la couture (ATMO_FOG seul, ~12 % a 160 blocs).
        // Applique AVANT l'echelle fresnel/skylight, comme composite1
        // (skyReflect pose la teinte avant le facteur skyl) : l'epargne des
        // hautes lumieres lit ainsi une luminance de ciel ABSOLUE.
        // Cran 0 = `return sky;`, donc bit-identique au rendu livre.
        vec3 skyDH = getAmbientColor() * 0.65 + getLightColor() * 0.03;
        skyDH = waterSkyTint(skyDH);
        vec3 reflDH = skyDH * fresG * skyl2;
        // Glint soleil analytique (reflet speculaire du disque) : l'ocean DH
        // accroche la trainee du soleil/lune comme l'eau composite — sans SSR
        // (depth vanilla absente, cf. decision flag ci-dessus).
        vec3 Lw = normalize(shadowLightPosition);
        float spec = pow(clamp(dot(reflect(normalize(viewPos), normalV), Lw), 0.0, 1.0), 48.0);
        reflDH += getLightColor() * spec * fresG * smoothstep(0.7, 0.95, lmcoord.y)
               * 0.6 * WATER_SUN_GLINT;
        // Echo du REFLECT_DESAT de composite1 (reflet eau vanilla) : MEME
        // desaturation du reflet sur l'eau LOD -> aucune saute de teinte a la
        // couture vanilla/DH. #ifdef = no-op propre si le slider disparait.
        #ifdef REFLECT_DESAT
        reflDH = mix(reflDH, vec3(luma(reflDH)), clamp(REFLECT_DESAT, 0.0, 1.0));
        #endif
        color += reflDH;
    #endif
    float alpha = mix(0.50, 0.85, fresG);

/* DRAWBUFFERS:0125 */
    gl_FragData[0] = vec4(color, alpha);
    gl_FragData[1] = vec4(normalV * 0.5 + 0.5, 1.0);
    // flag 0.2 = eau DH (voir DECISION FLAG en tete) ; alpha 1.0 -> le blend
    // SRC_ALPHA remplace pleinement le texel (meme mecanique que gbuffers_water).
    gl_FragData[2] = vec4(lmcoord, 0.2, 1.0);
    // Teinte d'eau du biome, disponible si l'integration composite veut la lire.
    gl_FragData[3] = vec4(glcolor.rgb, 1.0);
}
