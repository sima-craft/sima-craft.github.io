#version 120
/*
    deferred: the sky is painted HERE, BEFORE translucents.
    Atmosphere + stars + sun/moon + cirrus/alto layers + volumetric cumulus,
    written onto the sky pixels of the opaque gbuffer (colortex0), so glass
    and water later blend over the real sky. In the End (END_STORM_ACTIVE)
    the volumetric storm + lightning glow of lib/end_storm.glsl replace the
    cloud chain over the End sky.
*/

#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/distort.glsl"
#include "/lib/biome.glsl"
#include "/lib/dimension.glsl"
#include "/lib/lighting.glsl"
#include "/lib/atmosphere.glsl"
#include "/lib/blackhole.glsl"
#include "/lib/sky.glsl"
#include "/lib/clouds.glsl"
#include "/lib/end_storm.glsl"

uniform sampler2D colortex0;
uniform sampler2D depthtex0;
#ifdef DISTANT_HORIZONS
// Distant Horizons LOD depth - SEPARATE from depthtex0
uniform sampler2D dhDepthTex0;
#endif
uniform mat4 gbufferProjectionInverse;
uniform vec3 skyColor;
uniform ivec2 eyeBrightnessSmooth;
// Guarded: lib/lighting.glsl declares frameCounter under SHADOW_V2 with the
// same guard (a duplicate uniform is a GLSL error).
#ifndef VL_FRAMECOUNTER_DECL
#define VL_FRAMECOUNTER_DECL
uniform int frameCounter; // blue-noise slice index (BLUE_NOISE=1)
#endif
// Standard uniforms, declared OUT of the gate on purpose (harmless when the
// gate is off): no gated declaration can strand a later use.
uniform float viewWidth;
uniform float viewHeight;
uniform int isEyeInWater; // SUN_HALO / RAINBOW_V2 gate (no sky optics underwater)
#ifdef CLOUD_PREPARE_ACTIVE
// Half-res premultiplied cloud chain baked by prepare.fsh (CLOUD_HALF_RES=1):
// lower-left quadrant of colortex15, rgb premultiplied, a = total coverage.
uniform sampler2D colortex15;
#endif

varying vec2 uv;

void main() {
    float d0 = texture2D(depthtex0, uv).r;
#ifdef VLX_DEFERRED_ACTIVE
    // PERF_DEFERRED (lib/settings.glsl) : colortex0.a porte le drapeau
    // "terrain differe" que deferred1 consomme JUSTE APRES cette passe. Le
    // ciel peint ci-dessous force aKeep = 1.0 ("deja shade") ; tout autre
    // pixel repart avec l'alpha que les gbuffers ont ecrit. A gate 0 cette
    // branche disparait et l'ecriture historique vec4(color, 1.0) revient
    // verbatim (hash identique).
    vec4 c0Full = texture2D(colortex0, uv);
    vec3 color = c0Full.rgb;
    float aKeep = c0Full.a;
#else
    vec3 color = texture2D(colortex0, uv).rgb;
#endif

    // Dimension detection: the Overworld has a real skyColor, Nether/End do
    // not (~black). skyColor goes to 0 at Overworld midnight, so a luma test
    // alone fails at night; fogColor.g vs .r separates Overworld blue from
    // End violet and Nether orange.
#if DIMENSION_FX == 1
    // DIMENSION_FX: exact detection from the Iris biome uniforms
    // (lib/dimension.glsl, double test: biome category + biome id). The
    // legacy color heuristic below misread most Nether biomes (their vanilla
    // skyColor is not black) as Overworld; prepare.fsh mirrors this choice.
    bool overworld = (dimNether() < 0.5 && dimEnd() < 0.5);
#elif DIM_DETECT_FIX == 1
    // Extra locks (night + neutral-gray fog used to misdetect Overworld as End):
    // (1) eye skylight > 8/240 is impossible in the Nether/End -> guarantees
    //     Overworld;
    // (2) g >= r counts neutral-gray fog (rain, night, blindness) as Overworld;
    //     End (violet) and Nether (orange) have strictly r > g.
    bool overworld = eyeBrightnessSmooth.y > 8
                  || luma(skyColor) > 0.004
                  || fogColor.g >= fogColor.r;
#else
    bool overworld = luma(skyColor) > 0.004 || fogColor.g > fogColor.r;
#endif

#ifdef DISTANT_HORIZONS
    // DH LODs write their depth into dhDepthTex0, NOT depthtex0. A pixel with
    // d0 >= 1.0 covered by a LOD is NOT sky: do not paint atmosphere over
    // DH terrain already shaded by dh_terrain.
    float dhD = texture2D(dhDepthTex0, uv).r;
    if (d0 >= 1.0 && dhD >= 1.0) {
#else
    if (d0 >= 1.0) {
#endif
#ifdef VLX_DEFERRED_ACTIVE
        aKeep = 1.0; // pixel ciel : peint ici, deferred1 n'y touchera pas
#endif
        // TAAU: sub-rect UV [0..TAAU_S] -> visible screen [0..1] before NDC
        // (division folds away at compile time when TAAU_S = 1.0).
        vec4 ndc = vec4(uv / TAAU_S, d0, 1.0) * 2.0 - 1.0;
        vec4 vw = gbufferProjectionInverse * ndc;
        vec3 worldDir = normalize(mat3(gbufferModelViewInverse) * (vw.xyz / vw.w));
        vec3 sunW = normalize(mat3(gbufferModelViewInverse) * sunPosition);
        vec3 lightW = normalize(mat3(gbufferModelViewInverse) * shadowLightPosition);
#if BLUE_NOISE == 1
        // Blue-noise march jitter (TAA-averaged). Feeds ONLY the volumetric
        // marches below (3D alto + cumulus) - nothing else reads it here.
        float dither = blueDither(gl_FragCoord.xy, frameCounter);
#else
        float dither = bayer8(gl_FragCoord.xy);
#endif

        if (!overworld) {
#if DIMENSION_FX == 1
            // Nether: fog-colored dome (zenith x0.6 -> horizon, biome hue).
            // End: violet-black gradient + nebula + cold stars (skyEndDim,
            // lib/sky.glsl). No clouds, halo, rainbow, sun or moon: the whole
            // Overworld chain below stays in its own branch.
            color = (dimNether() > 0.5) ? dimNetherSky(worldDir) : skyEndDim(worldDir);
#if defined END_BLACKHOLE_ACTIVE && DEBUG_VIEW == 26
            // BH2 DEBUG VIEW 26 (lib/blackhole.glsl, endBlackHoleDebug): the
            // black hole's OWN contributions in false colour - RED photon
            // ring, GREEN lensed far slab, BLUE unlensed near slab, MAGENTA
            // shadow - scaled low so ACES keeps the hues apart. The storm and
            // the haze are still composed on top, ON PURPOSE: whatever stays
            // grey-blue there is an END STORM tower, not a second hole.
            if (dimEnd() > 0.5) color = endBlackHoleDebug(worldDir) * 0.45;
#endif
#ifdef END_STORM_ACTIVE
            if (dimEnd() > 0.5) {
                // END STORM (lib/end_storm.glsl). Lightning first: a glow of
                // the far haze toward the bolt (wide lobe + soft core, dimmed
                // with the bolt distance), under the storm like the stars.
                {
                    vec3 bP;
                    vec3 bC;
                    float fl = endLightningState(frameTimeCounter, cameraPosition, bP, bC);
                    if (fl > 0.001) {
                        vec3 tb = bP - cameraPosition;
                        float dB = length(tb);
                        float c = 1.0 - dot(worldDir, tb / dB);
                        // HALO behind the towers: the wide lobe is what reads
                        // as a halo once the storm is composed on top of it,
                        // so it takes END_LIGHTNING_POWER like the in-cloud
                        // point light and a wider base (0.30 / 0.45 against
                        // 0.22 / 0.35). Sky only - the VL haze glow of
                        // composite1 and its lib/vl_halfres.glsl mirror are
                        // deliberately left alone so the two stay identical.
                        color += bC * (fl * (exp2(-9.0 * c) * 0.30 + exp2(-60.0 * c) * 0.45)
                                     * (200.0 / (dB + 100.0)) * (0.5 + 0.5 * min(END_HAZE_DENSITY, 2.0))
                                     * END_LIGHTNING_POWER);
                    }
                }
#ifdef END_STORM_PREPARE
                // Half-res temporal bake of prepare/prepare1: the SAME tap as
                // the Overworld cloud composite below (premultiplied pair,
                // quarter-texel jitter, clamp inside the written quadrant).
                vec2 pixE = 1.0 / vec2(viewWidth, viewHeight);
                vec2 qE = uv * 0.5 + (0.25 + (dither - 0.5) * 0.5) * pixE;
                qE = clamp(qE, 0.5 * pixE, vec2(0.5) - 0.5 * pixE);
                vec4 stE = texture2D(colortex15, qE);
                color = stE.rgb + color * (1.0 - stE.a);
#else
                // Inline full-res march (half-res cloud pass off)
                vec4 stE = endStormMarch(cameraPosition, worldDir, lightW, dither, frameTimeCounter, 1.0e9, 0.0);
                color = mix(color, stE.rgb, stE.a);
#endif
            }
#endif // END_STORM_ACTIVE
#else
            // Nether / End: dimension-specific sky
            bool nether = (fogColor.r > fogColor.b * 1.4);
            if (nether) {
                float down = clamp(-worldDir.y * 0.5 + 0.5, 0.0, 1.0);
                vec3 sky = mix(vec3(0.06, 0.015, 0.008), vec3(0.40, 0.10, 0.035), down * down);
                sky = mix(sky, toLinear(fogColor) * 1.6, 0.4);
                sky *= 0.7 + 0.6 * fbmTex(worldDir.xz / (abs(worldDir.y) + 0.3) * 2.0 + frameTimeCounter * 0.05);
                color = sky;
            } else {
                // End: violet void + nebula + cold stars
                float up = worldDir.y * 0.5 + 0.5;
                vec3 sky = mix(vec3(0.020, 0.010, 0.045), vec3(0.075, 0.050, 0.120), up);
                vec3 ax = normalize(vec3(0.3, 0.6, 0.74));
                vec3 eu = normalize(cross(ax, vec3(0.0, 1.0, 0.0)));
                vec3 ev = cross(ax, eu);
                vec2 np = vec2(dot(worldDir, eu), dot(worldDir, ev)) * 2.2;
                float sw = atan(np.y, np.x) * 1.5 + length(np) * 2.0 - frameTimeCounter * 0.03;
                float neb = smoothstep(0.35, 0.85, fbmTex(np * 1.6 + vec2(cos(sw), sin(sw)) * 0.5))
                          * exp(-pow(dot(worldDir, ax) * 1.6, 2.0));
                sky += mix(vec3(0.35, 0.10, 0.55), vec3(0.65, 0.25, 0.85), fbmTex(np * 3.0 + 9.0)) * neb * 0.8;
                sky += skyStars(worldDir, 0.7);
                color = sky;
            }
#endif // DIMENSION_FX (legacy heuristic skies above)
        } else {
        #ifdef PHYSICAL_SKY
            color = getSkyPhysical(worldDir, sunW);
        #else
            color = getSkyCelestial(worldDir, sunW);
        #endif

        #ifdef CLOUD_PREPARE_ACTIVE
        {
            // HALF-RES CLOUDS (CLOUD_HALF_RES=1): the full chain (cirrus/2D
            // alto sheet, 3D alto, 22-deg halo, rainbow, cumulus) was baked by prepare.fsh
            // into the lower-left quadrant of colortex15 as ONE PREMULTIPLIED
            // pair (rgb = folded layer colors, a = total coverage), rays built
            // with this very uv -> NDC mapping. One bilinear tap upsamples it
            // (the sky is smooth; premultiplied color cannot ring dark at
            // cloud edges) and ONE composite replaces the whole sequential
            // mix() chain - mathematically identical to it. Composition order
            // is unchanged: sun/moon/stars are already in "color" and the
            // clouds go OVER them, exactly as the inline path below.
            vec2 pix = 1.0 / vec2(viewWidth, viewHeight);
            // Stored quadrant texel i = full-res pixel 2i, so pixel j reads
            // quadrant coord j*0.5 + a quarter texel: even pixels land on
            // their exact stored ray, odd pixels on the true midpoint of
            // their two neighbours. The quarter-texel blue-noise jitter
            // (TAA-averaged, reuses the march dither) breaks the residual
            // 2x2 reconstruction grid; the clamp keeps the bilinear footprint
            // inside the written quadrant.
            vec2 q = uv * 0.5 + (0.25 + (dither - 0.5) * 0.5) * pix;
            q = clamp(q, 0.5 * pix, vec2(0.5) - 0.5 * pix);
            vec4 cl = texture2D(colortex15, q);
            color = cl.rgb + color * (1.0 - cl.a);
        }
        #else
        #if defined CLOUD_LAYER_ALTO || defined CLOUD_LAYER_CIRRUS
            vec4 hc = highClouds(cameraPosition, worldDir, sunW, cloudWorldTime()); // world time (cirrus + 2D alto)
            color = mix(color, hc.rgb, hc.a);
        #endif

        // Second volumetric layer: 3D altocumulus (over cirrus on screen since
        // lower in the sky; under the cumulus composed afterwards)
        #if defined CLOUD_LAYER_ALTO && ALTO_VOLUMETRIC == 1
        {
            vec4 av = volumetricAlto(cameraPosition, worldDir, lightW, dither, cloudWorldTime()); // world time (3D alto)
            color = mix(color, av.rgb, av.a);
        }
        #endif

        // 22-degree halo (SUN_HALO): ice ring on the thin high veils just
        // composed, under the cumulus. Additive ring + x0.96 inside.
        #if SUN_HALO == 1 && (defined CLOUD_LAYER_ALTO || defined CLOUD_LAYER_CIRRUS)
        if (isEyeInWater == 0) {
            float haloDark = 1.0;
            vec3 halo = skyHalo22(cameraPosition, worldDir, sunW, cloudWorldTime(), haloDark); // world time (veil fields)
            color = color * haloDark + halo;
        }
        #endif

        // Rainbow (RAINBOW_V2): graded double bow from the antisolar point,
        // Alexander's dark band as a multiplier, bows additive.
        #if defined RAINBOW && RAINBOW_V2 == 1
        if (isEyeInWater == 0) {
            float rbDark = 1.0;
            vec3 rb = skyRainbow(worldDir, sunW, rbDark);
            color = color * rbDark + rb;
        }
        #endif

        // Rainbow after rain: primary arc at 42 deg from the antisolar point,
        // fainter inverted secondary arc at 51 deg
        #if RAINBOW_V2 == 0 // legacy bow, replaced by skyRainbow above at 1
        #ifdef RAINBOW
        {
            float wetGlow = wetness * (1.0 - rainStrength)
                          * smoothstep(0.05, 0.3, sunW.y);
            if (wetGlow > 0.01) {
                float a = acos(clamp(dot(worldDir, -sunW), -1.0, 1.0));
                float pos = (a - 0.709) / 0.048;
                if (pos > -0.2 && pos < 1.2) {
                    float band = smoothstep(0.0, 0.18, pos) * smoothstep(1.0, 0.82, pos);
                    vec3 rb = clamp(vec3(smoothstep(0.45, 0.80, pos),
                                         exp(-pow((pos - 0.5) * 3.0, 2.0)),
                                         smoothstep(0.55, 0.20, pos)), 0.0, 1.0);
                    color += rb * band * 0.30 * wetGlow;
                }
                float pos2 = (a - 0.873) / 0.060;
                if (pos2 > -0.2 && pos2 < 1.2) {
                    float band2 = smoothstep(0.0, 0.18, pos2) * smoothstep(1.0, 0.82, pos2);
                    vec3 rb2 = clamp(vec3(smoothstep(0.55, 0.20, pos2),
                                          exp(-pow((pos2 - 0.5) * 3.0, 2.0)),
                                          smoothstep(0.45, 0.80, pos2)), 0.0, 1.0);
                    color += rb2 * band2 * 0.10 * wetGlow;
                }
            }
        }
        #endif
        #endif // RAINBOW_V2 == 0

        #ifdef VOLUMETRIC_CLOUDS
            vec4 vc = volumetricClouds(cameraPosition, worldDir, lightW,
                                       getSkyBase(worldDir, sunW),
                                       dither, cloudWorldTime(), 1.0e9); // world time (cumulus)
            color = mix(color, vc.rgb, vc.a);
        #endif
        #endif  // CLOUD_PREPARE_ACTIVE (inline fallback above)
        }   // end Overworld branch
    }

/* DRAWBUFFERS:0 */
#ifdef VLX_DEFERRED_ACTIVE
    gl_FragData[0] = vec4(color, aKeep); // alpha = drapeau PERF_DEFERRED preserve
#else
    gl_FragData[0] = vec4(color, 1.0);
#endif
}
