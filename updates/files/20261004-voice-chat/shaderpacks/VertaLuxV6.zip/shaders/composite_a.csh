#version 430 compatibility
/* VertaLux - LPV STAGE 2, FLOOD pass 1/4 (step 8).  PING-PONG: A(lightImg) -> B(lightImgB).
   Composite slot: Iris runs composite.csh (INJECTION, no suffix) then composite_a/b/c/d in
   ALPHABETICAL order ('.'=0x2E < '_'=0x5F, so injection goes first), with a
   glMemoryBarrier(TEXTURE_FETCH|SHADER_IMAGE_ACCESS) BEFORE AND AFTER each .csh (default mode,
   allowConcurrentCompute is ABSENT from shaders.properties), so each pass sees the previous
   pass's imageStore (read-after-write). After composite_d the result is back in A(lightImg),
   which is what sampleLPV (composite5) reads.
   Gate: EMISSIVE_LPV=0 OR LPV_PASSES<2 -> copy A->B (parity no-op, negligible cost).
   CL_V3=1 (lib/settings.glsl): the whole flood ladder is DEAD CODE - composite.csh
   alone diffuses via frame-parity ping-pong and OWNS both volumes, so this pass must
   not even copy (a stray A->B copy would clobber the parity history). Compiled out. */
#include "/lib/settings.glsl"
#include "/lib/common.glsl"

layout(local_size_x = 8, local_size_y = 8, local_size_z = 8) in;
const ivec3 workGroups = ivec3(16, 16, 16);   // 16*8 = 128 per axis

layout(rgba16f) uniform image3D lightImg;     // A
layout(rgba16f) uniform image3D lightImgB;    // B

#define LPVF_SRC  lightImg                      // reads A
#define LPVF_DST  lightImgB                     // writes B
#define LPVF_STEP 8
#include "/lib/lpv_flood.glsl"

void main() {
#if EMISSIVE_LPV == 0
    return; // LPV chain disabled -> no work at all
#endif
    ivec3 c = ivec3(gl_GlobalInvocationID);
    if (any(greaterThanEqual(c, ivec3(LPVF_RES)))) return;
#if EMISSIVE_LPV == 1 && CL_V3 == 0 && LPV_PASSES >= 2
    lpvFloodCell(c);    // A -> B, step 8
#elif EMISSIVE_LPV == 1 && CL_V3 == 0
    lpvCopyCell(c);     // parity: A -> B without propagating
#endif
}
