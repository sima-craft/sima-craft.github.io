#version 430 compatibility
/* VertaLux -- image finishing: bloom, auto-exposure, Purkinje, tonemapping,
   saturation, film grain, underwater warp.
   Voxel GI (smooth diffuse bounce + emissive) is added HERE, in LINEAR HDR,
   BEFORE bloom/exposure/tonemap, so it is tonemapped like everything else and
   its emission rolls off instead of hard-clipping to white. Temporal
   accumulation (colortex8/9) and emissive history live in this pass.
   NOTE: the bloom brightpass runs in composite2 (before this pass) on
   colortex0 which does not yet contain GI -> GI/emissive does NOT bloom.
   Reads colortex0 (HDR scene), colortex2/3, depthtex0.
   Writes colortex0 as LDR with luminance in alpha (consumed by final FXAA);
   under VOXEL_GI also writes colortex8/9/10 (GI/guide/emissive history). */

#include "/lib/settings.glsl"
// common.glsl provides: luma(), hash13(), hash12(), toLinear(), toSrgb()
#include "/lib/common.glsl"
// dimension.glsl: DIMENSION_FX Nether / End weights (auto-exposure bound,
// world-clock grades, godrays / lens flare / Purkinje gates below).
#include "/lib/dimension.glsl"

// === GI history buffer formats -- Iris directive, parsed INSIDE the /* */
//     comment. DO NOT UNCOMMENT. Clear=false is REQUIRED (history buffers).
//     These formats are declared ONLY in this file (single writer = composite5). ===
// PERF (RTX buffer purge): with RTX off (VOXEL_GI=0) and RTX_BUFFER_PURGE=1 the
// whole block below is compiled out, so NO colortex8/9/10/12 reference survives
// in any program (the samplers and both RENDERTARGETS lists are already gated)
// and Iris skips their allocation (~79 MiB per copy at 1080p, x2 with alt).
// CAVEAT: Iris's const scanner is line-by-line and may ignore this #if; that is
// harmless -- the formats stay registered but the buffers stay UNREFERENCED.
// PT REACTIVATION: nothing to re-edit here. VOXEL_GI=1 (plus FULL_PATH_TRACE=1
// for colortex12) brings the block back automatically.
#if VOXEL_GI == 1 || RTX_BUFFER_PURGE == 0
/*
const int  colortex8Format  = RGBA16F;
const int  colortex9Format  = RGBA32F;
const int  colortex10Format = RGBA16F;
const bool colortex8Clear   = false;
const bool colortex9Clear   = false;
const bool colortex10Clear  = false;
#if FULL_PATH_TRACE == 1
const int  colortex12Format = RGBA16F;
// Clear stays TRUE (verifier): allocation is driven by REFERENCES, not by the
// const scanner -- at FPT=0 the buffer is unallocated so the clear costs nothing;
// at FPT=1 pixels not covered by gbuffers_terrain (entities/hand/water/DH) would
// otherwise keep stale direct-light terms across frames.
const bool colortex12Clear  = true;
#endif
*/
#endif

// === BLOOM MIP: mip generation for colortex3 (brightpass pre-blurred by
//     composite2/3) -- Iris directive parsed inside the comment, declared in the
//     READING pass (composite5). NB: Iris's const scan is line-by-line, so the
//     #if may be ignored (mips generated even at BLOOM_MIP=0: benign, ~0.05 ms).
//     DO NOT UNCOMMENT. ===
/*
#if BLOOM_MIP == 1
const bool colortex3MipmapEnabled = true;
#endif
*/

uniform sampler2D colortex0;
uniform sampler2D colortex2;
uniform sampler2D colortex3;
uniform sampler2D depthtex0;
#if GODRAY_WATER_SPLIT == 1
uniform sampler2D depthtex1;     // OPAQUE depth: air share of a water pixel's path
#endif
#ifdef DISTANT_HORIZONS
uniform sampler2D dhDepthTex0;   // DH LOD depth: occludes godrays/lens flare
#endif
uniform mat4 gbufferProjection;
uniform vec3 sunPosition;
uniform vec3 upPosition;
uniform float rainStrength;
uniform float viewWidth;
uniform float viewHeight;
uniform float frameTimeCounter;
uniform float centerDepthSmooth;
uniform float near;
uniform float far;
uniform int isEyeInWater;
uniform int bossBattle;
uniform ivec2 eyeBrightnessSmooth;

#if DAMAGE_FX == 1
// Damage flash inputs. currentPlayerHealth: Iris uniform, health / max health in
// 0..1, -1 in creative/spectator. damageHealthLag: custom uniform (shaders.properties,
// smooth id 57) that snaps up instantly and decays with a 0.7 s half-life, so the
// positive difference = fraction of max health just lost. Declared and used ONLY
// under DAMAGE_FX==1: zero uniform reads when the effect is off.
uniform float currentPlayerHealth;
uniform float damageHealthLag;
#endif

// --- Voxel GI + temporal accumulation uniforms ---
//     All gated by VOXEL_GI==1: no clash with the uniforms above, zero cost when off.
#if VOXEL_GI == 1
uniform sampler2D colortex1;   // view-space normals (encoded *0.5+0.5)
uniform sampler2D colortex11;  // LabPBR metalness (.g) for opaque metal/glossy voxel reflections
uniform sampler2D colortex8;   // GI history: rgb = accumulated GI, a = frame count
uniform sampler2D colortex9;   // history guide: camera-RELATIVE worldPos, a = valid flag
#if EMISSIVE_VOXEL == 1
uniform sampler2D colortex10;  // emissive history: rgb = accumulated emissive, a = count.
                               // Declared as soon as emissive is ON (not only ACCUM==1):
                               // gl_FragData[3]=emisOut writes it unconditionally under
                               // VOXEL_GI==1, and CHECKERBOARD must texelFetch it on skipped
                               // pixels. Narrowing this gate breaks compilation with
                               // EMISSIVE_VOXEL=1 + EMISSIVE_ACCUM=0 + GI_CHECKERBOARD=1.
#endif
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform vec3 cameraPosition;
uniform vec3 previousCameraPosition;
uniform mat4 gbufferPreviousModelView;
uniform mat4 gbufferPreviousProjection;
uniform int  frameCounter;
#if FULL_PATH_TRACE == 1
uniform sampler2D colortex12;          // PURE sun direct (albedo-weighted), exported by gbuffers with shadow=1
uniform vec3 shadowLightPosition;      // ACTIVE light direction (sun by day / moon by night, Iris swaps it)
#endif
layout (rgba16f) uniform image3D voxelImg;
#if VOXEL_CASCADES > 1
layout (rgba16f) uniform image3D voxelImg1;
#endif
#if VOXEL_CASCADES > 2
layout (rgba16f) uniform image3D voxelImg2;
#endif
#if VOXEL_CASCADES > 3
layout (rgba16f) uniform image3D voxelImg3;
#endif
#if VOXEL_CASCADES > 4
layout (rgba16f) uniform image3D voxelImg4;
#endif
#if VOXEL_CASCADES > 5
layout (rgba16f) uniform image3D voxelImg5;
#endif
#if EMISSIVE_LPV == 1
layout (rgba16f) uniform image3D lightImg;   // LPV light field (read-only here).
                                              // lightImgB is NOT declared here: composite5 reads
                                              // lightImg ONLY; the flood/ping-pong lives in the .csh.
#include "/lib/lpv.glsl"
#endif
#endif

varying vec2 uv;   // matching .vsh is #version 120 (varying/ftransform); legal under 'compatibility'

#if BLOOM_MIP == 1
// Tap one LOD of the bloom pyramid (mipmapped colortex3). textureLod needs GLSL 430;
// composite5 is the only 430 post pass (the others stay on 120).
vec3 bloomMipTap(vec2 coord, float lod) {
    vec2 texel = exp2(lod) / vec2(viewWidth, viewHeight);
#if BLOOM_HALF_RES == 1
    // Half-res: keep the bilinear + cross footprint (~1.5 texels at this LOD)
    // inside the lower-left quadrant -- beyond it the pyramid is black, and
    // high-LOD taps would blend that dead zone into the top/right screen edge.
    coord = min(coord, vec2(0.5 * TAAU_S) - 1.5 * texel);
#endif
    vec3 s = textureLod(colortex3, coord, lod).rgb * 4.0;
    // +-1 texel cross at this LOD: breaks up bilinear diamonds at LOD >= 5
    s += textureLod(colortex3, coord + vec2(texel.x, 0.0), lod).rgb;
    s += textureLod(colortex3, coord - vec2(texel.x, 0.0), lod).rgb;
    s += textureLod(colortex3, coord + vec2(0.0, texel.y), lod).rgb;
    s += textureLod(colortex3, coord - vec2(0.0, texel.y), lod).rgb;
    return s * 0.125;
}
#endif

// ACES approximation (Krzysztof Narkowicz fit of the Academy reference)
vec3 aces(vec3 x) {
    const float a = 2.51;
    const float b = 0.03;
    const float c = 2.43;
    const float d = 0.59;
    const float e = 0.14;
    return clamp((x * (a * x + b)) / (x * (c * x + d) + e), 0.0, 1.0);
}

// Uchimura tonemap (fallback when ACES/AgX are off)
vec3 uchimura(vec3 x) {
    const float P = 1.0;
    const float a = 1.0;
    const float m = 0.22;
    const float l = 0.4;
    const float c = 1.33;
    float l0 = ((P - m) * l) / a;
    float S0 = m + l0;
    float S1 = m + a * l0;
    float C2 = (a * P) / (P - S1);
    float CP = -C2 / P;
    vec3 w0 = 1.0 - smoothstep(vec3(0.0), vec3(m), x);
    vec3 w2 = step(vec3(S0), x);
    vec3 w1 = 1.0 - w0 - w2;
    vec3 T = m * pow(x / m, vec3(c));
    vec3 S = P - (P - S1) * exp(CP * (x - S0));
    vec3 L = m + a * (x - m);
    return clamp(T * w0 + L * w1 + S * w2, 0.0, 1.0);
}

// AgX (minimal implementation, after Benjamin Wrensch / Troy Sobotka).
vec3 agxContrast(vec3 x) {
    vec3 x2 = x * x;
    vec3 x4 = x2 * x2;
    return  15.5   * x4 * x2
          - 40.14  * x4 * x
          + 31.96  * x4
          - 6.868  * x2 * x
          + 0.4298 * x2
          + 0.1191 * x
          - 0.00232;
}
vec3 agx(vec3 col) {
    const mat3 agx_mat = mat3(
        0.842479062253094,  0.0784335999999992, 0.0792237451477643,
        0.0423282422610123, 0.878468636469772,  0.0791661274605434,
        0.0423756549057051, 0.0784336,          0.879142973793104);
    const float min_ev = -12.47393;
    const float max_ev =   4.026069;
    col = agx_mat * col;
    col = clamp(log2(col), min_ev, max_ev);
    col = (col - min_ev) / (max_ev - min_ev);
    return agxContrast(col);
}
vec3 agxEotf(vec3 col) {
    const mat3 agx_mat_inv = mat3(
         1.19687900512017,   -0.0980208811401368, -0.0990297440797205,
        -0.0528968517574562,  1.15190312990417,   -0.0989611768448433,
        -0.0529716355144438, -0.0980434501171241,  1.15107367264116);
    // The reference implementation ends with pow(2.2) (back to LINEAR). Removing it
    // would make the later toSrgb apply gamma twice -> washed out / too bright AgX.
    return pow(clamp(agx_mat_inv * col, 0.0, 1.0), vec3(2.2));
}

// ============================================================================
//  VOXEL GI + TEMPORAL ACCUMULATION
//  hash13() and luma() are NOT redeclared here: they come from common.glsl
//  (redefining them fails compilation). The helpers below are not in common.glsl.
// ============================================================================
#if VOXEL_GI == 1
vec3 worldPosFromDepth(float d) {
    // TAAU: uv is the full-res VISIBLE screen here (post-TAA pass), so the NDC is
    // built without dividing by TAAU_S; only the caller's READ of d uses uv * TAAU_S.
    vec4 ndc = vec4(uv, d, 1.0) * 2.0 - 1.0;
    vec4 vp = gbufferProjectionInverse * ndc;
    vec3 viewPos = vp.xyz / vp.w;
    return (gbufferModelViewInverse * vec4(viewPos, 1.0)).xyz; // camera-relative
}

vec3 cosineHemisphere(vec3 n, float u1, float u2) {
    float r = sqrt(u1);
    float th = 6.2831853 * u2;
    vec3 t = normalize(cross(n, abs(n.y) < 0.9 ? vec3(0.0, 1.0, 0.0) : vec3(1.0, 0.0, 0.0)));
    vec3 b = cross(n, t);
    return normalize(t * (r * cos(th)) + b * (r * sin(th)) + n * sqrt(max(1.0 - u1, 0.0)));
}

// Uniform sphere sampling: normal-independent direction so a surface can "see" a
// sideways/behind source (fixes one-sided emissive). Gated by EMISSIVE_NEE_OMNI.
vec3 uniformSphere(float u1, float u2) {
    float z = 1.0 - 2.0 * u1;
    float r = sqrt(max(0.0, 1.0 - z * z));
    float ph = 6.2831853 * u2;
    return vec3(r * cos(ph), r * sin(ph), z);
}

// SKY-ON-MISS: LOCAL copy of getSkyBase (lib/sky.glsl). Depends ONLY on dir, sunDir,
// rainStrength and luma(). Do NOT #include sky.glsl instead: it pulls lighting/atmosphere
// and uniforms absent here (compile failure), and getSkyCelestial's *25 sun disc would
// produce GI fireflies. Supplies the low-frequency directional signal (blue zenith, bright
// horizon, sun glow) the cosine diffuse integral wants. Auto-dims at night (dayF). No shadows.
// NOTE: this term is NOT firefly-clamped and is scaled by the warm tint * VOXEL_GI_STRENGTH,
// so keep SKY_GI_STRENGTH moderate or the sun-facing side overexposes.
// CONFIG_SKY: the creator RGB tint IS mirrored here (bounce light must match the dome);
// SKY_HORIZON_LIFT/SKY_NIGHT_BRIGHT are NOT - this integral only wants the low-frequency hue.
#if SKY_GI == 1
vec3 skyGI(vec3 dir, vec3 sunDir) {
    float sh = sunDir.y;
    float dayF  = smoothstep(-0.05, 0.25, sh);
    float duskF = clamp(1.0 - abs(sh) * 4.0, 0.0, 1.0) * smoothstep(-0.14, -0.04, sh); // asymmetric: no dusk tint at night
    float horiz = pow(1.0 - clamp(dir.y, 0.0, 1.0), 3.0);
    vec3 dayZen = vec3(0.13, 0.40, 0.92);
    vec3 dayHor = vec3(0.62, 0.80, 0.98);
    vec3 ngtZen = vec3(0.004, 0.007, 0.018);
    vec3 ngtHor = vec3(0.012, 0.018, 0.040);
    vec3 sky = mix(mix(ngtZen, dayZen, dayF), mix(ngtHor, dayHor, dayF), horiz);
    float sunAmt = pow(clamp(dot(dir, sunDir) * 0.5 + 0.5, 0.0, 1.0), 3.0);
    sky = mix(sky, vec3(1.0, 0.40, 0.12), clamp(duskF * sunAmt * horiz * 1.2, 0.0, 1.0));
    float glow = pow(clamp(dot(dir, sunDir), 0.0, 1.0), 8.0);
    sky += vec3(1.0, 0.80, 0.50) * glow * 0.22 * dayF;
    sky += vec3(1.0, 0.45, 0.15) * glow * 0.60 * duskF;
    sky = mix(sky, vec3(luma(sky)) * vec3(0.8, 0.85, 0.95), rainStrength * 0.85);
    return sky * 1.22 * vec3(SKY_TINT_R, SKY_TINT_G, SKY_TINT_B);
}
#endif

// CLIPMAP sample: reads point p (camera-relative) from the FINEST cascade whose cell falls
// in [0,256), returns that cascade's voxel and writes its scale to outScale (march step).
// MUST use the SAME world-aligned cell formula as the write side (shadow.fsh), recomputed
// per cascade with s = VOXEL_SCALE*2^i. Only one cascade is read per call -> no double count.
// IMPORTANT: an in-bounds but EMPTY cell (clear=0) in a fine cascade is an AUTHORITATIVE MISS
// (.a=0); do NOT fall back to a coarser cascade (the fine grid is the high-res truth, falling
// back would double count and leak light). outScale<0 means p is outside ALL cascades ->
// early-out sentinel for the march loops.
vec4 sampleClip(vec3 p, out float outScale) {
    // Cascade 0 (s = VOXEL_SCALE): same formula as the original single-grid version.
    {
        float s = VOXEL_SCALE;
        ivec3 camBlock = ivec3(floor(cameraPosition / s));
        ivec3 cell = ivec3(floor((p + (cameraPosition - vec3(camBlock) * s)) / s)) + 128;
        if (all(greaterThanEqual(cell, ivec3(0))) && all(lessThan(cell, ivec3(256)))) {
            outScale = s; return imageLoad(voxelImg, cell);
        }
    }
#if VOXEL_CASCADES > 1
    {
        float s = VOXEL_SCALE * 2.0;
        ivec3 camBlock = ivec3(floor(cameraPosition / s));
        ivec3 cell = ivec3(floor((p + (cameraPosition - vec3(camBlock) * s)) / s)) + 128;
        if (all(greaterThanEqual(cell, ivec3(0))) && all(lessThan(cell, ivec3(256)))) {
            outScale = s; return imageLoad(voxelImg1, cell);
        }
    }
#endif
#if VOXEL_CASCADES > 2
    {
        float s = VOXEL_SCALE * 4.0;
        ivec3 camBlock = ivec3(floor(cameraPosition / s));
        ivec3 cell = ivec3(floor((p + (cameraPosition - vec3(camBlock) * s)) / s)) + 128;
        if (all(greaterThanEqual(cell, ivec3(0))) && all(lessThan(cell, ivec3(256)))) {
            outScale = s; return imageLoad(voxelImg2, cell);
        }
    }
#endif
#if VOXEL_CASCADES > 3
    {
        float s = VOXEL_SCALE * 8.0;
        ivec3 camBlock = ivec3(floor(cameraPosition / s));
        ivec3 cell = ivec3(floor((p + (cameraPosition - vec3(camBlock) * s)) / s)) + 128;
        if (all(greaterThanEqual(cell, ivec3(0))) && all(lessThan(cell, ivec3(256)))) {
            outScale = s; return imageLoad(voxelImg3, cell);
        }
    }
#endif
#if VOXEL_CASCADES > 4
    {
        float s = VOXEL_SCALE * 16.0;
        ivec3 camBlock = ivec3(floor(cameraPosition / s));
        ivec3 cell = ivec3(floor((p + (cameraPosition - vec3(camBlock) * s)) / s)) + 128;
        if (all(greaterThanEqual(cell, ivec3(0))) && all(lessThan(cell, ivec3(256)))) {
            outScale = s; return imageLoad(voxelImg4, cell);
        }
    }
#endif
#if VOXEL_CASCADES > 5
    {
        float s = VOXEL_SCALE * 32.0;
        ivec3 camBlock = ivec3(floor(cameraPosition / s));
        ivec3 cell = ivec3(floor((p + (cameraPosition - vec3(camBlock) * s)) / s)) + 128;
        if (all(greaterThanEqual(cell, ivec3(0))) && all(lessThan(cell, ivec3(256)))) {
            outScale = s; return imageLoad(voxelImg5, cell);
        }
    }
#endif
    outScale = -1.0; // outside ALL cascades -> early-out sentinel
    return vec4(0.0); // miss
}

// Clipmap ray march. Returns the first solid voxel (.rgb = content, .a flag: 0 empty,
// 1 albedo, 2 emissive). Occupied = .a > 0.5. Signature is shared with the reflection
// paths -- do not change it.
// Step length grows with DISTANCE travelled, not just with the cascade containing p:
// otherwise a ray staying inside fine cascade 0 would only reach
// VOXEL_GI_DISTANCE*VOXEL_SCALE blocks and never read the coarse cascades. Step =
// max(active cascade scale, distance-driven scale), clamped to the coarsest cascade so
// no occluder is skipped. Step length does NOT feed sampleClip's cell formula, so
// write==read consistency holds. The occupancy test is skipped at i==0 to avoid a
// self-hit at the ray origin for any VOXEL_SCALE.
vec4 marchVoxel(vec3 p, vec3 dir, int steps) {
    const float coarsest = VOXEL_SCALE * float(1 << (VOXEL_CASCADES - 1));
    float travelled = 0.0;
    for (int i = 0; i < steps; i++) {
        float s;
        vec4 vox = sampleClip(p, s);
        if (s < 0.0) return vec4(0.0); // outside all cascades: early-out
        if (i > 0 && vox.a > 0.5) return vox; // i==0 skipped: anti self-hit at origin
        // Effective step: at least the active cascade scale, growing with travelled
        // distance so a finite step budget still reaches the coarse cascades. Clamped
        // to 'coarsest' (largest voxel) so no occluder is stepped over.
        float distStep = VOXEL_SCALE * exp2(clamp(floor(log2(max(travelled, 1.0))),
                                                  0.0, float(VOXEL_CASCADES - 1)));
        float stepLen = clamp(max(s, distStep), VOXEL_SCALE, coarsest);
        p += dir * stepLen;
        travelled += stepLen;
    }
    return vec4(0.0);
}

// Sibling of marchVoxel that ALSO returns the hit point (out hitPos), used to re-bias the
// next bounce ray. Body is an exact copy of marchVoxel plus hitPos.
// SYNC REQUIRED: any future fix to marchVoxel must be re-applied here.
vec4 marchVoxelP(vec3 p, vec3 dir, int steps, out vec3 hitPos) {
    const float coarsest = VOXEL_SCALE * float(1 << (VOXEL_CASCADES - 1));
    float travelled = 0.0;
    for (int i = 0; i < steps; i++) {
        float s;
        vec4 vox = sampleClip(p, s);
        if (s < 0.0) { hitPos = p; return vec4(0.0); }       // outside grid: miss
        if (i > 0 && vox.a > 0.5) { hitPos = p; return vox; } // hit: return current p
        float distStep = VOXEL_SCALE * exp2(clamp(floor(log2(max(travelled, 1.0))),
                                                  0.0, float(VOXEL_CASCADES - 1)));
        float stepLen = clamp(max(s, distStep), VOXEL_SCALE, coarsest);
        p += dir * stepLen;
        travelled += stepLen;
    }
    hitPos = p; return vec4(0.0);                             // step budget exhausted: miss
}

#if FULL_PATH_TRACE == 1 && VOXEL_GI == 1
// FIXED-STEP shadow march (cascade-local s, NO growth with distance) so a 1-voxel wall between
// the surface and the sun is not stepped over (anti light-leak through thin walls). Kept separate
// from marchVoxel (shared by GI/reflections). Returns the first solid voxel; skips i==0.
vec4 marchVoxelShadow(vec3 p, vec3 dir, int steps) {
    for (int i = 0; i < steps; i++) {
        float s;
        vec4 vox = sampleClip(p, s);
        if (s < 0.0) return vec4(0.0);                 // outside all cascades: early-out (full sun)
        if (i > 0 && vox.a > 0.5) return vox;          // solid voxel hit -> shadowed
        p += dir * s;                                  // step = cascade-local scale, no exp2(dist) growth
    }
    return vec4(0.0);
}

// Sun visibility by voxel ray march. lightW = WORLD direction to the active light.
// wpos = camera-relative world pos; wn = world normal. 1.0 = full sun, 0.0 = shadow.
// Uses a DEDICATED shadow origin (small normal bias + pre-step along the ray); reusing the
// GI origin (pushed 0.75 block) would cause peter-panning.
float traceSunVisibility(vec3 wpos, vec3 wn, vec3 lightW) {
    float ndl = dot(wn, lightW);
    if (ndl <= 0.02) return 0.0;                       // back-face to the light = shadow
    vec3 origin = wpos + wn * (0.25 * VOXEL_SCALE);    // small shadow-only normal bias (anti acne)
    float fc = float(frameCounter & 255);
    vec3 t = normalize(cross(lightW, abs(lightW.y) < 0.9 ? vec3(0.0, 1.0, 0.0) : vec3(1.0, 0.0, 0.0)));
    vec3 b = cross(lightW, t);
    float occ = 0.0;
    for (int i = 0; i < FPT_SUN_SAMPLES; i++) {
        vec3 rd = lightW;
        if (FPT_SUN_SAMPLES > 1) {                     // jitter inside the sun cone = penumbra
            float u1 = hash13(wpos + vec3(float(i) + 0.3, 11.7 + fc, 3.3));
            float u2 = hash13(wpos + vec3(2.9, float(i) + 0.7, 19.1 + fc));
            float rr = sqrt(u1) * FPT_SUN_RADIUS, aa = 6.2831853 * u2;
            rd = normalize(lightW + (t * cos(aa) + b * sin(aa)) * rr);
            if (dot(rd, wn) < 0.02) rd = normalize(rd + wn * (0.02 - dot(rd, wn)));
        }
        // pre-step along rd (anti edge-leak + anti self-hit), scaled by VOXEL_SCALE.
        vec3 ro  = origin + rd * (FPT_LIGHT_BIAS * VOXEL_SCALE + 0.5 * VOXEL_SCALE);
        vec4 hit = marchVoxelShadow(ro, rd, FPT_SUN_STEPS);
        occ += (hit.a > 0.5) ? 1.0 : 0.0;              // solid hit before exiting = shadowed
    }
    float vis = 1.0 - occ / float(FPT_SUN_SAMPLES);
    vis *= smoothstep(0.02, 0.18, ndl);                // soften the terminator on grazing faces
    return clamp(vis, 0.0, 1.0);
}
#endif

// LOCAL EMISSIVE GATHER (NEE-like). At each shaded point, sample the local emissive FIELD
// with N SHORT normal-oriented rays: marchVoxelP returns the first occupant, which gives
// intrinsic VISIBILITY (a wall between P and the source blocks it = free anti-leak), then
// integrate 1/r^2. Fixes the "lit on one side only" artifact: every surface FACING a source
// gets energy, not just the ones that happen to catch a random GI ray.
// NOT true NEE (no known source position): rays are still cosine-hemisphere and rays landing
// on a non-emissive solid are discarded. Sparsity is reduced (dedicated short rays + 1/r^2)
// but not eliminated; the colortex10 EMA hides the residual grain. The cosine PDF is already
// applied by the sampling, so do NOT multiply by cos again (cos^2 = biased estimator).
// Fills the SAME giEmissive variable, so the downstream chain (colortex10 EMA, checkerboard,
// EMISSIVE_GI_GAIN) is untouched. Uses marchVoxelP; do not alter marchVoxel/marchVoxelP.
#if EMISSIVE_VOXEL == 1 && EMISSIVE_NEE == 1
#if EMISSIVE_VOXEL == 1 && EMISSIVE_HYBRID == 1
vec3 sampleEmissiveFieldTL(vec3 p, out float outW);   /* forward decl: defined below, called here */
#endif
vec3 gatherEmissiveNEE(vec3 wpos, vec3 wn) {
    // Origin biased OFF the surface. Small bias (0.5 voxel) is enough since marchVoxelP already
    // skips i==0, and it avoids a dark seam against a directly adjacent source (floor next to
    // glowstone) which is exactly where the most light is expected.
    vec3 origin = wpos + wn * (0.5 * VOXEL_SCALE);
    // Reach: radius in blocks -> step count; capped at 48 so a small VOXEL_SCALE cannot explode cost.
    int   reach = clamp(int(EMISSIVE_NEE_RADIUS / VOXEL_SCALE), 4, 48);
    float maxD  = EMISSIVE_NEE_RADIUS;
    // Seed must DIFFER from the GI loop seed, otherwise the two correlate and stripe.
    float fc    = float(frameCounter & 255);
    float seed  = hash13(wpos * 2.3 + 71.7 + fc);
    vec3 acc = vec3(0.0);
    for (int s = 0; s < EMISSIVE_NEE_SAMPLES; s++) {
        float u1 = hash13(wpos + vec3(float(s) + seed, 31.3 + fc, 5.9));
        float u2 = hash13(wpos + vec3(7.1, float(s) + seed, 17.4 + fc));
        // Ray split: the first (1-OMNI)*N rays use the normal hemisphere, the last OMNI*N use the
        // full sphere (catches sources to the side/behind). EMISSIVE_NEE_OMNI is a constant #define
        // so the compiler folds the branch (zero cost at 0.0). wDir weights the sphere share,
        // tuned via EMISSIVE_NEE_OMNI_GAIN.
        float fracS = (float(s) + 0.5) / float(EMISSIVE_NEE_SAMPLES);
        vec3  dir;
        float wDir;
        if (EMISSIVE_NEE_OMNI > 0.0 && fracS >= (1.0 - EMISSIVE_NEE_OMNI)) {
            dir  = uniformSphere(u1, u2);                   // full sphere (omnidirectional)
            wDir = EMISSIVE_NEE_OMNI_GAIN;
        } else {
            dir  = cosineHemisphere(wn, u1, u2);            // normal hemisphere, PDF ~ cos/pi
            wDir = 1.0;
        }
        // Anti-leak pre-step (EMISSIVE_NEE_BIAS, ~0.25 voxel). marchVoxelP already skips i==0, so a
        // quarter voxel is enough to avoid edge leaks WITHOUT missing an adjacent emissive voxel
        // (floor touching a glowstone = where the max is wanted). The first occupant is still
        // tested, so leaks through a wall do not reopen.
        vec3 ro  = origin + dir * (EMISSIVE_NEE_BIAS * VOXEL_SCALE);
        vec3 hp;
        vec4 hit = marchVoxelP(ro, dir, reach, hp);         // first occupant = VISIBILITY
        if (hit.a < 1.5) continue;                          // miss OR opaque solid -> 0 (anti-leak)
        float d = length(hp - origin);                      // distance from the SURFACE to the emissive voxel (blocks)
        if (d > maxD) continue;                             // beyond the gather radius
        // Cosine PDF already applied by the sampling -> no cos factor here.
        // WINDOWED FALLOFF, MC block-light style: a plain 1/(1+0.5 d^2) falls to ~0.07 at 5 blocks
        // (lamp dies in ~4 blocks). Instead: a STRETCHED inverse-square (bright core near the
        // source) * a smoothstep window that reaches EXACTLY 0 at the radius (no hard edge/seam).
        // Selected at RUNTIME rather than with #if because EMISSIVE_NEE_SOFT is a FLOAT and the
        // GLSL preprocessor only accepts integers in #if. EMISSIVE_NEE_SOFT<=0.0 restores the plain
        // falloff. The constant folds, so there is no per-ray branch.
        float fall;
        if (EMISSIVE_NEE_SOFT <= 0.0) {
            fall = 1.0 / (1.0 + 0.5 * d * d);              // plain falloff (fallback)
        } else {
            float kSoft = 0.30 / (EMISSIVE_NEE_SOFT * max(maxD, 1.0)); // stretch 1/r^2 to the radius scale
            float core  = 1.0 / (1.0 + kSoft * d * d);    // bounded 1/r^2 (bright near core)
            float dn    = clamp(d / max(maxD, 1e-3), 0.0, 1.0); // distance normalized to the radius
            float win   = 1.0 - smoothstep(0.55, 1.0, dn); // soft window: full below 0.55R, 0 at R
            fall = core * win;
        }
        // EMISSIVE_VOXEL_TRILINEAR: read radiance TRILINEARLY at the hit point (empty cells masked)
        // -> continuous under translation, damps the re-snap step. Fallback = nearest hit.rgb.
#if EMISSIVE_VOXEL == 1 && EMISSIVE_HYBRID == 1 && EMISSIVE_VOXEL_TRILINEAR == 1
        float _trw; vec3 _trc = sampleEmissiveFieldTL(hp, _trw);
        vec3  emisRGB = (_trw > 1e-4) ? _trc : hit.rgb;
#else
        vec3  emisRGB = hit.rgb;
#endif
        vec3  c    = emisRGB * fall;
        float lc = luma(c);                                 // firefly guard (very bright nearby voxel)
        if (lc > 4.0) c *= 4.0 / lc;
        acc += c * wDir;                                     // sphere-share weighting (wDir=1 for hemisphere rays)
    }
    acc /= float(EMISSIVE_NEE_SAMPLES);
    return acc * EMISSIVE_NEE_GAIN;
}
#endif

// Temporal reprojection shared by the GI EMA and the checkerboard path.
// Returns true iff a VALID history is found, and fills:
//   histGI   - accumulated GI at the reprojected texel
//   count    - stored count + 1, capped (used by the EMA on computed pixels)
//   countRaw - the STORED count (h.a, not incremented): written as-is on a skipped pixel so
//              the counter does not inflate and the EMA window stays nominal
//   hpx      - history texel index, so colortex10 (emissive) reprojects to the same place
//   hpxValid - true when hpx is usable even if the GI history itself was rejected (emissive)
bool reprojectGI(vec3 wpos, out vec3 histGI, out float count, out float countRaw,
                 out ivec2 hpx, out bool hpxValid) {
    histGI   = vec3(0.0);
    count    = 1.0;
    countRaw = 0.0;
    hpx      = ivec2(0);
    hpxValid = false;
#if TEMPORAL_ACCUM == 1
    vec3 wpsAbs = wpos + cameraPosition;
    vec4 prevClip = gbufferPreviousProjection
                  * (gbufferPreviousModelView * vec4(wpsAbs - previousCameraPosition, 1.0));
    if (prevClip.w > 0.001) {
        vec2 histUV = (prevClip.xy / prevClip.w) * 0.5 + 0.5;
        if (histUV.x >= 0.0 && histUV.x <= 1.0 && histUV.y >= 0.0 && histUV.y <= 1.0) {
            hpx = ivec2(histUV * vec2(viewWidth, viewHeight));
            hpx = clamp(hpx, ivec2(0), ivec2(int(viewWidth) - 1, int(viewHeight) - 1));
            hpxValid = true;
            vec4 h  = texelFetch(colortex8, hpx, 0);
            vec4 hg = texelFetch(colortex9, hpx, 0);

            if (any(isnan(h))  || any(isinf(h)))  h  = vec4(0.0);
            if (any(isnan(hg)) || any(isinf(hg))) hg = vec4(0.0);

            vec3  hPos   = hg.rgb;
            float hValid = hg.a;

            vec3  worldDelta = (wpos - hPos) + (cameraPosition - previousCameraPosition);
            float moved = length(worldDelta);
            float distEye = length(wpos);
            float thresh  = DISOCCLUSION_THRESHOLD * max(1.0, distEye * 0.05);

            if (moved <= thresh && h.a >= 0.5 && hValid > 0.5) {
                histGI   = h.rgb;
                countRaw = h.a;  // STORED count (not incremented) -> written as-is on a skip
                count    = clamp(min(h.a + 1.0, float(TAA_GI_FRAMES)), 1.0, float(TAA_GI_FRAMES));
                return true;
            }
        }
    }
#endif
    return false;
}

vec3 accumulateGI(vec3 rawGI, vec3 wpos, out vec4 outAccum, out vec4 outGuide) {
    vec3  histGI; float count; float countRaw; ivec2 hpx; bool hpxValid;
    if (reprojectGI(wpos, histGI, count, countRaw, hpx, hpxValid)) {
        rawGI = min(rawGI, histGI * 4.0 + vec3(0.25)); // anti-firefly clamp against history
    } else {
        histGI = rawGI; count = 1.0;                   // disocclusion: restart the EMA
    }
    float alpha = 1.0 / count;
    vec3  accum = mix(histGI, rawGI, alpha);
    outAccum = vec4(accum, count);
    outGuide = vec4(wpos, 1.0);
    return accum;
}

#if EMISSIVE_VOXEL == 1 && EMISSIVE_ACCUM == 1
// DEDICATED temporal accumulation for emissive (kills flicker).
// SAME reprojection / disocclusion test as accumulateGI (colortex10 = emissive history,
// colortex9 reused as the shared guide: same pixel, same geometry). Key differences:
//  - NO hard anti-firefly clamp (that caused a visible fade-in); only a very permissive
//    guard min(rawEmis, histE*8+1) against real spikes/NaN.
//  - Comet-trail gate: if the reprojected history is very bright while the current pixel is
//    nearly non-emissive, treat it as a disocclusion (reset) -> no bright smear when the
//    reprojection lands on the wrong surface below the threshold.
//  - Fast rise on step changes (flowing lava, lamp switched on): alpha is raised when
//    luminance jumps up, settling in 1-2 frames without reintroducing fade-in, while the
//    symmetric shimmer of animated lava stays averaged over the window.
vec3 accumulateEmissive(vec3 rawEmis, vec3 wpos, out vec4 outEmis) {
    vec3  histE = rawEmis;
    float count = 1.0;

#if TEMPORAL_ACCUM == 1
    vec3 wpsAbs = wpos + cameraPosition;
    vec4 prevClip = gbufferPreviousProjection
                  * (gbufferPreviousModelView * vec4(wpsAbs - previousCameraPosition, 1.0));

    if (prevClip.w > 0.001) {
        vec2 histUV = (prevClip.xy / prevClip.w) * 0.5 + 0.5;
        if (histUV.x >= 0.0 && histUV.x <= 1.0 && histUV.y >= 0.0 && histUV.y <= 1.0) {
            ivec2 hpx = ivec2(histUV * vec2(viewWidth, viewHeight));
            hpx = clamp(hpx, ivec2(0), ivec2(int(viewWidth) - 1, int(viewHeight) - 1));
            vec4 he = texelFetch(colortex10, hpx, 0);   // emissive history
            vec4 hg = texelFetch(colortex9,  hpx, 0);   // shared worldPos guide

            if (any(isnan(he)) || any(isinf(he))) he = vec4(0.0);
            if (any(isnan(hg)) || any(isinf(hg))) hg = vec4(0.0);

            vec3  hPos   = hg.rgb;
            float hValid = hg.a;

            vec3  worldDelta = (wpos - hPos) + (cameraPosition - previousCameraPosition);
            float moved   = length(worldDelta);
            float distEye = length(wpos);
            // Emissive disocclusion threshold. Strictness is tunable via EMISSIVE_DISOCC_SCALE
            // (0.5 = stricter than albedo GI, 1.0 = equally tolerant).
            float thresh  = DISOCCLUSION_THRESHOLD * EMISSIVE_DISOCC_SCALE * max(1.0, distEye * 0.05);

            // Comet-trail gate: bright history + nearly black current pixel => reset.
            float lh = luma(he.rgb);
            float lr = luma(rawEmis);
            bool  brightGhost = (lr < 0.02 && lh > 0.2);

            if (moved <= thresh && he.a >= 0.5 && hValid > 0.5 && !brightGhost) {
                histE = he.rgb;
                count = clamp(min(he.a + 1.0, float(EMISSIVE_ACCUM_FRAMES)),
                              1.0, float(EMISSIVE_ACCUM_FRAMES));
                // VERY permissive guard: bounds real spikes/NaN only, does NOT sculpt
                // luminance (so no fade-in).
                rawEmis = min(rawEmis, histE * 8.0 + vec3(1.0));
            } else {
                // SOFT RESET: instead of count=1 (alpha=1 = hard re-roll, flickers), keep the
                // history and restart from EMISSIVE_RESET_FRAMES frames (alpha=1/N) so the
                // transition blends over N frames. EMISSIVE_RESET_FRAMES=1 +
                // EMISSIVE_DISOCC_SCALE=0.5 restores the hard-reset behaviour.
                if (EMISSIVE_RESET_FRAMES > 1 && he.a >= 0.5 && hValid > 0.5 && !brightGhost) {
                    histE = he.rgb;
                    count = float(EMISSIVE_RESET_FRAMES);
                }
                // brightGhost or no history -> hard reset (histE=rawEmis, count=1) already set.
            }
        }
    }
#endif

    float alpha = 1.0 / count;
    // FAST RISE: an upward luminance jump (lamp on, lava flow) raises alpha to settle in 1-2
    // frames; a symmetric shimmer keeps alpha low (1/count) and stays averaged over the window.
    alpha = max(alpha, smoothstep(0.0, 0.3, luma(rawEmis) - luma(histE)));
    vec3  accum = mix(histE, rawEmis, alpha);
    if (any(isnan(accum)) || any(isinf(accum))) accum = rawEmis;

    outEmis = vec4(accum, count);
    return accum;
}
#endif
#endif

// ===================== HYBRID EMISSIVE TINT -- HELPERS =====================
#if VOXEL_GI == 1 && EMISSIVE_VOXEL == 1 && EMISSIVE_HYBRID == 1
// Sample the voxel emissive FIELD (cascade 0) TRILINEARLY around a world point, MASKING empty
// cells (.a<=0.5) so black does not bleed at the edges of a hollow source.
// Returns the weighted mean COLOR (rgb); outW = total weight (0 = no filled cell).
// Uses imageLoad(voxelImg) (legal: voxelImg is not readonly, same as sampleClip).
vec3 sampleEmissiveFieldTL(vec3 p, out float outW) {
    float s = VOXEL_SCALE;
    ivec3 camBlock = ivec3(floor(cameraPosition / s));
    vec3  fp   = (p + (cameraPosition - vec3(camBlock) * s)) / s + 128.0;
    vec3  base = floor(fp);
    vec3  f    = fp - base;
    ivec3 b    = ivec3(base);
    vec3  acc  = vec3(0.0);
    float wsum = 0.0;
    for (int i = 0; i < 8; i++) {
        ivec3 off = ivec3(i & 1, (i >> 1) & 1, (i >> 2) & 1);
        ivec3 c   = b + off;
        if (any(lessThan(c, ivec3(0))) || any(greaterThanEqual(c, ivec3(256)))) continue;
        vec4  v = imageLoad(voxelImg, c);
        if (v.a <= 0.5) continue;                       // empty cell -> MASKED (no black bleed)
        vec3  wxyz = mix(1.0 - f, f, vec3(off));
        float w    = wxyz.x * wxyz.y * wxyz.z;
        acc  += v.rgb * w;
        wsum += w;
    }
    outW = wsum;
    return (wsum > 1e-5) ? acc / wsum : vec3(0.0);
}
// HYBRID EMISSIVE BASE: vanilla block light colortex2.x (omnidirectional, stable, smooth) raised
// to a gamma curve and TINTED by the voxel emissive field colour (gold/green/cyan) read
// trilinearly around the surface (tint normalized by its luma, warm-white fallback when the
// field is black). Linear HDR, added BEFORE tonemap. Independent of RNG/frameCounter -> stable.
vec3 emissiveHybridBase(vec2 uv, vec3 wpos, vec3 wn) {
    float bl = texture2D(colortex2, uv * TAAU_S).x;     // vanilla block light [0..1] (TAAU: sub-rect)
    if (bl <= 0.001) return vec3(0.0);
    float curve = pow(clamp(bl, 0.0, 1.0), EMISSIVE_HYBRID_CURVE);
    float fw;
    vec3  field = sampleEmissiveFieldTL(wpos + wn * (0.5 * VOXEL_SCALE), fw);
    float fl    = luma(field);
    vec3  tint  = (fl > 1e-4) ? field / fl : vec3(1.0, 0.92, 0.78); // normalized hue, warm-white fallback
    return curve * tint * EMISSIVE_HYBRID_GAIN;
}
#endif
// =================================================================================
#if VOXEL_GI == 1 && (GI_DENOISE == 1 || (EMISSIVE_VOXEL == 1 && EMISSIVE_DENOISE == 1))
// Linear depth (same formula as the DOF block below; common.glsl has no helper for it).
float linDepth(float d) {
    return 2.0 * near * far / (far + near - (d * 2.0 - 1.0) * (far - near));
}
// A-trous, 1 pass, N dilation levels x 3x3 ring. Center = CURRENT-frame accum (giCenter, no
// radiance latency). Neighbours = colortex8 frame n-1 (point-sampled) with depth/normal/luma
// edge stopping evaluated at the neighbour pixel (current-frame gbuffer). px = screen coord;
// nCenter = WORLD normal; zCenter = linear depth. Depth weight is RELATIVE (sharp at any
// distance, no smearing far away).
// TAAU CAVEAT: under TAA_UPSCALING=1 the texelFetch of depthtex0/colortex1 below should target
// ivec2(vec2(q) * TAAU_S) (gbuffers live in the sub-rect) while colortex8 stays in full-res
// pixels -- this mixed kernel is not remapped, so the denoise is slightly wrong near edges.
// No effect at VOXEL_GI=0 or with TAAU off.
vec3 atrousGI(vec3 giCenter, ivec2 px, vec3 nCenter, float zCenter) {
#if GI_DENOISE_STRONG == 1 && GI_DENOISE_PASSES == 3
    // WIDE kernel (4 levels, dilation 1,2,4,8 = ~17x17 effective) to attack low-frequency grain
    // on flat surfaces. The 4th level is only added when GI_DENOISE_PASSES==3; drop that slider
    // to 2 for the cheaper 2-level kernel.
    const int   STEPS[4] = int[4](1, 2, 4, 8);
    const float STEPW[4] = float[4](1.0, 0.6, 0.35, 0.2);
    const int   NPASS = 4;
#elif GI_DENOISE_PASSES == 3
    const int   STEPS[3] = int[3](1, 2, 4);     // increasing dilation (SVGF) = wider kernel
    const float STEPW[3] = float[3](1.0, 0.5, 0.25);
    const int   NPASS = 3;
#else
    const int   STEPS[2] = int[2](1, 2);        // narrow 2-level kernel (cheap fallback)
    const float STEPW[2] = float[2](1.0, 0.5);
    const int   NPASS = 2;
#endif
    float s = max(DENOISE_STRENGTH, 0.0001);
    float relZ = 0.05 * s;              // RELATIVE depth tolerance (fraction of the distance)
    float sigN = 32.0 / s;             // normal exponent (large = stops quickly)
#if GI_DENOISE_STRONG == 0
    float invSigL = 1.0 / (0.60 * s);  // luminance sigma (legacy mode: FIXED)
#endif
    float lCenter = luma(giCenter);
    ivec2 maxPx = ivec2(int(viewWidth) - 1, int(viewHeight) - 1);

    // --- Immediate 3x3 stats: mean / variance / max luma of VALID neighbours (offset 1, not *st).
    //     Gated by (SPATIAL_CLAMP || DENOISE_STRONG) so STRONG=0 + CLAMP=0 compiles out to zero
    //     cost. Feeds both the spatial clamp and the variance-aware wL.
    //     Same rejections as the filter (sky dN>=1, NaN/Inf, gN.a<0.5) plus a same-surface depth
    //     gate, so it never clamps to 0 and never measures a different surface (edge/thin object).
    float nMean = 0.0, nVar = 0.0; bool haveStat = false;
#if (GI_SPATIAL_CLAMP == 1 || GI_DENOISE_STRONG == 1)
    {
        float sL = 0.0, sL2 = 0.0, maxL = 0.0, cnt = 0.0;
        for (int oy = -1; oy <= 1; oy++)
        for (int ox = -1; ox <= 1; ox++) {
            if (ox == 0 && oy == 0) continue;
            ivec2 q = px + ivec2(ox, oy);
            if (q.x < 0 || q.y < 0 || q.x > maxPx.x || q.y > maxPx.y) continue;
            float dN = texelFetch(depthtex0, q, 0).r;
            if (dN >= 1.0) continue;                                // sky
            // same-surface gate: skip a neighbour at a very different depth (convex edge)
            if (abs(linDepth(dN) - zCenter) > max(zCenter, 1.0) * 0.10) continue;
            vec4 gN = texelFetch(colortex8, q, 0);
            if (any(isnan(gN)) || any(isinf(gN)) || gN.a < 0.5) continue;
            float lN = luma(gN.rgb);
            sL += lN; sL2 += lN * lN; maxL = max(maxL, lN); cnt += 1.0;
        }
        if (cnt >= 3.0) {                                           // need >=3 reliable neighbours, else do nothing
            nMean    = sL / cnt;
            nVar     = max(sL2 / cnt - nMean * nMean, 0.0);
            haveStat = true;
#if GI_SPATIAL_CLAMP == 1
            float sigma = sqrt(nVar);
            // Cap = max( mean + K*sigma , brightest neighbour ) + small absolute floor: a uniformly
            // bright area (center ~ neighbours) is NOT clipped, only an isolated spike is.
            float cap = max(nMean + GI_SPATIAL_CLAMP_K * sigma, maxL) + 0.05;
            // Deadband: only pull the center when it clearly exceeds the cap, so legitimate small
            // highlights barely brighter than their neighbourhood survive.
            if (lCenter > cap * 1.25) {
                giCenter *= cap / max(lCenter, 1e-4);                // keep the hue (luma ratio)
                lCenter   = cap;                                     // resync (weights neighbour wL)
            }
#endif
        }
    }
#endif

#if GI_DENOISE_STRONG == 1
    // VARIANCE-AWARE wL (SVGF): sigma_luma = GI_LUMA_PHI * local luma std-dev, CAPPED at the legacy
    // scale (0.60*s). Noisy flat area -> high variance -> large lumaDenom -> wL ~ 1 -> neighbours
    // really are averaged (this is what kills grain on flat surfaces).
    // The min() cap matters: a real luminance EDGE (contact darkening, soft shadow) also raises the
    // variance, and depth+normal do not protect it (same flat surface). Without the cap the filter
    // would blur across it; with it, wL stays discriminating (never a pure box blur).
    // The 1e-3 floor makes wL strict again on already-clean areas (variance ~0, nothing to smooth).
    float lumaDenom = min(GI_LUMA_PHI * sqrt(max(nVar, 0.0)), 0.60 * s) + 1e-3;
#endif

    vec3  sum  = giCenter;   // center, weight 1
    float wsum = 1.0;

    for (int si = 0; si < NPASS; si++) {
        int   st = STEPS[si];
        float kw = STEPW[si];
        for (int oy = -1; oy <= 1; oy++)
        for (int ox = -1; ox <= 1; ox++) {
            if (ox == 0 && oy == 0) continue;
            ivec2 q = px + ivec2(ox, oy) * st;
            if (q.x < 0 || q.y < 0 || q.x > maxPx.x || q.y > maxPx.y) continue;

            float dN = texelFetch(depthtex0, q, 0).r;
            if (dN >= 1.0) continue;                 // sky: reject
            float zN = linDepth(dN);

            vec3 vnN = normalize(texelFetch(colortex1, q, 0).rgb * 2.0 - 1.0);
            vec3 nN  = normalize(mat3(gbufferModelViewInverse) * vnN);

            vec4 gN = texelFetch(colortex8, q, 0);   // accumulated albedo GI, frame n-1
            if (any(isnan(gN)) || any(isinf(gN)) || gN.a < 0.5) continue;

            // RELATIVE depth: |dz| scaled by distance -> contact darkening stays sharp far away.
            float wZ = exp(-abs(zN - zCenter) / (max(zCenter, 1.0) * relZ));
            float wN = pow(max(dot(nCenter, nN), 0.0), sigN);
#if GI_DENOISE_STRONG == 1
            // Variance-aware (capped). haveStat==false (edge/disocclusion, <3 reliable neighbours)
            // -> wL=1: depth+normal do the stopping alone (no reliable luma statistic).
            float wL = (haveStat)
                     ? exp(-abs(luma(gN.rgb) - lCenter) / lumaDenom)
                     : 1.0;
#else
            float wL = exp(-abs(luma(gN.rgb) - lCenter) * invSigL);   // legacy: FIXED sigma
#endif
            float wS = kw / (1.0 + float(ox*ox + oy*oy));
            float w  = wZ * wN * wL * wS;

            sum  += gN.rgb * w;
            wsum += w;
        }
    }
    return sum / max(wsum, 1e-4);
}
#endif

#if VOXEL_GI == 1 && EMISSIVE_VOXEL == 1 && EMISSIVE_DENOISE == 1
// DEDICATED spatial denoise for emissive. Modeled on atrousGI but: (1) reads colortex10
// (accumulated emissive) instead of colortex8; (2) NO spatial clamp (colortex10 is already
// EMA-stable and dense); (3) keeps a VARIANCE-AWARE wL so noisy flat surfaces really are
// averaged, which is what kills the grain; (4) sigmas driven by EMISSIVE_DENOISE_STRENGTH /
// EMISSIVE_LUMA_PHI, independent of the GI sliders. colortex10 is dense (the checkerboard path
// rewrites emisOut on EVERY visible pixel), so the kernel sees no holes.
// It NEVER feeds back into colortex10: applied display-only to the value added to color, exactly
// like atrousGI vs accumOut. Depends on linDepth (gate widened above).
// TAAU CAVEAT: same mixed kernel as atrousGI (gbuffer texelFetch in the sub-rect vs colortex10
// at full res) -- not remapped under TAA_UPSCALING=1.
vec3 atrousEmissive(vec3 eCenter, ivec2 px, vec3 nCenter, float zCenter) {
    const int   STEPS[3] = int[3](1, 2, 4);          // increasing dilation (SVGF) = wide kernel
    const float STEPW[3] = float[3](1.0, 0.6, 0.3);
    const int   NPASS = 3;
    float s    = max(EMISSIVE_DENOISE_STRENGTH, 0.0001);
    float relZ = 0.05 * s;                            // RELATIVE depth tolerance (fraction of distance)
    float sigN = 32.0 / s;                            // normal exponent (large = stops quickly)
    ivec2 maxPx = ivec2(int(viewWidth) - 1, int(viewHeight) - 1);
    float lCenter = luma(eCenter);

    // --- 3x3 luma variance (offset 1) over VALID neighbours: noisy flat area -> high variance
    //     -> large lumaDenom -> wL ~ 1 -> neighbours are averaged (kills the grain).
    float nMean = 0.0, nVar = 0.0; bool haveStat = false;
    {
        float sL = 0.0, sL2 = 0.0, cnt = 0.0;
        for (int oy = -1; oy <= 1; oy++)
        for (int ox = -1; ox <= 1; ox++) {
            if (ox == 0 && oy == 0) continue;
            ivec2 q = px + ivec2(ox, oy);
            if (q.x < 0 || q.y < 0 || q.x > maxPx.x || q.y > maxPx.y) continue;
            float dN = texelFetch(depthtex0, q, 0).r;
            if (dN >= 1.0) continue;                                       // sky
            if (abs(linDepth(dN) - zCenter) > max(zCenter, 1.0) * 0.10) continue; // same-surface gate
            vec4 eN = texelFetch(colortex10, q, 0);
            if (any(isnan(eN)) || any(isinf(eN)) || eN.a < 0.5) continue;
            float lN = luma(eN.rgb);
            sL += lN; sL2 += lN * lN; cnt += 1.0;
        }
        if (cnt >= 3.0) { nMean = sL / cnt; nVar = max(sL2 / cnt - nMean * nMean, 0.0); haveStat = true; }
    }
    // sigma_luma = PHI * local std-dev, CAPPED (protects real source/shadow edges);
    // 1e-3 floor -> wL becomes strict again on clean areas.
    float lumaDenom = min(EMISSIVE_LUMA_PHI * sqrt(max(nVar, 0.0)), 0.60 * s) + 1e-3;

    vec3  sum  = eCenter;   // center, weight 1
    float wsum = 1.0;
    for (int si = 0; si < NPASS; si++) {
        int   st = STEPS[si];
        float kw = STEPW[si];
        for (int oy = -1; oy <= 1; oy++)
        for (int ox = -1; ox <= 1; ox++) {
            if (ox == 0 && oy == 0) continue;
            ivec2 q = px + ivec2(ox, oy) * st;
            if (q.x < 0 || q.y < 0 || q.x > maxPx.x || q.y > maxPx.y) continue;
            float dN = texelFetch(depthtex0, q, 0).r;
            if (dN >= 1.0) continue;                  // sky: reject
            float zN = linDepth(dN);
            vec3 vnN = normalize(texelFetch(colortex1, q, 0).rgb * 2.0 - 1.0);
            vec3 nN  = normalize(mat3(gbufferModelViewInverse) * vnN);
            vec4 eN  = texelFetch(colortex10, q, 0);  // accumulated emissive, frame n-1 (Iris flip)
            if (any(isnan(eN)) || any(isinf(eN)) || eN.a < 0.5) continue;
            float wZ = exp(-abs(zN - zCenter) / (max(zCenter, 1.0) * relZ));
            float wN = pow(max(dot(nCenter, nN), 0.0), sigN);
            float wL = (haveStat) ? exp(-abs(luma(eN.rgb) - lCenter) / lumaDenom) : 1.0;
            float wS = kw / (1.0 + float(ox*ox + oy*oy));
            float w  = wZ * wN * wL * wS;
            sum  += eN.rgb * w;
            wsum += w;
        }
    }
    return sum / max(wsum, 1e-4);
}
#endif
// ============================================================================

void main() {
    vec2 suv = uv;

    // Underwater: triple-frequency screen warp
    if (isEyeInWater == 1) {
        float rt = frameTimeCounter;
        float eyeB = float(eyeBrightnessSmooth.y) / 240.0;
        suv += vec2(
            sin(uv.y * 58.0 + rt * 2.2) * 0.55 + sin(uv.y * 33.0 + rt * 1.6) * 0.30
          + sin(uv.y * 12.0 + rt * 0.8) * 0.15,
            cos(uv.x * 58.0 + rt * 2.0) * 0.55 + cos(uv.x * 36.0 + rt * 1.4) * 0.30
          + cos(uv.x * 11.0 + rt * 0.7) * 0.15
        ) * (0.0010 + 0.0012 * eyeB);
    }
    if (isEyeInWater == 2) {
        suv += vec2(sin(uv.y * 28.0 + frameTimeCounter * 1.4),
                    cos(uv.x * 26.0 + frameTimeCounter * 1.1)) * 0.006;
    }

    // TAAU (POST-TAA pass): colortex0 colour is FULL RES (reconstructed by composite4) but
    // depthtex0 / colortex1 / colortex2 / colortex11 and the colortex3 bloom pyramid stay in
    // the sub-rect -> those reads must use uv * TAAU_S. At TAAU_S = 1.0 the multiply folds away.

    float dropHi = 0.0;
    #if CAMERA_DROPLETS > 0
    {
        // R6 sober lens-droplet rework. A handful of near-still drops that pop
        // in, sit and evaporate (tiny lens refraction: UV pulled toward the
        // drop centre by a spherical-cap profile), plus rare thin trails that
        // slide down and die fast. No full-screen crawling warp.
        float exposed = float(eyeBrightnessSmooth.y) / 240.0;
        float dAmt = rainStrength * smoothstep(0.40, 0.85, exposed);
        if (dAmt > 0.01 && isEyeInWater == 0) {
            float aspect = viewWidth / viewHeight;
            float dStr = (CAMERA_DROPLETS == 2) ? 1.0 : 0.55; // 1 = subtle, 2 = strong
            vec2 guv = uv * vec2(aspect, 1.0);

            // ---- still droplets: two sparse scales, short life cycle ----
            for (int i = 0; i < 2; i++) {
                float sc = (i == 0) ? 5.0 : 7.5;
                vec2 gp = guv * sc + float(i) * 3.7;
                vec2 cellD = floor(gp);
                vec2 frD = gp - cellD;
                float hD = hash12(cellD + float(i) * 41.0);
                if (hD < 0.86) continue;                       // ~1 cell in 7 owns a drop
                // pop in fast, sit, evaporate (per-drop period 6-10 s)
                float life = fract(frameTimeCounter / (6.0 + hD * 4.0) + hD * 9.0);
                float fadeD = smoothstep(0.0, 0.06, life) * smoothstep(1.0, 0.75, life);
                vec2 dpos = vec2(0.25) + 0.5 * vec2(hash12(cellD + 3.1), hash12(cellD + 8.6));
                vec2 ddD = frD - dpos;
                float rD = length(ddD);
                float radD = 0.055 + 0.045 * hash12(cellD + 5.2);
                float m = smoothstep(radD, radD * 0.35, rD) * fadeD * dAmt;
                suv -= ddD * (m * m) * (0.10 * dStr);          // refract toward centre
                dropHi = max(dropHi, m * 0.55);
            }

            // ---- running trails: rare, thin, slide down and fade fast ----
            {
                float ncol = 8.0;
                float ci = floor(uv.x * ncol);
                float hc = hash12(vec2(ci * 1.71, 57.0));
                if (hc > 0.55) {                               // ~1 lane in 2.2 active
                    float period = 6.0 + hc * 7.0;             // one run each 6-13 s
                    float ph = fract(frameTimeCounter / period + hc * 31.0);
                    float yH = 1.08 - ph * 1.30;               // head slides top -> bottom
                    float xC = (ci + 0.25 + 0.50 * hash12(vec2(ci, 3.3))) / ncol
                             + sin(uv.y * 26.0 + hc * 40.0) * 0.003; // gentle wiggle
                    float dxg = (uv.x - xC) * aspect;
                    float dy = uv.y - yH;                      // tail lives above the head
                    float lat = smoothstep(0.0050, 0.0012, abs(dxg)); // thin (~5 px @1080p)
                    float tail = lat * step(0.0, dy) * smoothstep(0.30, 0.02, dy)
                               * smoothstep(1.0, 0.80, ph) * dAmt;
                    float head = lat * smoothstep(0.014, 0.0, abs(dy)) * dAmt;
                    // refraction: pull toward the trail centreline + drag at the head
                    suv.x -= dxg * (tail * 0.5 + head * 1.2) * (0.05 * dStr);
                    suv.y -= head * (0.008 * dStr);
                    dropHi = max(dropHi, tail * 0.30 + head * 0.55);
                }
            }
        }
    }
    #endif

    vec3 color;
#if defined DOF && DOF_V2 == 1
    // How blurred this pixel ended up (0 = sharp). Consumed by the chromatic
    // aberration block below: its raw taps are SHARP colortex0 reads that
    // would overwrite the blurred r/b channels with a magenta/green ghost,
    // so on blurred pixels it keeps the gather's own ABERRED r/b instead
    // (the disc taps sample the CA-offset coordinates, see the DOF loop).
    float dofBlurF = 0.0;
#endif

    #ifdef DOF
    {
#if DOF_V2 == 1
        // --- DOF_V2 (settings.glsl): thin-lens CoC + coverage-weighted Vogel disc. ---
        vec2  pxd = 1.0 / vec2(viewWidth, viewHeight);
        // TAAU: depth sub-rect; same half-texel inset as the tap reads below
        // (at suv = 1 a raw read sits ON the sub-rect boundary -- harmless
        // while depthtex0 is GL_NEAREST, wrong the day the filtering changes).
        float dHere = texture2D(depthtex0, min(suv * TAAU_S, vec2(TAAU_S) - 0.5 * pxd)).r;
        float ld = 2.0 * near * far / (far + near - (dHere * 2.0 - 1.0) * (far - near));
        float lc = 2.0 * near * far / (far + near - (centerDepthSmooth * 2.0 - 1.0) * (far - near));
        // Thin-lens CoC in FULL-RES pixels: |1 - dFocus/d| saturates toward
        // 9 px x DOF_STRENGTH on a far background and grows fast on a very
        // near foreground (V1's |d-dF|/dF blurred both sides identically).
        // 16 px cap: what 12 dithered taps can support without falling apart.
        float cocC = min(abs(1.0 - lc / max(ld, 0.05)) * (9.0 * DOF_STRENGTH), 16.0);
        color = texture2D(colortex0, suv).rgb;
        if (cocC > 0.3) {
            // Per-pixel rotation of the Vogel spiral (SPATIAL hash: this pass
            // is post-TAA, temporal dither would shimmer): the 12-tap ring
            // pattern turns into stable grain instead of onion rings.
            float rot = hash12(gl_FragCoord.xy) * 6.2831853;
            vec3  acc  = color;   // center anchor: wsum never collapses
#ifdef CHROMATIC_ABERRATION
            // CA carried INTO the gather: the r/b reads of every disc tap (and
            // of the center anchor) sample the aberred coordinates, so the
            // bokeh keeps its fringes -- a real lens fringes hardest exactly
            // on out-of-focus highlights. Same formula as the CA block below;
            // the depth/coverage weights are shared (caD is sub-pixel scale,
            // the tap's own CoC does not change across it).
            vec2 rcD = uv - 0.5;
            vec2 caD = rcD * dot(rcD, rcD) * 0.010;
            acc.r = texture2D(colortex0, clamp(suv + caD, vec2(0.0), vec2(1.0))).r;
            acc.b = texture2D(colortex0, clamp(suv - caD, vec2(0.0), vec2(1.0))).b;
#endif
            float wsum = 1.0;
            for (int i = 0; i < 12; i++) {
                float aa  = float(i) * 2.39996 + rot;
                float rr  = sqrt((float(i) + 0.5) / 12.0);
                float dPx = rr * cocC;
                vec2  tuv = clamp(suv + vec2(cos(aa), sin(aa)) * (dPx * pxd),
                                  vec2(0.0), vec2(1.0));
                // tap depth -> tap CoC (same formula); half-texel inset keeps
                // the TAAU sub-rect edge from bleeding the dead zone.
                float dT = texture2D(depthtex0, min(tuv * TAAU_S, vec2(TAAU_S) - 0.5 * pxd)).r;
                float lt = 2.0 * near * far / (far + near - (dT * 2.0 - 1.0) * (far - near));
                float cocT = min(abs(1.0 - lc / max(lt, 0.05)) * (9.0 * DOF_STRENGTH), 16.0);
                // Coverage weight: a tap contributes only if ITS OWN blur disc
                // reaches this pixel. An in-focus (sharp) tap therefore cannot
                // leak into the bokeh of a blurred foreground or background
                // around it -- the edge protection V1 lacked.
                float w = clamp(cocT - dPx + 0.5, 0.0, 1.0);
                vec3 tapC = texture2D(colortex0, tuv).rgb;
#ifdef CHROMATIC_ABERRATION
                tapC.r = texture2D(colortex0, clamp(tuv + caD, vec2(0.0), vec2(1.0))).r;
                tapC.b = texture2D(colortex0, clamp(tuv - caD, vec2(0.0), vec2(1.0))).b;
#endif
                acc  += tapC * w;
                wsum += w;
            }
            // Sub-pixel radii fade in smoothly; V1 snapped from sharp to an
            // 8-tap disc at its binary coc>0.8 gate (visible focus ring).
            dofBlurF = smoothstep(0.3, 1.2, cocC);
            color = mix(color, acc / wsum, dofBlurF);
        }
#else
        float dHere = texture2D(depthtex0, suv * TAAU_S).r; // TAAU: depth sub-rect
        float ld = 2.0 * near * far / (far + near - (dHere * 2.0 - 1.0) * (far - near));
        float lc = 2.0 * near * far / (far + near - (centerDepthSmooth * 2.0 - 1.0) * (far - near));
        float coc = clamp(abs(ld - lc) / max(lc, 2.0), 0.0, 1.0) * 7.0 * DOF_STRENGTH;
        if (coc > 0.8) {
            vec2 pxd = coc / vec2(viewWidth, viewHeight);
            vec3 acc = vec3(0.0);
            for (int i = 0; i < 8; i++) {
                float aa = float(i) * 2.39996;
                float rr = sqrt((float(i) + 0.5) / 8.0);
                acc += texture2D(colortex0, suv + vec2(cos(aa), sin(aa)) * rr * pxd).rgb;
            }
            color = acc * 0.125;
        } else {
            color = texture2D(colortex0, suv).rgb;
        }
#endif
    }
    #else
        color = texture2D(colortex0, suv).rgb;
    #endif

    #ifdef CHROMATIC_ABERRATION
    {
        vec2 rc = uv - 0.5;
        vec2 ca = rc * dot(rc, rc) * 0.010;
#if defined DOF && DOF_V2 == 1
        // The raw CA taps are SHARP pre-DOF reads: on a blurred pixel they
        // would replace the r/b channels of the bokeh with a sharp ghost.
        // Fade toward the DOF result by how blurred the pixel is -- which is
        // NOT dropping CA there: the DOF_V2 gather sampled its r/b taps at
        // the SAME aberred coordinates, so color.r/b already carry the
        // blurred fringes. This mix is sharp-aberred -> blurred-aberred;
        // dofBlurF = 0 (sharp pixel or DOF idle) reproduces the raw
        // assignment exactly.
        color.r = mix(texture2D(colortex0, suv + ca).r, color.r, dofBlurF);
        color.b = mix(texture2D(colortex0, suv - ca).b, color.b, dofBlurF);
#else
        color.r = texture2D(colortex0, suv + ca).r;
        color.b = texture2D(colortex0, suv - ca).b;
#endif
    }
    #endif

    #if DAMAGE_FX == 1
    // ---- DAMAGE FLASH 1/2: impulse + radial blur, HDR (pre-GI/bloom/tonemap) ----
    // dmgAmt = fraction of max health just lost (half heart = 0.05, 4 hearts = 0.4),
    // decaying with damageHealthLag's 0.7 s half-life. Gated on health > 0 so
    // creative/spectator (-1) and the death screen (0) stay inert; respawn is silent
    // (the lag snaps UP instantly). Continuous damage (fire/poison) = light pulses.
    // Also read at the post-tonemap grade below (2/2) -- declared at main() scope.
    float dmgAmt = (currentPlayerHealth > 0.0)
                 ? clamp(damageHealthLag - currentPlayerHealth, 0.0, 1.0) * DAMAGE_FX_STRENGTH
                 : 0.0;
    if (dmgAmt > 0.003) {
        // Brief zoom-streak: 6 taps of colortex0 (FULL-RES post-TAA here, plain uv,
        // same convention as DOF above) stepping TOWARD the screen centre, so taps
        // never leave [0,1] and the centre stays sharper than the edges. Radius and
        // mix both grow with the damage taken; transient only, never permanent.
        vec2 stepD = (suv - 0.5) * min(dmgAmt, 1.0) * 0.05;
        vec3 accD = color;
        for (int i = 1; i <= 6; i++) accD += texture2D(colortex0, suv - stepD * float(i)).rgb;
        color = mix(color, accD * (1.0 / 7.0), clamp(dmgAmt * 2.5, 0.0, 0.7));
    }
    #endif

    // =====================================================================
    //  VOXEL GI injected in LINEAR HDR, BEFORE bloom/exposure/tonemap.
    //  Reconstruction uses 'uv', NOT 'suv': avoids the underwater/droplet warp.
    //  accumOut/guideOut default to vec4(0.0) (sky / VOXEL_GI==0 / DEBUG_VIEW>=13).
    //  Whole block skipped at DEBUG_VIEW>=13 (composite6 overwrites colortex0 for the
    //  voxel/RTX debug views, so the work would be wasted).
    // =====================================================================
    vec4 accumOut = vec4(0.0);
    vec4 guideOut = vec4(0.0);
    vec4 emisOut  = vec4(0.0);   // emissive history (colortex10)
    #if VOXEL_GI == 1 && DEBUG_VIEW < 13
    {
        float dG = texture2D(depthtex0, uv * TAAU_S).r; // TAAU: gbuffer sub-rect
        if (dG < 1.0) {
            vec3 wpos = worldPosFromDepth(dG);
            vec3 vn = normalize(texture2D(colortex1, uv * TAAU_S).rgb * 2.0 - 1.0); // TAAU
            vec3 wn = normalize(mat3(gbufferModelViewInverse) * vn);
            // Bias scaled to cascade-0 voxel size (anti self-hit + anti edge light-leak), same as
            // the reflection paths. max() keeps a floor when VOXEL_SCALE is small.
            vec3 origin = wpos + wn * max(GI_RAY_BIAS * VOXEL_SCALE, 0.5); // push out of the surface
#if FULL_PATH_TRACE == 1
            {
                // VOXEL SUN SHADOW: colortex0 already holds the PURE direct term (gbuffers forced
                // shadow=1). Read that direct (albedo-weighted, sampled at 'suv' to match the
                // 'color' sample) and SUBTRACT the occluded share -> directPT*vis remains, i.e. a
                // voxel shadow, without touching ambient/torch/GI/emissive/reflections.
                // max(...,0) guards against negative colour from residual DOF/droplet misalignment.
                // lightW = WORLD direction of the active light.
                vec3 directPT = texture2D(colortex12, suv * TAAU_S).rgb; // TAAU: gbuffer sub-rect
                if (luma(directPT) > 1e-5) {
                    vec3  lightW = normalize(mat3(gbufferModelViewInverse) * shadowLightPosition);
                    float vis    = traceSunVisibility(wpos, wn, lightW);
                    color = max(color - directPT * (1.0 - vis), 0.0);
                }
            }
#endif

            // CHECKERBOARD: reproject FIRST to know whether history is valid, then ray-march only
            // on the checkerboard's "compute" pixels OR on skipped pixels WITHOUT history
            // (disocclusion / first frame / offscreen) so no black holes appear.
#if GI_CHECKERBOARD == 1
            // 2x2 checkerboard (>>1: more stable than 1x1 with TAA off), alternating each frame.
            ivec2 cb = ivec2(gl_FragCoord.xy) >> 1;
            bool  gi_compute = (((cb.x + cb.y) + frameCounter) & 1) == 0;
            vec3  cbHistGI; float cbCount; float cbCountRaw; ivec2 cbHpx; bool cbHpxValid;
            bool  cbHistValid = reprojectGI(wpos, cbHistGI, cbCount, cbCountRaw, cbHpx, cbHpxValid);
            // No valid history => march anyway. First frames are forced too (colortex8/9 may not
            // be zero-initialised).
            bool  doMarch = gi_compute || !cbHistValid || frameCounter < 2;
#else
            bool  doMarch = true;
#endif

            vec3 gi;
            vec3 giEmissive = vec3(0.0);   // declared outside the branch: used by the emissive block below

            if (doMarch) {
                vec3 giAlbedo = vec3(0.0);
#if GI_FIREFLY_CLAMP == 1
                // RELATIVE anti-firefly: bound each ray against the running mean luma of the rays
                // already accumulated. A lone ray hitting a bright source while the others miss
                // (a hot dot) is clipped to GI_FIREFLY_MAX x the partial mean; a uniformly bright
                // GI raises its own mean and is NOT limited. Covers the first frame, disocclusion
                // and fresh checkerboard pixels where the EMA has no history to clamp against.
                // The absolute floor avoids over-clipping the very first ray (mean still 0) and
                // near-black areas.
                vec3  fcSumA = vec3(0.0);   // albedo sum so far (for the running mean)
                vec3  fcSumE = vec3(0.0);   // emissive sum so far
                float fcN    = 0.0;         // rays processed so far
#endif
#if SKY_GI == 1
                // WORLD sun direction, computed ONCE (uniforms exist under VOXEL_GI==1).
                // Same expression as composite1.fsh. Reads NO shadow data.
                vec3 sunW = normalize(mat3(gbufferModelViewInverse) * sunPosition);
#endif
                float fc = float(frameCounter & 255);
                float seed = hash13(wpos * 1.7 + 13.1 + fc);
                for (int s = 0; s < VOXEL_GI_SAMPLES; s++) {
                    float u1 = hash13(wpos + vec3(float(s) + seed, 1.7 + fc, 9.2));
                    float u2 = hash13(wpos + vec3(4.3, float(s) + seed, 2.1 + fc));
                    vec3 rd = cosineHemisphere(wn, u1, u2);
                    // Anti edge-leak: pre-advance the origin by HALF a voxel along rd.
                    vec3 ro = origin + rd * (0.5 * VOXEL_SCALE);

                    // --- MULTI-BOUNCE path for THIS ray ---
                    // throughput = cumulative albedo; dir/p evolve at each bounce. BOUNCES=1 gives a
                    // single march with the same albedo/emissive/miss split and the same firefly
                    // clamp (throughput=1). Cheapest fallback: BOUNCES=1 + SKY_GI=0.
                    vec3 throughput = vec3(1.0);
                    vec3 dir = rd;
                    vec3 p   = ro;
                    for (int b = 0; b < BOUNCES; b++) {
                        vec3 hp;
                        // Reduced reach for indirect bounces (b>0): a bounce does not need full range,
                        // so ~half the steps past the first keeps enclosed-interior cost down.
                        int reach = (b == 0) ? VOXEL_GI_DISTANCE : max(VOXEL_GI_DISTANCE / 2, 4);
                        vec4 hit = marchVoxelP(p, dir, reach, hp);
#if GI_FIREFLY_CLAMP == 1
                        {
                            // Relative anti-firefly applied at EVERY bounce, so with BOUNCES>1 the
                            // fcN denominator counts BOUNCES, not rays (intended).
                            bool  isE  = (hit.a > 1.5);
                            float meanL = (fcN > 0.5)
                                        ? luma((isE ? fcSumE : fcSumA) / fcN)
                                        : 0.0;
                            float capH = GI_FIREFLY_MAX * meanL + (isE ? 0.50 : 0.20);
                            float lh   = luma(hit.rgb);
                            if (lh > capH) hit.rgb *= capH / max(lh, 1e-4);
                            if (isE) fcSumE += hit.rgb; else fcSumA += hit.rgb;
                            fcN += 1.0;
                        }
#endif
                        if (hit.a < 0.5) {                              // MISS: sky / outside grid
#if SKY_GI == 1
                            giAlbedo += throughput * skyGI(dir, sunW) * SKY_GI_STRENGTH; // sky -> DIFFUSE
#endif
                            break;                                     // SKY_GI=0: adds nothing
                        }
#if EMISSIVE_VOXEL == 1
                        if (hit.a > 1.5) {                             // EMISSIVE: source -> terminate path
#if EMISSIVE_NEE == 1 || EMISSIVE_LPV == 1
                            // NEE/LPV already own the direct emitter radiance (they fill giEmissive
                            // below), so do NOT add it here (double counting).
                            // CAVEAT: under NEE==1 the emissive multi-bounce (BOUNCES>1) is LOST here
                            // (path ends without accumulating); the single-bounce gather dominates.
                            break;
#else
                            giEmissive += throughput * hit.rgb;        // -> colortex10 (accumulateEmissive)
                            break;
#endif
                        }
#else
                        if (hit.a > 1.5) {                            // EMISSIVE_VOXEL=0: no emissive channel
                            giAlbedo += throughput * hit.rgb;          // treat radiance as diffuse, then
                            break;                                     // terminate (do NOT propagate as albedo)
                        }
#endif
                        // ALBEDO: diffuse contribution (at b==0, throughput=1)
                        giAlbedo += throughput * hit.rgb;
                        throughput *= hit.rgb;                          // attenuate by the hit albedo
                        throughput = min(throughput, vec3(1.0));        // anti-explosion bound
                        if (luma(throughput) < 0.01) break;             // deterministic RR-lite: dead path
                        // No voxel normal available -> scatter around -dir (the surface roughly faces the ray).
                        float v1 = hash13(p + vec3(float(b) + 5.0, fc, 1.3));
                        float v2 = hash13(p + vec3(2.7, float(b) + seed, fc));
                        vec3 newDir = cosineHemisphere(-dir, v1, v2);
                        // Anti self-hit re-bias: step back along -dir (best normal proxy without a
                        // voxel normal, avoids bouncing inside the solid at grazing incidence), THEN
                        // advance >= 1 cascade-0 voxel along the NEW direction.
                        p   = hp - dir * (0.5 * VOXEL_SCALE)
                                 + newDir * max(GI_RAY_BIAS * VOXEL_SCALE, VOXEL_SCALE);
                        dir = newDir;
                    }
                }
                giAlbedo   /= float(VOXEL_GI_SAMPLES);
                giEmissive /= float(VOXEL_GI_SAMPLES);
#if EMISSIVE_VOXEL == 1 && EMISSIVE_LPV == 1
                // LPV: DIRECT field read at the surface, offset along the normal (anti self-hit).
                // REPLACES gatherEmissiveNEE. Plain assignment (=) overwrites anything the GI loop
                // accumulated (the emissive break above already includes EMISSIVE_LPV). The whole
                // downstream chain (accumulateEmissive -> colortex10 EMA, checkerboard,
                // EMISSIVE_GI_GAIN, EMISSIVE_DENOISE) is unchanged, so temporal stabilization is free.
                // Expect short range: only surfaces ~1 block from a source, no long-distance flood.
                giEmissive = sampleLPV(wpos + wn * (0.5 * LPV_SCALE));
#elif EMISSIVE_VOXEL == 1 && EMISSIVE_NEE == 1
                // NEE REPLACES the random-hit fill of giEmissive (which is 0 here, since the
                // emissive branch no longer feeds it under EMISSIVE_NEE==1). Downstream chain
                // (accumulateEmissive -> colortex10 EMA, checkerboard, EMISSIVE_GI_GAIN) unchanged.
                giEmissive = gatherEmissiveNEE(wpos, wn);
#endif

                // EMA + anti-firefly clamp on the RAW value.
                gi = accumulateGI(giAlbedo, wpos, accumOut, guideOut);
            }
#if GI_CHECKERBOARD == 1
            else {
                // SKIPPED pixel with valid history: reuse the history and write back the STORED
                // count (cbCountRaw = h.a, NOT incremented) so the counter does not inflate on
                // skipped frames and the EMA keeps its nominal window (GI response stays fast).
                // a>=1 is guaranteed -> colortex8.a>=0.5 -> neighbour denoise stays consistent.
                gi       = cbHistGI;
                accumOut = vec4(cbHistGI, max(cbCountRaw, 1.0));
                guideOut = vec4(wpos, 1.0);   // CURRENT wpos, else the n+1 reprojection is wrong
            }
#endif

            // Edge-aware a-trous spatial denoise on the accumulated diffuse GI.
            // Center = 'gi' (current frame, no radiance latency); neighbours = colortex8 frame n-1
            // (Iris flip) with depth/normal/luma stopping. accumOut keeps the NON-denoised accum:
            // the spatial denoise must never feed back into the history.
#if GI_DENOISE == 1
            {
                ivec2 px = ivec2(uv * vec2(viewWidth, viewHeight));
                float zC = linDepth(dG);
                gi = atrousGI(gi, px, wn, zC);
            }
#endif

            // --- LINEAR HDR: added BEFORE exposure + tonemap + toSrgb ---
            // Gain is 1.0 pre-tonemap (a post-tonemap-calibrated 0.3 would badly underexpose once
            // it passes through exposure*ACES(x*0.6)); target a full-sun bounce of ~0.3-0.5 linear,
            // the middle of the ACES curve. Tune from there with the VOXEL_GI_STRENGTH slider.
            // DAY/NIGHT: albedo GI is bounced SUN light, so it MUST fade out at night; without this
            // factor a town stays warmly lit after sunset. giDayF ~1 by day, ~0 at night (sun height).
            // Emissive (giEmissive) and moonlight (lighting.glsl) stay active at night.
            float giDayF = smoothstep(-0.05, 0.15, dot(normalize(sunPosition), normalize(upPosition)));
            // SEALED ROOM: sky/sun-bounce GI must NOT light a room with no sky access, otherwise it
            // bounces wall albedo as if sunlit and a sealed room goes white by day. colortex2.y =
            // sky lightmap (lmcoord.y) = 0 in a closed room; *1.2 reaches full GI as soon as there
            // is a little sky. Emissive is NOT gated here, so lanterns still light a sealed room.
            float giSky = clamp(texture2D(colortex2, uv * TAAU_S).y * 1.2, 0.0, 1.0); // TAAU
            color += gi * vec3(1.0, 0.95, 0.82) * VOXEL_GI_STRENGTH * giDayF * giSky;
#if EMISSIVE_VOXEL == 1
            // HYBRID TINT: stable emissive base (tinted vanilla lightmap), computed ONCE and added
            // at each combine site below. EMISSIVE_HYBRID=0 -> stays 0.0.
            vec3 hybridBase = vec3(0.0);
#if EMISSIVE_HYBRID == 1
            hybridBase = emissiveHybridBase(uv, wpos, wn);
            // The voxel gather (giEmissive, now a residual BOUNCE) is scaled by EMISSIVE_HYBRID_BOUNCE.
            giEmissive *= EMISSIVE_HYBRID_BOUNCE;
#endif
  #if EMISSIVE_ACCUM == 1
            // Temporally STABILIZED emissive (kills flicker): EMA reprojected into colortex10,
            // with NO hard anti-firefly clamp (so no fade-in), plus the comet-trail gate and the
            // fast rise on step changes.
            // On a SKIPPED pixel giEmissive=0 (no loop ran) would trip accumulateEmissive's
            // brightGhost gate and reset (flicker). So instead colortex10 is reprojected at the
            // SAME history texel as the GI (cbHpx) and that emissive is reused with the STORED
            // count, rather than calling accumulateEmissive with rawEmis=0.
  #if GI_CHECKERBOARD == 1
            if (!doMarch) {
                vec4 he = (cbHpxValid) ? texelFetch(colortex10, cbHpx, 0) : vec4(0.0);
                if (any(isnan(he)) || any(isinf(he))) he = vec4(0.0);
                emisOut = vec4(he.rgb, max(he.a, 1.0)); // he.a = STORED count: not re-incremented
                vec3 emisAdd = he.rgb;                   // displayed value (colortex10 left untouched)
  #if EMISSIVE_DENOISE == 1
                if (luma(emisAdd) > 1e-4) { ivec2 epx = ivec2(uv * vec2(viewWidth, viewHeight)); emisAdd = atrousEmissive(emisAdd, epx, wn, linDepth(dG)); }
  #endif
                color  += emisAdd * EMISSIVE_GI_GAIN + hybridBase;
            } else
  #endif
            {
                vec3 accumEmissive = accumulateEmissive(giEmissive, wpos, emisOut); // emisOut -> colortex10 (NOT denoised)
                vec3 emisAdd = accumEmissive;            // denoise is display-only
  #if EMISSIVE_DENOISE == 1
                if (luma(emisAdd) > 1e-4) { ivec2 epx = ivec2(uv * vec2(viewWidth, viewHeight)); emisAdd = atrousEmissive(emisAdd, epx, wn, linDepth(dG)); }
  #endif
                color += emisAdd * EMISSIVE_GI_GAIN + hybridBase;
            }
  #else
            // EMISSIVE_ACCUM=0 fallback: raw add, may flicker. The history is still written
            // (count=1) so switching accumulation back ON starts from a sane state.
            // On a skipped pixel colortex10 is still reprojected (it is declared whenever
            // EMISSIVE_VOXEL==1) to avoid a 1-frame hole. No EMA here, just history reuse.
  #if GI_CHECKERBOARD == 1
            if (!doMarch) {
                vec4 he = (cbHpxValid) ? texelFetch(colortex10, cbHpx, 0) : vec4(0.0);
                if (any(isnan(he)) || any(isinf(he))) he = vec4(0.0);
                emisOut = vec4(he.rgb, max(he.a, 1.0));
                vec3 emisAdd = he.rgb;                   // denoise is display-only
  #if EMISSIVE_DENOISE == 1
                if (luma(emisAdd) > 1e-4) { ivec2 epx = ivec2(uv * vec2(viewWidth, viewHeight)); emisAdd = atrousEmissive(emisAdd, epx, wn, linDepth(dG)); }
  #endif
                color  += emisAdd * EMISSIVE_GI_GAIN + hybridBase;
            } else
  #endif
            {
                emisOut = vec4(giEmissive, 1.0);
                vec3 emisAdd = giEmissive;               // denoise is display-only
  #if EMISSIVE_DENOISE == 1
                if (luma(emisAdd) > 1e-4) { ivec2 epx = ivec2(uv * vec2(viewWidth, viewHeight)); emisAdd = atrousEmissive(emisAdd, epx, wn, linDepth(dG)); }
  #endif
                color += emisAdd * EMISSIVE_GI_GAIN + hybridBase;
            }
  #endif
#endif
        }
    }
    #endif
    // =====================================================================

    // =====================================================================
    //  OFF-SCREEN VOXEL REFLECTIONS (water). One mirror ray through the clipmap, in
    //  LINEAR HDR (tonemapped later). COMPLEMENTS composite1's screen-space SSR, which
    //  is already blended into colortex0 and therefore already in `color`. Adds ONLY on
    //  a voxel GEOMETRY hit (hitR.a > 0.5): the SKY is NOT re-added here, because
    //  composite1 already reflects getSkyAll for every ray direction -- a voxel MISS
    //  (sky / outside grid) must leave `color` alone or open water is double-lit.
    //  Fresnel-weighted ADD (not a destructive mix) so existing water/SSR is preserved.
    //  Gated on VOXEL_GI==1: marchVoxel and the colortex1/gbufferModelViewInverse/
    //  cameraPosition uniforms only exist there. isEyeInWater==0 because underwater is
    //  the Snell window, handled by composite1. HORIZONTAL water only (wnR.y>0.5):
    //  waterfalls and underside faces have their own handling in composite1.
    // =====================================================================
    #if VOXEL_GI == 1 && VOXEL_REFLECTIONS == 1 && DEBUG_VIEW < 13
    if (isEyeInWater == 0) {
        float matFlagR = texture2D(colortex2, uv * TAAU_S).b;   // 1.0 = water (TAAU: gbuffer sub-rect)
        if (matFlagR > 0.95) {                          // water only: this branch kills the cost on 99% of pixels
            float dR = texture2D(depthtex0, uv * TAAU_S).r; // TAAU
            if (dR < 1.0) {
                vec3 wnR = normalize(mat3(gbufferModelViewInverse) * normalize(texture2D(colortex1, uv * TAAU_S).rgb * 2.0 - 1.0)); // TAAU
                if (wnR.y > 0.5) {                       // horizontal water (lake/ocean): skips waterfalls/undersides
                    vec3 wposR    = worldPosFromDepth(dR);  // camera-RELATIVE world pos
                    vec3 viewDirW = normalize(wposR);       // camera sits at the origin of that frame
                    // Schlick Fresnel for water (F0=0.02), same convention as composite1.
                    float ndvR  = clamp(dot(wnR, -viewDirW), 0.0, 1.0);
                    float fresR = 0.02 + 0.98 * pow(1.0 - ndvR, 5.0);
                    if (fresR > 0.004) {                    // skip nearly non-reflective pixels
                        vec3 rayDir = reflect(viewDirW, wnR);
                        // Light roughness (rippled water): micro-jitter keyed to world position and
                        // STABLE (no frameCounter -- nothing accumulates/TAAs here, it would shimmer).
                        float jit = (hash13(wposR * 2.3) - 0.5) * 0.02;
                        rayDir = normalize(rayDir + wnR * jit);
                        // Anti self-hit guard at grazing incidence: the ray must stay above the water.
                        if (dot(rayDir, wnR) < 0.02) rayDir = normalize(rayDir + wnR * (0.02 - dot(rayDir, wnR)));
                        // Anti self-hit bias scaled to cascade-0 voxel size (>= 1 voxel).
                        vec3 originR = wposR + wnR * max(0.6, VOXEL_SCALE * 1.5);
                        vec4 hitR = marchVoxel(originR, rayDir, REFLECTION_STEPS);
                        // ADD only on a geometry HIT. A MISS (sky / outside grid) adds nothing:
                        // the reflected sky is already in `color` from composite1.
                        if (hitR.a > 0.5) {
                            vec3 reflColor;
                            if (hitR.a > 1.5) {
                                // Emissive: direct radiance (reflected lava/glowstone is correct).
                                reflColor = hitR.rgb;
                            } else {
                                // Albedo: approximate GI-style lighting, else the reflection looks flat.
                                reflColor = hitR.rgb * vec3(1.0, 0.95, 0.82) * 1.4;
                            }
                            // Weighted ADD (not a mix): screen SSR is already in `color` from
                            // composite1, so only the off-screen complement is added here.
                            color += reflColor * fresR * REFLECTION_STRENGTH;
                        }
                    }
                }
            }
        }
    }
    #endif
    // ---- end water voxel reflections ----

    // =====================================================================
    //  OFF-SCREEN VOXEL REFLECTIONS on GLOSSY/METAL OPAQUES.
    //  Same pattern as the water block: one voxel mirror ray, ADD-only on a geometry HIT
    //  (.a>0.5), MISS adds NOTHING (sky/screen SSR already in color from composite1).
    //  Targets pure opaques (matFlag~0) that are smooth enough (smoothness colortex2.a)
    //  OR metallic (metalness colortex11.g). Perf gate: trace only when gloss > threshold.
    //  Without a LabPBR pack gloss=0 -> no rays -> free and inert.
    //  NOTE: worldPosFromDepth(dO) reads the fragment's GLOBAL uv internally, so dO MUST be
    //  the depth sampled at the current uv -- never pass a depth taken at another uv.
    // =====================================================================
    #if VOXEL_GI == 1 && VOXEL_REFLECTIONS == 1 && VOXEL_REFLECTIONS_OPAQUE == 1 && DEBUG_VIEW < 13
    if (isEyeInWater == 0) {
        vec4 d2O = texture2D(colortex2, uv * TAAU_S);       // TAAU: gbuffer sub-rect
        // pure OPAQUE (excludes water 1.0 / glass 0.7 / lava 0.58 / emissive 0.5);
        // the SNOW band (0.38, SNOW_SPARKLE tag) is an opaque too.
        if (d2O.b < 0.05 || (d2O.b > 0.35 && d2O.b < 0.42)) {
            float smoothO = d2O.a;                          // colortex2.a = LabPBR perceptual smoothness (0 without a pack)
            float metalO  = texture2D(colortex11, uv * TAAU_S).g;    // LabPBR metalness (TAAU)
            float glossO  = max(smoothO, metalO);
            if (glossO > REFLECT_OPAQUE_THRESHOLD) {        // perf gate + LabPBR dependency (RUNTIME, not #if)
                float dO = texture2D(depthtex0, uv * TAAU_S).r; // TAAU
                // Hand guard (mirror of composite1): squashed hand depth (<0.56)
                // would yield garbage voxel-reflection ray origins.
                if (dO < 1.0 && dO > 0.56) {
                    vec3 vnO = normalize(texture2D(colortex1, uv * TAAU_S).rgb * 2.0 - 1.0); // TAAU
                    vec3 wnO = normalize(mat3(gbufferModelViewInverse) * vnO);
                    vec3 wposO    = worldPosFromDepth(dO);  // camera-RELATIVE world pos (global uv)
                    vec3 viewDirO = normalize(wposO);       // camera sits at the origin of that frame
                    float ndvO  = clamp(dot(wnO, -viewDirO), 0.0, 1.0);
                    float fresD = 0.04 + 0.96 * pow(1.0 - ndvO, 5.0);   // dielectric F0=0.04
                    float fresO = mix(fresD, 1.0, metalO);              // metal = mirror face-on
                    float reflWO = fresO * glossO;          // weight = Fresnel x sharpness
                    if (reflWO > 0.01) {
                        vec3 rayDirO = reflect(viewDirO, wnO);
                        float jitO = (hash13(wposO * 2.7) - 0.5) * (1.0 - glossO) * 0.10;  // STABLE glossy blur (no frameCounter)
                        rayDirO = normalize(rayDirO + wnO * jitO);
                        if (dot(rayDirO, wnO) < 0.02) rayDirO = normalize(rayDirO + wnO * (0.02 - dot(rayDirO, wnO)));
                        vec3 originO = wposO + wnO * max(0.6, VOXEL_SCALE * 1.5);          // anti self-hit bias = 1 cascade-0 voxel
                        vec4 hitO = marchVoxel(originO, rayDirO, REFLECTION_STEPS);
                        if (hitO.a > 0.5) {                 // ADD-only on HIT (MISS -> nothing)
                            vec3 reflColO;
                            if (hitO.a > 1.5) {
                                reflColO = hitO.rgb;        // emissive: direct radiance (reflected lanterns at night)
                            } else {
                                // Albedo: approximate GI-style lighting (warm daytime tint).
                                // Local giDayF (~1 day, ~0 night) kills the albedo reflection at night
                                // to stay consistent with the voxel GI; the outer giDayF is not in scope here.
                                float giDayFO = smoothstep(-0.05, 0.15, dot(normalize(sunPosition), normalize(upPosition)));
                                reflColO = hitO.rgb * vec3(1.0, 0.95, 0.82) * 1.4 * mix(0.3, 1.0, giDayFO);
                            }
                            color += reflColO * reflWO * REFLECTION_STRENGTH_OPAQUE;        // weighted ADD, dedicated low strength
                        }
                    }
                }
            }
        }
    }
    #endif
    // ---- end opaque voxel reflections ----

    #ifdef BLOOM_ACTIVE
        #if BLOOM_MIP == 1
        // Pyramid sum over LOD 1..6, weights normalized to 1.00 -> same total energy as a
        // single tap (0.26 * BLOOM_STRENGTH) but a much wider, softer halo.
        // TAAU: the bloom pyramid (colortex3) is PRE-TAA -> sub-rect
        #if BLOOM_HALF_RES == 1
        // Half-res: quadrant coord (0.5 * sub-rect) and the ladder shifted one
        // level down -- quadrant LOD n has the same ON-SCREEN texel size as
        // full-res LOD n+1, so halo widths and weights are unchanged. LOD 0 is
        // the half-res blurred brightpass itself (was: downsampled full-res).
        vec3 bloomSum = bloomMipTap(suv * (TAAU_S * 0.5), 0.0) * 0.28
                      + bloomMipTap(suv * (TAAU_S * 0.5), 1.0) * 0.24
                      + bloomMipTap(suv * (TAAU_S * 0.5), 2.0) * 0.19
                      + bloomMipTap(suv * (TAAU_S * 0.5), 3.0) * 0.14
                      + bloomMipTap(suv * (TAAU_S * 0.5), 4.0) * 0.09
                      + bloomMipTap(suv * (TAAU_S * 0.5), 5.0) * 0.06;
        #else
        vec3 bloomSum = bloomMipTap(suv * TAAU_S, 1.0) * 0.28
                      + bloomMipTap(suv * TAAU_S, 2.0) * 0.24
                      + bloomMipTap(suv * TAAU_S, 3.0) * 0.19
                      + bloomMipTap(suv * TAAU_S, 4.0) * 0.14
                      + bloomMipTap(suv * TAAU_S, 5.0) * 0.09
                      + bloomMipTap(suv * TAAU_S, 6.0) * 0.06;
        #endif
        vec3 bloomC = bloomSum * 0.26 * BLOOM_STRENGTH;
        #else
        #if BLOOM_HALF_RES == 1
        // Half-res: single bilinear tap on the quadrant, clamped one texel
        // inside so the top/right screen edge does not blend the black dead
        // zone. Bloom is a wide blur -> bilinear upsample is enough.
        vec3 bloomC = texture2D(colortex3, min(suv * (TAAU_S * 0.5),
                          vec2(0.5 * TAAU_S) - 1.0 / vec2(viewWidth, viewHeight))).rgb
                      * 0.26 * BLOOM_STRENGTH;
        #else
        vec3 bloomC = texture2D(colortex3, suv * TAAU_S).rgb * 0.26 * BLOOM_STRENGTH; // TAAU
        #endif
        #endif
        // Ordered dither (bayer8): breaks bloom banding on sky gradients.
        bloomC += (bayer8(gl_FragCoord.xy) - 0.5) * (1.0 / 255.0);
        color += max(bloomC, vec3(0.0));
    #endif

    float exposure = EXPOSURE;
    #ifdef AUTO_EXPOSURE
        float eyeB = float(max(eyeBrightnessSmooth.x, eyeBrightnessSmooth.y)) / 240.0;
        float adaptK = mix(3.2, 1.0, smoothstep(0.03, 0.65, eyeB));
#if DIMENSION_FX == 1
        // Nether: bounded adaptation (x2.0 max) - the dark fog roof must not
        // drive the gain up and blow the lava out. Exact no-op elsewhere.
        adaptK = mix(adaptK, min(adaptK, 2.0), dimNether());
#endif
        exposure *= adaptK;
    #endif
    color *= exposure;

    #ifdef LAVA_OVERLAY
    if (isEyeInWater == 2) {
        vec3 lavaView = vec3(2.2, 0.55, 0.06);
        float vig = 1.0 - dot(uv - 0.5, uv - 0.5) * 1.2;
        color = mix(color * vec3(1.6, 0.5, 0.2), lavaView, 0.72)
              * (0.7 + 0.5 * vig) * (0.85 + 0.15 * sin(frameTimeCounter * 5.0));
    }
    #endif

    // ---- White balance ----
    color *= vec3(1.0 + WB_TEMPERATURE, 1.0 + WB_TINT * 0.5, 1.0 - WB_TEMPERATURE);

    // ---- Tonemap (LINEAR HDR -> LDR, then sRGB encode) ----
    #ifdef AGX_TONEMAP
        color = agxEotf(agx(color));
    #elif defined ACES_TONEMAP
        color = aces(color * 0.6);
    #else
        color = uchimura(color);
    #endif
    color = toSrgb(color);

    // GOLDEN HOUR GRADE (post-tonemap): in BOUNDED space the image can be warmed and
    // saturated without ever blowing out to white -- the cinematic dusk grade.
    float sunHd = dot(normalize(sunPosition), normalize(upPosition));
    float duskG = clamp(1.0 - abs(sunHd) * 4.5, 0.0, 1.0) * smoothstep(-0.12, -0.02, sunHd)
                // Gated by eye sky exposure: this grade is FULL SCREEN and was
                // warming/saturating caves at sunset (pink veil underground).
                * smoothstep(0.0, 0.30, float(eyeBrightnessSmooth.y) / 240.0);
#if DIMENSION_FX == 1
    // Nether / End: no golden hour (their sun is frozen; the eye gate above is
    // already 0 there, this keeps the contract explicit). Dimension weights
    // shared by the world-clock grade, godrays and lens flare below.
    float dimClock = (1.0 - dimNether()) * (1.0 - dimEnd());
    duskG *= dimClock;
#endif
    if (duskG > 0.001) {
        color *= mix(vec3(1.0), vec3(1.06, 0.93, 0.84), duskG);
        float lG = luma(color);
        color = clamp(mix(vec3(lG), color, 1.0 + 0.30 * duskG), 0.0, 1.0);
    }

    // TIME-OF-DAY COLOR GRADE ([CONFIG] lab, post-tonemap, after the golden
    // hour grade, before vignette/grain). 4 periods with CONTINUOUS weights:
    // day/night from sun height (sunHd, hoisted above), the twilight band
    // split into dawn vs dusk by the MC clock (worldTime 0 = sunrise,
    // 6000 = noon, 12000 = sunset, 18000 = midnight). Applied as DELTAS from
    // neutral, so all-default sliders keep the pixel bit-identical (every
    // factor folds to exactly 1.0 whatever the weights are).
    #if TC_ENABLE == 1
    {
        float tcDayW   = smoothstep(0.10, 0.32,  sunHd);
        float tcNightW = smoothstep(0.10, 0.32, -sunHd); // disjoint from tcDayW
        float tcTwiW   = clamp(1.0 - tcDayW - tcNightW, 0.0, 1.0);
        // Rising half of the clock (midnight -> noon) = dawn side of twilight.
        // Crossfaded over ~500 ticks around the noon/midnight seams (verifier:
        // at |sunPathRotation| > 60 deg the twilight weight is nonzero at noon,
        // a hard ternary would pop between dawn and dusk settings there).
        float dawnSide = 1.0 - smoothstep(5750.0, 6250.0, float(worldTime))
                             + smoothstep(17750.0, 18250.0, float(worldTime));
        float tcDawnW  = tcTwiW * clamp(dawnSide, 0.0, 1.0);
        float tcDuskW  = tcTwiW - tcDawnW;
#if DIMENSION_FX == 1
        // Nether / End: the shared world clock must not show -> every period
        // weight collapses to 0 and each factor below folds to exactly 1.0.
        tcDawnW *= dimClock; tcDuskW *= dimClock; tcDayW *= dimClock; tcNightW *= dimClock;
#endif
        float tcT =       tcDawnW * TC_DAWN_TEMP          + tcDayW   * TC_DAY_TEMP
                        + tcDuskW * TC_DUSK_TEMP          + tcNightW * TC_NIGHT_TEMP;
        float tcS = 1.0 + tcDawnW * (TC_DAWN_SAT - 1.0)   + tcDayW   * (TC_DAY_SAT - 1.0)
                        + tcDuskW * (TC_DUSK_SAT - 1.0)   + tcNightW * (TC_NIGHT_SAT - 1.0);
        float tcB = 1.0 + tcDawnW * (TC_DAWN_BRIGHT - 1.0) + tcDayW   * (TC_DAY_BRIGHT - 1.0)
                        + tcDuskW * (TC_DUSK_BRIGHT - 1.0) + tcNightW * (TC_NIGHT_BRIGHT - 1.0);
        // Temperature: warm raises R / lowers B (cool is the reverse)
        color.r *= 1.0 + tcT * 0.15;
        color.b *= 1.0 - tcT * 0.15;
        color = mix(vec3(luma(color)), color, tcS);
        color *= tcB;
        // Post-tonemap space is [0,1]: clamp like the golden-hour grade so
        // off-default BRIGHT/TEMP cannot push highlights past the contrast curve.
        color = clamp(color, 0.0, 1.0);
    }
    #endif

    color = mix(color, color * color * (3.0 - 2.0 * color), 0.18 * TONEMAP_CONTRAST);

    float l = luma(color);
    float satC = clamp(length(color - vec3(l)) * 2.2, 0.0, 1.0);
    color = mix(vec3(l), color, SATURATION + (1.0 - satC) * 0.10 * VIBRANCE);

    #ifdef PURKINJE
    {
        float eyeS = float(eyeBrightnessSmooth.y) / 240.0;
        float sceneD = clamp(1.0 - eyeS * 2.0, 0.0, 1.0);
        float localD = clamp(1.0 - luma(color) * 6.0, 0.0, 1.0);
        float pk = sceneD * localD;
#if DIMENSION_FX == 1
        // Nether: no scotopic blue shift on the warm dark (it read as an
        // Overworld night); End keeps half of it (violet world anyway).
        pk *= 1.0 - max(dimNether(), 0.5 * dimEnd());
#endif
        if (pk > 0.01) {
            vec3 nightSight = vec3(0.42, 0.62, 1.12) * luma(color) * 1.10;
            color = mix(color, nightSight, pk * 0.60);
        }
    }
    #endif

    #ifdef GODRAYS
#if DIMENSION_FX == 1
    // Nether / End: no screen-space godrays (no sun to anchor them).
    if (isEyeInWater == 0 && dimClock > 0.5) {
#else
    if (isEyeInWater == 0) {
#endif
        float sunHg = dot(normalize(sunPosition), normalize(upPosition));
        vec4 clipG = gbufferProjection * vec4(sunPosition, 1.0);
        if (sunHg > -0.05 && clipG.w > 0.0) {
            vec2 suvG = (clipG.xy / clipG.w) * 0.5 + 0.5;
            if (suvG.x > -0.4 && suvG.x < 1.4 && suvG.y > -0.4 && suvG.y < 1.4) {
                // warmT hoisted out of the loop (the extraction threshold depends on dusk)
                float warmT = smoothstep(0.35, 0.02, sunHg);
                vec2 stepG = (suvG - uv) / float(GODRAY_SAMPLES);
                float dRay = fract(hash12(gl_FragCoord.xy) + fract(frameTimeCounter));
                vec2 q = uv + stepG * dRay;
                float decay = 1.0;
                float acc = 0.0;
                float wsum = 0.0;
#if GODRAY_ANCHOR_FIX == 1
                // Sun anchoring: the suvG PROJECTION is correct (clip = P*viewPos); it was the
                // EXTRACTION that produced ghost rays -- any bright pixel (cloud bank, sand,
                // marbled water) passed the luma threshold and anchored a fan of rays ON ITSELF
                // instead of on the sun. Double mask: (1) SKY pixels only (depth>=1, so terrain
                // and water no longer feed the rays), (2) an aspect-corrected circumsolar disc,
                // so only the sun's neighbourhood is a source while cloud/foliage occlusion still
                // carves the rays. The disc widens at sunset (legitimate warm halo).
                float aspectG = viewWidth / viewHeight;
                float rSunG = mix(0.26, 0.50, warmT);
                for (int i = 0; i < GODRAY_SAMPLES; i++) {
                    q += stepG;
                    if (q.x < 0.0 || q.x > 1.0 || q.y < 0.0 || q.y > 1.0) break;
                    float dSunG = length((q - suvG) * vec2(aspectG, 1.0));
                    // TAAU: the march q lives in FULL-RES screen space (post-TAA
                    // colortex0); only the DEPTH reads go through the sub-rect.
                    float srcW = smoothstep(rSunG, rSunG * 0.25, dSunG)
                               * step(1.0, texture2D(depthtex0, q * TAAU_S).r);
#ifdef DISTANT_HORIZONS
                    // DH LODs must occlude the godray source too (their depth
                    // lives in dhDepthTex0, not depthtex0), otherwise a setting
                    // sun behind a LOD mountain radiates straight THROUGH it.
                    srcW *= step(1.0, texture2D(dhDepthTex0, q * TAAU_S).r);
#endif
                    // Threshold lowered at sunset (the warm sky feeds the rays)
                    acc += smoothstep(1.3 - warmT * 0.55, 4.5, luma(texture2D(colortex0, q).rgb)) * srcW * decay;
                    wsum += decay;
                    decay *= 0.90;
                }
#else
                for (int i = 0; i < GODRAY_SAMPLES; i++) {
                    q += stepG;
                    if (q.x < 0.0 || q.x > 1.0 || q.y < 0.0 || q.y > 1.0) break;
                    // Threshold lowered at sunset (the warm sky feeds the rays)
                    acc += smoothstep(1.3 - warmT * 0.55, 4.5, luma(texture2D(colortex0, q).rgb)) * decay;
                    wsum += decay;
                    decay *= 0.90;
                }
#endif
                acc /= max(wsum, 1e-4);
                // Player/hand looked "transparent" in front of the sun: the ray path
                // between the camera and a NEAR occluder is physically almost zero, so
                // attenuate by the center pixel's distance and godrays stop painting
                // OVER the player.
                float d0G = texture2D(depthtex0, uv * TAAU_S).r; // TAAU: depth sub-rect
                if (d0G < 1.0) {
                    // Linearize via gbufferProjection: gbufferProjectionInverse is
                    // declared under the VOXEL_GI gate in this file and is not in scope here.
                    float zNdcG = d0G * 2.0 - 1.0;
                    float distG = gbufferProjection[3][2] / (zNdcG + gbufferProjection[2][2]);
                    acc *= clamp(distG / 24.0, 0.0, 1.0);
#if GODRAY_WATER_SPLIT == 1
                    // A WATER pixel already owns a full beam system: the
                    // volumetric march of composite1 runs THROUGH the surface
                    // to the opaque floor and draws the underwater shafts
                    // there. This screen fan knows nothing about the surface,
                    // and the whole block is gated on isEyeInWater == 0, so
                    // the same lake carried two ray systems seen from the bank
                    // and one seen from inside -- the geometry was unified, the
                    // composited image was not.
                    // Keep only the share of the pixel's path that really IS
                    // air: camera -> surface against camera -> floor. depthtex1
                    // ignores translucents, so an opaque pixel gives d1G == d0G
                    // and the ratio is exactly 1 (bit-identical there). Floor
                    // 0.25: a grazing sea pixel is mostly REFLECTED sky, whose
                    // light never crossed the column, and the airborne haze in
                    // front of it is real -- the fan is trimmed, never cut.
                    if (texture2D(colortex2, uv * TAAU_S).b > 0.95) {
                        float d1G = texture2D(depthtex1, uv * TAAU_S).r;
                        float dist1 = far;
                        if (d1G < 1.0) {
                            float zNdc1 = d1G * 2.0 - 1.0;
                            dist1 = gbufferProjection[3][2] / (zNdc1 + gbufferProjection[2][2]);
                        }
                        acc *= clamp(distG / max(dist1, 1e-3), 0.25, 1.0);
                    }
#endif
                }
                // Warm->white tint inlined (getLightColor is not included in composite5).
                vec3 rayTint = mix(vec3(1.0, 0.95, 0.85), vec3(1.0, 0.80, 0.55), warmT);
                float radial = exp(-length(uv - suvG) * 0.7);
                color += rayTint * acc * 0.06 * GODRAY_STRENGTH * radial
                       * (1.0 + warmT * GODRAY_DUSK_BOOST)
                       * smoothstep(-0.05, 0.1, sunHg) * (1.0 - rainStrength * 0.7);
            }
        }
    }
    #endif

    #ifdef LENS_FLARE
    {
        float sunH = dot(normalize(sunPosition), normalize(upPosition));
        vec4 clipS = gbufferProjection * vec4(sunPosition, 1.0);
#if UW_FLARE_CUT == 1
        // No lens-housing flare underwater: the sun disc seen from below keeps bloom
        // and the Snell window, but no ghosts / screen halo.
        if (isEyeInWater == 0 && sunH > 0.0 && clipS.w > 0.0) {
#else
        if (sunH > 0.0 && clipS.w > 0.0) {
#endif
            vec2 suvS = (clipS.xy / clipS.w) * 0.5 + 0.5;
            if (suvS.x > -0.2 && suvS.x < 1.2 && suvS.y > -0.2 && suvS.y < 1.2) {
                float occ = 0.0;
                for (int i = 0; i < 5; i++) {
                    vec2 o = vec2(cos(float(i) * 1.2566), sin(float(i) * 1.2566)) * 0.012;
                    vec2 q = clamp(suvS + o, vec2(0.001), vec2(0.999));
                    // TAAU: probes in full-res screen space, depth reads in the sub-rect
                    float visS = step(1.0, texture2D(depthtex0, q * TAAU_S).r);
#ifdef DISTANT_HORIZONS
                    // A DH LOD in front of the sun cuts the lens flare too.
                    visS *= step(1.0, texture2D(dhDepthTex0, q * TAAU_S).r);
#endif
                    occ += visS;
                }
                float vis = occ * 0.2 * smoothstep(0.0, 0.15, sunH) * (1.0 - rainStrength);
#if DIMENSION_FX == 1
                vis *= dimClock; // Nether / End: no sun, no lens-housing flare
#endif
                if (vis > 0.001) {
                    float aspect = viewWidth / viewHeight;
                    vec2 toC = vec2(0.5) - suvS;
                    vec2 dS = (uv - suvS) * vec2(aspect, 1.0);
                    vec3 fl = vec3(1.0, 0.85, 0.60) * exp(-dot(dS, dS) * 60.0) * 0.30;
                    for (int g = 1; g <= 4; g++) {
                        vec2 gpos = suvS + toC * (float(g) * 0.5);
                        vec2 dg = (uv - gpos) * vec2(aspect, 1.0);
                        float sz = 200.0 + float(g) * 250.0;
                        vec3 gc = (g == 1) ? vec3(0.90, 0.55, 0.30)
                                : (g == 2) ? vec3(0.35, 0.70, 0.50)
                                : (g == 3) ? vec3(0.40, 0.45, 0.90)
                                           : vec3(0.70, 0.40, 0.70);
                        fl += gc * exp(-dot(dg, dg) * sz) * 0.10;
                    }
                    color += fl * vis * LENS_FLARE_STRENGTH;
                }
            }
        }
    }
    #endif

    #if CAMERA_DROPLETS > 0
        // discreet cool glint on drop/trail rims (dropHi already carries dAmt)
        color += vec3(0.55, 0.65, 0.75) * dropHi * dropHi * 0.09;
    #endif

    #ifdef BOSS_FX
    if (bossBattle > 0) {
        float bpulse = 0.5 + 0.5 * sin(frameTimeCounter * 2.8);
        float bvig = dot(uv - 0.5, uv - 0.5) * 3.5;
        color = mix(color, color * vec3(0.55, 0.25, 0.80), bvig * 0.25 * bpulse);
    }
    #endif

#if defined END_STORM_ACTIVE && END_LIGHTNING_FLASH == 1
    // ---- END LIGHTNING screen flash (post-tonemap, bounded space): a faint
    //      additive tint in the bolt color on each strike, stronger for the
    //      nearer bolts (horizontal offset from the camera-relative state:
    //      camPos = 0 here). Peak +0.09 at the closest bolt, anti-epilepsy by
    //      design (the storm, fog and surfaces carry the real flash).
    if (dimEnd() > 0.5) {
        vec3 bPF;
        vec3 bCF;
        float flF = endLightningState(frameTimeCounter, vec3(0.0), bPF, bCF);
        if (flF > 0.001) {
            // Rescaled with the bolt draw: strikes now start past the
            // END_ISLAND_CLEAR ramp (155 blocks at the default dial instead of
            // 110), so the kernel is retuned to keep the SAME screen flash -
            // 0.93 at the nearest bolt, 0.51 at the farthest - and the gain
            // drops 0.12 -> 0.11 because the pulse peak went ~0.83 -> ~0.88.
            // Peak stays exactly +0.09, and the added remanence only makes the
            // tail longer and softer, never the spike higher.
            float nearF = 200.0 / (length(bPF.xz) + 60.0);
            color = clamp(color + bCF * (flF * 0.11 * nearF), 0.0, 1.0);
        }
    }
#endif

    #if DAMAGE_FX == 1
    // ---- DAMAGE FLASH 2/2: post-tonemap grade (bounded space; after Purkinje so
    //      the red is not blue-shifted at night, before film grain; the VIGNETTE
    //      of final.fsh comes later on top). Edge-heavy dark blood vignette
    //      sparing the centre + a brief global desaturate/darken kick.
    //      Curve at strength 1.0: half heart ~0.15 edge tint (subtle), 1 heart
    //      0.30, ~3 hearts saturates at 0.85 = violent flash.
    if (dmgAmt > 0.003) {
        float edgeD = smoothstep(0.25, 1.0, length(uv - 0.5) * 1.41421); // 1.0 at corners
        float vigD  = clamp(dmgAmt * 3.0, 0.0, 0.85) * edgeD;
        color = mix(color, vec3(0.45, 0.02, 0.02), vigD);
        color = mix(color, vec3(luma(color)) * 0.85, clamp(dmgAmt, 0.0, 1.0) * 0.25);
    }
    #endif

    #ifdef FILM_GRAIN
        float grain = hash12(gl_FragCoord.xy + fract(frameTimeCounter) * 113.0) - 0.5;
        color += grain * 0.012;
    #endif

    // Vignette is applied once, in final.fsh.
// PERF: conditional MRT. At VOXEL_GI=0, writing vec4(0) full-screen into colortex8
// (16F) + 9 (32F) + 10 (16F) costs 32 bytes/pixel of dead bandwidth (~66 MB/frame
// at 1080p), so the extra targets are declared only when GI is on.
#if VOXEL_GI == 1
/* RENDERTARGETS: 0,8,9,10 */
#else
/* RENDERTARGETS: 0 */
#endif
    gl_FragData[0] = vec4(color, luma(color)); // colortex0  : LDR + luma in alpha (consumed by FXAA)
#if VOXEL_GI == 1
    gl_FragData[1] = accumOut;  // colortex8  : accumulated albedo GI + count
    gl_FragData[2] = guideOut;  // colortex9  : worldPos guide (disocclusion, shared with emissive)
    gl_FragData[3] = emisOut;   // colortex10 : accumulated emissive + count
#endif
}
