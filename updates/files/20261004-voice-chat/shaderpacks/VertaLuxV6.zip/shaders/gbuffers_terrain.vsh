#version 120
/* Terrain (vertex): wind sway for foliage + TAA/TAAU jitter (reference impl). */

#include "/lib/settings.glsl"
#include "/lib/common.glsl"

attribute vec4 mc_Entity;
attribute vec4 at_tangent;

uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
uniform vec3 cameraPosition;
uniform float frameTimeCounter;
uniform float rainStrength;
uniform int frameCounter;   // drives the TAA jitter sequence
uniform float viewWidth;
uniform float viewHeight;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 normal;
varying vec4 tangent;
varying vec3 viewPos;
varying float mat;

void main() {
    mat = mc_Entity.x;

    vec4 pos = gl_ModelViewMatrix * gl_Vertex;

    #ifdef WAVING_FOLIAGE
        // Foliage sways gently, harder in rain. mat 10 = waving plant material.
        // LIMITATION: this displacement lives in the CAMERA pass only. shadow.vsh
        // rasterizes the undisplaced geometry (ftransform + distortShadow), so the
        // shadow map keeps the still silhouette. Invisible at WAVING_STRENGTH 1
        // (amplitude 0.022 block), visible from ~3 up. Fixing it means duplicating
        // the whole block in shadow.vsh under the same #ifdef, with the shadow-space
        // world position - deliberately NOT done here.
        if (mat > 9.5 && mat < 10.5) {
            vec4 wp = gbufferModelViewInverse * pos;
            vec3 absW = wp.xyz + cameraPosition;
            float aqua = step(absW.y, WATER_LEVEL - 0.2);  // 1 = underwater plant
            bool doWave = true;
            #ifndef WAVING_WATER_PLANTS
                if (aqua > 0.5) doWave = false;            // underwater plants stay still
            #endif
            if (doWave) {
                // Underwater: slow and wide sway; in wind: faster and tighter
                // WAVING_SCALE / RAIN_BOOST / WATER_AMOUNT are compile-time
                // constants; at their defaults (1.0 / 1.5 / 1.8) the folded
                // expression is bit-identical to the historical one.
                float t = frameTimeCounter * WAVING_SPEED * (1.0 - 0.5 * aqua);
                float amp = 0.022 * WAVING_STRENGTH * (1.0 + rainStrength * WAVING_RAIN_BOOST)
                          * (1.0 + aqua * WAVING_WATER_AMOUNT);
                wp.x += sin(absW.x * (0.6 * WAVING_SCALE) + absW.y * (0.3 * WAVING_SCALE) + t * 1.7)
                      * sin(absW.z * (0.5 * WAVING_SCALE) + t * 1.3) * amp;
                wp.z += sin(absW.z * (0.7 * WAVING_SCALE) + absW.y * (0.2 * WAVING_SCALE) + t * 1.4) * amp * 0.7;
                pos = gbufferModelView * wp;
            }
        }
    #endif

    viewPos = pos.xyz;
    gl_Position = gl_ProjectionMatrix * pos;
    #ifdef TAA
        // TAAU: jitter expressed in RENDER BUFFER texels (divided by TAAU_S).
        // After the scale mapping below it is again a CONSTANT sub-texel offset
        // of the framebuffer, which composite4 undoes with the same sequence.
        // At TAAU_S = 1.0 this is identical to plain TAA.
        gl_Position.xy += taaJitterNDC(frameCounter) * TAA_JITTER * gl_Position.w * vec2(2.0 / (viewWidth * TAAU_S), 2.0 / (viewHeight * TAAU_S));
    #endif
    // TAAU: BOTTOM-LEFT sub-rect mapping - NDC [-1,1] -> [-1, 2*TAAU_S-1], i.e.
    // UV [0,1] -> [0,TAAU_S]. Applied AFTER the jitter; that order keeps the
    // jitter a sub-texel offset of the render buffer, not of the visible screen.
    // At TAAU_S = 1.0 this folds away at compile time (no-op).
    gl_Position.xy = gl_Position.xy * TAAU_S + gl_Position.w * (TAAU_S - 1.0);

    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord  = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    glcolor  = gl_Color;
    normal   = normalize(gl_NormalMatrix * gl_Normal);
    tangent  = vec4(normalize(gl_NormalMatrix * at_tangent.xyz), at_tangent.w);
}
