#version 330 compatibility
/* VertaLux — Distant Horizons : terrain LOD (fragment).
   Eclairage COHERENT avec gbuffers_terrain : shadeSurface (lib/lighting.glsl)
   avec gl_Color comme albedo (geometrie DH non texturee — pas de PBR, pas de
   normal map, pas de POM). Au-dela de shadowDistance, shadeSurface fond DEJA
   l'ombre vers lm.y^2 (sfade, lighting.glsl:330) et sampleShadowPCF sort tot
   hors de la shadow map -> les LODs recoivent soleil/ambiant/ombres de nuages
   (cloudShadow, monde) coherents SANS passe d'ombre DH (dhShadow.enabled=false,
   voir shaders.properties : LODs >= ~far alors que la shadow map couvre
   shadowDistance <= 384 — rien d'utile a projeter, cout evite).
   DRAWBUFFERS alignes gbuffers_terrain : colortex0 couleur eclairee (HDR),
   colortex1 normale, colortex2 lmcoord + flag 0 (opaque) + smoothness 0,
   colortex5 albedo (parite debug). Le bloc #ifdef DISTANT_HORIZONS de
   composite1 lit colortex2.g (skylight des LODs) pour sa brume DH.
   colortex11/12 NON ecrits : colortex11Clear/colortex12Clear = true les
   couvrent, et les pixels DH (depthtex0 = 1.0) ne passent jamais par les
   branches PBR/GI qui les consomment.
   AUCUN fog ici : la brume des LODs vit dans composite1 (reconstruction via
   dhProjectionInverse) — en faire ici serait du double-fog. */

// Opt-out de la compensation d'ambiante SSGI/RSM de shadeSurface (GI-RSM) :
// composite1 classe les pixels DH comme ciel (isDHpix) et ne leur reinjecte
// JAMAIS le rebond ; sans cet opt-out le LOD perdrait 15 % de son ambiante
// ciel sans contrepartie — echelon de luminosite net sur la couture
// vanilla/DH. Voir le bloc GI_BOUNCE_AMBIENT dans lib/lighting.glsl.
#define VLX_DH_NO_GI_COMP

#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/distort.glsl"
#include "/lib/biome.glsl"
#include "/lib/dimension.glsl"
#include "/lib/lighting.glsl"

uniform float far;

varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 normal;
varying vec3 viewPos;
flat varying int dhMatId;

void main() {
    // Anti double-draw: under far-32 the vanilla terrain already covers the
    // area, so skip the shading and every gbuffer write that would pollute
    // the near-terrain pixels.
    if (length(viewPos) < max(far - 32.0, 32.0)) discard;

    vec3 albedo = toLinear(glcolor.rgb);
    // Feuillage LOD : meme diffusion sous-surface que le terrain vanilla
    // (plancher diffus + contre-jour) — coherence de teinte des forets.
    float subsurface = (dhMatId == DH_BLOCK_LEAVES) ? 1.0 : 0.0;
    vec3 nrm = normalize(normal);
    float dither = bayer8(gl_FragCoord.xy);

    vec3 color = shadeSurface(albedo, nrm, lmcoord, viewPos, dither, subsurface);

    // Emissifs LOD : lave et blocs lumineux continuent de rougeoyer au loin
    // (luminance > seuil de bloom 2.2) — memes teintes que gbuffers_terrain,
    // intensite reduite (pas de masque texture a cette distance).
    if (dhMatId == DH_BLOCK_LAVA) {
        color += albedo * vec3(1.40, 0.78, 0.38) * EMISSIVE_BOOST * 0.45;
    } else if (dhMatId == DH_BLOCK_ILLUMINATED) {
        color += albedo * vec3(1.25, 0.95, 0.62) * EMISSIVE_BOOST * 0.30;
    }

/* DRAWBUFFERS:0125 */
    gl_FragData[0] = vec4(color, 1.0);
    gl_FragData[1] = vec4(nrm * 0.5 + 0.5, 1.0);
    // flag colortex2.b = 0.0 (opaque pur) et smoothness .a = 0.0 : aucun test
    // matiere des composites (eau >0.95, verre 0.6-0.8, portail 0.82-0.93,
    // SSR PBR via .a) ne se declenche sur un LOD.
    gl_FragData[2] = vec4(lmcoord, 0.0, 0.0);
    gl_FragData[3] = vec4(glcolor.rgb, 1.0);
}
