#version 430 compatibility
/* VertaLux - LPV STAGE 2, FLOOD pass 2/4 (step 4).  PING-PONG: B(lightImgB) -> A(lightImg).
   Gate: EMISSIVE_LPV=0 OR LPV_PASSES<2 -> copy B->A (parity no-op).
   CL_V3=1: dead code, compiled out entirely (see composite_a.csh header). */
#include "/lib/settings.glsl"
#include "/lib/common.glsl"

layout(local_size_x = 8, local_size_y = 8, local_size_z = 8) in;
const ivec3 workGroups = ivec3(16, 16, 16);

layout(rgba16f) uniform image3D lightImg;     // A
layout(rgba16f) uniform image3D lightImgB;    // B

#define LPVF_SRC  lightImgB                     // reads B
#define LPVF_DST  lightImg                      // writes A
#define LPVF_STEP 4
#include "/lib/lpv_flood.glsl"

void main() {
#if EMISSIVE_LPV == 0
    return; // LPV chain disabled -> no work at all
#endif
    ivec3 c = ivec3(gl_GlobalInvocationID);
    if (any(greaterThanEqual(c, ivec3(LPVF_RES)))) return;
#if EMISSIVE_LPV == 1 && CL_V3 == 0 && LPV_PASSES >= 2
    lpvFloodCell(c);    // B -> A, step 4
#elif EMISSIVE_LPV == 1 && CL_V3 == 0
    lpvCopyCell(c);     // parity: B -> A without propagating
#endif
}
