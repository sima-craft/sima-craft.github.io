#version 120
/*
    composite: screen-space GI (SSGI / RTGI / SS lights), RSM sun bounce, SSAO.
    Reads gbuffers (colortex0/1/2, depthtex0) and, for the RSM, the shadow map
    (shadowtex1 depth + shadowcolor0 banded albedo -- see the RSM block).
    Writes colortex4 (GI rgb, view depth in .a) and colortex6 (AO in .r,
    temporal history length / 64 in .g, smoothed relative GI sigma in .b --
    GI_DENOISE_V2 only, otherwise 0; composite1's a-trous rings read it).
    Both are smoothed by temporal accumulation (reprojection) whose weight is a
    running average driven by that history length.
    GI_HALF_RES 1: all of the above is computed in the lower-left quadrant
    only (1 quadrant texel = full-res pixel at uv*2, ~4x fewer shaded pixels);
    readers upsample (composite1 giUpsample). History follows the quadrant.
    VL_HALF_RES 1: the unified volumetric-light march (lib/vl_halfres.glsl)
    also runs here in the same quadrant, writing its two endpoint sets to
    colortex13/14; composite1's VL block upsamples and recombines them.
*/

#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/distort.glsl"
#include "/lib/biome.glsl"
#include "/lib/dimension.glsl"
#include "/lib/lighting.glsl"
#if defined VOLUMETRIC_LIGHT && VL_HALF_RES == 1
// Wave-caustic helpers for the underwater god-ray march (pure functions,
// v120-safe, no uniforms -- same include set as gbuffers_water).
// PHYSICS_FIELD_SYNC (lib/settings.glsl) : ce programme est le SECOND
// consommateur du champ republie par l'ocean de PHYSICS MOD PRO (via la marche
// demi-res de lib/vl_halfres.glsl) - voir composite1.fsh.
// PHYS_REAL : la carte de rides recopiee est lue DANS lib/water.glsl
// (vlxPhysRipRaw), donc son sampler doit etre declare AVANT l'include - meme
// condition que le VLX_PHYS_REAL de lib/water.glsl.
#if PHYSICS_MOD_SUPPORT == 1 && PHYSICS_FIELD_SYNC == 1 && PHYS_REAL == 1
uniform sampler2D physRippleSampler;
#if PHYS_REAL_V2 == 1
// PHYS_REAL_V2 : carte de waviness ancree monde (MIROIR de composite1.fsh).
uniform sampler2D physWavMapSampler;
#endif
#endif
#define VLX_PHYS_CONSUMER
#include "/lib/water.glsl"
#endif

// Temporal accumulation weight follows the active GI mode
#ifdef SSGI
#define GI_ACCUM_W SSGI_ACCUM
#else
#define GI_ACCUM_W RTGI_ACCUM
#endif

// PERF_RSM_INTERLEAVE (LOT B, B3, lib/settings.glsl): the RSM loop draws
// RSM_N samples per frame. At 1 that is HALF the Vogel sequence (even/odd
// indices, parity = frameCounter + pixel checkerboard -- see the loop);
// RSM_N is the divisor of the Monte-Carlo estimator AND of its variance
// stream, so both stay unbiased at 8 taps. At 0 this is token-identical to
// the previous divisor.
#if PERF_RSM_INTERLEAVE == 1
#define RSM_N (RSM_SAMPLES / 2)
#else
#define RSM_N RSM_SAMPLES
#endif

// === VL_HALF_RES buffers -- Iris directives parsed INSIDE the /* */ block.
//     DO NOT UNCOMMENT. colortex13 = (scatHi.rgb, transHi), colortex14 =
//     (scatLo.rgb, odUW), quadrant texels only (see lib/vl_halfres.glsl).
//     Clear=false: every texel is rewritten each frame (out-of-quadrant
//     fragments write the neutral pair) and composite1 reads the SAME frame.
//     NB: Iris's const scanner is line-by-line and may ignore this #if; that
//     is harmless -- with the gate off the buffers stay unreferenced (the
//     samplers and the RENDERTARGETS list are gated), so Iris skips their
//     allocation, same contract as the composite5 RTX buffer purge.
#if defined VOLUMETRIC_LIGHT && VL_HALF_RES == 1
/*
const int  colortex13Format = RGBA16F;
const int  colortex14Format = RGBA16F;
const bool colortex13Clear  = false;
const bool colortex14Clear  = false;
*/
#endif

uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform sampler2D colortex2;
uniform sampler2D colortex4;
#if GI_V3 == 1
// GI_V3 (multi-rebond) : colortex5 = albedo GAMMA (RGB8, ecrit par les
// gbuffers). La radiance SORTANTE indirecte d'un emetteur vaut
// toLinear(colortex5) * colortex4.rgb - exactement ce que composite1 applique
// ("color += gi * alb", alb = toLinear(colortex5)), donc les deux bouts de la
// chaine restent dans le meme espace et sur le meme albedo.
uniform sampler2D colortex5;
#endif
uniform sampler2D colortex6;
uniform sampler2D depthtex0;
uniform mat4 gbufferProjection;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferPreviousModelView;
uniform mat4 gbufferPreviousProjection;
uniform mat4 shadowModelViewInverse;
uniform mat4 shadowProjectionInverse;
uniform vec3 previousCameraPosition;
uniform float viewWidth;
uniform float viewHeight;
// Guarded: lib/lighting.glsl declares frameCounter under SHADOW_V2 with the
// same guard (a duplicate uniform is a GLSL error).
#ifndef VL_FRAMECOUNTER_DECL
#define VL_FRAMECOUNTER_DECL
uniform int frameCounter;
#endif
// --- VL_HALF_RES march inputs (consumed inside lib/vl_halfres.glsl only).
//     Declared OUT of the gate on purpose (standard uniforms, harmless when
//     the gate is off): no gated declaration can strand a later use. ---
uniform sampler2D depthtex1;
uniform float far;
uniform int isEyeInWater;
uniform ivec2 eyeBrightnessSmooth;
#if defined VOLUMETRIC_LIGHT && VL_HALF_RES == 1 && VLX_PHYS_SYNC == 1
// PHYSICS_FIELD_SYNC (lib/settings.glsl) : la marche VL demi-res lit le
// battement et les parametres de l'ocean PHYSICS MOD. Ce pass est en
// #version 120 : SEUL le sampler flottant 2x1 est lu (texture2D aux centres
// des deux texels), jamais l'estampille entiere plein ecran - elle demanderait
// un usampler2D et un texelFetch, tous deux 130+. C'est aussi inutile ici : un
// pas de marche est dans le VOLUME, jamais sur la surface.
// Gate identique a celui de l'include de lib/water.glsl plus bas : aucune
// declaration ne peut se retrouver orpheline de son usage.
uniform sampler2D physOceanParamsSampler;
#if VLX_PHYS_REAL == 1
uniform sampler2D physRipParamsSampler;
#endif
#ifndef VL_BIOMECAT_DECL
#define VL_BIOMECAT_DECL
uniform int biome_category;
#endif
#ifndef CAT_NONE
#define CAT_NONE 0
#endif
#ifndef CAT_BEACH
#define CAT_BEACH 9
#endif
#ifndef CAT_OCEAN
#define CAT_OCEAN 11
#endif
#ifndef CAT_RIVER
#define CAT_RIVER 13
#endif
#endif

varying vec2 uv;

vec3 toView(vec2 coord, float depth) {
    // TAAU: framebuffer UV [0..TAAU_S] -> visible screen [0..1] before NDC
    // (division folds away at compile time when TAAU_S = 1.0).
    vec4 ndc = vec4(coord / TAAU_S, depth, 1.0) * 2.0 - 1.0;
    vec4 v = gbufferProjectionInverse * ndc;
    return v.xyz / v.w;
}

#ifdef DISTANT_HORIZONS
// DH LOD depth bounds the VL_HALF_RES march tail (mirror of composite1).
uniform sampler2D dhDepthTex1;
uniform mat4 dhProjectionInverse;

vec3 toViewDH(vec2 coord, float depth) {
    // TAAU: same sub-rect -> visible screen remap as toView.
    vec4 ndc = vec4(coord / TAAU_S, depth, 1.0) * 2.0 - 1.0;
    vec4 v = dhProjectionInverse * ndc;
    return v.xyz / v.w;
}
#endif

#if defined VOLUMETRIC_LIGHT && VL_HALF_RES == 1
#include "/lib/vl_halfres.glsl"
#endif

void main() {
#if GI_HALF_RES == 1
    // Half-res sub-viewport: only the lower-left quadrant [0, 0.5*TAAU_S]^2
    // computes GI/AO. Each quadrant fragment shades the full-res pixel at 2x
    // its position, snapped to that pixel's exact center (no bilinear mixing
    // of depth/normals/flags); the gathers below still sample the FULL-res
    // gbuffers. Fragments outside the quadrant skip all work and write the
    // neutral defaults (gi = 0, ao = 1, depth 0) -- nothing reads colortex4/6
    // there (every reader samples at uv * 0.5) and the fragment stays alive
    // for other sub-viewport blocks sharing this pass.
    bool giQuad = uv.x < 0.5 * TAAU_S && uv.y < 0.5 * TAAU_S;
    vec2 uvG = giQuad ? (floor(gl_FragCoord.xy) * 2.0 + 0.5) / vec2(viewWidth, viewHeight)
                      : uv;
#else
    vec2 uvG = uv; // full-res passthrough (bit-identical legacy path)
#endif
    float d0 = texture2D(depthtex0, uvG).r;
    vec3 gi = vec3(0.0);
    float ao = 1.0;
    float curDepth = 0.0;
    // Temporal history length in frames, stored back in colortex6.g (see the
    // accumulation block at the bottom). 0 = no usable history for this texel.
    float histN = 0.0;
#ifdef VLX_DEN_ACTIVE
    // Smoothed RELATIVE sigma of the GI estimator, stored back in colortex6.b
    // (8 bits). It is the memory of the variance window (see the temporal
    // block): the INSTANTANEOUS sigma is correlated with the estimate itself
    // (an all-miss frame has sigma = 0 AND gi = 0), so the window takes the
    // max of both. 0 on sky/hand/out-of-quadrant texels, 1 on disocclusion.
    float vlxDenB = 0.0;
#endif

    // Held item / hand: MC & Iris squash its depth range near the camera
    // (hand d0 < ~0.56, world geometry always lands above). Every gather
    // below (SSGI/RTGI/RSM/SS lights/SSAO + temporal reprojection) would
    // sample the scene BEHIND the hand and composite1 would then paint that
    // bounce/AO over it -> "transparent hand". Skip: the hand keeps its pure
    // forward shading (gi = 0, ao = 1) and writes a zero history depth so
    // reprojected neighbours reject it instead of inheriting wall GI.
    bool isHand = d0 < 0.56;

#if GI_HALF_RES == 1
    // Out-of-quadrant fragments take the neutral write path below (early skip)
    if (giQuad && d0 < 1.0 && !isHand) {
#else
    if (d0 < 1.0 && !isHand) {
#endif
        vec3 viewPos = toView(uvG, d0);
        curDepth = -viewPos.z;
        vec3 normal = normalize(texture2D(colortex1, uvG).rgb * 2.0 - 1.0);
#ifdef VLX_DEN_ACTIVE
        // Variance of the per-frame GI estimator, folded stream by stream
        // (SSGI + RSM add their m2 - m1^2/n in quadrature: independent
        // dither streams). Feeds the temporal variance window below.
        float vlxDenVar = 0.0;
#endif
        // ---- Sample dither: TWO decorrelated streams ----
        // Every gather below is a Vogel disc: its quality is set by how well the
        // per-pixel ANGLE and the per-pixel RADIAL offset decorrelate from one
        // pixel to the next AND from one frame to the next (the temporal blend
        // at the bottom then averages them out).
        // BLUE_NOISE = 1 takes the same tileable 64^3 slice-per-frame source the
        // volumetric marches use: neighbouring pixels get DIFFERENT angles, so
        // the residual noise is high-frequency - which is exactly what the
        // bilateral upsample (composite1 giUpsample), the full-res 3x3 filter
        // and TAA can erase. The old Bayer8 rotation is spatially CORRELATED in
        // 8x8 blocks: its residue is blotchy, and no denoiser removes blotches.
        // 0 = the previous Bayer8 + golden-angle frame rotation, bit-identical.
#if BLUE_NOISE == 1
        float dith  = blueDither(gl_FragCoord.xy, frameCounter);
        float dithR = blueDither(gl_FragCoord.xy + vec2(37.0, 17.0), frameCounter);
#else
        float frame16 = float(frameCounter - (frameCounter / 16) * 16);
        float dith  = fract(bayer8(gl_FragCoord.xy) + frame16 * 0.618034);
        float dithR = fract(dith + hash12(gl_FragCoord.xy + 17.0));
#endif

        // ---- SSGI: single SUN bounce only ----
        // Contract: block lights stay strictly vanilla. Emissive pixels are
        // skipped and the torch share is subtracted from the source lightmap;
        // skylight is required, so GI fades out naturally in caves.
        #ifdef SSGI
        // WHOLE-PASS EARLY-OUT (cost only, result bit-identical). The per-sample
        // sunOnly factor carries smoothstep(-0.04, 0.10, sunHeight()), which is
        // a UNIFORM: at night it is exactly 0, every tap fell through to
        // "continue" AFTER paying its depth + normal + flag taps, and the block
        // returned exactly vec3(0). Hoisted here, SSGI now costs NOTHING between
        // dusk and dawn - about 3 x SSGI_SAMPLES texture fetches per pixel saved
        // on half the day, for zero visual change.
        float sunUpG = smoothstep(-0.04, 0.10, sunHeight());
#if GI_V3 == 1
        // GI_V3 : le rebond ne depend plus SEULEMENT du soleil (emetteurs +
        // part lumiere de bloc + reinjection multi-rebond), donc l'early-out de
        // nuit ci-dessus ne peut plus fermer la passe tout court. Il est reporte
        // sur le RECEPTEUR : la boucle ne s'ouvre la nuit / en grotte que si ce
        // pixel voit de la lumiere de bloc. UN tap colortex2 par pixel, et la
        // propriete "de nuit le SSGI coute ZERO" est conservee la ou elle est
        // vraie (nuit en plein champ, sans torche). Meme expression que la part
        // torche du gather (min(lm.x*1.5, 1)), voir lib/settings.glsl bloc GI_V3.
        // POURQUOI CETTE PORTE NE PERD RIEN : le lightmap de bloc vanilla vaut
        // 0 EXACTEMENT quand aucune source n'est a moins de 15 blocs de
        // propagation. Le gather, lui, porte a 16 blocs. Un pixel ferme par
        // cette porte n'a donc, au pire, qu'une coquille de 1 bloc d'emetteurs
        // potentiels - et ceux-la sont a plus de 15 blocs de propagation, donc
        // occultes. Le seuil 0.02 s'ouvre des le PREMIER cran du lightmap
        // (niveau 1 -> lm.x = 1/15 -> 0.1 apres le x1.5), il ne coupe donc
        // jamais un niveau non nul.
        float recvBL = min(texture2D(colortex2, uvG).r * 1.5, 1.0);
        if (sunUpG > 0.001 || recvBL > 0.02) {
#else
        if (sunUpG > 0.001) {
#endif
            // TAAU: screen radius expressed in the render sub-rect
            float screenR = clamp(VLX_GI3_R * gbufferProjection[1][1] / curDepth * 0.5, 0.03, 0.55) * TAAU_S;
            float aspect = viewHeight / viewWidth;
            vec3 ssgiAcc = vec3(0.0);
            // ---- Relative anti-firefly (see SSGI_FIREFLY_MAX, lib/settings.glsl).
            // Running mean of the taps ALREADY accepted by this pixel; the
            // absolute floor is scaled by the sun so a lone tap on a legitimately
            // sunlit surface is never clipped. Same idiom as the voxel GI clamp
            // in composite5. There was NO clamp here before this pass.
            vec3  fcSum  = vec3(0.0);
            float fcN    = 0.0;
            float fcFloor = 0.20 * luma(getLightColor()) + 0.02;
#if GI_V3 == 1
            // Le plancher ci-dessus est proportionnel au SOLEIL : ~0.02 la nuit
            // et en grotte, c'est-a-dire exactement la ou les emetteurs sont la
            // seule lumiere. Le premier tap emissif y etait ecrete a 0.02 et la
            // rampe de la moyenne courante ne redemarrait jamais. Plancher
            // additionnel (biais mesure -7 % sur une nappe de lave a 16 taps,
            // voir GI_EMISSIVE_FLOOR dans lib/settings.glsl) ; en plein jour il
            // est negligeable devant les ~1.4 du terme solaire.
            fcFloor += GI_EMISSIVE_FLOOR;
#endif
#ifdef VLX_DEN_ACTIVE
            // Sum of squared accepted-tap lumas (misses count as exact 0):
            // with fcSum this gives the stream's m2 - m1^2/n. Free ride on
            // the firefly bookkeeping, no extra texture tap.
            float fcM2   = 0.0;
#endif
            for (int i = 0; i < VLX_GI3_N; i++) {
                float t = (float(i) + dithR) / float(VLX_GI3_N);
                float ang = float(i) * 2.39996 + dith * 6.2831853;
                vec2 off = vec2(cos(ang) * aspect, sin(ang)) * sqrt(t) * screenR;
                vec2 suv = uvG + off;
#if GI_V3 == 1
                // ---- F4 : BORDS D'ECRAN, fondu et non coupure ----
                // Jeter l'echantillon qui sort du cadre est une COUPURE : le
                // gain 2.5/N suppose N echantillons disponibles, donc le GI
                // s'assombrit sur tout le pourtour de l'image, et d'autant plus
                // que le disque passe a 16 blocs. On le REPLIE par symetrie
                // dans le cadre : il retombe sur une surface voisine plausible,
                // et s'il n'est pas plausible (trop loin en MONDE, mauvaise
                // orientation) les tests ci-dessous le rejettent comme
                // n'importe quel autre. Deux abs par axe, aucune branche.
                // BORNE : |off| <= 0.55*TAAU_S, donc suv reste dans
                // [-0.55*S, 1.55*S] et les deux replis suffisent a le ramener
                // dans [0, S] sans jamais repasser negatif.
                suv = abs(suv);
                suv = vec2(TAAU_S) - abs(vec2(TAAU_S) - suv);
#else
                if (suv.x < 0.0 || suv.x > TAAU_S || suv.y < 0.0 || suv.y > TAAU_S) continue;
#endif

                float sd = texture2D(depthtex0, suv).r;
                if (sd >= 1.0) continue;                       // sky contributes via ambient
                vec3 np = toView(suv, sd);
                vec3 dvec = np - viewPos;
                float l2 = dot(dvec, dvec);
                if (l2 > VLX_GI3_R * VLX_GI3_R || l2 < 0.02) continue;

                vec3 ldir = dvec * inversesqrt(l2);
                float ndl = dot(normal, ldir);                // bounce must come from the front
                if (ndl <= 0.0) continue;

                vec3 nn = normalize(texture2D(colortex1, suv).rgb * 2.0 - 1.0);
                float face = clamp(dot(nn, -ldir), 0.0, 1.0);

                vec4 sData = texture2D(colortex2, suv);
#if GI_V3 == 1
                // ---- C : les EMETTEURS entrent dans le rebond ----
                // Bande colortex2.b 0.45-0.65 = emissif 0.50 / lave 0.58 /
                // portail (voir gbuffers_terrain.fsh). Avant : "continue".
                float emitM = (sData.b > 0.45 && sData.b < 0.65) ? 1.0 : 0.0;
#else
                if (sData.b > 0.45 && sData.b < 0.65) continue; // never gather emissives
#endif
                // Sun-only share of the source pixel: torch influence removed,
                // skylight required, gated to daytime (the daytime gate is the
                // hoisted sunUpG above - same product, same result).
                float sunOnly = clamp(1.0 - sData.r * 1.5, 0.0, 1.0) * smoothstep(0.15, 0.55, sData.g)
                              * sunUpG;
#if GI_V3 == 1
                // Part de la source qui compte. Un pixel EMISSIF est traite
                // SEULEMENT par son terme emissif : sinon la part "lumiere de
                // bloc" reprendrait aussi sa couleur HDR (son propre lightmap
                // vaut 1) et la doublerait sans plafond. Les deux branches sont
                // exclusives et sans plafond commun, par construction.
                // srcRaw sert de porte AVANT le tap colortex0 ET avant les deux
                // taps de reinjection : il ne depend que de sData, deja lu.
                // APPROXIMATION ASSUMEE : un echantillon rejete ici ne reinjecte
                // pas son GI accumule non plus, alors qu'il pourrait en avoir.
                // C'est ce qui garde le cout borne, et c'est presque toujours
                // vrai : le lightmap torche vanilla se propage DANS L'AIR, donc
                // toute surface d'une zone eclairee a la torche a lm.x > 0, et
                // de jour a ciel ouvert sunOnly > 0. Le cas perdu est la surface
                // strictement noire au lightmap qui ne recoit QUE du rebond -
                // et son rebond a elle est deja proche de zero.
                float srcRaw = (emitM > 0.5) ? GI_EMISSIVE_GAIN
                                             : (sunOnly + GI_BLOCKLIGHT_GAIN * min(sData.r * 1.5, 1.0));
                if (srcRaw <= 0.001) continue;
#else
                if (sunOnly <= 0.01) continue;
#endif

                vec3 bcol = texture2D(colortex0, suv).rgb;
                // Falloff normalized by radius: weight is ~1/9 at l2 = R*R
                // whatever radius is chosen.
#if GI_V3 == 1
                // Poids PUREMENT GEOMETRIQUE : la part de source (srcW) est
                // maintenant un terme separe, parce qu'elle ne s'applique plus
                // au meme facteur pour le direct, l'emissif et le rebond
                // reinjecte. Le produit final wG * (bcol*srcW) reproduit
                // exactement l'expression d'origine quand srcW = sunOnly.
                // ---- F3 : FUITES, garde sur la PORTEE AJOUTEE seulement ----
                // Le plancher 0.30 du terme d'orientation laisse un emetteur qui
                // TOURNE LE DOS au recepteur contribuer quand meme a 30 % : c'est
                // le canal de fuite d'un GI ecran (une piece voisine vue par la
                // camera, mais separee du recepteur par un mur). Un ecran n'a
                // aucun test de visibilite recepteur -> emetteur, la seule
                // defense est l'orientation. Tant que le gather ne depassait pas
                // ~9.5 blocs le probleme restait borne ; a 16 blocs il ne l'est
                // plus. Le plancher est donc RESSERRE avec la distance, et
                // UNIQUEMENT sur la couronne que cette passe ajoute : sous
                // l2/R^2 = 0.35 (soit 9.5 blocs a R = 16) la formule est
                // EXACTEMENT celle d'avant (0.30 + 0.70*face), au-dela elle
                // exige un vrai face-a-face (plancher 0.30 -> 0.05 a 16 blocs).
                // Aucune regression possible sur le rendu de proximite, qui est
                // celui que le createur regarde ; le cout est un smoothstep.
                float fFloor = mix(0.30, 0.05,
                                   smoothstep(0.35, 1.0, l2 / (VLX_GI3_R * VLX_GI3_R)));
                float wG = ndl * (fFloor + (1.0 - fFloor) * face) / (1.0 + l2 * (8.0 / (VLX_GI3_R * VLX_GI3_R)));
                // Plafond ABSOLU de la radiance emissive (colortex0 y porte
                // EMISSIVE_BOOST) - voir GI_EMISSIVE_MAX, lib/settings.glsl.
                float srcW = (emitM > 0.5)
                           ? (GI_EMISSIVE_GAIN * min(1.0, GI_EMISSIVE_MAX / max(luma(bcol), 1e-3)))
                           : srcRaw;
#else
                float w = ndl * (0.30 + 0.70 * face) / (1.0 + l2 * (8.0 / (SSGI_RADIUS * SSGI_RADIUS))) * sunOnly;
#endif
                // saturate the bounce so color bleeding reads clearly
                bcol = max(mix(vec3(luma(bcol)), bcol, 1.6), vec3(0.0));
#if GI_V3 == 1
                vec3 rad = bcol * srcW;
                // ---- A : REINJECTION = MULTI-REBOND ----
                // Radiance SORTANTE indirecte de l'emetteur, telle que
                // composite1 la peindra : albedo * gi accumule. colortex4 est
                // relu ici a l'image N-1 (cette passe l'ecrit en fin de main(),
                // Clear = false) - meme classe d'acces que la reprojection
                // temporelle plus bas, qui lit deja colortex4 pendant qu'elle
                // l'ecrit. La saturation x1.6 n'est PAS re-appliquee : le gi
                // accumule l'a deja subie a l'image precedente.
#if GI_HALF_RES == 1
                // L'historique vit dans le quadrant bas-gauche : meme recentrage
                // (+0.25 texel) et meme borne interieure que puvH plus bas.
                vec2 ghUV = min(suv * 0.5 + 0.25 / vec2(viewWidth, viewHeight),
                                0.5 * TAAU_S - 1.5 / vec2(viewWidth, viewHeight));
#else
                vec2 ghUV = suv;
#endif
                vec4 gh = texture2D(colortex4, ghUV);
                // DESOCCLUSION : .a = profondeur lineaire ecrite a l'image
                // precedente A CETTE POSITION ECRAN. Meme tolerance relative
                // que la reprojection temporelle. Sans ce test on reinjecte le
                // rebond d'une geometrie qui n'est plus la.
                float zSmp = -np.z;
                if (abs(gh.a - zSmp) < 0.1 * zSmp + 0.5) {
                    vec3 rj = toLinear(texture2D(colortex5, suv).rgb) * gh.rgb;
                    // Soupape anti-emballement (GI_REINJECT_MAX) : la serie est
                    // deja bornee geometriquement par l'albedo (s*rho <= 0.45),
                    // ce plafond ne protege que du cas pathologique HDR.
                    rad += rj * min(1.0, GI_REINJECT_MAX / max(luma(rj), 1e-4));
                }
                vec3 contrib = rad * wG;
#else
                vec3 contrib = bcol * w;
#endif
                float capH = SSGI_FIREFLY_MAX * ((fcN > 0.5) ? luma(fcSum) / fcN : 0.0) + fcFloor;
                float lh   = luma(contrib);
                if (lh > capH) contrib *= capH / max(lh, 1e-4);
                fcSum += contrib;
                fcN   += 1.0;
#ifdef VLX_DEN_ACTIVE
                // post-clamp luma is exactly min(lh, capH)
                fcM2  += min(lh, capH) * min(lh, capH);
#endif
                ssgiAcc += contrib;
            }
            // gain calibrated for the wide falloff above
            gi += ssgiAcc * (2.5 / float(VLX_GI3_N) * VLX_GI3_SS);
#ifdef VLX_DEN_ACTIVE
            {
                // Variance of the pixel SUM: m2 - m1^2/n over ALL taps (the
                // "continue" misses are legitimate zeros of the estimator),
                // scaled by the square of the block gain applied to gi above.
                float gS  = 2.5 / float(VLX_GI3_N) * VLX_GI3_SS;
                float m1S = luma(fcSum);
                vlxDenVar += max(fcM2 - m1S * m1S / float(VLX_GI3_N), 0.0) * gS * gS;
            }
#endif
        }
        #endif

        // ---- RTGI (legacy): one indirect bounce from the lit scene ----
        // Each surface gathers real light from nearby lit surfaces
        // (colortex0 = already-lit scene): color bleeding, bounced sun and
        // torch light, tinted light through stained glass.
        #if defined RTGI && !defined SSGI
        {
            // TAAU: screen radius expressed in the render sub-rect
            float screenR = clamp(RTGI_RADIUS * gbufferProjection[1][1] / curDepth * 0.5, 0.03, 0.55) * TAAU_S;
            float aspect = viewHeight / viewWidth;
            // dithR is now hoisted to the top of main() (shared with SSGI/RSM);
            // the local redeclaration that used to sit here would only shadow it.
            for (int i = 0; i < GI_SAMPLES; i++) {
                float t = (float(i) + dithR) / float(GI_SAMPLES);
                float ang = float(i) * 2.39996 + dith * 6.2831853;
                vec2 off = vec2(cos(ang) * aspect, sin(ang)) * sqrt(t) * screenR;
                vec2 suv = uvG + off;
                if (suv.x < 0.0 || suv.x > TAAU_S || suv.y < 0.0 || suv.y > TAAU_S) continue;

                float sd = texture2D(depthtex0, suv).r;
                if (sd >= 1.0) continue;                       // sky contributes via ambient
                vec3 np = toView(suv, sd);
                vec3 dvec = np - viewPos;
                float l2 = dot(dvec, dvec);
                if (l2 > RTGI_RADIUS * RTGI_RADIUS || l2 < 0.02) continue;

                vec3 ldir = dvec * inversesqrt(l2);
                float ndl = dot(normal, ldir);                // bounce must come from the front
                if (ndl <= 0.0) continue;

                // emitter must face the receiver
                vec3 nn = normalize(texture2D(colortex1, suv).rgb * 2.0 - 1.0);
                float face = clamp(dot(nn, -ldir), 0.0, 1.0);

                vec3 bcol = texture2D(colortex0, suv).rgb;
                // emissive sources (flag 0.5 in colortex2.b) are boosted
                float flagE = texture2D(colortex2, suv).b;
                float emit = (flagE > 0.45 && flagE < 0.65) ? 5.0 : 1.0;
                float w = ndl * (0.30 + 0.70 * face) / (1.0 + l2 * 1.2) * emit;
                // saturate the bounce so color bleeding reads clearly
                bcol = max(mix(vec3(luma(bcol)), bcol, 1.7), vec3(0.0));
                gi += bcol * w;
            }
            gi *= 7.0 / float(GI_SAMPLES) * RTGI_STRENGTH;
        }
        #endif

        // ---- RSM: off-screen sun bounce (Reflective Shadow Map) ----
        // The shadow map is a shadowDistance-wide orthographic view FROM THE SUN
        // and holds, per texel, the surface CLOSEST TO THE LIGHT - i.e. a lit
        // surface. Each texel becomes a small secondary light (a VPL), so colour
        // bleeds in from geometry the camera cannot see. This is the only path
        // in the pack that does that; SSGI can only bounce what is on screen.
        //
        // WHAT "OFF-SCREEN" ACTUALLY MEANS HERE (limit, stated because the three
        // comments this replaces overstated it). shaders.properties sets
        // shadow.culling = true, and its own doc says light-aware culling only
        // keeps the sections that can cast INTO the view frustum. The shadow map
        // is therefore NOT a 360 deg disc around the player: what it holds is
        // the view frustum EXTRUDED TOWARDS THE SUN. So the RSM does bring back
        // the sunlit cliff just off the edge of the screen and the wall behind
        // the player WHEN THEY LIE ON THE SUN SIDE, and it does not when they do
        // not - and what lies on the sun side changes as the camera turns, so
        // some bounce can pop on a camera rotation (the same behaviour the
        // Nether lava height map is already documented to have). The 12-frame
        // temporal accumulation smears such a pop into a short trail rather than
        // removing it. shadow.culling = reversed (already offered for the Nether
        // in shaders.properties) trades frame time for a stable 360 deg map.
        //
        // WHAT shadowcolor0 REALLY CONTAINS (checked, not assumed - the pack has
        // been burned by exactly this before). It is NOT a plain albedo:
        // shadow.fsh packs a 3-state MATERIAL TAG into disjoint RGB bands,
        // colour compressed x0.30 -> WATER [0.00..0.30], GLASS/PORTAL
        // [0.35..0.65], SOLID [0.70..1.00], alpha forced to 1.0 so the write
        // survives the Iris shadow-pass alpha blend. The decode below
        // ((rgb - 0.70) / 0.30, gated by SHADOW_TEX1_GATE_FIX exactly like every
        // other reader) is therefore MANDATORY and is already correct: without
        // it a mid-grey stone (0.5 albedo -> 0.85 stored) would bounce as near
        // WHITE. Water and glass texels decode negative, clamp to 0 and are
        // dropped by the luma test - intended (they are not diffuse bouncers).
        // The shadowcolor0 CLEAR is white = the top of the SOLID band, so a texel
        // with depth but no colour write decodes to white; harmless, because a
        // texel with no geometry has shadowtex1 = 1.0 and lands past RSM_RADIUS.
        // NETHER: shadowcolor0 holds the hot-emitter tint of the lava HEIGHT MAP
        // instead (DIMENSION_FX, end of shadow.fsh) - raw, unbanded, so decoding
        // it as an albedo WOULD be wrong. It never happens: the receiver skylight
        // gate below is 0 everywhere in the Nether (no sky lightmap), and it is
        // now an early-out, so not a single tap is taken there.
        #ifdef VLX_RSM_ACTIVE
        {
            // ---- Pre-gates, ALL hoisted out of the loop ----
            // (a) RECEIVER SKYLIGHT. Same value as before, but it used to be
            //     applied AFTER the loop: an indoor pixel paid RSM_SAMPLES x 2-4
            //     shadow taps just to be multiplied by 0. It is what keeps the
            //     RSM from leaking through walls and ceilings (there is no
            //     receiver->VPL visibility test; a shadow map cannot give one).
            // (b) SUN HEIGHT. Iris swaps shadowLightPosition to the MOON at
            //     night and the shadow map follows, so without this gate the RSM
            //     bounced moonlight: dim, and far noisier than it is worth. SSGI
            //     is gated by the same expression.
            // (c) DISTANCE. See RSM_FADE_NEAR/FAR in lib/settings.glsl.
            //     RSM_V2 (lib/settings.glsl, section G): (a)'s two knees move
            //     0.05/0.40 -> 0.12/0.50 WITH the x2 gain, so the one channel
            //     through which this block can leak light through a wall - a
            //     receiver with partial sky, gated by nothing else because a
            //     shadow map cannot give a receiver->VPL visibility test - comes
            //     out DARKER than it is today at skylight 0.2 instead of twice as
            //     bright. Everything at skylight >= 0.50, i.e. every open-sky
            //     surface, takes the full gain. Same instruction, two constants.
            float rGate = smoothstep(VLX_RSM_SKY_LO, VLX_RSM_SKY_HI, texture2D(colortex2, uvG).g)
                        * smoothstep(-0.04, 0.10, sunHeight())
                        * (1.0 - smoothstep(RSM_FADE_NEAR, RSM_FADE_FAR, curDepth));
#if defined VOLUMETRIC_CLOUDS && defined VC_GROUND_SHADOWS
            // (d) CLOUD SHADOW, at the RECEIVER. The direct term multiplies by
            //     cloudShadow (shadeSurface, lib/lighting.glsl) but the RSM
            //     emitters did not: the ground darkened under a passing cumulus
            //     while its bounce stayed at full strength (rain WAS handled -
            //     getLightColor carries rainStrength - only the cast cloud
            //     shadow was missing). One evaluation, hoisted: a good
            //     approximation as long as RSM_RADIUS stays small against the
            //     size of a cloud. Placed BEFORE the early-out below, so a
            //     receiver under a dense cloud skips the whole loop too.
            //     PERF_CSHADOW_CHEAP: this gate is a SECONDARY consumer (it
            //     weights a bounce that is then blurred + temporally filtered)
            //     so it goes through cloudShadowCheap (5-tap field,
            //     lib/lighting.glsl; pure pass-through at 0) - the direct
            //     term in shadeSurface keeps the full field.
            if (rGate > 0.002) {
                vec3 wpR = (gbufferModelViewInverse * vec4(viewPos, 1.0)).xyz + cameraPosition;
                vec3 lDirWR = normalize(mat3(gbufferModelViewInverse) * shadowLightPosition);
                rGate *= cloudShadowCheap(wpR, lDirWR);
            }
#endif
            if (rGate > 0.002) {
            vec3 wrel = (gbufferModelViewInverse * vec4(viewPos, 1.0)).xyz;
            vec3 wnormal = mat3(gbufferModelViewInverse) * normal;
            // undistorted shadow clip position of the fragment
            vec4 sc = shadowProjection * (shadowModelView * vec4(wrel, 1.0));
            vec2 baseClip = sc.xy;
            // VLX_RSM_R = max(RSM_RADIUS, RSM_REACH) at GI_QUALITY >= 2 under
            // RSM_V2, an exact alias of RSM_RADIUS otherwise (lib/settings.glsl,
            // section D). Same idiom as VLX_GI3_R for the screen gather: the
            // slider still dials UP, it just cannot sit below the 16-block reach
            // on the tiers where the axis turns this block on.
            float radClip = VLX_RSM_R / shadowDistance;
            float rad2 = VLX_RSM_R * VLX_RSM_R;
            // clip-space baseline of the sender-normal finite difference, sized
            // so it spans ~4 DISTORTED texels whatever the distortion is:
            // d(uv) = d(clip) / (2 * fdist), so d(clip) = 8 * fdist / resolution.
            float texClip = 8.0 / float(shadowMapResolution);
            // clip -> shadow-view is DIAGONAL (the shadow projection is
            // orthographic; lib/lighting.glsl already relies on that when it
            // reads shadowProjection[2].z on its own).
            float pia = shadowProjectionInverse[0][0];
            float pib = shadowProjectionInverse[1][1];
            float pic = shadowProjectionInverse[2][2];
            // shadow clip -> camera-relative world, folded into ONE matrix
            // instead of two mat4 products per sample (exact, both are uniform).
            mat4 sClipToWorld = shadowModelViewInverse * shadowProjectionInverse;
#ifdef SSGI
            // Screen reach of the SSGI gather for THIS pixel, hoisted: the
            // anti-double-count test below may only reject a VPL that the SSGI
            // block could actually have picked up. See that test for why.
            // VLX_GI3_R et non SSGI_RADIUS : le test ne doit rejeter que ce que
            // le gather SSGI a REELLEMENT pu ramasser, donc il doit suivre la
            // portee effective (16 blocs sous GI_V3). Sinon la couronne 12-16
            // blocs serait comptee DEUX fois.
            float ssgiR2 = VLX_GI3_R * VLX_GI3_R;
            float ssgiScreenR = clamp(VLX_GI3_R * gbufferProjection[1][1] / curDepth * 0.5, 0.03, 0.55) * TAAU_S;
            float ssgiAsp = viewHeight / viewWidth;
#endif

#if RSM_V2 == 1
            // ---- RSM_V2: IMPORTANCE SAMPLING OF THE 1/(l2+0.5) KERNEL ----
            // The loop below used to draw the radius UNIFORMLY IN AREA
            // (r = R*sqrt(t)) while the kernel it evaluates concentrates the
            // energy at the centre. That mismatch is the whole reason widening
            // this gather was refused: the estimator's variance carries the
            // domain area, Var = (pi R^2 / N) * integral(f^2) - integral(f)^2/N,
            // and integral(f^2) of a 1/l^2 kernel is dominated by the NEAR field,
            // so sigma grows like R while the mean only grows like ln(R^2).
            // Drawing the radius with the KERNEL'S OWN density p(r) ~ 1/(r^2+c)
            // and dividing by it removes that factor. Closed-form inverse CDF:
            //     r^2 = c * (Q^t - 1),  Q = 1 + R^2/c   ->   exp2(t * log2 Q)
            //     weight 1/p = pi * ln(Q) * (r^2 + c)
            // The pi*ln(Q) half is constant and folds into the gain below; the
            // (r^2 + c) half is per-sample and multiplies contrib. SAME
            // integrand, SAME domain, therefore SAME MEAN - checked to 0.05 %
            // against a 400k-point quadrature (rsmv2_sim.py). Only the variance
            // moves, and it is what pays for RSM_PRESENCE and RSM_REACH.
            // c: per-tier (VLX_RSM_C, lib/settings.glsl section C), clamped to
            // R^2/4 so a player who dials RSM_RADIUS down to 2 blocks does not
            // end up with a density so flat the whole scheme stops helping.
            float rsmC    = max(0.5, min(VLX_RSM_C, rad2 * 0.25));
            float rsmLogQ = log2(1.0 + rad2 / rsmC);   // = log2 Q
            // clip-space scale of a WORLD radius: radClip is R/shadowDistance
            // and the draw above already returns BLOCKS (it ends at r = R by
            // construction), so the R has to be divided back out - hoisted here
            // rather than paid per sample. Same reason radClip stays in use at
            // RSM_V2 = 1: this is exactly radClip/R = 1/shadowDistance.
            float rsmScale = radClip * inversesqrt(rad2);
            float rsmGain = 3.14159265 * (rsmLogQ * 0.69314718) / float(RSM_N);
            // Absolute floor of the anti-firefly clamp, hoisted (it was
            // recomputed per sample). It has to follow the SCALE of contrib, and
            // under importance sampling that scale is ~c, not ~1/R^2: contrib
            // carries the weight (r^2+c), so a floor left constant clipped a
            // third of the energy at 1 block on the tiers whose c is large.
            // See lib/settings.glsl, section F.
            float rsmFloor = RSM_FIREFLY_FLOOR * (VLX_RSM_FF * rsmC);
#else
            float rsmGain = 3.14159265 * rad2 / float(RSM_N);
            float rsmFloor = RSM_FIREFLY_FLOOR * VLX_RSM_FF;
#endif
            vec3 rsm = vec3(0.0);
            vec3  fcSum = vec3(0.0);   // relative anti-firefly, see RSM_FIREFLY_MAX
            float fcN   = 0.0;
#ifdef VLX_DEN_ACTIVE
            float fcM2  = 0.0;         // sum of squared post-clamp lumas (sigma stream)
#endif
#if PERF_RSM_INTERLEAVE == 1
            // Interleave parity = frame + pixel CHECKERBOARD (quadrant texels:
            // gl_FragCoord steps 1 per half-res texel, so neighbours are in
            // antiphase and the upsample/3x3/TAA cancel the even/odd stratum
            // difference SPATIALLY -- the centre stratum of the 1/(l2+0.5)
            // kernel belongs to one half only, a frame-only parity would make
            // the whole image breathe by ~0.8% at half framerate; measured in
            // b3_model2.py, doc at the LOT B block of lib/settings.glsl).
            // Integer parity without %% (GLSL 120, same idiom as frame16 above).
            int rsmIx = int(gl_FragCoord.x) + int(gl_FragCoord.y) + frameCounter;
            int rsmPar = rsmIx - (rsmIx / 2) * 2;
#endif
            for (int i = 0; i < RSM_N; i++) {
                // Radius and angle now come from DIFFERENT noise streams. Before,
                // both were driven by the same `dith`, so the whole disc was one
                // spiral rigidly rotated and radially shifted: neighbouring
                // pixels shared the same pattern and the residual noise came out
                // LOW frequency (blotches), which no denoiser removes.
#if PERF_RSM_INTERLEAVE == 1
                // B3: this frame draws the even-or-odd HALF of the Vogel
                // sequence. Angle AND radius follow the true index vi, so each
                // frame is still a full-radial-range Vogel spiral (stride-2
                // golden angle stays equidistributed) -- NOT an inner/outer
                // half, which would alternate brightness.
                int vi = i * 2 + rsmPar;
                float t = (float(vi) + dithR) / float(RSM_SAMPLES);
                float ang = float(vi) * 2.39996 + dith * 6.2831853;
#else
                float t = (float(i) + dithR) / float(RSM_SAMPLES);
                float ang = float(i) * 2.39996 + dith * 6.2831853;
#endif
#if RSM_V2 == 1
                // Inverse CDF of p(r) ~ 1/(r^2+c) over the disc (see the setup
                // block above). t is the SAME stratified + dithered Vogel
                // parameter as before, so the stratification, the golden-angle
                // spread and the B3 even/odd interleave are all untouched -- only
                // the radial MAPPING changes. At t -> 1 this returns exactly
                // r^2 = R^2, so the disc still ends where it ended.
                float rp2 = rsmC * (exp2(t * rsmLogQ) - 1.0);
                float wIS = rp2 + rsmC;                 // 1/p, constant part folded in rsmGain
                vec2 soff = vec2(cos(ang), sin(ang)) * (sqrt(rp2) * rsmScale);
#else
                vec2 soff = vec2(cos(ang), sin(ang)) * sqrt(t) * radClip;
#endif
                vec2 sclip = baseClip + soff;

                // distorted read position (texel density near the player)
                float fdist = getDistortFactor(sclip);
                vec2 ruv = (sclip / fdist) * 0.5 + 0.5;
                if (ruv.x <= 0.0 || ruv.x >= 1.0 || ruv.y <= 0.0 || ruv.y >= 1.0) continue;

                // reconstruct the VPL world position from the shadow depth
                float sd = texture2D(shadowtex1, ruv).r;
                float clipz = (sd * 2.0 - 1.0) / VLX_SHADOW_ZSCALE; // inverse of the distortShadow Z packing
                vec4 vplW = sClipToWorld * vec4(sclip, clipz, 1.0);
                vec3 vpl = vplW.xyz / vplW.w;

                vec3 dvec = vpl - wrel;
                float l2 = dot(dvec, dvec);
                if (l2 < 0.05 || l2 > rad2) continue;
                vec3 dir = dvec * inversesqrt(l2);

                float recv = max(dot(wnormal, dir), 0.0);       // receiver must face the VPL
                if (recv <= 0.0) continue;

                // sunlit surface albedo gives the bounce color
                vec3 valb = texture2D(shadowcolor0, ruv).rgb;
#if SHADOW_TEX1_GATE_FIX == 1
                // Opaque texels are encoded in the SOLID band [0.70..1.00]
                // (see shadow.fsh) -> decode the albedo before bouncing.
                valb = clamp((valb - 0.70) / 0.30, 0.0, 1.0);
#endif
                // ---- COLOUR SPACE (fixed by this pass). shadow.fsh writes the
                // RAW sRGB bytes of the atlas (col = texture2D(gtexture, uv) *
                // glcolor, then banded x0.30 + tag), so what the decode above
                // returns is a GAMMA value. Everything from here to the tonemap
                // in composite5 is LINEAR HDR, and every OTHER reader of that
                // same atlas data linearises it: gbuffers_terrain.fsh
                // (albedo = toLinear(col.rgb)) and composite1.fsh
                // (alb = toLinear(colortex5)). Skipping it here injected a wrong
                // colour into 100 % of the RSM taps: mid stone decoded 0.503
                // where its true linear albedo is 0.211 (x2.4 too bright), grass
                // x2.8..x6.8 depending on the channel - and gamma COMPRESSES the
                // ratio between channels, so grass bounced yellow-green (V/R
                // 1.31) instead of saturated green (V/R 1.78). It also left the
                // two GI paths in two different spaces: SSGI reads colortex0,
                // which is already linear. Placed OUTSIDE the gate so the
                // SHADOW_TEX1_GATE_FIX == 0 fallback (shadow.fsh writes raw
                // col.rgb there, unbanded but just as sRGB) is linearised too.
                valb = toLinear(valb);
                // skip near-black texels (deep shadow): do not dilute the bounce.
                // Threshold moved WITH the space - toLinear(0.04) = 0.00089 - so
                // exactly the same set of texels is rejected as before.
                if (luma(valb) < 0.00089) continue;

                // ---- SENDER cosines, from the shadow depth ----
                // MISSING BEFORE THIS PASS, and it is why the RSM read as a flat
                // ambient wash rather than as bounced light: a shadow texel
                // emitted equally in every direction, and a wall whose back is
                // turned to the sun (back faces ARE rasterised into the shadow
                // map) emitted as brightly as sunlit ground. Two extra
                // shadowtex1 taps - paid ONLY by samples that already passed
                // range, receiver orientation and albedo - reconstruct the
                // emitter's NORMAL, from which:
                //   cosSend = how much the VPL faces the RECEIVER. This is the
                //             one that WEIGHTS the sample.
                //   cosSun  = how much the VPL faces the LIGHT. NOT a weight
                //             (it cancels, see the normalisation block at the
                //             end); it is the REJECT, and the only one possible:
                //             a height field cannot tell a front face from a
                //             back face any other way.
                // The difference is taken in CLIP space (offset, then re-distort)
                // because the distortion is not cheaply invertible in uv space.
                // A depth buffer is a height field over the light plane, so the
                // reconstructed normal always lies in the light hemisphere and
                // cosSun is EXACTLY the z of that normal in light space - no sun
                // vector needed. At a silhouette the two taps straddle two
                // surfaces and the normal tips toward the horizon, which is why
                // the reject threshold sits at 0.15 rather than at 0: an edge
                // texel's "normal" describes the depth step, not the surface.
                // COST, and the BUG THIS FIXES: the neighbours used to reuse the
                // CENTRE's distortion factor (uv = c * 0.5/fdist + 0.5) to save
                // two pow(). That is NOT a 0.2 % error. The distortion is
                // u(x) = x * 0.5 / f(x) with f = 0.85*d + 0.15, whose derivative
                // is (0.5/f) * (1 - x*f'/f), not 0.5/f: reusing the centre's
                // factor lands the read at the right NUMBER of texels but the
                // clip-space step it really represents is eClip / (1 - x*f'/f),
                // so the finite-difference BASE was under-estimated by that same
                // factor - x1.44 at 20 blocks, x2.33 at 60, x3.48 at
                // RSM_FADE_FAR with shadowDistance 256. The reconstructed slope
                // came out that much too steep, tipping the normal toward the
                // horizon: flat ground under a 45 deg sun reported cosSun 0.57
                // instead of 0.707 near the player and 0.28 far away, i.e. an
                // extra ~x2.5 darkening on top of the intended RSM_FADE, and -
                // because f depends on where the RECEIVER sits in the shadow map
                // - the bounce off a STATIC floor drifted as the player walked.
                // Fixed by reading at the TRUE distorted uv of each neighbour,
                // which makes the base exactly eClip. Two extra getDistortFactor
                // per surviving sample (two pow on the legacy curve, two Cardano
                // solves under SHADOW_LOD_V2 -- accounted in the SHADOW LOD
                // block of lib/settings.glsl); correctness over the saving.
                float eClip = texClip * fdist;
                vec2 cu = sclip + vec2(eClip, 0.0);
                vec2 cv = sclip + vec2(0.0, eClip);
                vec2 uvu = (cu / getDistortFactor(cu)) * 0.5 + 0.5;
                vec2 uvv = (cv / getDistortFactor(cv)) * 0.5 + 0.5;
                // Both neighbours must land INSIDE the map. Only the centre was
                // bounds-tested; a sample one texel from the edge read the
                // clamped border texel, giving an arbitrary difference and a
                // false normal exactly on the outer ring of the shadow map -
                // the distant receivers, already the worst case above.
                if (uvu.x <= 0.0 || uvu.x >= 1.0 || uvu.y <= 0.0 || uvu.y >= 1.0 ||
                    uvv.x <= 0.0 || uvv.x >= 1.0 || uvv.y <= 0.0 || uvv.y >= 1.0) continue;
                float zu = (texture2D(shadowtex1, uvu).r * 2.0 - 1.0) / VLX_SHADOW_ZSCALE;
                float zv = (texture2D(shadowtex1, uvv).r * 2.0 - 1.0) / VLX_SHADOW_ZSCALE;
                // tangents Tu = (pia*e, 0, pic*dzu), Tv = (0, pib*e, pic*dzv)
                vec3 nRaw = vec3(-pib * pic * (zu - clipz) * eClip,
                                 -pia * pic * eClip * (zv - clipz),
                                  pia * pib * eClip * eClip);
                // A height field over the light plane can only face the light.
                // The z sign already comes out positive with Iris' orthographic
                // shadow projection (pia and pib are both +shadowDistance); this
                // flip makes the block independent of that handedness instead of
                // silently returning cosSun = 0 everywhere if it ever changed.
                if (nRaw.z < 0.0) nRaw = -nRaw;
                vec3 nS = normalize(nRaw);
                // BACK-FACE / SILHOUETTE REJECT. cosSun is no longer a WEIGHT
                // (see the normalisation block at the end for why it cancels),
                // it is the only thing that can reject a texel whose surface is
                // edge-on or turned away from the sun: a height field over the
                // light plane cannot distinguish front from back, so nothing
                // else in this loop can. 0.15 = ~81 deg, i.e. drop the grazing
                // and silhouette texels whose reconstructed normal is dominated
                // by the depth discontinuity rather than by the surface.
                float cosSun = nS.z;
                if (cosSun <= 0.15) continue;
                vec3 nW = mat3(shadowModelViewInverse) * nS;
                float cosSend = max(-dot(nW, dir), 0.0);        // VPL must face the receiver
                if (cosSend <= 0.0) continue;

#ifdef SSGI
                // ---- ENERGY: never count a bounce twice ----
                // This VPL may ALSO be visible on screen, where the SSGI block
                // above already gathered it. Counting it in both places
                // brightens exactly the surfaces facing the camera - the ones
                // the player judges the exposure on - and it is the one real
                // double-count in the chain once both switches are on together
                // (which is what GI_QUALITY >= 2 now does). Reproject the VPL
                // into the current frame; if the g-buffer agrees it IS the
                // visible surface there, drop it. What survives is what SSGI
                // cannot see but the shadow map still holds: geometry off the
                // sides, hidden behind something else, or behind the camera WHEN
                // IT LIES ON THE SUN SIDE (shadow.culling = true keeps only what
                // can cast into the frustum - see the header of this block).
                // One depth tap.
                // mat3(gbufferModelViewInverse) is a pure rotation, so its
                // inverse is its transpose: (v * M) == transpose(M) * v.
                //
                // BOUNDED BY THE SSGI REACH (fixed by this pass). Being visible
                // on screen is NOT enough: the SSGI gather is a disc of
                // SSGI_RADIUS blocks projected to screen and CLAMPED to 0.55 of
                // the frame, so at fov 60 anything closer than ~9.4 blocks to
                // the camera has its gather cut short - the SSGI never reached
                // those 12 blocks, yet the RSM was dropping them anyway. Same
                // for a VPL beyond SSGI_RADIUS, which is unbounded as soon as
                // the player raises RSM_RADIUS (up to 128) above SSGI_RADIUS:
                // the WHOLE visible scene then vanished from both paths. Reject
                // only what the SSGI could really have gathered: within its
                // world radius AND inside its screen disc (the SSGI offset
                // scales x by the aspect, so the disc is an ellipse - undo it
                // before measuring). Net energy is conserved, not lost.
                if (l2 < ssgiR2) {
                    vec3 vplV = viewPos + dvec * mat3(gbufferModelViewInverse);
                    vec4 pcS = gbufferProjection * vec4(vplV, 1.0);
                    if (pcS.w > 0.0) {
                        vec2 puvS = ((pcS.xy / pcS.w) * 0.5 + 0.5) * TAAU_S;
                        vec2 dS = puvS - uvG;
                        dS.x /= max(ssgiAsp, 1e-4);
                        if (puvS.x > 0.0 && puvS.x < TAAU_S && puvS.y > 0.0 && puvS.y < TAAU_S
                            && dot(dS, dS) < ssgiScreenR * ssgiScreenR) {
                            float dzS = texture2D(depthtex0, puvS).r;
                            if (dzS < 1.0) {
                                float zS = -toView(puvS, dzS).z;
                                // same relative tolerance as the temporal reprojection test
                                if (abs(zS + vplV.z) < 0.05 * zS + 0.25) continue;
                            }
                        }
                    }
                }
#endif
                // Saturation boost, same idiom and now the SAME VALUE as the
                // SSGI block above (1.6). It used to be 1.8 here only because
                // the albedo was still in gamma and therefore desaturated; with
                // toLinear applied at the decode the two paths bleed alike.
                // mix() around the luma is luma-preserving on its own, but the
                // max() clamp is NOT: a channel pushed negative is clipped to 0,
                // which ADDS a little energy on saturated albedos (grass: blue
                // falls to -0.029, clips to 0, luma +1.6 % - and the bounce
                // leaves with exactly zero blue). Assumed: the SSGI block above
                // does the same, so the two paths stay coherent.
                valb = max(mix(vec3(luma(valb)), valb, 1.6), vec3(0.0));
                // Kernel window. The old linear 1 - l2/R2 started fading from the
                // very centre, where the energy is; 1 - (l2/R2)^2 fades later
                // (0.76 at 0.7R, 0.51 at 70 % of the AREA) and still reaches 0
                // at the edge, so there is no hard ring. The BARE disc integral
                // gains ~33 %, but the 1/(l2+0.5) term below concentrates the
                // energy near the centre where both windows are already ~1:
                // weighted by it, the real gain is ~+8-10 % on a typical
                // receiver.
                float e1 = l2 / rad2;
                float edge = 1.0 - e1 * e1;
                // NO cosSun here - see the normalisation block below: the
                // samples live in the LIGHT PLANE, and the emitter's own
                // irradiance E*cosSun cancels exactly against the plane->surface
                // Jacobian 1/cosSun. cosSun survives only as the back-face
                // reject above. (That cancellation is a change of VARIABLE, so it
                // does not care how the radius is DISTRIBUTED inside the plane -
                // it holds unchanged under RSM_V2's importance sampling.)
#if RSM_V2 == 1
                // wIS = (r^2 + c) is the importance weight 1/p of the radius that
                // was actually drawn, minus its constant part (folded into
                // rsmGain). r is the LIGHT-PLANE radius, l the 3D distance: the
                // two only coincide on a surface parallel to the light plane,
                // which is why this does not simply cancel the kernel - and why
                // c stays a calibration rather than a derivation.
                vec3 contrib = valb * (recv * cosSend * edge * wIS / (l2 + 0.5));
#else
                vec3 contrib = valb * (recv * cosSend * edge / (l2 + 0.5));
#endif
                // Relative anti-firefly, same idiom as the SSGI block above. The
                // absolute floor is scaled by the radius: contrib's natural
                // magnitude runs as 1/rad2 through the geometric term, so a
                // fixed 0.15 clipped legitimate taps at RSM_RADIUS 2 and did
                // nothing at 32. 100/rad2 is exactly 1.0 at the shipped
                // RSM_RADIUS 10, so the shipped behaviour is unchanged.
                // rsmFloor IS exactly that product when RSM_V2 = 0 (VLX_RSM_FF
                // aliases 100 / RSM_RADIUS^2 there); under RSM_V2 it follows c
                // instead, because wIS changed what contrib's natural scale is.
                // Hoisted either way - it never depended on the sample.
                float capH = RSM_FIREFLY_MAX * ((fcN > 0.5) ? luma(fcSum) / fcN : 0.0)
                           + rsmFloor;
                float lh   = luma(contrib);
                if (lh > capH) contrib *= capH / max(lh, 1e-4);
                fcSum += contrib;
                fcN   += 1.0;
#ifdef VLX_DEN_ACTIVE
                fcM2  += min(lh, capH) * min(lh, capH);
#endif
                rsm   += contrib;
            }
            // ---- Normalisation ----
            // Monte-Carlo estimate over a disc of RSM_RADIUS BLOCKS (world
            // units: radClip divides by shadowDistance, so the slider is in
            // blocks, never in texels), sampled uniformly in the LIGHT PLANE -
            // soff is a disc in shadow CLIP space, which is the plane
            // perpendicular to the sun, NOT the emitting surface.
            //   estimator = (area of the sampling domain / N) * sum(f)
            //             = (pi R^2 / N) * sum(f)
            // TWO THINGS THIS PASS CORRECTED IN THE FORMULA.
            // (a) THE MISSING pi. The disc area is pi*R^2, not R^2. The old
            //     comment claimed "the two pi cancel"; there is only ONE. This
            //     pack's diffuse term really is albedo * (direct + ambient) with
            //     no 1/pi anywhere (shadeSurface, lib/lighting.glsl), so the
            //     single pi of the domain area has nothing to cancel against.
            // (b) cosSun IS NOT A WEIGHT. Changing variables from the light
            //     plane to the emitting surface gives dA_surface =
            //     dA_plane / cosSun, and the emitter's own irradiance carries a
            //     factor cosSun. They cancel EXACTLY, so the light-plane
            //     integrand carries cosSend and cosRecv and nothing else.
            //     Multiplying by cosSun as well biased every sample downward.
            //     It now only rejects back faces and silhouettes (see the
            //     cosSun <= 0.15 test in the loop), which is the one job a
            //     height field cannot do any other way.
            // THE BUG BEFORE THAT: the gain was a bare 16 / N with NO R term at
            // all, so the RSM_RADIUS slider changed the BRIGHTNESS of the bounce
            // as ~ln(R^2)/R^2 instead of only its reach. It now changes reach
            // only, which is what a radius is supposed to do.
            // CALIBRATION, stated because it IS a change: (a)+(b) raise the
            // bounce ~pi/cosSun ~ x4.4 on typical ground, while linearising the
            // albedo (see the decode above) lowers it ~x0.45. Net ~x2, so
            // RSM_STRENGTH's default drops from 1.0 to 0.5 in lib/settings.glsl
            // and the delivered image stays where it was calibrated - but each
            // of the three factors is now individually right instead of three
            // wrongs cancelling, and RSM_STRENGTH stays the dial.
            // VLX_GI3_RS = RSM_STRENGTH * GI_PRESENCE sous GI_V3 (le rebond
            // solaire HORS-ECRAN suit la meme presence que le rebond ecran ; il
            // ne subit pas la dilution de portee, donc c'est un +30 % net -
            // c'est le "rebond du soleil plus present" demande). Alias exact de
            // RSM_STRENGTH a GI_V3 = 0.
            // ---- RSM_V2 : LE RAYON BOUGE MAINTENANT, ET LE GAIN AUSSI ----
            // rsmGain remplace le pi*R^2/N ci-dessus par pi*ln(Q)/N : c'est la
            // constante de normalisation de la densite d'importance p ~ 1/(r^2+c)
            // avec laquelle le rayon a ete tire (bloc de preparation en tete de
            // la boucle). Les deux estiment LA MEME integrale ; a RSM_V2 = 0
            // rsmGain vaut exactement 3.14159265 * rad2 / RSM_N, l'expression
            // d'origine. VLX_RSM_S = VLX_GI3_RS * RSM_PRESENCE (x2) sous RSM_V2,
            // alias exact de VLX_GI3_RS sinon : c'est le "monte le RSM" demande,
            // et il est finance par la baisse de variance du noyau, pas emprunte
            // au bruit. Tableau de mesures : lib/settings.glsl, section E.
            gi += rsm * getLightColor() * rsmGain * VLX_RSM_S * rGate;
#ifdef VLX_DEN_ACTIVE
            {
                // Same fold as the SSGI stream. The vec3 gain applied to gi is
                // approximated by its luma for the sigma (chroma of the light
                // vs chroma of the taps second-order for a variance estimate).
                // Same gain as the line above, so the sigma the variance window
                // sees stays the sigma of what was actually written.
                float gR  = luma(getLightColor()) * rsmGain * VLX_RSM_S * rGate;
                float m1R = luma(fcSum);
                vlxDenVar += max(fcM2 - m1R * m1R / float(RSM_N), 0.0) * gR * gR;
            }
#endif
            }
        }
        #endif

        // ---- Screen-space lights (legacy mode) ----
        #if defined SS_LIGHTS && !defined RTGI && !defined SSGI
        {
            // search radius: SS_LIGHT_RADIUS blocks projected to screen
            // (TAAU: expressed in the render sub-rect)
            float screenR = clamp(SS_LIGHT_RADIUS * gbufferProjection[1][1] / curDepth * 0.5, 0.02, 0.45) * TAAU_S;
            float aspect = viewHeight / viewWidth;

            for (int i = 0; i < GI_SAMPLES; i++) {
                float t = (float(i) + dith) / float(GI_SAMPLES);
                float ang = float(i) * 2.39996 + dith * 6.2831853;
                vec2 off = vec2(cos(ang) * aspect, sin(ang)) * sqrt(t) * screenR;
                vec2 suv = uvG + off;
                if (suv.x < 0.0 || suv.x > TAAU_S || suv.y < 0.0 || suv.y > TAAU_S) continue;

                // only emissive pixels (flag 0.5) are light sources
                float flag = texture2D(colortex2, suv).b;
                if (flag < 0.4 || flag > 0.6) continue;

                float sd = texture2D(depthtex0, suv).r;
                if (sd >= 1.0) continue;
                vec3 lightPos = toView(suv, sd);
                vec3 dvec = lightPos - viewPos;
                float l2 = dot(dvec, dvec);
                if (l2 > SS_LIGHT_RADIUS * SS_LIGHT_RADIUS || l2 < 0.01) continue;

                vec3 ldir = dvec * inversesqrt(l2);
                float ndl = dot(normal, ldir);
                if (ndl <= 0.0) continue;

                // shadow ray: 4 steps along the surface -> source segment
                float occ = 1.0;
                for (int j = 0; j < 4; j++) {
                    float fj = mix(0.15, 0.85, (float(j) + dith) / 4.0);
                    vec3 pp = viewPos + dvec * fj;
                    vec4 c = gbufferProjection * vec4(pp, 1.0);
                    vec2 ouv = ((c.xy / c.w) * 0.5 + 0.5) * TAAU_S; // TAAU: NDC->UV sub-rect
                    if (ouv.x < 0.0 || ouv.x > TAAU_S || ouv.y < 0.0 || ouv.y > TAAU_S) continue;
                    float oz = toView(ouv, texture2D(depthtex0, ouv).r).z;
                    if (oz > pp.z + 0.08 && oz < pp.z + 1.2) occ -= 0.25;
                }
                occ = max(occ, 0.0);

                vec3 lightCol = texture2D(colortex0, suv).rgb;
                gi += lightCol * (ndl * occ / (l2 + 0.5));
            }
            gi *= 16.0 / float(GI_SAMPLES) * SS_LIGHT_STRENGTH;
        }
        #endif

        // ---- SSAO ----
        #ifdef AO
        {
            #if AO_QUALITY == 0
            // AO_QUALITY 0: legacy SSAO (fallback)
            float aoAcc = 0.0;
            vec3 t1v = normalize(abs(normal.y) < 0.9
                ? cross(normal, vec3(0.0, 1.0, 0.0))
                : cross(normal, vec3(1.0, 0.0, 0.0)));
            vec3 t2v = cross(normal, t1v);

            for (int i = 0; i < AO_SAMPLES; i++) {
                float a = float(i) * 2.39996 + dith * 6.2831853;
                float r = sqrt((float(i) + dith) / float(AO_SAMPLES)) * AO_RADIUS;
                vec3 sp3 = viewPos + (t1v * cos(a) + t2v * sin(a)) * r + normal * (r * 0.4 + 0.02);

                vec4 c = gbufferProjection * vec4(sp3, 1.0);
                vec2 suv2 = ((c.xy / c.w) * 0.5 + 0.5) * TAAU_S; // TAAU: NDC->UV sub-rect
                if (suv2.x <= 0.0 || suv2.x >= TAAU_S || suv2.y <= 0.0 || suv2.y >= TAAU_S) continue;

                float sd2 = texture2D(depthtex0, suv2).r;
                if (sd2 >= 1.0) continue;
                float diffz = toView(suv2, sd2).z - sp3.z;
                // occluder in front of the test point, with a range check
                if (diffz > 0.02) aoAcc += smoothstep(AO_RADIUS * 2.0, 0.0, diffz);
            }
            ao = clamp(1.0 - aoAcc / float(AO_SAMPLES) * 1.4 * AO_STRENGTH, 0.0, 1.0);
            #else
            // AO_QUALITY 1: SAO/Alchemy estimator.
            // occ = max(0, v.n - bias) / (|v|^2 + eps) per screen-disk sample:
            // the cosine term darkens only true corners/contacts, the strict 3D
            // range kills halos behind foliage/overhangs, the depth-proportional
            // bias avoids grazing-angle acne, and the per-sample cap prevents
            // 1/d^2 sparkles. Denoised by a 3x3 bilateral (composite1) plus the
            // temporal blend below.
            float aoAcc = 0.0;
            float rW = max(AO_RADIUS, 0.05);
            float rW2 = rW * rW;
            // TAAU: screen radius expressed in the render sub-rect
            float screenR = clamp(rW * gbufferProjection[1][1] / curDepth * 0.5, 0.004, 0.25) * TAAU_S;
            float aspAO = viewHeight / viewWidth;
            float biasAO = 0.025 + curDepth * 0.0025;

            for (int i = 0; i < AO_SAMPLES; i++) {
                float a = float(i) * 2.39996 + dith * 6.2831853;
                // Radius stream decorrelated from the angle stream (dithR, same
                // fix as the SSGI/RSM discs above): with both driven by `dith`
                // the disc was one rigid spiral and the residual noise came out
                // LOW frequency - blotches the bilateral + temporal denoisers
                // never remove. dithR is already computed and in scope.
                float t = (float(i) + dithR) / float(AO_SAMPLES);
                vec2 suv2 = uvG + vec2(cos(a) * aspAO, sin(a)) * (sqrt(t) * screenR);
                if (suv2.x <= 0.0 || suv2.x >= TAAU_S || suv2.y <= 0.0 || suv2.y >= TAAU_S) continue;

                float sd2 = texture2D(depthtex0, suv2).r;
                if (sd2 >= 1.0) continue;                    // sky does not occlude
                vec3 vAO = toView(suv2, sd2) - viewPos;
                float dd = dot(vAO, vAO);
                if (dd > rW2) continue;                      // strict range -> no halo
                float occ = max(0.0, dot(vAO, normal) - biasAO) / (dd + 0.08);
                occ *= 1.0 - smoothstep(rW2 * 0.4, rW2, dd); // soft fade at range edge
                aoAcc += min(occ, 2.5);
            }
            ao = clamp(1.0 - aoAcc * (1.3 * AO_STRENGTH / float(AO_SAMPLES)), 0.0, 1.0);
            #endif
        }
        #endif

        // ---- Temporal accumulation: reproject into the previous frame ----
        vec3 wpos = mat3(gbufferModelViewInverse) * viewPos
                  + gbufferModelViewInverse[3].xyz + cameraPosition;
        vec4 prevClip = gbufferPreviousProjection
                      * (gbufferPreviousModelView * vec4(wpos - previousCameraPosition, 1.0));
        // TAAU: the GI history (colortex4/6, written by THIS pass) also lives
        // in the sub-rect -> NDC->UV = *TAAU_S, bounds at TAAU_S.
        vec2 puv = ((prevClip.xy / prevClip.w) * 0.5 + 0.5) * TAAU_S;
#if GI_HALF_RES == 1
        // History lives in the same half-res quadrant: sample at puv * 0.5,
        // clamped ~1 texel inside so bilinear taps never blend stale data
        // from outside the quadrant.
        // Verifier fix: +0.25 texel recenters the tap on the represented texel --
        // without it a STATIC camera re-reads its own history a quarter-texel off
        // every frame inside the feedback loop = progressive blur/drift.
        vec2 puvH = min(puv * 0.5 + 0.25 / vec2(viewWidth, viewHeight), 0.5 * TAAU_S - 1.5 / vec2(viewWidth, viewHeight));
#else
        vec2 puvH = puv;
#endif
        // w > 0 required: behind the camera, dividing by negative w
        // reprojects onto mirrored but valid UVs.
#ifdef VLX_DEN_ACTIVE
        // ---- V2 temporal (mission DEN): VARIANCE window, not relative ----
        // The legacy clamp below (#else) squeezed the history into a window
        // RELATIVE to the CURRENT one-frame estimate; multiplicative, it
        // collapses to [-0.02, +0.05] whenever gi lands near zero -- and with
        // the Vogel disc re-rotated every frame gi DOES land at zero wherever
        // the taps are sparse (bounce-lobe edges, distant RSM): the history
        // was crushed then re-inflated in a loop. That cycle is a real
        // flicker for every SSGI/RSM user (NOT the creator's "clignote un
        // peu de partout" - his live config compiles this whole path out,
        // see the gate note in lib/settings.glsl), plus a black bias (the crush only
        // acts downward). The window here is gi +- (KSIG * sigma + 0.02) with
        // sigma = max(instantaneous stream sigma, smoothed sigma memory of
        // colortex6.b) -- the smoothed half is what keeps the window OPEN on
        // an all-miss frame (instantaneous sigma is correlated with gi: both
        // are zero exactly on the frames that misbehave). Full derivation,
        // model numbers and the calibration sweep: lib/settings.glsl,
        // section DENOISE GI V2.
        float vlxDenSig = sqrt(vlxDenVar);
        if (prevClip.w > 0.001 && puv.x > 0.0 && puv.x < TAAU_S && puv.y > 0.0 && puv.y < TAAU_S) {
            vec4 hist = texture2D(colortex4, puvH);
            vec3 hAO = texture2D(colortex6, puvH).rgb; // .r AO, .g histN/64, .b smoothed sigma
            float mref = max(luma(gi), luma(hist.rgb)) + 0.05;
            float dev = VLX_DEN_KSIG * max(vlxDenSig, hAO.b * mref) + 0.02;
            vec3 histC = clamp(hist.rgb, gi - vec3(dev), gi + vec3(dev));
            float rDep = abs(hist.a - curDepth) / (0.1 * curDepth + 0.5);
            if (rDep < 1.0) {
                // Running average as before, but the settled cap moves from
                // 0.92 to 0.95 (ACCUM_BOOST): the variance window now guards
                // against ghosting, so the history can live longer.
                float nMax = min(1.0 / max(1.0 - GI_ACCUM_W, 1e-3) * VLX_DEN_ACCUM_BOOST, 64.0);
                histN = min(hAO.g * 64.0 + 1.0, nMax);
                float wH = 1.0 - 1.0 / max(histN, 1.0);
                // Partial disocclusion: as the depth guide nears its reject
                // edge, degrade the history weight toward DIS_W (0.95 -> 0.7).
                wH = min(wH, mix(1.0, VLX_DEN_DIS_W, smoothstep(0.5, 1.0, rDep)));
                gi = mix(gi, histC, wH);
                ao = mix(ao, hAO.r, min(wH, 0.80));
                // The sigma memory follows the SAME running average as the GI.
                vlxDenB = mix(min(vlxDenSig / mref, 1.0), hAO.b, wH);
            } else {
                // DISOCCLUSION. Legacy mixed 50% of the STALE history without
                // any clamp (a real trail); here the stale value first goes
                // through the variance window, so its contamination is bounded
                // by DIS_W * dev while the variance still drops hard. Counter
                // restarts at HIST0 (weight is back to 0.75 next frame).
                // colortex6.b serves TWO readers with OPPOSITE needs: the
                // a-trous ring weight of composite1 (wants "wide open here")
                // and next frame's variance window dev = KSIG*max(sigma,
                // .b*mref)+0.02 above (wants "tight here"). Forcing .b = 1
                // unconditionally opened next frame's window to ~2*max(gi,h)
                // at weight 0.667: 2-4 extra frames of ghost trail after a
                // stale reproject (Monte-Carlo, sparse and dense flux) - and
                // on every tier where VLX_DEN_ADAPT is 0 the ring block that
                // the flag exists to open is compiled out, so the trade
                // bought nothing. Force 1 ONLY where the adaptive rings
                // actually read it (DENOISE_QUALITY 3); publish the honest
                // instantaneous sigma everywhere else.
                if (hist.a > 0.01) gi = mix(gi, histC, VLX_DEN_DIS_W);
                histN = VLX_DEN_HIST0;
#if VLX_DEN_ADAPT == 1
                vlxDenB = 1.0;
#else
                vlxDenB = min(vlxDenSig / mref, 1.0);
#endif
            }
        } else {
            // No reprojection at all (first frame / off-screen): fresh start,
            // publish the instantaneous sigma so the rings see this texel.
            vlxDenB = min(vlxDenSig / (luma(gi) + 0.05), 1.0);
        }
#else
        if (prevClip.w > 0.001 && puv.x > 0.0 && puv.x < TAAU_S && puv.y > 0.0 && puv.y < TAAU_S) {
            vec4 hist = texture2D(colortex4, puvH);
            vec2 hAO = texture2D(colortex6, puvH).rg;   // .r = AO, .g = history length / 64
            if (abs(hist.a - curDepth) < 0.1 * curDepth + 0.5) {
                // ---- HISTORY LENGTH (colortex6.g, 8 bits, 0..64 frames) ----
                // The old blend used a CONSTANT weight, so a freshly disoccluded
                // pixel started from a black or foreign history and crawled
                // toward the truth at 8 % per frame: ~30 frames of dark smear
                // trailing every moving edge, and the "mix 50 %" hack below to
                // paper over it. A running average 1 - 1/n converges in n frames
                // and lands on EXACTLY the same steady-state WEIGHT once n
                // reaches 1/(1 - GI_ACCUM_W) - verified: nMax = 12.5 at
                // GI_ACCUM_W 0.92 and wH = 1 - 1/12.5 = 0.92 exactly. The
                // settled BLEND is therefore unchanged; the settled anti-ghost
                // CLAMP is not, and deliberately so (see k below). colortex6 is RGBA8 with
                // Clear = false and .g/.b were unused, so this is free: no new
                // buffer, no extra tap (the AO tap already reads this texel).
                float nMax = min(1.0 / max(1.0 - GI_ACCUM_W, 1e-3), 64.0);
                histN = min(hAO.g * 64.0 + 1.0, nMax);
                float wH = 1.0 - 1.0 / max(histN, 1.0);
                // Anti-ghosting clamp, WIDENING with the history length. k = 1.6
                // reproduces the previous window exactly (lo = gi*0.5,
                // hi = gi*1.6) and is what a 1-frame-old history gets. A mature
                // 12-frame average is a BETTER estimate than the single noisy
                // frame it is being clamped against, so squeezing it back into a
                // window built from that frame's noise threw away most of the
                // accumulation - the very thing the extra samples are bought for.
                // BE CLEAR ABOUT WHAT THIS CHANGES: at steady state histN hits
                // nMax, so k = 2.4 there where the old code used 1.6 at all
                // times - the settled window widens from [gi/2, gi*1.6] to
                // [gi/3, gi*2.4]. That is a real change to the SETTLED image
                // (more tolerance for trailing behind moving edges), not just a
                // transient fix. 2.4 rather than the 3.0 first tried: it keeps
                // most of the accumulation while halving the extra trail length
                // a mobile entity can drag.
                float k = mix(1.6, 2.4, clamp(histN / nMax, 0.0, 1.0));
                vec3 lo = gi / (k * 1.25) - vec3(0.02);
                vec3 hi = gi * k + vec3(0.05);
                vec3 histC = clamp(hist.rgb, lo, hi);
                gi = mix(gi, histC, wH);
                ao = mix(ao, hAO.r, min(wH, 0.80));
            } else {
                // reprojection rejected: partial fallback smoothing (anti-flicker).
                // Skip when history is a zeroed hand/sky pixel (a=0): mixing 50%
                // black darkened walls sliding over the hand silhouette.
                if (hist.a > 0.01) gi = mix(gi, hist.rgb, 0.5);
                histN = 1.0;   // restart the running average on the next frame
            }
        }
#endif
    }

#if defined VOLUMETRIC_LIGHT && VL_HALF_RES == 1
    // ---- Half-res unified volumetric-light march ----
    // Same lower-left-quadrant contract as GI_HALF_RES above: a quadrant
    // fragment marches for the full-res pixel at 2x its position (exact
    // center snap); composite1's VL block upsamples with a depth-aware
    // bilateral and recombines the two endpoints with its per-pixel wMirror.
    // Out-of-quadrant fragments skip the march (no cost) and write the
    // neutral pair (scat 0, trans 1, odUW 0).
    vec4 vlA = vec4(0.0, 0.0, 0.0, 1.0);
    vec4 vlB = vec4(0.0);
    if (uv.x < 0.5 * TAAU_S && uv.y < 0.5 * TAAU_S) {
        vec2 vlUvF = (floor(gl_FragCoord.xy) * 2.0 + 0.5) / vec2(viewWidth, viewHeight);
        vlHalfResMarch(vlUvF, vlA, vlB);
    }

/* RENDERTARGETS: 4,6,13,14 */
    gl_FragData[0] = vec4(gi, curDepth);
    // colortex6: .r = AO (the only channel any reader has ever used), .g = the
    // temporal history length / 64 (this pass only, see the accumulation block).
#ifdef VLX_DEN_ACTIVE
    gl_FragData[1] = vec4(ao, histN * (1.0 / 64.0), vlxDenB, 1.0);
#else
    gl_FragData[1] = vec4(ao, histN * (1.0 / 64.0), 0.0, 1.0);
#endif
    gl_FragData[2] = vlA;   // colortex13: scat/trans endpoint wMirror = 0
    gl_FragData[3] = vlB;   // colortex14: scat endpoint wMirror = 1 + odUW
#else
/* DRAWBUFFERS:46 */
    gl_FragData[0] = vec4(gi, curDepth);
#ifdef VLX_DEN_ACTIVE
    gl_FragData[1] = vec4(ao, histN * (1.0 / 64.0), vlxDenB, 1.0);
#else
    gl_FragData[1] = vec4(ao, histN * (1.0 / 64.0), 0.0, 1.0);
#endif
#endif
}
