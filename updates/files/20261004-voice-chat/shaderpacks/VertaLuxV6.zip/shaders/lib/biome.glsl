/*
    VertaLux - biome climate weights (BIOME_CLIMATE, lib/settings.glsl).
    Three continuous, camera-UNIFORM weights (hot / humid / cold) derived from
    the SMOOTHED Iris biome uniforms biomeTempS / biomeHumS (custom uniforms in
    shaders.properties, smooth ids 58/59, 0.6 s half-life: a biome border
    glides instead of popping). Uniform branches only -> zero per-pixel cost.
    Consumers: getSkyBase (lib/sky.glsl), getLightColor / getAmbientColor
    (lib/lighting.glsl) and the ATMO_FOG blocks (composite1.fsh).
    The uniforms and weights live while BIOME_CLIMATE is on; with the toggle
    off every weight is a literal 0.0 and the call sites are gated anyway.
    Self-contained (declares its own uniforms) and include-guarded: include it
    from any program, BEFORE lib/lighting.glsl. Requires lib/settings.glsl.
    Fail-safe: biomeTempS carries temperature + 20.0 (Iris temperature spans
    -0.7..2.0, so the valid band is 19.3..22.0). A rejected or unset custom
    uniform reads 0 -> biomeOkW() = 0 -> every weight is EXACTLY 0 (same
    render as BIOME_CLIMATE 0) instead of a false "cold everywhere". The same
    gate hides the first ~2 s while the smooth() settles after a reload.
*/
#ifndef VL_BIOME_GLSL
#define VL_BIOME_GLSL

// Uniforms only while the toggle is on (BIOME_CLIMATE 0 -> every weight below
// is a literal 0.0, no uniform referenced).
#if BIOME_CLIMATE == 1
uniform float biomeTempS;   // smooth(58, temperature + 20.0, 6.0, 6.0)
uniform float biomeHumS;    // smooth(59, rainfall, 6.0, 6.0), 0..1

// 1.0 once the smoothed temperature sits in its valid band (>= 19.3).
float biomeOkW() { return smoothstep(17.0, 19.0, biomeTempS); }
// Biome temperature back in Iris units (-0.7 .. 2.0).
float biomeTemp() { return biomeTempS - 20.0; }
#endif

// Hot & dry weight (desert, badlands, savanna): 0..1, exactly 0 when gated off.
float biomeHotW() {
#if BIOME_CLIMATE == 1
    return smoothstep(0.9, 1.6, biomeTemp())
         * (1.0 - smoothstep(0.3, 0.6, biomeHumS)) * biomeOkW();
#else
    return 0.0;
#endif
}

// Hot & humid weight (jungle, swamp, mangrove): 0..1, exactly 0 when gated off.
float biomeHumidW() {
#if BIOME_CLIMATE == 1
    return smoothstep(0.65, 0.95, biomeHumS)
         * smoothstep(0.5, 0.9, biomeTemp()) * biomeOkW();
#else
    return 0.0;
#endif
}

// Cold weight (snowy biomes, frozen peaks): 0..1, exactly 0 when gated off.
float biomeColdW() {
#if BIOME_CLIMATE == 1
    return (1.0 - smoothstep(0.0, 0.3, biomeTemp())) * biomeOkW();
#else
    return 0.0;
#endif
}

// Atmospheric-fog density multiplier (composite1 ATMO_FOG, vanilla + DH
// mirror): hot +15%, humid +15%, cold -15% at full weight, x strength
// (the documented <= 15% bound of every biome-climate effect).
float biomeFogDensMul() {
#if BIOME_CLIMATE == 1
    return 1.0 + (0.15 * biomeHotW() + 0.15 * biomeHumidW() - 0.15 * biomeColdW())
               * BIOME_CLIMATE_STRENGTH;
#else
    return 1.0;
#endif
}

// Atmospheric-fog tint: warm dust when hot, faint grey-green when humid.
vec3 biomeFogTint() {
#if BIOME_CLIMATE == 1
    return mix(vec3(1.0), vec3(1.06, 1.00, 0.90), biomeHotW() * BIOME_CLIMATE_STRENGTH)
         * mix(vec3(1.0), vec3(0.96, 1.00, 0.95), biomeHumidW() * BIOME_CLIMATE_STRENGTH);
#else
    return vec3(1.0);
#endif
}

/*
    EAU9 / WATER_COLOR_V4 -- WHICH WATER IS THE CAMERA STANDING IN.
    ONE camera-uniform scalar on the axis CLEAR(0) - MID(0.5) - DARK(1), and
    ONE mixer that every water site in the pack reads, so the view leg
    (composite1 waterColumn), the light leg (lib/lighting.glsl vlxWaterShadowT),
    the caustic tint, the glass column and the culled water faces cannot
    disagree about what the medium is -- the "one medium, one chroma" criterion
    EAU4 exists to defend, carried by construction instead of by re-derivation.
    Derivation, constants and measurements: the WATER_COLOR_V4 block in
    lib/settings.glsl.
    COST. With WATER_COLOR_V4 = 0 the mixer returns its first argument and the
    whole thing folds away, so the SPIR-V is byte-identical to the pre-V4 pack.
    With BIOME_CLIMATE = 0 the three weights are literal 0.0, so t folds to the
    compile-time constant WCOL4_T_BASE and the mix folds to a constant vec3.
    Only with BOTH on is anything computed, and then it is a uniform-only
    expression (five smoothsteps and two mixes) that the driver hoists out of
    any loop it appears in.
    WHY UNIFORM AND NOT PER-PIXEL. The vanilla biome water tint would be a
    richer signal, but it is a colortex5 TAP and the light leg has no such tap:
    keying the medium on it would make the sun's transmittance through the water
    and the water's own colour disagree again, which is the exact defect class
    EAU4 closed. The climate weights are readable from every program, so they
    are what the medium is keyed on. The per-pixel vanilla tint keeps its
    existing, separate job (the `turbid` swamp murk in waterColumn) untouched.
*/
// Position on the water-type axis: 0 = clear polar, 0.5 = ocean/lake/river,
// 1 = swamp/mangrove.  Exactly WCOL4_T_BASE when the climate uniforms are off
// or unset, which is the intended default AND the fail-safe.
// Declared only when it is used, so that at WCOL_V4 = 0 NOT ONE LINE of EAU9
// reaches the compiler: the preprocessed source is then the pre-EAU9 source, and
// the rollback needs no argument about optimisers or fold order. Verified with
// glslc -E: zero occurrences of vlxWaterTypeW / vlxWaterMix3 / vlxWater* /
// vlxScatUW* / WCOL4_* in the preprocessed composite1 at V4 = 0, against 28 at 1.
#if WCOL_V4 == 1
// The DEVIATION from base rides BIOME_CLIMATE_STRENGTH, like every other
// biome-climate effect in this file, so the user's existing dial governs how far
// biomes may pull the water apart. At strength 0 the water is WCOL4_T_BASE
// everywhere -- the realism fix still applies, only the per-biome spread stops.
float vlxWaterTypeW() {
    return clamp(WCOL4_T_BASE + (WCOL4_T_HUMID * biomeHumidW()
                               + WCOL4_T_HOT   * biomeHotW()
                               - WCOL4_T_COLD  * biomeColdW()) * BIOME_CLIMATE_STRENGTH,
                 0.0, 1.0);
}
#endif

// Pick this biome's value out of the three anchors.  Branchless: below the
// midpoint the second mix has weight 0 and returns the first, above it the
// first mix has weight 1 and returns midV.
// LUMINANCE NOTE, and it is the reason the in-scatter chroma may be mixed at
// all: the three chroma anchors carry the IDENTICAL Rec.709 luminance
// (0.358481), and luminance is linear, so every intermediate biome weight
// carries it too -- EXACTLY, not approximately. The pack's constant-brightness
// rule therefore holds for every biome without being re-verified per biome.
// OFF STATE IS A MACRO, NOT A FUNCTION RETURNING clearV, and the difference was
// measured: a function call anywhere in an expression defers constant folding
// from glslc to spirv-opt, and the two folders disagree in the last bit. The
// macro makes the WATER_COLOR_V4 = 0 source TEXTUALLY the pre-EAU9 source at
// every call site -- and it also keeps the light leg's inner loop free of a call
// it does not need.
#if WCOL_V4 == 1
vec3 vlxWaterMix3(vec3 clearV, vec3 midV, vec3 darkV) {
    float t = vlxWaterTypeW();
    return mix(mix(clearV, midV, min(t * 2.0, 1.0)), darkV, max(t * 2.0 - 1.0, 0.0));
}
#else
#define vlxWaterMix3(clearV, midV, darkV) (clearV)
#endif

#endif // VL_BIOME_GLSL
