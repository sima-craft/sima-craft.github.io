/*
    VertaLux 3.0 "Realis" - global settings.
    Options are grouped into categories in the "Shader Options" screen.
    Included FIRST by every program; nothing here may depend on other headers.
*/

// ############################################################################
// #  REGLAGE FIN : IL SE FAIT EN EDITANT CE FICHIER, PLUS DANS LE MENU       #
// ############################################################################
// Le menu in-game a ete refondu (passe "menus 4 ecrans", demande du createur) :
// il n'expose plus QUE des interrupteurs ON/OFF et des PALIERS NOMMES (Bas /
// Moyen / Eleve / Tres eleve). Plus AUCUN nombre brut n'est affiche, et la
// ligne sliders= de shaders.properties ne contient plus que ces paliers.
// Les dials numeriques n'ont PAS ete supprimes du code : ils sont TOUS restes
// des #define de CE fichier et se modifient A LA MAIN, ici. Un #define qui
// n'est liste sur aucun ecran garde son commentaire "// [...]" sans risque :
// Iris ne dessine que ce que shaders.properties lui demande.
// FAMILLES QUI SE REGLENT DESORMAIS A LA MAIN DANS CE FICHIER :
//   eau           WAVE_* WAVES_V* SWELL_* WIND_DIRECTION WATER_* RIPPLE_*
//                 FOAM_* WHITECAP_* WAVE3_* (forme de la mer, reflets, mousse)
//   caustiques    CAUSTIC_* CA4_* (echelle, nettete, contraste, vitesse, mur)
//   sous l'eau    UW_* (brouillard, teintes, puits de lumiere, particules)
//   reflets       SSR_* (tolerances, pas, bords, repli) REFLECT_* WATER_MIRROR_*
//   verre / PBR   GLASS_* PBR_* NORMAL_STRENGTH POM_DEPTH
//   nuages        VC_* CLOUD_* (forme, lumiere, ombres portees, perf)
//   ciel          SKY_* STAR_SIZE SUN_* MOON_* ATMO_* RAYLEIGH_* MIE_* AURORA_*
//   brouillard    VL_* GODRAY_* HEIGHT_FOG_* ATMO_FOG_* FOG_* CAVE_FOG_*
//   lumiere       SUN_INTENSITY MOON_INTENSITY AMBIENT_* TORCH_* MIN_LIGHT
//                 LPV_* CL_* EMISSIVE_* LAVA_* VANILLA_*
//   ombres / AO   SHADOW_* PCSS LIGHT_SIZE AO_* CONTACT_SHADOW_* FOLIAGE_SHADOW_*
//   GI            SSGI_* RSM_* GI_HALF_RES SSR_PREV_FRAME
//   image         BLOOM_THRESHOLD BLOOM_PHYSICAL/MIP/HALF_RES WB_* TAA_JITTER
//                 MOTION_BLUR_* DOF_STRENGTH LENS_FLARE_STRENGTH DEBAND
//   ambiance      DAWN_MIST_* RAINBOW_* SUN_HALO_* SNOW_SPARKLE_* BIOME_*
//                 WAVING_* PORTAL_* TC_* (couleurs par moment du jour)
//   dimensions    DIMENSION_FX NETHER_* END_* BLACKHOLE_*
// Ce que le menu expose est, lui, DERIVE dans le bloc "AXES DE MENU" ci-dessous.
//
// ---------------- PASSE "MENUS2" : LES REGLAGES FIGES ----------------
// Deuxieme demande du createur, mot pour mot : "ya des toggles genre debanding,
// retire, ce sera toujours ON par defaut pour toujours, donc juste retirer" et
// "ou alors du genre WAVE V3 retire-moi ca pitie". Deux familles de bascules ont
// donc quitte le menu POUR DE BON :
//   (a) les NUMEROS DE VERSION d'un sous-systeme - le joueur n'a pas a choisir
//       QUELLE implementation calcule sa mer ou sa brume ;
//   (b) les CORRECTIONS TECHNIQUES qui doivent rester actives pour toujours -
//       invisibles quand elles marchent, laides quand elles manquent.
// Elles gardent EXACTEMENT leur valeur (aucun pixel ne bouge) et portent chacune
// un bloc "### FIGE PAR LA PASSE MENUS2" qui dit pourquoi et comment revenir en
// arriere a la main. Sorties du menu par cette passe :
//   WAVES_V3=1  DAWN_MIST_VOL=1  DEBAND=1  TC_ENABLE=1  WATER_DISPLACEMENT (defini)
// Deja hors menu et concernees par le meme critere (elles n'ont jamais ete
// listees sur un ecran, rien a retirer) : WAVES_V2 WAVE_NORMALS_V3
// WAVE_FAST_NORMALS CAUSTICS_V4/V5/V6 WATER_COLOR_V2/V3 SHADOW_V2 SSR_HIT_V2
// SSR_BACKFACE SSR_FAST PBR_ROUGHNESS_V2 RIPPLES_V5 UW_SHAFTS_UNIFIED
// UW_SHAFT_FIX3 UW_SUN_COHERENT GLASS_SEE_THROUGH SUN_MIRROR_SHADOW
// REFLECT_GROUND_FB CLOUD_HIGH_V3 CLOUD_TEMPORAL RAINBOW_V2 DIM_DETECT_FIX
// SHADOW_TEX1_GATE_FIX PIXEL_WATER_FIX GODRAY_ANCHOR_FIX PARTICLE_FAST_SHADOWS
// BLUE_NOISE NOISE_TEX GI_HALF_RES VL_HALF_RES CLOUD_HALF_RES BLOOM_HALF_RES
// VLX_RSM_ACTIVE (porte derivee du RSM, posee par l'axe GI_QUALITY - voir la
// section RSM) et les calibrations sans liste RSM_FADE_NEAR/FAR,
// RSM_FIREFLY_MAX/FLOOR, SSGI_FIREFLY_MAX ; idem pour le denoiser GI de la
// mission DEN : GI_DENOISE_V2 (porte de secours), VLX_DEN_ACTIVE (porte
// derivee) et les calibrations VLX_DEN_* (section DENOISE GI V2).
// REGLE POUR LA SUITE : un #define qui est un numero de version, un "fix", un
// "_FAST", un "_HALF_RES" ou une porte derivee ne remonte JAMAIS au menu.

// ============ SHADOWS ============
// Contact Shadows (SSCS): micro shadows between adjacent blocks.
// Improves corners and edges - off by default (GPU cost).
//#define CONTACT_SHADOWS

// Real shadow-map shadows on particles (smoke, drips, rain splashes...): a
// particle in tree shade goes dark like the terrain. 0 = legacy lightmap-only.
#define PARTICLE_SHADOWS 1 // [0 1]
// Far-particle fast path: beyond 24 blocks a particle spans 2-6 px and its
// PCSS penumbra is sub-pixel, so the full soft shadow (5-tap blocker search +
// SHADOW_SAMPLES PCF) is replaced by ONE hard shadowtex1 tap. Near particles
// keep the full PCSS. 0 = soft shadow at any distance.
#define PARTICLE_FAST_SHADOWS 1 // [0 1]

// ==================== AXES DE MENU (PALIERS NOMMES) ====================
// TOUT ce que le menu in-game expose en dehors des interrupteurs ON/OFF est ici.
// Chaque axe [0..N] est un PALIER NOMME (Bas / Moyen / Eleve / Tres eleve) et
// DERIVE ci-dessous les valeurs techniques reelles (resolutions, nombres
// d'echantillons, portees, gains). Les valeurs derivees ne sont PAS des options
// de menu : elles suivent l'axe.
// Note : les #define places dans les branches #if/#elif/#else sont des
// redefinitions EXCLUSIVES (une seule branche compile) - un audit de doublons
// doit sauter ce bloc. Chaque chaine se termine par #else, donc le symbole est
// TOUJOURS defini quel que soit le palier.
// REGLE DE NON-REGRESSION : le palier PAR DEFAUT de chaque axe redonne
// EXACTEMENT les valeurs livrees avant la refonte des menus. Le tableau de
// preuve est dans le resume de la passe "menus 4 ecrans".
// UNE EXCEPTION, VOULUE ET ASSUMEE, SUR L'EAU.
// (Il y en avait deux : WATER_TINT, le palier de teinte du milieu, a ete RETIRE
// du menu par la passe EAU8 sur demande explicite du createur - "retire les
// differents profils de couleurs, je veux que naturel". La teinte est FIGEE au
// cran "Naturel" historique dans le bloc EAU : TEINTE DU MILIEU plus bas.)
// WATER_SKY_TINT. Son defaut est 2 (Moyen) alors que le rendu livre est le
// cran 0 (Azur (physique), qui sort du ciel reflechi AU BIT PRES - la fonction
// waterSkyTint de composite1.fsh y fait un `return sky;` immediat, verifie en
// SPIR-V). C'est une DECISION EXPLICITE DU CREATEUR de la passe EAU6 : il garde
// le miroir fort (WATER_REFLECTIVITY 1.5, surcharge x1.5 du Fresnel qu'il a
// demandee) et compense en desaturant / rechauffant le CIEL REFLECHI DANS
// L'EAU, choix artistique assume. Annonce au joueur dans l'infobulle
// ("Azur (physique) = le rendu livre jusqu'ici").
// Ce ne sont PAS des derives accidentelles : ne pas les
// "corriger" sans decision explicite. Les 11 axes de QUALITE (DENOISE_QUALITY
// est ne avec la mission DEN : son cran 0 EST le cout livre, regle tenue) et
// tous les autres axes de LOOK (EXPOSURE 0.85, SATURATION 1.05, VIBRANCE 1.0,
// TONEMAP_CONTRAST 1.0, VIGNETTE 0.15, BLOOM 1.2, SHARPEN eteint, STAR 1.0 /
// Voie lactee 0.0, VC_COVERAGE 0.40, DAMAGE 1.0, CAMERA_DROPLETS 0) suivent la
// regle sans exception.
//
// ---- axes de PERFORMANCE / QUALITE (ecran "Qualite") ----
#define SHADOW_QUALITY 1 // [0 1 2 3]
// Les deux axes LOD de l'ombre (GRATUITS : ils redistribuent la carte, ils ne
// l'agrandissent pas). Doc complete, tables derivees et tableaux chiffres au
// bloc "LOD D'OMBRE" (section PSEUDO-CASCADES, plus bas dans ce fichier).
#define SHADOW_SHARP_LEVEL 2 // [0 1 2 3]
#define SHADOW_SHARP_RANGE 0 // [0 1 2 3]
// Ombres PIXEL-PERFECT : les bords d'ombre deviennent des MARCHES alignees sur
// la grille des texels 16x16 des blocs (look "voxel"), caustiques comprises.
// Defaut 0 (eteint), et 0 dans les QUATRE profils. Doc complete, perimetre
// exact et pieges au bloc "OMBRES PIXEL-PERFECT" (juste apres
// SHADOW_TEX1_GATE_FIX, plus bas dans ce fichier).
#define PIXEL_SHADOWS 0 // [0 1]
#define CLOUD_QUALITY 1 // [0 1 2 3]
#define VOLUMETRIC_QUALITY 1 // [0 1 2 3]
// RAYONS DE NUAGES : les colonnes de lumiere et d'ombre que les cumulus
// decoupent dans la brume, visibles a TOUTE HEURE et de TOUS LES COTES.
// Ce n'est PAS un axe de qualite (il vit sur l'ecran "Ambiance & monde"), il
// est declare ICI parce que VOLUMETRIC_QUALITY pilote sa FINESSE (SHAFT_STEPS)
// et que les deux se lisent ensemble. Doc complete, mecanisme, mesures,
// perimetre et rollback : bloc "RAYONS DE NUAGES" juste apres VL_FULL_RES.
#define CLOUD_SHAFTS 2 // [0 1 2 3]
#define WAVE_QUALITY 2 // [0 1 2 3]
#define CAUSTIC_QUALITY 2 // [0 1 2]
#define SUNRAY_QUALITY 1 // [0 1 2 3]
#define REFLECT_QUALITY 2 // [0 1 2 3]
#define PBR_QUALITY 2 // [0 1 2 3]
#define GI_QUALITY 1 // [0 1 2 3]
#define DENOISE_QUALITY 0 // [0 1 2 3]
#define TAA_MODE 0 // [0 1 2 3 4]
// Finesse du RESOLVE temporel (composite4), a ne pas confondre avec TAA_MODE
// juste au-dessus, qui est la RESOLUTION de rendu. Trois paliers, doc complete
// et chiffres au bloc TAA_V2 (plus bas dans ce fichier) :
//   0 Bas    boite min/max brute + historique bilineaire (1 lecture au lieu
//            de 5) : le palier le moins cher de l'axe.
//   1 Moyen  LE RESOLVE LIVRE : clip de variance mu +- 1.15 sigma en YCoCg +
//            Catmull-Rom 5 lectures, plus les corrections a cout nul (fondu de
//            bord d'ecran, garde de sous-rect TAAU, distance de rejet du
//            fantome enfin coherente avec l'extent qu'elle divise).
//   2 Eleve  + la boite s'elargit de l'instabilite TEMPORELLE mesuree du pixel
//            (canal libre colortex7.a, ZERO lecture de plus) et de la distance
//            de reprojection, avec garde de silhouette. C'est le palier qui
//            corrige le clignotement des surfaces lisses.
// ECART ASSUME A LA REGLE "cran 0 = le cout livre" (regle enoncee pour
// DENOISE_QUALITY, quelques lignes plus haut) : ici c'est le cran 1 qui EST le
// resolve livre, et le DEFAUT est le cran 2. Cet axe existe precisement pour
// CORRIGER le comportement livre (demande du createur : "gros polish" de la
// stabilite), pas pour le preserver ; son cran 0 est plus economique que le
// livre, ce qui donne quand meme aux profils bas quelque chose a acheter.
// Inerte tant que TAA_V2 = 0 (le resolve est alors verbatim), et comme tout le
// reste de composite4, inerte si TAA est decoche.
#define TAA_QUALITY 2 // [0 1 2]
// ---- axes de LOOK (ecrans "Eau & ciel" et "Image") ----
// (WATER_TINT retire par EAU8 : la teinte du milieu n'est plus une option de
//  menu, elle est figee au cran "Naturel" - bloc EAU : TEINTE DU MILIEU.)
#define WATER_SKY_TINT 2 // [0 1 2 3]
#define CLOUD_AMOUNT 2 // [0 1 2 3]
#define STAR_LEVEL 1 // [0 1 2 3]
#define IMG_EXPOSURE 1 // [0 1 2 3]
#define IMG_SATURATION 1 // [0 1 2 3]
#define IMG_CONTRAST 1 // [0 1 2 3]
#define BLOOM_LEVEL 2 // [0 1 2 3]
#define VIGNETTE_LEVEL 1 // [0 1 2 3]
#define SHARPEN_LEVEL 0 // [0 1 2 3]
#define DAMAGE_LEVEL 2 // [0 1 2 3]

// ---- LOT B PERF (audit 2026-08) : 5 gates independants, HORS MENU ----
// 0 = comportement precedent VERBATIM, 1 = optimisation active. Memes regles
// que le LOT A (bloc apres PERF_OCEAN) : pas de liste // [..] (option fantome
// Iris), commentaire apres la valeur obligatoire pour le -Set du harnais.
// Poses ICI (avant le bloc OMBRES) parce que PERF_SHADOW_TAPS est consomme
// par la table SHADOW_QUALITY quelques lignes plus bas.
// B1 : au palier SHADOW_QUALITY 2 UNIQUEMENT, SHADOW_SAMPLES 12 -> 8 et
//      VLX_SEARCH_TAPS 8 -> 6 (lib/lighting.glsl). Le blue-noise
//      spatio-temporel + TAA absorbent la variance ajoutee -- c'est deja le
//      pari assume des paliers 0/1 (4/8 taps) ; le palier 2 garde plus de
//      taps que le palier 1 sur les DEUX compteurs, la monotonie de l'axe
//      tient. Paliers 0/1/3 inchanges. Poste n°1 de l'audit : le PCSS est
//      paye en FORWARD (gbuffers), donc multiplie par l'overdraw.
#define PERF_SHADOW_TAPS 1 // palier 2: 8 taps PCF + 6 taps recherche (0 = 12/8 legacy)
// B2 : getDistortFactor/getDistortDeriv (lib/distort.glsl, SHADOW_LOD_V2) -
//      la rampe remplace le solveur de Cardano (cbrt+sqrt+3 div par appel)
//      par une spline rationnelle C1 a coefficients fittes HORS LIGNE
//      (b2_fit5.py) : 3 segments + prolongement lineaire integre, erreur max
//      mesuree 0.261 % sur f pour d dans [aE,1] sur les 64 combos
//      SHARP_LEVEL x SHARP_RANGE x SHADOW_QUALITY (detail dans distort.glsl).
//      Ecrivain (shadow.vsh) et TOUS les lecteurs passent par les memes
//      fonctions (verifie par grep : zero Cardano en dur ailleurs), donc
//      l'erreur du fit s'ANNULE entre ecriture et lecture ; la derivee est
//      celle DU MEME MORCEAU (coherence biais/jacobien, zero acne ajoutee).
#define PERF_DISTORT_LUT 1 // rampe LOD par spline rationnelle (0 = Cardano exact)
// B3 : RSM (composite.fsh) - 8 echantillons par frame au lieu de
//      RSM_SAMPLES (16 au palier GI 2) : indices de Vogel pairs/impairs en
//      alternance, parite = frame + DAMIER pixel. Le damier est un ECART a la
//      spec de l'audit (parite frame seule), impose par la mesure
//      (b3_model2.py) : la strate centrale du disque domine le noyau
//      1/(l2+0.5), une parite frame seule alterne donc ~0.8 % de la moyenne
//      par pixel a 30-60 Hz ; en antiphase spatiale, l'upsample bilateral +
//      le 3x3 + le TAA l'annulent (mesure : 0.01-0.03 % residuel sur une
//      paire antiphase). Le clamp de variance du denoiseur (KSIG 2.0) ne
//      rejette RIEN (activite du clamp 0.0 % mesuree, dev >= 2*sigma_inst et
//      sigma_inst monte de x1.41 avec 8 taps -- l'alternance est DANS la
//      fenetre). Couts assumes, mesures sur le modele : bruit residuel
//      x1.1-1.4 apres filtre spatial, biais -1..-4 % du rebond (clamp
//      anti-firefly relatif plus strict a 8 taps), et la variance converge
//      ~2x plus lentement en mouvement (GI_ACCUM ~12-20 frames reconstruit).
#define PERF_RSM_INTERLEAVE 1 // RSM 8 ech./frame en alternance damier (0 = 16/frame)
// B4 : branche eau de composite1 - (a) le rayon SSR principal est saute
//      ENTIEREMENT quand le fondu distance->ciel est deja quasi total
//      (distSkyW >= 0.85, le MEME seuil que le skip existant du 2e rayon).
//      HONNETETE DU CHIFFRE : distSkyW = smoothstep(NEAR,FAR,dist) *
//      WATER_DSKY_STRENGTH et le defaut STRENGTH vaut 0.65 < 0.85 -> au
//      defaut ce skip ne s'allume JAMAIS ; il n'agit qu'aux crans 0.85/1.0
//      du menu (des ~160/132 blocs). (b) le 2e rayon flou (SSR_STEPS pas de
//      plus) s'allume a blurR > 0.015 (au lieu de 0.01) et s'eteint des
//      distSkyW >= 0.5 (au lieu de 0.85) : au WATER_ROUGHNESS 0.05 par
//      defaut le 2e rayon ne servait QUE sous la pluie (blurR 0.0149 a
//      dist>=120) ou il pesait ~10 % d'un reflet deja fondu au ciel a
//      moitie ; il s'eteint donc completement au defaut. PART D'ECRAN
//      (perspective PERF_OCEAN, oeil de plage s_min~3, 90 % des pixels ocean
//      sous 30 blocs) : le seuil 0.5 tombe a ~125 blocs -> ~2.4 % des pixels
//      ocean concernes par (b) a hauteur d'oeil, ~12 % depuis une falaise
//      (h~10) ; (a) touche ~2 % (et 0 % au STRENGTH defaut). Le gain est
//      donc surtout le COUT PAR PIXEL des 10 % de pixels lointains, pas une
//      part d'ecran massive -- chiffre tel quel, pas de miracle promis.
#define PERF_WATER_SSR_FAR 1 // early-out SSR eau lointaine + 2e rayon releve (0 = legacy)
// B5 : marche VL (composite1.fsh + MIROIR lib/vl_halfres.glsl) - pas
//      effectifs vlN = clamp(int(marchEnd/10), 6, VL_SAMPLES) au lieu de
//      VL_SAMPLES fixes : plein budget seulement sur les rayons longs, un
//      interieur/une ruelle a marchEnd 20 paie 6 pas au lieu de 16 (palier
//      2). dt = marchEnd/vlN recouvre toute la dalle ; consommateurs
//      adaptes : mix csA/csB sur vlN, blockFog /= vlN, dmPatchy (Nyquist
//      DAWN_MIST) clampe sur vlN (pas plus grossier -> amplitude reduite,
//      exactement l'intention du garde-fou), nSubU suit dt tout seul
//      (floor(dt/4)+1). ECART A LA SPEC assume : l'oeil SOUS L'EAU garde
//      VL_SAMPLES pleins -- la dalle UW est calibree a 6.0/4.0 blocs par pas
//      (bloc VOLUMETRIQUES) et tout l'appareil caustique/filaments (UW_SHAFT)
//      est indexe dessus ; l'exemple vise par l'audit est l'interieur oeil
//      sec. Aux paliers 0/1 (VL_SAMPLES 4/8) la borne basse min(6,VL_SAMPLES)
//      evite un clamp(lo>hi) indefini et ne REHAUSSE jamais le budget.
#define PERF_VL_ADAPTIVE 1 // pas VL adaptatifs a la longueur du rayon (0 = budget fixe)

// ---- LOT C PERF (audit 2026-08, piece 1 : LE PIXEL D'EAU) : 3 gates ----
// HORS MENU, memes regles que les LOTS A/B : pas de liste // [..] (option
// fantome Iris), commentaire apres la valeur obligatoire pour le -Set du
// harnais. Cible : la branche EAU de composite1 (+ lib/lighting.glsl pour
// C1a). Facture livree du pixel d'eau oeil-dehors : SSR 40 pas + 6 refine
// (64/8 au palier REFLECT 3) x jusqu'a 2 rayons, PCSS legacy 26-58 taps selon
// SHADOW_QUALITY, caustiques, colonne, ciel-miroir -- 150-250 taps, 1.5-6 ms
// scene-dependant ("je me mets a lagger en regardant l'ocean"). Les corps
// program_water_* (gbuffers_water + physics_ocean_v2) ne sont PAS touches :
// tout se joue dans composite1, donc l'ocean PHYSICS MOD (meme chemin
// composite) beneficie des trois gates a l'identique.
// C1a : l'ombre recue par la SURFACE d'eau (wShadow, branche eau composite1)
//      reste volontairement sur le chemin legacy sampleShadowPCF sous
//      SHADOW_V2 (le receveur V2 exige dFdx/dFdy fiables, indisponibles sur
//      une position reconstruite plein-ecran -- choix documente sur place).
//      Sur l'EAU la penombre fine est quasi invisible (surface animee +
//      reflet dominant ~90 % ciel au loin), donc version allegee DEDIEE
//      sampleShadowWaterLite (lib/lighting.glsl) : recherche de bloqueur
//      3 positions (6 taps ; legacy 5x2 = 10), PCF 6 taps MATERIELS
//      (shadow2D 2x2 par tap via shadowtex0/1HW ; legacy = SHADOW_SAMPLES x
//      2-3 taps logiciels, 8/8/8/16 selon le palier), et AU-DELA de 60 blocs
//      la recherche est SAUTEE ENTIEREMENT : penombre FIXE 1.1 texel + sonde
//      eclairee 2 taps (sans elle, l'ocean lointain ENSOLEILLE - le cas
//      majoritaire - paierait plus cher que l'early-out legacy a 10 taps).
//      ECARTS ASSUMES, DOCUMENTES : (a) l'ombre teintee (verre/eau au-dessus
//      d'une surface d'eau) passe a un passe-partout NEUTRE 0.65 -- wShadow
//      n'est consomme qu'en LUMA, seule la luminance de la teinte comptait
//      deja ; (b) au-dela de 60 blocs la largeur de penombre est constante
//      (l'ombre y module un reflet quasi pur ciel). Le rivage ombrage (< 60
//      blocs) garde recherche + penombre variable : la transition avec le
//      terrain V2 voisin reste du meme ordre que le legacy (meme rayon
//      12 texels, meme pente 35, meme plancher 0.30/0.6 texel). PORTEE :
//      exige SHADOW_V2 == 1 (les samplers HW n'existent que la ; c'est le
//      defaut livre) -- a SHADOW_V2 == 0 ce gate est INERTE et l'eau garde
//      le sampleShadowPCF complet.
#define PERF_WATER_SHADOW 1 // ombre d'eau allegee 3+6 taps HW (0 = PCSS legacy complet)
// C1b : rayon SSR de l'eau a PAS DOUBLE au loin. Option retenue parmi celles
//      de la spec (damier temporel / demi-colonne / pas double) : PAS DOUBLE,
//      la seule realisable proprement en UNE passe fragment -- le damier
//      exigerait un historique dedie (le SSR est calcule AVANT le TAA dans
//      composite1, colortex7 ne porte que la frame precedente complete) et la
//      demi-colonne un partage inter-pixels impossible en fragment pur. Mise
//      en oeuvre : multiplicateur global ssrStepMul (1.0 partout, fondu
//      1.0 -> 2.0 sur 20..30 blocs de distance du pixel d'eau, oeil dehors
//      seulement), qui DOUBLE les trois bornes du pas (SSR_STEP0_PIX/
//      SSR_PIX_MIN/pixMax et le garde-fou profondeur SSR_ZSTEP) et COUPE la
//      marche a SSR_STEPS/mul iterations : meme portee ecran ET profondeur
//      (bornes x2, budget /2), -50 % de taps de marche sur l'essentiel de
//      l'ocean (40 -> 20 pas au palier 2, 64 -> 32 au palier 3). SSR_REFINE
//      inchange : l'erreur du point d'impact double (pas residuel x2) mais
//      reste sub-texel a ces distances. Le glint GGX (haute frequence) n'est
//      PAS touche. PERTES ASSUMEES : geometrie fine (mat, barriere) a 25+
//      blocs peut etre enjambee par la marche ; le 2e rayon flou (pluie)
//      porte le meme regime. A mul intermediaire (fondu 20..30) bornes et
//      budget varient continument -> pas de couture. IEEE : x*1.0 exact,
//      gate 1 + pixel proche = bit-identique au legacy.
#define PERF_WATER_SSR_CB 1 // pas SSR eau x2 + budget /2 au-dela de ~25 blocs (0 = pleine marche)
// C1c : COURT-CIRCUIT de l'eau lointaine. Au-dela de ~90 blocs, la ou le
//      poids miroir atteint son plafond (reflW = 0.98 des ~45 blocs en
//      rasant, table EAU5) et ou le fond est invisible (colonne asymptotique),
//      le pixel d'eau = ciel-miroir teinte (waterSkyTint via skyReflect,
//      normale aplatie identique a la branche lourde) + glint GGX (garde :
//      c'est la beaute du truc) + colonne ASYMPTOTIQUE (waterColumn avec
//      chemin 1e3 blocs : Tfl -> 0, il ne reste que le in-scatter, la
//      constante vers laquelle la colonne integree converge de toute facon a
//      cette distance) -- ZERO rayon SSR, ZERO PCSS (1 tap dur shadowVis1
//      remplace l'ombre : il continue d'eteindre le soleil-miroir et le glint
//      dans l'ombre d'une falaise, le bug historique "reflet du soleil a
//      l'ombre" ne revient pas), ZERO caustique, ZERO colonne integree, ZERO
//      refraction. FONDU sur 20 blocs avant le seuil (70 -> 90, mix continu
//      branche lourde -> pixel simple ; dans la bande les DEUX sont payees,
//      bande fine ~1 % des pixels ocean a hauteur d'oeil). GARDE-FOUS : oeil
//      dehors seulement, plan d'eau quasi horizontal (flatW), et poids miroir
//      estime >= ~0.95 (meme chaine fresnel/graze/horizon que la branche
//      lourde, SSR a zero) -- une vue plongeante depuis une falaise ou le
//      fond resterait visible garde la branche complete. ECARTS ASSUMES :
//      whitecaps (OFF par defaut) et sparkle (OFF) eteints au-dela du fondu ;
//      l'ecume de rivage disparait au-dela de 90 blocs (elle fondait deja
//      x0.35 a 140) ; DEBUG_VIEW 23/24/28 ne peignent plus ces pixels ; le
//      chemin PT (RT_REFLECT_MODE >= 2) est ignore au-dela du seuil. PART
//      D'ECRAN (densite h/s^2, oeil de plage s_min ~ 3) : ~3 % des pixels
//      ocean au-dela de 90 blocs a hauteur d'oeil -- mais ce sont les plus
//      chers (2 rayons longs + PCSS plein) ; depuis une falaise (h >= 10,
//      s_min ~ 15) ~17 %, et c'est la vue "je regarde l'ocean" du rapport.
#define PERF_WATER_FAR_SIMPLE 1 // court-circuit eau > ~90 blocs, fondu 70-90 (0 = branche complete)
// ---- LOT C PERF (audit 2026-08, piece 2 : LE PIXEL DE TERRAIN) : 1 gate ----
// HORS MENU, memes regles que les autres gates du LOT C (pas de liste // [..],
// commentaire apres la valeur obligatoire pour le -Set du harnais).
// CIBLE (poste n1 de l'audit, 1.0-2.0 ms) : gbuffers_terrain paie shadeSurface
// (PCSS SHADOW_V2 : 2 + 2*VLX_SEARCH_TAPS + 2*SHADOW_SAMPLES taps, soit ~34-58
// selon SHADOW_QUALITY ; cloudShadow 1-9 taps ; LPV/CL ; compensations GI) PAR
// FRAGMENT RASTERISE : l'overdraw (feuillage/cutout qui cassent l'early-z,
// terrain non trie) le paie 2-3x sur les scenes de foret.
// A 1 : le fragment terrain NON emissif ecrit un G-buffer brut - colortex0 =
// albedo LINEAIRE (x teinte biome x AO vanilla), alpha = drapeau differe
// (0.00 opaque / 0.02 feuillage-subsurface) ; colortex1/2/5/11 INCHANGES - et
// la passe plein-ecran deferred1 (deferred1.fsh, entre le ciel "deferred" et
// les translucides dans l'ordre Iris) reconstruit la position depuis depthtex0
// et appelle LE MEME shadeSurface de lib/lighting.glsl UNE fois par pixel
// VISIBLE (cloudShadow devient 1 eval/pixel par construction). Les fragments
// emissifs / portails / emission labPBR restent FORWARD dans gbuffers_terrain
// (leurs termes additifs dependent de la texture, appliques APRES shadeSurface),
// tout comme les stages HORS terrain routes vers ce programme (gate renderStage
// au call site - cassage DESTROY, block entities/texte : dessines APRES
// deferred1 sur MC 26.2, prouve au bytecode par l'audit, ils ne seraient JAMAIS
// shades s'ils partaient differes) ; tous se signalent par alpha >= 0.1.
// Entites / main / DH ecrivent un alpha 1.0 force (verifie) ; textured/_lit
// discard < 0.05 puis ecrivent col.a ; ATTENTION gbuffers_basic ecrit
// glcolor.a NON borne - sur aujourd'hui uniquement parce que ses seuls
// consommateurs en fenetre opaque sont le leash (a=1.0) et sky_basic (depth
// 1.0, exclu par d0<1) : invariant FRAGILE, a re-verifier si un nouveau
// consommateur de Basic apparait. Tous traversent
// deferred1 par un PASSTHROUGH EXACT (copie de colortex0 - pas un discard :
// les passes deferred lisent le front et ecrivent le back du ping-pong
// main/alt d'Iris, un discard laisserait le contenu perime de l'autre copie).
// DRAPEAU : colortex0.a n'a AUCUN lecteur entre les gbuffers et la reecriture
// "vec4(color, 1.0)" de composite1 (verifie par grep : composite/composite1..5
// lisent .rgb seulement ; final.fsh lit .a mais bien apres composite1). Le
// canal est donc LIBRE dans cette fenetre : AUCUN nouveau colortex, zero
// bande passante ajoutee. deferred.fsh (ciel) PRESERVE cet alpha a gate 1
// (a gate 0 il reecrit 1.0 comme avant, hash identique).
// BUG A (2026-08, feuillage invisible / ombres intactes) : Iris emule l'alpha
// test fixed-function en appendant en fin de main() un test sur l'ALPHA DE
// SORTIE de gl_FragData[0] (preuve bytecode iris-fabric-1.11.2 :
// CommonTransformer + AlphaTest.toExpression ; passe terrain CUTOUT ref 0.5).
// Le drapeau 0.00/0.02 ci-dessus echouait ce test -> TOUT fragment cutout
// differe etait discard. DEPENDANCE DURE du gate : la ligne
// "alphaTest.gbuffers_terrain=off" de shaders.properties (doc sur place) ;
// le test est relocalise dans le discard in-shader de gbuffers_terrain.fsh
// (seuil par matiere 0.5 id 10 / 0.1 sinon, algebre d'equivalence sur place).
// ECARTS ASSUMES A 1 (bornes mesurables, pas des promesses de zero-diff) :
//  (a) position reconstruite depuis depthtex0 : le jitter TAA des vsh est
//      RETIRE du NDC avant l'unprojection (deferred1.fsh, BUG B "bords
//      d'ombre qui clignotent" - l'inverse non compensee faisait trembler la
//      position monde d'un sous-texel par frame et la recherche PCSS sautait
//      de texel shadow map en texel). Reste la quantification du depth,
//      negligeable ;
//  (b) lightmap relue en RGBA8 (colortex2.rg, quantif 1/255) au lieu du
//      varying pleine precision (< 1 % sur le terme torch en lm^3) ;
//  (c) le gradient dFdx/dFdy du plan recepteur SHADOW_V2 vient de la position
//      reconstruite : identique sur les surfaces planes, et les silhouettes
//      retombent sur le fallback normal deja code (seuil 30 deg) ;
//  (d) surcouche de cassage / contour de selection : NI L'UN NI L'AUTRE n'est
//      dans la fenetre opaque sur MC 26.2 (phases breakingOverlay/outline,
//      APRES deferred1 - prouve au bytecode). Le contour (Line->Basic) se
//      blende sur la couleur deja shadee : zero effet. Le cassage passait par
//      ce programme SANS jamais etre shade (defaut releve par l'audit) ->
//      corrige par le gate renderStage du call site : il shade forward et
//      retrouve exactement le resultat d'avant (2*S(c)*S(t)).
// A 0 : chemin forward d'origine (branches #else intactes) AU TEST ALPHA
// PRES : la ligne alphaTest.gbuffers_terrain=off s'applique aux DEUX gates
// (shaders.properties n'est pas conditionnable sur un define hors menu), le
// discard in-shader relocalise tue le meme ensemble de fragments (BUG A
// ci-dessus). ROLLBACK REVISE : le hash SPIR-V gate 0 de gbuffers_terrain
// n'est PLUS celui de pd_baseline.txt - nouveau baseline pd_baseline2.txt
// (+ pd_baseline2_gate0.txt), et la preuve que gate-0-nouveau ne differe de
// gate-0-ancien QUE par la relocalisation est le diff du pretraite
// (expand.ps1, commentaires a part) : declaration d'alphaTestRef + les deux
// lignes du discard (aCut / max), rien d'autre. deferred1 compile en
// PASSTHROUGH TRIVIAL. LIMITE DU ROLLBACK : le programme deferred1 reste une
// passe plein ecran qui COPIE colortex0 (lecture + ecriture RGBA16F,
// ~0.05-0.1 ms selon la resolution) - la copie est incompressible (ping-pong
// main/alt, voir plus haut) et Iris ne sait pas desactiver un programme via
// une option a VALEUR hors menu (program.*.enabled exige une option BOOLEENNE
// de menu). Cout fixe residuel assume et documente ici.
// FPT : a FULL_PATH_TRACE=1 + VOXEL_GI=1 le gate est INERTE (le chemin
// shadeSurfaceFPT/colortex12 est conserve tel quel) via la porte derivee
// VLX_DEFERRED_ACTIVE posee en FIN de ce fichier (elle depend de defines
// posterieurs a ce bloc).
#define PERF_DEFERRED 1 // terrain differe: G-buffer brut + shading 1x/pixel visible dans deferred1 (0 = forward verbatim)
// ---- CAUSTIC_FACING (correctif 2026-08, HORS MENU, memes regles LOT A/B/C) ----
// BUG VISE (rapport in-game, oeil sous l'eau) : des caustiques s'affichent au
// DOS des kelp (cote a l'ombre du soleil), debordent derriere eux, et
// s'affichent sur le flanc ombre des poissons/entites. CAUSES MESUREES :
//   (1) CA4_WALL (0.75 defaut) est un PLANCHER : toute face non orientee vers
//       le haut garde 75 % de la caustique -- un cross-quad de kelp (normale
//       horizontale) recoit donc presque tout ;
//   (2) AUCUN terme d'orientation vers le soleil (N.L) a aucun des trois sites
//       d'application de composite1.fsh (through-water / bande de rivage /
//       sous-marin, variantes v4 ET legacy v3) ;
//   (3) shadowVis1 = 1 tap shadowtex1 + biais constant : une geometrie
//       d'epaisseur nulle (cross-quad, corps de poisson) a sa propre
//       profondeur ~= celle du tap -> toujours "eclairee". La shadow map ne
//       peut PAS sauver le dos des kelp ; seul un test de normale le peut.
// CE QUE FAIT LE GATE (1, defaut) : a chaque site le poids caustique est
// multiplie par un facteur d'orientation FAIL-CLOSED
//     smoothstep(0.0, 0.25, dot(normaleMonde, lightW))
// (dot <= 0 -> strictement 0 : une face dos au soleil ne recoit RIEN ; le
// plancher CA4_WALL ne dose plus que les faces qui VOIENT le soleil), et les
// facteurs BON MARCHE du masque (orientation, caN*, hauteur du soleil/pluie,
// absorption, fondu distance) sont evalues AVANT le champ caustique
// (vlCa4Net ~9 photons + 3 pentes / waveCausticFull ~9 trains) et avant le
// tap shadowVis1 ; masque <= 0.004 -> champ ET tap sautes (le poids est
// multiplicatif lineaire : hors coupure, produit des memes facteurs).
// NORMALE DES CROSS-QUADS/CUTOUTS (verifie dans les gbuffers) :
// gbuffers_terrain.fsh:175/374 et gbuffers_entities.fsh:50 ecrivent dans
// colortex1 la normale VUE brute (gl_NormalMatrix * gl_Normal), SANS flip
// gl_FrontFacing (seul lib/program_water_fragment.glsl:243 flippe, pour l'eau).
// Les modeles vanilla "cross" (kelp & co) portent DEUX quads opposes une face
// chacun : la normale stockee est donc la normale SORTANTE de la face que la
// camera voit -- N.L eteint bien le cote visuellement a l'ombre vu par le
// joueur. Au site through-water la normale est reconstruite en espace ecran
// (cross de differences finies de depthtex1) : orientee camera PAR
// CONSTRUCTION, meme comportement. Les shafts volumetriques (marche VL,
// causticShaftMask, lib/vl_halfres.glsl) ne sont PAS touches : un terme
// volumetrique n'a pas de normale, N.L n'y a pas de sens.
// 0 = comportement precedent VERBATIM (prouve par hash SPIR-V des 7 combos).
#define CAUSTIC_FACING 1 // caustiques limitees aux faces orientees soleil + early-out du champ (0 = legacy verbatim)

// ---------------- OMBRES (SHADOW_QUALITY) ----------------
// CE CRAN AMELIORE : la NETTETE de l'ombre, puis sa PORTEE.
// MESURE : taille du texel d'ombre EN BLOCS, au centre de la carte (la ou le
// joueur regarde). C'est LA metrique de nettete, et elle depend des DEUX
// nombres a la fois :
//     texel_monde = (2 * shadowDistance / shadowMapResolution) * (1 - SHADOW_DISTORT_STRENGTH)
// Le facteur (1 - S) vient de la pseudo-cascade (lib/distort.glsl) : pres du
// joueur la carte est magnifiee 1/(1-S) fois. A S = 0.90 (defaut) :
//     palier 0 : 2*128/1024 * 0.10 = 0.0250   bloc/texel   portee 128
//     palier 1 : 2*192/2048 * 0.10 = 0.01875  bloc/texel   portee 192
//     palier 2 : 2*256/4096 * 0.10 = 0.0125   bloc/texel   portee 256
//     palier 3 : 2*384/8192 * 0.10 = 0.009375 bloc/texel   portee 384
// -> chaque cran est a la fois PLUS NET (x1.33, x1.50, x1.33) et PLUS LOIN
//    (x1.50, x1.33, x1.50). Monotone sur les deux axes.
// NOTE LOD (passe SHADOW_LOD_V2, bloc "LOD D'OMBRE" plus bas) : ces texels
// centraux valent pour la courbe actuelle (SHADOW_LOD_V2 0). A 1 (defaut), le
// facteur (1 - S) est remplace par VLX_LOD_M0 (0.14 au defaut L2 : memes
// chiffres x1.4) mais il tient sur TOUT le plateau SHADOW_SHARP_RANGE au lieu
// de s'evaporer des le premier bloc -- les deux axes du cran restent monotones
// exactement comme ci-dessus, le LOD ne renormalise rien entre paliers.
// BUG CORRIGE (audit des paliers ; retour createur : "j'augmente la qualite de
// l'ombre et c'est pareil, c'est juste la distance ?") : le palier 3 partageait
// la resolution 4096 du palier 2 tout en montant la portee a 384. Son texel
// valait donc 0.01875 - EXACTEMENT celui du palier 1, et 1.5x plus GROS que
// celui du palier 2. Passer en "Tres eleve" rendait les ombres MOINS nettes
// qu'en "Eleve" : une regression vendue comme une amelioration. Corrigee en
// portant la resolution du dernier cran a 8192.
// BUDGET VRAM DU 8192 (c'est lui qui autorise ce cran) : la passe shadow alloue
// deux textures de PROFONDEUR 32 bits (shadowtex0 + shadowtex1) et shadowcolor0
// en RGBA8, soit 8192^2 * (4+4+4) = 805 306 368 octets = 768 Mio, contre
// 192 Mio a 4096 : +576 Mio. UNITE : Mio = 2^20 octets (les memes chiffres en
// Mo decimaux font 805 / 201 / +604 - c'est la meme quantite, pas une autre).
// Les trois autres endroits qui citent ce budget (shaders.properties, les deux
// .lang) disent tous +576 Mio. Ce chiffre suppose UN SEUL buffer couleur
// d'ombre : c'est ce que borne le "const int shadowColorBuffers = 1" pose plus
// bas (section SHADOW_V2) ; sans lui Iris en allouerait deux et il faudrait
// ajouter 8192^2 * 4 = 256 Mio pour rien, shadowcolor1 n'etant jamais lu.
// En face, sur la RTX 5080 du createur (16 Gio) : ~0.9 Gio de colortex a 1440p
// (~2.0 Gio a 2160p ; 16 cibles, double tampon, formats declares dans
// composite1/composite4/composite5/prepare) + 168 Mio d'images voxel/LPV
// (voxelImg 256^3 + lightImg/lightImgB 128^3, RGBA16F) + les depthtex. La marge
// reste large meme en 4K.
// COUT GPU : le remplissage de la passe shadow est x4 (67 Mpx au lieu de 17).
// C'est le poste le plus cher du pack - d'ou "Tres eleve", et pas le defaut.
// LES AUTRES VALEURS DERIVEES DE CET AXE :
//   SHADOW_SAMPLES       taps PCF dans la penombre           4 / 8 / 12 / 16
//   VLX_SEARCH_TAPS      taps de recherche de bloqueur PCSS  4 / 5 / 8 / 10
//                        (lib/lighting.glsl, suit cet axe)
//   AO_SAMPLES           taps de l'occlusion ambiante        4 / 8 / 12 / 16
//   CONTACT_SHADOW_STEPS pas du raymarch de contact          6 / 8 / 10 / 16
//                        (INERTE tant que CONTACT_SHADOWS n'est pas defini : il
//                         ne l'est pas par defaut et n'est sur aucun ecran)
// NOTE PENOMBRE : avec SHADOW_V2 = 1 (defaut) la largeur de penombre est
// calculee en BLOCS (rPen = lsize * distB / dPerBlock, lib/lighting.glsl) : elle
// ne bouge PAS d'un palier a l'autre, seules la nettete et la portee changent -
// c'est le comportement attendu. Sur le chemin LEGACY (SHADOW_V2 = 0) le rayon
// de penombre vaut penombre_texels * 2*shadowDistance/resolution avec un terme
// proportionnel a la resolution : il est donc proportionnel a shadowDistance et
// les ombres y sont d'autant plus FLOUES que le palier est haut. Ce chemin
// n'est pas expose dans le menu et garde sa calibration d'origine.
#if SHADOW_QUALITY == 0
const int   shadowMapResolution     = 1024;
const float shadowDistance          = 128.0;
#define SHADOW_SAMPLES 4
#define CONTACT_SHADOW_STEPS 6
#define AO_SAMPLES 4
#elif SHADOW_QUALITY == 1
const int   shadowMapResolution     = 2048;
const float shadowDistance          = 192.0;
#define SHADOW_SAMPLES 8
#define CONTACT_SHADOW_STEPS 8
#define AO_SAMPLES 8
#elif SHADOW_QUALITY == 2
const int   shadowMapResolution     = 4096;
const float shadowDistance          = 256.0;
// PERF_SHADOW_TAPS (LOT B, B1) : 12 -> 8 taps PCF a CE palier seulement (le
// jumeau VLX_SEARCH_TAPS 8 -> 6 vit dans lib/lighting.glsl). AO_SAMPLES et
// CONTACT_SHADOW_STEPS ne bougent pas : le gate ne touche que l'ombre PCSS.
#if PERF_SHADOW_TAPS == 1
#define SHADOW_SAMPLES 8
#else
#define SHADOW_SAMPLES 12
#endif
#define CONTACT_SHADOW_STEPS 10
#define AO_SAMPLES 12
#else
const int   shadowMapResolution     = 8192;
const float shadowDistance          = 384.0;
#define SHADOW_SAMPLES 16
#define CONTACT_SHADOW_STEPS 16
#define AO_SAMPLES 16
#endif

// ---------------- NUAGES (CLOUD_QUALITY) ----------------
// CE CRAN AMELIORE : la FINESSE du volume nuageux, et sa PORTEE.
// MESURE : longueur de pas de la marche, en blocs. Le pas est recalcule pour
// couvrir TOUTE la tranche visee (lib/clouds.glsl : dt = (t1-t0)/samples avec
// t1 borne par VC_RENDER_DISTANCE), donc monter la portee SANS monter les
// echantillons ALLONGE le pas et DEGRADE la finesse. La bonne metrique est le
// rapport, pas l'un des deux nombres :
//     pas = VC_RENDER_DISTANCE / VC_SAMPLES
//     palier 0 :  700 /  8 = 87.5 blocs/pas   portee  700
//     palier 1 :  900 / 16 = 56.3             portee  900
//     palier 2 : 1400 / 28 = 50.0             portee 1400
//     palier 3 : 1800 / 48 = 37.5             portee 1800
// -> pas strictement decroissant ET portee strictement croissante.
// BUG CORRIGE (audit des paliers) : le palier 2 portait 24 echantillons pour
// 1400 blocs, soit un pas de 58.3 - PLUS LONG que les 56.3 du palier 1. Passer
// en "Eleve" gagnait de la portee mais perdait de la finesse dans le volume
// proche. 24 -> 28 echantillons remet le rapport dans l'ordre.
// COUT : lineaire en VC_SAMPLES (x2.0 / x1.75 / x1.71 par cran), applique aux
// ~1/4 de pixels de la cuisson demi-resolution.
// VC_SAMPLES_EFF (bake temporel demi-res, CLOUD_TEMPORAL = 1) suit
// mecaniquement : ceil(0.6 * VC_SAMPLES) = 5 / 10 / 17 / 29.
// PAS SOUS CET AXE, ET C'EST VOLONTAIRE : CLOUD_HALF_RES et CLOUD_TEMPORAL
// (plus bas dans ce fichier) sont les DEUX plus gros leviers de cout des
// nuages - les passer a 0 au dernier cran multiplierait la facture par ~6.6
// (x4 pixels x 48/29 echantillons) et ferait de "Tres eleve" un cran
// injouable au lieu d'un cran cher. Ils restent a 1 a tous les paliers et se
// reglent a la main.
#if CLOUD_QUALITY == 0
#define VC_SAMPLES 8
#define VC_RENDER_DISTANCE 700.0
#elif CLOUD_QUALITY == 1
#define VC_SAMPLES 16
#define VC_RENDER_DISTANCE 900.0
#elif CLOUD_QUALITY == 2
#define VC_SAMPLES 28
#define VC_RENDER_DISTANCE 1400.0
#else
#define VC_SAMPLES 48
#define VC_RENDER_DISTANCE 1800.0
#endif
// VC_SAMPLES_EFF (temporally resolved half-res bake, CLOUD_TEMPORAL=1) is
// derived from these tiers in the CLOUDS section below: 5 / 10 / 17 / 29.

// ---------------- VOLUMETRIQUES (VOLUMETRIC_QUALITY) ----------------
// Le nombre de pas de la marche VL et la portee du rayon sous-marin. Les RAYONS
// DU SOLEIL (godrays + puits de lumiere) ont leur propre axe SUNRAY_QUALITY
// juste dessous : GODRAY_SAMPLES a quitte ce bloc lors de la refonte des menus.
// CE CRAN AMELIORE : la FINESSE de la brume (moins de bandes / de bruit), et
// la PORTEE du rayon sous-marin.
// MESURE : longueur de pas de la marche, en blocs, sur les DEUX regimes. Le pas
// est marchEnd / VL_SAMPLES (composite1.fsh l.5874 et lib/vl_halfres.glsl l.87)
// avec marchEnd = 160 hors de l'eau et UW_RAY_DISTANCE sous l'eau :
//     hors de l'eau : 160 / VL_SAMPLES  = 40.0 / 20.0 / 10.0 / 5.0
//     sous l'eau    : UW / VL_SAMPLES   =  6.0 /  6.0 /  6.0 / 4.0
//     portee sous l'eau (blocs)         : 24 / 48 / 96 / 128
// -> pas non croissant partout (l'echelle 4/8/16/32 DOUBLE les echantillons a
//    chaque cran, le pas aerien est divise par 2 a chaque fois), portee
//    strictement croissante.
// BUG CORRIGE (audit des paliers) : le palier 2 portait 12 echantillons pour
// 96 blocs, soit un pas SOUS L'EAU de 8.0 - contre 6.0 aux paliers 0 et 1.
// Passer en "Eleve" voyait plus loin sous l'eau mais avec des puits de lumiere
// et un brouillard PLUS bandes en champ proche. 12 -> 16 echantillons remet le
// pas a 6.0 sans rien retirer a la portee, et ameliore au passage le pas hors
// de l'eau (13.3 -> 10.0).
// COUT : lineaire en VL_SAMPLES, paye sur ~1/4 des pixels A TOUS LES PALIERS
// (VL_HALF_RES vaut 1 partout depuis la passe VQ3 ci-dessous ; le define
// expert VL_FULL_RES, pose sous l'axe, est le seul chemin vers le plein ecran).
// clamp(VL_SAMPLES/12, 0.35, 1) (DAWN_MIST_PATCHY) sature a 1.0 des 12
// echantillons : 12, 16, 20 et 32 y sont identiques, l'axe ne touche la brume
// d'aube qu'aux paliers 0 et 1.
// ---- PASSE VQ3 : LE PALIER 3 REVIENT EN DEMI-RESOLUTION ----
// Historique. La passe "audit des paliers" avait passe VL_HALF_RES a 0 au
// dernier cran, au motif que le max ne devait rien laisser adoucir : la marche
// y redevenait plein ecran, bit-identique au pack pre-demi-res, et les stries
// des puits de lumiere cessaient d'etre lissees par l'upsample.
// Deux audits independants ont ensuite chiffre ce que ce 0 coutait : a 1080p
// la marche tournait sur 2.07 Mpx au lieu de ~0.52 (x4), ~130 unites de cout
// fixe par pixel (20 pas x ~6.5 unites/pas) PARTOUT, plus les taps de
// filaments sur l'ocean -- le poste dominant de la perte de FPS face a l'eau
// -- pour un gain limite a la nettete des bords de brume et des stries :
// l'upsample bilateral est depth-aware, les silhouettes sont deja gerees.
// RE-ETAGEMENT : le x4 de pixels rendu par le retour au quadrant est
// reinvesti dans la QUALITE de la marche (20 -> 32 pas, portee UW 112 -> 128).
// Chiffres a 1080p, en pas marches par image :
//     avant : 2.07 Mpx x 20 pas  = 41.5 M pas   (palier 3 plein ecran)
//     apres : 0.52 Mpx x 32 pas  = 16.6 M pas   (x2.5 MOINS cher)
//     ref.  : 0.52 Mpx x 16 pas  =  8.3 M pas   (palier 2 : le 3 coute
//             desormais 2x le 2, contre 5x avant la passe)
// NB : ces -60% sont des PAS MARCHES, pas du temps de frame : l'upsample
// bilateral 4 taps et les ecritures colortex13/14 de composite.fsh restent
// payes sur les 2.07 Mpx entiers -- taxe deja due aux paliers 0-2,
// NOUVELLEMENT due au palier 3 (elle n'existait pas dans la colonne "avant").
// METRIQUE DU PALIER 3 : des pas de marche PLUS FINS (5.0 contre 10.0 hors de
// l'eau, 4.0 contre 6.0 sous l'eau, portee 128 contre 96) ET 4x moins de
// pixels que l'ancien palier 3. Ce qu'il perd, honnetement : la pleine
// resolution du brouillard -- bords de shafts un peu plus doux, stries
// sous-marines legerement lissees par l'upsample. Ce qu'il gagne : le pas le
// plus court du pack sur les deux regimes (moins de bandes et de bruit que
// tout autre palier), et la portee sous-marine la plus longue.
#if VOLUMETRIC_QUALITY == 0
#define VL_SAMPLES 4
#define UW_RAY_DISTANCE 24.0 // 4 steps, dt 6.0
#elif VOLUMETRIC_QUALITY == 1
#define VL_SAMPLES 8
#define UW_RAY_DISTANCE 48.0 // 8 steps, dt 6.0
#elif VOLUMETRIC_QUALITY == 2
#define VL_SAMPLES 16
#define UW_RAY_DISTANCE 96.0 // 16 steps, dt 6.0
#else
#define VL_SAMPLES 32
#define UW_RAY_DISTANCE 128.0 // longest underwater ray range (32 steps, dt 4.0)
#endif
// VL_FULL_RES (expert, fige HORS MENU -- regle MENUS2 : un _HALF_RES ne
// remonte jamais au menu) : 1 force VL_HALF_RES = 0 a N'IMPORTE QUEL palier.
// La marche VL redevient alors plein ecran (chemin inline de composite1 ;
// colortex13/14 et l'upsample compilent out) : cout x4 sur la marche, a
// reserver aux CAPTURES D'ECRAN -- en jeu la difference se limite a des bords
// de brume et des stries un peu plus nets, l'upsample bilateral etant
// depth-aware. Compose avec tous les paliers, palier 3 compris (VQ3 +
// VL_FULL_RES 1 = l'ancien "Tres eleve" plein ecran, en 32 pas au lieu de 20).
#define VL_FULL_RES 0 // [0 1]
#if VL_FULL_RES == 1
#define VL_HALF_RES 0
#else
#define VL_HALF_RES 1
#endif

/* ================= RAYONS DE NUAGES (CLOUD_SHAFTS) ==================
   DEMANDE : "au coucher du soleil on voit les rayons du soleil traverser les
   nuages de tous les cotes, partout. Je veux ca, mais pas uniquement au
   coucher. La, pour voir les sun rays dans les nuages il faut etre au bord de
   son ombre."

   POURQUOI CA NE MARCHAIT PAS -- trois causes, toutes mesurees :
   1. cloudShadow / cloudShadowCheap (lib/lighting.glsl) commencent par
      sunUpF = smoothstep(0.06, 0.22, L.y) et RETOURNENT 1.0 en dessous de
      0.06. Au COUCHANT l'ombre des nuages DISPARAIT -- exactement l'inverse
      de la demande. MESURE (marche 0-160 b, ombre pure, phase retiree,
      eventail de 30 deg a 90 deg du soleil) : a 1/2/3 deg de hauteur de
      soleil l'ecart-type de la visibilite nuage vaut 0.00000 (aucune
      structure, visibilite moyenne 1.000). Avec la carte : 0.0175 / 0.0193 /
      0.0339, moyenne 0.989 / 0.987 / 0.560.
   2. La marche VL proche ne prenait que DEUX sondes d'ombre de nuage (csA a
      25 %, csB a 75 % de la marche) interpolees lineairement : aucune
      structure de faisceau LE LONG du rayon, et une structure PARASITE en
      travers. MESURE, a 10 et 45 deg de soleil, contre la meme marche prise
      pas a pas avec le proxy exact : ecart-type 0.0933 / 0.0809 pour les 2
      sondes, contre 0.0093 / 0.0218 pour la reference -- les 2 sondes
      produisent 10 a 4 fois PLUS de "structure" que la verite, parce que ce
      sont deux silhouettes de nuage tamponnees sur le ciel, pas des colonnes.
   3. Les brouillards analytiques du lointain (ATMO_FOG, AERIAL_PERSPECTIVE,
      DAWN_MIST, traine HEIGHT_FOG) sont ponderes par fogSunVis(), 2-3 sondes
      moyennees en UN scalaire par pixel : aucune colonne possible.

   CE QUE FAIT LE GATE (mecanisme, en quatre pieces) :
   (A) CARTE DE TRANSMITTANCE DES NUAGES (CTM), cuite chaque frame par le
       nouveau passage prepare2.fsh dans colortex12 (R8, CTM_RES^2, taille
       fixe via size.buffer). Un texel = l'OPACITE dT du proxy 2D des cumulus
       au point correspondant du PLAN des nuages (VC_BASE + VC_THICK*0.33, le
       barycentre de densite que cloudShadow projette deja), calculee par
       vlCloudOpacityAtPlane() -- SOURCE UNIQUE, la meme fonction que
       cloudShadowCheap appelle. Grille ancree MONDE : origine =
       floor(cpCam / CTM_CELL) * CTM_CELL - CTM_RANGE, ou cpCam est la
       projection du point camera sur le plan des nuages. Cuiseur et lecteurs
       recalculent cette expression a l'identique a partir des SEULS uniformes
       cameraPosition / shadowLightPosition : meme frame -> meme valeur par
       construction, aucun uniform custom, aucun stockage d'origine.
   (B) LECTURE : ctmShadow(wp, lightW, darkness), 1 tap bilineaire, SANS
       sunUpF -> les faisceaux VIVENT au couchant. Hors carte -> 1.0
       (fail-open, comme partout dans le pack). Le fondu au ras de l'horizon
       est porte par les consommateurs (lightUp pour la marche, un
       smoothstep(-0.02, 0.06, L.y) pour fogSunVis).
   (C) DEUX CONSOMMATEURS : la marche VL proche prend ctmShadow A CHAQUE PAS
       (au lieu des 2 sondes), et fogSunVis devient une INTEGRALE ponderee de
       ctmShadow sur SHAFT_STEPS points du rayon.
   (D) SEGMENT LOINTAIN (sous-gate SHAFT_FAR, bloc dedie plus bas dans ce
       fichier) : au-dela de marchEnd, un SECOND segment de marche porte son
       PROPRE milieu d'aerosols, additif, dose par le palier (SHAFT_TAU), avec
       une phase qui melange le HG du tronc et un terme Rayleigh (SHAFT_ISO).
       C'est lui qui fait exister les colonnes AU LOIN et DE TOUS LES COTES
       SANS AUCUN brouillard analytique : les pieces (B) et (C) ci-dessus ne
       peuvent eclairer que le milieu qui existe deja, et une configuration qui
       coupe ATMO_FOG / HEIGHT_FOG / DAWN_MIST n'en a plus. Les brouillards, ou
       ils sont allumes, RENFORCENT le resultat (ils ajoutent leur propre
       milieu, lui aussi ombre par la carte) ; ils ne le conditionnent plus.

   PERIMETRE -- CE QUI NE CHANGE PAS, ET C'EST VOULU :
   . les ombres de nuages AU SOL (cloudShadow depuis shadeSurface, terrain
     differe, eau, particules, main) gardent leur sunUpF et leurs 9 taps :
     projeter une ombre NETTE au sol a 5 deg de soleil n'est pas le sujet ;
   . les godrays d'ecran de composite5.fsh (radial ancre sur le disque
     solaire) ne sont pas touches ;
   . cirrus et altocumulus ne sont PAS dans la carte : les ombres du pack ne
     connaissent que les cumulus, et un bord de faisceau doit tomber la ou
     tombe le bord d'ombre au sol ;
   . Nether / End : le cuiseur se termine par discard, les lecteurs rendent
     1.0 (meme neutralite que cloudShadow) ;
   . branches PROCEDURALES (VC_CUMULUS_SHAPES 0 ou VC_TEXTURED 0) : ECART
     ASSUME, la CTM est DESACTIVEE (CLOUD_SHAFTS_ACTIVE l'exige) et le code
     retombe mot pour mot sur les 2 sondes csA/csB et sur fogSunVis d'origine.
     Le proxy procedural de cloudShadow est une DUPLICATION du champ de
     lib/clouds.glsl (documentee sur place) : l'extraire une seconde fois
     aurait double la dette de synchronisation pour des branches qui ne sont
     ni le defaut ni livrees.

   PALIERS. Le cran pilote TROIS constantes :
     . SHAFT_AMB_K, le poids de l'ombre sur la part CIEL des brouillards
       analytiques (sans effet quand ils sont eteints) ;
     . SHAFT_TAU, l'epaisseur optique du milieu du SEGMENT LOINTAIN -- c'est
       lui qui dose la QUANTITE de brume porteuse quand il n'y a pas de
       brouillard du tout ;
     . SHAFT_ISO, la part de phase Rayleigh du segment lointain -- c'est lui
       qui rend les colonnes lisibles a 90 deg et DE DOS.
   Valeurs :  palier 1 K 0.25 / TAU 0.10 / ISO 0.35
              palier 2 K 0.45 / TAU 0.22 / ISO 0.55   (defaut)
              palier 3 K 0.65 / TAU 0.40 / ISO 0.75
   Detail et mesures des deux derniers : bloc "ROUND 2 : SEGMENT LOINTAIN".
   SHAFT_AMB_K (c'est CE terme qui rend les colonnes des brouillards visibles
   DE COTE, puisqu'a 90 deg du soleil le lobe pow(vdotS, 6) est nul) :
     0 Desactive  code d'origine BIT-IDENTIQUE (preuve par hash SPIR-V)
     1 Discret    K = 0.25, exactement le plancher actuel (0.75 + 0.25*v) :
                  meme amplitude qu'aujourd'hui, mais de vraies colonnes
     2 Naturel    K = 0.45, le defaut
     3 Marque     K = 0.65
   MESURE (ecart-type de fogShadAmb sur la bande d'horizon, vue a 90 deg du
   soleil, FOV 90, far 256) :
     soleil 10 deg : AVANT 0.0471 | palier 1 0.0267 | 2 0.0481 | 3 0.0694
     soleil 45 deg : AVANT 0.0340 | palier 1 0.0280 | 2 0.0504 | 3 0.0729
   L'ecart-type AVANT est en grande partie du BRUIT de deux sondes (voir
   cause 2) ; le palier 2 retrouve son amplitude avec une structure JUSTE.
   CE QUE "MARQUE" SACRIFIE, chiffre : sous ciel entierement couvert (pluie
   0.85, carte saturee) la valeur moyenne de fogShadAmb tombe a 0.896 (AVANT
   et palier 1), 0.812 (palier 2), 0.729 (palier 3), et son PLANCHER a 0.813 /
   0.663 / 0.514. A 3 le ciel d'orage devient franchement sombre : c'est le
   prix des colonnes les plus lisibles.

   COUT, MESURE EN TAPS PONDERES PAR LA DENSITE DE PIXELS (1080p, VL_HALF_RES
   1, couverture par defaut) : cloudShadowCheap coute en moyenne 1.99 taps de
   carte (early-out ciel clair sur 75.4 % du plan). AVANT : 2 sondes plein
   ecran + 2 sondes demi-res = 5.18 M EVALUATIONS COMPLETES du champ (chacune
   ~2 taps + ~40 ALU + un pow()). APRES : 1.05 M evaluations completes (la
   cuisson, cout FIXE, independant de la resolution) + 14.5 M taps bilineaires
   d'un R8 de 1 MiB tres coherent, au palier livre. Autrement dit -80 % du
   travail CHER, contre 2.5 fois plus d'ECHANTILLONS -- et ce sont ces
   echantillons qui font les colonnes. En taps bruts (unite qui ignore le cout
   ALU) : +1 % a VOLUMETRIC_QUALITY 0, +61 % a 1, +162 % a 2, +323 % a 3 ;
   +87 % en 1280x720, +46 % en 3840x2160 (la cuisson ne suit pas l'ecran).
   Je n'ai PAS mesure de temps de frame : le harnais ne fait que compiler.

   ROLLBACK : CLOUD_SHAFTS = 0 dans le menu. prepare2 continue d'exister mais
   chaque fragment y fait discard (RENDERTARGETS non gate, meme idiome que
   prepare.fsh) et tous les sites reprennent leur texte d'origine.
   ================================================================== */
// --- Sous-gates HORS MENU (pas de liste [..] : Iris ne doit pas les voir) ---
// CTM_RES : cote de la carte, en texels. MESURE (20 000 points, carte reelle
// cumulus_base.bin, vraies constantes) : l'erreur ne depend que de la TAILLE
// DE CELLULE, pas de CTM_RANGE. Cellule 4 b -> erreur moyenne 0.002, p99
// 0.06 ; 6 b -> 0.0035 / 0.11 ; 8 b -> 0.0055 / 0.15 ; 12 b -> 0.010 / 0.23.
// A L'ECRAN (le seul critere qui compte) : le contraste des colonnes est
// INSENSIBLE a la cellule de 12 b a 0 b (0.0276 -> 0.0282 d'ecart-type) ; seul
// le GRADIENT de bord bouge -- p95 0.00253 (cellule 12) / 0.00338 (6) /
// 0.00368 (4) / 0.00432 (exact). 1024^2 rend donc 78 % du gradient exact et
// 98.6 % du contraste, pour 1.05 M texels et 1 MiB.
// CONTROLE LE PLUS DUR (champ de vue ENTIER, FOV 90, 3 hauteurs de soleil x 3
// azimuts, marche 0-160 b ponderee densite) : la grille livree rend une
// moyenne EGALE a la reference sans grille a 1e-4 pres (0.7664 contre 0.7665 a
// 3 deg, 0.9864 contre 0.9865 a 10 deg) et 96.6 a 99.5 % de son amplitude de
// structure sur les 8 des 9 vues qui en portent une (la 9e est un ciel
// uniforme des DEUX cotes), avec 0.00 % du poids tombant hors carte. Les 2 sondes csA/csB
// qu'elle remplace donnaient, elles, 1.0000 a 3 deg (aucune ombre) et 0.69 a
// 0.89 la ou la verite est 0.95 a 1.00 : elles se trompent dans les DEUX sens.
// Passer a 1536^2 couterait 2.25 fois la cuisson pour +7 points de gradient.
#define CTM_RES 1024 // cote de la carte de transmittance, en texels
// CTM_RANGE : demi-etendue de la carte, en blocs, autour du point camera
// PROJETE sur le plan des nuages. Centrer sur cpCam (et non sur la camera)
// DIVISE PAR DEUX l'etendue necessaire : sans ce centrage il faudrait couvrir
// l'offset de projection ET son excursion, soit 2*k*(planeY - camY).
// MESURE de ce qui tombe hors carte, en PONDERANT par le poids reel du
// brouillard (moitie du poids dans les 265 premiers blocs au crepuscule) :
// RANGE 2048 perd 9.9 % du poids a 3 deg de soleil et 0.4 % a 5 deg ;
// RANGE 3072 perd 0.5 % a 3 deg et 0.0 % a 5 deg et au-dela. 3072 avec
// CTM_RES 1024 donne CTM_CELL = 6.0 blocs.
#define CTM_RANGE 3072.0 // demi-etendue de la carte, en blocs
#define CTM_CELL ((2.0 * CTM_RANGE) / float(CTM_RES)) // cote d'une cellule, en blocs
// CTM_MIN_LY : plancher sur la hauteur du soleil dans la PROJECTION de la
// carte (l'ancien code clampait a 0.25, ce qui figeait l'ombre bien avant le
// couchant). DERIVE DE LA PORTEE DE LA CARTE, pas du gout : a L.y = 0.05 le
// cisaillement vaut k = |L.xz|/L.y = 19.98, donc un point de marche 160 blocs
// SOUS la camera (la pire excursion verticale de la marche 0-160) se projette
// a 160 * 19.98 = 3197 blocs, c'est-a-dire exactement au bord de la carte
// (CTM_RANGE 3072, a 4 % pres). En dessous de ce plancher, allonger la
// projection ne ferait que sortir de la carte : on la fige.
#define CTM_MIN_LY 0.05 // plancher de L.y dans la projection de la carte
// SHAFT_FAR_DIST : borne de l'integrale de fogSunVis, en blocs. Le rayon
// utile est min(dist, SHAFT_FAR_DIST) : dist borne deja le rayon a la surface
// vue (pixel terrain / LOD DH) ou a 'far' (pixel ciel), donc cette constante
// n'agit QUE sur les pixels tres lointains (grandes distances de rendu, DH).
// MESURE du poids residuel au-dela, avec le profil d'ATMO_FOG : au crepuscule
// (sigma 0.00262/bloc a y=71) 6.8 % du poids reste au-dela de 1024 blocs ; en
// plein jour (sigma 0.00164) 18.6 %. Ce residu prend la moyenne des points
// echantillonnes -- biais vers le champ PROCHE, c'est-a-dire vers la partie
// que la marche dessine deja finement.
#define SHAFT_FAR_DIST 1024.0 // borne de l'integrale de brouillard, en blocs
// SHAFT_STEPS : nombre de points de l'integrale, DERIVE de VOLUMETRIC_QUALITY.
// MESURE de la stabilite temporelle AVANT TAA (ecart-type, sur 16 valeurs de
// jitter, du resultat d'un meme pixel ; soleil 10 / 45 deg) :
//   AVANT (2 sondes) 0.0942 / 0.1022
//   n = 3  0.0823 / 0.0615     n = 5  0.0508 / 0.0366
//   n = 8  0.0209 / 0.0212     n = 12 0.0172 / 0.0123
// Meme le cran le plus bas est donc DEJA plus stable qu'aujourd'hui, et le
// cran haut divise le scintillement par 6. Espacement : voir shaft_offsets
// dans composite1.fsh -- exponentiel (poids egal), MESURE non biaise (biais
// -0.0000, RMS 0.0019 des n = 3) la ou l'espacement LINEAIRE garde un biais
// de -0.021 (soleil 10 deg) a -0.035 (45 deg) QUEL QUE SOIT n, parce qu'il
// sur-echantillonne un lointain qui ne pese presque rien.
#if VOLUMETRIC_QUALITY == 0
#define SHAFT_STEPS 3 // points de l'integrale de brouillard
#elif VOLUMETRIC_QUALITY == 1
#define SHAFT_STEPS 5 // points de l'integrale de brouillard
#elif VOLUMETRIC_QUALITY == 2
#define SHAFT_STEPS 8 // points de l'integrale de brouillard
#else
#define SHAFT_STEPS 12 // points de l'integrale de brouillard
#endif
// SHAFT_AMB_K : poids de l'ombre sur la part CIEL du brouillard, par palier
// (fogShadAmb = (1 - K) + K * fogShadDir). K = 0.25 EST le plancher 75 %
// actuel : le palier 1 est donc iso-amplitude, seul le mecanisme change.
#if CLOUD_SHAFTS == 1
#define SHAFT_AMB_K 0.25 // part ciel ombrable, palier Discret
#elif CLOUD_SHAFTS == 2
#define SHAFT_AMB_K 0.45 // part ciel ombrable, palier Naturel
#elif CLOUD_SHAFTS == 3
#define SHAFT_AMB_K 0.65 // part ciel ombrable, palier Marque
#else
#define SHAFT_AMB_K 0.25 // inutilise a CLOUD_SHAFTS 0 (chemin legacy verbatim)
#endif

/* ---- ROUND 2 : SEGMENT LOINTAIN DE LA MARCHE (sous-gate SHAFT_FAR) ----
   POURQUOI. Les trois pieces du round 1 vivent dans un MILIEU qu'elles ne
   fabriquent pas : la marche VL proche (0-160 b) dans airDens, et l'integrale
   fogSunVis dans les brouillards ANALYTIQUES. Une configuration qui coupe
   ATMO_FOG, HEIGHT_FOG, DAWN_MIST et AERIAL_PERSPECTIVE -- ce que fait la
   configuration de reference de ce pack -- compile donc la piece (4) OUT et
   laisse la piece (3) travailler dans 0.0008/bloc borne a 160 blocs.
   MESURE (config sans brouillards, soleil 10 deg, bande d'horizon, unites =
   fraction de lightC) : amplitude des colonnes 0.00453 face au soleil,
   0.00026 a 90 deg, 0.00001 DOS AU SOLEIL. Autrement dit : rien au-dela de
   160 blocs, et rien du tout de dos.

   CE QUE FAIT CE SOUS-GATE. Apres la boucle proche, oeil SEC, un SECOND
   segment de marche va de marchEnd a farEnd avec son PROPRE milieu :
   . MILIEU : brume d'aerosols dediee, ADDITIVE. densFar(y) = SHAFT_DENS *
     exp(-max(y - WATER_LEVEL, 0) / SHAFT_H), plafonnee a la base de la dalle
     de cumulus (voir SHAFT_H). SHAFT_DENS = SHAFT_TAU / SHAFT_FAR_END, donc
     SHAFT_TAU EST l'epaisseur optique d'un rayon horizontal au niveau de la
     mer sur toute la portee : le palier dose une grandeur PHYSIQUE, pas un
     gain.
   . AUCUNE EXTINCTION N'EST APPLIQUEE A LA SCENE (transF, transHi/transLo et
     odUW sont intacts) : le segment ne fait qu'AJOUTER de la lumiere diffusee.
     ECART ASSUME, et c'est le point : l'extinction serait exactement le
     brouillard de distance que cette configuration a coupe volontairement
     (voile blanc sur les grandes villes). Ce que cet ecart coute est borne
     par tau : a SHAFT_TAU 0.22 un rayon horizontal de 3072 blocs "oublie"
     1 - exp(-0.22) = 19.7 % d'extinction au palier Naturel (9.5 % au palier
     Discret, 33.0 % au palier Marque), et bien moins sur tout rayon plus
     court ou plus haut. Le segment s'auto-attenue en revanche (transFar), donc
     il ne peut pas diverger avec la portee.
   . PHASE : mix(HG du tronc, Rayleigh, SHAFT_ISO). Le HG (g 0.60 + boost dusk)
     est un lobe AVANT : il est quasi nul a 90 deg et NUL de dos, c'est-a-dire
     precisement la ou le createur veut voir les rayons. Le terme Rayleigh
     3/(16 pi) * (1 + cos^2) vaut 0.0597 a 90 deg et 0.119 de dos contre 0.032
     et 0.024 pour le HG : c'est lui qui fait exister les colonnes de cote et
     de dos. MESURE, amplitude des colonnes au palier Naturel rapportee au
     round 1 seul (fraction de lightC, bande d'horizon, FOV 90) :
       soleil  3 deg : face x1.5 | 90 deg x2.2 | dos x11.7
       soleil 10 deg : face x1.3 | 90 deg x2.1 | dos x34.4
       soleil 45 deg : face x1.7 | 90 deg x2.2 | dos x10.4
     En STRUCTURE D'OMBRE PURE (ecart-type du champ divise par le meme champ
     sans nuages), soleil 10 deg : face au soleil 0.00001 -> 0.0282, dos
     0.0027 -> 0.0673. CE QUE SHAFT_ISO COUTE : il RETIRE de la brume face au
     soleil (0.0926 -> 0.0691 de lightC a ISO 0 -> 0.75, soleil 10 deg), donc
     le halo laiteux circumsolaire est plus faible aux paliers hauts, pas plus
     fort. La part moleculaire n'est PAS teintee en bleu : ces colonnes sont
     du SOLEIL diffuse, et une teinte froide sur un faisceau de coucher serait
     fausse. Le terme Rayleigh n'est pris que pour sa FORME ANGULAIRE (les
     parts spectrales reelles sont 1.2e-5/m moleculaire contre 1e-4..5e-4/m
     aerosols : c'est un ecart assume, la lisibilite laterale prime).
   . OMBRE : ctmShadow au pas courant (la carte du round 1) x un tap
     shadowtex1 tant que le pas est DANS la portee de la carte d'ombre
     (shadowDistance) -- les montagnes creusent la brume, et au-dela le tap
     n'est meme pas paye.
   . POIDS DE DONNEE : la ou la PROJECTION du pas sort de la carte de
     transmittance, ctmShadow fail-open a 1.0 -- ce qui ajouterait de la brume
     qu'AUCUNE colonne ne grave, c'est-a-dire un voile pur. Le segment y est
     donc FONDU (vlCtmDataW), meme regle que UW_SHAFT_FIX3 (C) : pas de
     donnee, pas de lumiere reclamee. MESURE de ce que cela retire (bande
     d'horizon, palier Naturel) : -19.4 % de brume a 3 deg de soleil dos au
     soleil (la vue ou 15.1 % du poids sort de la carte), -3.2 % a 3 deg /
     90 deg, -0.3 a -2.8 % a 10 deg, 0.0 % a 45 deg.
   . CONTINUITE A 160 BLOCS : les deux integrales sont cumulatives le long du
     MEME rayon, et pour un pixel terrain farEnd = min(distVol, portee) alors
     que marchEnd = min(distVol, 160) : la longueur du segment croit donc de 0
     quand distVol franchit 160 blocs. Aucune couture. MESURE (eventail de 30 a
     90 deg du soleil, 900 pixels) : saut maximal entre pixels voisins 2.1 a
     3.1 % de l'amplitude du profil (un escalier ferait 100 %). La DENSITE,
     elle, CHUTE d'un facteur 11.5 a 160 blocs (0.0008/bloc contre 6.94e-05) :
     le raccord ne peut pas produire une marche BRILLANTE, seulement une pente
     plus douce.
   PERIMETRE : oeil sec uniquement (isEyeInWater 0 et pas de base vitree),
   Overworld uniquement (Nether/End : retour a zero, meme test que ctmShadow),
   et rien d'autre du pack n'est touche -- le terme est simplement ajoute a
   scat, que composite1 applique deja par color = color*transF + scat*fogKeepW.
   ROLLBACK : SHAFT_FAR 0 -> la livraison du round 1, au bit pres (preuve par
   hash SPIR-V contre cs_post0 / cs_post2).                                  */
#define SHAFT_FAR 1 // segment lointain de la marche VL (0 = round 1 seul)
// SHAFT_FAR_END : portee du segment, en blocs. DERIVEE, pas choisie : au-dela
// de CTM_RANGE la projection de l'ombre sort de la carte, le poids de donnee
// tombe a 0 et le segment n'ajouterait plus que du voile. La portee du segment
// est donc EXACTEMENT la portee de la carte. MESURE du poids qui sort deja de
// la carte a cette portee, sur la bande d'horizon : 0.5 % (soleil 3 deg, face),
// 2.4 % (3 deg, 90 deg), 15.1 % (3 deg, dos), 4.0 % a 5 deg, 0.9 % a 10 deg,
// 0.0 % a 45 deg. Allonger a 4096 ou 6144 monterait ce hors-carte a 35 % et
// 41 % (moyenne du champ de vue) pour un gain nul.
#define SHAFT_FAR_END CTM_RANGE // portee du segment lointain, en blocs
// SHAFT_H : hauteur d'echelle du milieu, en blocs, ET son PLAFOND.
// TRANSPOSITION PHYSIQUE : la base des cumulus reels est vers 1500 m et la
// hauteur d'echelle des aerosols vers 1.2 km, soit un rapport base/echelle de
// 1.25 ; la base MC est a VC_BASE - WATER_LEVEL = 172 blocs, donc la meme
// optique demanderait 138 blocs (densite 0.287 a la base). CRITERE DU
// CHANTIER, qui l'emporte : l'air doit rester LUMINEUX ENTRE LES NUAGES, donc
// densite >= 0.5 a la base -> SHAFT_H >= 172/ln(2) = 248.1. On livre 250
// (densite 0.5045 a la base). ECART ASSUME de 250 contre 138 : le monde MC est
// verticalement comprime, et une couche calee sur la transposition brute
// laisserait les colonnes au ras du sol. MESURE de ce que H change (soleil
// 10 deg, azimut 90 deg, bande d'horizon) : amplitude des colonnes 0.00041
// (H 137) / 0.00065 (250) / 0.00087 (400), et rapport zenith/horizon de la
// brume 0.020 / 0.064 / 0.130 -- a 250 un rayon qui monte a bien SORTI de la
// couche (6.4 % de la valeur d'horizon a 80 deg d'elevation).
// PLAFOND DE COUCHE : la densite est eteinte a la base de la dalle de cumulus
// par (1 - smoothstep(VC_BASE - VC_THICK*0.33, VC_BASE, y)). Ce n'est pas un
// artifice : les cumulus se forment SUR l'inversion qui plafonne la couche
// melangee, donc les aerosols s'arretent la ou les nuages commencent. La
// largeur du fondu est le VC_THICK*0.33 que le pack utilise deja partout comme
// barycentre de densite de la dalle. CONSEQUENCE MESUREE : le segment ne peut
// pas voiler un nuage DEJA DESSINE, puisqu'il s'eteint a son plancher.
// ECART ASSUME au cahier des charges, qui proposait un clip d'extremite par la
// couverture premultipliee de colortex15 : le plafond fait le meme travail en
// MIEUX et sans nouveau sampler. MESURE, soleil 10 deg, brume ajoutee :
//   pixels les plus couverts : 0.01604 sans rien / 0.01142 clip couverture /
//   0.01013 plafond (le plafond coupe 37 % contre 29 % pour le clip) ;
//   bande de CIEL entiere : 0.00619 / 0.00610 / 0.00138 (4.5 fois moins).
// Le plafond ne depend en outre ni de CLOUD_HALF_RES ni de CLOUD_TEMPORAL :
// il n'y a aucune configuration ou un repli soit a decrire.
#define SHAFT_H 250.0 // hauteur d'echelle du milieu lointain, en blocs
// SHAFT_FAR_EDGE : largeur de la rampe de bord de la carte pour le poids de
// donnee, en fraction du cote uv. 0.04 * 2 * CTM_RANGE = 246 blocs de plan :
// assez large pour que la disparition du terme se dissolve au lieu de tracer
// un bord net dans le ciel, assez etroite pour ne pas manger le coeur utile.
#define SHAFT_FAR_EDGE 0.04 // rampe de bord de carte du poids de donnee
// SHAFT_FAR_STEPS : points du segment lointain, DERIVE de VOLUMETRIC_QUALITY.
// MESURE de la stabilite temporelle AVANT TAA (ecart-type RELATIF, sur 16
// valeurs de jitter d'un meme pixel, bande d'horizon a 90 deg du soleil) :
//   pas       4      6      8      12     16     24
//   3 deg   0.167  0.134  0.103  0.074  0.060  0.039
//   45 deg  0.144  0.101  0.080  0.060  0.041  0.027
// Strictement decroissante a chaque cran. On livre 6 / 8 / 12 / 16 : le cran
// le plus bas reste sous 0.14 et le cran haut divise le scintillement par 2.8.
// Le terme est ADDITIF et petit devant la scene (0.005 a 0.02 de lightC selon
// l'azimut), et TAA moyenne encore : cet ecart-type relatif se lit sur une
// contribution deja faible.
#if VOLUMETRIC_QUALITY == 0
#define SHAFT_FAR_STEPS 6 // points du segment lointain
#elif VOLUMETRIC_QUALITY == 1
#define SHAFT_FAR_STEPS 8 // points du segment lointain
#elif VOLUMETRIC_QUALITY == 2
#define SHAFT_FAR_STEPS 12 // points du segment lointain
#else
#define SHAFT_FAR_STEPS 16 // points du segment lointain
#endif
// SHAFT_TAU : epaisseur optique du milieu lointain sur un rayon HORIZONTAL au
// niveau de la mer et sur toute la portee. C'est CE terme qui dose la QUANTITE
// de brume porteuse au palier, la ou SHAFT_AMB_K dose la part ciel des
// brouillards pour ceux qui les ont. MESURE de la brume ajoutee (fraction de
// lightC, bande d'horizon, soleil 10 deg) : face au soleil +0.011 / +0.019 /
// +0.024 aux paliers 1/2/3 sur un round 1 a 0.050 ; de dos +0.0016 / +0.0049 /
// +0.0109 sur un round 1 a 0.0015. Le palier 3 TRIPLE donc la brume de dos.
// SHAFT_ISO : part de phase Rayleigh (voir le bloc ci-dessus). Croissante avec
// le palier : plus le cran est haut, plus les colonnes existent DE TOUS LES
// COTES -- et moins le halo circumsolaire est fort.
#if CLOUD_SHAFTS == 1
#define SHAFT_TAU 0.10 // epaisseur optique du milieu lointain, palier Discret
#define SHAFT_ISO 0.35 // part Rayleigh de la phase, palier Discret
#elif CLOUD_SHAFTS == 2
#define SHAFT_TAU 0.22 // epaisseur optique du milieu lointain, palier Naturel
#define SHAFT_ISO 0.55 // part Rayleigh de la phase, palier Naturel
#elif CLOUD_SHAFTS == 3
#define SHAFT_TAU 0.40 // epaisseur optique du milieu lointain, palier Marque
#define SHAFT_ISO 0.75 // part Rayleigh de la phase, palier Marque
#else
#define SHAFT_TAU 0.22 // inutilise a CLOUD_SHAFTS 0 (chemin legacy verbatim)
#define SHAFT_ISO 0.55 // inutilise a CLOUD_SHAFTS 0 (chemin legacy verbatim)
#endif
// VL_STRENGTH NE MULTIPLIE PAS SHAFT_TAU -- ecart assume, et c'est le
// PRECEDENT DU PACK : VL_STRENGTH est le dial de l'AIR de la marche proche
// (airDens = 0.0008 * VL_STRENGTH) et AUCUN autre milieu ne le suit (le
// brouillard de hauteur a HEIGHT_FOG_DENSITY, la brume d'aube a
// DAWN_MIST_STRENGTH, le Nether NETHER_FOG_DENSITY, l'End END_HAZE_DENSITY --
// ces deux derniers REMPLACENT meme airDens). Le milieu lointain a de meme son
// propre dial : le palier, via SHAFT_TAU. La raison chiffree de ne pas les
// coupler : VL_STRENGTH monte jusqu'a 20, ce qui porterait l'epaisseur optique
// du segment a 0.22 * 20 = 4.4, c'est-a-dire un mur opaque (98.8 % de brume
// sur un rayon horizontal) -- exactement le voile que ce chantier evite.
// L'interrupteur de ce terme est le cran "Rayons de nuages : Desactive".

// ---------------- RAYONS DU SOLEIL (SUNRAY_QUALITY) ----------------
// Godrays de l'air (GODRAY_SAMPLES, ex-VOLUMETRIC_QUALITY) + puits de lumiere
// sous l'eau : nombre de sous-pas par pas de marche et distance de rendu.
// CE CRAN AMELIORE : la CONTINUITE des rayons (moins de marches d'escalier) et
// leur PORTEE sous l'eau.
// MESURE 1 : GODRAY_SAMPLES = pas de la marche ecran des godrays, sur une
// longueur ecran FIXE (composite5.fsh l.1679 : stepG = (suvG - uv)/samples).
// Le pas vaut donc 1/6, 1/8, 1/12, 1/16 de cette longueur : chaque cran
// raccourcit strictement le pas -> 6 / 8 / 12 / 16.
// MESURE 2 : UW_SHAFT_RENDER_DIST = distance de chemin IMMERGE (blocs) a
// laquelle les puits de lumiere sous-marins s'ETEIGNENT ET s'ARRETENT :
// fondu entre 0.7x et 1.0x, puis, au-dela de 1.0x, les taps du champ de
// caustiques du pas ne sont plus payes du tout (vraie borne de marche,
// voir UW_SHAFT_BOUND dans le bloc UW_VOLUMETRICS) ->
// 12 / 24 / 32 / 48 : strictement croissante a chaque cran, et le COUT des
// faisceaux suit la meme monotonie puisque seuls les pas sous la borne payent.
// MESURE 3 : UW_SHAFT_SUBSTEPS = PLAFOND du nombre de taps du champ de
// caustiques par pas de marche (1 tap par ~4 blocs de pas, borne ici) ->
// 1 / 3 / 3 / 4. PLATEAU ASSUME entre les paliers 1 et 2 : au-dela de 3 taps le
// plafond n'est atteint que si le pas depasse 12 blocs, c'est-a-dire seulement
// a VOLUMETRIC_QUALITY 0 ou 1. Monter le plafond au palier 2 ne changerait donc
// RIEN sur une configuration deja "Eleve" partout. Les deux autres mesures
// bougent a ce cran, il n'est pas mort.
// MESURE 4 : UW_SHAFT_VIEW_DIST (PERF_OCEAN, oeil hors de l'eau seulement) =
// distance CAMERA (blocs) a laquelle les filaments immerges s'eteignent AUSSI,
// en PLUS de la borne de chemin immerge ci-dessus -> 96 A TOUS LES PALIERS.
// DEUX CAS a distinguer, ils n'ont pas le meme statut :
//  - isEyeInWater == 1 (plongeur) : uwCamB == uwPathB et la borne de CHEMIN
//    (12/24/32/48) mord toujours la premiere -- la borne camera est INERTE.
//  - oeil sec : la borne camera est la seule des deux indexee sur la distance
//    a l'ecran, et c'est elle qui agit. Elle doit donc etre SUB-JND partout
//    ou elle coupe, a tous les paliers qui la livrent.
// DERIVATION (pas un gout) : une striation fine fait 0.26-0.4 bloc
// (lib/water.glsl, vlCa4Vol / CALIBRATION V5) ; a 1080p et FOV vertical 70 deg
// elle couvre (0.3/d) * 1080 / (2*tan(35 deg)) = 231/d px -> 2.4 px a 96
// blocs, le SEUL point ou le critere sub-JND est tenu. Les anciennes bornes
// par palier (32/48/64) donnaient 7.2/4.8/3.6 px : des structures RESOLUES a
// l'ecran, coupees devant l'oeil -- et au palier livre (SUNRAY_QUALITY 1,
// borne 48) un lac a 55 blocs perdait la TOTALITE de ses puits de lumiere,
// annulant frontalement l'intention de UW_SHAFTS_UNIFIED (d1) : "a lake 40
// blocks away keeps its beams". D'ou le plancher uniforme : la borne camera ne
// peut jamais mordre avant que la borne de CHEMIN du palier ait fini son
// travail, quelle que soit la distance d'entree dans l'eau. Le cout est
// marginal : la fenetre 69..96 blocs ne couvre que quelques % des pixels
// d'ocean vus de la berge (la borne de chemin fait le reste).
// Palier 1 = les valeurs livrees (8 / 3 / 24.0 / 96.0).
#if SUNRAY_QUALITY == 0
#define GODRAY_SAMPLES 6
#define UW_SHAFT_SUBSTEPS 1
#define UW_SHAFT_RENDER_DIST 12.0
#define UW_SHAFT_VIEW_DIST 96.0
#elif SUNRAY_QUALITY == 1
#define GODRAY_SAMPLES 8
#define UW_SHAFT_SUBSTEPS 3
#define UW_SHAFT_RENDER_DIST 24.0
#define UW_SHAFT_VIEW_DIST 96.0
#elif SUNRAY_QUALITY == 2
#define GODRAY_SAMPLES 12
#define UW_SHAFT_SUBSTEPS 3
#define UW_SHAFT_RENDER_DIST 32.0
#define UW_SHAFT_VIEW_DIST 96.0
#else
#define GODRAY_SAMPLES 16
#define UW_SHAFT_SUBSTEPS 4
#define UW_SHAFT_RENDER_DIST 48.0
#define UW_SHAFT_VIEW_DIST 96.0
#endif

// ---------------- VAGUES (WAVE_QUALITY) ----------------
// Remplace l'ancien axe WATER_QUALITY, qui ne pilotait que WAVE_ITERATIONS.
// WAVE_ITERATIONS = trains de houle (v2), WAVE3_SCALES = barreaux de l'echelle
// WAVES_V3, WAVE3_PARALLAX = pas d'occlusion de parallaxe sur l'eau proche.
// CE CRAN AMELIORE : le NOMBRE D'ECHELLES DE DETAIL visibles sur la mer, et le
// RELIEF de l'eau proche.
// MESURE 1 : WAVE3_SCALES = octaves de l'echelle WAVES_V3, chacune ajoutant une
// frequence de vague plus fine -> 4 / 5 / 6 / 8. C'est la mesure principale :
// elle bouge a CHAQUE cran.
// MESURE 2 : WAVE3_PARALLAX = pas de la marche d'occlusion de parallaxe sur
// l'eau proche -> 0 (aucun relief, surface plate) / 4 / 6 / 12. Bouge aussi a
// chaque cran, et le passage 0 -> 4 est le plus visible de l'axe.
// MESURE 3 : WAVE_ITERATIONS = trains de houle v2 -> 2 / 3 / 3 / 4. PLATEAU
// ASSUME entre les paliers 1 et 2 : au-dela de 3 trains la mer devient illisible
// (voir la note d'origine ci-dessous), le cran 2 achete de la finesse
// (WAVE3_SCALES) et du relief (WAVE3_PARALLAX), pas de la houle en plus.
// Palier 2 = les valeurs livrees (3 / 6 / 6).
#if WAVE_QUALITY == 0
#define WAVE_ITERATIONS 2
#define WAVE3_SCALES 4
#define WAVE3_PARALLAX 0
#elif WAVE_QUALITY == 1
#define WAVE_ITERATIONS 3
#define WAVE3_SCALES 5
#define WAVE3_PARALLAX 4
#elif WAVE_QUALITY == 2
#define WAVE_ITERATIONS 3
#define WAVE3_SCALES 6
#define WAVE3_PARALLAX 6
#else
#define WAVE_ITERATIONS 4
#define WAVE3_SCALES 8
#define WAVE3_PARALLAX 12
#endif
// 3 wave iterations by default, 4 only at Very high: fewer wave trains keeps
// the sea readable.

// ---------------- CAUSTIQUES (CAUSTIC_QUALITY) ----------------
// CE CRAN AMELIORE : la JUSTESSE du filet de caustiques sous l'eau.
// MESURE : il n'y a pas de compteur d'echantillons ici - l'axe change
// d'ESTIMATEUR, et la mesure est donc qualitative mais discrete et verifiable :
//   0 -> 1 : la densite de photons cesse d'etre une formule analytique (v3) et
//            devient un vrai estimateur lu sur la mer WAVES_V3 (v4+v5). Le
//            filet suit alors la houle reellement rendue.
//   1 -> 2 : la mise en forme v6 remplace un pochoir a deux tons par une
//            caustique CONTINUE (degrade au lieu de clair/sombre).
// Chaque cran allume un etage supplementaire et n'en eteint aucun : monotone
// par construction. COUT : v4/v5 ajoutent la lecture du champ de vagues, v6 une
// mise en forme par pixel touche - negligeable devant la marche VL.
// Les trois A/B documentes du filet de densite de photons (lib/water.glsl) :
//   0 Bas    = caustiques ANALYTIQUES v3 (CAUSTICS_V4 = 0 : v4/v5/v6 ne sont
//              meme pas lues), le chemin le moins cher.
//   1 Moyen  = estimateur v4 lu sur la mer WAVES_V3 (v5), mise en forme v4.
//   2 Eleve  = + mise en forme v6 (caustique continue au lieu d'un pochoir
//              deux tons). PALIER LIVRE.
// Seuls deux etats seraient "utiles" si l'on ne comptait que v4 ; v6 change
// assez le rendu pour meriter son cran, d'ou 3 paliers et non 4.
#if CAUSTIC_QUALITY == 0
#define CAUSTICS_V4 0
#define CAUSTICS_V5 0
#define CAUSTICS_V6 0
#elif CAUSTIC_QUALITY == 1
#define CAUSTICS_V4 1
#define CAUSTICS_V5 1
#define CAUSTICS_V6 0
#else
#define CAUSTICS_V4 1
#define CAUSTICS_V5 1
#define CAUSTICS_V6 1
#endif

// ---------------- REFLETS / SSR (REFLECT_QUALITY) ----------------
// Budget du SEUL raymarch qui dessine tous les reflets du pack (composite1
// ssrRay : eau, verre, PBR opaque).
// CE CRAN AMELIORE : la PORTEE du reflet (jusqu'ou un objet hors champ proche
// est encore retrouve a l'ecran) et la PRECISION du point d'impact.
// MESURE 1 : SSR_STEPS = nombre de pas de la marche. Le pas croit
// geometriquement (facteur 1.22, borne en pixels), donc la distance couverte
// croit vite avec le nombre de pas : 20 / 28 / 40 / 64.
// MESURE 2 : SSR_REFINE = bisections apres le croisement. La longueur du pas
// residuel est divisee par 2^SSR_REFINE, donc l'erreur sur le point d'impact
// est divisee par 16 / 32 / 64 / 256 : c'est ce qui empeche un reflet de
// "glisser" le long d'une arete. Elle entre aussi dans la fenetre
// d'acceptation ssrTol().
// Palier 2 = les valeurs livrees (40 / 6).
// BUG CORRIGE (audit des paliers) : le palier 3 posait SSR_FAST 0. Or
// SSR_FAST n'est PAS un marcheur a demi-pas : composite1.fsh l.944-955 le dit
// explicitement - "SSR_FAST does not change the marching scheme; it removes the
// per-step mat4 work instead", meme depart, meme croissance 1.22, meme nombre
// de bisections, meme validation, "result identical up to float rounding". Le
// chemin rapide suit clip incrementalement (clipP += clipD*stepLen) parce que
// la projection est AFFINE en p, et projette chaque milieu de bisection comme
// la MOYENNE des clips des bornes - ce qui est exact, pas approche. Mettre
// SSR_FAST a 0 au dernier cran faisait donc payer ~12 MAD de plus par pas et
// par bisection pour EXACTEMENT la meme image. Le cran devient 1 partout ; ce
// qui achete vraiment quelque chose au palier 3, ce sont les 64 pas et les 8
// bisections. L'infobulle du menu qui promettait "pas complet ou demi-pas" a
// ete corrigee dans les deux .lang.
// SSR_FAST EST DONC SORTI DE LA CHAINE #if : les quatre branches posaient la
// meme valeur 1, ce qui laissait croire a un levier de palier alors qu'il n'en
// est plus un. Il est pose UNE SEULE FOIS ci-dessous. NE JAMAIS LE REBRANCHER
// SUR UN AXE : le re-etager reintroduirait exactement le bug corrige au-dessus.
#define SSR_FAST 1
#if REFLECT_QUALITY == 0
#define SSR_STEPS 20
#define SSR_REFINE 4
#elif REFLECT_QUALITY == 1
#define SSR_STEPS 28
#define SSR_REFINE 5
#elif REFLECT_QUALITY == 2
#define SSR_STEPS 40
#define SSR_REFINE 6
#else
#define SSR_STEPS 64
#define SSR_REFINE 8
#endif

// ---------------- MATIERES PBR (PBR_QUALITY) ----------------
// CE CRAN AMELIORE : le FLOU du reflet sur les matieres RUGUEUSES (une pierre
// polie, un metal brosse : leur reflet doit s'etaler, pas montrer 2 fantomes).
// MESURE : PBR_ROUGH_TAPS = PLAFOND du nombre de rayons GGX par pixel ->
// 1 / 2 / 3 / 4. Le nombre naturel depend de la rugosite du materiau
// (composite1.fsh l.3724 : 2 sous alpha 0.09, 3 sous 0.30, 4 au-dela), donc
// chaque cran DEBLOQUE une bande de materiaux supplementaire :
//     1 : un seul rayon partout (cout legacy ; le flou ne vient plus que du
//         filtre d'empreinte ecran et du TAA)
//     2 : les metaux polis (fer alpha 0.017, or 0.047) passent a 2 rayons
//     3 : la bande alpha 0.09-0.30 (bois, quartz...) passe a 3   <- livre
//     4 : la bande alpha >= 0.30, soit smoothness <= 0.452, atteint enfin ses
//         4 rayons - jamais atteinte avant ce cran
// Second effet, non negligeable : l'ETALEMENT angulaire est plafonne par le
// nombre de rayons (alphaDir = min(alpha, 0.25 + 0.09*nTaps)), donc le cran 4
// fait aussi passer le cone de 0.52 a 0.61 sur ces materiaux. Un rayon de plus
// = un ssrRay + un getSkyAll, et seulement sur les pixels concernes (ils sont
// de toute facon ignores de face).
// PBR_ROUGH_TAPS = taps du flou de rugosite des reflets. Palier 2 = la valeur
// livree (3).
// PAS DE POM_SAMPLES ICI : le seul POM du pack (gbuffers_terrain.fsh, sous
// "#if defined PBR_TEXTURES && defined PBR_POM") est un parallax a UN SEUL tap
// qui ne lit que POM_DEPTH - il n'y a aucune boucle de marche a piloter. Un
// POM_SAMPLES derive de cet axe serait un symbole mort et l'infobulle
// promettrait au joueur un gain FPS inexistant. Si une vraie marche POM est
// implementee un jour, la rebrancher ici (et remettre le POM dans les .lang).
#if PBR_QUALITY == 0
#define PBR_ROUGH_TAPS 1
#elif PBR_QUALITY == 1
#define PBR_ROUGH_TAPS 2
#elif PBR_QUALITY == 2
#define PBR_ROUGH_TAPS 3
#else
#define PBR_ROUGH_TAPS 4
#endif

// ---------------- LUMIERE INDIRECTE (GI_QUALITY) ----------------
// CE CRAN AMELIORE : d'abord la FINESSE du rebond de lumiere (moins de bruit,
// ombres de contact plus propres), puis sa PORTEE (le rebond HORS ECRAN
// s'allume), puis sa RESOLUTION.
// MESURE 1 : nombre d'echantillons par pixel du rebond ecran (SSGI) et du
// rebond hors-ecran (RSM).
//     palier 0 :  4 SSGI /  RSM eteint
//     palier 1 :  8 SSGI /  RSM eteint   <- palier livre
//     palier 2 : 12 SSGI / 16 RSM        <- le rebond hors-ecran APPARAIT
//     palier 3 : 24 SSGI / 24 RSM
// MESURE 1bis (posee par cette passe) : PRESENCE du rebond hors-ecran.
// C'est le saut le plus visible de l'axe, et c'est un saut de NATURE, pas de
// finesse : le SSGI ne peut faire rebondir que ce que la camera voit deja, donc
// une falaise de gres juste hors champ n'eclaire rien. Le RSM lit la shadow map
// : c'est le seul chemin du pack qui ramene de la couleur depuis le hors-champ.
// CE QUE "HORS-CHAMP" VEUT DIRE ICI, EXACTEMENT (limite reelle, a ne pas
// survendre) : shaders.properties pose shadow.culling = true, et sa propre doc
// dit que le culling light-aware ne garde que les sections capables de projeter
// DANS le frustum de vue. La shadow map n'est donc PAS un disque a 360 degres
// autour du joueur : c'est le frustum de vue EXTRUDE VERS LE SOLEIL. Le RSM
// ramene donc bien la falaise de gres juste hors cadre et le mur derriere le
// joueur QUAND ILS SONT DU COTE DU SOLEIL, et pas quand ils n'y sont pas ; et
// ce qui est du cote du soleil change quand la camera tourne, donc une part du
// rebond peut POPER sur une rotation (exactement le comportement deja
// documente pour la height map de lave du Nether). L'accumulation temporelle
// sur 12 images etale ce pop en trainee courte au lieu de le supprimer.
// shadow.culling = reversed (deja propose pour le Nether dans
// shaders.properties) achete une map stable a 360 degres contre du temps GPU :
// c'est le reglage a tester si le pop se voit. Il s'allume donc aux
// deux derniers crans (demande du createur : "en profil, les 2 derniers, Extreme
// et le truc la, j'aimerais que tu actives le RSM"), via la porte derivee
// VLX_RSM_ACTIVE (section RSM plus bas) - PAS en epinglant RSM_GI dans les
// profils : ce sont les paliers qui pilotent, pas les profils.
// La case "Rebond hors ecran (RSM)" du menu reste utile : elle FORCE le RSM aux
// paliers 0 et 1 (elle est donc le maitre atteignable a tous les crans).
// MESURE 2 : nombre de pixels reellement ombres. GI_HALF_RES = 1
// n'ombre que le quadrant inferieur gauche de colortex4/6 (1 texel = 1 pixel
// plein ecran a uv*2, ~4x moins de pixels) et composite1 reexpand avec un
// upsample bilateral profondeur+normale a 4 taps.
//     paliers 0/1/2 : demi-resolution (1/4 des pixels)
//     palier 3      : PLEINE resolution (chemin d'origine, bit-identique au
//                     pack pre-demi-resolution)
// LACUNE CORRIGEE (audit des paliers, question "un parametre de cout important
// sous AUCUN axe") : GI_HALF_RES etait le plus gros levier de cout ET de
// qualite de toute la chaine GI, et il restait fige a 1 quel que soit le
// palier. "Tres eleve" achetait donc 2x plus d'echantillons... etales sur un
// quart des pixels, puis relisses par l'upsample - exactement le genre de cran
// qui ne se voit pas. En pleine resolution, les silhouettes et les coins
// cessent d'etre reconstruits par interpolation : c'est le saut visible du
// dernier cran. Cout : ~x4 sur la passe GI, au palier 3 uniquement.
// MONOTONIE, VERIFIEE CRAN PAR CRAN (chaque cran doit se VOIR) :
//   0 -> 1  x2 echantillons SSGI (4 -> 8). NUANCE (verif GI-RSM) : le bruit
//           Monte-Carlo decroit en 1/sqrt(N), donc sigma ne baisse que de
//           x1.41, et le residu passe ENSUITE par l'upsample bilateral (4
//           texels demi-res moyennes) puis la moyenne temporelle glissante
//           (~12.5 images) - en scene STATIQUE l'ecart est a la limite du
//           perceptible. Ce cran achete surtout de la stabilite EN MOUVEMENT,
//           quand l'historique temporel est rejete et que le bruit d'une
//           seule image se voit.
//   1 -> 2  +50 % d'echantillons SSGI ET le rebond HORS ECRAN s'allume : de la
//           couleur arrive de geometrie que la camera ne voit pas. C'est le plus
//           gros saut de l'axe, et il est qualitatif.
//   2 -> 3  x2 echantillons SSGI, +50 % RSM, et PLEINE resolution : les
//           silhouettes et les coins cessent d'etre reconstruits par
//           interpolation.
// L'axe reste sans effet si SSGI est eteint ET que le RSM ne s'allume pas
// (paliers 0/1 avec la case RSM decochee).
// RSM_SAMPLES garde une valeur > 0 aux paliers 0/1 meme si le RSM y est eteint
// par defaut : la case du menu peut le rallumer, et le nombre sert alors de
// diviseur (un 0 serait une division par zero a la compilation du chemin RSM).
//
// ---- COUT MESURE (taps de texture par PIXEL D'ECRAN, composite.fsh) ----
// Compte par echantillon, mortalite des "continue" incluse (~60 % des taps SSGI
// atteignent les 3 lectures suivantes, ~50 % des taps RSM atteignent la
// reconstruction de normale) :
//   SSGI  ~2.8 taps/echantillon   (profondeur, normale, flags, couleur)
//   RSM   ~3.0 taps/echantillon   (profondeur d'ombre, albedo bande, 2 taps de
//                                  normale, 1 tap de rejet ecran)
//   SSAO   1.0 tap/echantillon    + 2 taps de reprojection temporelle par pixel
// Un texel demi-resolution couvre 4 pixels d'ecran, d'ou la division par 4 aux
// paliers 0/1/2 :
//   palier 0    19 taps / texel  ->  ~4.8 taps / pixel d'ecran
//   palier 1    34 taps / texel  ->  ~8.6
//   palier 2    98 taps / texel  -> ~24.6
//   palier 3   160 taps / PIXEL  -> ~160, plus le COTE composite1 recompte :
//              +15 taps/pixel nets, pas +8. Detail : giFilter3 fait 9 taps
//              colortex4 (centre + 8 voisins) et 9 taps colortex1 (le poids de
//              normale ajoute par la passe GI-RSM), et surtout GI_HALF_RES = 0
//              REACTIVE le bilateral AO pleine resolution (9 colortex4 +
//              9 colortex6 = 18 taps) que le chemin demi-res saute entierement,
//              tout en perdant les 12 taps de giUpsample. Total palier 3
//              ~197 taps/pixel.
// Ordre de grandeur en ms a 1080p sur la RTX 5080 du createur, scene exterieure
// de jour (le pire cas pour cet axe) : ~0.3 / 0.5 / 1.2 / 3-6 ms pour la passe
// composite (fourchette haute tant que ce n'est pas mesure sur la machine
// cible : les ~72 taps RSM du palier 3 sont des acces ALEATOIRES et incoherents
// dans une shadow map 4k/8k, le pire cas pour le cache de texture, et la
// reconstruction de normale paie desormais 2 pow() par echantillon survivant
// pour lire aux VRAIES uv distordues - correction de base, voir composite.fsh).
// Le palier 3 est donc bien "un cran de carte haut de gamme", pas un
// cran gratuit - c'est deja ce que dit shaders.properties, qui nomme GI_QUALITY
// comme le premier cran a baisser si le fps ne suit pas.
// CE QUI EMPECHE LE RSM DE FAIRE S'EFFONDRER LES FPS : trois portes anticipees
// (composite.fsh, bloc RSM) sautent la boucle ENTIERE, pas seulement son
// resultat. Ciel du recepteur nul (grotte, interieur), soleil sous l'horizon
// (toute la nuit), recepteur au-dela de RSM_FADE_FAR blocs. Dans une scene
// reelle elles retirent la majorite des pixels : la nuit le RSM coute ZERO, en
// grotte zero, et en paysage ouvert seuls les ~40-60 % de pixels a moins de
// 112 blocs paient. Les chiffres ci-dessus sont le plafond, pas la moyenne.
// La meme porte "soleil" a ete posee sur le SSGI, qui la payait deja par
// echantillon sans jamais en sortir : le SSGI aussi coute maintenant zero la
// nuit, a resultat identique au bit pres.
#if GI_QUALITY == 0
#define SSGI_SAMPLES 4
#define RSM_SAMPLES 8
#define GI_HALF_RES 1
#elif GI_QUALITY == 1
#define SSGI_SAMPLES 8
#define RSM_SAMPLES 12
#define GI_HALF_RES 1
#elif GI_QUALITY == 2
#define SSGI_SAMPLES 12
#define RSM_SAMPLES 16
#define GI_HALF_RES 1
#else
#define SSGI_SAMPLES 24
#define RSM_SAMPLES 24
#define GI_HALF_RES 0
#endif

// ---------------- NETTOYAGE DU REBOND (DENOISE_QUALITY) ----------------
// Retour createur (mission DEN) : "ca clignote un peu de partout ; rajouter
// quality du denoiser". CE CRAN AMELIORE : la STABILITE de la lumiere
// indirecte (moins de scintillement image a image), a resultat moyen inchange.
// Il pilote le SEUL etage SPATIAL du denoiser GI (les anneaux a-trous du cote
// lecture, composite1 giUpsample / giFilter3) ; l'etage TEMPOREL (clamp de
// variance, composite.fsh) est actif a TOUS les paliers via la porte
// GI_DENOISE_V2 ci-dessous - c'est lui le gros du gain, et il est gratuit.
// MESURE (modele numerique den_model2.py, scintillement = moyenne du |delta|
// image-a-image du pixel GI affiche, camera fixe, GI_QUALITY 2, x1.00 = le
// pack avant cette passe ; "clairseme" = bord de lobe de rebond / RSM
// lointain, la ou le createur voit "partout" clignoter) :
//     palier 0 : x0.36  (x0.20 clairseme)   +0 tap        <- palier livre
//     palier 1 : x0.27  (x0.15 clairseme)   +8 taps/pixel
//     palier 2 : x0.24  (x0.13 clairseme)   +16 taps/pixel
//     palier 3 : x0.24 en bruit fort, converge vers la nettete du palier 0
//                sur une image deja propre (poids des anneaux pilotes par le
//                sigma accumule de colortex6.b) ; memes taps que le palier 2.
// MONOTONIE : chaque cran reduit le residu OU (palier 3) rend la meme
// reduction plus nette la ou elle n'est pas necessaire. Le DEFAUT est 0 :
// c'est le cran qui reproduit le cout actuel a epsilon pres (mesure au
// SPIR-V : +0 tap de texture des deux cotes -- composite1 a DQ0 est
// BIT-IDENTIQUE a l'ancien -- et +87 ops statiques dans composite.fsh a
// GI_QUALITY 1, +137 au 2, du pur ALU sur ~6800/7700 ops, soit ~1.5 %),
// regle de non-regression du menu. Les profils suivent 0/1/2/3.
// COUT (taps de texture par PIXEL D'ECRAN opaque, cote composite1) :
//   demi-res (GI_QUALITY 0-2) : giUpsample 12 -> 12 / 20 / 28 / 28
//   pleine res (GI_QUALITY 3) : giFilter3  18 -> 18 / 26 / 34 / 35
// L'axe est SANS EFFET si le SSGI est eteint ET que le RSM ne s'allume pas
// (memes maitres que GI_QUALITY ; la porte VLX_DEN_ACTIVE, section DENOISE GI
// plus bas, ne s'ouvre que la).
// VLX_DEN_RINGS = anneaux a-trous du cote lecture (0/1/2), VLX_DEN_ADAPT =
// rayon pilote par la variance locale (palier 3 seulement). Valeurs derivees,
// pas des options de menu.
#if DENOISE_QUALITY == 0
#define VLX_DEN_RINGS 0
#define VLX_DEN_ADAPT 0
#elif DENOISE_QUALITY == 1
#define VLX_DEN_RINGS 1
#define VLX_DEN_ADAPT 0
#elif DENOISE_QUALITY == 2
#define VLX_DEN_RINGS 2
#define VLX_DEN_ADAPT 0
#else
#define VLX_DEN_RINGS 2
#define VLX_DEN_ADAPT 1
#endif

// ---------------- RENDU TAA / UPSCALING (TAA_MODE) ----------------
// SEUL AXE DONT LE CRAN 0 EST LE MEILLEUR : c'est un axe de PERFORMANCE, pas de
// qualite. Il descend, il ne monte pas. Les libelles du menu le disent
// ("Ultra qualite" -> "Ultra performance"), les valeurs aussi.
// CE CRAN ACHETE : des images par seconde, contre de la nettete.
// MESURE : TAAU_RENDER_SCALE^2 = fraction des pixels reellement calcules en 3D
// (le cout du rendu suit le CARRE de l'echelle lineaire) ->
// 100 % / 72 % / 56 % / 44 % / 25 %, soit environ -25 % de pixels par cran.
// ATTENTION, DEPENDANCE : TAAU_RENDER_SCALE n'est lue qu'au travers de
// "#if defined TAA && TAA_UPSCALING == 1" (lib/common.glsl). Poser TAA_MODE != 0
// avec l'anti-aliasing temporel DECOCHE ne fait donc RIEN, silencieusement.
// C'est pour cela que les profils POTATO et MEDIUM epinglent TAA=true.
// UN seul reglage a 5 crans qui pilote l'upscaling temporel :
//   0 Ultra qualite    = 100 % (pas d'upscaling)   -> PALIER LIVRE
//   1 Qualite          = 0.85  (72 % des pixels)
//   2 Equilibre        = 0.75  (56 %)  <- la valeur TAAU_RENDER_SCALE livree
//   3 Performance      = 0.66  (44 %,  ratio "DLSS Quality")
//   4 Ultra performance= 0.50  (25 %,  ratio "DLSS Performance")
// Justification des echelles : le cout du rendu suit le CARRE de l'echelle, on
// veut donc des crans a peu pres reguliers en NOMBRE DE PIXELS, pas en largeur.
// 0.85 / 0.75 / 0.66 / 0.50 donnent 72 / 56 / 44 / 25 % - environ -25 % de
// pixels par cran, ce qui est la granularite ou un cran se voit sur le fps sans
// que la nettete s'effondre d'un coup. Toutes sont des valeurs de la liste
// historique de TAAU_RENDER_SCALE, donc un reglage a la main reste coherent.
// A TAA_MODE 0 l'echelle vaut 1.0 : elle n'est de toute facon jamais lue
// (lib/common.glsl : "#if defined TAA && TAA_UPSCALING == 1"), donc le palier
// par defaut rend EXACTEMENT comme la version livree (qui portait 0.75 inerte).
#if TAA_MODE == 0
#define TAA_UPSCALING 0
#define TAAU_RENDER_SCALE 1.0
#elif TAA_MODE == 1
#define TAA_UPSCALING 1
#define TAAU_RENDER_SCALE 0.85
#elif TAA_MODE == 2
#define TAA_UPSCALING 1
#define TAAU_RENDER_SCALE 0.75
#elif TAA_MODE == 3
#define TAA_UPSCALING 1
#define TAAU_RENDER_SCALE 0.66
#else
#define TAA_UPSCALING 1
#define TAAU_RENDER_SCALE 0.5
#endif

// ---------------- COUVERTURE NUAGEUSE (CLOUD_AMOUNT) ----------------
// AXE DE LOOK, PAS DE QUALITE : monter ne veut pas dire "mieux", ca veut dire
// "plus couvert". Aucun cran n'est meilleur qu'un autre, ils sont differents.
// MESURE : VC_COVERAGE = fraction du ciel couverte -> 0.20 / 0.30 / 0.40 / 0.60.
// EFFET VISIBLE : cumulus epars et bien separes (0.20) jusqu'a des masses qui
// fusionnent en nappe continue (0.60). COUT : nul au premier ordre - c'est un
// seuil de densite, pas un budget d'echantillons ; un ciel plus couvert fait
// simplement terminer la marche plus tot (plus d'occlusion), donc 0.60 peut
// meme etre marginalement PLUS rapide que 0.20.
// Palier 2 = la valeur livree (VC_COVERAGE 0.40).
#if CLOUD_AMOUNT == 0
#define VC_COVERAGE 0.20
#elif CLOUD_AMOUNT == 1
#define VC_COVERAGE 0.30
#elif CLOUD_AMOUNT == 2
#define VC_COVERAGE 0.40
#else
#define VC_COVERAGE 0.60
#endif

// ---------------- ETOILES (STAR_LEVEL) ----------------
// AXE DE LOOK : monter rend le ciel nocturne plus spectaculaire, pas plus
// "juste". MESURE : STAR_BRIGHTNESS -> 0.5 / 1.0 / 2.0 / 3.0 et
// MILKYWAY_BRIGHTNESS -> 0.0 / 0.0 / 0.75 / 1.5.
// EFFET VISIBLE : le cran 1 -> 2 est le plus marquant de l'axe, c'est celui qui
// ALLUME la Voie lactee (elle est absente aux crans 0 et 1). Les crans 0 -> 1 et
// 2 -> 3 ne font que doubler l'eclat.
// COUT : nul (deux multiplications) - c'est un axe de gout, pas de budget.
// Eclat des etoiles + apparition de la Voie lactee sur les deux crans hauts.
// Palier 1 = les valeurs livrees (1.0 / 0.0 : pas de Voie lactee).
#if STAR_LEVEL == 0
#define STAR_BRIGHTNESS 0.5
#define MILKYWAY_BRIGHTNESS 0.0
#elif STAR_LEVEL == 1
#define STAR_BRIGHTNESS 1.0
#define MILKYWAY_BRIGHTNESS 0.0
#elif STAR_LEVEL == 2
#define STAR_BRIGHTNESS 2.0
#define MILKYWAY_BRIGHTNESS 0.75
#else
#define STAR_BRIGHTNESS 3.0
#define MILKYWAY_BRIGHTNESS 1.5
#endif

// ---------------- EAU : TEINTE DU MILIEU (FIGEE, EAU8) ----------------
// EAU8 : LE PALIER DE MENU WATER_TINT N'EXISTE PLUS. Demande explicite du
// createur : "retire les differents profils de couleurs, je veux que naturel".
// Il reste UNE teinte, celle de l'ancien cran "Naturel", posee en clair a la
// fin de ce bloc ; le texte ci-dessous est conserve comme DERIVATION et
// HISTORIQUE (il parle du palier a quatre crans qui a existe de EAU5 a EAU8 --
// lire "le cran Naturel" partout ou il dit "le palier").
// L'axe faisait PIVOTER la chroma du
// MILIEU - la TEINTE - a luminance Rec.709 EXACTE et a saturation HSV EXACTE.
// C'est la MEME mecanique que la projection de gamut EAU4 : on ne touche qu'aux
// ECARTS des trois canaux par rapport a leur point achromatique, prise dans
// l'autre sens - EAU4 depensait de la SATURATION pour rentrer dans le gamut, ce
// palier depense de l'ANGLE DE TEINTE et ne touche ni la luminance ni la
// saturation. Rotation de Rodrigues autour de l'axe achromatique, puis retrait
// exact de la luma du vecteur tourne (donc luma(resultat) == luma(origine) au
// bit pres), puis remise a l'echelle de l'ecart pour retrouver la saturation
// HSV d'origine, bornee par la garde de gamut (aucun canal negatif).
// LES SEPT CONSTANTES DU MILIEU TOURNENT ENSEMBLE - colonne vue de dehors
// (WCOL_SCAT_DEEP), colonne immergee (WCOL_UW_*), colonne derriere une vitre et
// faces d'eau cullees (WCOL_SCAT_UW), teinte des puits de lumiere sous-marins
// (uwShaftTint), et - ajoutees apres l'audit EAU5, elles manquaient - les trois
// chromas du chemin OEIL DANS UNE STRUCTURE DE VERRE SOUS L'EAU
// (composite1.fsh, bloc "Submerged glass") : WT_GWS (brume proche), WT_GWD
// (brume profonde) et WT_GWH (halo UNDERWATER_FX). Ce chemin est VIVANT aux
// defauts (UNDERWATER_FX defini, GLASS_SEE_THROUGH = 1) et ses trois litteraux
// etaient CODES EN DUR hors palier : au cran 0 l'eau vue de dehors tombait a
// 168.0 deg pendant que la brume vue depuis le dome de verre restait a
// 204.0 / 219.5 / 206.3 deg, soit un split dedans/dehors de 36 a 51 deg - la
// classe de defaut exacte que EAU4 existe pour supprimer. Attention, ce n'est
// PAS le meme site que WCOL_SCAT_UW, qui traite la colonne DERRIERE la vitre
// vue de DEHORS. Avec les trois familles ci-dessous, le split dedans/dehors
// reste a 0.01 deg a TOUS les crans : l'acquis EAU4 est porte par construction,
// pas re-verifie a la main.
//   famille   sat     teinte cran 0 / 1 / 2 / 3        luminance Rec.709
//   WT_DEEP   0.9035  168.0 / 192.0 / 210.4 / 180.0    0.358481 (inchangee)
//   WT_UWC    0.9036  168.0 / 192.0 / 210.4 / 180.0    0.128066 (inchangee)
//   WT_GLASS  0.9035  168.0 / 192.0 / 210.4 / 180.0    0.314172 (inchangee)
//   WT_SHAFT  0.6522  168.0 / 192.0 / 204.0 / 180.0    0.620792 (inchangee)
//   WT_GWS    0.9091  168.0 / 192.0 / 204.0 / 180.0    0.240528 (inchangee)
//   WT_GWD    0.9500  168.0 / 192.0 / 219.5 / 180.0    0.005616 (inchangee)
//   WT_GWH    0.8913  168.0 / 192.0 / 206.3 / 180.0    0.244098 (inchangee)
// TROIS FAMILLES NE SONT PAS A 0.904 DE SATURATION ET TROIS N'ONT PAS 210.4 AU
// CRAN 2, ET C'EST VOULU : le cran 2 reproduit le litteral historique AU BIT
// PRES, litteral par litteral. Consequence a ecrire noir sur blanc : au cran 2
// (le look livre) les puits de lumiere gardent leur decalage historique de
// 6.4 deg par rapport au milieu (204.0 contre 210.4), la brume de verre proche
// aussi (204.0), la brume profonde est a +9.1 deg (219.5) et le halo a -4.1 deg
// (206.3). Aux crans 0 / 1 / 3, toutes les familles sont alignees sur le milieu
// (167.997 / 192.000 / 180.004) : c'est le cran livre, et lui seul, qui porte
// les ecarts d'origine.
// NON-REGRESSION, CHIFFRES MESURES. Colonne seule sur sable a midi, les quatre
// crans : L(0.5 bloc) 0.6203 / L(3) 0.3750 / L(20) 0.1416 et dynamique
// 0.5->20 = x4.38. L'ecart de luminance de la COLONNE COMPLETE (cran 2 ->
// cran 0) est de -0.010 % a 0.5 bloc, -0.025 % a 3 blocs et +0.037 % a 20
// blocs. La borne "0.02 %" annoncee au premier jet etait optimiste et surtout
// mal cadree : prise SEUL, le terme d'in-scatter derive davantage - -0.804 % a
// 0.5 bloc, -0.259 % a 3, +0.041 % a 20 - parce que le facteur par canal
// (1 - absorb*visW) n'est pas plat et repondere une chroma tournee. Visuellement
// nul dans les deux cas, mais la borne porte sur la colonne complete.
// CE QUI EST PALIER-INDEPENDANT PAR CONSTRUCTION, verifie : la lisibilite du
// fond a 3 blocs (T = 0.2135 / 0.5111 / 0.5571, visW = 0.7067 / 0.6796 /
// 0.6338) ne depend que de WCOL_K_OUT et WCOL_B_SCAT, qui ne sont JAMAIS
// tournes ; la dynamique 0.5->20 blocs est invariante ; le split dedans/dehors
// mesure 0.005 deg au cran 0 et 0.014 deg au cran 2. La garde WATER_FOG_BLUE
// 1.25 tient (cran 2 : -0.09 + 1.25*0.0720 = 0.000000 exactement ; crans
// 0/1/3 a -0.0356 / -0.0263 / -0.0365, donc le clamp max(slateC, 0) mord bien
// la ou il a ete ecrit pour mordre - et 1.25 reste inatteignable au menu,
// WATER_FOG_BLUE n'etant ni dans sliders= ni dans aucun screen.*).
//
// WT_MIRROR - POURQUOI UN PALIER DE TEINTE TOUCHE AUSSI LE MIROIR. Audit EAU5
// (tableau complet en tete de composite1.fsh) : le REFLET DU CIEL pese 7.0 % du
// pixel d'eau a 2 blocs, 29.9 % a 5, 66.7 % a 10, 89.8 % a 20 et 80.9 % a 60
// (chiffres RENORMALISES apres l'audit : le premier jet du tableau oubliait le
// voile volumetrique, qui reprend 18 % du pixel a 60 blocs).
// CORRECTION EAU7, PREMIERE COLONNE SEULE : le 7.0 % a 2 blocs est surestime.
// Recalcule sur la geometrie propre du site reflW (oeil 1.8 au-dessus, fond a
// 3 blocs, ndvGeo = 1.8/L, chemin = 3/ndvGeo, formule reelle fresP x damper x
// WATER_REFLECTIVITY x plancher), le miroir pese 1.1 % a 2 blocs et 16.9 % a 5.
// Le champ LOINTAIN du tableau tient a 2-4 points pres, le champ PROCHE non :
// c'est cette moitie proche qui a fait croire que le miroir decidait le pixel
// de HAUT-FOND, alors qu'il en decide 0.5 a 2.0 % (bloc EAU7 plus bas).
// Un palier qui ne toucherait QUE le milieu serait donc muet des 10 blocs - c'est
// exactement pourquoi quatre re-derivations successives de la chroma n'ont
// jamais suffi. Chaque cran porte donc aussi le poids du miroir, le ciel etant
// le bleu le plus sature de la scene. Cran 2 = 1.0 : x1.0 est neutre en IEEE,
// le look livre est reproduit BIT A BIT. Le plancher anti-noir de l'horizon
// (WATER_HORIZON_SKY) n'est PAS multiplie : au-dela de 48 blocs l'eau garde son
// miroir plein et ne peut toujours pas devenir noire.
// CE QUE WT_MIRROR DEPLACE EN PLUS DU MIROIR, effet de bord assume et mesure :
// wMirror = reflW * flatW (composite1.fsh), donc en changeant reflW le palier
// change aussi wMirror, qui pondere QUATRE autres sites - le relief ATMO_FOG,
// la densite du pas VL immerge uw*0.008*(1 - wMirror*0.85), la queue analytique
// HEIGHT_FOG et le fogKeepW de l'application VL. Les TROIS RELIEFS D'AIR au-
// dessus de l'eau bougent donc avec le palier. Amplitude a 20 blocs, cran 2 ->
// cran 0 : wMirror 0.9389 -> 0.7511, donc fogKeepW 0.4836 -> 0.5869, soit
// +1.4 point de voile bleu ciel, qui rend ~0.2 deg sur les 7.5 deg de rotation
// visee. Reel, negligeable, ecrit ici pour qu'il ne surprenne personne.
// PORTEE DE WT_MIRROR - LIMITE ASSUMEE. Le clamp 0.98 de reflW mord des
// L ~ 22 blocs au cran 2 et L ~ 45 au cran 0 : au-dela de ~45 blocs reflW vaut
// 0.9800 AUX DEUX CRANS, au bit pres, et le palier est INERTE. Ecart de teinte
// livree cran 2 -> cran 0 : 7.5 deg a 20 blocs, 3.3 a 30, 0.64 a 45, 0.57 a 60,
// 0.63 a 120. Le controle agit donc de ~8 a ~45 blocs, pas au-dela ; le champ
// lointain garde le bleu livre quel que soit le cran. Un vrai levier lointain
// demanderait clamp(..., 0.0, 0.98 * WT_MIRROR) ou de porter le palier dans la
// clause hzR de WATER_HORIZON_SKY - les deux echangent la garantie anti-noir
// contre de la teinte, aucun des deux n'est livre.
// SITE D'EAU HORS PORTEE, nomme pour que l'enumeration soit complete :
// dh_water.fsh (nappe LOD Distant Horizons) dessine l'eau avec son propre
// albedo, son propre Fresnel et son propre reflet (reflDH) et ne reference ni
// WT_*, ni WCOL_*, ni WATER_REFLECTIVITY ; composite1 ne lit jamais le flag 0.2
// qu'il ecrit. Le palier ne l'atteint pas. Impact nul aux defauts : son propre
// discard le cantonne au-dela de far-32, ou le clamp 0.98 ci-dessus sature deja
// le miroir vanilla aux deux crans - le palier y est de toute facon muet.
// (L'ancien paragraphe "DEFAUT = 0 (Vert)" est retire avec le palier : il
// documentait un defaut de MENU qui n'existe plus. Les mesures de livraison
// valables pour la teinte figee sont celles du cran 1 des tables ci-dessus.)
// EAU8 -- UNE SEULE TEINTE, FIGEE. Ce sont les valeurs de l'ancien cran 1
// "Naturel" (teinte 192.0 deg pour le milieu), RECOPIEES A L'IDENTIQUE : le
// reglage LIVE du createur au moment du retrait etait WATER_TINT=1, donc son
// rendu ne bouge pas d'un bit. Chaque famille garde sa luminance Rec.709
// historique (WT_DEEP 0.358481, WT_UWC 0.128066, WT_GLASS 0.314172, WT_SHAFT
// 0.620792, WT_GWS 0.240528, WT_GWD 0.005616, WT_GWH 0.244098) et sa
// saturation HSV propre -- rien n'a ete recalcule.
#define WT_DEEP_R 0.050964
#define WT_DEEP_G 0.432761
#define WT_DEEP_B 0.528190
#define WT_UWC_R 0.018186
#define WT_UWC_G 0.154606
#define WT_UWC_B 0.188722
#define WT_GLASS_R 0.044664
#define WT_GLASS_G 0.379270
#define WT_GLASS_B 0.462922
#define WT_SHAFT_R 0.281133
#define WT_SHAFT_G 0.702835
#define WT_SHAFT_B 0.808257
#define WT_GWS_R 0.032313
#define WT_GWS_G 0.290821
#define WT_GWS_B 0.355447
#define WT_GWD_R 0.000424
#define WT_GWD_G 0.006871
#define WT_GWD_B 0.008482
#define WT_GWH_R 0.038846
#define WT_GWH_G 0.293675
#define WT_GWH_B 0.357382
#define WT_MIRROR 0.90

// ---------------- EAU : CHROMA DU PORTEUR DU FOND (EAU7) ----------------
// TABLE DE PARTS, PARAMETREE EN CHEMIN OPTIQUE - c'est-a-dire en blocs d'eau
// traverses par le rayon de VUE - et NON en distance camera comme les tables
// EAU5/EAU6 plus haut. Sable (0.76,0.70,0.50), midi, skyl 1, vue 45 deg, donc
// vdep = 0.707 x chemin. Part de LUMINANCE LINEAIRE du pixel (apres colonne,
// miroir et brouillard, AVANT tonemap), pas un poids de mix. Apres l'ACES la
// part LIVREE du fond tombe a ~85/83/79/75 % sur 0.5-3 bl (la compression
// mange la contribution marginale d'un fond brillant) ; le critere de
// dominance du fond tient dans les deux espaces de mesure :
//   chemin                    0.5 bl   1 bl    2 bl    3 bl    5 bl
//   albedo du FOND            97.2 %  96.4 %  94.4 %  91.7 %  84.3 %
//   in-scatter (slateC)        0.5 %   1.1 %   2.7 %   4.9 %  11.4 %
//   ciel reflechi (reflW)      0.5 %   0.6 %   0.9 %   1.2 %   2.0 %
//   couche gbuffers_water      1.8 %   1.9 %   2.0 %   2.2 %   2.3 %
// SITES INERTES DANS CETTE BANDE, verifies un par un : teinte de BIOME (turbid
// = smoothstep(0.05,0.45, r+g-1.05b) vaut EXACTEMENT 0 sur l'ocean vanilla
// (0.247,0.463,0.894 -> -0.229), donc zero hors marais/mangrove - conforme a
// l'intention) ; PUITS DE LUMIERE (uwShaftTint, profondeur optique 0.016-0.024
// sur 2-3 blocs, <= 2-3 % en champ proche) ; WATER_HORIZON_SKY (hzDistW =
// smoothstep(48,192,dist) = 0 exactement sous 48 blocs) ; FOAM (rive seule,
// shoreD < 1.6) ; ATMO_FOG / HEIGHT_FOG / ssrLocalAmb (~0 a 2-5 blocs).
// CONSEQUENCE A ECRIRE NOIR SUR BLANC : dans la bande ou le defaut se voit, le
// FOND DOMINE le pixel. Ce que WATER_TINT deplace (l'in-scatter, et lui seul)
// vaut 0.5 a 4.9 % de ce pixel ; ce que WT_MIRROR deplace (le miroir) 0.5 a
// 2.0 %. Les quatre re-derivations successives de la chroma du MILIEU ne
// pouvaient donc structurellement pas etre visibles la ou le createur regarde.
// LE VRAI DEFAUT n'est pas la couleur du voile, c'est la CHROMA DU FILTRE pose
// sur le PORTEUR du fond : bg est multiplie par absorb*visW, qui normalise au
// bleu vaut (0.734,0.961,1.000) a 0.5 bloc, (0.529,0.917,1.000) a 1,
// (0.288,0.846,1.000) a 2, (0.160,0.784,1.000) a 3, (0.051,0.679,1.000) a 5.
// Teinte LIVREE du sable : 49 deg a sec, 95 a 0.5 bloc, 152 a 1, 174 a 2,
// 178 a 3 - cyan pur, plus aucune trace d'ocre. L'herbe marine survit mieux
// (teinte 135-160 deg au lieu de 113) non par une propriete de l'herbe mais
// parce que le meme filtre ne coute que 15-32 % au canal G contre 71-95 % au R.
// QUI PAIE LA PERTE R/B a 2 blocs de chemin : jambe de VUE 51.3 %, jambe de
// LUMIERE (vlxWaterShadowT) 40.5 %, teinte des CAUSTIQUES 8.1 %. Les trois
// sites sont traites ci-dessous et par le spectre des caustiques ; aucun des
// trois n'est l'in-scatter.
//
// (1) LE PORTEUR - composite1.fsh, fin de waterColumn(). La chroma du filtre
// est partiellement re-neutralisee sur les premiers blocs de chemin, a
// LUMINANCE INCHANGEE : mix(T, vec3(luma(T)), k) preserve luma(T) par
// construction, donc luma(Tk) == luma(Tfl) au bit pres. La dynamique
// 0.5 -> 20 blocs, le degrade haut-fond/large et la lisibilite du fond restent
// portes par luma(Tfl) exactement comme avant ; seule la CHROMA du fond survit
// aux deux premiers blocs. WFLOOR_CHROMA_KEEP = part de chroma rendue a chemin
// nul, WFLOOR_KEEP_RANGE = longueur (en blocs de CHEMIN) sur laquelle elle
// s'eteint. L'EAU LIBRE est inerte par construction : exp(-8/2.5) = 0.04 a
// 8 blocs, et elle est de toute facon pilotee a 75-98 % par le miroir.
// WFLOOR_CHROMA_KEEP 0.0 restore le comportement d'avant EAU7 AU BIT PRES.
// QUATRE SITES, UNE SEULE FONCTION - vlxFloorCarrier() dans composite1.fsh.
// Les TROIS sites freres fabriquent leur Beer-Lambert A LA MAIN et n'appellent
// jamais waterColumn(), donc un grep sur waterColumn ne les voit pas ; leur
// raison d'etre ecrite est pourtant de coller a la colonne d'eau libre ("so a
// lake never changes colour behind a pane", "so culled water faces match the
// real surface"). Corriger waterColumn() SEUL aurait donc rouvert exactement le
// split dedans/dehors que EAU4 existe pour fermer. Les quatre :
//   - composite1.fsh, fin de waterColumn()          (eau libre, chemin dPath)
//   - composite1.fsh, absorbG (bloc GLASS_SEE_THROUGH) : l'eau qu'une VITRE cache
//   - composite1.fsh, absorbU x2 : les deux colonnes de FACES D'EAU CULLEES
//     (branche PIXEL_WATER_FIX et branche legacy) - chemin PASSE DEJA MIS A
//     L'ECHELLE (wd * 0.8 / WATER_CLARITY), soit le nombre exact que leur propre
//     exponentielle utilise.
// SITE VOLONTAIREMENT EXCLU, nomme pour que l'enumeration soit complete :
// composite1.fsh, absU = exp(-dist * WCOL_K_UW) - la colonne OEIL SOUS L'EAU.
// Elle a son PROPRE spectre (0.0916,0.0198,0.0032 : pente R-B 0.088/bloc contre
// 0.356 pour WCOL_K_OUT, soit 4x plus douce), sa propre echelle metres/bloc
// (x0.315 contre x1.36) et surtout sa PROPRE commande de desaturation
// (UW_FOG_DESAT). Le defaut rapporte porte sur le fond vu DE DEHORS ; toucher
// cette colonne changerait un look qui n'a pas ete mis en cause et qui a deja
// son levier. A ne rouvrir que si le rendu SOUS l'eau est signale a son tour.
// EAU8 -- POUSSE 0.55/2.5 -> 0.85/3.0 sur captures du createur ("piscine
// cyan") : au premier jet le sable livre restait a ~77 deg de teinte sous
// 1 bloc de chemin (sec = 43 deg). A 0.85/3.0 le recalcul COMPLET (jambe de
// lumiere vlxWaterShadowT avec sunPathRotation, caustiques, couche gbuffers,
// miroir, chaine tonemap) donne ~58 / 76 / 139 deg a 0.5 / 1 / 2 blocs de
// CHEMIN, soit ~64 / 99 / 163 deg a 0.5 / 1 / 2 blocs de PROFONDEUR. A
// 1 bloc de profondeur la saturation n'est que ~0.04 (v ~0.92) : quasi
// blanc, lisible comme du sable clair ; a 2 blocs, lavis sarcelle pale. Le
// residu vient surtout de la chroma du filtre de vue non neutralisee (keep
// 0.85*exp(-2/3) = 0.44 a 2 blocs de chemin), puis de la jambe de lumiere,
// enfin des caustiques. La rampe vers le sarcelle puis le marin continue
// au-dela (keep 0.16 des 5 blocs de chemin, l'eau libre reste inerte : miroir
// a 75-98 %). La luminance ne bouge pas :
// mix vers luma() est conservatif par construction.
#define WFLOOR_CHROMA_KEEP 0.85
#define WFLOOR_KEEP_RANGE 3.0
// (2) LA JAMBE DE LUMIERE - lib/lighting.glsl, vlxWaterShadowT(). ELLE MANQUAIT
// A TOUTES LES ENUMERATIONS EAU, et c'est le DEUXIEME terme le plus fort. Elle
// renvoie exp(-t * VLX_WATER_K_*) avec t = epaisseur d'eau traversee par le
// SOLEIL, donc le terme DIRECT du fond est deja multiplie par (0.57,0.87,0.94)
// sous 1.41 bloc et (0.43,0.82,0.91) sous 2.12 AVANT que composite1 ne pose sa
// propre Beer-Lambert : le rouge est absorbe DEUX FOIS avec le meme spectre.
// Physiquement juste dans le principe, mais 40.5 % de la destruction de la
// teinte du sable a 2 blocs de chemin. Ce site n'est PAS annule - il porte
// l'assombrissement en profondeur - seule sa CHROMA est bornee, a luminance
// Rec.709 exacte. La correction est posee DANS la fonction, donc les QUATRE
// consommateurs la recoivent ensemble et ne peuvent pas diverger : les deux
// samplers d'ombre (chemin legacy et sampleShadowPCFV2), la marche VL de
// composite1.fsh et son miroir lib/vl_halfres.glsl - le faisceau et le spot
// qu'il eclaire restent priced par un seul spectre.
// A NOTER, non corrige et assume : l'AMBIANT (gAmbC * skyl) n'est PAS attenue
// par cette jambe, ce qui rend l'ombre sous-marine relativement plus bleue
// encore que le soleil. WLEG_CHROMA_CUT 0.0 = comportement d'avant EAU7.
// EAU8 -- 0.5 -> 0.75, meme campagne de captures que WFLOOR_CHROMA_KEEP : la
// jambe de lumiere re-absorbait le rouge du fond une deuxieme fois avec le
// meme spectre, a TOUTES les profondeurs. A 0.75 il en reste un quart (le
// refroidissement en profondeur est deja porte par la jambe de vue et par la
// colonne) ; la luminance de la jambe -- donc l'assombrissement avec la
// profondeur ET la luminance des faisceaux VL qui la consomment -- est
// inchangee au bit pres (mix vers luma()).
#define WLEG_CHROMA_CUT 0.75

// ---------------- EAU : LE CIEL REFLECHI DANS L'EAU (WATER_SKY_TINT) ----------------
// POURQUOI CET AXE EXISTE, ET POURQUOI CE N'EST PAS WATER_TINT BIS.
// L'audit EAU5 (tableau complet en tete de composite1.fsh) a etabli qu'au-dela
// de ~8 blocs le pixel d'eau EST le ciel reflechi : 70.1 % du pixel final a 10
// blocs, 96.3 % a 20, 98.7 % a 60. WATER_TINT ne touche QUE le milieu (plus le
// POIDS du miroir via WT_MIRROR) : il ne peut pas changer la COULEUR de ce
// ciel. Et l'audit a mesure que la desaturation n'est pas le levier non plus -
// pousser REFLECT_DESAT de 0.40 a 0.52 ne deplace la teinte livree que de
// 0.7 deg a 20 blocs. Le seul levier restant est la TEINTE du ciel reflechi
// elle-meme, et c'est exactement ce que cet axe fait.
// CE QU'IL FAIT, EN UNE PHRASE : il fait pivoter la chroma du CIEL VU DANS
// L'EAU hors de l'azur et baisse sa saturation, a luminance Rec.709
// RIGOUREUSEMENT constante, sans toucher au ciel reel.
//
// LA MECANIQUE - la meme projection de chroma que WATER_TINT, prise dans un
// troisieme sens. WATER_TINT depense de l'ANGLE et ne touche ni la luminance ni
// la saturation ; EAU4 depensait de la SATURATION pour rentrer dans le gamut ;
// ici on depense les DEUX et toujours rien sur la luminance. Le vecteur de
// travail est le meme : la chroma A LUMA NULLE c = sky - luma(sky). On tire sa
// DIRECTION vers une direction cible fixe (WST_TARGET) puis on remet la
// longueur a |c| * WST_SAT. mix() de deux vecteurs a luma nulle a une luma
// nulle, normalize() aussi, donc luma(resultat) == luma(entree) PAR
// CONSTRUCTION - mesure : ecart relatif MAXIMUM 1.1e-7 % sur les cinq distances
// et les quatre crans, c'est-a-dire le bruit d'arrondi du modele en double
// precision ; le fp32 du shader y ajoute son propre ~1e-5 %, toujours mille
// fois sous le quantum du fp16 des buffers. CONSEQUENCE QUI PORTE LOIN : comme
// la luminance ne bouge pas, reflSkyL ne bouge pas, donc AUCUN poids en aval
// ne bouge - ni les trois fondus darkH / darkH2 / darkV, ni 'hit', ni reflW,
// ni wMirror, donc ni le relief ATMO_FOG, ni la densite VL immergee, ni la
// queue HEIGHT_FOG, ni fogKeepW. Ce palier ne deplace QUE de la chroma. Tirer la
// DIRECTION plutot que tourner d'un angle fixe est ce qui rend la transformation
// SANS DEPASSEMENT : un ciel deja arrive sur la cible n'est plus deplace, donc
// aucun crepuscule violet ne peut partir en magenta parce qu'il partait de plus
// loin. La garde de gamut (aucun canal negatif) est un simple facteur d'echelle
// sur la chroma, elle preserve donc la luma elle aussi.
//
// LES DEUX PORTES, ET POURQUOI LE SOLEIL NE BOUGE PAS.
// (a) PORTE D'AZUR : le tirage est pondere par la proximite de la direction de
//     chroma d'entree avec WST_AZURE (la chroma unitaire moyenne du ciel de
//     jour du pack, mesuree sur les directions qu'un plan d'eau utilise
//     reellement). Mesures : ciel de jour 0.9957 a 0.9995 -> porte pleine ;
//     BANDE DU COUCHANT VUE VERS LE SOLEIL -0.911 a -0.967 -> porte a ZERO ;
//     coeur du disque solaire -0.999 -> porte a ZERO. Le chemin d'or sur l'eau
//     au couchant est donc INTOUCHE, aux quatre crans, a toutes les distances
//     (mesure : ecart 0.0 deg de teinte et 0.00 % de luminance a 5/10/20/60
//     blocs). C'est ce que le createur aime le plus ; il ne bouge pas d'un bit.
// (b) EPARGNE DES HAUTES LUMIERES : le tirage s'eteint au-dessus de WST_HI0 en
//     luminance HDR. Le ciel diffus plafonne vers 0.95-1.2 -> jamais epargne ;
//     le disque solaire monte a ~24 -> toujours epargne. PIC SOLAIRE MESURE, a
//     midi, cran 3 (le plus fort) : entree (25.6096, 24.1062, 21.6776),
//     sortie (25.6096, 24.1062, 21.6776) - IDENTIQUE AU BIT. Les deux portes se
//     recouvrent : la chroma du disque est chaude (porte (a) = 0) ET sa
//     luminance est enorme (porte (b) = 0).
//     CONTINUITE AU BORD DU DISQUE, verifiee parce que deux portes qui se
//     croisent sont exactement le genre d'endroit ou un anneau apparait.
//     AFFIRMATION CORRIGEE : une note precedente creditait le mauvais mecanisme
//     et mesurait la mauvaise variable. |c| NE passe PAS par zero au bord : son
//     minimum re-mesure est 0.0476, soit 7.6 % du 0.6279 du ciel zenithal nu,
//     atteint a la valeur de disque t = 0.188, ou Y = 5.09 - donc la ou
//     l'EPARGNE DES HAUTES LUMIERES a DEJA force w = 0. Le bord est protege par
//     la porte (b) SEULE ; le mecanisme "|c| -> 0" n'y joue aucun role.
//     L'ancien profil (60 pas, monotone, pente 3.33) balayait la VALEUR DU
//     DISQUE et non la POSITION ECRAN : il ne pouvait pas repondre a la question
//     de l'anneau, puisque t lui-meme s'effondre de 1 a 0 sur ~10 % du rayon.
//     BALAYE EN ANGLE, au SUN_SIZE 0.04 par defaut : |sortie - entree| passe de
//     0 a 0.354 (HDR lineaire) sur 0.0327 deg, soit 0.49 px a 70 deg de champ
//     en 1080p - moins d'un pixel, inoffensif.
//     LIMITE ASSUMEE, ECRITE : SUN_SIZE est un curseur de menu jusqu'a 1.0. La
//     meme rampe fait 1.26 px a SUN_SIZE 0.1, 2.55 px a 0.2 et 5.64 px a 0.5 :
//     un fin lisere chromatique autour du soleil REFLECHI devient visible a
//     partir de ~0.1. Assume plutot que corrige - elargir WST_HI0..WST_HI1
//     deplacerait tous les nombres des tables ci-dessous, et le defaut est 0.04.
// Le GLINT de la surface (le lobe GGX de gbuffers/composite1) n'est PAS un
// terme de ciel : il est construit sur gLightC. Il n'est ni lu ni ecrit ici.
//
// LES CINQ SITES D'INJECTION - l'enumeration complete, faite parce que le pack
// a deja perdu CINQ fois un site oublie (le cinquieme etant l'ocean DH,
// ci-dessous, oublie par l'audit EAU6 lui-meme). La fonction vit desormais dans
// /lib/water_sky_tint.glsl pour que composite1 ET dh_water puissent l'appeler :
//   1. skyReflect() -- le miroir de la surface d'eau libre (appel ligne ~2553).
//   2. skyReflect() -- le miroir de l'eau DERRIERE UNE VITRE (GLASS_SEE_THROUGH,
//      appel ligne ~3431). La teinte est appliquee DANS skyReflect, donc ces
//      deux sites sont couverts par construction et tout futur appel le sera
//      aussi. skyReflect n'a que ces deux appelants et ils sont tous deux de
//      l'eau : la fonction est un site d'eau, pas un site de ciel.
//   3. hzSkyRaw -- le plancher anti-noir WATER_HORIZON_SKY de la colonne d'eau
//      libre (~ligne 2427).
//   4. gsHzSky -- le meme plancher pour l'eau derriere une vitre (~ligne 3396).
//   5. reflDH -- l'OCEAN DISTANT HORIZONS (dh_water.fsh, bloc WATER_SKY_REFLECT).
//      Ce pass bati son propre reflet de ciel sur getAmbientColor /
//      getLightColor : il est INVISIBLE a un grep getSky*, et c'est exactement
//      pour ce motif qu'il avait ete ecarte. Or au-dela de far-32 le pixel est
//      un miroir sature a ~98 %, donc l'endroit ou une teinte porte LE PLUS.
//      Ecart de teinte mesure a la couture vanilla/DH AVANT correctif : -6.4 deg
//      au cran 0, +12.9 au cran 2 (le defaut) et +30.3 au cran 3 - il doublait
//      ET changeait de signe au defaut, sans rien pour le masquer (DISTANCE_FOG
//      vaut 0 par defaut ; ATMO_FOG seul, ~12 % a 160 blocs). La teinte y est
//      posee AVANT l'echelle fresnel/skylight et AVANT le glint (le glint n'est
//      pas un terme de ciel), donc dans le meme ordre qu'ici.
// Tout le reste du miroir (le second rayon flou r2, le fondu des touches SSR
// sombres, la reprise PT_REFLECT_WATER, le plancher (a) de WATER_HORIZON_SKY)
// DERIVE de reflSky et suit donc automatiquement - c'est pour cela que la
// teinte est posee sur reflSky et pas plus bas.
// CE QUI N'EST PAS UN SITE, ET POURQUOI (liste tenue pour que personne ne
// "complete" l'enumeration a tort) : gSkyFB / gSkyFB2 (le reflet PROPRE de la
// vitre), les getSkyAll des reflets PBR opaques et des metaux, wetSkyRefl (sol
// mouille), et les cinq getSkyBase des brouillards. Ces cinq derniers sont de
// l'AIR : le meme voile couvre le rivage juste a cote, les teinter cote eau
// seulement mettrait une couture sur la ligne de berge. (dh_water.fsh N'EST
// PLUS une exclusion : c'est le site 5 ci-dessus.)
// SOUS L'EAU, LE PALIER EST DE FAIT INERTE - affirmation CORRIGEE, l'ancienne
// disait l'inverse de ce que fait le code. Elle pretendait que "dans la fenetre
// de Snell reflSky est le ciel REFRACTE et porte donc le palier". Faux :
// reflSky (composite1.fsh ~1682) est le ciel REFLECHI. Le ciel REFRACTE que
// l'oeil voit vraiment a travers la fenetre est `color`, le tap colortex0 en
// ruv (~ligne 2179), qui n'est teinte par rien. Et dans la fenetre le code pose
// fres = fres * 0.22 (~ligne 2512) : en regardant droit vers le haut,
// fresSchlick ~ 0.02, donc reflW = clamp(0.0044 * 0.95 * 1.5, 0, 0.98) ~ 0.006.
// Hors fenetre, la couleur est la reflexion totale interne uwFB (~ligne 2732),
// elle non plus jamais teintee. Le palier deplace donc MOINS DE 1 % du pixel
// sous l'eau, pas "toute la fenetre de Snell". Inoffensif - et cela supprime la
// couture que l'ancien commentaire redoutait, puisque rien n'est teinte sous
// l'eau. La reflexion totale interne (WCOL_UW_TIR / SHALLOW) n'est de toute
// facon pas un terme de ciel.
//
// LES CRANS. 0 = Azur (physique) : `return sky;` immediat, rendu livre INCHANGE
// - verifie en SPIR-V, et la formulation exacte compte. glslc sans -O n'inline
// pas, donc le module BRUT porte encore une OpFunction identite et trois
// OpFunctionCall (327300 octets contre 326940 au build de reference) : un
// artefact de build debug, pas un changement de comportement. Passes tous deux
// par spirv-opt -O --strip-debug (ce que fait un vrai pilote), les deux modules
// coincident instruction par instruction : 49832 instructions comparees, 0
// difference apres renumerotation des identifiants, et les 69 comptes
// d'opcodes egaux. 2 = Moyen = DEFAUT, la direction demandee par le createur.
// TEINTE / SATURATION HSV DU CIEL REFLECHI LUI-MEME, a midi, apres
// REFLECT_DESAT (donc la couleur que le pixel recoit vraiment) :
//   distance   cran 0        cran 1        cran 2        cran 3
//    2 blocs   219.4 / 0.658 226.6 / 0.557 236.5 / 0.444 250.2 / 0.390
//    5 blocs   218.0 / 0.597 225.3 / 0.504 235.5 / 0.398 249.8 / 0.342
//   10 blocs   216.0 / 0.516 223.5 / 0.433 234.0 / 0.339 249.1 / 0.282
//   20 blocs   214.0 / 0.452 221.7 / 0.379 232.4 / 0.294 248.4 / 0.238
//   60 blocs   211.6 / 0.398 219.6 / 0.334 230.7 / 0.258 247.6 / 0.203
// LA TEINTE MONTE, ET C'EST BIEN UN RECHAUFFEMENT - le nombre HSV trompe ici.
// Ce que la transformation fait vraiment est de REMONTER LE ROUGE : rapport
// R/B du ciel reflechi a 20 blocs, 0.548 -> 0.621 -> 0.706 -> 0.795 des crans
// 0 a 3, soit +29 % de rouge relatif au bleu au cran 2. Le pixel livre a 20
// blocs passe de (0.696, 0.788, 0.855) a (0.755, 0.776, 0.847) : le rouge monte
// de 0.059, le vert et le bleu ne bougent pas. L'angle de teinte grimpe vers
// 230 uniquement parce que le bleu reste le canal maximum ; perceptivement
// c'est moins cyan, donc moins azur et plus chaud, a luminosite egale.
// PIXEL D'EAU LIVRE (apres colonne + miroir + tonemap + etalonnage), eau libre,
// midi, teinte / saturation HSV / luminance Rec.709.
// ATTENTION, CONFIG DE MESURE : cette table est calculee a WATER_TINT = 2
// (Bleu), PAS au defaut livre. Preuve interne : sa ligne L = 10 (202.9 / 207.7 /
// 213.0 / 218.3) est mot pour mot la ligne "WT 2 Bleu" de la matrice 4x4 plus
// bas. EAU8 : le palier WATER_TINT n'existe plus, la teinte du milieu est
// FIGEE aux valeurs de l'ancien cran 1 (Naturel) - la ligne "WT 1" des tables
// ci-dessous est donc la SEULE vivante. Les chiffres correspondants sont
// dans la matrice 4x4 : a 10 blocs, WT 0 va de 190.6 (cran 0) a 194.5 (cran 2),
// soit +3.9 deg, et WT 1 de 197.1 a 204.2, soit +7.1 deg - contre +10.1 deg sur
// la ligne WT 2 ci-dessous. L'ordre des crans et le signe sont les memes
// partout ; seule l'AMPLITUDE change, et elle change pour la raison mecanique
// donnee avec la matrice (le poids WT_MIRROR).
// DEUX CO-LOCATAIRES NON TEINTES DU MEME PIXEL, NOMMES PARCE QUE LA TABLE LES
// IGNORE - les teintes publiees ici sont donc OPTIMISTES :
//   (a) gbuffers_water.fsh (~ligne 361) pose son PROPRE voile de ciel en
//       Fresnel, (getAmbientColor()*0.65 + getLightColor()*0.03) * fresG *
//       skyl2, melange dans colortex0 a un alpha qui monte a 0.38 sur l'eau
//       horizontale ; composite1 le relit tel quel comme tap de refraction
//       (~ligne 2179). Il n'est teinte par AUCUN des deux paliers et survit
//       dans la part (1 - reflW).
//   (b) Les brouillards aeriens (ATMO_FOG, perspective aerienne, queue
//       HEIGHT_FOG) posent ensuite du getSkyBase NON teinte par-dessus :
//       ATMO_FOG seul vaut ~1.7 % a 20 blocs et ~5.0 % a 60.
// BORNE QUE CELA IMPOSE : a 10 blocs, jusqu'a ~1/3 du pixel n'est pas teinte.
// Les deux termes sont INDEPENDANTS DU CRAN, donc ils ne touchent pas la
// conclusion sur la LUMINANCE (elle tient : preservation exacte au miroir,
// ecart relatif max 1.2e-7 %, et livre +0.27 a +1.24 % apres exposition + ACES,
// POSITIF partout) ; ils rabotent seulement l'amplitude de TEINTE annoncee.
//   L    cran 0              cran 1              cran 2              cran 3
//    2   206.0/0.820/0.296   206.5/0.805/0.297   207.0/0.791/0.297   207.3/0.778/0.298
//    5   203.2/0.657/0.480   205.1/0.615/0.482   206.9/0.575/0.485   208.4/0.541/0.487
//   10   202.9/0.368/0.673   207.7/0.315/0.677   213.0/0.266/0.680   218.3/0.225/0.682
//   20   205.4/0.185/0.773   214.1/0.146/0.775   225.9/0.109/0.777   242.4/0.080/0.777
//   60   204.7/0.140/0.798   213.7/0.110/0.800   226.6/0.081/0.801   245.6/0.060/0.801
// CRITERE DE LA PASSE, ET LA CONFIG SUR LAQUELLE IL EST DEFINI. Le chiffre
// vedette ci-dessous est mesure a WATER_TINT = 2, comme toute la table : la
// "bande 204-205 deg" est la bande du cran 0 A WT 2. Elle N'EXISTE PAS aux
// reglages du joueur - au defaut livre (WT 0) la teinte du cran 0 est ~190.6, au
// profil live (WT 1) ~197.1. Sur CES lignes-la, a 10 blocs, le cran 2 apporte
// +3.9 deg (WT 0 : 190.6 -> 194.5) et +7.1 deg (WT 1 : 197.1 -> 204.2). C'est
// cela que le defaut cran 2 achete en pratique ; la bande 204-205 ne peut pas le
// justifier a elle seule. Le critere reste tenu la ou il est defini :
// a 20 blocs, A WT 2, le cran 2 sort la teinte livree de la
// bande 204-205 deg de +20.5 deg (205.4 -> 225.9) pour +0.46 % de luminance,
// tres en dessous de la borne de 2 %. Ecart de luminance maximum sur toute la
// table : +1.07 % (5 blocs), lui aussi sous la borne - et il est POSITIF, donc
// l'eau ne s'assombrit nulle part : le delave rejete a la passe precedente
// venait d'une perte de luminance, celle-ci n'en a pas.
// AU COUCHANT. Vers le soleil : ecart 0.0 deg / 0.00 % partout (porte d'azur).
// Dos au soleil, la ou l'eau lointaine est deja un gris-bleu sombre, l'effet est
// PLUS fort qu'a midi parce que l'etalonnage golden-hour (x1.06/0.93/0.84 et
// +23 % de saturation) amplifie la chroma deja tournee : 209.2 -> 243.1 a 20
// blocs et 210.3 -> 272.5 a 60 blocs au cran 2, pour +0.83 % / +0.65 % de
// luminance. Ecrit noir sur blanc parce que ces angles sonnent violet : a la
// saturation ou ils vivent (0.13-0.18) le pixel reel passe de
// (0.381, 0.440, 0.500) a (0.456, 0.423, 0.484), c'est-a-dire un gris ardoise
// legerement chaud, pas un magenta. Le cran 3 pousse cette meme eau a
// (0.486, 0.417, 0.470), franchement mauve : c'est le cran extreme, il est
// nomme "Fort" et c'est son role.
// COMPOSITION AVEC LA TEINTE DU MILIEU - les deux termes ne se battent pas,
// ils s'additionnent sur des parts DISJOINTES du pixel (le milieu d'un cote,
// le ciel reflechi de l'autre). Matrice HISTORIQUE (EAU6, le palier WT
// n'existe plus depuis EAU8 : seule la ligne WT 1 Naturel decrit le pack
// livre) des teintes a 10 blocs, eau libre, midi :
//                    WST 0    WST 1    WST 2    WST 3
//   WT 0 Vert        190.6    192.7    194.5    195.3
//   WT 1 Naturel     197.1    200.6    204.2    207.4
//   WT 2 Bleu        202.9    207.7    213.0    218.3
//   WT 3 Turquoise   193.9    196.7    199.4    201.4
// Chaque ligne est monotone croissante et chaque colonne conserve l'ordre des
// ambiances de WATER_TINT (Vert < Turquoise < Naturel < Bleu) : aucun couple ne
// s'annule, aucun ne se double. L'AMPLITUDE de WATER_SKY_TINT depend du cran de
// WATER_TINT, et c'est mecanique et voulu : WT_MIRROR pese le miroir
// (0.80/0.90/1.00/0.85), donc moins il y a de ciel dans le pixel, moins le
// teinter le deplace - ecart cran 0 -> cran 2 : +3.8 deg sur Vert, +5.5 sur
// Turquoise, +7.1 sur Naturel, +10.1 sur Bleu. La luminance livree monte de
// +1.61 % au plus sur les seize cases (Vert x Fort), toujours vers le HAUT.
// COUT : nul en pratique - deux racines carrees, un produit scalaire et un
// mix() par pixel D'EAU (jamais sur un pixel de ciel, de terrain ou de vitre),
// et zero instruction au cran 0 (la fonction rend son argument, le compilateur
// la supprime).
#if WATER_SKY_TINT == 1
#define WST_PULL 0.22
#define WST_SAT 0.87
#elif WATER_SKY_TINT == 2
#define WST_PULL 0.46
#define WST_SAT 0.73
#elif WATER_SKY_TINT == 3
#define WST_PULL 0.74
#define WST_SAT 0.60
#else
// Cran 0 : jamais lus (waterSkyTint rend son argument avant de les toucher).
// Definis quand meme pour que le symbole existe a tous les crans, comme le
// reste du fichier.
#define WST_PULL 0.0
#define WST_SAT 1.0
#endif
// Direction de chroma a luma nulle du CIEL DE JOUR du pack (moyenne unitaire
// des directions qu'un plan d'eau reflechit reellement, de 2 a 120 blocs) :
// c'est la reference de la porte d'azur, pas une couleur.
#define WST_AZURE_R -0.50032125
#define WST_AZURE_G 0.06153909
#define WST_AZURE_B 0.86365015
// Direction CIBLE : la direction d'azur ci-dessus tournee de +45 deg autour de
// l'axe achromatique (ardoise indigo, cote chaud du bleu). Litteral a luma
// -1.7e-9 et de norme 1.000000003 : l'erreur de luminance qu'elle introduit
// est bornee par |c| * WST_SAT * 1.7e-9, soit ~1e-9 en lineaire, mille fois
// sous le pas du fp16 des buffers.
#define WST_TARGET_R 0.23733754
#define WST_TARGET_G -0.16715448
#define WST_TARGET_B 0.95693797
// Porte d'azur (produit scalaire des directions de chroma) et epargne des
// hautes lumieres (luminance HDR du ciel, AVANT la mise a l'echelle par la
// lumiere du ciel skyl - donc un seuil absolu, pas relatif a l'ombre du pixel).
#define WST_GATE0 0.15
#define WST_GATE1 0.70
#define WST_HI0 1.5
#define WST_HI1 3.5

// ---------------- IMAGE : EXPOSITION (IMG_EXPOSURE) ----------------
// LES SEPT AXES "IMAGE" SONT DES AXES DE GOUT, PAS DE QUALITE. Ils reglent un
// multiplicateur du grading final : leur cout est nul (aucun echantillon, aucune
// boucle), et "monter" veut dire "plus fort", jamais "mieux". Le cran par defaut
// de chacun est le rendu de reference du pack.
// MESURE (IMG_EXPOSURE) : EXPOSURE -> 0.6 / 0.85 / 1.1 / 1.5.
// EFFET VISIBLE : luminosite globale avant tonemap ; 0.6 assombrit et protege
// les hautes lumieres, 1.5 ouvre l'image et peut ecreter le ciel.
// Palier 1 = la valeur livree (0.85).
#if IMG_EXPOSURE == 0
#define EXPOSURE 0.6
#elif IMG_EXPOSURE == 1
#define EXPOSURE 0.85
#elif IMG_EXPOSURE == 2
#define EXPOSURE 1.1
#else
#define EXPOSURE 1.5
#endif

// ---------------- IMAGE : SATURATION (IMG_SATURATION) ----------------
// AXE DE GOUT, cout nul. MESURE : SATURATION -> 0.9 / 1.05 / 1.25 / 1.6 et
// VIBRANCE -> 0.75 / 1.0 / 1.5 / 2.0. Les deux montent ensemble.
// EFFET VISIBLE : SATURATION agit sur TOUTES les couleurs, VIBRANCE surtout sur
// les couleurs ternes (elle epargne ce qui est deja sature), donc le cran 3
// gonfle la vegetation et le ciel sans cramer les blocs deja colores.
// Un seul axe pour les deux dials du meme terme (composite5 : SATURATION porte
// la saturation globale, VIBRANCE la remontee des couleurs ternes).
// Palier 1 = les valeurs livrees (1.05 / 1.0).
#if IMG_SATURATION == 0
#define SATURATION 0.9
#define VIBRANCE 0.75
#elif IMG_SATURATION == 1
#define SATURATION 1.05
#define VIBRANCE 1.0
#elif IMG_SATURATION == 2
#define SATURATION 1.25
#define VIBRANCE 1.5
#else
#define SATURATION 1.6
#define VIBRANCE 2.0
#endif

// ---------------- IMAGE : CONTRASTE (IMG_CONTRAST) ----------------
// AXE DE GOUT, cout nul. MESURE : TONEMAP_CONTRAST -> 0.5 / 1.0 / 1.5 / 2.0,
// applique comme un dosage de courbe en S (composite5 : mix vers 3x^2-2x^3 a
// 0.18 * TONEMAP_CONTRAST). EFFET VISIBLE : noirs plus fermes et blancs plus
// francs en montant ; a 0.5 l'image devient plate, "documentaire".
// Palier 1 = la valeur livree (1.0).
#if IMG_CONTRAST == 0
#define TONEMAP_CONTRAST 0.5
#elif IMG_CONTRAST == 1
#define TONEMAP_CONTRAST 1.0
#elif IMG_CONTRAST == 2
#define TONEMAP_CONTRAST 1.5
#else
#define TONEMAP_CONTRAST 2.0
#endif

// ---------------- IMAGE : BLOOM (BLOOM_LEVEL) ----------------
// MESURE : BLOOM_STRENGTH -> (eteint) / 0.6 / 1.2 / 2.0, plus la porte derivee
// BLOOM_ACTIVE au cran 0. EFFET VISIBLE : halo autour des sources vives.
// SEUL AXE "IMAGE" QUI A UN COUT : le cran 0 supprime toute la chaine de bloom
// (composite2/composite3 + la composition dans final), les crans 1-3 la paient
// integralement et ne different que par un multiplicateur. Le cout ne monte
// donc PAS avec le cran : il est binaire, 0 contre 1-2-3.
// Le cran 0 eteint le bloom via la porte derivee BLOOM_ACTIVE, seul endroit ou
// elle est posee : il n'y a plus d'interrupteur separe a laisser orphelin.
// NOM EN _ACTIVE, PAS "BLOOM" : le parseur d'options d'Iris ne suit pas les
// conditionnelles, un "#define BLOOM" nu en debut de ligne serait enregistre
// comme BooleanOption CACHEE qu'une vieille config (BLOOM=false) pourrait
// epingler, neutralisant tout le palier sans aucun controle en jeu. Un nom qui
// n'a jamais ete une option de menu ne peut pas etre epingle (voir la liste
// "NE JAMAIS EXPOSER" de shaders.properties).
// BLOOM_STRENGTH est defini dans TOUTES les branches (composite2 lit
// BLOOM_THRESHOLD sans garde, on garde la meme discipline ici).
// Palier 2 = la valeur livree (bloom actif, force 1.2).
#if BLOOM_LEVEL == 0
#define BLOOM_STRENGTH 1.2
#elif BLOOM_LEVEL == 1
#define BLOOM_STRENGTH 0.6
#elif BLOOM_LEVEL == 2
#define BLOOM_STRENGTH 1.2
#else
#define BLOOM_STRENGTH 2.0
#endif
#if BLOOM_LEVEL > 0
#define BLOOM_ACTIVE
#endif

// ---------------- IMAGE : VIGNETAGE (VIGNETTE_LEVEL) ----------------
// AXE DE GOUT, cout nul. MESURE : VIGNETTE -> 0.0 / 0.15 / 0.3 / 0.5.
// EFFET VISIBLE : assombrissement des coins de l'ecran. 0.0 = aucun.
// VIGNETTE est lue SANS garde dans final.fsh, donc 0.0 = eteint.
// Palier 1 = la valeur livree (0.15).
#if VIGNETTE_LEVEL == 0
#define VIGNETTE 0.0
#elif VIGNETTE_LEVEL == 1
#define VIGNETTE 0.15
#elif VIGNETTE_LEVEL == 2
#define VIGNETTE 0.3
#else
#define VIGNETTE 0.5
#endif

// ---------------- IMAGE : NETTETE (SHARPEN_LEVEL) ----------------
// MESURE : SHARPEN_STRENGTH -> (eteint) / 0.38 / 0.6 / 0.9, plus la porte
// SHARPEN_ACTIVE au cran 0. EFFET VISIBLE : rehaussement des contours, utile
// pour compenser l'adoucissement du TAA et surtout de l'upscaling
// (TAA_MODE >= 1). COUT : un flou 3x3 dans final.fsh, paye des le cran 1 ;
// comme le bloom, le cout est binaire (0 contre 1-2-3), pas progressif.
// SHARPEN_STRENGTH n'est lue QUE dans "#ifdef SHARPEN_ACTIVE" (final.fsh), donc
// le cran 0 (pas de porte posee) est exactement l'etat livre : la nettete
// adaptative etait desactivee et sa force de 0.6 restait inerte.
// NOM EN _ACTIVE : meme raison que BLOOM_ACTIVE ci-dessus - un "#define SHARPEN"
// nu serait vu par Iris comme une option booleenne cachee (defaut OFF) qu'une
// vieille config pourrait forcer a true, allumant la nettete a SHARPEN_LEVEL 0.
#if SHARPEN_LEVEL == 0
#define SHARPEN_STRENGTH 0.6
#elif SHARPEN_LEVEL == 1
#define SHARPEN_STRENGTH 0.38
#elif SHARPEN_LEVEL == 2
#define SHARPEN_STRENGTH 0.6
#else
#define SHARPEN_STRENGTH 0.9
#endif
#if SHARPEN_LEVEL > 0
#define SHARPEN_ACTIVE
#endif

// ---------------- IMAGE : EFFET DE DEGATS (DAMAGE_LEVEL) ----------------
// AXE DE GOUT. MESURE : DAMAGE_FX_STRENGTH -> (eteint) / 0.5 / 1.0 / 2.0, plus
// la porte numerique DAMAGE_FX. EFFET VISIBLE : intensite du flash rouge et de
// la deformation quand le joueur perd des points de vie. COUT : binaire aussi
// (0 contre 1-2-3), et de toute facon nul hors des instants de degats.
// DAMAGE_FX est un [0 1] numerique lu en VALEUR (composite5 : "#if DAMAGE_FX == 1",
// l.86 / 1079 / 1862 - jamais "#ifdef"). C'est precisement pour cela que le cran 0
// peut poser "#define DAMAGE_FX 0" au lieu de ne rien poser : un "#ifdef" aurait
// evalue VRAI sur cette ligne et laisse l'effet allume a DAMAGE_LEVEL 0.
// Palier 2 = l'etat livre (actif, force 1.0).
#if DAMAGE_LEVEL == 0
#define DAMAGE_FX_STRENGTH 1.0
#elif DAMAGE_LEVEL == 1
#define DAMAGE_FX_STRENGTH 0.5
#elif DAMAGE_LEVEL == 2
#define DAMAGE_FX_STRENGTH 1.0
#else
#define DAMAGE_FX_STRENGTH 2.0
#endif
#if DAMAGE_LEVEL > 0
#define DAMAGE_FX 1
#else
#define DAMAGE_FX 0
#endif
// ---- AUDIT DES PALIERS : CE QUI RESTE HORS AXE, ET POURQUOI ----
// Question posee a l'audit : "un parametre de cout important est-il sous AUCUN
// axe et reste-t-il fige quel que soit le palier ?". Deux l'etaient et ont ete
// rebranches (GI_HALF_RES sous GI_QUALITY, VL_HALF_RES sous
// VOLUMETRIC_QUALITY -- puis RE-FIGE a 1 partout par la passe VQ3 : le 0 du
// palier 3 multipliait la marche par 4 pour un gain sub-JND, le budget est
// reinvesti en 32 pas + portee UW 128, et le plein ecran vit sur le define
// expert VL_FULL_RES, sous l'axe). Les suivants restent HORS AXE, volontairement :
//   CLOUD_HALF_RES / CLOUD_TEMPORAL  Les plus gros leviers de cout des nuages.
//     Les passer a 0 au dernier cran multiplierait la facture nuages par ~6.6
//     (x4 pixels x 48/29 echantillons) : "Tres eleve" deviendrait injouable au
//     lieu d'etre cher. CLOUD_QUALITY monte deja les echantillons x6.
//   BLOOM_HALF_RES                   Le bloom n'a pas d'axe de QUALITE (seul
//     BLOOM_LEVEL existe, et c'est un axe de gout dont le cout est binaire).
//     Un flou gaussien demi-res est indiscernable d'un plein-res a l'oeil.
//   MOTION_BLUR_SAMPLES              MOTION_BLUR est un simple ON/OFF ; 8
//     echantillons est la valeur ou l'effet cesse de montrer des fantomes.
//   AO_QUALITY, SHADOW_DISTORT_STRENGTH, SHADOW_Z_SCALE, VLX_PCSS_CAP
//     Ce sont des CALIBRATIONS globales, pas des budgets : les faire varier par
//     palier changerait le LOOK d'un cran a l'autre au lieu de sa finesse.
//     (Depuis la passe LOD, SHADOW_DISTORT_STRENGTH n'est lue qu'a
//     SHADOW_LOD_V2 0 ; la courbe plateau expose ses DEUX axes au menu,
//     SHADOW_SHARP_LEVEL / SHADOW_SHARP_RANGE -- gratuits, ce sont des axes de
//     REPARTITION de la carte, pas des budgets non plus.)
//   GI_SAMPLES                       Ne sert qu'a SS_LIGHTS, chemin legacy
//     eteint (//#define SS_LIGHTS) : le brancher sur un axe creerait un symbole
//     mort et une infobulle mensongere, exactement le piege POM_SAMPLES.
// CONSOMMATEURS ORPHELINS : aucun au moment de l'audit. Chaque symbole derive
// d'un axe a ete verifie et a au moins un lecteur REEL hors de ce fichier (le
// piege connu est POM_SAMPLES, qui n'etait lu nulle part : ne jamais deriver un
// symbole d'un axe sans verifier son consommateur). Deux cas limites, documentes
// sur place :
//   CONTACT_SHADOW_STEPS  n'est lu que sous "#ifdef CONTACT_SHADOWS", qui est
//     commente par defaut et sur aucun ecran : la valeur suit bien l'axe, mais
//     elle ne change rien tant que le joueur n'a pas active les contact shadows
//     a la main dans ce fichier.
//   TAAU_RENDER_SCALE     n'est lue que sous "#if defined TAA && TAA_UPSCALING
//     == 1" : TAA_MODE != 0 avec TAA decoche ne fait rien (d'ou TAA=true epingle
//     dans les profils POTATO et MEDIUM).
// ================ FIN DES AXES DE MENU ================
const float shadowDistanceRenderMul = 1.0;   // [-1.0 0.5 0.75 1.0 1.5 2.0 3.0 4.0]
// ENTITY shadow range = entityShadowDistanceMul * shadowDistance. This is an Iris GLSL CONST
// (read from composite/deferred/final - settings.glsl is included by final.fsh), NOT a
// shaders.properties key: an "entityShadowDistanceMul=1.0" line there is silently ignored.
// 0.5 = entities cast only within half the terrain shadow range (128 blocks at HIGH): a mob
// shadow is invisible that far anyway, and villages/farms stop flooding the shadow pass.
// Raise to 1.0 (Iris default) if distant entities visibly lose their shadow.
const float entityShadowDistanceMul = 0.5;
const float sunPathRotation         = -35.0; // [-90.0 -75.0 -60.0 -50.0 -40.0 -35.0 -25.0 -10.0 0.0 25.0 45.0 90.0]

// PSEUDO-CASCADES (rectilinear distortion, lib/distort.glsl): concentrates
// shadow map texels near the player. Iris has a SINGLE shadow pass (no real
// multi-cascade), so the distortion IS the pseudo-cascade - resolution decays
// continuously with distance, with no seams.
// 0.85 matches the old fixed constant at shadowDistance 256; 0.90 was raised
// when SHADOW_QUALITY 3 went to shadowDistance 384, to keep the near texel
// identical to 0.85 at 256 (edge texel ~1.5x coarser in exchange).
// IT IS A SINGLE GLOBAL VALUE, SHARED BY THE FOUR SHADOW_QUALITY TIERS, so it
// does NOT re-normalise anything between tiers: the near world texel is
// (2 * shadowDistance / shadowMapResolution) * (1 - S) at every tier, and it is
// the resolution/distance PAIR that has to progress. That is exactly why tier 3
// now carries shadowMapResolution 8192 -- see the SHADOW_QUALITY block at the
// top of this file for the four-tier table.
// Do NOT exceed 0.92: beyond that the per-vertex distortion visibly bends the
// shadow edges of large triangles.
// PCSS, bias and texel size follow automatically (all depend on the factor f).
// NOTE LOD : depuis SHADOW_LOD_V2 (bloc suivant, ON par defaut) cette pente
// n'est LUE qu'a SHADOW_LOD_V2 0 -- la courbe plateau a ses propres tables.
#define SHADOW_DISTORT_STRENGTH 0.90 // [0.80 0.85 0.88 0.90 0.92]

// ---------------- LOD D'OMBRE (SHADOW_LOD_V2 + les 2 axes du menu) ----------------
// Demande du createur : "plus c'est loin plus la res est basse, comme dans les
// vrais jeux, pour garder de super details de pres tout en gagnant des perfs
// meme en qualite basse ; la res basse mais aussi la distance de cette res".
// LE MECANISME EXISTAIT DEJA : la distorsion ci-dessus EST une resolution
// degressive avec la distance (x10 au centre a S=0.90). Ce bloc la RE-PROFILE
// (un vrai PLATEAU de nettete constante autour du joueur, puis une chute
// franche) et l'EXPOSE en deux axes de menu (ecran QUALITE, bloc ombres) :
//   SHADOW_SHARP_LEVEL  [0-3]  NETTETE de la zone proche = grossissement du
//                              plateau : x3.3 / x5 / x7.1 / x10 du texel de
//                              base du palier d'ombres (VLX_LOD_M0 ci-dessous).
//   SHADOW_SHARP_RANGE  [0-3]  PORTEE de la zone nette : 12 / 20 / 32 / 48
//                              blocs demandes (VLX_LOD_R), bornee par le
//                              budget (voir CLAMP) -- le rayon LIVRE est
//                              min(R, QMAX * M0 * 1.08 * shadowDistance).
// RAYONS LIVRES (R0/R1/R2/R3 en blocs, par palier d'ombres -- PLATEAUX
// ASSUMES : les crans hauts saturent le budget et peuvent COINCIDER, comme le
// plateau documente de UW_SHAFT_SUBSTEPS ; l'infobulle .lang le dit au joueur
// avec ces memes chiffres) :
//   L2 (defaut) : SQ0 12 / 13.9 / 13.9 / 13.9   SQ1 12 / 20 / 20.9 / 20.9
//                 SQ2 12 / 20 / 27.9 / 27.9     SQ3 12 / 20 / 32 / 41.8
//     -> au defaut SQ1, "Longue" et "Tres longue" sont IDENTIQUES et
//        "Moyenne"->"Longue" ne vaut que +4.5%.
//   L3 : SQ0 8.3 aux QUATRE crans   SQ1 12 / 12.4 / 12.4 / 12.4
//        SQ2 12 / 16.6 / 16.6 / 16.6   SQ3 12 / 20 / 24.9 / 24.9.
//   L0/L1 saturent moins (L0 livre 12/20/32/48 pleins des SQ2).
// Le "12 / 20 / 28 / 42" des infobulles de profil est la DIAGONALE
// SQ0R0 -> SQ3R3 (ce que les profils livrent), PAS l'axe a qualite fixe.
// COURBE (formules, derivee, inverse, monotonie : en-tete de lib/distort.glsl,
// LE SEUL site qui l'implemente -- l'ecrivain shadow.vsh et TOUS les lecteurs
// passent par getDistortFactor/getDistortDeriv/distortShadow, verifie par grep
// sur l'arbre entier ; le seul site qui dupliquait la PENTE, le jacobien de
// sampleShadowPCFV2, est passe sur getDistortDeriv par cette passe).
// L'AIRE DE TEXELS EST FIXE : la carte fait toujours shadowMapResolution^2 et
// couvre toujours tout le disque shadowDistance (f(1) = 1 exact). Un plateau
// plus net ou plus large se paie donc a mi-distance et au bord. TAUX D'ECHANGE
// (texel RADIAL en cm : centre / bord du plateau / mi-distance / bord de carte,
// courbe actuelle en tete ; RANGE 0 partout ; le tangentiel, moins puni, est
// dans les infobulles .lang) :
//   Q0 1024/128  actuel 2.50 /  --  /  75.6 / 250   (le "bord du plateau"
//     L0 x3.3    7.50 /  8.75(12blk)  / 43.3 /  78     actuel n'existe pas :
//     L2 x7.1    3.50 /  4.08(12blk)  / 98.4 / 171     la nettete s'evapore
//     L3 x10     2.50 /  2.92(8.3blk) / 101  / 170     des le premier bloc)
//   Q1 2048/192  actuel 1.88 /  --  /  56.7 / 188
//     L2 x7.1    2.63 /  3.06(12blk) / 49.3 /  84
//     L3 x10     1.88 /  2.19(12blk) / 71.8 / 121
//   Q2 4096/256  actuel 1.25 /  --  /  37.8 / 125
//     L2 x7.1    1.75 /  2.04(12blk) / 28.4 /  48
//   Q3 8192/384  actuel 0.94 /  --  /  28.4 /  94
//     L2 x7.1    1.31 /  1.53(12blk) / 18.8 /  31
// Lecture : au defaut L2/R0 le bord de carte est MOINS grossier qu'avant a tous
// les paliers (la rampe cubique repartit ce que l'ancienne hyperbole entassait
// sur l'anneau final) ; la facture du plateau tombe a mi-distance (ex. Q1 :
// 49.3 cm contre 56.7 -- meme mieux -- mais a L3 : 71.8 contre 56.7).
// GAIN REEL EN QUALITE BASSE (le but demande) -- texel radial a 5/15/40/100
// blocs, "ancien Eleve" = courbe actuelle a SHADOW_QUALITY 2 (la reference que
// le joueur connait) :
//   ancien Eleve (4096)      : 1.7 / 2.9 /  7.2 / 25.5 cm
//   Q1+L3 (carte 2048, x4 de remplissage en moins) : 2.0 / 6.5 / 33.5 / 74.2,
//     plateau 1.88 cm sur 12 blocs -> les 12 premiers blocs au niveau de
//     l'ancien Eleve pour le prix d'une carte MEDIUM ;
//   Q0+L3 (carte 1024)       : 2.7 / 22.7 / 68.3 / 142, plateau 2.50 cm sur
//     8.3 blocs -> le pied du joueur au niveau de l'ancien Eleve pour le prix
//     d'une carte POTATO (au-dela de ces 8 blocs, l'echange se paie cash).
// ATTENTION PROFILS : ces deux configurations chiffrees (Q1+L3, Q0+L3) sont
// des reglages 100% MANUELS -- les quatre profils epinglent
// SHADOW_SHARP_LEVEL=2 (raison ecrite au bloc MONOTONIE de
// shaders.properties). POTATO tel que livre (SQ0/L2/R0) vaut, aux memes
// 5/15/40/100 blocs : 3.7 / 12.5 / 63.9 / 141.4 cm contre 4.6 / 10.6 / 36.3 /
// 161.3 pour la courbe actuelle a SQ0 -- mieux a 5 et 100 blocs, mais x1.18
// plus grossier a 15 et x1.76 a 40. Le gain "meme en qualite basse" demande
// par le createur ne se prend donc PAS au menu profil : il se prend a la main
// (nettete Tres elevee + portee Courte), et L3 dans POTATO aurait ete pire
// encore a mi-champ (22.7 cm a 15 blocs contre 12.5) -- d'ou le choix.
// COUT ALU DE LA BASCULE (ce que "GRATUIT" ne couvre PAS) : gratuit qualifie
// les deux AXES (constantes pliees a la compilation, meme cout aux 16 crans),
// pas SHADOW_LOD_V2=1 lui-meme. La branche rampe de getDistortFactor coute
// cbrt(pow) + sqrt + cbrt(pow) + 3 divisions la ou la courbe legacy coutait
// cbrt(pow) + 1 mad, et la rampe couvre presque tout le disque (plateau 12
// blocs sur 192 au defaut). Sites en boucle interne : RSM (composite.fsh,
// 3 appels par echantillon x RSM_SAMPLES jusqu'a 24 a GI_QUALITY 3 = jusqu'a
// 72 resolutions de Cardano par pixel GI), marche VL (composite1.fsh et
// lib/vl_halfres.glsl, 1 par pas), recepteurs (lib/lighting.glsl, ~1-3 par
// pixel). ALU pure, comptee ici en operations ; le remplissage et la VRAM de
// la passe, eux, sont chiffres plus haut.
// CLAMP (aire + stabilite), pose dans distort.glsl : le plateau ne peut pas
// occuper plus de QMAX = min(0.72, 6*M0) du rayon de la carte.
//   - aire : a 2.5 cm sur 12 blocs une carte 1024 devrait loger 960 px de
//     plateau par axe sur 1024 -- il ne resterait rien pour les 116 blocs
//     restants. Le clamp borne le texel de bord a 9.22x le texel de base au
//     PIRE des 64 couples (Q0/L2/R1), soit JAMAIS pire que la courbe actuelle
//     (10x a S=0.90).
//   - stabilite : la carte est ancree sur le joueur, la jonction plateau->rampe
//     marche avec lui. L'erreur d'interpolation par sommet de shadow.vsh sur
//     des faces de 1 bloc (estimateur : fleche de corde sur un segment radial
//     de 1 bloc, sag = |q''|*dw^2/8 convertie en texels, q'' = -h''/h'^3)
//     culmine a 2.8 px sur les 64 couples avec ce QMAX par niveau -- 1.3 px
//     des le defaut L2/R0 a SHADOW_QUALITY 0 -- contre 0.6-0.7 px pour la
//     courbe actuelle, et ~4.8 px si on laissait L3 porter un long plateau
//     (d'ou le 6*M0 qui serre le cran x10). La rampe a h''=0 de SON cote de
//     la jonction seulement (cote plateau h'' = 2*M0*TILT*1.08^3 ~ 0.063 aux
//     defauts) : raccord C1, pas C2 -- et c'est h' qui compte : continu, donc
//     texel, jacobien J et biais Tb varient continument, aucun bord d'ombre
//     ne saute quand on marche.
// DEFAUTS L2 / R0 : calcules, pas choisis -- distance L2 log-ponderee a la
// courbe actuelle sur tout le disque (radial + tangentiel, poids 1/(0.05+d)).
// Les valeurs ABSOLUES de cette metrique dependent de la normalisation et du
// domaine d'integration retenus et ne sont pas reproductibles depuis cette
// seule phrase ; l'enonce VERIFIABLE (retrouve par deux implementations
// independantes de la recette) est l'ORDRE : L2R0 est le couple le plus
// proche de la courbe actuelle au palier d'ombres par defaut, nettement
// devant le deuxieme (L1R1 ou L2R1 selon la normalisation). Le rendu d'un
// pack fraichement installe bouge donc au minimum possible.
// CONSOMMATEURS VERIFIES avec la nouvelle courbe (chacun ne depend que de f,
// de J ou du zscale -- jamais de la forme de la courbe) : sampleShadowPCF
// (texel uv = 1/(res*f), biais en f), sampleShadowPCFV2 + shadowReceiverV2
// (J et Tb via getDistortDeriv, ci-dessus), caustiques et waterAboveShadow[Glass]
// (composite1 : chaine avant getDistortFactor->distortShadow, delta-z pur),
// lavaGlowAt (sonde +-1.5 blocs convertie par 1/f tangentiel, comme avant),
// RSM (composite.fsh : offsets en CLIP re-distordus par echantillon, base de
// difference finie eClip exacte par construction), marche VL de composite1 et
// son MIROIR lib/vl_halfres.glsl (diff refaite apres cette passe : les deux
// sites restent identiques, AUCUN des deux ne touche a la courbe ; leur rampe
// de bord "0.02" se resout sur 1-sp = 0.02, soit u = sc/f = 0.96 puisque
// sp = u*0.5+0.5, largeur (1 - h(0.96))*shadowDistance : 31.5 / 32.1 / 37.0 /
// 48.8 blocs au defaut L2/R0 selon le palier d'ombres, et de 15.2 (couple le
// plus ETROIT : L0/R0 a SHADOW_QUALITY 0) a 122.7 (L2/R3 a SHADOW_QUALITY 3)
// sur les 64 couples, contre 37.6 / 56.5 / 75.3 / 112.9 pour la courbe
// actuelle a S=0.90 : le critere ">= la plus large lame de caustique,
// 6 blocs" tient partout),
// debugShadowClassify (meme recepteur que la passe reelle). shadow.culling et
// shadowDistanceRenderMul : inchanges -- le culling d'Iris raisonne en volume
// MONDE (sections pouvant projeter dans le frustum), la distorsion n'y entre
// pas ; la couverture du disque etant identique (f(1)=1), aucun des deux
// n'avait a bouger.
// SHADOW_LOD_V2 0 = courbe actuelle BIT-IDENTIQUE (meme expression, meme ordre
// d'operations, jacobien V2 compris) pour comparaison A/B en jeu. Regle du
// menu : un numero de version ne remonte jamais a l'ecran -- la bascule reste
// ici, seuls les deux axes sont exposes.
#define SHADOW_LOD_V2 1 // [0 1]
// Tables des deux axes (consommees par lib/distort.glsl ; le pattern multi-
// branches est le meme que VLX_SEARCH_TAPS / SHADOW_SAMPLES, sans danger pour
// le scanner d'options d'Iris qui ne suit pas les #if).
#if SHADOW_SHARP_LEVEL == 0
#define VLX_LOD_M0 0.30
#elif SHADOW_SHARP_LEVEL == 1
#define VLX_LOD_M0 0.20
#elif SHADOW_SHARP_LEVEL == 2
#define VLX_LOD_M0 0.14
#else
#define VLX_LOD_M0 0.10
#endif
#if SHADOW_SHARP_RANGE == 0
#define VLX_LOD_R 12.0
#elif SHADOW_SHARP_RANGE == 1
#define VLX_LOD_R 20.0
#elif SHADOW_SHARP_RANGE == 2
#define VLX_LOD_R 32.0
#else
#define VLX_LOD_R 48.0
#endif
// SHADOW_Z_SCALE: shadow map Z packing (distortShadow, lib/distort.glsl).
// The Iris shadow frustum has a FIXED depth range (~near 0.05 / far 256, light
// camera 100 blocks from the player) INDEPENDENT of shadowDistance. A z*0.5
// packing only covers ~-230..+280 blocks ALONG THE SUN AXIS, so at low/medium
// sun the shadows die around 250-400 blocks whatever shadowDistance says (sun
// side: falsely lit terrain; opposite side: false darkening).
// 0.2 gives ~-612..+668 blocks, covering view distance 512 at any sun height.
// Reader-side biases rescale automatically through the (SHADOW_Z_SCALE * 2.0)
// factor - exact no-op at 0.5. GPU cost: zero, only z precision distribution
// changes.
#define SHADOW_Z_SCALE 0.2 // [0.5 0.3 0.25 0.2 0.15]
#define SHADOW_SOFTNESS 1.0 // [0.0 0.1 0.25 0.5 1.0 1.5 2.0 3.0 5.0 8.0 12.0]
// SHADOW_SAMPLES: derived from SHADOW_QUALITY (quality block at the top of this file)
#define PCSS
// LIGHT_SIZE: sun angular size as a MULTIPLE OF THE REAL SUN (0.53 deg ->
// penumbra width 0.0093 block per block of occluder distance). SHADOW_V2:
// 1.0 = physical penumbra, 3.0 (default) = the SAME penumbra the legacy path
// produced 10 blocks behind an occluder (measured: legacy radius 0.146 blk at
// MEDIUM / 0.150 at HIGH vs 0.0465 physical -> x3.1-3.2), so the overall look
// is unchanged while contact shadows become texel-sharp. Legacy path
// (SHADOW_V2 0): the value is rescaled by 0.25/3.0 inside lighting.glsl, so
// this 3.0 default reproduces the old 0.25 slope bit-exactly.
// Visual sun disc size is SUN_SIZE, unrelated.
#define LIGHT_SIZE 3.0 // [0.0 0.5 1.0 1.5 2.0 3.0 4.0 6.0 8.0 12.0]

// ---- SHADOW_V2 (lib/lighting.glsl): texel-proportional bias + hardware PCF + physical PCSS ----
// 1 (default): (a) normal offset and depth bias PROPORTIONAL TO THE DISTORTED
// TEXEL footprint (slope-scaled: ~2-4 cm at the player instead of the fixed
// 6.7 cm of the legacy bias, larger far away where texels are coarse, so acne
// stays impossible); (b) every PCF tap is a hardware 2x2 bilinear depth
// comparison (shadowtex0HW/shadowtex1HW, Iris SEPARATE_HARDWARE_SAMPLERS) in
// the near field and on side-lit surfaces; far sun-aligned receivers, where
// the radial texel is up to 5x the tangential one, compare against the
// linear-interpolated raw depth instead (plane-exact, 4x smaller bias);
// (c) PCSS penumbra = LIGHT_SIZE x real-sun angle x blocker distance, floor of
// ONE distorted texel (the legacy floor was 6 texels at the player), cap 2
// blocks; (d) Vogel disc rotated by spatio-temporal blue noise (TAA-integrated);
// (e) per-tap receiver-plane depth bias (no self-shadow halo on slopes inside
// wide penumbrae). 0 = legacy path, bit-identical, for in-game A/B comparison.
#define SHADOW_V2 1 // [0 1]
// Depth bias in DISTORTED texels along the light axis (SHADOW_V2 only), texel
// measured along the receiver's uphill direction. Every tap is compensated for
// the receiver plane, so only the 2x2 hardware footprint (<= 1.41 texels) can
// self-shadow: with the slope-scaled normal offset, 1.5 keeps a margin >= x1.5
// at every angle up to a grazing sun (lib/lighting.glsl header). The foot of a
// vertical caster's shadow starts at SHADOW_BIAS_TEXELS * cos(sunElev) texels
// (0.8-1.4 texels at 1.5, i.e. 1-2.5 cm at the player). Lower = tighter contact,
// higher = safer on steep slopes / noisy normals.
#define SHADOW_BIAS_TEXELS 1.5 // [0.5 0.75 1.0 1.25 1.5 2.0 2.5 3.0 4.0]
// Iris const, HORS de tout #if (le scanner de const d'Iris ne suit pas
// forcement les #if, et la valeur est vraie sur les deux chemins de toute
// facon) : le pack n'ECRIT que gl_FragData[0] dans shadow.fsh et ne LIT que
// shadowcolor0 (verifie sur tout l'arbre). Sans cette borne Iris alloue les
// deux buffers couleur d'ombre par defaut, soit 8192^2 * 4 = 256 Mio de pure
// perte au palier SHADOW_QUALITY 3, et le budget VRAM annonce au joueur en
// tete de ce fichier serait faux d'un tiers.
const int shadowColorBuffers = 1;
#if SHADOW_V2 == 1
// Iris consts (read from the fragment programs): hardware depth compare on both
// shadow depth maps. shaders.properties requires SEPARATE_HARDWARE_SAMPLERS, so
// shadowtex0/shadowtex1 stay raw depth (blocker search, caustics, VL, debug)
// and only shadowtex0HW/shadowtex1HW (sampler2DShadow) do the compare.
const bool shadowHardwareFiltering0 = true;
const bool shadowHardwareFiltering1 = true;
#endif

// ---- Foliage/entity shadows: two independent fixes, each with a fallback ----
// (a) CASTER (shadow.fsh): the shadow-pass discard tests the TEXTURE alpha only.
//     When gl_Color.a arrives near 0 for entities/the player (vertex format or overlay in
//     the Iris shadow pass), a (tex.a * glcolor.a < 0.1) test erases their entire geometry
//     from the shadow map and they cast nothing. 0 = old combined test.
#define SHADOW_CUTOUT_FIX 1 // [0 1]
// (b) RECEIVER (lighting.glsl + composite1): when Iris writes foliage/entities into
//     shadowtex0 ONLY (tex1 excludes the translucent phase), an s1 gate makes them nearly
//     invisible (light tint instead of occlusion). The 3-state tag therefore lives in RGB
//     BANDS of shadowcolor0 with alpha forced to 1.0, so the write SURVIVES the Iris shadow
//     pass alpha blend (an alpha-encoded tag is destroyed even with blend.shadow=off).
//     Bands (encoded in shadow.fsh; decoded in lighting.glsl, composite1 x2, composite RSM,
//     final debug views): WATER rgb*0.30 [0..0.30], GLASS/PORTAL rgb*0.30+0.35, SOLID
//     rgb*0.30+0.70. The WHITE clear of shadowcolor0 lands in the SOLID band (fail-safe:
//     full occlusion even if the color write fails). 0 = old alpha encoding.
#define SHADOW_TEX1_GATE_FIX 1 // [0 1]

/*
    ============ OMBRES PIXEL-PERFECT (PIXEL_SHADOWS) ============
    Option de menu declaree tout en haut de ce fichier (ecran QUALITE, a cote
    des trois autres axes d'ombre). DEFAUT 0, et PIXEL_SHADOWS=0 est ecrit dans
    les QUATRE profils de shaders.properties : choisir un profil ETEINT
    l'option, toujours. A 0 le pack est BIT-IDENTIQUE au pack sans l'option
    (tout le code ajoute vit sous #if PIXEL_SHADOWS == 1, les trois macros
    ci-dessous se reduisent textuellement a leur argument).

    CE QUE CA FAIT. Le RECEVEUR -- le point du sol/du mur dont on teste
    l'eclairement -- est ramene au CENTRE de son texel de bloc avant d'etre
    projete dans la shadow map. Tous les pixels d'ecran qui tombent dans le
    meme texel de 1/16 de bloc interrogent donc EXACTEMENT le meme endroit de
    la carte et recoivent EXACTEMENT la meme visibilite : le bord d'ombre
    cesse d'etre une courbe filtree et devient un escalier dont les marches
    sont les pixels de la texture 16x16 du bloc. C'est le look "voxel".

    LA GRILLE. PIXEL_SHADOW_GRID (hors menu, juste sous ce bloc) = nombre de
    texels par bloc, 16.0 = la resolution vanilla. Le snap vise le CENTRE du
    texel, (floor(w * G) + 0.5) / G, et NON le noeud round(w * G) / G : les
    frontieres d'un texel de bloc sont aux multiples de 1/16 en coordonnees
    monde (le texel k d'une face couvre [n + k/16, n + (k+1)/16]), donc c'est
    floor() qui fait tomber les marches sur les bords des pixels de la
    texture ; round() les decalerait d'un demi-texel et l'escalier ne
    coinciderait plus avec le damier de la texture.

    L'AXE QU'ON NE SNAPPE PAS. Deplacer le receveur le long de sa PROPRE
    NORMALE le fait entrer dans le bloc (acne) ou en sortir (ombre decollee,
    "peter-panning"). Le snap ne touche donc que les DEUX axes tangents : on
    prend l'axe monde dominant de la normale et on le laisse intact. Sur une
    face de bloc (normale = un axe exactement) c'est exact : le point reste
    rigoureusement dans le plan de la face, l'acne ajoutee est nulle par
    construction. Sur une surface OBLIQUE (entites, feuillage, marches,
    normal-map PBR) glisser dans le plan xz d'une pente ferait quand meme
    sortir du plan, alors le point est REMIS SUR SON PLAN TANGENT en bougeant
    UNIQUEMENT le long de l'axe dominant : p_a += (n . (p - p_snap)) / n_a.
    Cette correction est exactement 0 sur une face alignee, elle est constante
    par cellule sur un plan quelconque (donc elle ne "deflouterait" pas les
    marches), et |n_a| >= 1/sqrt(3) pour une normale unitaire, donc pas de
    division dangereuse (une normale NULLE -- cas theorique -- desactive la
    correction ; les particules et la main passent la DIRECTION DE LA LUMIERE
    comme normale, alors le snap glisse dans le plan perpendiculaire a cet axe,
    ce qui est inoffensif : leur offset est deja porte par la lumiere).
    L'offset normal existant (toShadowClip et shadowReceiverV2) est conserve
    tel quel par-dessus : le snap ne le remplace pas, il ne fait que ne pas le
    contrarier.
    MESURE (harnais px_acne.py / px_acne2.py) : deplacement HORS PLAN du
    receveur = 0.00000 bloc sur +X, +Y, +Z et sur deux pentes obliques, et
    fraction de texels auto-ombres sur une face plane isolee = 0.000 % aux
    trois orientations, a 0 / 10 / 30 blocs, soleil a 55 et a 18 degres. Avec
    un snap NAIF des trois axes la meme mesure remonte a 44-50 % d'acne sur
    les murs des que la grille grossit, et le snap tangent SANS la reprojection
    a 16-37 % sur une pente a 45 degres : les deux precautions sont donc
    necessaires, pas decoratives.

    LE PLAN RECEVEUR DE SHADOW_V2. shadowReceiverV2 estime la pente du
    receveur avec dFdx/dFdy(viewPos) pour compenser la profondeur par tap. Une
    position SNAPPEE a des derivees NULLES a l'interieur d'un texel et
    ENORMES a la frontiere : le gradient serait faux partout. Le calcul du
    normal geometrique est donc HISSE AVANT le snap (et hors du if, donc en
    controle uniforme, ce qui est en prime plus correct pour dFdx) et le snap
    n'est applique qu'apres.

    TAA ET RESOLUTION DE RENDU. Le jitter TAA fait tomber un pixel d'ecran
    sur des points monde legerement differents d'une frame a l'autre ; comme la
    visibilite est CONSTANTE a l'interieur d'un texel de bloc, le seul endroit
    ou ca varie est le bord de marche, que le TAA antialiase donc a l'echelle
    du sous-pixel -- c'est souhaitable, ca enleve l'escalier de PIXELS D'ECRAN
    sans toucher a l'escalier de TEXELS DE BLOC. Sous TAAU (TAA_MODE > 0) le
    rendu est upscale : les marches restent alignees, elles sont juste dessinees
    avec moins de pixels d'ecran.

    COORDONNEES ABSOLUES. La grille est ancree sur le MONDE, pas sur la camera
    (sinon elle glisserait avec le joueur). Les caustiques snappent world0.xz /
    world1.xz tels quels, comme tout le reste du code de caustiques, donc elles
    heritent de la precision float32 de ces coordonnees : au-dela de ~1e6 blocs
    de l'origine l'ecart entre deux floats depasse 1/16 et la grille se
    degrade. Le RECEVEUR d'ombre, lui, passe par la decomposition entier +
    fraction decrite plus haut et reste exact partout.

    LE FILTRAGE : "FLOUTER, PUIS PIXELISER". La penombre PCSS (recherche de
    bloqueurs + disque PCF de Vogel, largeur = taille du soleil x distance au
    bloqueur) est CONSERVEE sous l'option, dans les trois echantillonneurs
    (sampleShadowPCFV2, sampleShadowPCF legacy, sampleShadowWaterLite) : elle
    est simplement evaluee AU CENTRE DU TEXEL SNAPPE. Comme tous les pixels
    d'ecran d'un meme texel de bloc partagent ce centre, ils partagent aussi
    le rayon de penombre et le disque de taps : le texel recoit UNE valeur,
    celle du filtre au centre. Resultat : une ombre au contact de son bloc
    garde un bord net (penombre plus fine qu'un texel -> une seule marche),
    une ombre portee par un bloqueur lointain s'elargit en MARCHES DE GRIS,
    chaque marche etant un texel de 1/16 -- c'est exactement le flou d'abord,
    la quantification ensuite. La rotation bleue du disque (blueDither par
    pixel + frame) reste par pixel d'ecran : le bruit INTRA-texel qu'elle
    laisse avant TAA est le meme qu'a PIXEL_SHADOWS 0 et le TAA l'integre vers
    la valeur commune du texel (meme centre, meme rayon -> meme esperance).
    Le plan receveur par tap (g), la borne d'un texel de carte et le tap 2x2
    materiel du chemin V2 fonctionnent inchanges autour du centre snappe (le
    point est reste dans le plan tangent, cf. la reprojection ci-dessus).
    MESURE (harnais pxs_image.py, meme modele que px_image.py, bloc flottant a
    1 / 4 / 16 blocs, soleil 35 deg) : ecart INTRA-texel maximal 0.00000 aux
    trois hauteurs (chaque cellule 1/16 est uniforme, comme en tap dur), et
    largeur de penombre au bord gauche 1 / 2 / 4 texels de bloc (0.062 /
    0.125 / 0.234 bloc) contre 0.047 / 0.109 / 0.250 bloc pour l'ombre par
    defaut : meme largeur physique, quantifiee sur la grille. Niveaux de gris
    distincts 117 / 235 / 299 contre 54 / 37 / 68 en tap dur.
    SHADOW_SOFTNESS / LIGHT_SIZE gardent donc leur effet sous l'option ;
    SHADOW_QUALITY pilote toujours la RESOLUTION et la PORTEE de la carte (et
    donc la fidelite des marches, cf. le tableau ci-dessous), l'occlusion
    ambiante et les contact shadows.
    VARIANTE BINAIRE : PIXEL_SHADOW_HARD (hors menu, sous PIXEL_SHADOW_GRID) =
    1 remet le tap DUR unique de la premiere livraison (aucune penombre, 2 taps
    au lieu de 18-54, le look le plus "voxel"). Les trois blocs
    `#if PIXEL_SHADOWS == 1 && PIXEL_SHADOW_HARD == 1` de lib/lighting.glsl
    sont ce chemin ; a 0 ils tombent textuellement sur le chemin PCSS normal.

    RESOLUTION : JUSQU'OU LES MARCHES SONT FIDELES. Pour qu'une marche soit
    exacte il faut que la shadow map resolve mieux que 1/16 de bloc (0.0625)
    AU RECEVEUR. Texel RADIAL de la carte (le pire des deux axes, distorsion
    SHADOW_LOD_V2 comprise) aux defauts livres SHADOW_SHARP_LEVEL 2 /
    SHADOW_SHARP_RANGE 0, en blocs, mesure a la distance joueur :

        palier            0 bl    10 bl    30 bl    60 bl   fidele jusqu'a
        Q0 1024/128 bl  0.0350   0.0398   0.4671   0.9311      13 blocs
        Q1 2048/192 bl  0.0263   0.0299   0.1618   0.3314      17 blocs
        Q2 4096/256 bl  0.0175   0.0199   0.0724   0.1503      27 blocs
        Q3 8192/384 bl  0.0131   0.0149   0.0346   0.0714      52 blocs

    Lecture : autour du joueur la carte est 2 a 5 fois plus fine que le texel
    de bloc, donc les marches sont EXACTES. Au-dela de la colonne "fidele
    jusqu'a", un texel de carte couvre plus d'un texel de bloc : les marches
    restent alignees sur la grille (le snap ne ment jamais) mais deux texels
    de bloc voisins peuvent partager la meme valeur -- l'escalier se lit en
    marches de 2, 3, 4 texels de bloc. Ce n'est pas un bug, c'est la
    resolution de la carte. Le plateau de nettete ne depasse pas ~21 blocs
    (butee d'aire QMAX), donc monter SHADOW_SHARP_RANGE ne gagne que 2 a 5
    blocs : l'axe utile pour repousser la limite est SHADOW_QUALITY.

    CE QUI SUIT L'OPTION :
      - ombre directe soleil/lune sur le terrain, les entites, la main, les
        blocs textures/eclaires et le terrain differe (PERF_DEFERRED : le
        shading passe par le meme shadeSurface dans deferred1) ;
      - ombres COLOREES (verre teinte, vitraux : bandes RGB de shadowcolor0) ;
      - ombre de l'EAU sur elle-meme (sampleShadowWaterLite / le PCF legacy)
        et l'ombre de la colonne d'eau au bord d'une vitre ;
      - CAUSTIQUES : le point de lookup du champ (world.xz + glissement du
        rayon refracte) est snappe sur la meme grille -> le reseau se dessine
        en pixels de 1/16 de bloc, aux trois sites (a travers la surface,
        rivage, immerge), sur les bras CAUSTICS_V4 et legacy v3, et le tap
        d'ombre qui masque les caustiques utilise le meme receveur snappe ;
      - la vue de debug des ombres (DEBUG_VIEW 22) suit, pour rester
        diagnostique.
    CE QUI NE SUIT PAS, ET POURQUOI :
      - ombres de NUAGES (cloudShadow, VC_CAST_SHADOWS) : un nuage est a
        150-2000 blocs et son ombre est basse frequence par nature, la
        quantifier a 1/16 de bloc ne se verrait pas et coincerait une texture
        procedurale animee sur une grille fixe ;
      - rayons VOLUMETRIQUES / godrays (la marche de composite1 et son miroir
        lib/vl_halfres.glsl) : ce sont des points EN L'AIR, pas des receveurs
        de surface -- il n'y a pas de texel de bloc a viser, et snapper la
        marche crenellerait les faisceaux ;
      - GI / RSM, reflets SSR, lumieres colorees (LPV volumique) : basse
        frequence, ou dans un espace qui n'est pas celui des faces de blocs ;
      - Distant Horizons (dh_terrain / dh_water) : HORS PERIMETRE de ce
        round -- le LOD DH n'a pas de texel 16x16 a l'echelle ou il rend, et
        son ombre passe par les memes fonctions donc elle SUIT
        mecaniquement le tap dur, sans que l'alignement ait un sens la-bas.
    Note : les entites (mobs, joueur, coffres animes) ne sont PAS alignees sur
    la grille des blocs ; leur ombre PROJETEE l'est (c'est le receveur qui est
    snappe, pas le caster), mais leur PROPRE surface recoit un escalier ancre
    sur la grille monde, pas sur leur maillage. C'est attendu et fait partie
    du look.

    COUT. Le snap = ~15 ALU par receveur (2 transformees mat3, 1 floor vec3,
    1 mix, 1 dot, 1 division ; zero texture en plus). Le filtrage est celui
    de l'ombre par defaut, donc le meme nombre de taps de shadow map :
      voie V2  2 + 2*VLX_SEARCH_TAPS + 2*SHADOW_SAMPLES  = 18 / 28 / 30 / 54
               selon SHADOW_QUALITY 0/1/2/3
      legacy   10 + 2*SHADOW_SAMPLES                     = 18 / 26 / 26 / 42
      eau      sampleShadowWaterLite                     = 6 a 12
    L'option coute donc la meme chose que l'ombre par defaut, a ~15 ALU pres.
    Avec PIXEL_SHADOW_HARD 1 ces trois comptes tombent a 2 taps (l'option
    devient alors PLUS RAPIDE que l'ombre par defaut).
*/
// Texels par bloc de la grille de snap. 16.0 = la resolution vanilla des
// textures de blocs ; 8.0 donne des marches deux fois plus grosses, 32.0 colle
// a un pack de textures 32x. HORS MENU (pas de liste), sans effet a
// PIXEL_SHADOWS 0.
#define PIXEL_SHADOW_GRID 16.0 // texels par bloc (hors menu, pas de liste)
// Variante BINAIRE de l'option (hors menu, pas de liste). 0 (defaut) = le
// receveur snappe est filtre par la PCSS normale : la penombre grandit avec la
// distance au bloqueur puis se pixelise sur la grille 1/16 ("flouter, puis
// pixeliser", paragraphe LE FILTRAGE ci-dessus). 1 = un seul tap dur par texel
// de bloc, aucune penombre : le comportement de la premiere livraison, 2 taps
// au lieu de 18-54. Sans effet a PIXEL_SHADOWS 0.
#define PIXEL_SHADOW_HARD 0 // 1 = tap dur binaire sans penombre (hors menu, pas de liste)

// ============ AMBIENT OCCLUSION (SSAO) ============
#define AO
#define AO_STRENGTH 1.0 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 2.0 3.0 5.0 8.0]
#define AO_RADIUS 0.75 // [0.1 0.25 0.5 0.75 1.0 1.5 2.0 4.0 8.0]
// AO_SAMPLES: derived from SHADOW_QUALITY
// AO_QUALITY 1 (default) = modern estimator: cosine-weighted hemisphere
// (SAO/Alchemy - only occluders actually SEEN by the surface count), STRICT 3D
// range (no halo from distant occluders), 3x3 bilateral denoise (composite1),
// and SUN-AWARE application (AO occludes ambient, so it fades out in direct
// sunlight instead of dirtying it). 0 = legacy SSAO.
#define AO_QUALITY 1 // [0 1]

// GI_HALF_RES 1 (default) = SSGI/RTGI/RSM/SS lights/SSAO are computed at HALF
// resolution: composite.fsh shades only the lower-left quadrant of colortex4/6
// (1 quadrant texel = 1 full-res pixel at uv*2, ~4x fewer shaded pixels; the
// gathers keep the same radii/sample counts and still read the FULL-res
// gbuffers). The temporal history follows the same quadrant. Readers
// (composite1) re-expand with a 4-tap depth+normal bilateral upsample, so
// silhouettes and corners stay crisp. 0 = legacy full-res path, bit-identical.
// GI_HALF_RES : derive de GI_QUALITY (bloc AXES DE MENU, haut de ce fichier) -
// 1 aux paliers 0/1/2, 0 au palier 3. Il n'est plus un #define autonome ici :
// la valeur est posee dans les quatre branches de l'axe, comme SSGI_SAMPLES et
// RSM_SAMPLES. Pour le figer a la main, remplacer les quatre lignes de l'axe
// par une seule valeur.

// ============ SSGI - ONE SUN BOUNCE (screen space) ============
// ONLY sunlight bounces: sunlit surfaces illuminate their neighbours (color
// bleeding, filled-in shadows). Block lights stay STRICTLY vanilla - emissive
// pixels are ignored and the torch share is subtracted at the source. It fades
// out naturally in caves (no sun to bounce). RSM_GI below is the off-screen
// counterpart.
#define SSGI
#define SSGI_STRENGTH 1.0 // [0.25 0.5 0.75 1.0 1.25 1.5 2.0 3.0 4.0]
#define SSGI_RADIUS 12.0 // [4.0 6.0 8.0 12.0 16.0 24.0 32.0 48.0]
// SSGI_SAMPLES : derive de GI_QUALITY (bloc AXES DE MENU, haut de ce fichier)
#define SSGI_ACCUM 0.92 // [0.0 0.5 0.70 0.80 0.85 0.90 0.92 0.95 0.97 0.99]
// ---- Clamp anti-fireflies du rebond ecran (calibration, PAS un reglage) ----
// Un tap est borne a SSGI_FIREFLY_MAX x la moyenne courante des taps deja
// acceptes par CE pixel, plus un plancher absolu proportionnel au soleil
// (0.20 * luma(getLightColor())). Ce plancher est CALIBRE : a midi
// getLightColor() vaut ~6.9 en luma (4.6 x SUN_INTENSITY 1.5), donc le plancher
// vaut ~1.4 alors que le tap LEGITIME le plus brillant possible (bloc clair en
// plein soleil, poids 1) plafonne vers 1.1. Aucun tap legitime n'est donc
// ecrete, y compris le PREMIER (celui pour lequel la moyenne courante vaut
// encore 0) : le clamp relatif n'introduit aucun biais d'ordre.
// Meme idiome que le clamp relatif du GI voxel
// (composite5, GI_FIREFLY_MAX) : un rebond uniformement clair remonte sa propre
// moyenne et n'est PAS limite, seul un tap isole beaucoup plus brillant que les
// autres est ecrete. AVANT cette passe il n'y avait AUCUN clamp sur le SSGI :
// un seul tap sur un bloc blanc en plein soleil pouvait porter tout le pixel,
// et l'accumulation temporelle (0.92) le figeait en point brillant permanent.
// 3.0 = compromis mesure : au-dessus de ~6 le clamp ne sert plus a rien, en
// dessous de ~2 il eteint le color bleeding franc (un mur de gres ensoleille
// EST legitimement 3x plus clair que la moyenne de ses voisins).
// Aucune liste "// [...]" : ce n'est pas une option de menu.
#define SSGI_FIREFLY_MAX 3.0
// ---- Compensation d'ambiante du rebond ecran ET hors-ecran ----
// LACUNE FERMEE PAR LA PASSE GI-RSM. Le pack compensait deja le double comptage
// de l'indirect pour ses deux autres chemins GI - "ambient *= VOXEL_GI_AMBIENT"
// et "ambient *= mix(1.0, RTGI_BOUNCE_AMBIENT, skyl)" dans lib/lighting.glsl -
// mais RIEN pour le SSGI ni pour le RSM : l'ambiante ciel restait pleine et le
// rebond s'y ajoutait en pur. Tant que le RSM etait eteint par defaut cela
// passait ; il est desormais ALLUME par l'axe GI_QUALITY aux paliers 2 et 3
// (les deux profils les plus utilises), donc la compensation devient due.
// 0.85 et non 0.35 comme le voxel GI : le SSGI/RSM ne ramene qu'UN rebond
// solaire partiel (rien la nuit, rien en grotte, rien du hors-champ non
// ensoleille), il ne remplace pas l'ambiante ciel, il la complete. Ponderee par
// skyl comme RTGI_BOUNCE_AMBIENT, donc exactement neutre en grotte.
// 1.0 = comportement d'avant cette passe (aucune compensation).
// Aucune liste "// [...]" : c'est une CALIBRATION, pas une option de menu (le
// menu refondu n'expose aucun nombre brut).
#define GI_BOUNCE_AMBIENT 0.85

// ============ REAL-TIME GLOBAL ILLUMINATION (RTGI, legacy mode) ============
//#define RTGI
#define RTGI_STRENGTH 1.5 // [0.0 0.5 0.75 1.0 1.25 1.5 2.0 3.0 4.0 6.0 10.0 20.0 50.0]
#define RTGI_RADIUS 8.0 // [2.0 4.0 6.0 8.0 12.0 16.0 24.0 32.0 64.0 128.0]
#define RTGI_ACCUM 0.92 // [0.0 0.5 0.70 0.80 0.85 0.90 0.92 0.95 0.97 0.99]
#define RTGI_BOUNCE_AMBIENT 0.35 // [0.0 0.2 0.3 0.35 0.45 0.6 0.8 1.0 1.5 2.0 3.0 5.0]
// ============ RSM - OFF-SCREEN SUN BOUNCE ============
// RSM_GI = la CASE DU MENU. Elle FORCE le rebond hors-ecran aux paliers bas de
// GI_QUALITY ; aux paliers 2 et 3 il est deja allume par l'axe (voir plus bas).
// Elle reste une option de menu nue (jamais dans un #if) : c'est la regle Iris
// rappelee en tete de shaders.properties.
//#define RSM_GI
// RSM_STRENGTH : RECALIBRE de 1.0 a 0.5 par la passe GI-RSM, parce que trois
// erreurs qui se compensaient ont ete corrigees ensemble dans composite.fsh :
//   (1) l'albedo lu dans shadowcolor0 etait laisse en GAMMA alors que toute la
//       chaine est en LINEAR HDR jusqu'a composite5 -> il est maintenant passe
//       dans toLinear (x0.45 environ sur un monde typique) ;
//   (2) l'estimateur Monte-Carlo perdait le pi de l'aire du disque et portait
//       un cosSun en trop (il s'annule exactement contre le jacobien
//       plan-de-lumiere -> surface) -> x pi/cosSun, environ x4.4 ;
//   (3) la base de la difference finie de la normale d'emetteur etait
//       sous-estimee d'un facteur 1.4 a 3.5 selon la distance.
// Net environ x2 : 0.5 rend donc la MEME luminosite livree qu'avant, mais
// chaque facteur est desormais juste isolement. Le curseur reste le dial.
#define RSM_STRENGTH 0.5 // [0.0 0.5 0.75 1.0 1.5 2.0 3.0 4.0 6.0 10.0 20.0 50.0]
#define RSM_RADIUS 10.0 // [2.0 4.0 6.0 8.0 10.0 14.0 20.0 32.0 64.0 128.0]
// RSM_SAMPLES : derive de GI_QUALITY (bloc AXES DE MENU, haut de ce fichier)
// ---- Porte derivee : le RSM est ACTIF si l'axe l'allume OU si la case l'exige.
// PREFIXE VLX_ OBLIGATOIRE (piege Iris documente en tete de
// shaders.properties : un "#define NOM" NU, meme enferme dans un #if, est
// enregistre comme option booleenne CACHEE, et une vieille config portant
// "NOM=false" commenterait la ligne et eteindrait le palier sans aucun controle
// en jeu pour s'en sortir). Le prefixe VLX_ est l'idiome du pack pour les
// defines DERIVES, pose et explique dans lib/distort.glsl (VLX_SHADOW_DISTORT,
// VLX_SHADOW_ZSCALE) : un nom prefixe VLX_ est interne par convention, ne
// ressemble pas a une variante de la case RSM_GI et n'a donc aucune chance
// d'etre epingle par une config ecrite a la main ou generee.
// NE JAMAIS exposer VLX_RSM_ACTIVE au menu.
#if GI_QUALITY >= 2 || defined RSM_GI
#define VLX_RSM_ACTIVE
#endif
// ---- Fondu par la DISTANCE (calibration, PAS un reglage) ----
// La shadow map est distordue (lib/distort.glsl) : elle concentre ses texels
// autour du joueur. Un recepteur lointain echantillonne donc des texels enormes
// et flous, et le rebond y degenere en bruit basse frequence qui bave d'une
// image a l'autre. Fondu lineaire entre RSM_FADE_NEAR et RSM_FADE_FAR blocs de
// profondeur de vue ; au-dela, la boucle entiere est SAUTEE (gain de cout pur,
// c'est la majorite des pixels d'un paysage ouvert). 64 -> 112 blocs = au-dela
// de la zone ou le rebond de couleur se lit encore a l'oeil.
// Aucune liste "// [...]" : ce ne sont pas des options de menu.
#define RSM_FADE_NEAR 64.0
#define RSM_FADE_FAR 112.0
// ---- Clamp anti-fireflies du rebond hors-ecran ----
// Meme idiome relatif que SSGI_FIREFLY_MAX (voir le bloc SSGI ci-dessus). Le
// plancher absolu est ici en unites "albedo x geometrie" (le soleil n'est
// applique qu'a la sortie de la boucle), d'ou une constante et non un terme en
// getLightColor().
// MISE A L'ECHELLE PAR LE RAYON (posee par la passe GI-RSM) : composite.fsh
// applique ce plancher comme RSM_FIREFLY_FLOOR * (100 / RSM_RADIUS^2), parce
// que l'echelle naturelle de "contrib" varie comme 1/R^2 via le terme
// geometrique. Un plancher ABSOLU ecretait des taps legitimes a RSM_RADIUS 2 et
// ne touchait plus rien a RSM_RADIUS 32. Le facteur vaut exactement 1.0 au
// RSM_RADIUS 10 livre : aucun changement sur l'image par defaut.
#define RSM_FIREFLY_MAX 3.0
#define RSM_FIREFLY_FLOOR 0.15

// ============ DENOISE GI V2 (mission DEN : "ca clignote de partout") ============
// POURQUOI l'ancien chemin clignotait, mesure sur le modele numerique
// (den_model2.py, scenarios A/A'/B) : le clamp anti-ghosting de composite.fsh
// serrait l'historique dans une fenetre RELATIVE a l'estimee COURANTE
// [gi/(k*1.25)-0.02, gi*k+0.05]. Multiplicative, elle devient une fenetre
// ABSOLUE minuscule quand gi tombe pres de zero - et avec un disque de Vogel
// tourne chaque image, gi TOMBE regulierement a zero partout ou les taps sont
// clairsemes (bords de lobe de rebond, RSM lointain a 16 taps) : l'historique
// etait ECRASE vers 0.05 puis regonfle a l'image suivante, en boucle - un
// scintillement reel POUR TOUT UTILISATEUR SSGI/RSM, et aussi un biais NOIR :
// l'ecrasement n'agit que vers le bas (image livree ~10-15 % sous la moyenne
// vraie de l'estimateur dans les zones clairsemees). ATTENTION DIAGNOSTIC :
// le "clignote un peu de partout" du CREATEUR ne peut PAS venir d'ici - sa
// config live (VeraLux Classic.txt : SSGI=false, GI_QUALITY=0, RSM_GI off)
// ferme la porte VLX_DEN_ACTIVE ci-dessous et compile tout ce chemin OUT.
// Son scintillement est a chercher ailleurs (bake orage demi-res + resolve
// prepare1, TAA, nuages).
// LE REMPLACEMENT (GI_DENOISE_V2 1) : fenetre de VARIANCE symetrique
// gi +- (KSIG * sigma + 0.02), ou sigma est l'ecart-type REEL de l'estimateur,
// suivi en deux morceaux :
//   - sigma INSTANTANE : somme des carres des contributions acceptees par les
//     boucles SSGI et RSM (m2 - m1^2/n, flux independants ajoutes en
//     quadrature) - deja disponibles, le clamp fireflies suit les memes sommes;
//   - sigma LISSE (colortex6.b, canal libre du RGBA8) : moyenne glissante du
//     sigma relatif, MEME poids que l'historique GI. INDISPENSABLE : le sigma
//     instantane est CORRELE a l'estimee (une image ou tous les taps ratent a
//     sigma = 0 ET gi = 0 - une fenetre batie dessus ecrase l'historique
//     exactement sur les images qui derapent, mesure x1.45 PIRE que l'ancien
//     clamp sur le modele v1). La fenetre prend le max des deux.
// L'accumulation passe de 0.92 a 0.95 (VLX_DEN_ACCUM_BOOST ci-dessous) : la
// fenetre de variance protege du ghosting, donc l'historique peut durer plus.
// En DISOCCLUSION (guide profondeur rejete), l'ancien chemin melangeait 50 %
// d'un historique PERIME sans le clamper (traine) ; V2 melange
// VLX_DEN_DIS_W = 0.7 de l'historique CLAMPE dans la fenetre (contamination
// bornee a 0.7*dev) et redemarre le compteur a VLX_DEN_HIST0 = 3 images, et
// colortex6.b est force a 1 pour que l'etage spatial (palier 3) ouvre ses
// anneaux en grand exactement la. Chiffres du modele : scintillement affiche
// x0.36 camera fixe (x0.20 zones clairsemees), x0.46 en translation, temps de
// reponse a un changement d'eclairage 45 images contre 71 avant (la fenetre
// suit le niveau, l'ancien clamp rebondissait).
// PORTE DE SECOURS : 0 = chemin d'avant, BIT-IDENTIQUE (verifie en SPIR-V aux
// quatre GI_QUALITY). Pas de liste "// [..]" : jamais une option de menu.
#define GI_DENOISE_V2 1 // porte de secours hors menu, 0 = chemin legacy bit-identique
// La porte derivee ne s'ouvre que si un flux GI moderne alimente le sigma
// (SSGI ou RSM). Les modes legacy RTGI / SS_LIGHTS gardent l'ancien chemin :
// leurs boucles n'ont pas de suivi m2 et un sigma vide ecraserait l'historique.
// PREFIXE VLX_ + SUFFIXE _ACTIVE obligatoires (pieges Iris documentes en tete
// de shaders.properties et a la porte VLX_RSM_ACTIVE ci-dessus).
// NE JAMAIS exposer VLX_DEN_ACTIVE au menu.
// ETAT LIVRE : dans le .txt live du createur (SSGI=false, GI_QUALITY=0,
// RSM_GI commente) cette porte est FERMEE - ni fenetre de variance, ni
// anneaux, ni canal colortex6.b n'existent dans son binaire. Toute mesure
// en jeu du denoiser exige d'abord SSGI coche (ou GI_QUALITY >= 2, ou
// RSM_GI) dans le menu QUALITE.
#if GI_DENOISE_V2 == 1 && (defined SSGI || defined VLX_RSM_ACTIVE)
#define VLX_DEN_ACTIVE
#endif
// ---- Calibrations du temporel (PAS des options de menu, aucune liste) ----
// VLX_DEN_KSIG : demi-largeur de la fenetre en ecarts-types. Balayage du
// modele (scenario C) : 1.5 laisse encore x1.5 de scintillement pour le meme
// lag ; 2.5/3.0 ne gagnent plus rien de mesurable. 2.0 = P(clamp d'un
// historique sain) ~4.5 %.
#define VLX_DEN_KSIG 2.0
// VLX_DEN_ACCUM_BOOST : multiplie nMax = 1/(1-GI_ACCUM_W). x1.6 amene le 0.92
// livre exactement a 0.95 (nMax 12.5 -> 20) et respecte un GI_ACCUM_W edite a
// la main (le boost est un facteur, pas un remplacement). Borne a 64 par le
// codage 8 bits de colortex6.g.
#define VLX_DEN_ACCUM_BOOST 1.6
// VLX_DEN_DIS_W / VLX_DEN_HIST0 : poids d'historique clampe et redemarrage du
// compteur en disocclusion (0.7 / 3 -> le poids remonte a 0.75 des l'image
// suivante ; l'ancien chemin repartait a 1, soit 0.5).
#define VLX_DEN_DIS_W 0.7
#define VLX_DEN_HIST0 3.0
// ---- Calibrations du spatial (cote lecture, composite1) ----
// Poids de base des anneaux a-trous 1 et 2 (retombee B3-spline 1/2 puis 1/4
// du bloc bilineaire central), multiplies par les memes affinites profondeur
// + normale que les 4 taps de base - un anneau ne traverse jamais une arete
// que le bilateral refuse deja.
#define VLX_DEN_RING_W1 0.5
#define VLX_DEN_RING_W2 0.25
// Palier 3 : poids des anneaux x clamp(b * GAIN, MIN, 1) ou b = sigma lisse
// max des 4 taps de base (colortex6.b). GAIN 4.0 : anneaux pleins des b 0.25
// (bruit fort / disocclusion), quasi fermes (MIN) sur une image propre.
#define VLX_DEN_ADAPT_GAIN 4.0
#define VLX_DEN_ADAPT_MIN 0.05

// ============ GI_V3 - GROS CHANTIER LUMIERE INDIRECTE ============
// DEMANDE DU CREATEUR, mot pour mot : "les rebondissements de lumiere plus
// PRESENTS - j'ai du mal a le voir des fois", "rajouter les sources de lumiere
// dans le GI, mais SUBTIL sur les lumieres", "agrandir : 4 rebondissements
// minimum, rayons jusqu'a ~16 blocs".
// PORTE DE SECOURS : 0 = la chaine GI d'avant cette passe, VERBATIM (tous les
// blocs ajoutes sont enfermes dans "#if GI_V3 == 1" avec le texte d'origine en
// #else ; les macros derivees ci-dessous deviennent des ALIAS du nom d'origine,
// donc le retrait mecanique des blocs redonne le fichier d'avant). Pas de liste
// "// [..]" : ce n'est JAMAIS une option de menu (piege Iris, en tete de
// shaders.properties). Les axes GI_QUALITY et DENOISE_QUALITY restent
// significatifs : GI_V3 les REDEFINIT tier par tier, il ne les court-circuite
// pas.
#define GI_V3 1 // porte de secours hors menu, 0 = chaine GI legacy verbatim
//
// ---- A. MULTI-REBOND PAR REINJECTION TEMPORELLE ----
// Le SSGI est MONO-REBOND par construction : il echantillonne colortex0, qui
// contient "albedo x (direct + ambiante)" et RIEN de l'indirect (composite1
// applique le GI plus tard, "color += gi * albedo", et n'ecrit pas colortex4).
// Le multi-rebond se fait donc en relisant, a la position de l'emetteur, le GI
// ACCUMULE de l'image precedente : colortex4 (RGBA16F, Clear = false, .rgb = gi
// accumule, .a = profondeur lineaire) est deja relu par cette meme passe pour
// la reprojection temporelle - aucun buffer nouveau, aucune ligne dans
// shaders.properties. La radiance sortante indirecte d'un emetteur vaut
// albedo(colortex5) x gi(colortex4) : c'est exactement ce que composite1
// applique, donc les deux cotes de la chaine restent coherents.
//   frame 1 : 1 rebond      frame 2 : 2 rebonds ...   regime : une infinite.
// SURETE ENERGETIQUE, mesuree (scratchpad gi3_sim.py) : le gain d'operateur du
// gather SSGI, pour le PIRE cas (recepteur totalement entoure de surfaces), est
// s = 2.5 * moyenne_t[ndl*face/(1+8t)] = 2.5 * 0.5 * ln(9)/8 = 0.343, et il ne
// depend PAS du rayon (le noyau 1/(1+8*l2/R^2) est normalise par R). La serie
// des rebonds est donc geometrique de raison s*rho*GI_PRESENCE <= 0.343 * 1.0 *
// 1.30 = 0.446 < 1 : elle CONVERGE toujours, meme sur un albedo blanc.
//   rho 0.30 -> x1.12   rho 0.50 -> x1.21   rho 0.70 -> x1.32   rho 0.85 -> x1.41
// (albedos Minecraft lineaires typiques 0.2-0.7, rho_max ~0.85 sur la laine
// blanche). C'est CA le "plus present" demande, et il vient de la physique.
// Transitoire mesure avec l'accumulation a 0.95 : 42 % du supplement a 15
// images, 88 % a 60, 99 % a 120 (2 s a 60 fps) - le regime multi-rebond
// s'installe sans pompage visible.
// BOUCLE FERMEE, simulee AVEC la fenetre de variance du denoiseur en place
// (gi3_sim2.py, 600 images, bruit MC 10 % et 25 %) : le regime atteint 97-98 %
// (bruit 10 %) et 93-95 % (bruit 25 %) de la valeur theorique - la fenetre
// prend un petit biais NEGATIF, jamais positif, donc elle ne peut pas nourrir
// l'emballement ; scintillement affiche 0.004 a 0.017 en unites de gi. Teste
// jusqu'a rho = 1.0 (albedo blanc pur, impossible en jeu) : toujours borne,
// x1.75 au lieu du x1.80 theorique. Aucun reglage ne rend cette boucle
// divergente tant que s*rho*GI_PRESENCE < 1.
// TROIS GARDES, toutes obligatoires :
//   (1) multiplication par l'albedo de l'emetteur (<= 1) -> borne geometrique ;
//   (2) plafond ABSOLU de luma sur la radiance reinjectee (GI_REINJECT_MAX) ->
//       une boucle sur un emetteur HDR (lave a 10+) ne peut pas s'emballer ;
//   (3) test de DESOCCLUSION : colortex4.a porte la profondeur lineaire ecrite
//       a l'image precedente A CETTE POSITION ECRAN ; on ne reinjecte que si
//       elle correspond a la profondeur courante de l'echantillon (meme
//       tolerance relative que la reprojection temporelle, 0.1*z + 0.5). Sans
//       lui on injecte le GI d'une geometrie qui n'est plus la.
// LIMITE ASSUMEE : la relecture se fait a la position ECRAN COURANTE de
// l'echantillon, pas reprojetee dans l'image precedente (cela couterait une
// mat4 par echantillon). En camera fixe c'est exact ; en mouvement le decalage
// vaut le flux optique d'UNE image et le test (3) rejette tout ce qui ne
// correspond plus. Un terme indirect basse frequence supporte ce
// desalignement, le direct ne le supporterait pas.
//
// ---- B. PORTEE 16 BLOCS ----
// Rayon monde du gather ecran : 12 blocs avant cette passe (SSGI_RADIUS, meme
// valeur aux quatre paliers - seul le NOMBRE d'echantillons variait), 16 sous
// GI_V3. Le curseur SSGI_RADIUS reste un dial mais ne peut plus descendre sous
// 16 (max()), parce que "rayons jusqu'a 16 blocs" est la demande.
// CE QUE CA CHANGE, mesure et honnete : le noyau etant normalise par R, un
// environnement UNIFORME garde exactement la meme luminosite (s invariant) ;
// une TACHE localisee a distance fixe (le mur rouge a 5 blocs qui saigne sur le
// sol) perd en revanche un facteur R^2 de densite d'echantillons et n'en
// regagne qu'un facteur w : integrale mesuree x0.753 en passant de 12 a 16
// blocs. C'est structurel - a budget d'echantillons fixe, elargir DILUE.
// D'ou les deux compensations ci-dessous (densite + presence), et non un
// "gain parce que c'est plus joli".
// LE RSM N'EST PAS ELARGI, et c'est un ECART MOTIVE : son noyau est
// 1/(l2+0.5), non normalise, donc sa moyenne croit comme ln(R^2) pendant que
// son ecart-type croit comme R. Mesure (gi3_sim.py, N = 8/frame apres
// l'entrelacement) : R 10 -> 16 rapporte x1.19 de lumiere pour x1.50 de bruit
// relatif (sigma/moyenne 0.80 -> 1.20). Le createur se plaint deja du
// scintillement : ce troc est refuse. Les 16 blocs sont ceux des RAYONS
// (SSGI), qui est ce que la demande dit.
#define GI_REACH 16.0
//
// ---- DENSITE : nombre d'echantillons du rebond ecran, par palier ----
// Le disque passe de 12 a 16 blocs, donc son AIRE est x1.78 : a nombre
// d'echantillons constant la densite tomberait a 0.56. La table GI_V3 en
// reprend les deux tiers ; le tiers restant est compense par le fait que le
// terme REINJECTE est quasi sans bruit (il relit un buffer deja denoise
// temporellement), donc il DILUE le bruit relatif du pixel d'un facteur
// 1/(1+s*rho) ~ 0.82. TABLE MESUREE (gi3_sim2.py ; taps SSGI par pixel OMBRE -
// aux paliers 0-2 l'ombrage est en demi-res, donc diviser par 4 pour l'ecran) :
//   palier | N : leg -> v3 | taps/px : leg -> v3 | densite | sigma/moyenne
//      0   |   4 ->  6     |   16 ->  30 (x1.88) |  0.84   | 0.219 -> 0.123
//      1   |   8 -> 10     |   32 ->  50 (x1.56) |  0.70   | 0.115 -> 0.076
//      2   |  12 -> 16     |   48 ->  80 (x1.67) |  0.75   | 0.077 -> 0.048
//      3   |  24 -> 28     |   96 -> 140 (x1.46) |  0.66   | 0.039 -> 0.027
// Le bruit BAISSE a tous les paliers malgre le disque plus large : c'est le
// point qui compte pour le createur, qui se plaint du scintillement. Le
// surcout ecran reel vaut +3.5 / +4.5 / +8 taps par pixel d'ecran aux paliers
// 0-2 (demi-res) et +44 au palier 3 (pleine res, ~+22 % sur les ~197 taps/px
// de la passe composite). Le palier 3 reste le palier cher, annonce comme tel
// dans shaders.properties. Le palier 0 n'est PAS paye par le profil POTATO :
// il epingle SSGI=false.
#if GI_V3 == 1
#if GI_QUALITY == 0
#define VLX_GI3_N 6
#elif GI_QUALITY == 1
#define VLX_GI3_N 10
#elif GI_QUALITY == 2
#define VLX_GI3_N 16
#else
#define VLX_GI3_N 28
#endif
#define VLX_GI3_R (max(SSGI_RADIUS, GI_REACH))
#else
#define VLX_GI3_N SSGI_SAMPLES
#define VLX_GI3_R SSGI_RADIUS
#endif
//
// ---- D. PRESENCE ----
// GI_PRESENCE est une COMPENSATION, pas un embellissement : 1/0.753 = 1.33 est
// le facteur qui rend exactement au saignement de couleur de proximite ce que
// la portee 16 blocs lui prend (voir B). 1.30 est pose juste en dessous pour ne
// pas depasser le rendu d'avant sur ce cas la. Ce qui reste comme GAIN NET est
// alors le multi-rebond (x1.21 a x1.41) et la portee - de la physique.
// Bilan mesure sur les trois situations qui comptent :
//   tache proche (mur colore a 5 blocs) : 0.753 * 1.30 * 1.21 = x1.18
//   champ ouvert / lointain             : 1.000 * 1.30 * 1.21 = x1.57
//   piece close (le cas "je ne le vois pas") : 1.30 * 1.41    = x1.83
// Applique AUSSI au RSM (rebond solaire hors-ecran) : le createur demande que
// le soleil rebondisse plus, et le RSM ne subit pas la dilution de B.
#define GI_PRESENCE 1.10 // presence du SSGI - 1.30 etait la compensation exacte de la dilution 16 blocs ; ramene a 1.10 sur retour user ("le SSGI un peu trop fort, c'etait le RSM que je voulais booster") : tache proche x1.0, champ ouvert x1.33, piece close x1.55 (au lieu de x1.18/1.57/1.83)
#if GI_V3 == 1
#define VLX_GI3_SS (SSGI_STRENGTH * GI_PRESENCE)
#define VLX_GI3_RS (RSM_STRENGTH * GI_PRESENCE)
#else
#define VLX_GI3_SS SSGI_STRENGTH
#define VLX_GI3_RS RSM_STRENGTH
#endif
//
// ---- C. LES SOURCES DE LUMIERE DANS LE GI, "SUBTIL" ----
// Avant cette passe le contrat etait "block lights stay STRICTLY vanilla" : les
// pixels emissifs etaient sautes (continue) et la part torche etait SOUSTRAITE
// de la source (1 - lm.x*1.5). Le createur demande l'inverse, en subtil. Deux
// termes distincts, et surtout DEUX ROLES DISTINCTS pour ne pas doubler ce que
// les lumieres colorees (CL_V3 / EMISSIVE_LPV) font deja :
//   CL_V3 / LPV = la TEINTE LOCALE de la source, propagee en volume autour
//                 d'elle. C'est le premier rebond, et il est deja juste.
//   GI          = le REBOND DIFFUS des surfaces qu'elle eclaire, a distance,
//                 sur la geometrie que le voxel ne resout pas.
// (1) GI_EMISSIVE_GAIN : le pixel emissif lui-meme (bande colortex2.b
//     0.45-0.65 = emissif 0.50 / lave 0.58 / portail) entre dans le gather
//     avec ce gain, et SANS la porte soleil. Il compte pour ce qu'il est,
//     plafonne en luma par GI_EMISSIVE_MAX (colortex0 y porte deja
//     EMISSIVE_BOOST = 8, soit ~3 a 8 de luma HDR sur une torche ou une nappe
//     de lave). 0.30 = le cran "subtil", CHIFFRE (gi3_sim2.py ; gi est une
//     IRRADIANCE, on le compare donc a direct+ambiante, ~6.9 en luma a midi) :
//        nappe de lave sur 50 % du disque -> gi 0.34 = 4.9 % du plein soleil,
//                                            et ~0.8x la lumiere de bloc
//                                            vanilla d'un pixel a lm.x = 0.5 ;
//        sur 20 % -> gi 0.13 ;   sur 5 % -> gi 0.03.
//     Autrement dit : une grande nappe se voit franchement (elle doit - c'est
//     la seule lumiere du Nether, ou skylight = 0 eteint le RSM ET la part
//     solaire du SSGI), une source ponctuelle ne se voit pas. Monter vers 0.5
//     pour un Nether plus incandescent, descendre vers 0.15 pour un rebond
//     emissif quasi imperceptible.
//     PROPRIETE UTILE, gratuite : l'anti-firefly RELATIF deja en place
//     (SSGI_FIREFLY_MAX, moyenne courante des taps acceptes) fait exactement
//     le bon tri - une GRANDE source (lave, plafond de glowstone) touchee par
//     beaucoup d'echantillons remonte sa propre moyenne et passe, une PETITE
//     source touchee par un echantillon isole est ecretee au plancher et ne
//     scintille pas. "Subtil" est donc obtenu par l'estimateur, pas seulement
//     par le gain.
// (2) GI_BLOCKLIGHT_GAIN : la part de la source qui vient de la LUMIERE DE
//     BLOC, reprise a 30 % au lieu d'etre soustraite. C'est le terme qui se
//     VOIT : un mur eclaire a la torche est une grande surface, donc bien
//     echantillonne, contrairement a la torche elle-meme (une torche a 3 blocs
//     couvre ~4e-4 du disque de gather : elle n'est presque jamais touchee -
//     raison de fond pour laquelle un GI ecran ne remplacera jamais le LPV sur
//     les petites sources, et raison pour laquelle EMISSIVE_LPV passe a 1 dans
//     le profil EXTREME). L'expression reutilise TELLE QUELLE la complementaire
//     de la soustraction existante, min(lm.x*1.5, 1), zero ALU nouveau.
//     30 % = la part assumee de double comptage avec le LPV, choisie basse.
// (3) GI_EMISSIVE_FLOOR : le plancher absolu de l'anti-firefly est
//     proportionnel au SOLEIL (0.20*luma(getLightColor())), donc ~0.02 la nuit
//     et en grotte - il etranglait le premier tap emissif la ou l'emissif est
//     justement la seule lumiere. Ce plancher additionnel (0.10) laisse la
//     rampe demarrer ; biais mesure sur une nappe de lave a 16 taps : -7 %.
// COUT : le SSGI ne peut plus etre saute en bloc la nuit (il l'etait, gain
// documente au bloc SSGI). La porte de nuit est reportee sur le RECEPTEUR :
// elle ne s'ouvre que s'il voit de la lumiere de bloc (1 tap colortex2 par
// pixel). Un pixel de nuit en plein champ, sans torche, coute donc toujours
// ZERO - seules les scenes eclairees a la torche paient.
#define GI_EMISSIVE_GAIN 0.30
#define GI_EMISSIVE_MAX 5.0
#define GI_EMISSIVE_FLOOR 0.10
#define GI_BLOCKLIGHT_GAIN 0.30
// Plafond de luma de la radiance REINJECTEE (garde (2) de la section A). 4.0
// est une SOUPAPE, pas un reglage : le gi accumule d'une surface eclairee vaut
// typiquement 0.1 a 1.5, la valeur n'est atteinte que par une boucle qui
// s'emballe. La baisser jusqu'a ~1.0 assombrirait volontairement le
// multi-rebond ; la monter ne change rien tant que la serie converge.
#define GI_REINJECT_MAX 4.0
//
// ---- COMPENSATION D'AMBIANTE (le levier de LISIBILITE) ----
// GI_BOUNCE_AMBIENT (defini plus haut, section SSGI) rend a l'ambiante ciel la
// part que le rebond fournit desormais, ponderee par skyl - donc NEUTRE en
// grotte. Le rebond monte de ~x1.4 en exterieur : la part rendue doit suivre,
// 15 % -> 21 %. C'est aussi ce qui rend le rebond LISIBLE (moins de nappe plate
// d'ambiante, plus de lumiere directionnelle) : c'est le vrai remede au "j'ai
// du mal a le voir". #undef assume : GI_BOUNCE_AMBIENT n'a pas de liste, ce
// n'est donc pas une option de menu et aucune config ne peut l'epingler ; la
// redefinition est locale a ce bloc et disparait avec GI_V3 = 0.
#if GI_V3 == 1
#undef GI_BOUNCE_AMBIENT
#define GI_BOUNCE_AMBIENT 0.79
#endif

// ============ RSM_V2 - LE REBOND SOLAIRE HORS-ECRAN, PLUS PRESENT ============
// DEMANDE DU CREATEUR, mot pour mot, apres le test de GI_V3 : "le GI, j'aimerais
// que tu montes le RSM en fait, pas que le SSGI".
// PORTE DE SECOURS : 0 = le RSM exactement tel que GI_V3 l'a livre (meme rayon,
// meme noyau, meme gain, meme porte de ciel, meme plancher anti-firefly). Pas de
// liste "// [..]" : ce n'est JAMAIS une option de menu (piege Iris, en tete de
// shaders.properties). Les axes GI_QUALITY et DENOISE_QUALITY restent
// significatifs - ce bloc les REDEFINIT palier par palier, il ne les
// court-circuite pas.
// VERIFIE, pas affirme : composite.fsh preprocesse a RSM_V2 = 0 (GI_QUALITY 3,
// DENOISE_QUALITY 3 = la config live) a ete compare ligne a ligne au fichier
// d'AVANT cette passe. Les seules differences sont DEUX SORTIES DE FACTEUR
// COMMUN, a valeur strictement identique :
//     rsmGain  = 3.14159265 * rad2 / RSM_N        (etait ecrit deux fois inline)
//     rsmFloor = RSM_FIREFLY_FLOOR * (100 / R^2)  (etait recalcule a chaque tap)
// Les deux servent aussi de point d'insertion propre pour la version RSM_V2 = 1.
// Aucune autre ligne du bloc RSM ne bouge : ni le rayon, ni le tirage, ni les
// rejets, ni la reconstruction de normale d'emetteur, ni l'anti-double-comptage
// avec le SSGI.
#define RSM_V2 1 // porte de secours hors menu, 0 = RSM GI_V3 verbatim
//
// ---- POURQUOI L'AGENT PRECEDENT AVAIT REFUSE, ET CE QUI A CHANGE ----
// Le bloc GI_V3 ci-dessus refuse d'elargir le RSM, et sa mesure etait JUSTE :
// avec un echantillonnage UNIFORME EN AIRE (r = R*sqrt(t)) et un noyau
// 1/(l2+0.5) non normalise, la moyenne croit comme ln(R^2) pendant que
// l'ecart-type croit comme R -> R 10 -> 16 rapporte peu de lumiere pour
// beaucoup de bruit. Re-mesure ici (rsmv2_sim.py, meme scene, N = 12
// taps/image du palier 3) : sigma/moyenne 0.67 -> 1.23 a 2 blocs d'un mur,
// exactement le troc refuse.
// CE QUI A CHANGE : ce n'est pas le rayon le probleme, c'est L'ESTIMATEUR. Le
// noyau 1/(l2+0.5) concentre l'energie au centre alors que les echantillons
// sont repartis uniformement sur toute l'aire ; la variance de l'estimateur
// vaut alors (pi R^2 / N) x integrale de f^2, dominee par le champ PROCHE et
// multipliee par R^2 - d'ou sigma ~ R pour une moyenne ~ ln(R^2).
// L'ECHANTILLONNAGE PAR IMPORTANCE annule ce facteur : on tire le rayon avec
// la densite du noyau lui-meme, p(r) ~ 1/(r^2+c), et on divise par cette
// densite. C'est le meme integrande sur le meme domaine, DONC LA MEME MOYENNE
// (verifie a 0.05 % pres contre une quadrature a 400 000 points, rsmv2_sim.py,
// R = 10/14/16 x d = 2/5/10) - seule la variance tombe. C'est ce qui PAIE le
// gain et le rayon demandes.
//
// ---- A. LE NOYAU : TIRAGE PAR IMPORTANCE ----
// CDF inverse, exacte et fermee (composite.fsh, boucle RSM) :
//     r^2 = c * (Q^t - 1)      avec Q = 1 + R^2/c,  t uniforme dans [0,1)
//     poids d'importance = (r^2 + c)     (c'est 1/p, a la constante pres)
//     gain de l'estimateur = pi * ln(Q) / N     (au lieu de pi * R^2 / N)
// Cout : UN exp2 par echantillon (log2(Q) est hoiste, et R est un litteral donc
// tout ce qui l'entoure est plie a la compilation). AUCUN tap de texture
// nouveau - voir J.
// r est le rayon dans le PLAN DE LUMIERE (celui qu'on tire), l reste la
// distance 3D recepteur -> emetteur (celle du noyau) : les deux ne coincident
// que sur une surface parallele au plan de lumiere, et c'est pour cela que le
// poids ne s'annule pas exactement contre le noyau. L'estimateur reste exact
// quoi qu'il arrive (c'est une division par la densite, pas une approximation) ;
// c est ce qui reste a calibrer, et c'est l'objet de C.
//
// ---- B. EFFET DE BORD GRATUIT : L'EMPREINTE DANS LA SHADOW MAP NE BOUGE PAS
// Rayon PLAN moyen des taps (rsmv2_final.py, bloc J) :
//     livre  R = 10 uniforme  -> 6.67 blocs (p90 9.5)
//     RSM_V2 R = 16, c = 8    -> 6.63 blocs (p90 13.2)
// Le rayon passe de 10 a 16 blocs SANS etaler les lectures de shadowtex1 : les
// ~72 taps aleatoires du palier 3, annonces comme incoherents au bloc
// GI_QUALITY, restent aussi groupes qu'avant. Pas de regression de cache.
//
// ---- C. CALIBRATION DE c, PALIER PAR PALIER ----
// c fixe l'endroit ou la densite passe d'a-peu-pres uniforme (r << sqrt(c)) a
// 1/r^2 (r >> sqrt(c)). Trop petit, les echantillons s'entassent au centre et
// un mur a 5-7 blocs est SOUS-echantillonne ; trop grand, on retombe sur
// l'uniforme et sur le bruit d'origine. L'optimum depend du NOMBRE
// d'echantillons : moins on en a, plus il faut rester uniforme (avec 4 taps,
// concentrer c'est risquer de rater le mur). D'ou une table indexee sur le
// palier, comme l'est deja la table RSM_SAMPLES.
// BALAYAGE MESURE (rsmv2_tiers.py / rsmv2_low.py, c de 2 a 64, d de 1 a 13
// blocs, critere = bruit RELATIF jamais pire que le livre ; table finale
// rsmv2_final2.py, avec le plancher anti-firefly de F en place) :
//     palier | R  | c  | c effectif | bruit relatif | gain reel | sigma absolu
//        0   | 10 | 48 |     25     |  <= x1.15     |  >= x1.84 |    x1.19
//        1   | 10 | 48 |     25     |  <= x1.24     |  >= x1.85 |    x1.15
//        2   | 16 | 12 |     12     |  <= x1.36     |  >= x2.09 |    x1.16
//        3   | 16 |  8 |      8     |  <= x1.04     |  >= x2.08 |    x0.93
// ("c effectif" = apres la borne R^2/4 ci-dessous, qui mord a R = 10. Le "pire
// cas" du bruit relatif tombe a 5-7 blocs aux paliers 0-2, la ou la
// contribution reste petite en ABSOLU. Le palier 3 - la config du createur -
// est le seul a etre meilleur sur TOUTES les mesures a la fois.)
// BORNE DE SURETE dans composite.fsh : c est borne par R^2/4, pour que le
// curseur RSM_RADIUS puisse descendre a 2 blocs sans que la densite ne devienne
// plate au point de perdre tout l'interet du tirage. Vers le HAUT il n'y a rien
// a borner : a RSM_RADIUS 128 un c constant est exactement ce qu'il faut, c'est
// la ou l'uniforme est le plus catastrophique.
#if GI_QUALITY == 0
#define VLX_RSM_C 48.0
#elif GI_QUALITY == 1
#define VLX_RSM_C 48.0
#elif GI_QUALITY == 2
#define VLX_RSM_C 12.0
#else
#define VLX_RSM_C 8.0
#endif
//
// ---- D. PORTEE : 16 BLOCS, ET SEULEMENT LA OU L'AXE ALLUME LE RSM ----
// Meme valeur que GI_REACH : le gather ecran et le rebond hors-ecran forment
// enfin UNE SEULE sphere de 16 blocs au lieu de deux portees differentes.
// Meme idiome que VLX_GI3_R : max() avec le curseur, donc RSM_RADIUS reste un
// dial vers le HAUT (jusqu'a 128) mais ne peut plus descendre sous 16 aux
// paliers ou le RSM est allume par l'axe. Aux paliers 0/1 le RSM est ETEINT par
// defaut (il faut cocher "Rebond hors ecran") et il n'y a que 4-6 taps par
// image : la portee y reste celle du curseur, sinon les memes 4 taps devraient
// couvrir 2.6 fois plus d'aire.
// CE QUE LA PORTEE RAPPORTE, mesure : a RSM_RADIUS 10 un mur ensoleille a 10
// blocs ne rapporte RIEN DU TOUT (l2 > R^2, et la fenetre edge est deja proche
// de zero a 0.9 R). Ce n'est donc pas "x1.19 de lumiere en plus", c'est zero qui
// devient quelque chose : 0.000 -> 0.024 de luma a 10 blocs, 0.000 -> 0.006 a 13.
#define RSM_REACH 16.0
#if RSM_V2 == 1 && GI_QUALITY >= 2
#define VLX_RSM_R (max(RSM_RADIUS, RSM_REACH))
#else
#define VLX_RSM_R RSM_RADIUS
#endif
//
// ---- E. PRESENCE : LE GAIN, x2 ----
// C'est le levier direct demande. Il est pose APRES le noyau, parce que seul le
// noyau rend le troc acceptable : un gain seul multiplie la moyenne ET
// l'ecart-type, il ne change pas le bruit RELATIF (c'est ce que l'agent
// precedent avait raison de refuser). Ici la baisse de variance est encaissee
// d'abord, le gain la depense ensuite.
// MESURE AVANT/APRES, palier 3 (config live du createur), recepteur au sol a d
// blocs d'un mur de gres ensoleille, soleil a 45 deg (rsmv2_ship.py) :
//     d      contribution (luma)      sigma/moyenne          sigma ABSOLU
//     1     0.081 -> 0.169  x2.08    1.333 -> 0.597  x0.45   0.108 -> 0.101
//     2     0.070 -> 0.156  x2.22    0.666 -> 0.311  x0.47   0.047 -> 0.049
//     3     0.055 -> 0.133  x2.41    0.408 -> 0.250  x0.61   0.023 -> 0.033
//     5     0.028 -> 0.090  x3.24    0.285 -> 0.296  x1.04   0.008 -> 0.027
//     7     0.009 -> 0.057  x6.50    0.432 -> 0.427  x0.99   0.004 -> 0.024
//    10     0.000 -> 0.024  nouveau      --  -> 0.729        0.000 -> 0.018
//    13     0.000 -> 0.006  nouveau      --  -> 1.239        0.000 -> 0.007
// Autrement dit : le bruit RELATIF n'est jamais pire que x1.04 du livre a AUCUNE
// distance, il est presque divise par deux la ou le rebond se lit (1-3 blocs),
// et le sigma ABSOLU MAXIMUM sur toute la plage BAISSE (0.108 -> 0.101, x0.93) -
// or c'est lui que voit la fenetre du denoiseur, qui vaut VLX_DEN_KSIG*sigma +
// 0.02 en unites de gi. 2e scene verifiee (recepteur SUR un mur, rebond du sol
// ensoleille devant lui, rsmv2_final.py bloc K) : x1.6 a x5.3 de contribution
// pour un bruit relatif x0.25 a x0.64.
// LE MULTI-REBOND SUIT, sans rien changer a sa convergence : la contribution
// RSM est ajoutee a `gi`, et `gi` est ECRIT dans colortex4 (composite.fsh,
// gl_FragData[0]) que la reinjection du gather SSGI relit a l'image suivante -
// le rebond solaire hors-ecran est donc bien re-diffuse par le multi-rebond de
// GI_V3, ce n'etait pas un manque. Et le RSM n'entre PAS dans l'operateur de la
// serie (il est ajoute APRES la boucle SSGI, ce n'est pas un terme du gather) :
// la raison geometrique reste s*rho*GI_PRESENCE <= 0.446, INCHANGEE. Doubler le
// RSM double le terme SOURCE de la serie, pas sa raison - la somme reste bornee
// par 1/(1-0.446) exactement comme avant. Aucun risque d'emballement.
#define RSM_PRESENCE 2.0
#if RSM_V2 == 1
#define VLX_RSM_S (VLX_GI3_RS * RSM_PRESENCE)
#else
#define VLX_RSM_S VLX_GI3_RS
#endif
//
// ---- F. ANTI-FIREFLY : LE PLANCHER CHANGE D'ECHELLE ----
// Sous le noyau brut, "contrib" varie comme 1/R^2 par le terme geometrique, et
// le plancher absolu suivait : RSM_FIREFLY_FLOOR * (100/R^2). Sous le tirage par
// importance le poids (r^2+c) ANNULE ce 1/R^2 : contrib ne depend plus du rayon,
// il depend de c - son ordre de grandeur est (r^2+c)/(l^2+0.5), donc ~c pres du
// recepteur. Le plancher suit donc c, plus R.
// ERREUR ATTRAPEE EN MESURANT, et c'est pour cela que le chiffre est ici : un
// plancher laisse CONSTANT a 0.30 marchait au palier 3 (c = 8 : 0.4 % d'energie
// ecretee) mais ecretait 34 % de l'energie a 1 bloc aux paliers 0/1, ou c vaut
// 25 - un biais qui rendait le x2 demande en x1.31. Balayage du multiplicateur
// (rsmv2_floor.py ; energie ecretee max et gain reel minimum sur d = 1..7) :
//     x0.125*c : ecrete 11-23 %, gain reel x1.53 a x1.88     -> biaise
//     x0.25 *c : ecrete  0-7.5 %, gain reel x1.84 a x2.09    <- retenu
//     x0.375*c : ecrete  0-1.3 %, gain reel x1.96 a x2.09, sigma +20 a +40 %
// 0.25 laisse donc passer le gain demande a toutes les distances et a tous les
// paliers, et au palier 3 il redonne EXACTEMENT 0.15 * 0.25 * 8 = 0.30, soit la
// meme valeur que le plancher livre (0.15 * 100/100) : le palier du createur ne
// change pas d'ecretage du tout. Le vrai travail reste fait par le terme
// RELATIF (RSM_FIREFLY_MAX x moyenne courante des taps acceptes), qui est sans
// echelle et qui borne le seul cas ou le tirage par importance peut amplifier un
// tap : un echantillon a la fois proche en RAYON PLAN et proche en DISTANCE 3D,
// ou le rapport (r^2+c)/(l^2+0.5) monte (au plus c/0.5 quand les deux tendent
// vers 0, deja 1.45 seulement a 4 blocs). Un plancher NUL n'est pas une option :
// le premier tap se fait alors ecreter contre une moyenne courante encore nulle
// et le rebond s'eteint entierement (mesure : 100 % d'energie ecretee).
#if RSM_V2 == 1
#define VLX_RSM_FF 0.25 // multiplie rsmC dans composite.fsh, ce n'est pas un absolu
#else
#define VLX_RSM_FF (100.0 / (RSM_RADIUS * RSM_RADIUS))
#endif
//
// ---- G. ANTI-FUITES : LA PORTE DE CIEL DU RECEPTEUR SE RESSERRE ----
// Le RSM n'a AUCUN test de visibilite recepteur -> emetteur (une shadow map ne
// peut pas en fournir un ; c'est ecrit tel quel dans composite.fsh). Sa seule
// defense contre un rebond qui traverse un mur est la porte de LUMIERE DE CIEL
// du recepteur : un pixel enferme ne recoit rien. Doubler le gain doublerait
// aussi ce qui fuit par cette porte - un interieur juste derriere une porte
// ouverte, ou skyl vaut 0.2-0.3, se mettrait a recevoir du soleil rebondi a
// travers le mur deux fois plus fort.
// Les deux genoux du smoothstep sont donc releves EN MEME TEMPS que le gain,
// 0.05/0.40 -> 0.12/0.50. Effet net (porte x gain), calcule :
//     skyl 0.10 -> x0.00 (etait 0.055 : la fuite disparait)
//     skyl 0.20 -> x0.58 (PLUS SOMBRE qu'aujourd'hui malgre le x2)
//     skyl 0.30 -> x1.15
//     skyl 0.40 -> x1.66
//     skyl 0.50 et au-dela -> x2.00 plein
// Un bloc a ciel ouvert a skyl ~ 1.0 : toute surface exterieure - la cible du
// rebond SOLAIRE - touche le gain plein. Ce qui perd, c'est exactement la zone
// ou la lumiere n'aurait pas du passer. Zero ALU nouveau (deux constantes).
#if RSM_V2 == 1
#define VLX_RSM_SKY_LO 0.12
#define VLX_RSM_SKY_HI 0.50
#else
#define VLX_RSM_SKY_LO 0.05
#define VLX_RSM_SKY_HI 0.40
#endif
//
// ---- H. COMPENSATION D'AMBIANTE ----
// Meme raisonnement qu'au bloc GI_V3 : si le rebond monte, la part que
// l'ambiante ciel lui rend doit suivre, sinon on compte deux fois. GI_V3 avait
// pose 0.79 (21 % rendus) pour une montee d'ensemble de ~x1.4. Le supplement
// mesure ici vaut +0.06 de luma sur un recepteur ayant de la geometrie a moins
// de 16 blocs (moyenne du tableau de E sur d = 1..13) ; avec l'ancrage du bloc
// GI_V3 (15 % d'ambiante ~ le rebond d'avant, ~0.21 de luma), un point de rendu
// vaut ~0.014 de luma, donc +0.06 ~ +4.3 points. On en prend 3, comme
// GI_PRESENCE avait ete pose "juste en dessous" de sa compensation exacte :
// 21 % -> 24 %, GI_BOUNCE_AMBIENT 0.79 -> 0.76.
// GATE OBLIGATOIRE SUR VLX_RSM_ACTIVE : lib/lighting.glsl applique
// GI_BOUNCE_AMBIENT des que "SSGI ou VLX_RSM_ACTIVE", donc un palier 0/1 avec
// SSGI seul et le RSM eteint recevrait la compensation d'un rebond qu'il
// n'obtient pas. Il garde 0.79.
#if RSM_V2 == 1 && defined VLX_RSM_ACTIVE
#undef GI_BOUNCE_AMBIENT
#define GI_BOUNCE_AMBIENT 0.76
#endif
//
// ---- I. LE DENOISEUR TIENT-IL ? MESURE, RIEN N'A ETE RETOUCHE ----
// GI_DENOISE_V2 ouvre sa fenetre a VLX_DEN_KSIG * sigma + 0.02, ou sigma n'est
// PAS une constante : il est estime par la passe elle-meme (vlxDenVar =
// (m2 - m1^2/N) * gR^2, composite.fsh). gR a ete mis a jour avec le gain, donc
// la fenetre suit toute seule. Verifie quand meme (rsmv2_den.py, 60 000 pixels
// par distance) : largeur de fenetre RAPPORTEE AU SIGNAL, c'est elle qui fixe
// l'equilibre scintillement / tra1nage que la passe DENOISE avait calibre.
//     d       1     2     3     5     7    10 blocs
//     avant  0.83  0.76  0.71  0.67  0.74   --
//     apres  0.70  0.66  0.67  0.77  0.85  0.93
// Meme regime : aucune constante du denoiseur n'a besoin de bouger. Deuxieme
// mesure, celle qui compte pour le scintillement - le rapport sigma_estime /
// sigma_reel valait 0.62 a 1 bloc AVANT : la fenetre s'y fermait PLUS qu'il ne
// fallait, ce qui est exactement le cycle "on ecrase l'historique puis on le
// regonfle" que la section DENOISE GI V2 decrit comme la cause du clignotement.
// Il passe a 1.18. Aux autres distances l'estimateur SUR-ouvre (1.7-2.3 avant,
// 2.0-2.7 apres) parce qu'il suppose des taps independants alors que la sequence
// de Vogel est STRATIFIEE - propriete pre-existante, partagee avec le flux SSGI,
// et qui va dans le bon sens (fenetre trop large = on garde l'historique).
//
// ---- J. CE QUI N'A PAS ETE FAIT, ET POURQUOI ----
// AJOUTER DES ECHANTILLONS. C'etait le levier evident (+50 % de RSM_SAMPLES aux
// paliers 2-3). Il n'est PAS pris : +50 % d'echantillons divise l'ecart-type par
// sqrt(1.5) = 1.22 et coute +50 % de taps, la ou le changement de noyau le
// divise par 2.2 a 1-3 blocs pour ZERO tap de plus. Le budget de la passe
// composite est donc rendu intact : le palier 3 garde ses 24 RSM_SAMPLES / 12
// taps par image, et les ~+22 % que GI_V3 avait deja ajoutes restent le seul
// surcout de la chaine GI. Taps de texture par pixel du RSM, mesures
// (rsmv2_pick.py, bloc P) : 16.7 avant, 16.2 apres - la boucle en prend meme un
// peu MOINS, parce que le tirage par importance passe plus de temps dans le
// champ proche, ou le taux de rejet est plus eleve (19.5 % -> 17.6 %
// d'echantillons retenus, et seuls les retenus paient les deux taps de
// reconstruction de normale). Le seul surcout reel est un exp2 par echantillon.

// ============ REAL LIGHTS (emissive sources - legacy mode) ============
//#define SS_LIGHTS
#define SS_LIGHT_STRENGTH 1.0 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0 3.0 5.0 10.0 20.0 50.0]
#define SS_LIGHT_RADIUS 16.0 // [4.0 8.0 12.0 16.0 24.0 32.0 48.0 64.0 128.0]
#define GI_SAMPLES 8 // [2 4 8 12 16 24 32 64 128]
#define EMISSIVE_BOOST 8.0 // [0.0 1.0 2.0 4.0 6.0 8.0 10.0 12.0 16.0 24.0 32.0 48.0 64.0 100.0]
#define LAVA_GLOW 1.0 // [0.0 0.5 1.0 1.5 2.0 3.0 5.0 8.0 12.0 20.0]
#define LAVA_ANIMATE
#define LAVA_FLOW_SPEED 0.06 // [0.0 0.03 0.06 0.1 0.2 0.4]
#define EMISSIVE_FLICKER
#define VANILLA_BLOCKLIGHT
#define VANILLA_TORCH 1.0 // [0.0 0.1 0.25 0.5 0.75 1.0 1.25 1.5 2.0 3.0 5.0 8.0]
#define HELD_LIGHT_STRENGTH 1.0 // [0.0 0.5 1.0 1.5 2.0 3.0 5.0 8.0 12.0]

// ---- PORTALS. Nether = the VANILLA animated texture (atlas animation stepped by the
// game at its native speed, nothing re-animated) with vanilla alpha, lifted to HDR by
// PORTAL_GLOW so the bright swirls feed the bloom; rendered in gbuffers_water because
// the nether_portal block is TRANSLUCENT and never reaches gbuffers_terrain (flag
// colortex2.b = 0.85, composite1 only adds the optional wobble below).
// End = window onto deep space (block entity -> gbuffers_block fallback ->
// gbuffers_terrain, identified by uniform blockEntityId == 25), see END_PORTAL_SPACE.
// PORTAL_FX 0 = original rendering; PORTAL_GLOW = HDR intensity (feeds bloom).
#define PORTAL_FX 1 // [0 1]
#define PORTAL_GLOW 1.0 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0 3.0 5.0]
// NETHER_PORTAL_WOBBLE 1 = slow sub-pixel shimmer of the Nether portal sheet and of
// what is seen through it (composite1: |offset| <= 0.5 screen px, ~5 s period).
// 0 (default) = the vanilla texture stays perfectly still.
// ### FIGE PAR LA PASSE "MEN" - PLUS AUCUN CONTROLE EN JEU, VALEUR DEFINITIVE 0.
// Raison : le plus petit detail de tout le menu (un demi-pixel), deja OFF par
// defaut - une case pour un effet que personne ne voit n'a pas sa place dans un
// menu de 4 ecrans. Le "// [0 1]" est retire pour qu'Iris cesse de l'annoncer
// comme option : un nom qui n'est plus une option ne peut plus etre epingle par
// une vieille config. Reactiver le shimmer se fait A LA MAIN, ici (site unique :
// composite1.fsh "#if PORTAL_FX == 1 && NETHER_PORTAL_WOBBLE == 1").
#define NETHER_PORTAL_WOBBLE 0 // FIGE : ondulation du portail, OFF definitif
// END_PORTAL_SPACE 1 = end_portal / end_gateway faces become a window onto deep space
// (gbuffers_terrain): 4 hashed star layers with per-layer view parallax in the face
// tangent frame (the deepest slides the most), drift <= 0.0015 block/s, slow twinkle
// (6-12 s, TAA-safe), 2-octave violet/blue nebula, near-black void (~0.004), slight
// edge vignette (well depth). Stars are HDR (~2-4 at the defaults, bloom), the void
// is not. 0 = the previous parallax star well, bit-identical.
#define END_PORTAL_SPACE 1 // [0 1]
// CONFIG_LIGHT: depth of the space behind the End portal - scales the per-layer
// parallax (how much the star layers slide with the view angle) and the edge
// vignette. 1.0 = calibrated.
#define END_PORTAL_DEPTH 1.0 // [0.5 0.75 1.0 1.25 1.5 2.0 2.5 3.0]

// ---- GLOWING RESOURCE BLOCKS (boolean toggles, OFF by default) ----
// The redstone torch (block family 26) ALWAYS emits red - no toggle. These toggles make
// SOLID resource blocks emit. Commented out = OFF = normal albedo. They are plain booleans:
// they appear as ON/OFF in screen.RTX_EMISSIVE, never in sliders=.
//#define REDSTONE_BLOCK_GLOW   // redstone block -> red
//#define EMERALD_BLOCK_GLOW    // emerald block -> green
//#define DIAMOND_BLOCK_GLOW    // diamond block -> cyan
// ---- Additional emissive resource blocks (families 31..38, OFF by default) ----
// Same rules: commented out = OFF = normal albedo. ON/OFF buttons in screen.RTX_EMISSIVE.
//#define GOLD_BLOCK_GLOW       // gold block -> warm gold
//#define IRON_BLOCK_GLOW       // iron block -> neutral white
//#define NETHERITE_BLOCK_GLOW  // netherite block -> dark purple
//#define AMETHYST_BLOCK_GLOW   // amethyst block (solid) -> purple
//#define COPPER_BLOCK_GLOW     // copper block (+ variants/waxed) -> copper orange
//#define RAW_IRON_BLOCK_GLOW   // raw iron block -> dull neutral
//#define RAW_GOLD_BLOCK_GLOW   // raw gold block -> dull gold
//#define RAW_COPPER_BLOCK_GLOW // raw copper block -> dull orange

#define SUN_INTENSITY 1.5 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 2.0 3.0 5.0 8.0 12.0 20.0]
#define MOON_INTENSITY 1.0 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0 3.0 5.0 8.0 12.0 20.0]
#define AMBIENT_INTENSITY 0.75 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 2.0 3.0 5.0 8.0]
#define SUN_TINT_TEMP 1.0 // [0.4 0.6 0.8 0.9 1.0 1.1 1.25 1.5 2.0 3.0]
// ---- CONFIG_LIGHT appearance dials (lib/lighting.glsl). Defaults = exact current render.
// Per-channel multipliers on the block-light tint (getTorchColor).
#define TORCH_R 1.0 // [0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4]
#define TORCH_G 1.0 // [0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4]
#define TORCH_B 1.0 // [0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4]
// DAY ambient temperature (getAmbientColor): >1 cooler (R down, B up), <1 warmer.
// Dusk/night ambients untouched.
#define AMBIENT_COOL 1.0 // [0.8 0.85 0.9 0.95 1.0 1.05 1.1 1.15 1.2]
// Saturation of the sky ambient inside SHADOWED areas (shadeSurface):
// 1.0 = full ambient tint (current look), 0.0 = neutral grey shadows.
#define SHADOW_TINT 1.0 // [0.0 0.15 0.3 0.45 0.6 0.75 0.9 1.0]

// ============ VOLUMETRIC LIGHT ============
// VL_RAIN: precipitation visible inside light shafts (rain streaks)
#define VL_RAIN
#define VOLUMETRIC_LIGHT
#define VL_STRENGTH 1.0 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 2.0 3.0 5.0 8.0 12.0 20.0]
// VL_SAMPLES: derived from VOLUMETRIC_QUALITY
#define VL_BLOCKLIGHT
#define VL_BLOCK_STRENGTH 1.0 // [0.0 0.25 0.5 1.0 1.5 2.0 3.0 5.0 8.0 12.0]
// VL_HALF_RES 1 (default) = the unified volumetric march (height fog + sun
// shafts + underwater god rays) runs at HALF resolution in composite.fsh
// (same lower-left-quadrant pattern as GI_HALF_RES, lib/vl_halfres.glsl)
// with TWO endpoint integrations (wMirror 0 / wMirror 1); composite1
// recombines them with the pixel's real water-mirror weight (transmittance
// EXACT, in-scatter endpoint-lerped, mid-range error < ~2% typical) behind a
// depth-aware bilateral upsample -> the VL_SAMPLES march is paid on ~1/4 of
// the pixels (~4x cheaper). Underwater god-ray striations soften slightly
// (half-res + bilateral). 0 = original full-res inline march in composite1,
// bit-identical.
// VL_HALF_RES : derive de VL_FULL_RES (bloc AXES DE MENU, haut de ce
// fichier). Depuis la passe VQ3 il vaut 1 a TOUS les paliers -- le palier 3
// re-etage reinvestit le x4 de pixels en 32 pas + portee UW 128 -- et il
// n'est plus pose dans les branches de l'axe : la seule voie vers le plein
// ecran est VL_FULL_RES = 1 (define expert fige hors menu, sous l'axe ;
// cout x4 sur la marche, a reserver aux captures d'ecran).

// ============ HEIGHT FOG (cinematic) ============
#define HEIGHT_FOG
// SEALEVEL_MIST: mist sheet just above water at dawn/dusk. It produces a golden horizontal
// BAND at Y=63, so it is OFF by default. Define it to restore the old behaviour.
//#define SEALEVEL_MIST
#define HEIGHT_FOG_DENSITY 1.0 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0 3.0 5.0 8.0 12.0 20.0]
#define HEIGHT_FOG_FALLOFF 1.0 // [0.1 0.25 0.5 0.75 1.0 1.5 2.0 3.0 5.0 8.0]

// ---- Mid-field atmospheric fog + biome tint + dusk boosts ----
// ATMO_FOG: progressive Beer-Lambert layer starting around 60 blocks (the vanilla layer
// only kicks in at the very end of the far plane). Boolean toggle (VOLUMETRICS menu).
#define ATMO_FOG
#define ATMO_FOG_DENSITY 1.0 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0 3.0 5.0 8.0]
// Dusk mist boost. 1.0 is the anti-wash default: four luminance boosts stack at
// sunset, so the defaults are deliberately staggered.
#define ATMO_FOG_DUSK_BOOST 1.0 // [0.0 0.5 1.0 1.5 2.0 3.0 4.0 6.0]
// FOG_BIOME_TINT: volumetric mist takes the biome tint (greenish swamp, etc). OFF by default.
//#define FOG_BIOME_TINT
#define FOG_BIOME_TINT_STRENGTH 0.6 // [0.0 0.25 0.4 0.6 0.8 1.0]
// Dusk boost of the VL phase function (more directional shafts; NaN clamped in code).
#define VL_DUSK_BOOST 1.0 // [0.0 0.5 1.0 1.5 2.0 3.0]
// Dusk boost of the screen-space godrays. 0.5 is the anti-wash default.
#define GODRAY_DUSK_BOOST 0.5 // [0.0 0.5 1.0 1.5 2.0 3.0]
// FOG_SHADOWS: shadows CAST ONTO the additive fogs. The unified VL march is
// the only fog that was shadow-aware; the analytic fog terms (ATMO_FOG,
// AERIAL_PERSPECTIVE, DAWN_MIST, the HEIGHT_FOG far tail) received the sun
// UNIFORMLY, so haze under a cumulus or behind a shading mountain kept
// glowing -- which made the volumetrics read flat. 1 (default) = ONE shared
// per-pixel sun-visibility probe (composite1 fogSunVis: 3 dither-jittered
// single-tap raw shadowtex1 reads x cloud shadow, spread over the whole view
// ray at a mean 20/50/80% of its length, fail-open beyond the shadow map so
// distant haze is never darkened by shade at your feet)
// multiplies the DIRECT/solar glow of those fogs; their sky-ambient part
// only dips to 75% under full occlusion (ambient light arrives from the
// whole sky). Terrain shadows onto the CLOUDS themselves are NOT attempted:
// the cloud slab (VC_BASE 210 blocks up, often 700+ blocks out) sits far
// outside the shadow map range, and clouds already carry their own
// light-march self-shadowing. COST: 3 shadow-map taps plus, under cloud cover,
// up to ~9 noise evaluations per tap for the cloud factor (occluded taps skip
// it). That cloud cost does NOT scale with CLOUD_QUALITY, so low-end machines
// pay the same as high-end ones -- set this to 0 there if the fogs are not
// worth it. 0 = legacy uniform fog glow, bit-identical.
// ### FIGE PAR LA PASSE "MEN" - PLUS AUCUN CONTROLE EN JEU, VALEUR DEFINITIVE 1.
// ATTENTION, retrait INVERSE des autres : l'EFFET RESTE ACTIF ("faut garder
// ca", mot du createur) - c'est le REGLAGE qui disparait du menu, pas les
// ombres sur le brouillard. Le "// [0 1]" est retire pour qu'Iris cesse de
// l'annoncer comme option : une vieille config portant FOG_SHADOWS=0 ne peut
// plus eteindre l'effet en silence. Couper les 3 taps (machine faible) se fait
// A LA MAIN, ici - les sites composite1 passent tous par FOG_SHADOWS_ACTIVE et
// restent bit-identiques a 0.
#define FOG_SHADOWS 1 // FIGE : ombres sur le brouillard, TOUJOURS actives

// ============ WATER ============
// ---- PHYSICS MOD PRO (mod externe, ocean dynamique) ------------------------
// 1 = les programmes physics_ocean_v2.* / physics_ocean_shadow_v2.* (racine de
// shaders/) compilent le corps de gbuffers_water / shadow avec PHYSICS_OCEAN :
// la geometrie de l'ocean simule du mod suit SES vagues (deplacement vertex du
// mod, jamais le notre) et la normale ecrite au gbuffer est celle de SON champ
// (SSR / Fresnel / glint GGX / wMirror de composite1 suivent), ecume comprise.
// 0 = ces programmes deviennent des copies conformes de l'eau normale : aucun
// symbole physics_* ne survit a la precompilation.
// SANS le mod, ce reglage est SANS EFFET dans les deux sens : les fichiers
// physics_ocean_v2.* ne sont des programmes que POUR le mod (c'est lui qui les
// declare a Iris) ; Iris seul ne les compile jamais, et gbuffers_water/shadow
// ne definissent jamais PHYSICS_OCEAN. HORS MENU volontairement (interrupteur
// de compatibilite, pas un gout) - pas de liste [..], donc pas une option Iris.
#define PHYSICS_MOD_SUPPORT 1 // hors menu : support de l'ocean de Physics Mod Pro
// ---- PHYSICS_FIELD_SYNC : les EFFETS D'EAU suivent l'ocean du mod ----------
// PHYSICS_MOD_SUPPORT ci-dessus fait suivre la GEOMETRIE et la NORMALE de la
// surface (donc SSR, Fresnel, glint, refraction : ils lisent colortex1). Ce
// gate-ci fait suivre ce que composite1 recalcule DANS SON PROPRE CHAMP et qui
// restait donc desynchronise des cretes visibles :
//   - le filet de caustiques v4/v5/v6 (vlCa4Net / vlCaNetD) aux trois sites
//     (a travers la surface, rivage, oeil immerge) ;
//   - les puits de lumiere sous-marins de la marche VL (vlCa4Vol pour les
//     striations, causticShaftMask pour les gerbes larges) ;
//   - l'ecume WHITECAPS (la crete lue devient celle du mod).
// COMMENT (aucun uniforme du mod n'est lie a composite : le mod ne lie ses UBO
// PhysicsOcean / PhysicsOceanChunk qu'aux programmes ocean) : les programmes
// ocean PUBLIENT leur champ dans deux images Iris (shaders.properties -
// physOceanParams 2x1 rgba32f = parametres globaux + battement frameCounter ;
// physOceanPix plein ecran r32ui = estampille + waviness par pixel), que
// composite1 / composite relisent en samplers. Le champ lui-meme est
// REIMPLEMENTE a parametres explicites dans lib/water.glsl (vlxPhysSlope :
// meme recurrence 13 octaves que physics_waveHeight, gradient ANALYTIQUE en
// une passe - chaine du drag comprise - au lieu de 4 differences finies) et
// branche dans les estimateurs par des globales.
// AUTOMATIQUE : l'effet ne s'allume que la ou le battement de la frame
// COURANTE prouve que l'ocean du mod est rendu. Sans le mod les images ne sont
// jamais ecrites, le battement est perime, et tout reste le chemin legacy.
// 0 = rollback complet : plus aucune declaration d'image ni de sampler, plus
// aucune globale, chaque programme redevient BIT-IDENTIQUE (preuve par hash
// SPIR-V). HORS MENU volontairement (interrupteur de compatibilite, pas un
// gout) - pas de liste [..], donc pas une option Iris.
// COUT A 0 : les deux directives image.* de shaders.properties ne sont pas
// gatables par le preprocesseur, donc les deux images restent ALLOUEES
// (2 texels + un plein ecran r32ui, ~8 Mio en 1080p) ; clear=false, donc
// aucun memset par frame. Pour recuperer ces 8 Mio : supprimer les deux lignes
// image.physOcean* a la main.
// VUE DE DEBUG : DEBUG_VIEW 30 (bloc DEBUG en bas de ce fichier).
#define PHYSICS_FIELD_SYNC 1 // hors menu : les effets d'eau suivent l'ocean du mod
// ---- PHYS_SWELL : les caustiques FOCALISENT sous la HOULE VISIBLE du mod ----
// RETOUR CREATEUR (test en jeu du raccord ci-dessus) : "les caustics reagissent
// pas trop aux vagues de physics mod". CAUSE, MESUREE : le filet lit bien le
// champ du mod, mais avec une pente NORMALISEE (contraste calibre du pack, K
// resolu sur l'exposition) et une deviation FIXE (CA4_DEV) ; or la courbure du
// champ du mod croit avec l'octave (poids x freq^2 = 1.11^i), donc le filet est
// dessine par les octaves FINES (4-6 blocs, 7 % de l'amplitude, a peine
// visibles sur la surface) et glisse a LEUR vitesse (1.3 bloc/s) alors que la
// houle visible (10-30 blocs) avance a 4.3 blocs/s : rien ne suit les cretes.
// MECANISME (physique, pas un gain) : la carte de refraction x -> x + c*d*grad h
// (c = 1 - 1/1.3333, d = profondeur) a pour jacobien J = I + c*d*A*H, H =
// hessienne de la hauteur, A = la meme matrice d'obliquite que le filet
// (vlCa4Aniso). La densite lumineuse paraxiale est 1/|det J| : > 1 sous les
// cretes (lentille convergente), < 1 sous les creux, moyenne EXACTEMENT 1 tant
// qu'il n'y a pas de pli (conservation de l'aire). vlxPhysSwellFocus
// (lib/water.glsl) l'evalue sur les PHYS_SWELL_OCT premieres octaves du champ
// (lambda >= 9.4 blocs = la houle que l'oeil voit ; les octaves fines sont deja
// dans le filet) avec la hessienne de Gauss-Newton de la meme recurrence, et
// vlCaNetD multiplie le filet par ce facteur aux trois sites.
// PHYS_SWELL_GAIN : la profondeur EFFECTIVE de focalisation = d x GAIN. A 1.0
// (valeur physique) le champ du mod, houle de 2 blocs d'amplitude sur 30 blocs,
// focalise peu avant 20 blocs de fond (mesure pf_swell.py, amp 2, 8 octaves :
// p5-p95 du facteur 0.95-1.10 a 5 blocs, 0.90-1.21 a 10, 0.81-1.54 a 20). Le
// createur veut VOIR les bandes suivre les cretes sur un fond de plage : 2.5
// place le regime "reseau lisible" (p95 1.3 a 1.5) entre 5 et 10 blocs de
// fond. Ecart assume et chiffre : la focalisation est celle d'une eau 2.5 fois
// plus profonde. Exposition : moyenne du facteur +1 % a 10 blocs effectifs,
// +4 % a 20, +13 % a 40 (les plis sont bornes par PHYS_SWELL_MAX ; l'absorption
// du pack eteint de toute facon le terme a ces profondeurs). 1.0 = physique.
// 0 = filet seul (la livraison precedente, bit-identique). Sans effet hors de
// l'ocean du mod. HORS MENU, pas de liste.
#define PHYS_SWELL 1 // hors menu : bandes de focalisation de la houle du mod sur les caustiques
#define PHYS_SWELL_OCT 8 // octaves du champ du mod prises comme houle visible (lambda >= 9.4 b)
#define PHYS_SWELL_GAIN 2.5 // profondeur effective de focalisation = d x GAIN (1.0 = physique)
#define PHYS_SWELL_MIN 0.40 // plancher du facteur (creux)
#define PHYS_SWELL_MAX 2.5 // plafond du facteur (plis)
// ---- VLX_PHYS_BIOME : test de biome pour les sites SANS estampille ----------
// Les sites "rivage" et "oeil immerge" (et la marche VL) n'ont pas l'estampille
// par pixel de la surface ; la livraison exigeait en plus un biome camera
// cotier (biome_category = CAT_OCEAN / CAT_BEACH / CAT_RIVER, CAT_NONE tolere).
// RETOUR CREATEUR : "c'est que les caustics qu'on voit de dehors l'eau ?" - sous
// l'eau rien ne suivait. Le mapping de biome_category d'Iris sur MC 26.2 n'est
// pas verifiable ici (les categories ont disparu du jeu en 1.19, Iris les
// reconstruit) : un ocean range dans une categorie inattendue eteint le site
// immerge EN SILENCE. 0 (defaut) = le battement (l'ocean du mod est rendu pres
// du joueur, pass ombre compris) + les tests d'altitude suffisent ; ecart
// assume : une riviere / un lac au niveau de la mer a moins de shadowDistance
// d'un ocean du mod actif prend le champ du mod. 1 = la regle livree.
#define VLX_PHYS_BIOME 0 // hors menu : 1 = exiger un biome cotier pour les sites sans estampille
// ---- PHYS_REAL : LES VRAIES CAUSTIQUES DE LA SURFACE QUE LE MOD AFFICHE ----
// RETOUR CREATEUR (test en jeu de PHYS_SWELL) : "ca ne reagit pas aux vagues
// reelles de Physics : les ripples que je fais en jetant un objet n'existent
// pas dans les caustiques ; je mets la hauteur des vagues a 0 et il y a
// toujours des caustiques ; les vagues en V que fait le bateau n'y sont pas."
// TROIS CAUSES, toutes reelles :
//  1. Le chemin PHYSICS_FIELD_SYNC nourrit le FILET du pack (vlCa4Net), qui est
//     NORMALISE en amplitude (K resolu sur l'exposition) : une mer plate garde
//     le filet. C'est le "hauteur 0 -> toujours des caustiques".
//  2. physics_ripples (rides d'objets, sillages, joueur) n'est liee qu'aux
//     programmes ocean et n'etait jamais lue ailleurs : aucun anneau, aucun V.
//  3. La NORMALE QUE LE MOD AFFICHE n'est PAS le gradient de sa hauteur.
//     physics_wavePixel accumule dx += force / pow(w, 0.75) - force SANS
//     facteur de frequence - puis direction = -dx / pow(waveSum, 0.25), et
//     physics_waveNormal en fait baseSlope = direction * (oceanHeight/13 *
//     max(0.1,waviness)) / 0.6, plus la pente des rides x 0.042 x rippleBlend.
//     MESURE (pr_m1.py) : la pente RENDUE vaut 1.95 fois le gradient vrai a
//     13 octaves (2.04 a 40) - le cahier des charges annoncait "environ 5x" :
//     REFUTE, chiffre. Cela reste une AUTRE surface que celle que le champ
//     reimplemente donnait, et c'est celle que le joueur voit.
// CE QUE PHYS_REAL LIVRE
//  (1) Les deux programmes ocean RECOPIENT physics_ripples dans l'image Iris
//      physRipple et publient sa portee, sa taille et son centre MONDE dans
//      physRipParams (shaders.properties).
//  (2) lib/water.glsl reimplemente la NORMALE DU MOD a parametres explicites
//      (vlxPhysSlopeReal), rides comprises, AVEC SON JACOBIEN analytique
//      (chaine du drag portee : erreur RMS 0.0005 % contre les differences
//      finies a 13 octaves, 0.02 % a 25 - pr_m1.py).
//  (3) vlCaNetD renvoie, sur un pixel d'ocean du mod, la DENSITE PARAXIALE DE
//      REFRACTION 1 / |det(I - c d A dS)| (c = 1 - 1/1.3333, A = l'obliquite
//      solaire du pack) A LA PLACE du filet. Surface plate => dS = 0 => det = 1
//      => densite EXACTEMENT 1.000000000, aucune caustique (mesure pr_m2.py D).
// PHYS_SWELL EST RENDU INERTE a PHYS_REAL 1 (son code et ses defines restent,
// mais la focalisation par la hessienne de la HAUTEUR est remplacee par celle
// de la pente REELLEMENT AFFICHEE, qui la contient). PHYS_REAL 0 = la
// livraison PHYS_SWELL, bit-identique (preuve par hash SPIR-V).
// COUT A 0 : les deux directives image.* de shaders.properties (2 Mio,
// clear=false). Aucun symbole, aucune globale, aucun store.
// VUE DE DEBUG : DEBUG_VIEW 31 (bloc DEBUG en bas de ce fichier).
#define PHYS_REAL 1 // hors menu : caustiques physiques de la surface affichee par le mod
// Taille de la copie de physics_ripples. DOIT rester egale a la taille de
// image.physRipple dans shaders.properties (une directive image.* n'est pas
// preprocessee). 1024^2 = 1 048 576 texels ; a 4 texels par fragment un ocean
// qui couvre 12.6 % d'un ecran 1080p recopie TOUTE la carte chaque frame, 5 %
// la recopie en 2.5 frames (mesure pr_m4.py D). Les rides du mod avancent a
// 1-2 blocs/s : 3 frames de retard = 0.05-0.10 bloc. Assume.
#define PHYS_REAL_RIPN 1024 // cote de l'image physRipple (= shaders.properties)
// Rotation de l'index de copie d'une frame a l'autre : impair, donc premier
// avec 2^20, donc les fenetres de frames successives ne se recouvrent pas.
#define PHYS_REAL_ROT 262145 // 2^18 + 1 : decalage de l'index de copie par frame
// OCTAVES DE LA NORMALE. Le mod publie physics_iterationsNormal ; on le borne.
// MESURE (pr_m1.py 3) a amplitude 2 : les octaves au-dela de 20 (lambda < 1.29
// bloc) ajoutent 5 % de la pente RENDUE mais MULTIPLIENT PAR 9 la RMS de son
// jacobien (0.139 a 20 octaves, 1.264 a 40) - et c'est le jacobien, pas la
// pente, qui fait la caustique. A 40 octaves l'estimateur mono-branche est
// replie sur 55 % de l'aire (pr_m2.py A) : ce n'est plus une caustique, c'est
// du bruit sous-pixel. 20 est le dernier palier ou la caustique reste un
// reseau lisible (filaments 1.3-4 blocs). Le plancher 13 est le nombre
// d'octaves du DEPLACEMENT du mod (PHYSICS_ITERATIONS_OFFSET) : on ne rend
// jamais une surface plus lisse que celle qu'il deplace, et une valeur
// publiee nulle ou aberrante degenere proprement.
#define PHYS_REAL_MINOCT 13 // plancher d'octaves (= PHYSICS_ITERATIONS_OFFSET)
#define PHYS_REAL_MAXOCT 20 // plafond d'octaves (mesure : au-dela, du bruit)
// theta = c * d * RMS(dS) est LE parametre du probleme. Au-dela du premier pli
// l'estimateur mono-branche (1/|det|) n'a plus de sens physique : la lumiere
// arrive alors par plusieurs chemins et il faudrait les sommer. On borne donc
// la PROFONDEUR DE FOCALISATION a theta = 0.35, la crete de la courbe
// d'exposition mesuree (pr_m2b.py C). Consequence assumee, et physique : sous
// une eau tres profonde le reseau cesse de se resserrer, il sature - ce que
// fait aussi la vraie mer.
#define PHYS_REAL_THMAX 0.35 // theta maximal (borne la profondeur de focalisation)
#define PHYS_REAL_DMAX 24.0 // borne absolue de la profondeur de focalisation (blocs)
// CAP SOLAIRE. Le soleil n'est pas ponctuel : son rayon angulaire vaut
// 4.654e-3 rad, soit 3.49e-3 apres refraction dans l'eau (divise par n). Pres
// d'un pli Y(x) ~ a x^2 / 2, la densite ideale 1/sqrt(2 a |y|) devient, lissee
// sur la tache solaire de demi-largeur d*alpha, au plus sqrt(2/(a d alpha))
// avec a = c d |d2S| : le plancher sur |det| vaut donc d * sqrt(c alpha k |dS| / 2)
// ou k = RMS(d2S)/RMS(dS) est le nombre d'onde caracteristique du champ,
// MESURE (pr_m1.py 4) a 5.60 par bloc a 20 octaves -> CAPK = 0.0494.
// A amplitude nulle |dS| = 0 donc le plancher est 0 : la densite reste
// EXACTEMENT 1, ce qui est la propriete que le createur demande.
#define PHYS_REAL_CAPK 0.0494 // plancher de |det| = CAPK * d * sqrt(|dS|)
// Normalisation d'ensemble : RMS(dS) est reconstruite DANS la boucle a partir
// de sa somme geometrique sum (w^0.25 f_i)^2. La constante est calee sur la
// RMS MESUREE (pr_m2b.py A) : erreur <= 3 % de 13 a 25 octaves.
#define PHYS_REAL_C0 0.2105 // RMS(dS) = C0 * ampf * s / waveSum^0.25 * sqrt(somme)
// EXPOSITION. Le cap et les plis font deriver la moyenne de la densite ;
// MESUREE sur 81 points (4 nombres d'octaves x 3 amplitudes x 8 profondeurs,
// pr_m2b.py B) elle s'effondre sur UNE courbe en theta, ajustee a 6.7 % RMS
// par f(theta) = 1 + 9.0 theta^2 / (1 + 3.7 theta). Diviser par f rend au
// terme livre la moyenne 1 que toute la calibration du pack suppose : pire
// ecart 15.5 % sur les 60 cellules du sweep, -1.2 a +3.8 % au point nominal
// (20 octaves, amplitude 2). Sans elle : +42 % a 5 blocs.
#define PHYS_REAL_EA 9.0 // f(theta) = 1 + EA*theta^2/(1 + EB*theta)
#define PHYS_REAL_EB 3.7 // (idem)
// Plancher du terme : un creux ne noircit pas le fond.
#define PHYS_REAL_MIN 0.10 // plancher de la densite
// PUITS DE LUMIERE. Les striations volumetriques deviennent
// 0.42 + max(densite - 1, 0) * VOLK, la bande [0.42, 1.55] que la mise en
// forme aval attend. VOLK est RESOLU (pr_m4.py A) pour que le pic (p99.9)
// retombe sur 1.45, la valeur que le pack a calibree pour vlCa4Vol : mediane
// 0.526 sur 4 profondeurs a amplitude 2. A amplitude nulle il n'y a PLUS DE
// FAISCEAUX du tout - c'est physique, une surface plate ne fabrique pas de
// rayons.
#define PHYS_REAL_VOLK 0.53 // gain des striations des puits de lumiere
// ---- PHYS_REAL_V2 : STABILITE TEMPORELLE ET EXCLUSIVITE -------------------
// RETOUR CREATEUR (test en jeu de PHYS_REAL) : "les caustics beuguent un peu,
// ca clignote, c'est beugue, je pense qu'il y a conflit. Fais en sorte
// d'utiliser QUE ces caustics-la quand le Physics Mod est active."
// DEUX CAUSES, TOUTES DEUX MESUREES (pr2_m0/m0b/m1/m2.py) :
//  1. LA WAVINESS PUBLIEE EST NON DETERMINISTE. physOceanParams ne porte
//     qu'une waviness, celle du dernier fragment ocean ecrit de la frame, et
//     l'ordre d'ecriture change d'une frame a l'autre. Sous PHYS_REAL
//     l'amplitude des caustiques est PHYSIQUE (baseSlope proportionnelle a
//     oceanHeight/13 x waviness), donc aux sites SANS estampille par pixel
//     (rivage, oeil immerge, puits de lumiere) le terme SAUTE. MESURE : avec
//     une waviness tiree dans [0.3, 1] a chaque frame, l'ecart-type temporel
//     par pixel du terme est multiplie par 2.22 (p95 x1.98) a 5 blocs de fond.
//  2. LA DENSITE PARAXIALE EST EVALUEE EN UN POINT. 1/|det| n'est pas filtre :
//     les lignes de pli font moins d'un pixel et le jitter TAA les fait
//     scintiller. MESURE (32 frames jitterees, pixels de 0.05 bloc, avant
//     TAA) : p99 de l'ecart-type temporel par pixel 0.557 a 5 blocs, 0.514 a
//     10 - contre 0.148 / 0.080 pour le FILET DU PACK, la reference que le
//     createur trouve stable.
// CE QUE PHYS_REAL_V2 LIVRE
//  (A) CARTE DE WAVINESS ANCREE MONDE (image physWavMap, shaders.properties) :
//      cellules de 4 blocs, ecrites par les DEUX programmes ocean avec une
//      estampille de frame, relues au xz du point d'ENTREE par les sites sans
//      estampille. Dans une cellule de 4 blocs la waviness est quasi
//      constante, donc "dernier gagne" y devient stable : MESURE, une
//      dispersion intra-cellule de 0.05 / 0.10 n'induit que 0.09-0.22x /
//      0.17-0.39x le bruit propre de l'estimateur.
//  (B) DENSITE FILTREE : l'estimateur a 9 PHOTONS du pack (reseau 3x3
//      CA4_PSPACE / CA4_PRAD, meme splat quadratique a bord dur) nourri du
//      VRAI jacobien analytique du mod. Le compte est divise par S0, son
//      esperance pour la carte IDENTITE : PAS de courbe de tonalite.
//      MESURE : p99 de l'ecart-type temporel par pixel 0.094 a 5 blocs, 0.105
//      a 10, contre 0.557 / 0.514 pour la densite ponctuelle - un facteur 5 a
//      6 sur la QUEUE, qui est exactement ce que le clignotement est.
//  (C) EXCLUSIVITE : aux paliers ou CAUSTICS_V4 vaut 0 (CAUSTIC_QUALITY 0) et
//      dans le bras UW_GODRAY_CAUSTIC_LOCK 0, les bras LEGACY du pack
//      (waveCausticSoft/Full/Chroma, causticSmall) restaient appliques a
//      l'ocean du mod. Ils sont maintenant remplaces, sur ces pixels-la, par
//      la meme densite physique, remappee dans la bande que chaque bras
//      consomme. Plus AUCUN terme de caustique du pack ne survit sur l'ocean
//      du mod, a AUCUN palier.
// CE QUE LA MESURE A REFUTE. Le cahier des charges demandait la deflexion
// PHYSIQUE au centre du reseau (d0 = -c d A S). MESURE (pr2_m0.py B) : a 5
// blocs de fond la deflexion physique vaut deja 1.4 rayon de noyau et 2.8 a
// 10 blocs, alors que le jacobien physique, lui, est PETIT (||M - I|| ~ 0.3) :
// l'image du reseau ne se deforme pas assez pour revenir sur le pixel, les 9
// photons sortent tous du disque et le terme S'EFFONDRE - moyenne 0.36 a
// 5 blocs, 0.11 a 10, derive maximale -96.5 %. (Le filet du pack, lui, vit
// avec une deflexion de 3.6 rayons parce que son jacobien est amplifie par
// CA4_DEV et le clamp +-3.) Ce qui est livre est le reseau RE-CENTRE sur la
// preimage du point (d0 = 0) : c'est l'estimateur mono-branche exact de la
// densite au point, lisse par le noyau, moyenne 0.999 a 1.097 avant
// correction. Ecrit noir sur blanc.
// PHYS_REAL_V2 0 = la livraison PHYS_REAL, bit-identique (preuve par hash).
// COUT A 0 : la directive image.physWavMap de shaders.properties (64 Kio,
// clear=false). Aucun symbole, aucune globale, aucun store.
#define PHYS_REAL_V2 1 // hors menu : caustiques du mod stables et exclusives
// Carte de waviness. WAVN DOIT rester egal a la taille de image.physWavMap
// dans shaders.properties (une directive image.* n'est pas preprocessee).
// WAVC = cote de cellule en blocs ; WAVN x WAVC = 512 blocs de periode.
// WAVM = modulo de l'estampille : 1024 est le plus grand modulo dont TOUTES
// les valeurs +1 (donc jusqu'a 1024) sont exactes en float16 (2049 ne l'est
// pas). WAVR = rayon d'ecriture, en blocs : il borne l'empreinte des
// ecrivains a 2 x 250 = 500 blocs, donc sous la periode de 512, donc sans
// repliement de cellule.
#define PHYS_REAL_V2_WAVN 128 // cote de la carte de waviness (= shaders.properties)
#define PHYS_REAL_V2_WAVC 4.0 // cote d'une cellule, en blocs
#define PHYS_REAL_V2_WAVM 1024.0 // modulo de l'estampille (exact en float16)
#define PHYS_REAL_V2_WAVR 250.0 // rayon d'ecriture, en blocs (anti-repliement)
// EXPOSITION. Sans deflexion au centre, la moyenne du compte divise par S0
// derive avec theta = c dEff RMS|dS| : MESUREE sur 596 points (3 nombres
// d'octaves x 4 amplitudes x 3 waviness x 2 instants x 9 profondeurs) elle
// s'effondre sur UNE courbe en theta, +15.35 % au pire. L'ajustement
// m(theta) = 1 + 4.60 theta^2 / (1 + 30.10 theta^2) la ramene a +-3.37 %
// (RMS residuel 0.0071). C'est mieux que ce que le chemin PHYS_REAL livrait
// (15.5 % residuel) et mieux que la calibration du pack elle-meme (15.1 %).
#define PHYS_REAL_V2_EA 4.60 // m(theta) = 1 + EA theta^2 / (1 + EB theta^2)
#define PHYS_REAL_V2_EB 30.10 // (idem)
// SURFACE PLATE EXACTEMENT 1. Le compte varie avec le jitter meme pour la
// carte identite (MESURE : ecart-type 0.0199 du rapport S/S0), ce qui est
// inacceptable pour "hauteur de vagues 0 -> plus rien". Le terme est donc
// melange vers 1.0 par smoothstep(0, W0, ||M - I||) : a amplitude nulle ET
// sans ride M vaut I EXACTEMENT, donc le melange vaut 0 et le terme vaut
// 1.000000 exactement. MESURE du choix de W0 (pr2_m0b.py G) a 5 blocs :
//   W0     grain a amp 0.10   grain a amp 0.25   contraste perdu a wav 0.2
//   brut        0.02036            0.02412                    0 %
//   0.02        0.01430            0.02362                    0.1 %
//   0.05        0.00454            0.01743                    7 %
//   0.10        0.00140            0.00802                   31 %
// 0.05 divise par 4.5 le grain de la mer quasi plate en ne coutant que 7 % de
// contraste au cas le plus defavorable (waviness 0.2, fond a 3 blocs) et
// moins de 0.3 % des que l'amplitude depasse 0.5 bloc.
#define PHYS_REAL_V2_W0 0.05 // largeur du melange vers 1.0 (unites de ||M - I||)
// ---- PHYS_DISP : DISPERSION CHROMATIQUE de la caustique physique ----------
// DEMANDE CREATEUR (photo de piscine a l'appui) : "on voit des couleurs qui
// sortent un peu des caustiques ; un truc realiste, pas juste rouge et bleu
// sur les cotes, quali mais rapide".
// PHYSIQUE : l'indice de l'eau depend de la longueur d'onde (20 C, CRC :
// 486.1 nm 1.3372, 546.1 nm 1.3345, 589.3 nm 1.3330, 656.3 nm 1.3312) ; aux
// longueurs d'onde dominantes des primaires sRGB, n(612) = 1.3324, n(550) =
// 1.3344, n(465) = 1.3385. Le facteur de deviation paraxial c = 1 - 1/n vaut
// donc 0.249469 / 0.250580 / 0.252895 : le BLEU est devie 0.92 % de plus que
// le vert, le ROUGE 0.44 % de moins. Les trois caustiques sont le MEME motif
// a trois echelles de deviation : la carte de refraction de chaque canal est
// M_l = I + k_l (M - I) avec k_l = c_l / c_G (k_R 0.995568, k_B 1.009241).
// Asymetrique par nature (courbe plus raide dans le bleu : +0.92 % contre
// -0.44 %). Le bleu, plus devie, FOCALISE plus fort : a l'echelle du noyau de
// 14 cm de l'estimateur (regime pre-focal, plis bornes) l'effet est un
// CONTRASTE PAR CANAL, pas un lisere lateral - les filaments brillants tirent
// vers le bleu-cyan (B/R 1.040 sur les pics a K 8 ; B/G 1.019, R/G 0.989 sur
// un filament de densite 3), les cellules sombres entre eux vers le chaud
// (B/R 0.964), les demi-teintes restent neutres (MESURE pf_disp8b.py ; le
// decalage des plis entre canaux, ~1 cm a 5 blocs, est invisible sous 14 cm
// de noyau). Jamais le lisere rouge/bleu symetrique d'un decalage de canaux.
// Moyenne de chaque canal ~ 1 (conservation par canal) : pas de teinte
// moyenne ajoutee, et a surface plate les trois canaux valent exactement 1.
// COUT : les 9 photons sont splattes 3 fois (27 noyaux au lieu de 9 : +92
// instructions dynamiques, +5 %, 0 transcendante, MESURE pf_disp_cost.py),
// ZERO evaluation de champ en plus - la pente et le jacobien sont partages
// par les trois canaux.
// PHYS_DISP_K : exageration de la deviation spectrale (1.0 = physique). Les
// franges d'une vraie piscine se lisent parce que les filaments y font 1-2 cm ;
// ici le noyau de l'estimateur fait 14 cm (0.144 bloc), donc a echelle
// physique la frange ne vaut que 0.3 % du pic en moyenne, 0.8 % au p95 des
// bords (MESURE pf_disp8.py, anneau + houle du mod a 5 blocs, 32 tirages, le
// meme jitter pour chaque K). La valeur livree 8.0 donne |R-B|/G = 3.5 % en
// moyenne sur les bords des filaments, 6.1 % au p95, 20 % au maximum -
// l'ordre de grandeur de la photo - pour une derive de teinte moyenne de
// +0.60 % (bleu) / -0.31 % (rouge), sous le seuil visible. 6.0 : 2.7 / 4.5 /
// 15 % ; 10.0 : 4.4 / 7.6 / 25 %, teinte +0.75 / -0.39 %. 1.0 = strictement
// physique, 0 = aucune couleur ; 12.0 si le createur veut plus visible.
// HORS MENU, sans liste. PHYS_DISP 0 = la livraison PHYS_REAL_V2, bit-identique.
#define PHYS_DISP 1 // hors menu : dispersion chromatique de la caustique physique
#define PHYS_DISP_K 8.0 // exageration de la deviation spectrale (1.0 = physique)
#define PHYS_DISP_KR 0.995568 // c(612 nm) / c(550 nm), eau 20 C (pf_disp.py)
#define PHYS_DISP_KB 1.009241 // c(465 nm) / c(550 nm), eau 20 C (pf_disp.py)
// COPIE DE RIDES. Le front d'un anneau montre une couture la ou la fenetre de
// copie de la frame courante s'arrete : MESURE (pr2_m2.py D3), un retard d'une
// frame vaut 10.7 % de l'ecart-type spatial du terme SUR la couture (32 % a
// trois frames). Deux corrections, toutes deux gratuites : le pass gbuffer
// recopie 8 texels par fragment au lieu de 4 (un ocean qui couvre 6.3 % d'un
// ecran 1080p recopie alors TOUTE la carte chaque frame, contre 12.6 % avant),
// et la fenetre du pass OMBRE est decalee d'une demi-carte pour qu'elle ne
// recouvre plus celle du gbuffer : les deux fenetres deviennent disjointes,
// donc la couverture par frame est la SOMME des deux au lieu du maximum.
#define PHYS_REAL_V2_RIPK 8 // texels de rides copies par fragment ocean (gbuffer)
#define WATER_WAVES
#define WAVE_STRENGTH 1.0 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 2.0 3.0 5.0 8.0 12.0]
// EAU5 : 1.0 -> 0.75 (-25 %), sur retour createur "reduire un peu la vitesse de
// l'eau". WAVE_SPEED est L'HORLOGE DE LA SURFACE et rien d'autre : swellEval
// (0.60 * WAVE_SPEED), le chop et la texture v3 (0.8 * WAVE_SPEED), les trains
// (omg * WAVE_SPEED), wave3Eval (t * WAVE_SPEED) et - c'est ce qui garantit la
// synchro - vlCa5Slope, qui lit le MEME champ wave3Eval avec le meme facteur A
// UNE CONSTANTE PRES : l'horloge de la surface est t * WAVE_SPEED, celle des
// caustiques t * WAVE_SPEED * CAUSTIC_SPEED * CA4_SPEED * CA5_TK, avec
// CA5_TK = sqrt(CA5_K), le facteur de dispersion omega ~ sqrt(k) qui accompagne
// le rescale spatial CA5_K (physiquement juste, et donc PAS egal a 1.0). Ce qui
// est invariant sous WAVE_SPEED, et c'est tout ce qu'il faut, c'est le RAPPORT
// des deux horloges : les deux sont lineaires en WAVE_SPEED, il se simplifie.
// Sous CAUSTICS_V5 = 1 (CAUSTIC_QUALITY >= 1 ; l'axe est declare [0 1 2] et
// tourne a son defaut 2, il n'apparait pas dans le .txt de reglages) le filet
// de caustiques est deflechi par vlCa5Slope et
// PAR RIEN D'AUTRE : le rapport des deux horloges ne
// bouge pas, la synchro vagues<->caustiques tient a n'importe quelle vitesse.
// Le glint suit lui aussi, ses normales VENANT du champ de vagues.
// RESIDU ASSUME : vlCa4Slope (le champ v4 pur, seul chemin quand
// CAUSTIC_QUALITY = 0) tourne sur t * CAUSTIC_SPEED * CA4_SPEED, sans
// WAVE_SPEED - il n'a jamais ete cale sur l'horloge de la surface, ses quatre
// derives lui sont propres. Rien ne change pour lui, et il n'est pas atteint
// aux crans livres. L'ecume/whitecaps et les rides de pluie ont aussi leur
// propre rythme (frameTimeCounter direct), inchange.
// La liste "// [...]" est RETIREE (meme raison que WAVES_V3 plus bas) : WAVE_SPEED
// n'est plus expose - il n'est ni dans sliders= ni dans aucun screen.* - mais tant
// qu'il portait une liste, Iris continuait de l'ENREGISTRER comme option, donc une
// entree WAVE_SPEED=1.0 heritee d'un ancien fichier de reglages pouvait ecraser
// silencieusement ce defaut. Sans la liste, c'est une constante et rien d'autre.
#define WAVE_SPEED 0.75 // vitesse de l'horloge de surface (constante, plus une option)
// WAVES_V2: coherent directional spectrum (lib/water.glsl) - one dominant
// ANALYTIC Gerstner-lite SWELL (lambda ~26 blocks, fixed wind direction,
// trochoidal profile with tight crests and wide troughs, wave groups) + a
// medium ANISOTROPIC CHOP in wind space (crests elongated perpendicular to the
// wind, 2 trains drifting downwind) + micro capillaries (WATER_MICRONORMAL).
// The final normal is still the SUM, so ripples/foam/glint/whitecaps keep
// working and whitecaps ride the swell crests. Calibrated for
// WATER_NORMAL_STRENGTH 0.75-1.5. 0 = the original choppy-octave sea.
#define WAVES_V2 1 // [0 1]
// Number of swell TRAINS: the first train is full strength, each following one
// heads in another direction (~58 deg plus variation), shorter, weaker (x0.55)
// and faster, giving a rich but readable cross sea. Fronts are NOT parallel
// (domain warp ~9 blocks). The analytic caustics (causticFieldH, lib/water.glsl)
// derive from the SAME trains, so they follow the waves.
// WAVE_ITERATIONS: derived from WAVE_QUALITY (menu axes block, top of this file)
// WAVE_NORMALS_V3 1 = "two smooth layers" water normals: two soft noise
// sheets drifting downwind with ROUND lobes and no choppy profile,
// giving coherent reflections and a smooth surface.
// 0 (default) = the original CHOPPY-OCTAVE generator: two counter-drifting fields
// whose interference keeps transforming (crests are born and dissolve) instead
// of a sheet that merely slides. Displacement, whitecaps and CAUSTICS are the
// same either way.
#define WAVE_NORMALS_V3 0 // [0 1]
// Fast water normals (choppy V2 path, i.e. WAVES_V2=1 + WAVE_NORMALS_V3=0):
// the wind-space transform is hoisted out of the 3 finite-difference chop
// evaluations, and the octave LOD tiers are tightened to the measured
// sub-pixel distances at 1080p (see waveNormalWorldFast, lib/water.glsl).
// 0 = original per-call transform and the legacy 25/142-block tiers.
#define WAVE_FAST_NORMALS 1 // [0 1]

// ---------------- WAVES_V3: FORMED SEA (analytic-gradient noise ladder) -----
// A different sea ENTIRELY, not a variation of v2. Six ridged/plain value-noise
// rungs on a Pierson-Moskowitz amplitude ladder, each one squeezed into a long
// crest by an anisotropic sampling transform, each propagating at its OWN
// deep-water phase speed. The normal is the EXACT derivative of that sum
// (vnoiseD), never a finite difference, and it is crushed toward vertical as
// the view goes grazing so the far sea becomes a clean mirror.
// 0 = the v2 sea above, bit for bit (nothing of v3 is compiled).
// Every number below is either a physical relation or a measurement taken on
// THIS field; the criterion sits next to each one in lib/water.glsl.
// ### FIGE PAR LA PASSE "MENUS2" - PLUS AUCUN CONTROLE EN JEU, VALEUR DEFINITIVE 1.
// Raison : c'est un NUMERO DE VERSION du moteur de vagues, pas un gout. Le v3 EST
// la mer du pack (moins chere que le v2, normales analytiques exactes, mer
// lointaine en miroir) ; le v2 ne survit que comme reference historique dans le
// code. Le "// [0 1]" est retire pour qu'Iris cesse de l'annoncer comme option :
// un nom qui n'est plus une option ne peut plus etre epingle par une vieille
// config. Repasser a 0 (= la mer v2) se fait A LA MAIN, ici, en connaissance de
// cause : cela reveille aussi WATER_DISPLACEMENT, mort sous v3.
#define WAVES_V3 1 // FIGE : moteur de vagues du pack
// ---- WAVE_LOD (HORS MENU) : niveau de detail des vagues par DISTANCE.
// CONSTAT : le moteur v3 evalue ses WAVE3_SCALES barreaux A TOUTE DISTANCE,
// alors que ce meme fichier documente et mesure que la mer lointaine est
// ecrasee vers le miroir (inclinaison retenue 50 % a 25 blocs, 19 % a 100,
// 4 % a 500) et que les barreaux dont le pas de crete est passe sous deux
// empreintes de pixel ne peuvent plus QUE crenerer. On payait donc un
// bruit+gradient par barreau pour un signal invisible - et bruyant.
// Le chemin "choppy" v2 avait deja ce LOD (paliers 4/3/2/1 octaves,
// waveNormalWorldFast) ; v3, devenu le moteur par defaut, ne l'a jamais eu.
// CRITERE, celui du fichier lui-meme : garder le barreau i tant que sa
// longueur d'onde livree reste >= WAVE_LOD_K empreintes de pixel. A 1080p et
// 70 deg de champ, une empreinte vaut d/771 blocs, d'ou d <= (771/K)*lambda_i,
// et lambda_i = 1.24 * W3_LADDER_TOP * WAVE3_PEAK_LEN / 2^i (le 1.24 est
// l'etirement W3_LQ deja documente). Aux defauts : 6 barreaux sous ~96 blocs,
// 5 jusqu'a ~191, 4 jusqu'a ~382, 3 jusqu'a ~765, 2 au-dela. Le calcul suit
// WAVE3_PEAK_LEN automatiquement (un seul log2 par pixel, pas de palier fige).
// Plancher a 2 barreaux : la houle porteuse et sa premiere harmonique sont la
// FORME de la mer, jamais du detail - elles ne se coupent pas.
// Calibre a 1080p, comme les paliers du chemin choppy (meme precedent assume).
// GAIN MESURE, PONDERE PAR LA DENSITE DE PIXELS (h/s^2 : la mer proche occupe
// l'ecrasante majorite de l'ecran - la lecon PERF_OCEAN de ce projet, ou un
// gain non pondere avait ete surevalue 5-8x). Part du cout des NORMALES DE
// VAGUE economisee, a K = 2 : **0.9 % au bord de l'eau, 4.4 % sur une falaise,
// 18.2 % en vol**. A K = 3 : 1.4 / 6.9 / 28.3 %. C'est donc un gain MODESTE en
// vitesse au sol, reel seulement en hauteur ; son autre benefice, lui non
// conditionnel, est la STABILITE : les barreaux supprimes sont exactement ceux
// qui ne pouvaient plus que scintiller sous TAA.
// 0 = tous les barreaux a toute distance (comportement actuel).
#define WAVE_LOD 1 // LOD des vagues par distance (0 = tous les barreaux partout)
// Empreintes de pixel sous lesquelles un barreau ne fait plus que crenerer.
// PLUS HAUT = coupe plus tot (plus rapide, mer lointaine plus lisse).
#define WAVE_LOD_K 2.0 // seuil d'anti-crenelage, en empreintes de pixel
// Number of rungs, coarsest to finest. Each rung halves the crest spacing, so
// the field spans a factor 2^(N-1): 6 rungs = 6.4 down to 0.20 block at the
// default swell length. Cost is one noise+gradient fetch per rung per pixel.
// WAVE3_SCALES : derive de WAVE_QUALITY (bloc AXES DE MENU, haut de ce fichier)
// Swell length: the Pierson-Moskowitz PEAK wavelength, in blocks. The whole
// ladder is anchored to it (rung 0 = 1.6 x this value), so raising it stretches
// the entire sea. 4.0 puts the two dominant rungs at a MEASURED crest pitch
// (zero-crossing spacing along the crest normal) of 6.8 and 3.4 blocks - the
// "3-to-7 block ripple trame" the look calls for.
#define WAVE3_PEAK_LEN 4.0 // [1.5 2.0 3.0 4.0 5.5 7.0 9.0 12.0 16.0]
// Steepness (crest-to-trough / wavelength) of the equilibrium range. MEASURED
// on the field: 0.026 gives 0.127 block of visible peak-to-trough and a normal
// tilt of 4.6 deg mean / 8.5 deg at p90 - a gentle but very detailed sea.
// It does NOT move the whitecap or displacement thresholds (see wave3Height).
#define WAVE3_STEEP 0.026 // [0.008 0.013 0.018 0.022 0.026 0.032 0.040 0.055 0.075]
// Crest elongation of the coarsest rung (finer rungs taper off it). MEASURED
// aspect delivered at 5.5: 6.2 and 4.9 on the two dominant rungs, 3.0 on the
// finest - real crest LINES instead of round bumps. 1.0 = isotropic gravel.
#define WAVE3_ANISO 5.5 // [1.0 2.0 3.0 4.0 5.5 7.0 9.0 12.0]
// Crest-normal offset from the wind axis, in degrees, ALTERNATING sign from one
// rung to the next: successive trains cross at twice this angle, which is what
// makes a crossed sea with soft diamond interference instead of a grid.
#define WAVE3_SPREAD 20.0 // [0.0 8.0 14.0 20.0 27.0 35.0 45.0]
// How many of the COARSEST rungs get the ridge fold (straight flanks, marked
// crest, wide troughs - the asymmetric profile of a real gravity wave).
// 0 = smooth noise everywhere (rounder, softer sea).
#define WAVE3_RIDGE 2 // [0 1 2 3 4]
// Grazing-angle flattening: the tilt kept is (1+K)*cos(view)/(cos(view)+K), a
// 1/distance attenuation whose half-point sits at eye*(1+2K)/K. THE most
// important dial for the look - it turns the far sea into a mirror with a
// clean horizon and a tight sun-glitter path. 0.085 is derived from the pixel
// footprint (see W3_FLAT_NOTE in lib/water.glsl); 0 = far sea keeps rolling
// and shimmering like v2.
#define WAVE3_FLATTEN 0.085 // [0.0 0.02 0.04 0.06 0.085 0.12 0.18 0.30 0.50]
// Parallax occlusion steps on the near water. The geometry stays perfectly
// flat; the crests occlude the troughs and stretch in perspective. Runs only
// where the flattening still keeps more than half the tilt (~25 blocks at the
// default), fading out over the last few blocks so the edge is not a visible
// ring; it costs nothing on the far sea. 0 = off.
// WAVE3_PARALLAX : derive de WAVE_QUALITY (bloc AXES DE MENU, haut de ce fichier)

// Dominant swell amplitude (crest ~+0.6 block at 1.0). 0.0 disables the swell
// and leaves only the anisotropic chop.
#define SWELL_AMOUNT 0.75 // [0.0 0.5 0.75 1.0 1.5 2.0]
// Wind direction in degrees (swell AND chop are aligned; 0 = east, 90 = south).
#define WIND_DIRECTION 25.0 // [0.0 25.0 45.0 70.0 90.0 115.0 135.0 160.0 180.0 205.0 225.0 250.0 270.0 295.0 315.0 340.0]
// Vertex displacement of the water surface. WAVES_V2 ONLY: v3 draws a strictly
// flat quad on purpose (its sampling plane is wpos.xz - wpos.y, so a vertical
// offset would shear the field with its own coarse height), and skips this.
// ### FIGE PAR LA PASSE "MENUS2" - PLUS AUCUN CONTROLE EN JEU, RESTE DEFINI.
// Raison : son unique site d'usage est gbuffers_water.vsh, sous "#if WAVES_V3 ==
// 0". WAVES_V3 etant desormais fige a 1, ce reglage est un NO-OP TOTAL : le
// laisser au menu, c'etait offrir au createur un interrupteur qui ne change
// strictement rien a l'image. Il redevient vivant si et seulement si WAVES_V3
// repasse a 0 a la main ci-dessus. Il reste un "#define" nu, donc Iris continue
// de l'enregistrer comme booleen cache - c'est sans effet tant qu'aucun ecran ne
// le nomme, et la config live ne le mentionne pas.
#define WATER_DISPLACEMENT
#define SSR_ENABLED
// SSR fast march: clip(p) is AFFINE in p, so each march step and each binary
// refinement midpoint reuses incremental clip-space values instead of a full
// mat4 multiply (same step count, growth and hit validation; result identical
// up to float rounding). 0 = original per-step projection.
// SSR_FAST : constante 1, PAS un palier. Il ne change pas le schema de marche,
// seulement le cout par pas (resultat identique a l'arrondi flottant pres). Il
// est pose une seule fois dans le bloc REFLECT_QUALITY en tete de ce fichier,
// HORS de la chaine #if. Ne jamais le rebrancher sur un axe.

// ================= SSR REFLECTION ENGINE (composite1 ssrRay) =================
// The five blocks below are INDEPENDENT gates. Every one of them is
// BIT-IDENTICAL to the previous engine at 0, so any of them can be isolated in
// game. They are listed in the order they were derived, which is also their
// gain/effort order.
//
// --- A5: the raymarch budget is a REAL dial now ---
// It used to be hard-wired to 48 steps / 6 bisections inside ssrRay while the
// menu exposed REFLECTION_STEPS, which only ever drove the (disabled) voxel
// path of composite5. 48 and 6 are the legacy values: the defaults reproduce
// the old march exactly.
// MEASURED reach with SSR_STEP_V2 = 1 at 1920x1080 (first step 4 px, growth
// x1.22, cap diag/28 = 78.7 px), expressed in SCREEN DIAGONALS:
//   16 -> 0.19   24 -> 0.48   32 -> 0.76   36 -> 0.90
//   40 -> 1.05   48 -> 1.33 (default)      64 -> 1.90
// 40 is therefore the cheapest value that still crosses the whole frame, and
// anything under 36 cuts long reflections short. Bounded steps never jump OVER
// geometry, which the unbounded ones did from step ~10 onward, so a lower count
// here is not the same trade as before.
//
// COST, and it is NOT the static instruction count. Bounding the step in pixels
// keeps the ray ON SCREEN, so the loop now runs to its budget instead of
// walking out of the frustum after a handful of unbounded steps. Iterations
// actually EXECUTED before the ray leaves the frame (traversal of a screen
// diagonal, FOV 70, TAAU 0.66):
//   surface at   5 blocks: legacy 10 -> bounded 37   (x3.7)
//   surface at  10 blocks: legacy 14 -> bounded 37   (x2.6)
//   surface at  20 blocks: legacy 17 -> bounded 37   (x2.2)
//   surface at  50 blocks: legacy 21 -> bounded 37   (x1.8)
//   surface at 100 blocks: legacy 25 -> bounded 37   (x1.5)
// One iteration is one depthtex0 tap and the march is fetch-bound, so that
// ratio IS the cost ratio of a ray that finds nothing. Multiply it by the rays
// a pixel actually casts: opaque glossy up to PBR_ROUGH_TAPS, water 1 (2 when
// the rain roughness pushes the jitter past 0.01), glass 1 (2 when frosted).
// The DEFAULT is therefore 40, not 48: 1.05 screen diagonals of reach against
// 1.33, for 8 fewer taps on every one of those rays. Raise it to 48-64 if long
// grazing reflections matter more than frame time on your machine.
// SSR_STEPS : derive de REFLECT_QUALITY (bloc AXES DE MENU, haut de ce fichier)
// Binary refinements applied to the bracketing interval once a crossing is
// found. The residual interval is stepLen / 2^SSR_REFINE.
// SSR_REFINE : derive de REFLECT_QUALITY (bloc AXES DE MENU, haut de ce fichier)

// --- A1: intersection test (relative tolerance + thickness + backface) ---
// 0 = the legacy window, |dz| <= 1.0 + 0.04 * distance: 1 block ABSOLUTE plus
// 4%, i.e. an essentially absolute window where every comparable pack uses a
// relative one (iterationT 20%, Bliss 15%, Complementary 1 + 20%, BSL 1.0-2.2 x
// the current step). And when the window fails the code does NOT abort, it
// keeps marching BEHIND the object it just crossed and can validate a surface
// that is not visible from the reflecting point at all -- reflections "through"
// walls.
// MEASURED on our own march (start 0.5, growth 1.22, 6 bisections), window vs
// V2 window at the same iteration:
//   i= 0  d=  0.5 blk  legacy 1.02  v2 0.15   (v2 is 6.8x TIGHTER up close)
//   i= 5  d=  5.2 blk  legacy 1.21  v2 0.63   (x0.52)
//   i=18  d= 97.1 blk  legacy 4.89  v2 11.66  (x2.39)
//   i=25  d=397.6 blk  legacy 16.90 v2 47.71  (x2.82)
// So V2 is not "looser everywhere": it is much tighter near the camera (less
// smearing onto the wrong surface) and 2.4 to 3x wider past ~90 blocks, which
// is where the far hits were being thrown away.
// HONEST CORRECTION to the brief that motivated this: the claim that past ~25
// iterations the residual bisection interval (stepLen / 64) EXCEEDS the legacy
// window, making validation structurally impossible, does NOT hold on this
// march. Measured at i=25: residual 1.13 blk against a window of 16.90 blk; at
// i=47, 89.5 against 1271. With geometric growth the cumulative distance is
// ~5.5 x the step, so the window (4% of it) is always ~14x the residual. The
// residual floor below is kept as a guarantee (it costs one max) but it never
// binds at the default SSR_REFINE. The far-SSR failure came from the ABSOLUTE
// window at distance and from tunnelling (see SSR_STEP_V2), not from this.
// 1 = |dz| <= max(SSR_TOL_MIN, SSR_TOL_REL * |z|, half the residual interval),
// plus an explicit thickness model and a backface test.
#define SSR_HIT_V2 1 // [0 1]
// Acceptance window as a FRACTION of the hit's view depth. 0.12 = 12%, between
// Bliss (15%) and Complementary / iterationT (20%) - deliberately on the tight
// side because the thickness term below already covers the "behind" side.
#define SSR_TOL_REL 0.12 // [0.06 0.08 0.10 0.12 0.15 0.20 0.30]
// Absolute floor of that window, in blocks. Derivation: what the window must
// absorb near the camera is the SCENE depth gradient over one texel at the
// refined UV, dz/dpx = z / (f * tan(grazing angle)).
// FOCAL LENGTH USED THROUGHOUT THIS BLOCK: f = (viewHeight/2) / tan(FOV/2), in
// SUB-RECT texels, i.e. scaled by TAAU_RENDER_SCALE. Minecraft's default FOV is
// 70, so at 1080p f = 540 / tan(35 deg) = 771 px at render scale 1.0 and 509 px
// at 0.66. (An earlier revision of this block quoted f = 540 px everywhere,
// which is FOV 90 -- the numbers below are the corrected ones.)
// At 5 blocks and 10 degrees of grazing that gradient is 0.037 block per texel
// at f = 771 and 0.056 at f = 509 -- 0.15 keeps 2.7x to 4x of headroom while
// staying far under the legacy 1.0 block of slop.
#define SSR_TOL_MIN 0.15 // [0.05 0.10 0.15 0.25 0.40]
// Presumed thickness of what the ray crossed, as a multiplier on
// max(0.5 block, 5% of the distance). A refined point BEHIND the visible
// surface by less than this is INSIDE the object -> hit. Behind by more -> the
// ray passed behind it -> keep marching (the legacy code did that in both
// cases, which is defect 1b).
// CROSSOVER, measured: the back window is max(tolerance, thickness), so this
// dial only changes anything where SSR_THICK * 0.05 * z beats SSR_TOL_REL * z,
// i.e. above SSR_THICK = SSR_TOL_REL / 0.05 = 2.4 at the default tolerance -
// plus, at any setting, within ~4 blocks of the camera where the 0.5-block floor
// wins over the 0.15-block tolerance floor. Below 2.4 it is a NEAR-FIELD dial;
// at 3.0 it widens the back window at every distance.
#define SSR_THICK 1.0 // [0.5 0.75 1.0 1.5 2.0 3.0]
// Reject a hit whose surface turns its BACK to the ray (dot(normal, dir) above
// the threshold). 0.05 instead of 0 so a legitimately grazing hit - where the
// interpolated normal can cross zero by a fraction of a degree - survives.
// 0 = no backface test (costs one colortex1 tap per accepted hit).
#define SSR_BACKFACE 1 // [0 1]
#define SSR_BACKFACE_TOL 0.05 // [0.0 0.02 0.05 0.10 0.20]
// REMOVED (no replacement dial): a "front rejection" that dropped any hit closer
// to the CAMERA than the reflecting surface. The property it claimed to enforce
// -- a reflection cannot come from in front of the mirror -- is about the
// MIRROR's half-space, not the camera's, and it is already guaranteed by
// construction: every point of the ray satisfies dot(p - origin, normal) > 0
// because the ray IS the reflected direction. What the test actually measured
// was camera distance, so it threw away correct reflections on every mirror
// whose normal is not vertical (a polished iron wall at 20 blocks reflecting a
// post at 14 was rejected outright), and it bit on water too: below 45 degrees
// of incidence the reflected ray first moves TOWARD the camera (at 30 degrees
// its closest approach is 0.87 x the surface distance). It was also a hard
// binary rejection in the middle of the march, i.e. a visible hard edge inside
// the reflection rather than a fade. The guard against a false hit on a nearby
// occluder is the thickness model above (behind <= ssrThick), which is the test
// that actually expresses it.

// --- A2: the fallback is never black, and a reflection never darkens ---
// 0 = legacy: every branch uses sky * skyl as its miss fallback, and skyl is
// EXACTLY 0 in a cave, in the Nether and in the End, so a missed ray multiplies
// the surface by (1 - amt) - down to x0.10 on polished metal. That is the whole
// "metals are black underground" report.
// 1 = the miss falls back to a local ambient estimate, and the composition
// carries a no-darkening clause.
// SCOPE on the OPAQUE branch: at RT_REFLECT_MODE 0 (pure voxel RT) that branch
// already multiplies its composition weight by the ray confidence, so a miss
// contributes nothing at all and there is nothing for this gate to floor. It is
// therefore INERT on metals at mode 0 and active from mode 1 up. The water and
// glass branches are unaffected by RT_REFLECT_MODE.
#define SSR_FALLBACK_V2 1 // [0 1]
// Strength of the local ambient fallback: half the pixel's ambient light, half
// the pixel's own outgoing radiance (which already carries block light), scaled
// by this. 0 = no floor (legacy black).
#define SSR_AMB_FLOOR 0.35 // [0.0 0.15 0.25 0.35 0.50 0.75 1.0]
// Outdoor no-darkening floor: the composed pixel keeps at least this fraction
// of its own colour where the reflection is darker. INDOORS (skylight 0) the
// factor is forced to 1.0 - the fallback there is an estimate, so it is not
// allowed to darken the surface at all.
// CONFIDENCE-WEIGHTED, exactly like the ambient floor it sits next to: the
// clause is scaled by (1 - ray confidence), so it is at full strength on a MISS
// (where the reflection really is a guess and must not darken anything) and
// vanishes on a CONFIDENT hit. Without that weighting a polished metal
// reflecting a shaded corner could never show anything below 40% of its own
// diffuse colour outdoors - a permanent bright veil on the very material this
// gate is supposed to fix.
#define SSR_NO_DARKEN 0.40 // [0.0 0.20 0.30 0.40 0.50 0.70 1.0]

// --- G3: what a MISSED reflection ray is allowed to paint ---
// REFLECT_GROUND_FB. The miss fallback of every reflection branch is
// getSkyAll(reflected direction), and that call only means something for a ray
// that LEAVES the world. lib/sky.glsl builds its gradient from
//     horiz = pow(1.0 - clamp(dir.y, 0.0, 1.0), 3.0)
// so for dir.y <= 0 the clamp pins horiz at exactly 1.0 and the WHOLE lower
// hemisphere is painted the pure horizon colour, flat, with no gradient at all.
// Evaluated on the shipped constants at noon (SKY_HORIZON_LIFT 1.0, SKY_TINT
// 1.0): dayHor (0.62, 0.80, 0.98) x 1.22 = (0.757, 0.976, 1.196), luma 0.93 --
// a MILKY WHITE PLATE, and it is the BRIGHTEST value that gradient can produce
// at any elevation.
// A vertical pane mirrors ELEVATION exactly (reflect() about a horizontal
// normal leaves dir.y unchanged), so one pane shows three things stacked in
// screen order: real sky above the horizon line, real SSR geometry for the
// steeper downward rays that stay on screen, and that white plate in the
// grazing band in between, where the screen ray leaves the frame and misses.
// The "bande claire horizontale nette a la hauteur de l'horizon" and the
// "plaque blanche laiteuse" of the report are ONE defect, not two.
// PHYSICS. A downward ray sees the GROUND, whose radiance is its albedo times
// the irradiance it receives, i.e. a FRACTION of the horizon sky: ~0.13 for
// grass, ~0.20 for sand, ~0.06 for water at normal incidence. The shipped
// fallback is therefore 5x to 15x too bright below the horizon.
// The replacement is this file's own ssrLocalAmb recipe (half the pixel
// ambient, half the pixel's outgoing radiance, x SSR_AMB_FLOOR): no new
// constant is invented, SSR_AMB_FLOOR (0.35) already sits inside the albedo
// range above and is already the term the pack trusts for "the radiance
// leaving the surroundings of this pixel".
// SCOPE: the GLASS pane branch, which is where a reflected ray routinely
// points below the horizon. The opaque PBR branch has the same fallback and
// the same fault on vertical polished surfaces; it is NOT covered here (its
// sky term is split over six call sites across two roughness models).
// 0 = legacy (sky fallback below the horizon too).
#define REFLECT_GROUND_FB 1 // [0 1]
// SUN_MIRROR_SHADOW. WATER_GLINT_SHADOW masks the surface's OWN sun lobe, but
// the REFLECTED SKY carries a SECOND copy of the sun: lib/sky.glsl adds
// celestialDisc x25 (analytic dome) / x40 (PHYSICAL_SKY) inside getSkyAll, and
// skyReflect reads that same disc back out of colortex0 on its screen tap.
// Nothing masked that copy, so water in the shade of a cliff still showed the
// mirror image of the sun -- the reported "on voit le reflet du soleil alors
// qu'on est a l'ombre", arriving through the one door WATER_GLINT_SHADOW's own
// comment says it does not touch.
// PHYSICS. A mirror in shadow does NOT show the sun: the occluder that blocks
// the sun from that point is exactly what the mirror direction toward the sun
// runs into, so the disc is replaced by the occluder, not kept. The DIFFUSE
// dome is the opposite case -- it arrives from every direction and is only
// partly blocked -- so it must stay, and it does: ONLY the solar / lunar DISC
// is extinguished, by the same visibility the diffuse term uses.
// CONE = the SAME celestialDisc the sky draws, radius x1.5. Criterion: the
// disc's own rim already spans [0.90 .. 1.00] of its radius, and the
// horizon-refraction term inside celestialDisc grows that radius by up to
// x1.30, so x1.5 covers the widest disc the dome can draw plus its full rim
// and nothing else (SUN_SIZE 0.04 -> 2.3 deg, x1.5 -> 3.4 deg). The sun GLOW
// (pow(dot(dir,sunDir), 8), half-width ~23 deg) is SCATTERED SKY LIGHT and not
// the disc, so it is deliberately left alone.
// SITES: the water sky reflection (PCF penumbra, squared -- the specular
// follows the VISIBLE FRACTION of the disc, same law as WATER_GLINT_SHADOW),
// the glass pane reflection and the pane's own Blinn lobe, the wet-ground
// glint, and the opaque PBR reflection (the last three take one binary
// shadowtex1 tap, paid only on the pixels that actually mirror the disc).
// 0 = legacy.
#define SUN_MIRROR_SHADOW 1 // [0 1]

// --- A4: usable screen area ---
// 0 = legacy: smoothstep(1.0, 0.70) on max(|ndc.x|, |ndc.y|), i.e. the outer
// 15% of each half-width is faded and already half gone at 7.5% from the edge -
// roughly 30% of the screen area loses its reflected content - plus a hard
// abort at |ndc| = 1 and an ITERATION-indexed fade that kills exactly the
// distant hits.
// 1 = overscan + a border fade expressed as a BAND WIDTH IN PIXELS + a
// travel-based range fade.
// WHY PIXELS. A seam at the border of the frame is a screen artefact: what
// decides whether the eye sees it is how many PIXELS wide the transition is,
// not what fraction of NDC it covers. An exponent on |ndc| is neither: the same
// exponent is a different physical width on the x axis and on the y axis (the
// aspect ratio), a different width again at another render scale, and a
// different width again at another FOV. So the fade here is a plain smoothstep
// over a band measured in SUB-RECT PIXELS from the nearest border, evaluated
// per axis and taken at its minimum.
// MEASURED (1600x1600 sampling of the frame, edge weight only, contrast 0):
//   mean weight over the whole frame  legacy 0.727 -> 1.000 (TAAU 1.0),
//                                                     0.9999 (TAAU 0.66)
//   against 0.973 for the previous exponent-based revision of this gate.
//   |ndc| 0.80  legacy 0.741  now 1.000
//   |ndc| 0.85  legacy 0.500  now 1.000   <- legacy is already half gone here
//   |ndc| 0.90  legacy 0.259  now 1.000
//   |ndc| 0.95  legacy 0.074  now 1.000
//   |ndc| 0.98  legacy 0.013  now 1.000
//   |ndc| 1.00  legacy 0.000  now 0.935   <- overscan band starts
//   |ndc| 1.03  legacy 0.000  now 0.000
// (short axis, 1920x1080 at TAAU 0.66 -- the tightest case; the long axis keeps
// even more.)
#define SSR_EDGE_V2 1 // [0 1]
// How far outside the frame the march may still validate a hit. The depth tap
// is clamped to the frame there, so such a hit is a one-texel extrapolation:
// keep it small.
#define SSR_OVERSCAN 0.03 // [0.0 0.015 0.03 0.05 0.08]
// GEOMETRIC border band, in SUB-RECT PIXELS: a hit closer than this to the
// nearest frame border is cross-faded out over that band.
// DERIVATION. This band exists for ONE reason: a depth tap taken past the
// border is clamped back to the border, so a hit validated out there rests on
// an extrapolated depth. The band therefore only has to be wide enough to hide
// the moment the extrapolation starts, which is one refinement interval of the
// march projected on screen -- SSR_STEP0_PIX (4 px) plus the residual of the
// bisection, i.e. under 8 px. 12 px is that with 50% of margin, and the
// MEASURED cost of it is nil: mean edge weight 1.0000 at TAAU 1.0 and 0.9999
// at 0.66 (the whole band lives in the last 1.5% of each half-width).
#define SSR_EDGE_PX 12.0 // [4.0 6.0 8.0 12.0 16.0 24.0 32.0]
// CONTRAST widening of that band, in additional pixels at full contrast.
// DERIVATION. The band above hides the extrapolation; it does not hide the
// SEAM, and what makes a seam visible is not how bright the reflection is in
// absolute terms but how far it steps away from the pixel it is covering. So
// the band is widened in proportion to the Michelson contrast of that step,
// c = |L(hit) - L(surface)| / (L(hit) + L(surface)): 0 when the reflection
// matches its surroundings (there is no seam to hide, and nothing is removed),
// 1 for a full black-on-white step. 24 px triples the band at c = 1, which is
// the width at which a one-frame step of that amplitude stops being resolvable
// against the TAA history at 1080p. Water branch only (that is where a
// screen-border seam sits on a large, moving, near-uniform surface).
// 0 = off, band stays at SSR_EDGE_PX everywhere.
// MEASURED weight at the border, short axis, 1920x1080 TAAU 0.66:
//   |ndc| 0.95   c=0 1.000   c=0.5 1.000   c=1 0.888
//   |ndc| 0.98   c=0 1.000   c=0.5 0.835   c=1 0.493
//   |ndc| 1.00   c=0 0.935   c=0.5 0.405   c=1 0.205
// A reflection that blends into its surroundings keeps 94% of itself right at
// the border where a hard-contrast one keeps 21%: the seam disappears on
// exactly the pixels where it would have been visible, and stays where it would
// not. Mean weight over the frame at c = 1: 0.973.
#define SSR_EDGE_CTR_PX 24.0 // [0.0 8.0 16.0 24.0 40.0 64.0]
// Range fade, as a multiple of the render distance, applied to the ray's TRAVEL
// length instead of its iteration index. The legacy iteration fade (38 -> 48)
// removed precisely the far hits.
// TWO CORRECTIONS to the first revision of this fade. (1) It is applied to
// (travel - the surface's own view depth), not to travel: a ray that STARTS far
// from the camera has already "travelled" that far before it moves at all, and
// charging it for that penalised the exact case this engine exists for -- water
// at 20 blocks reaching for the mountain on the far shore lost 47% of its
// reflection at a 192-block render distance, and 66% at 512. Subtracting the
// origin depth makes the fade measure the ray's own excursion. (2) The default
// is 2.0, not 1.0: at 1.0 the fade started biting inside the render distance,
// i.e. on hits that are on screen and perfectly reliable. At 2.0 it is what it
// was meant to be, a safety net on runaway grazing rays, and the same two cases
// above keep 1.00.
#define SSR_RANGE 2.0 // [0.5 0.75 1.0 1.5 2.0 3.0 4.0]

// --- A3: start offset and screen-space step bounding ---
// 0 = legacy: start at origin + dir * (0.25 + dither * 0.25) - a FIXED 0.25-0.5
// block along the RAY, which barely leaves the surface at grazing incidence -
// then stepLen 0.5 block growing x1.22, with nothing expressed in pixels. At 5
// blocks the first step is ~90 px (no contact reflections at all); by step 20
// it is 23 blocks / >4000 px (a pole or a tree trunk falls between two samples
// and is never reflected).
// 1 = offset along the NORMAL, proportional to distance, and every step clamped
// in PIXELS.
// MEASURED legacy step size in pixels (1920x1080 at render scale 1.0, FOV 70 so
// f = 771 px, ray across the view axis):
//   at  5 blocks: step0  77 px, step10 564 px, step20 4128 px
//   at 20 blocks: step0  19 px, step10 141 px, step20 1032 px
//   at 50 blocks: step0   8 px, step10  56 px, step20  413 px
// A 1032 px step at 20 blocks is the tunnelling: a 1-block pole is ~39 px wide
// there, so it is stepped over 26 times out of 27. With the bound, no step ever
// exceeds 78.7 px and the early ones are 4-9 px.
// (At FOV 90, f = 540 px, every figure in that table is 30% smaller. The
// conclusion does not move; an earlier revision of this block quoted the FOV 90
// numbers as if they were the default.)
// MEASURED clearance from the surface at the start (how far the first sample
// sits off the plane), with the pixel-sized offset below:
//   grazing angle  2 deg: legacy 0.013 blk   now 0.05 / 0.10 / 0.31 blk at 5 / 20 / 60 blocks
//   grazing angle 10 deg: legacy 0.065 blk   (same figures - the offset is along the normal,
//   grazing angle 90 deg: legacy 0.375 blk    so it does not depend on the incidence)
// 0.013 block of clearance is the self-hit acne the "water within 2 blocks"
// hack was papering over.
#define SSR_STEP_V2 1 // [0 1]
// Start offset along the surface normal, in SCREEN PIXELS of the reflecting
// surface, floored at 0.05 block near the camera.
// DERIVATION. The offset only has to lift the first sample clear of the
// surface's own depth texel, and the world size of a texel at view depth z is
// z / f -- so the honest unit for this dial is the texel, not the block and not
// a fraction of z. Written that way the offset projects to a CONSTANT number of
// pixels at every distance, which is the property that matters: the reflection
// of a contact point is displaced by SSR_START_PX pixels and by no more,
// wherever the contact point is.
// 4.0 = the length of the first step (SSR_STEP0_PIX), i.e. the offset moves the
// origin by exactly one step and never by a fraction of the march.
// WHAT THIS REPLACED, and why: the offset used to be a flat 2% of the view
// distance, which projects to 0.02 * f = 15 px at FOV 70 -- almost four first
// steps, and 0.4 block of world displacement at 20 blocks. Contact reflections,
// which are the whole point of the 4 px first step, were detaching from their
// object by that much before the march even began.
#define SSR_START_PX 4.0 // [1.0 2.0 3.0 4.0 6.0 10.0 16.0]
// Length of the FIRST step, in pixels. This is what buys contact reflections:
// the legacy fixed 0.5 block is 54 px at 5 blocks and 5 px at 50.
#define SSR_STEP0_PIX 4.0 // [1.5 2.0 3.0 4.0 6.0 8.0 12.0]
// Lower clamp on every step, in pixels: below the sampling resolution a step
// only costs a tap.
#define SSR_PIX_MIN 1.5 // [0.75 1.0 1.5 2.0 3.0]
// Upper clamp on every step, expressed as SCREEN DIAGONAL / this. 28 gives
// ~79 px at 1920x1080, i.e. 3.6% of the diagonal per step - between Bliss
// (3.3%) and iterationT (6.25%).
#define SSR_PIX_DIV 28.0 // [12.0 16.0 20.0 24.0 28.0 36.0 48.0]
// Second cap on the step, this one RELATIVE TO THE VIEW DEPTH, and it is what
// keeps the horizon working. A pixel cap alone is degenerate for a ray pointing
// nearly along the view axis - grazing water reflecting the horizon is exactly
// that case: the ray barely moves on screen, so the pixel cap authorises a step
// of hundreds of blocks that moves 79 px and skips everything in DEPTH.
// 0.35 = the step never changes the view depth by more than 35%, which is ~3x
// the acceptance window (SSR_TOL_REL 0.12) so a crossing cannot be stepped over
// without at least one sample landing inside the window. By construction the
// depth then grows by at most x1.35 per step, and ln(192)/ln(1.35) = 17.5, so a
// 192-block render distance is still crossed in ~18 steps.
// This cap only takes over from the pixel cap below ~17 degrees off the view
// axis at the default FOV 70 (~25 degrees at FOV 90): the pixel cap allows
// pixMax / ppu = 0.102 z at 90 deg, 0.144 z at 45 deg, 0.298 z at 20 deg
// against this 0.35 z, at f = 771 px - i.e. it takes over exactly on the rays
// that were degenerate.
#define SSR_ZSTEP 0.35 // [0.15 0.25 0.35 0.50 0.75 1.0]
// ============================================================================
// WATER_REFRACTION : OFF PAR DEFAUT depuis la passe "MEN" (demande du createur,
// meme politique que GLASS_REFRACTION/GLASS_DISTORTION : toute refraction est
// livree eteinte). L'option RESTE au menu (ecran Eau, "Refraction de l'eau") :
// la cocher redefinit ce #define et rend le look calibre - c'est pourquoi
// REFRACTION_STRENGTH garde sa valeur 1.0 (une force 0.0 ferait de la case du
// menu un interrupteur mort). A OFF le cout est REELLEMENT nul : l'unique site
// (composite1.fsh "#ifdef WATER_REFRACTION") compile hors l'offset, le clamp,
// le test de separation ET la re-lecture colortex0 - ruv reste uv.
//#define WATER_REFRACTION
#define REFRACTION_STRENGTH 1.0 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0 3.0 5.0 8.0]
#define WATER_CAUSTICS
#define CAUSTIC_STRENGTH 1.0 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0 3.0 5.0 8.0 12.0]
#define CAUSTIC_SCALE 1.0 // [0.1 0.25 0.5 0.75 1.0 1.5 2.0 4.0 8.0]
// Focusing of the PHYSICAL caustics: multiplies the paraxial focal length
// cf = 0.25 * depth (convergence of rays refracted by the REAL wave field).
// Higher = sharper, more contrasted filaments focusing at a shallower depth;
// the focal depth stays EMERGENT, nothing is stamped on.
#define CAUSTIC_FOCUS 1.0 // [0.25 0.5 0.75 1.0 1.5 2.0 3.0]
// NOTE: CAUSTIC_SCALE above is INERT - caustic scale IS the wave scale (the
// pattern is stenciled from the real field). Removed from the menus, the define
// is kept only for .txt profile compatibility.
#define CAUSTIC_SPEED 1.0 // [0.0 0.5 1.0 1.5 2.0 3.0 5.0 8.0]
// Depth at which caustics start defocusing. Keep it low: past ~6 blocks the
// water is opaque enough to hide the bottom, so the blur would be invisible.
#define CAUSTIC_DEPTH_BLUR 3.0 // [1.0 2.0 3.0 4.0 6.0 8.0 12.0 16.0 24.0]
#define CAUSTIC_LARGE_SCALE 0.28 // [0.1 0.15 0.2 0.28 0.4 0.5 0.75 1.0]
#define CAUSTIC_LARGE_STRENGTH 0.6 // [0.0 0.25 0.4 0.6 0.8 1.0 1.5 2.0 3.0]
// ============ CAUSTICS V4 - PHOTON DENSITY NET ============
// 1 = the caustic is MEASURED instead of drawn: 9 photons per pixel leave a
// virtual water surface 1 block above the shaded point, are deflected by the
// local wave slope, fall one block, and the estimator counts how many land
// inside a 0.144-block disc. Closed cells, Y splits, hard cusps and wide dark
// plains between filaments come out on their own - a sum of wave trains
// cannot make any of them. See the header of the CAUSTICS_V4 block in
// lib/water.glsl for the full derivation.
// 0 = the v3 analytic caustics, BIT-IDENTICAL (nothing below is read, and
// every v3 entry point stays compiled) - for A/B comparison in game.
// CAUSTICS_V4 : derive de CAUSTIC_QUALITY (bloc AXES DE MENU, haut de ce fichier)
// 1 = the photon estimator reads THE WAVE FIELD YOU ARE LOOKING AT (WAVES_V3)
// instead of the private four-octave ridge field v4 carried. That was a
// structural defect, not a matter of taste: measured over six sites and three
// times, the correlation between the converged term and the visible surface's
// own -|grad h| was -0.003 +-0.064 under v4 - zero, with a scatter bigger than
// the mean - and is +0.757 +-0.028 under v5. The filaments now run along the
// crest lines, stretch with WAVE3_ANISO and turn with WIND_DIRECTION.
// Everything else is v4's and untouched - the 9 photons, the 0.110 spacing,
// the 0.1439 splat, the affine Jacobian, the Snell slide and the sun
// obliquity - and the cost is the same, because the estimator reads 4 rungs of
// the wave ladder where it used to read 4 octaves of its own.
// Re-derived on the new field by the same method: floor / knee / asymptote are
// the p10 / p90 / p95 of a 24M-photon ground truth, the gain is SOLVED for a
// mean of exactly 1.000, and the exposure budget over the whole dial space is
// -15.1% against -15.5% re-measured for v4 on the same harness. The term also
// gains contrast, from the measurement and not from a knob: dynamic range
// 12.4:1 against 10.1:1, because the wave field's photon density really is
// more bimodal than the ridge field's was.
// PRICE, stated: the caustics now follow the WAVE menu. WAVE3_STEEP is
// normalised out and WAVE3_PEAK_LEN only magnifies the mesh, but WAVE3_ANISO,
// WAVE3_RIDGE and WAVE3_SPREAD move the term's brightness by up to a third at
// their extremes, and WAVE3_SCALES must be >= 4 (default 6) or CA5 loses a
// rung. Under v5, resize the mesh with WAVE3_PEAK_LEN and leave CA4_SCALE at
// 0.5 - see CALIBRATION V5 K in lib/water.glsl.
// 0 = the v4 net, BIT-IDENTICAL. Needs WAVES_V3; with the v3 sea off there is
// no field to read and this falls back to v4 on its own.
// CAUSTICS_V5 : derive de CAUSTIC_QUALITY (bloc AXES DE MENU, haut de ce fichier)
// 1 = the estimator's OUTPUT stops being posterised. v4/v5 answer "all 9
// photons missed" with ONE number, CA_FLOOR, and that is the majority case:
// measured at the shipped constants, 60.9% of pixels per frame and STILL 44.1%
// after 32 TAA frames land on exactly 0.1987, while 84% of the pixels that do
// see a photon are already past the knee. The term is very nearly two-valued
// and its own median IS the floor. The true density on those same pixels runs
// p10 0.150 to p90 1.712 - an interquartile ratio of 3.57 painted flat.
// v6 deletes the floor instead of lowering it: the bottom of the range now
// comes from the splat kernel's own TAIL, evaluated once at the packet centre
// (one reciprocal), which is continuous everywhere and is ordered like the
// truth - measured E[true density | throw] falls monotonically 1.674 -> 0.686
// over the reachable throw. The compressor then moves after the exposure
// divide so its knee and asymptote can be READ OFF the ground truth: the true
// p99.9 and the true maximum, i.e. the map is exactly linear over 99.94% of the
// area AT THE DEFAULTS and rolls off toward the physical peak instead of
// clipping at 2.47. (Measured, and the "99.9%" is a default-setting figure, not
// a whole-space one: the spread of the term grows with the deflection dials, so
// the linear share falls to 92.8% at the worst reachable triple. The exposure
// consequence of that is CALIBRATION V6 K in lib/water.glsl.)
// Result against a 40 M-photon ground truth (v5 -> v6, truth): fraction on the
// exact minimum 0.4365 -> 0.000002 (0); contrast in the dark half 0.209 ->
// 0.517 (0.541); cusp over filament 1.02 -> 2.61 (2.75); top 5% of the area
// carries 12.3% -> 16.0% (15.9%); every quantile within 3.7% of the truth.
// It is also QUIETER, not louder, despite the higher ceiling: the background
// carries no jitter, so the TAA-8 residual falls from 12.2% to 4.5% of the
// term's own spatial spread. Exposure stays exactly 1.000 by construction, and
// the drift of the FINISHED term over the whole dial space IMPROVES, from
// -15.1% to +3.7% / -4.7% (rms 2.8%), the compressor's own de-dependence
// included - CALIBRATION V6 K in lib/water.glsl, which is also where the
// measurement lives.
// Same 9 photons, same field, same noise budget - no new field evaluation.
// 0 = the v5 shaping, BIT-IDENTICAL. Needs CAUSTICS_V5 (every v6 constant is a
// percentile of the WAVES_V3 field's own ground truth); with v5 off this falls
// back on its own.
// CAUSTICS_V6 : derive de CAUSTIC_QUALITY (bloc AXES DE MENU, haut de ce fichier)
// Size of the net cells (the mesh spacing) AND, with it, the width of a single
// filament. Higher = wider mesh and proportionally fatter filaments.
// MEASURED, and it corrects an earlier claim in this file. The two were said
// to be DECOUPLED - "the filaments are 0.20-0.26 block wide at any setting,
// they follow CA4_SHARP only". They are not. Filament width, taken as the FWHM
// of the radial autocorrelation of the dither-converged net (the same
// definition that returns 0.26 block at the default):
//   CA4_SCALE   0.5     1.0     2.0     3.0
//   width      0.253   0.513   1.085   1.685   block
//   width/dial 0.506   0.513   0.542   0.562
// i.e. width ~ 0.51 * CA4_SCALE, LINEAR in this dial, and the ratio does not
// fall off at the low end. The reason is that a filament is the level set
// {|grad h| small}, and that set magnifies with the lattice - the photon
// aperture, which is in absolute blocks, does not follow it.
// The splat kernel is only a FLOOR on the width - its own FWHM is
// 2 * 0.1439 / sqrt(2) = 0.204 block at CA4_SHARP 1 - and the default already
// sits above it (0.253). CA4_SHARP moves that floor; CA4_SCALE moves the level
// set, and over the whole menu range it is the level set that wins.
// CONSEQUENCE FOR THE DEFAULT: at 0.5 the filaments are 25 cm, inside the
// 10-30 cm band this term was designed for - which is why the default is 0.5
// and not 1.0. At 1.0 they are 51 cm, and at 3.0 they are 1.7-block smears,
// which is the multi-block look the term exists to avoid. Treat this dial as a
// scale for the WHOLE pattern.
// The grouping the eye reads follows the two ridged octaves, which carry 82%
// of the slope weight (0.420 at 3.70 * CA4_SCALE and 0.400 at 1.75 *
// CA4_SCALE) -- the fine pair only holds 0.075 and 0.022:
//   1.0 -> half the slope variance above 1.36 block, packet gaps p90 1.25 block
//   0.5 -> half the variance above 0.75 block (re-measured 0.71 on the net
//          itself).
// EXPOSURE IS NOT QUITE UNAFFECTED, which an earlier note here implied it was.
// The volumetric band does hold (18.0 / 17.6 / 18.0 / 17.3% lit at 0.5 / 1 /
// 2 / 3), but the surface net drifts: measured mean 0.993 / 0.977 / 0.956 /
// 0.945 and contrast 0.872 / 0.930 / 0.953 / 0.955 over the same four values.
// Coarser mesh = slightly darker and slightly harder. Floor and ceiling do not
// move at all (0.259..2.611 everywhere).
// Raise it for a coarser, more "swimming pool" net - and expect the filaments
// to coarsen with it.
#define CA4_SCALE 0.5 // [0.5 0.7 0.85 1.0 1.2 1.5 2.0 3.0]
// Filament SHARPNESS: scales the photon splat radius (0.144 block at 1.0,
// about 2.3 px of a 16x block texture) and the photon spacing together, so
// the 1.309 overlap ratio that sets the grain of the estimator is preserved.
// That ratio is DERIVED, not picked: it is the first radius/spacing at which
// an undeflected photon grid sums flat to within 2% RMS (CALIBRATION 4 in
// lib/water.glsl). Higher = thinner, harder lines - measured, same FWHM
// definition as CA4_SCALE above, at CA4_SCALE 0.5:
//   CA4_SHARP  0.5     0.7     1.0     1.5     2.0
//   width     0.334   0.300   0.268   0.226   0.183   block
// so this dial spans 1.8x of filament width against CA4_SCALE's 6.7x: it
// trims the width, CA4_SCALE sets it. Too high and 9 photons stop covering
// the kernel (pointillism).
// NOTE, it is not exposure-free at the ends: CA4_SHARP 0.5 combined with the
// distance defocus is the corner where the renormalisation drifts furthest
// (mean 0.85 against 1.0) - see the drift budget at vlCa4Mean in
// lib/water.glsl. At 0.85 and above the drift stays within 7%.
#define CA4_SHARP 1.0 // [0.5 0.7 0.85 1.0 1.2 1.5 2.0]
// Focusing exaggeration: how far a photon is thrown per unit of wave slope.
// UNDER CAUSTICS_V6 THERE IS NO FLAT FLOOR FOR THIS DIAL TO SIZE. What follows
// describes v4/v5, where the term answered "all 9 photons missed" with one
// number and this dial set how much of the screen got it - and that flat
// majority WAS the posterisation v6 exists to remove, not a feature. Under v6
// the dial still sets the throw, so it still darkens and thins the plains, but
// they stay CONTINUOUS. Measured fraction of the area on the exact minimum,
// TAA-16 over three patches, across this whole slider:
//   CA4_STEEP   0.5    0.7    0.85   1.0    1.25   1.5    2.0
//   v6        0.001% 0.001% 0.001% 0.001% 0.001% 0.001% 0.001%
//   v5        17.2%  28.8%  36.8%  44.9%  54.4%  62.3%  72.0%
// 0.001% is one pixel in 102400, i.e. the single darkest sample and nothing
// else - v6 has NO flat area at any setting of any of the three shaping dials.
// The worst corner of the whole space, CA4_STEEP 2.0 / CA4_SHARP 2.0 / soft 1.0,
// reads 0.002% under v6 against 91.3% under v5.
// This is the single dial that decides how much of the floor is DARK (58.7% at
// 1.0, per frame; 44% once TAA has accumulated 8 frames of jitter, which is
// what you actually see) - v4/v5 ONLY. Higher = larger dark plains, brighter
// and rarer filaments. The term is
// renormalised on its own mean, so this dial is very nearly exposure-free -
// measured 0.985..1.040 across its whole range at the other defaults, NOT
// exactly neutral. The renormalisation is a fit, not an identity; its full
// measured drift budget is written at vlCa4Mean in lib/water.glsl.
// Of the three shaping dials this is the one that is a matter of TASTE: no
// threshold picks 1.0, only the measured consequence above is documented.
#define CA4_STEEP 1.0 // [0.5 0.7 0.85 1.0 1.25 1.5 2.0]
// Contrast of the net around 1.0 (the term multiplies the pixel's composed
// lighting, so 1.0 is "no caustic"). At 1.0 the measured range is 0.26..2.61 with the camera
// SUBMERGED (10.1:1) and 0.46..2.18 seen from outside (4.8:1) - the compression
// from outside is not taste either: it is the contrast the wavy interface has
// already blurred away before the eye sees it, measured on this field
// (CALIBRATION 8). 0.0 mutes the net (the term becomes a constant 1.0).
#define CA4_CONTRAST 1.0 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 2.0]
// Animation trim of the net, on top of CAUSTIC_SPEED. The four octaves drift
// on their own vectors at 0.06 to 0.28 block/s, some against the others, so
// the filaments breathe instead of scrolling and never loop.
#define CA4_SPEED 1.0 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0 3.0]
// Caustics on VERTICAL faces (pool walls). The lookup slides with altitude,
// so a wall gets the same net sheared along the sun azimuth - which is what
// real pool walls look like. v3 had to mute vertical faces entirely (its
// finer pattern moired under TAA); the net is coarse enough to survive, so
// this is a dial. 0.0 = v3 behaviour (floors only), 1.0 = walls as strong as
// floors.
#define CA4_WALL 0.75 // [0.0 0.25 0.5 0.75 1.0]
// All foam is OFF by default. WATER_FOAM (ecume des bords) se reallume depuis
// l'ecran Eau ; les deux suivants sont figes (voir leurs blocs).
//#define WATER_FOAM
// ### FIGE PAR LA PASSE "MEN" - PLUS AUCUN CONTROLE EN JEU, RESTE //#define (OFF).
// Raison : les moutons d'ecume ("Moutons d'ecume", ex-ecran Eau) sont OFF
// depuis EAU8 et le createur ne les rallume jamais - la case sort du menu.
// Reallumer = decommenter A LA MAIN (site unique : composite1.fsh "#ifdef
// WHITECAPS"; FOAM_AMOUNT / WHITECAP_NEAR_FADE plus bas restent ses dials).
// Booleen nu : Iris continue de l'enregistrer comme booleen cache (meme statut
// que WATER_DISPLACEMENT) - sans effet tant qu'aucun ecran ne le nomme, et la
// config live ne le mentionne pas.
//#define WHITECAPS
// ### FIGE PAR LA PASSE "MEN" - PLUS AUCUN CONTROLE EN JEU, RESTE //#define (OFF).
// Raison : les rides dynamiques ("Rides dynamiques", ex-ecran Eau : anneaux de
// plongeon, sillage, impacts de pluie) sont OFF par defaut et jugees
// anecdotiques au menu. Reallumer = decommenter A LA MAIN (sites :
// gbuffers_water.fsh "#ifdef WATER_RIPPLES" x3 ; les dials RIPPLE_* et
// RIPPLES_V5 ci-dessous restent vivants pour ce cas). Meme statut de booleen
// cache que WHITECAPS ci-dessus.
//#define WATER_RIPPLES
// RIPPLES - (a) water entry/exit impulse: ONE expanding, damped ring driven by two custom
// Iris smooth() uniforms (ids 41/42, shaders.properties); (b) a discreet Kelvin-V swim wake
// behind the motion (speed from previousCameraPosition/frameTime); (c) rain impact rings
// under open sky. All of it is NORMAL DEFORMATION - no painted circles.
// Exposed in the WATER menu: dive/surface ring, wake + lapping (including at rest), rain
// impacts. 0.0 mutes a component and falls back to waves alone. Ripple slopes also follow
// WATER_NORMAL_STRENGTH so they stay consistent with the swell.
#define RIPPLE_WAKE_STRENGTH 1.0 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0 3.0]
#define RIPPLE_SPLASH_STRENGTH 1.0 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0 3.0]
#define RIPPLE_RAIN_STRENGTH 1.0 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0 3.0]
// Camera-biome gate on rain effects (rings + wet ground): Iris >= 1.6.1 provides the
// built-in uniform int biome_precipitation (0 none, 1 rain, 2 snow). 1 = no rain rings
// or wet gloss in deserts / snowy biomes; 0 = legacy behavior (fallback if the uniform
// is unavailable and reads 0). Not in the menu.
#define RIPPLE_BIOME_GATE 1 // [0 1]
// PLAYER-CENTERED BOAT WAKE: Kelvin V anchored on eyePosition (player model head, camera
// fallback when the uniform stays 0), oriented along the SMOOTHED heading (smooth uniforms
// 55/56 on cameraPosition, half-life 0.5 s; per-frame velocity fallback), 13-18 blocks of
// trail: diverging arms at ~19.5 deg + TRANSVERSE waves inside the V + bow bulge (normals,
// gbuffers_water) AND white foam painted into the whitecap channel (composite1: arms,
// turbulence behind the hull, bow; analytic masks laced with foamPattern).
// Boat gate: water plane -0.6..2.15 blocks below the eye (seated tolerance) and speed
// > ~1.5 b/s - NOT isEyeInWater, which is false in a boat. At-rest lapping is cut while
// moving; entry/exit rings stay silent during the isEyeInWater flicker of surface swimming.
// With no GPU history a turn folds the template (no persistent curved trail; the smoothed
// heading softens the fold). 0 = camera-centered legacy behaviour (anchors 43-48).
#define RIPPLES_V5 1 // [0 1]
#define WATER_REFLECTIVITY 1.5 // [0.0 0.25 0.5 0.65 0.8 1.0 1.3 1.5 2.0 3.0]
// Live water-look dials (added after remote screenshot tuning proved hopeless:
// the user dials these in-game). BRIGHT scales the veil luminance, BLUE slides
// the slate hue toward gray, PRESENCE restores near-field surface visibility.
#define WATER_FOG_BRIGHT 0.75 // [0.25 0.5 0.75 1.0 1.5 2.0]
#define WATER_FOG_BLUE 0.85 // [0.25 0.5 0.75 0.85 1.0 1.25]
#define WATER_SURFACE_PRESENCE 1.0 // [0.0 0.5 1.0 1.5 2.0]
// Sun glint = SINGLE tight GGX lobe (alpha 0.006 near -> 0.016 far, fresnel
// folded in, HDR-clamped): pin-point sparkles carried by the wave normals,
// no wide Blinn blob and no painted sun trail (both removed).
#define WATER_SUN_GLINT 1.0 // [0.0 0.5 0.75 1.0 1.5 2.0 3.0 5.0 8.0 12.0]
// WATER_GLINT_SHADOW: the water's SUN SPECULAR (GGX glint +
// WATER_SPARKLE) is masked by shadow VISIBILITY at the surface, so water in the
// shade of a cliff or building shows no sun reflection (same for the moon at
// night - shadowLightPosition follows). One shadowtex1 tap (shadowVis1, same
// infrastructure as composite1 caustics/AO); opaque only, so water never
// self-shadows; outside the shadow map it returns 1.0 (fail-safe: glint intact
// beyond range). Affects NEITHER the sky reflection NOR the SSR.
// G3 FOLLOW-UP -- that last sentence was the hole. The reflected sky carries a
// SECOND copy of the sun (celestialDisc inside getSkyAll, and the same disc
// again in the colortex0 screen tap skyReflect prefers), so masking this lobe
// alone still left the sun's MIRROR IMAGE on shaded water: the "on voit le
// reflet du soleil alors qu'on est a l'ombre" report. SUN_MIRROR_SHADOW (in
// the reflection section) closes it by extinguishing the mirrored DISC only --
// the diffuse dome keeps reflecting, which is the correct behaviour. The two
// gates are independent and both default to 1.
// 0 = legacy behaviour.
#define WATER_GLINT_SHADOW 1 // [0 1]
// ### FIGE PAR LA PASSE "MEN" - PLUS AUCUN CONTROLE EN JEU, RESTE //#define (OFF).
// Raison : le scintillement ("Scintillement de l'eau", ex-ecran Eau) est OFF
// par defaut ("Desactive si ca fait bruite", disait sa propre infobulle) - la
// case sort du menu. Reallumer = decommenter A LA MAIN (site unique :
// composite1.fsh "#ifdef WATER_SPARKLE"; WATER_SPARKLE_AMOUNT reste son dial).
// Meme statut de booleen cache que WHITECAPS / WATER_RIPPLES plus haut.
//#define WATER_SPARKLE
#define WATER_SPARKLE_AMOUNT 1.0 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0 3.0 5.0 8.0]
//#define WATER_MICRONORMAL
#define WATER_SKY_REFLECT
// WATER_CLOUD_REFLECT: the sky reflection samples the REAL sky pixels on screen (colortex0:
// atmosphere + VOLUMETRIC CLOUDS, already painted by deferred) whenever the reflected
// direction lands on screen, so the ocean actually reflects cumulus.
// Off-screen or below the horizon it falls back to getSkyAll (analytic gradient).
// Note that getSkyAll contains NO volumetric clouds (getClouds only exists under CLOUDS_2D,
// which is off), which is why the analytic fallback reflects an empty gradient.
#define WATER_CLOUD_REFLECT
#define WATER_NORMAL_STRENGTH 1.0 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0 3.0 5.0 8.0]
// ANTI-MARBLING: fraction of the wave normal kept for the SKY reflection only (screen-space
// skyReflect + analytic). With the full normal, the sampled screen UV jumps pixel to pixel
// between "white volumetric cloud" and "cloudless analytic blue" (getSkyAll), producing a
// blue-white marbled net across the whole water plane. Fresnel, sun glint and geometry SSR
// keep the FULL normal. 1.0 = no flattening (legacy).
// 0.5 (was 0.35): more wave life in the sky mirror -- reference-style cloud
// patches, distorted by the swell yet sharp.
#define WATER_SKY_DISTORT 0.5 // [0.0 0.15 0.25 0.35 0.5 0.75 1.0]
// EDGE FOAM (composite1): organic shoreline band - VERTICAL column depth (the band hugs
// the shore from any view angle), spatially phased ebb and flow (each stretch of coast
// breathes at its own rhythm), holed multi-octave lace, contact fringe, scattered micro
// bubbles. FOAM_AMOUNT 0.0 mutes it.
#define FOAM_AMOUNT 1.0 // [0.0 0.5 0.75 1.0 1.5 2.0 3.0 5.0 8.0]
#define WHITECAP_NEAR_FADE 14.0 // [6.0 10.0 14.0 20.0 30.0 50.0]
#define WATER_FALL_SPEED 3.5 // [1.0 2.0 3.5 5.0 8.0 12.0]
#define WATER_FALL_RELIEF 1.0 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0 3.0]
// Fresnel reflectivity floor on VERTICAL water (waterfalls/walls). On a vertical face the
// base Fresnel term collapses and the water looks dull; this floor brings the sky
// reflection back. 0.0 = legacy, 0.25 = bright water wall. Not exposed in the menu.
#define WATER_FALL_REFLECT_FLOOR 0.25 // [0.0 0.1 0.25 0.4 0.6]
#define WATER_ROUGH_REFLECT
// 0.05 (was 0.08): the reference water is a near-mirror -- cloud/sky patches
// stay soft-edged through the waves but SHARP, not smeared by distance blur.
#define WATER_ROUGHNESS 0.05 // [0.0 0.05 0.08 0.10 0.15 0.20 0.30 0.50]
// REFLECT_DESAT: desaturates the FINAL water reflection (SSR + sky + horizon floor
// combined) by mixing toward its luma, just before composition. A very saturated sky
// otherwise gives "candy blue" water; this pulls it toward a more photographic silver
// mirror. Applied by MULTIPLICATION inside the mix (no #if on a float).
// 0.0 = legacy behaviour.
#define REFLECT_DESAT 0.40 // [0.0 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.50]
// WATER_HORIZON_SKY: fixes water turning BLACK at grazing angles / toward the horizon.
// At grazing distance the SSR hits dark shadowed terrain (or near-black absorbed water)
// instead of reflecting the sky. This fix (a) lowers SSR confidence with distance so far
// water reflects the clean analytic SKY rather than a dark screen smear, and (b) applies a
// sky FLOOR to both the reflection and the base color so distant water can never be black.
// Near glossy reflections are preserved. Undefine for the original unclamped behaviour.
#define WATER_HORIZON_SKY
// Distance (blocks) at which water switches to a pure sky reflection.
// LOWER = the sky takes over earlier (less black, but shorter near-field SSR).
#define WATER_HORIZON_DIST 96.0 // [16.0 24.0 32.0 48.0 64.0 96.0 128.0 256.0]
// Strength of the sky floor (fraction of sky reflection forced in at the horizon).
// 1.0 = the farthest/most grazing water is ~100% sky. 0.0 disables the floor (SSR/base can
// still go black).
#define WATER_HORIZON_SKY_STRENGTH 1.0 // [0.0 0.25 0.5 0.65 0.75 0.85 1.0]
// MID-DISTANCE BLACK WATER (a near-black band around 40-120 blocks on a daylit ocean while
// near water looks fine). At medium grazing angles the SSR hits DARK distant terrain with a
// still-high hit confidence, so the sky floor (weighted by 1-hit) stays inactive and the
// dark reflection wins. Physically, choppy water seen from afar reflects mostly SKY
// (micro-facets), so the GEOMETRY reflection is faded toward the sky with distance
// (progressive mix from WATER_DSKY_NEAR, full at WATER_DSKY_FAR - deliberately not a
// full-sky max() that would wash out near reflections), and only when it is darker than the
// sky (a bright reflection - sunlit wall, sail - stays intact at range).
// Undefine for legacy behaviour. Not exposed in the menu.
#define WATER_DIST_SKY_MIX
// Window 48..160 with strength 0.65: a tighter/stronger window eats legitimate geometry
// reflections (mountains, trees) from 40-80 blocks out.
#define WATER_DSKY_NEAR 48.0 // [24.0 32.0 40.0 48.0 64.0 96.0]
#define WATER_DSKY_FAR 160.0 // [80.0 100.0 120.0 140.0 160.0 180.0 240.0]
#define WATER_DSKY_STRENGTH 0.65 // [0.0 0.25 0.5 0.65 0.75 0.85 1.0]
//#define UW_BIOME_TINT
// (off by default: no biome tint underwater)
#define UW_BIOME_TINT_STRENGTH 0.6 // [0.0 0.25 0.5 0.6 0.75 1.0 1.5]
#define UW_DENSITY_BOOST 1.0 // [0.5 0.75 1.0 1.25 1.5 2.0 3.0]
#define UW_FOG_DEPTH_TINT 1.0 // [0.0 0.5 1.0 1.5 2.0]
#define WATER_CLARITY 1.5 // [0.1 0.25 0.5 0.75 1.0 1.5 2.0 3.0 4.0 6.0 10.0 20.0 50.0]
// Higher = clearer column (the DEPTH_DENSITY/CLARITY ratio scales the in-water
// path length that feeds BOTH the absorption and the path veil in composite1).
#define WATER_FOG_DENSITY 1.0 // [0.0 0.1 0.25 0.5 0.75 1.0 1.5 2.0 3.0 5.0 8.0]
// Reference water column (calibrated defaults, not exposed in the menu):
// TINT_DESAT now only desaturates the SURFACE albedo (gbuffers_water/dh_water);
// the column itself uses a fixed slate palette. SCATTER_DARKEN scales the slate
// in-scatter, DEPTH_DENSITY densifies the path, REFLECT_FLOOR is the
// normal-incidence reflection floor modulated by sky light (0.0 = legacy).
#define WATER_TINT_DESAT 0.7 // [0.0 0.2 0.3 0.4 0.55 0.65 0.7 1.0]
#define WATER_SCATTER_DARKEN 0.80 // [0.5 0.65 0.8 0.9 1.0]
#define WATER_DEPTH_DENSITY 1.5 // [0.5 0.75 1.0 1.25 1.5 1.75 2.0 3.0]
#define WATER_REFLECT_FLOOR 0.06 // [0.0 0.04 0.06 0.08 0.12 0.2]
// UW_VOLUMETRICS: underwater volumetric fog + caustic god-rays.
// Depth-graded density with shafts modulated by the caustics. WATER_FOG_DENSITY is the
// density slider.
#define UW_VOLUMETRICS
#define UW_GODRAY_STRENGTH 2.0 // [0.0 0.5 1.0 1.5 2.0 3.0 5.0]
// Shaft geometry. FINESSE: higher = THINNER and RARER rays (raised aperture thresholds).
// SCALE: higher = WIDER pattern = more SPACE between blades (spectral sigma).
// Tune FINESSE first, then SCALE.
#define UW_SHAFT_FINESSE 1.3 // [0.6 0.8 1.0 1.3 1.6 2.0 2.6]
#define UW_SHAFT_SCALE 1.0 // [0.8 1.0 1.25 1.5 1.8]
// Eye-distance render limit (blocks) for the god-ray term ONLY: shafts fade out between
// 0.7x and 1.0x this distance; the UW fog, ambient and darkness continue beyond it.
// UW_SHAFT_RENDER_DIST : derive de SUNRAY_QUALITY (bloc AXES DE MENU, haut de ce fichier)
// ---- UW_SHAFT_BOUND: the render limit is a MARCH BOUND, not just a fade ----
// 1 = past 1.0x UW_SHAFT_RENDER_DIST of SUBMERGED path (camera distance with
// UW_SHAFTS_UNIFIED = 0, exactly the distance shaftFade already measures) the
// caustic taps of a march step are SKIPPED outright -- causticShaftMask +
// vlCa4Vol (slope + net), ~3 field evaluations per tap and the most expensive
// part of a submerged step -- instead of being computed and then multiplied by
// a shaftFade of exactly 0. The 0.7x..1.0x fade is untouched and happens
// entirely INSIDE the paid zone, so no wall appears at the bound: the beams
// have already melted to nothing where the taps stop. The two ranges are now
// properly separate: the UW FOG march still runs to UW_RAY_DISTANCE
// (VOLUMETRIC_QUALITY), only the FILAMENT term stops at UW_SHAFT_RENDER_DIST
// (SUNRAY_QUALITY) -- the unified-beam pedestal (UW_SHAFT_BASE, the submerged
// direct light) also continues past the bound, as it always did.
// SAVINGS, measured at the tier the figures ship with (SUNRAY_QUALITY 1 +
// VOLUMETRIC_QUALITY 1, diver facing the horizon): the march runs 8 steps of
// dt 6.0 to UW_RAY_DISTANCE 48, the bound sits at 24 -> the 4 far steps skip
// their tap = 4 x ~3 = ~12 field evaluations saved per marched pixel, HALF the
// shaft cost of the ray (paid on ~1/4 of pixels while VL_HALF_RES = 1).
// Output bit-identical at 1 (every skipped tap was multiplied by 0);
// 0 = legacy, the taps keep being paid beyond the bound. Not in the menu.
#define UW_SHAFT_BOUND 1 // [0 1]
// ==== UW_SHAFT_V4: the underwater beams SEEN FROM OUT OF THE WATER ==========
// Everything under this gate is scoped to ONE observer: the eye is DRY and
// looks down through the surface into the column. A submerged eye
// (isEyeInWater == 1) and the in-glass case are excluded BY THE CODE, not by
// tuning, so a diver's render is untouched at any setting below. 0 = the
// pre-V4 behaviour, verbatim.
//
// THE THREE MEASURED DEFECTS. (Numbers from the numeric port of the beam
// bracket, composite1.fsh ~7975-7995 + lib/vl_halfres.glsl ~1057-1059.)
//
// (A) THE BEAMS LIE FLATTER THAN PHYSICS ALLOWS. The column axis is set by
//     uwShaftSlide (lib/water.glsl): the lookup is constant along the
//     direction it slides, so the bright/dark columns are parallel to it by
//     construction. UW_SHAFT_FIX3 put that slide on the SHADOW MAP's axis --
//     lightW.xz / max(lightW.y, 0.15) -- so the beams and the cast shadow are
//     one geometry. That argument picks between axes that are POSSIBLE. Below
//     41.4 deg of sun elevation the air axis is not one of them: refraction at
//     the surface confines EVERY ray inside water to the 48.59 deg Snell cone
//     (slide <= tan 48.59 = 1.135 block per block of column), and total
//     internal reflection is what makes that a hard wall, not a soft
//     preference. Measured slide, and the angle from the vertical it draws:
//       sun elev   air axis (shipped)   Snell        air/Snell
//         55 deg   0.700  (35.0 deg)    0.477 (25.5)   1.47x
//         45 deg   1.000  (45.0 deg)    0.626 (32.0)   1.60x
//         30 deg   1.732  (60.0 deg)    0.854 (40.5)   2.03x
//         20 deg   2.747  (70.0 deg)    0.993 (44.8)   2.77x
//         10 deg   5.671  (80.0 deg)    1.096 (47.6)   5.18x
//          5 deg   6.641  (81.4 deg)    1.124 (48.3)   5.91x
//     UW_SHAFT_AXIS_MODE picks what to do about it (see the dial).
//
// (B) FROM THE BANK, THE FORWARD LOBE IS UNREACHABLE -- and the shipped phase
//     reaches it anyway. cosTU is dot(worldDir, uwLightW): BOTH vectors are
//     AIR vectors, while the scattering event happens under the surface,
//     between the REFRACTED view ray and the REFRACTED sun ray. Refraction
//     steepens both, and with a dry eye the two sit on opposite sides of the
//     horizontal, so their angles ADD instead of cancelling. The bound is
//     exact: with both rays inside the cone,
//        cos(dev) = sinTv*sinTl*cos(dAz) - cosTv*cosTl <= 0.563 - 0.437,
//     i.e. the in-water scattering deviation from a dry eye is ALWAYS
//     >= 82.8 deg. The forward lobe of the water HG (g = 0.58) simply cannot
//     be entered from above the surface -- and it is exactly where the shipped
//     air cosT lands. Over-brightness of the beam, measured (sun elevation x
//     look-down angle, toward the sun):
//        sun 55 / down 20  -> air dev  75.0 deg vs true 109.7  -> 2.15x
//        sun 30 / down 20  -> air dev  50.0 deg vs true  94.7  -> 3.77x
//        sun 20 / down 35  -> air dev  55.0 deg vs true  97.3  -> 3.29x
//        sun 10 / down 20  -> air dev  30.0 deg vs true  87.6  -> 7.64x
//        sun  5 / down 20  -> air dev  25.0 deg vs true  86.8  -> 9.43x
//     THIS is why the beams read "too laser, too bright" from the bank at a
//     low sun and not at noon: the error tracks the sun's elevation.
//     Fixed unconditionally under this gate (no dial): it is a wrong vector,
//     not a taste. Costs two uwSunRefract() calls per RAY, uniform branch.
//
// (C) THE COLUMN DOES NOT GET DARKER GOING DOWN. The beam bracket is
//        phaseW * UW_SHAFT_BASE  +  phaseShaft * caDir * beerR * ...
//     The filament half carries beerR = exp(-toSurf * 0.06); the PEDESTAL half
//     -- the submerged direct light UW_SHAFT_BASE took over from the removed
//     generic in-scatter -- carries NOTHING. So the two halves drift apart
//     with depth: at 30 blocks the filaments are down to 16% and the pedestal
//     is still at 100%, i.e. the deep column is ~80% flat glow with the
//     structure dissolved out of it. A diver barely sees this (his shaft
//     render distance is 24-48 blocks and he looks at a short column); from
//     the bank the WHOLE column is on screen at once and it reads as a slab of
//     even light. Measured surface-to-30-blocks contrast of the in-scatter
//     reaching the eye: 4.55:1 before, 16.45:1 with the pedestal on beerR.
//
// NOT A DEFECT, checked and cleared: the FRESNEL transmission of the beam
// through the surface. It is not written anywhere as a factor, but it is
// already carried, to within 20%, by the two wMirror sites the pack already
// has -- the submerged step density uw*0.008*(1 - wMirror*0.85) and the
// fogKeepW = 1 - 0.55*wMirror at apply time. Code kept vs. exact unpolarised
// Fresnel T(theta)/T(0) of a flat air/water interface:
//     depression 45 deg -> 0.953 vs 0.992   (0.96x)
//     depression 30 deg -> 0.916 vs 0.960   (0.95x)
//     depression 15 deg -> 0.732 vs 0.804   (0.91x)
//     depression  5 deg -> 0.345 vs 0.425   (0.81x)
//     depression2.5 deg -> 0.273 vs 0.243   (1.12x)
// It only breaks down below ~1 deg of depression (0.273 vs 0.106, 2.6x), i.e.
// on the horizon line itself, where PERF_OCEAN's own view bound has already
// faded the filaments out. No factor was added: a second one would double-
// count what those two sites already do.
#define UW_SHAFT_V4 1 // out-of-menu gate, 0 = pre-UW_SHAFT_V4 behaviour bit-identical
// (A) WHICH AXIS the beams and the caustic lookup slide along. Read by
// uwShaftSlope / uwShaftAxis / uwShaftSlide (lib/water.glsl), so it moves the
// volumetric beams AND the six floor-caustic sites of composite1's water
// branch TOGETHER -- a beam still lands exactly on the spot it lights, which
// is the registration UW_SHAFT_FIX3 (A) exists to protect. The only structure
// it does NOT move is the shadow map (an air rasterization; refracting it
// needs a second shadow pass this pack does not have).
//   0 = shipped air axis, unbounded. Beam and cast shadow agree at every sun
//       elevation, at the price of beams drawn outside the Snell cone below
//       41.4 deg (up to 81.4 deg from the vertical at sunset).
//   1 = air axis CLAMPED to the cone (DEFAULT). Bit-identical to the PRE-V4
//       expression -- not merely equal to it -- for any sun at or above
//       41.4 deg of elevation: uwShaftAxis and uwShaftSlide both build the
//       shipped vector FIRST and only shrink it when it falls outside the
//       cone, so nothing is re-associated on the path that used to be taken.
//       This pack's noon is 55 deg with sunPathRotation -35, so the validated
//       configuration does not move by one ulp. Below it the slide stops at
//       1.135 and the beams stay inside the
//       cone; the residual against true Snell is 1.14x at a 20-deg sun and
//       1.01x at a 5-deg one, i.e. the clamp IS Snell exactly where the error
//       used to be worst. Cost, stated honestly: the beam/cast-shadow gap this
//       reopens is 0 deg at 41.4 deg of sun, 11.4 deg at 30 deg, 21.4 deg at
//       20 deg -- always SMALLER than the gap mode 2 would open at the same
//       elevation, and exactly 0 where UW_SHAFT_FIX3 was validated.
//   2 = full refracted (Snell) axis. Physically exact everywhere, and the
//       configuration UW_SHAFT_FIX3 deliberately rejected: it re-opens the
//       gap at EVERY elevation (9.5 deg at this pack's noon, 25.2 deg at a
//       20-deg sun), which is the "the rays do not come from the sun" reading
//       that motivated FIX3. Kept as a documented, one-line choice.
#define UW_SHAFT_AXIS_MODE 1 // out-of-menu, see above (0 = shipped axis, 1 = Snell-cone clamp, 2 = full Snell)
#define UW_SHAFT_CONE_TAN 1.135 // tan(48.59 deg): the Snell cone, the widest a ray inside water can be. Read by mode 1 only.
// (C) how much of the filament extinction beerR the PEDESTAL takes.
// 1.0 = the pedestal decays on the filaments' own curve, so the SHAPE of the
// beam bracket stops depending on depth (default); 0.0 = the shipped flat
// pedestal. No new extinction constant is introduced on purpose: reusing
// beerR is what makes the two halves of the bracket keep a constant ratio.
#define UW_SHAFT_PED_FALL 1.0 // out-of-menu, 0.0 = shipped flat pedestal, 1.0 = pedestal on beerR
// (D) SPECTRAL half of that extinction. beerR is achromatic (one exponent for
// R, G and B), so the shipped beam keeps a frozen chroma at every depth -- its
// R/G ratio is 0.800 at the surface and still 0.800 at 40 blocks. Real water
// is a spectral filter: red goes first, and in COASTAL water (this pack's
// turquoise, G ~ B) the minimum attenuation sits in the green, so the beam
// must green out going down. Applied as a NORMALISED chroma (green = 1.0, R
// and B only ever darker) so it removes no luminance beyond what the physical
// channels lose: ~15% at 20 blocks. The two coefficients are the excess of
// K_red and K_blue over K_green, per block, and they are deliberately GENTLE
// -- real coastal K_red - K_green is ~0.35/m against 0.055/m here -- because
// the water COLUMN's own spectrum (waterColumn / WCOL_*) is a separate,
// independently tuned system and this must not race it. Resulting beam R/G:
// 0.800 at the surface, 0.462 at 10 blocks, 0.266 at 20, 0.154 at 30.
// 0.0 restores the shipped achromatic beam exactly.
#define UW_SHAFT_SPECTRAL 0.55 // out-of-menu, chromatic share of the beam's depth extinction (0.0 = achromatic)
#define UW_SHAFT_SPEC_KR 0.100 // K_red - K_green per block, before UW_SHAFT_SPECTRAL
#define UW_SHAFT_SPEC_KB 0.022 // K_blue - K_green per block, before UW_SHAFT_SPECTRAL
// ---- PERF_OCEAN: the bank-view ocean bill, bounded by what a PIXEL shows ----
// AUDIT (config VOLUMETRIC/SUNRAY/REFLECT/SHADOW_QUALITY 3, TAAU natif 1080p,
// oeil sur la berge, vue rasante ; NB PASSE VQ3 : cet audit decrit le palier 3
// d'AVANT le re-etagement, ou VL_HALF_RES valait 0 -- ce plein ecran n'existe
// plus que sous VL_FULL_RES = 1, mais les early-outs (1)(2)(3) vivent dans LES
// DEUX marches et restent actifs a tous les paliers): a ce palier-la, la
// marche VL tourne PLEIN ECRAN (chaque pixel paie ses 20 pas), et un rayon rasant reste
// immerge de la surface jusqu'a marchEnd = 160 (le fond opaque est a 300+
// blocs le long du rayon, transLo ne casse jamais: densite immergee
// wMirror-relevee ~0.002/bloc). Trois postes payaient plein pot un signal que
// le pixel ne peut pas montrer; 1 = trois VRAIS early-outs (du travail saute,
// jamais un facteur 0 paye), tous oeil-sec seulement:
//   (1) BORNE CAMERA des filaments. UW_SHAFT_RENDER_DIST borne le CHEMIN
//       IMMERGE (juste pour un plongeur) - un rayon de berge entrant dans
//       l'eau a 100 blocs payait donc ses taps de champ pleins a 100-148
//       blocs de la camera, la ou une striation de 0.3 bloc couvre ~2 px
//       (voir MESURE 4 / UW_SHAFT_VIEW_DIST, bloc AXES DE MENU). Le fondu
//       camera (0.72x..1.0x de VIEW_DIST 96) multiplie shaftFade, et le skip
//       shaftFade > 0 existant (UW_SHAFT_BOUND) cesse de payer les taps
//       au-dela: a VL_SAMPLES 20 c'etait jusqu'a 18 sous-taps de champ
//       (~2 evaluations chacun) par pixel d'ocean.
//       CE QUE LA COUPE RETIRE, honnetement: le terme filament pese environ
//       DEUX FOIS le piedestal UW_SHAFT_BASE dans le crochet du faisceau
//       (phaseShaft*1.44*caShaft/phaseW ~ 2 a caShaft moyen, vue
//       perpendiculaire, et outGU ~1.9 rehausse deja l'amplitude de pas d'un
//       facteur ~2 par construction, cf. d3) -- l'eteindre sur 69..96 blocs
//       enleve ~2/3 de la luminosite du faisceau sur cette bande, soit
//       quelques % de la luminance d'un pixel d'ocean rasant (transF ~0.5
//       la-bas). Ce n'est PAS "sub-JND par construction": c'est un fondu
//       PARFAITEMENT CONTINU en distance (aucune ligne de coupure; depuis la
//       passe VQ3 dt vaut 5.0 au palier 3, 96 = 19.2*dt : la frontiere du
//       skip ne tombe plus sur un indice de pas entier, mais vlDither
//       disperse deja les pas de +-dt, le skip reste donc granulaire au front
//       d'onde -- et il ne saute que des taps dont le fondu vaut exactement
//       0) juge invisible en pratique.
//   (2) DECROISSANCE de nSubU: la box-average du champ (F6) existe pour
//       l'aliasing la ou les filaments sont RESOLUS a l'ecran; le nombre de
//       taps par pas decroit avec la distance camera du pas (plein en deca de
//       max(0.55*VIEW_DIST, 30) = ~53 blocs, 1 tap des ~79 blocs), fenetre
//       calee DERRIERE le debut du fondu d'amplitude (1) pour que la variance
//       ajoutee arrive la ou l'amplitude tombe deja.
//       GRANULARITE: les deux early-outs s'executent en SIMD -- un front
//       d'onde paie le MAX de nSubU de ses lanes, et les seuils de nSubU ne
//       sont pas des multiples de dt (vlDither disperse les pas de +-dt),
//       donc le gain de taps est granulaire au front d'onde, pas par-pixel.
//   GAIN AGREGE, pondere par la densite de pixels (vue rasante, dtheta/ds
//   proportionnel a h/s^2): a hauteur d'oeil sur la plage (h~2, 90% des
//   pixels d'ocean sous s=30 ou presque rien ne change) les postes (1)+(2)
//   valent ~-4 a -6% du budget filaments du pixel d'ocean; depuis un point
//   haut (falaise/bateau, h>=10) ~-15 a -20%. Les gains PAR DISTANCE sont
//   bien plus gros (s=80: ~2 sous-taps au lieu de 18; s>=150: 0) mais ces
//   pixels sont rares a hauteur d'oeil. Pour un vrai -30% il faudrait toucher
//   dt (VL_SAMPLES), le nombre de pas payants (UW_SHAFT_RENDER_DIST) ou nSubU
//   en champ tres proche -- hors perimetre ici.
//   (3) CAUSTIQUES DU FOND vues de dehors: soft4/CAUSTIC_DIST_FADE est un
//       fondu PAYE (il elargit l'empreinte photon, ne tombe jamais a zero) -
//       un plateau ensoleille a 150 blocs payait encore vlCa4Net (3 pentes +
//       9 photons) + sonde d'ombre pour moduler une part de pixel que le
//       plafond miroir 0.98 (atteint des ~45 blocs en rasant) et l'absorption
//       de colonne tiennent au pour-mille. Les deux sites oeil-sec (a travers
//       la surface, et la bande de rivage) fondent 110->150 blocs puis
//       SAUTENT toute evaluation, taps de detection compris.
// Champ proche, garantie EXACTE (les fenetres sont indexees sur la distance
// camera du PAS, pas du pixel): bit-identique pour tout PAS a moins de
// ~53 blocs de la camera (nSubU plein), amplitude filament bit-identique
// jusqu'a 69.1 blocs (0.72x96). Un pixel PROCHE voit donc ses pas LOINTAINS
// perdre des taps -- mais ces pas sont deja attenues a 58-100% par la borne
// de chemin, et l'ecart porte sur la VARIANCE de l'estimateur box, pas sur sa
// moyenne. 0 = comportement actuel bit-identique. Not in the menu.
#define PERF_OCEAN 1 // out-of-menu gate, 0 = pre-PERF_OCEAN behaviour bit-identical
// ---- LOT A PERF (audit 2026-08) : 4 gates independants, HORS MENU ----
// 0 = comportement precedent VERBATIM, 1 = optimisation active. Pas de liste
// de valeurs apres ces defines (regle Iris : une liste // [..] sur un define
// hors menu en ferait une option fantome) ; le commentaire apres la valeur
// reste obligatoire pour le shim -Set du harnais de compilation.
// A1 : fogSunVis (composite1.fsh) - 2 sondes (20 % / 70 % du rayon) au lieu
//      de 3 (20/50/80) et test de hauteur du soleil HISSE au-dessus des taps
//      nuage (meme critere que le sunUpF de cloudShadow : lightDirW.y <= 0.06
//      -> aucune ombre de nuage possible, donc zero tap nuage la nuit).
#define PERF_FOGVIS 1 // 2 sondes fog + early-out nuit (0 = 3 sondes legacy)
// A2 : bake nuages half-res (prepare.fsh / prepare1.fsh) - discard immediat
//      AVANT le march quand l'oeil est TOTALEMENT enferme
//      (eyeBrightnessSmooth.y == 0). colortex15 garde alors son contenu
//      perime (clear=false, les DEUX cotes du ping-pong gelent) mais deferred
//      ne le lit que sur des pixels ciel (d0 >= 1.0), inexistants en grotte.
//      Le storm de l'End (y == 0 permanent la-bas) n'est PAS saute.
#define PERF_CAVE_SKIP 1 // skip du bake nuages oeil enferme (0 = bake permanent)
// A3 : cloudShadowCheap (lib/lighting.glsl) - champ cumulus 5 taps (centre +
//      croix interne) au lieu de 9 pour les consommateurs SECONDAIRES :
//      sondes fogSunVis (composite1), gate RSM (composite), csA/csB du march
//      VL (composite1 + miroir lib/vl_halfres.glsl). Le rendu des nuages et
//      shadeSurface (l'ombre au sol visible) gardent le champ complet.
#define PERF_CSHADOW_CHEAP 1 // 5 taps consommateurs secondaires (0 = champ complet partout)
// A4 : SSR du bloc PBR opaque (composite1.fsh) - lobe deja flou
//      (alphaG > 0.09) -> 24 pas de marche / 4 bisections au lieu de
//      SSR_STEPS / SSR_REFINE. Les quasi-miroirs (alphaG <= 0.09) gardent
//      tout ; l'eau, le verre et les autres consommateurs ne passent jamais
//      par ce plafond (restaure apres le dernier rayon du bloc).
#define PERF_SSR_ROUGH 1 // SSR borne par la rugosite (0 = plein budget partout)

// ================== SSR_V3 : STABILITE TEMPORELLE DES REFLETS ==================
// "Des fois ca clignote pas mal." MESURE avant d'ecrire une ligne : port numpy
// de ssrRay (SSR_FAST/STEP_V2/HIT_V2/EDGE_V2 = 1, REFLECT_QUALITY 2) marchant
// sur une scene analytique dont le raster est jitte EXACTEMENT comme les vsh le
// jittent (taaJitterNDC, Halton(2,3) mod 16, +-0.5 texel), 16 frames, ~3200
// pixels d'eau devant deux rangees de piquets fins (0.055 bloc ~ 2.9 px) et un
// mur. Metriques : nombre d'alternances hit/miss, variation totale (TV) de la
// confiance renvoyee, TV de la LUMINANCE composee mix(ciel, hit, conf) -- c'est
// cette derniere que l'oeil voit clignoter.
//
//   configuration                         alt/px   TV(lum)   px qui varient
//   (1) anneau eau par frame (livre)      0.425    0.4329        31.0 %
//   (2) anneau eau fige                   0.444    0.3284        11.1 %
//   (3) phase de marche par frame         0.004    0.2913         8.7 %
//   (4) phase de marche figee             0.002    0.2912         8.8 %
//   (5) fenetre d'acceptation continue    0.444    0.3406        13.7 %
//
// CE QUE LA MESURE DIT, ET CE QU'ELLE REFUTE :
//  (a) LE TERME TEMPOREL DES DIRECTIONS EST LA PREMIERE CAUSE. angW de la
//      branche eau vaut (dither + fract(frameTimeCounter*0.61)) * 2pi : il fait
//      tourner le rayon SSR de l'eau sur un anneau A CHAQUE FRAME. Le figer
//      dans le temps fait passer les pixels dont le reflet varie de 31.0 % a
//      11.1 % (-64 %) et la TV de luminance de 0.4329 a 0.3284 (-24 %), pour un
//      rayon d'anneau de blurR = 0.011 rad = 0.63 deg au defaut WATER_ROUGHNESS
//      0.05 : personne ne voit ce flou, tout le monde voit le scintillement.
//      Meme raisonnement que le commentaire PT_WATER_NORMAL de composite1 (une
//      surface animee fait rejeter l'historique TAA, donc rien ne moyenne).
//  (b) LA PHASE DE MARCHE (raySeed du bloc PBR opaque, tournee par le nombre
//      d'or a chaque frame) double le nombre d'alternances (0.002 -> 0.004).
//      Le commentaire du fichier avait deja identifie le mecanisme et ne
//      l'avait corrige QUE pour les miroirs purs (alphaG <= 0.012). La
//      DIRECTION garde sa rotation par frame (c'est elle que le TAA integre
//      pour flouter le lobe) ; seule la PHASE de depart est figee.
//  (c) LA FENETRE D'ACCEPTATION N'EST PAS LA CAUSE, ET LE TEST BINAIRE EST
//      MEME PLUS STABLE QUE SA VERSION CONTINUE. Contre-mesure explicite : sur
//      une geometrie RASANTE (soffit horizontal effleure par les rayons
//      reflechis) le test binaire donne 0 alternance et TV(lum) = 0.0000 sur
//      les 16 frames -- a SSR_TOL_REL 0.12 la fenetre vaut 12 % de la
//      profondeur (3.1 blocs a 26 blocs) alors que le jitter ne deplace la
//      profondeur du point que de 0.5 texel : le rapport jitter/fenetre vaut
//      tan(theta) / (2 * SSR_TOL_REL * f) et ne depasse 1 qu'au-dela de
//      theta = 89.7 deg. Le test binaire QUANTIFIE donc a zero toute variation
//      de |dz| qui reste dans la fenetre, ce qu'un fondu continu re-introduit
//      (TV(lum) 0.3284 -> 0.3406, +3.7 %). Le fondu est quand meme livre --
//      il rend le resultat CONTINU en l'entree, ce qui est la bonne propriete
//      quand la fenetre se resserre (SSR_TOL_REL 0.06 au cran bas du menu) et
//      il degrade les hits acceptes seulement grace a l'EPAISSEUR presumee,
//      qui sont geometriquement les moins surs -- mais avec une largeur par
//      defaut ETROITE (0.25) et le chiffre ci-dessus assume.
//  (d) RESIDU IRREDUCTIBLE : meme tout fige, 8.0 % des pixels voient encore le
//      reflet changer, a confiance CONSTANTE. C'est le contenu qui bouge : le
//      raster est jitte, donc les silhouettes fines glissent d'un demi-texel et
//      le rayon tombe une frame sur un piquet, la suivante sur le mur derriere.
//      Aucun reglage de la marche ne corrige cela (verifie : de-jitter des taps
//      de profondeur, TV(lum) 0.2912 -> 0.2743, -6 % seulement, parce que le
//      depth buffer est echantillonne en POINT et que le residu de reechantil-
//      lonnage bouge autant que le decalage qu'on retire ; idee mesuree puis
//      ABANDONNEE). C'est au TAA de le resoudre.
#define SSR_V3 1 // stabilite temporelle des reflets (0 = comportement precedent verbatim)
// Phase de marche SSR figee dans le temps (b). La direction GGX garde sa
// rotation par frame ; seule la graine passee a ssrRay redevient le Bayer
// statique. Aucun cout : c'est une expression de moins.
#define SSR_V3_MARCH_SEED 1 // graine de marche SSR figee (0 = graine tournee par frame)
// Anneau de flou du rayon SSR de l'eau fige dans le temps (a). Decorrelation
// SPATIALE conservee (Bayer + hash12 du fragment, l'idiome deja utilise dans
// composite1 comme repli BLUE_NOISE = 0), terme frameTimeCounter retire.
#define SSR_V3_WATER_RING 1 // anneau SSR eau fige (0 = rotation par frame)
// Largeur du fondu de confiance, en FRACTION de la borne (fenetre |dz| d'un
// cote, epaisseur presumee de l'autre). 0.25 = la confiance vaut 1 jusqu'a 75 %
// de la borne puis descend a 0 sur le dernier quart. 0.0 = test binaire.
#define SSR_V3_CONF 0.25 // largeur du fondu de confiance (0 = binaire)
// Marge de fenetre couplee a l'EMPREINTE DU JITTER TAA : quand le raster glisse
// de TAA_JITTER texel, la profondeur du rayon au point d'impact bouge de
// |dir.z| / ppu par texel (ppu = pixels parcourus par unite de rayon, deja en
// registre). Le fondu ne peut jamais etre plus etroit que ce deplacement, et
// jamais plus large que la borne elle-meme (min interne) : quand l'empreinte
// depasse la fenetre, le test n'a de toute facon plus de sens et la confiance
// devient un simple triangle sur la fenetre.
#define SSR_V3_JIT_TOL 1.0 // marge de fenetre = N x empreinte du jitter (0 = aucune)
// GLINT (e) -- ELARGISSEMENT DU LOBE PAR LA VARIANCE DE PENTE SOUS-PIXEL.
// MESURE sur le port numpy de wave3Eval (defauts : SCALES 6, PEAK_LEN 4.0,
// STEEP 0.026, ANISO 5.5, RIDGE 2), patch 60x60 blocs, 520^2 echantillons :
//   barreaux gardes   sigma_pente totale   sigma_pente RETIREE   part de variance
//        6                 0.0929               0.0000                0.0 %
//        5                 0.0828               0.0423               20.8 %
//        4                 0.0717               0.0593               40.8 %
//        3                 0.0594               0.0718               59.8 %
//        2                 0.0467               0.0805               75.1 %
// L'increment de VARIANCE par barreau retire est quasi constant (0.001789,
// 0.001727, 0.001639, 0.001325) : la pente d'un barreau est proportionnelle a
// son seul facteur Pierson-Moskowitz (l'amplitude va comme lambda et la pente
// comme amplitude/lambda, lambda se simplifie), donc les barreaux FINS portent
// l'essentiel de la pente. WAVE_LOD les coupe quand leur pas passe sous
// WAVE_LOD_K empreintes de pixel : premiere coupe a W3_LOD_C/32 = 95.6 blocs
// aux defauts, seconde a 191.2. En dessous de 95.6 blocs RIEN n'est retire et
// ce terme vaut EXACTEMENT zero -- l'eau proche et moyenne est bit-identique.
// Au-dela, la variance retiree est sous-pixel par construction : l'integrer
// dans le lobe est la reponse physique (alpha'^2 = alpha^2 + 2*sigma^2, la
// convolution d'une NDF par une gaussienne de pente), et c'est exactement ce
// qui transforme un champ clairseme de pics ecretes en un chemin de soleil
// continu. Chiffres aux defauts : a 120 blocs alpha 0.014 -> 0.037 (pic x0.14),
// a 192 blocs 0.016 -> 0.062 (pic x0.067) ; l'energie totale du chemin est
// conservee (elle est etalee, pas retiree). Mettre 0.0 pour retrouver le champ
// de pics ecretes.
#define SSR_V3_GLINT_VAR 1.0 // dose de l'elargissement de lobe par variance de pente (0 = aucun)
// Distance de la PREMIERE coupe WAVE_LOD, en blocs : W3_LOD_C / 32, ecrit ici
// pour rester independant de lib/water.glsl (1.6 = W3_LADDER_TOP).
#define SSR_V3_GLINT_D0 ((771.0 / WAVE_LOD_K) * (1.24 * 1.6 * WAVE3_PEAK_LEN) * 0.03125) // premiere coupe WAVE_LOD, en blocs
// Increment de VARIANCE de pente par barreau retire, mesure ci-dessus au
// gabarit par defaut, remis a l'echelle des trois cadrans qui multiplient la
// pente (tous des constantes de compilation, donc gratuit).
#define SSR_V3_GLINT_V1 (0.001789 * (WAVE3_STEEP / 0.026) * (WAVE3_STEEP / 0.026) * WAVE_STRENGTH * WAVE_STRENGTH * WATER_NORMAL_STRENGTH * WATER_NORMAL_STRENGTH) // variance de pente par barreau retire
// PLAFOND D'ENERGIE PAR PIXEL du glint, en luma HDR, applique au terme ADDITIF
// final (apres gLightC et tous les masques) avec un genou doux qui ne demarre
// qu'a 40 % du plafond. Aux defauts le terme culmine a specSun 33.8 x
// luma(gLightC) 6.9 = 233 : trois fois sous le genou, donc INERTE et bit-
// identique. Il n'existe pour l'instant AUCUNE borne absolue -- le menu
// autorise WATER_GLINT_KNEE 140 x WATER_SUN_GLINT 12 x SUN_INTENSITY 20, soit
// ~1.5e5 sur un seul pixel, ce qui est un generateur de lucioles pour le bloom.
#define SSR_V3_GLINT_CEIL 1500.0 // plafond doux du glint en luma HDR (inerte aux defauts)
// Underwater god-ray directionality. 0.0 = vertical columns stamped in xz, 1.0 = shafts
// fully aligned with the sun/moon axis (they move with the cycle). Not in the menu.
#define UW_GODRAY_DIRECTIONAL 0.8 // [0.0 0.25 0.5 0.8 1.0]
// Frequency/tilt of the light blades along the sun axis. Keep <=0.5: rel = wp -
// cameraPosition can get large and the sine aliases beyond that. Not in the menu.
#define UW_GODRAY_TILT 0.35 // [0.15 0.25 0.35 0.5 0.75 1.0]
// 1 = the shaft pattern IS the caustic projected PER MARCH STEP (physically shafts are
// caustic apertures: columns parallel to the sun/moon axis that dance with the waves and
// follow the light). 0 = legacy camera-relative sine blades (read as vertical and static).
// Not in the menu.
#define UW_GODRAY_CAUSTIC_LOCK 1 // [0 1]
// ---- UW_SHAFTS_UNIFIED: ONE underwater light-shaft system, both sides ----
// The beams are a property of the WATER (surface position, refracted sun axis,
// shared caustic field), not of the camera: the same water column must show
// the SAME beams whether the eye is submerged or standing on the bank - only
// the integrated segment changes. 1 fixes four things at once:
//   (a) OVERLAP. Every submerged march step used to receive TWO additive sun
//       terms: the generic in-scatter lightC*vis*phase (a smooth, unmodulated
//       shaft family carved only by the shadow map) AND the caustic shaft
//       term. Two beam systems of comparable magnitude on top of each other.
//       The direct in-scatter of a submerged step is now handed over to the
//       single beam term (smoothly, via the beam's own surface window).
//   (b) SAMPLING. Seen from the bank the march is bounded by the OPAQUE floor
//       rather than by UW_RAY_DISTANCE, so a whole water column can fall
//       inside a single 4-20 block step: the field is point-sampled once and
//       the beams alias into TAA noise instead of reading as beams. The step
//       is now box-averaged (UW_SHAFT_SUBSTEPS) whenever the eye is dry.
//       (The other half of that story - the wide sheaves and the fine
//       striations being read at two DIFFERENT lookups, the raw air
//       projection against the Snell one - is already fixed upstream: under
//       CAUSTICS_V4 cprjOff IS vlCa4Offset, so both scales ride one
//       wavefront. This path inherits that lookup, it does not redefine it.)
//   (c) SIDE MISMATCH. With a dry eye the beam took the AIR light colour and
//       the dusk-boosted air phase; it now takes the water tint and the water
//       phase g=0.58 whatever the camera does.
//   (d) INVISIBLE FROM THE BANK. UW_SHAFT_RENDER_DIST was measured from the
//       CAMERA, so a lake 24+ blocks away had its shafts fully faded before
//       the water even started. It is now measured along the SUBMERGED path
//       (identical when the eye is in the water, where the path starts at 0).
// 0 = previous behaviour, bit-identical.
#define UW_SHAFTS_UNIFIED 1 // [0 1]
// Unmodulated pedestal of the unified beam (UW_SHAFTS_UNIFIED = 1 only): the
// share of the refracted sunlight that lights the step BETWEEN the caustic
// filaments. It takes over from the generic in-scatter term removed by (a),
// and is deliberately NOT scaled by UW_GODRAY_STRENGTH so that dial stays a
// shaft dial instead of becoming an underwater light switch. It also replaces
// the flat 0.22 floor UW_GODRAY_DIRECTIONAL used to carry, so the two stop
// doing the same job: DIRECTIONAL is now purely striation contrast.
// 1.0 IS THE NEUTRAL POINT, not a bright setting: the pedestal rides the same
// water HG phase as the term it replaces, so at 1.0 a submerged step receives
// exactly the direct light it used to (the beam tint aside). Below 1.0 the
// background between the filaments is deliberately darkened; 0 = pure caustic
// modulation (black between the filaments).
#define UW_SHAFT_BASE 1.0 // [0.0 0.25 0.35 0.5 0.75 1.0 1.5]
// Eye OUTSIDE the water (UW_SHAFTS_UNIFIED = 1 only): TARGET scattering
// coefficient of the beam, in units of 0.008/block. The march weights a step
// with the step's OWN density: with a dry eye that is the air haze the ray
// also crosses PLUS the air-side submerged coefficient 0.008/block (kept low
// on purpose - it is what protects the grazing sunset mirror), while a diver
// integrates the water coefficient ~0.026/block. The compensation is therefore
// a RATIO, not a constant: the beam is multiplied by (this * 0.008) divided by
// the density the step really carries, which is why the default is 3.0
// (3 x 0.008 = 0.024 ~ the water coefficient) even though the beam is only
// ~1.7-1.9x too dim at the shipped defaults - the air haze already supplies
// the rest, and supplies more of it in rain or in a fog bank. The air part is
// taken WITHOUT the wMirror weighting, so the tuned transmittance, the grazing
// relief riding on it and the two half-res endpoints are untouched.
// 1.0 = target 0.008/block, i.e. no compensation beyond the haze.
#define UW_SHAFT_OUT_GAIN 3.0 // [1.0 1.5 2.0 3.0 4.0 6.0]
// Eye OUTSIDE the water (UW_SHAFTS_UNIFIED = 1 only): MAXIMUM sub-samples of
// the caustic field per march step. From the bank the march is bounded by the
// OPAQUE floor rather than by UW_RAY_DISTANCE, so the water column often gets
// only 1-2 steps and the beams alias into TAA noise. These extra taps
// box-average the field over the step, which is the correct integral for the
// weight that step carries. The count FOLLOWS the step length (one tap per
// ~4 blocks, capped here), because that length is what decides the aliasing:
// ~5 blocks at VOLUMETRIC_QUALITY 3 (VQ3 re-stage) needs 2 taps, the 20-40
// block steps of quality 0/1 need the full budget. Each tap is weighted by its own surface
// window, so a tap that lands above the water contributes nothing instead of
// contributing the sharpest, strongest sample of the field. Submerged steps
// always use 1 (the step is already short there, and a diver must not pay).
// UW_SHAFT_SUBSTEPS : derive de SUNRAY_QUALITY (bloc AXES DE MENU, haut de ce fichier)
// Anti-starburst (a): 1 = the caustic god-ray term only applies to the march segment that
// is ACTUALLY submerged (wp.y below the surface). Otherwise the march (depthtex1 = opaque)
// crosses the surface and steps ABOVE the water receive sharp caustics (toSurf=0 ->
// beerR=1, shrp=1), producing a frozen radial starburst around the sun seen from below.
// 0 = legacy. Not in the menu.
#define UW_SURFACE_CLAMP 1 // [0 1]
// Anti-starburst (b): 1 = when STARING at the light source underwater (~<17 deg off axis),
// the caustic modulation of the shafts tends toward its mean, giving a smooth halo around
// the disc instead of hard radial rays; tilted columns off axis are untouched.
// 0 = legacy. Not in the menu.
#define UW_SUNGAZE_SOFT 1 // [0 1]
// Anti-starburst (c): 1 = lens flare CUT underwater (there is no lens flare below the
// surface; refraction and the Snell window do that job). 0 = legacy. Not in the menu.
#define UW_FLARE_CUT 1 // [0 1]
// ---- UW_SUN_COHERENT: ONE refracted sun direction for every underwater term ----
// Under water the sun does NOT sit where lightW says. lightW is
// normalize(mat3(gbufferModelViewInverse) * shadowLightPosition), the AIR direction the
// shadow map is built on; the light that actually reaches a submerged point crossed the
// surface and was bent by Snell, so it arrives from asin(sin(theta_air)/1.3333), which
// saturates at 48.59 deg off vertical however low the star sits. Any underwater term still
// fed the RAW lightW draws its structure at theta_air -- 70 deg off vertical for a sun at
// 20 deg of elevation, i.e. 21 deg OUTSIDE the physical cone -- and therefore lands beside
// the terms that DO refract (the caustic net, the sheaf mask, the water-column glow, which
// all go through vlCa4Offset / refract() already). That is the residual "god rays that do
// not follow the sun".
// 1 = every submerged term shares the SINGLE direction uwSunRefract(lightW)
//     (lib/water.glsl), whose xz/y * depth slide is EXACTLY vlCa4Offset's, so the beams,
//     their in-scatter lobe, their halo softening and the shadow bands that carve them are
//     one geometry:
//       - HG phase of the unified beam and of its pedestal (phaseW),
//       - striation phase floor (phaseShaft),
//       - anti-starburst gaze test (UW_SUNGAZE_SOFT),
//       - direct in-scatter of a submerged step (the surface window),
//       - SHADOW PROBE: the occlusion of a submerged step is tested where the refracted
//         ray CROSSES THE SURFACE, not at the step itself, so the shadow of a bank / a
//         boat / a cliff enters the water at the same 48.59-deg-capped angle as the shafts
//         instead of at the air angle. Consequence, stated plainly: an occluder that is
//         ITSELF submerged (a wreck, a coral head between the step and the surface) stops
//         casting a beam shadow. It used to cast one at the WRONG angle; the divergence
//         between the two probes is ~0.22 block per block of column at this pack's noon
//         and ~1.75 at a 20-deg sun, so shallow water barely moves and deep water -- where
//         nothing floats above the diver anyway -- is where the fix shows.
// 0 = exact previous behaviour (every term above back on the air direction).
#define UW_SUN_COHERENT 1 // [0 1]
// ---- UW_SHAFT_FIX3: the beams and the CAST SHADOW must be ONE geometry ----
// UW_SUN_COHERENT above unified every underwater term on the SNELL-refracted axis. That is
// the physically right axis, and it is NOT the axis this renderer draws shadows on. There
// is exactly ONE occlusion structure in the pack -- the shadow map, rasterized along
// shadowLightPosition, i.e. the AIR direction -- and it is what draws the player's shadow
// on the sea floor (shadowEntities / shadowPlayer are both true, shaders.properties). So a
// diver saw his own shadow leave him at theta_air while the beams around him ran at
// theta_t: same AZIMUTH (both slides are built on normalize(lightW.xz)), but 25.19 deg
// apart in ELEVATION at a 20-deg sun (70.00 deg air vs 44.81 deg refracted) and 12.97 deg
// at 45 deg (45.00 vs 32.03). That gap IS the reported "the god rays still do not come from
// the sun": nobody can see theta_t, the observer compares the beams with the one
// directional object he CAN see, his own shadow.
// Refracting the shadow instead is not available: it would take a second shadow map
// rasterized along the refracted ray. So the beams move onto the shadow map's axis, and the
// three reported symptoms close together:
//   (A) DIRECTION. Every term that gives the beams an apparent direction rides
//       uwShaftAxis(lightW) (lib/water.glsl) = the shadow map's own axis: the column anchor
//       (cprj / lookU), the shared underwater light vector uwLightW and everything built on
//       it (HG phase of the beam and of its pedestal, striation phase floor,
//       UW_SUNGAZE_SOFT vanishing point, LOCK==0 blade basis), plus the three CAUSTICS_V4
//       floor sites so a beam still lands on the spot it lights. Residual error: the
//       max(lightW.y, 0.15) floor of the slide -- the value the v3 projection already
//       shipped -- caps the slope at 6.60 block/block, so between the beam gate
//       (lightW.y > 0.05, 2.87 deg) and 8.63 deg the axis is up to 5.66 deg too flat; above
//       8.63 deg the agreement is EXACT. DEBUG_VIEW 27 paints that residual in RED.
//   (B) OCCLUSION. With the beams back on the shadow map's axis the submerged shadow probe
//       returns to the STEP'S OWN position, so the player -- who IS in the shadow map --
//       occludes the beams again, and the dark notch he cuts in them is the same object as
//       the shadow he casts on the floor. UW_SUN_COHERENT's surface probe consulted the
//       shadow map at the surface crossing point, which by construction ignores EVERY
//       occluder between the step and the surface: that is why beams went through him.
//   (C) FAIL-OPEN. Out of the shadow map, or past its frustum Z, the march keeps the fog's
//       fail-open (vis = 1.0) because a false dark anti-sun shaft in the haze is worse than
//       a missing one. On the BEAM the same fail-open is a light leak: it claims full
//       sunlight exactly where there is no occlusion data, which is how a wide beam crosses
//       solid terrain. The beam term is now weighted by shOK, the probe's own validity
//       (0 outside the map, 0 past the frustum Z, smooth over the last 0.02 of the
//       distorted map. Solved on the EXACT ACTIVE distortion -- 1 - sp = 0.02 means
//       u = sc/f = 0.96, ramp = (1 - h(0.96)) * shadowDistance with h the inverse curve of
//       lib/distort.glsl : 31.5-48.8 blocks across the shadow tiers at the shipped plateau
//       defaults L2/R0 (15.2 at the narrowest of the 64 axis couples, L0/R0 at SQ0), and
//       37.6-112.9 on the legacy curve at S=0.90. NOT the 7.7 blocks once written here,
//       which linearised sp as if the distortion factor were 1.0 at the border. Either way
//       it is wider than causticShaftMask's 3-6 block blades spaced 4-10, so the beam dies
//       without cutting a ring; the price is shOK 1.00 (plateau curve; legacy paid 0.818)
//       at the end of the 160-block dry march at SQ1, and 0.47 (legacy 0.537) at the end
//       of a 112-block diver march at SQ0). The surface probe made this
//       far worse: it pushed the tap up to 1.42x the
//       column length away from the step (a 30-block column probed 42 blocks off), i.e.
//       straight out of the map. Fog, ambient and every air term keep the fail-open.
// 0 = exact previous behaviour, bit for bit (refracted axis, surface probe, and the fog
//     fail-open left on the beam).
#define UW_SHAFT_FIX3 1 // [0 1]
// Caustic treatment with view distance. With CAUSTIC_BLUR_FADE=1 this factor doses the
// distance BLUR (40..110 blocks from above, 20..56 underwater) plus a slight hold-back
// (x0.75 far away). With CAUSTIC_BLUR_FADE=0 it is the legacy ALPHA fade 48..120 (28..64
// underwater). 0.0 = no treatment. Not in the menu.
#define CAUSTIC_DIST_FADE 1.0 // [0.0 0.5 1.0]
// "Fade to blur" caustic policy: 1 = distance SOFTENS the web (waveCausticSoft) instead of
// extinguishing it, with lowered thresholds (-0.30 -> -0.22 surface site, 0.25 -> 0.20
// chroma sites), depth extinction pushed back ~3-4 blocks (exp(-0.22*d) -> exp(-0.13*d)),
// a tighter shallow fade (0.05..0.55 block) and cap 0.32 -> 0.38.
// 0 = previous policy. Not in the menu.
#define CAUSTIC_BLUR_FADE 1 // [0 1]
// Caustic fade in VERY shallow water (bottom seen through the surface): the light has not
// focused yet (ripple focal distance ~1 block), so below 0.10 block of column there is
// nothing and full strength is reached at ~1.1 block. This stops shallow sand from
// saturating to white. 1.0 = full fade, 0.0 = no fade. Not in the menu.
#define CAUSTIC_SHALLOW_FADE 1.0 // [0.0 0.5 1.0]
#define UNDERWATER_FX
//#define UW_VIGNETTE
#define UW_PARTICLES
#define WATER_LEVEL 63.0 // [-200.0 -150.0 -100.0 -64.0 -32.0 -16.0 0.0 16.0 32.0 48.0 63.0 96.0 128.0 160.0 200.0]
// PER-PIXEL water detection (fixes cyan patches in dry ravines below Y63):
// 1 = water effects seen from outside the water measure REAL water (shadow map water RGB
// tag + delta-z, colortex2 screen probes) instead of assuming "below Y63 = underwater".
// 0 = legacy behaviour. With the fix on, WATER_LEVEL only serves as an altitude reference
// for the mists (ATMO/CAVE/HEIGHT_FOG, SEALEVEL_MIST) and for eye-submerged heuristics.
// Kept an int so it can be used in #if (WATER_LEVEL is a float and cannot).
#define PIXEL_WATER_FIX 1 // [0 1]
// UW_RAY_DISTANCE: derived from VOLUMETRIC_QUALITY

// ============ GLASS ============
#define GLASS_EFFECTS
// Glass refraction/distortion OFF by default (user request). Passe "MEN" :
// WATER_REFRACTION est desormais OFF par defaut lui aussi (toute refraction du
// pack est livree eteinte), et le site verre de composite1 est passe sous
// "if (GLASS_REFRACTION != 0.0)" (branche constante, morte a 0.0) : a OFF le
// verre ne paie plus ni les 2 taps de profondeur ni la re-lecture colortex0
// qu'un offset nul payait quand meme. Se regle A LA MAIN ici (dial hors menu).
#define GLASS_REFRACTION 0.0 // [0.0 0.25 0.5 1.0 1.5 2.0 3.0 5.0 8.0]
#define GLASS_DISTORTION 0.0 // [0.0 0.5 1.0 2.0 3.0 5.0 8.0]
#define GLASS_ROUGH_REFLECT
// GLASS_SEE_THROUGH: a translucent pane must not SWALLOW the treatment of what
// stands behind it. A pane writes its OWN material flag (0.7) over the water
// flag of the lake behind it and its OWN depth into depthtex0, so that pixel
// skipped the water model entirely (no absorption, no veil, no tint, no surface
// mirror) and every distance fog priced the ray at the pane, 1-3 blocks away,
// instead of the surface behind it -- the "everything disappears through glass"
// report. 1 = the hidden segment is rebuilt from depthtex1: haze over the WHOLE
// path, then the shared water column, then the pane's own tint and reflections
// on top. 0 = legacy behaviour, bit-identical.
#define GLASS_SEE_THROUGH 1 // [0 1]

// ============ PLANET ============
#define PLANET_RADIUS 9000.0 // [1000.0 3000.0 5000.0 9000.0 15000.0 30000.0 100000.0 1000000.0 10000000.0]
//#define CLOUD_CURVATURE

// ============ CLOUDS ============
#define VOLUMETRIC_CLOUDS
// VC_SAMPLES: derived from CLOUD_QUALITY
// VC_COVERAGE: fraction of the sky covered. 0.70 = heavily clouded,
// 1.00 = overcast, 0.20 = a few scattered clouds.
// At 0.40 the cumulus are SEPARATE masses with blue sky between them; higher
// values merge them into continuous sheets.
// VC_COVERAGE : derive de CLOUD_AMOUNT (bloc AXES DE MENU, haut de ce fichier)
// VC_OPACITY: opacity of the cloud material. 1.0 = semi-transparent (light),
// 3.0 = solid clouds, 8.0 = fully opaque (stormy).
#define VC_OPACITY 2.0 // [0.1 0.5 1.0 1.5 2.0 3.0 5.0 8.0 12.0 20.0 50.0]
// VC_RENDER_DISTANCE: cloud draw distance in blocks, derived from CLOUD_QUALITY
// (700 / 900 / 1400 / 1800). There is NO 1000-block cap -- an old note here
// claimed one; the only clamps in lib/clouds.glsl are the slab exit and the
// scene maxDist ("t1 = min(min(t1, t0 + VC_RENDER_DISTANCE), maxDist)"), and
// the 1000 that appears there only picks the edge-fade start. The tier value
// really is what bounds the march, which is why VC_SAMPLES has to rise with it
// (see the CLOUD_QUALITY block at the top of this file).
// Layer 1 (cumulus) raised by 60 blocks (150 -> 210): a taller sky, cumulus
// tops at 370 leaving a 45-block gap under the altocumulus slab.
// VC36 : +25 blocs de plus (210 -> 235), demande utilisateur. C'est le DEFAUT
// DE MENU qui bouge, PAS un decalage derive : VC_BASE a des dizaines de
// consommateurs qui doivent bouger ENSEMBLE (bake prepare.fsh, ombre au sol
// cloudShadow, ancrage de reprojection CT_ANCHOR, re-march composite1, VL,
// ombre portee sur les nuages), et un seul #define les sert tous. Verifie :
// aucun 210 en dur dans le pack (grep), et l'ecart avec la couche alto reste
// sain -- VC2_ALTO_H = CLOUD_ALTO_HEIGHT + 50 = 465, donc 465 - (235 + 160)
// = 70 blocs de ciel entre le sommet des cumulus et la base de l'alto (95
// avant). Rollback : par le menu, ou en remettant 210.0 ici (VC36 = 0 ne le
// couvre pas, c'est une option de menu).
#define VC_BASE 235.0 // [64.0 120.0 140.0 150.0 160.0 192.0 210.0 235.0 256.0 384.0 512.0 1024.0]
// Thick slab (160) gives real budding towers instead of flat pancakes.
#define VC_THICK 160.0 // [20.0 60.0 90.0 120.0 160.0 256.0 384.0 512.0]
#define VC_DENSITY 1.0 // [0.0 0.1 0.3 0.5 0.75 1.0 1.25 1.5 2.0 3.0 5.0 8.0 12.0]
#define VC_WIND 1.0 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0 3.0 4.0 6.0 10.0 20.0]
#define VC_GROUND_SHADOWS
#define CLOUD_SHADOW_DARKNESS 0.75 // [0.0 0.25 0.4 0.5 0.6 0.75 0.85 0.95 1.0]
#define CLOUD_SHADOW_SOFTNESS 1.0 // [0.0 0.5 1.0 1.5 2.0 3.0]
// CLOUD_SHAFTS (bloc "RAYONS DE NUAGES", plus haut) : sa porte derivee
// CLOUD_SHAFTS_ACTIVE a besoin de VC_CUMULUS_SHAPES / VC_TEXTURED et vit donc
// plus bas, juste apres eux.
// Perf: cloud self-shadowing in 3 steps instead of 4 (cheaper, slightly softer).
//#define CLOUD_FAST_SHADOW
// Silver lining: cloud edges flaring toward the sun (forward scatter).
//#define CLOUD_SILVER_LINING
// CLOUD_EDGE_FADE: soft cloud fade at the render distance, removing the visible dome/arc
// where the march stops abruptly. Recommended ON; undefine for the original behaviour.
#define CLOUD_EDGE_FADE
#define CLOUD_BRIGHTNESS 1.0 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 2.0 3.0 5.0 8.0]
// ---- CONFIG_CLOUDS appearance dials: cumulus/alto SHADING only (lib/clouds.glsl).
// Density fields and masks are untouched - cloudShadow (lib/lighting.glsl)
// mirrors the cumulus mask and must keep matching. Defaults = exact current render.
// Brightness of the sunlit cumulus tops (scales the top ambient term).
#define CLOUD_WHITE 1.0 // [0.8 0.85 0.9 0.95 1.0 1.05 1.1 1.15 1.2]
// Brightness of the shaded cumulus bellies.
#define CLOUD_BELLY_BRIGHT 1.0 // [0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4]
// Blue bias of the belly shade: >1 cooler/bluer, <1 warmer/greyer.
#define CLOUD_BELLY_COOL 1.0 // [0.7 0.8 0.9 1.0 1.1 1.2 1.3]
// Silver-lining strength (sunward edge flare); stacks with VC_CUMULUS_SILVER.
#define CLOUD_SILVER 1.0 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 2.0]
// Brightness of the altocumulus layer (layer 2, volumetric and 2D variants).
#define CLOUD_ALTO_BRIGHT 1.0 // [0.7 0.8 0.9 1.0 1.1 1.2 1.3]
// ---- VC2 (HORS MENU) : refonte visuelle du cumulus TEXTURE (champ + eclairage).
// 1 (defaut) = profil VC2 : plancher de colonne releve (0.16 -> 0.22 de la
// dalle, 26 -> 35 blocs), LOBES moyenne echelle du sommet (tap x3.7 de la
// texture de base - c'est la silhouette chou-fleur qui manquait), remap de
// couverture raidi (bord de densite 23 -> 16 blocs, mesure), epaules par
// CELLULE (hauteur relative de colonne - la v5 les calculait sur la hauteur de
// DALLE : nulles sur une crepe), multiscatter 3 octaves (coeurs blancs, +126%
// de lumiere mesuree a od 220) + ambiante/assombrissement de base par hauteur
// RELATIVE (une crepe v5 etait "ventre" de sa base a son sommet -> le voile
// gris du rapport utilisateur). cloudShadow / cloudShadowCheap / sondes VL
// suivent par construction (helpers partages, lib/lighting.glsl).
// Ne s'applique qu'au chemin VC_CUMULUS_SHAPES=1 / VC_TEXTURED=1 ; les
// fallbacks proceduraux (VC_TEXTURED=0, VC_CUMULUS_SHAPES=0) restent v5
// verbatim dans les deux positions du gate.
// 0 = chaine v5 verbatim (SPIR-V identique aux baselines, preuve harnais).
#define VC2 1 // 0 = rollback chaine cumulus v5 verbatim (gate hors menu)
// ---- VC3 (HORS MENU, NICHE sous VC2) : champ de la couche 1 en vrai 3D.
// Verdict utilisateur sur le champ v2 : "un diagramme / des bulles" - champ 2D
// EXTRUDE (meme silhouette a toutes les hauteurs : IoU des coupes hR 0.25 /
// 0.75 = 0.86, mesure). VC3 : la carte meteo 2D (acquis v2 conserves :
// cellules x1.6, couverture x0.85, bords nets, hauteurs de colonne) ne donne
// plus que l'ENVELOPPE ; le VOLUME est defini par une texture 3D perlin-worley
// TUILANTE generee offline (textures/cumulus_shape3d.bin, 128^3 RG8, 4 MiB :
// R = billows multi-echelle, G = erosion worley HF, canaux egalises en rang) :
// un cumulus = agregat de bulles convexes, seuil d'iso-surface qui MONTE avec
// la hauteur relative de colonne -> domes separes au sommet, franges en poufs
// detaches, surplombs reels, silhouette differente a chaque hauteur (IoU 0.17
// apres refonte - vc3_render.py, preuve visuelle vc3_render_side.png).
// L'ECLAIRAGE v2 (multiscatter 3 octaves, powder, double lobe, ambiante par
// cellule) est conserve tel quel ; l'ombre au sol est modulee par 1 tap du
// vrai volume (vc3ShadowMod, lib/lighting.glsl). Ne s'applique qu'au chemin
// VC_CUMULUS_SHAPES=1 / VC_TEXTURED=1 (comme VC2). VC3=0 = champ VC2-v2
// verbatim (hashes vc3_pre_defaults.txt) ; VC2=0 = v5 verbatim
// (vc2_baseline.txt) - VC3 est ignore quand VC2=0.
#define VC3 1 // 0 = rollback champ cumulus VC2-v2 verbatim (gate hors menu)
// ---- VC32 (HORS MENU, NICHE sous VC2) : PROFONDEUR des cumulus.
// BUG MESURE (vc32_aspect.py, rejeu du vrai cumulus_base.bin sur 7200 blocs) :
// le pilote de hauteur vlCumulusTiers est nourri par une EROSION PAR MINIMUM
// sur des rayons indexes sur VL_CUM_RAD ; le boost de cellules x1.6 de la v2 a
// porte ce rayon a 224 blocs, si bien que le minimum sur l'anneau tombe a zero
// presque partout : y2 median = 0.000, p90 = 0.008 A L'INTERIEUR des masses.
// Toutes les colonnes retombaient donc sur leur plancher (0.22 + 0.08*covS) :
// 45 blocs de haut, MEDIANE ET P90 CONFONDUES, pour des masses de 442 blocs de
// large (moyenne ponderee-aire) => rapport hauteur/largeur 0.11 quand la photo
// de reference (cumulus mediocris) est a ~0.45. Le champ 3D VC3 sculptait donc
// de vraies bulles A L'INTERIEUR D'UNE CREPE : d'ou le verdict utilisateur
// "on dirait un diagramme / des bulles".
// CORRECTIF, a COUT NUL (memes 9 taps, memes rayons, autre combinaison) :
//  (a) le pilote passe du MINIMUM a la MOYENNE ponderee du meme voisinage
//      (0.34 centre + 0.36 anneau interne + 0.30 anneau externe) : il mesure
//      "a quelle profondeur dans la masse suis-je", donc il DOME le sommet
//      (haut au coeur, bas au bord) au lieu de saturer a zero ;
//  (b) rayons x VC32_RADK : l'echelle du dome se decorrele de la taille de
//      cellule, qui avait tue la mesure ;
//  (c) transfert VC32_SPAN/VC32_GAMMA a la place des budgets par palier.
// VC_THICK reste a 160 : teste en rendu offline a 160 / 210 / 260, epaissir la
// dalle avec des masses aussi larges donnait une BANQUE COUVERTE lourde, pas
// des cumulus ; c'est la largeur qu'il fallait reduire (VC32_CELL_K), pas la
// dalle qu'il fallait monter. Aucun changement de menu, aucun cout de march en
// plus, et l'ecart a l'alto (465) reste celui de la v2.
// GARDE-FOU ANTI-AIGUILLE conserve, et par construction : une moyenne de
// voisinage est FAIBLE sur une petite masse isolee -> elle reste basse
// (mesure : pire masse < 150 blocs a un rapport hauteur/largeur de 1.13).
// MESURES (vc32_final.py / vc32_cost.py / vc32_spikes.py, rejeu du vrai
// cumulus_base.bin + de la vraie texture 3D) :
//   avant : 171 masses, ciel 20.3 %, corde 442, colonnes 47 (p90 57), 0.11/0.13
//   apres : 348 masses, ciel 20.5 %, corde 297, colonnes 103 (p90 138),
//           rapport 0.35 moyen / 0.47 au dome = la cible photo.
// COUT : le nombre de PAS de march est inchange ; la part d'echantillons
// eclaires passe de 0.63 a 1.10 par rayon (x1.76) MAIS les cellules plus
// etroites font passer les sorties rapides "ciel clair" (1 tap) de 69.4 % a
// 81.9 % des echantillons - le modele de cout donne un total legerement
// INFERIEUR a l'actuel. Aucun tap ajoute, aucune option de menu touchee.
// ARTEFACT BORNE, ASSUME : donner de la hauteur multiplie le volume nuageux
// (3.0 % -> 7.2 % du volume de dalle), donc les filaments fins qui existaient
// deja se voient davantage : composantes fines et hautes 0.08 % -> 0.19 % du
// volume nuageux, pire rapport 1.6 -> 3.7 (56 blocs de haut pour 15 de large).
// Verifie : ce n'est PAS l'erosion (balayage de sa force au sommet et de la
// frange fine : aucun effet mesurable sur ce compte), et le prototype "appui
// basse frequence + fermeture spherique" ne l'ameliore pas non plus (teste,
// pire rapport 4.8) - a rouvrir seulement si l'utilisateur les voit encore.
// 0 = pilote v2 (erosion par minimum + budgets par palier) verbatim.
#define VC32 1 // profondeur cumulus: pilote de hauteur par moyenne de voisinage (0 = v2 verbatim)
// Rayons du voisinage du pilote, en fraction de ceux de l'erosion v2.
#define VC32_RADK 0.7 // rayon du dome (plus BAS = domes plus locaux et plus hauts)
// Amplitude du dome, en unites de colH (le plancher 0.22 vient de clouds.glsl).
#define VC32_SPAN 0.82 // hauteur max ajoutee au plancher de colonne
// Courbure du transfert (<1 = les masses moyennes montent plus tot).
#define VC32_GAMMA 0.75 // gamma du transfert profondeur -> hauteur
// Correction de la taille de cellule v2 (x1.6) : a hauteur enfin utilisable,
// des masses de 442 blocs restent des BANQUES fusionnees (rendu offline :
// couvert lourd) au lieu des entites distinctes de la photo. Ce facteur ramene
// les cellules a ~1.15 fois la taille v5 : masses ~330 blocs pour 100-140 de
// haut (rapport ~0.30/0.43, la cible photo) et du bleu franc entre elles. Le
// nuage est BIEN PLUS GROS en volume qu'en v2 (3x plus haut), pas en largeur.
#define VC32_CELL_K 0.66 // taille de cellule relative au boost v2 (1.0 = v2)
// ---- CT_ANCHOR (HORS MENU) : plan d'ancrage de la reprojection temporelle.
// BUG UTILISATEUR : "un effet de transparence, je vois les nuages derriere les
// nuages de la premiere couche". VERIFIE que ce N'EST PAS de la transparence :
// la transmittance mediane a travers un nuage est passee de 0.040 a 0.005 avec
// VC32 (vc33_opacity.py) - les nuages sont devenus PLUS opaques, pas moins.
// C'est donc un DEDOUBLEMENT de la resolution temporelle demi-res : elle
// reprojette l'image precedente en supposant tout le ciel sur UN plan, et ce
// plan etait le milieu geometrique de la dalle (y = 290) alors que la surface
// visible des nuages est a y ~ 229 (fraction 0.121, mesuree par la hauteur ou
// la transmittance tombe a 0.5). 60 blocs d'erreur -> l'historique est lu au
// mauvais endroit de l'ecran -> on melange le nuage voisin. Le defaut est
// ANCIEN (0.062 avant VC32) ; VC32 l'a rendu voyant. Details au site.
// 0 = ancrage mi-dalle (comportement precedent).
#define CT_ANCHOR 1 // ancrage reprojection sur la surface visible (0 = mi-dalle)
// Fraction de dalle vue d'EN DESSOUS (le cas courant) : mesuree, 0.121.
#define CT_ANCHOR_LOW 0.12 // ancrage quand on regarde les nuages par en dessous
// Vue d'AU-DESSUS : les domes d'abord. Deduit de la distribution des hauteurs
// de colonne (p90 138/160 = 0.86 moins l'epaule), non mesure directement.
#define CT_ANCHOR_HIGH 0.75 // ancrage quand on survole la couche
// ---- CT_V2 (HORS MENU) : POIDS DE L'HISTORIQUE DE LA RESOLUTION NUAGES.
// CT_ANCHOR a corrige le PLAN ; il ne pouvait pas corriger le fait qu'un plan
// UNIQUE ne represente pas une dalle de 160 blocs (l'etalement mesure des
// hauteurs de surface visible va de 0.054 a 0.304 de la dalle). L'utilisateur
// a d'ailleurs re-signale le dedoublement apres CT_ANCHOR. Au lieu de faire
// confiance au plan de la meme facon en toute circonstance, le blend quitte
// 0.18 a proportion de ce que la reprojection ne merite pas :
//  (a) la VITESSE ECRAN du texel, mesuree sur place (prevUV et la position
//      courante sont deja la) : per-texel et EXACTE, rotation ET translation.
//      Chaque image de rotation coute a l'historique un reechantillonnage
//      bilineaire de plus, et a 82 % de retention il en accumule ~5 : la
//      couche demi-res se liquefie des qu'on tourne la tete. "Mieux vaut du
//      bruit d'interleave que des fantomes."
//  (b) la COHERENCE DE PLAN : distance entre la reprojection ancree et la
//      reprojection "ciel infini" (rotation pure) du MEME rayon. Nulle par
//      construction sous rotation pure : ce terme isole exactement la part
//      parallaxe, la seule erreur qu'un plan unique puisse commettre.
// MESURES (modele 1D de la chaine complete, scratchpad cl_pick.py) : erreur du
// bake RESOLU contre l'anticrenelage exact, et energie de fantome.
//   camera posee       0.1190 -> 0.1137   88.9 % -> 88.9 %  (a reste 0.18)
//   20 deg/s           0.1072 -> 0.0779   66.7 % -> 52.3 %
//   60 deg/s           0.1047 -> 0.0537   33.3 % -> 13.0 %
//   140 deg/s          0.1049 -> 0.0537   13.9 % ->  5.2 %
//   marche 5 blocs/s   0.0891 -> 0.0875   70.9 % -> 71.0 %
//   45 deg/s + marche  0.0711 -> 0.0524   27.8 % -> 15.9 %
//   vol 40 blocs/s     0.1146 -> 0.0648   54.2 % -> 33.8 %  <- (b) porte tout
//                      (sans (b) : 0.1059 / 51.6 % -- c'est le SEUL cas ou la
//                       parallaxe passe le plancher de bruit, voir plus bas)
// Prix assume : scintillement +6 a +18 % selon le cas.
// LIMITE HONNETE DE (b) : a la MARCHE (5 blocs/s) la parallaxe d'une couche a
// 250 blocs ne vaut que ~0.14 px/image, SOUS le plancher de bruit fp32 de
// "wp - previousCameraPosition" loin de l'origine (~0.2 px vers 1e6 blocs). La
// zone morte CT_V2_COH_PX0 rend donc (b) inerte a la marche : c'est un CHOIX,
// l'alternative etant de prendre du bruit de virgule flottante pour de la
// parallaxe et de desserrer la resolution temporelle en permanence loin du
// spawn. (b) sert au VOL, ou le plan unique est justement le plus faux.
// ANCRE PAR TEXEL (la vraie solution structurelle) : ECARTEE, faute de place.
// colortex15 est RGBA16F et ses QUATRE canaux sont pris par le bake (rgb
// premultiplie + couverture) ; la distance d'accumulation n'existe que dans
// prepare.fsh, qui devrait l'ecrire, et il n'a ni canal ni cible libre.
// 0 = prepare1.fsh VERBATIM. HORS menu, SANS liste.
#define CT_V2 1 // gate hors menu, sans liste (non enregistre par Iris)
// Blend vise quand la reprojection est franchement douteuse (1.0 = bake brut).
#define CT_V2_BLEND_HI 1.0 // poids maximal de l'image courante
// Vitesse ecran du texel (px pleine res / image) ou le blend commence a
// monter, et ou il atteint CT_V2_BLEND_HI. 1.0 px/image = ~8 deg/s : en
// dessous, la resolution temporelle garde ses 0.18 livres.
#define CT_V2_V0 1.0 // debut de la montee du blend
#define CT_V2_V1 6.0 // fin de la montee du blend
// Divergence (px pleine res) entre reprojection ancree et reprojection infinie :
// ZONE MORTE en dessous de PX0 (plancher de bruit fp32, voir plus haut), plus
// aucune confiance a partir de PX1, et poids global du test. Mesures a
// 40 blocs/s : 0.5..2.0 -> 0.0648 ; 0.5..3.0 -> 0.0867 ; test coupe -> 0.1059.
#define CT_V2_COH_PX0 0.5 // zone morte du test de coherence de plan
#define CT_V2_COH_PX1 2.0 // divergence de plan saturant le test
#define CT_V2_COH_W 1.0 // poids du test de coherence de plan
// Elargissement de la boite min/max 3x3 du bake courant (livre : 0.10). La
// boite est batie sur un bake a marche reduite et depart interleave sur 4
// images : elle est deja plus large que le signal.
#define CT_V2_EXT 0.04 // elargissement relatif de la boite d'anti-fantome
// ---- VC_CAST_SHADOWS (HORS MENU) : les ombres PORTEES tombent sur les nuages.
// BUG UTILISATEUR : "mon ombre n'apparait pas sur les nuages". VERIFIE : la
// marche des nuages n'echantillonnait la shadow map NULLE PART (aucune
// occurrence de shadowtex dans lib/clouds.glsl) - les nuages n'avaient donc
// que leur auto-ombrage (la marche vers le soleil), jamais une ombre venue de
// l'exterieur. Le cas qui compte est le vol AU-DESSUS de la couche : le joueur
// et le terrain sont alors entre le soleil et les nuages, et leur ombre doit
// se poser sur les domes (l'ombre d'avion sur la mer de nuages). Depuis le
// sol, la geometrie fait qu'il n'y a presque jamais d'occulteur entre le
// soleil et un nuage : le terme reste a 1 et rien ne change - c'est voulu.
// FAIL-OPEN STRICT : hors du cadre de la shadow map (XY ou Z), le nuage est
// ECLAIRE. Sans cela toute la couche lointaine, qui sort forcement du cadre,
// virerait au noir. Meme contrat que shadowVis1 (composite1) et que les
// ombres d'iles de lib/end_storm.glsl, qui utilise deja toShadowClipWorld.
// N'affecte QUE le terme solaire (direct + lisere) : l'ambiante du ciel ne se
// fait pas ombrager par le terrain.
// COUT : 1 tap par echantillon ECLAIRE, soit ~1.1 par rayon au bake demi-res.
// 0 = aucune ombre portee sur les nuages (comportement precedent).
#define VC_CAST_SHADOWS 1 // ombres portees sur les nuages (0 = auto-ombrage seul)
// Biais genereux : le recepteur est a 200+ blocs du plan ou la carte est la
// plus dense, et de l'acne a cette altitude se lirait comme du grain sur les
// domes. Exprime dans la meme unite que le biais de shadowVis1.
#define VC_SHADOW_BIAS 0.0015 // biais de profondeur de l'ombre portee sur nuage
// ---- VC33 (HORS MENU, NICHE sous VC2) : le COTON des cumulus + la VITESSE
// de la couche 1.
// VERDICT UTILISATEUR : "les nuages je les trouve trop smooth, pas l'effet
// nuage coton" et "ralentir la premiere couche de nuages, les cumulus".
//
// CE QUI A ETE MESURE (rejeu offline du VRAI champ et de la VRAIE texture,
// vc33_lib.py / vc33_measure.py, CLOUD_QUALITY 3, marche livree) :
//  (1) LA TEXTURE. Le canal R - celui qui DEFINIT le volume - n'a que 0.15 %
//      de son energie spectrale sous 12 blocs (91.9 % au-dessus de 40, 7.9 %
//      entre 12 et 40). L'iso-surface de R est donc LISSE sous 12 blocs par
//      construction. Le canal G en porte, lui, 44 % entre 4 et 12 blocs A SON
//      TAP x3 - la matiere fine EXISTE deja dans le fichier, elle n'etait
//      simplement pas utilisee la ou ca compte.
//  (2) OU VA L'IMAGE. 76 % de la contribution lumineuse vient d'echantillons
//      a d >= 0.95 : clamp((R - T)/0.15) SATURE a 5 blocs sous la peau. Or
//      TOUT le detail fin livre est gate sur la coquille (edge2 > 0.18, soit
//      d < 0.34), qui ne pese que 4.3 % de l'image. Deplacer l'iso-surface ne
//      peut donc toucher que le lisere ; le CORPS du nuage n'est module que
//      par le light march, qui n'echantillonne que R (cf. (1)). C'est LA
//      cause du "trop smooth", pas l'amplitude de l'erosion.
//  (3) AMPLITUDE. |grad R| median = 0.029 par bloc : la frange fine livree
//      (0.08 sur d) ne deplace la surface que de 0.41 BLOC, sur une
//      transition d'iso-surface qui fait deja 5.2 blocs d'epaisseur. Elle est
//      invisible par construction.
//  (4) BAKE. La marche livree (29 pas warpes + resolve temporel) ajoute a
//      elle seule 9.4 points de bruit sous 4 blocs (2.4 % -> 11.8 % de
//      contraste RMS) : tout detail sous ~4 blocs ne fait que creneler.
//      L'empreinte pixel au bake demi-res vaut d/385 blocs : un motif de
//      7 blocs tombe sous 2 px vers 1350 blocs de distance.
//
// CONCEPTION RETENUE : le coton est un terme de SHADING, pas de geometrie.
// Le champ de densite reste BIT-IDENTIQUE a VC32 - silhouette, cloudShadow,
// sondes csA/csB, vc3ShadowMod, CT_ANCHOR et le compte d'aiguilles sont
// intacts par construction (verifie : 47 composantes, 4 aiguilles, 0.33 % du
// volume, pire rapport 10.4 - identiques au bit pres, vc33_spikes.py).
// Deux octaves, a moyenne EXACTEMENT nulle (les deux canaux sont egalises,
// donc E[G] = 0.5) : la luminance moyenne du nuage ne bouge pas (mesure
// +-0.5 %), seule la MODULATION apparait.
//   . octave GROSSIERE 16-31 blocs : canal .g du MEME fetch RG que R, deja lu
//     pour l'erosion -> ZERO tap. Signe + : je suis DANS une bosse, donc
//     eclairee.
//   . octave FINE 5-10 blocs : le tap x3 du canal G, DECALE VERS LE SOLEIL de
//     VC33_SUNOFF blocs. Signe - : de la matiere entre moi et le soleil, donc
//     OMBRE DE CONTACT. C'est ce decalage qui fait lire du RELIEF plutot
//     qu'une texture plaquee (compare a l'offset nul en rendu : image plus
//     molle). Le tap existait deja mais n'etait paye que sur 8.4 % des
//     echantillons ; il l'est desormais sur tous ceux qui ont d > 0.
// MESURES APRES (fenetre a 0.36 bloc/px dans une masse, moyenne de 3 marches):
//   bande COTON 4-12 blocs  : 4.20 % -> 7.32 % de contraste RMS (+74 %)
//   bande LOBES 12-40 blocs : 11.10 % -> 13.58 % (+22 %)
//   bande GRAIN < 4 blocs   : 3.00 % -> 3.24 % (pas de crenelage ajoute)
//   modulation ajoutee      : 14.2 % RMS de la luminance, p5..p95 -25 %..+27 %
//   luminance moyenne       : -0.5 % (le terme est a moyenne 1 par dessein)
// COUT MESURE (CQ2, bake demi-res, vue large 40 deg) : le tap x3 passe de
// 0.039 a 0.456 par rayon, soit +0.42 tap 3D par rayon (+0.24 sur une vue
// horizon). A titre de comparaison VC_CAST_SHADOWS, deja livre, coute ~1.1
// tap par rayon. Sur un bake 960x540 cela fait ~218 k fetches de plus par
// image dans une texture de 4 MiB (elle tient en L2) : bien sous les 0.3 ms
// du budget. Aucun pas de march ajoute, aucune option de menu touchee.
// 0 = VC32 verbatim (aucun tap ajoute, aucun terme de shading).
#define VC33 1 // coton des cumulus : relief fin par shading + vitesse couche 1 (0 = VC32 verbatim)
// Force globale du coton. 0.45 : au-dela (0.55, 0.70 testes en rendu) la
// masse se lit comme une eponge ; en dessous (0.25) le chou-fleur s'efface.
#define VC33_STR 0.45 // force du coton
// Poids des deux octaves. La grossiere est gratuite, la fine porte l'ombre de
// contact ; 0.50/0.80 donne la hierarchie d'un vrai chou-fleur (teste en
// rendu contre 1/0, 0/1 et 0.8/1.0).
#define VC33_COARSE 0.50 // octave 16-31 blocs (tap deja lu, gratuit)
#define VC33_FINE 0.80 // octave 5-10 blocs (le tap x3, decale vers le soleil)
// Part appliquee a l'ambiante du ciel (le terme solaire la recoit en entier).
// 0.40 : les ventres a l'ombre restent lisses et propres, comme sur photo, et
// seules les faces eclairees prennent la texture.
#define VC33_AMB 0.40 // part du coton sur l'ambiante
// Decalage du tap fin vers le soleil, en FRACTION de la tuile du tap x3
// (VC3_TILE/3 = 104 blocs au defaut) : 0.016 x 312 = 5.0 blocs, soit environ
// une demi-longueur d'onde de l'octave fine. Exprime ainsi, il suit
// VC_CUMULUS_SCALE au lieu d'etre un nombre de blocs fixe qui deviendrait
// faux aux autres echelles.
#define VC33_SUNOFF_F 0.016 // decalage sunward du tap fin, en tuiles de forme
// Fondu de distance, en tuiles de forme (x312 au defaut : 998 et 1700 blocs).
// MESURE : sans fondu, le coton ajoute +2.5 points de scintillement residuel
// au-dela de 1200 blocs (17.7 % contre 15.2 % pour le livre, ecart entre deux
// resolves 4 images independants) ; avec, on retombe a 15.8 % a 1200-2000 et
// EXACTEMENT sur la baseline a 2000-3000. C'est le seuil des 2 px d'empreinte
// au bake demi-res : au-dela, le motif ne pouvait plus que creneler.
#define VC33_FADE0 3.2 // debut du fondu de distance, en tuiles de forme
#define VC33_FADE1 5.45 // fin du fondu de distance, en tuiles de forme
// ---- VITESSE DE LA COUCHE 1 (meme gate VC33).
// Le vent est UNE option de menu (VC_WIND) partagee par les trois couches,
// mais chaque couche a son propre vecteur de base : cumulus (7.0, 2.4), alto
// (11.0, 4.0), cirrus (18.0, 6.0). Ce facteur ne multiplie QUE la famille
// cumulus, donc alto et cirrus gardent leur vitesse, VC_WIND garde son sens,
// et le vent des plantes (qui n'utilise pas VC_WIND) n'est pas concerne.
// Au defaut VC_WIND = 1 la couche 1 derivait a |(7.0, 2.4)| = 7.4 blocs par
// seconde de temps monde ; x0.5 la ramene a 3.7 (une masse de 300 blocs met
// 81 s a defiler de sa propre largeur au lieu de 40).
// TOUS les consommateurs du vent couche 1 suivent le meme facteur, pas
// seulement le rendu : la carte meteo (vlCumulusWind -> couverture, lobes,
// cloudShadow, cloudShadowCheap, sondes csA/csB), le volume 3D
// (vc3ShapeWind -> densite ET vc3ShadowMod), les wisps d'albedo, l'erosion
// des bras non-VC3 et les chemins proceduraux. Le differentiel +6 % du volume
// sur la carte (VC_WIND * 1.06) est un RATIO : il est preserve.
#define VC33_SPEED1 0.5 // vitesse de la couche 1 cumulus (1.0 = avant VC33)
#if VC33 == 1
#define VC33_WIND (VC_WIND * VC33_SPEED1)
#else
#define VC33_WIND VC_WIND
#endif
// ---- VC34 (HORS MENU, NICHE sous VC33) : ENCORE plus de detail sur les
// cumulus + une couche ALTO plus petite et moins nombreuse.
// VERDICT UTILISATEUR apres essai de VC33 : "les nuages c'est deja mieux, mais
// rajoute ENCORE plus de details" et "reduire la taille des nuages de la 2e
// couche (alto), et moins de nuages".
//
// ---- PARTIE 1 : LA 3e OCTAVE, ET POURQUOI ELLE EST ANISOTROPE -------------
// La voie evidente (monter VC33_STR, ou VC33_FINE) avait deja ete rejetee EN
// RENDU a la ronde VC33 ("la masse se lit comme une eponge"). La mesure dit
// pourquoi : monter l'amplitude monte TOUTES les bandes ensemble, y compris
// celle des lobes 12-40 blocs qui porte la forme de la masse. Rejets chiffres
// (contraste RMS par bande, fenetre de 192 px dans une masse, vc34_sweep2) :
//   VC33_STR x1.3 : lobes 12-40 +8.8 %, COTON 4-12 +13.6 %  -> l'eponge
//   VC33_FINE 1.05: lobes 12-40 +7.2 %, COTON 4-12 +14.2 %  -> idem
//   3e octave     : lobes 12-40 +0.4 %, COTON 4-12 +13.0 %  -> selectif
// Une octave AJOUTE une echelle au lieu d'amplifier celles qui existent : le
// corps garde sa forme, seule la texture s'enrichit. C'est la voie retenue.
//
// MAIS une 3e octave ISOTROPE x6 (motif 2.5-5 blocs) SCINTILLE : le pas de la
// marche fait 15-30 blocs, donc d'une image a l'autre le jitter deplace
// l'echantillon de bien plus qu'une periode et le tap se decorrele
// completement -- +2.60 et +3.16 points de scintillement sur les tranches
// 0-600 et 600-1200 blocs (ecart entre deux resolves independants), au-dessus
// du budget. OBSERVATION QUI DEBLOQUE : le rayon est quasi HORIZONTAL (on
// regarde les nuages, pas le zenith), donc c'est la frequence HORIZONTALE
// seule qui fixe la decorrelation le long du rayon ; la frequence VERTICALE
// est presque gratuite en scintillement -- et c'est elle qui dessine les
// festons de chou-fleur a l'ecran. D'ou une octave ANISOTROPE (3, 6, 3) :
// 5-10 blocs a l'horizontale (la MEME longueur de correlation que l'octave x3
// deja acceptee par VC33) et 2.5-5 blocs a la verticale.
// A amplitude et cout EGAUX, mesure contre l'isotrope x6 :
//   COTON 4-12  : 7.39 % (iso) -> 8.39 % (aniso)   -- PLUS de detail
//   scintillement 0-600 / 600-1200 : +2.60/+3.16 -> +1.40/+2.04 -- MOITIE moins
// L'anisotrope domine l'isotrope sur les deux axes a la fois.
// CONTRAINTE DURE : chaque composante du multiplicateur doit etre ENTIERE. Le
// vent est mod(., VC3_TILE) ; une translation de VC3_TILE doit valoir un
// nombre ENTIER de periodes de texture, sinon le pli du vent saute. 3, 6, 9
// sont legaux ; 4.5 ne l'est pas.
// 0 = VC33 verbatim (aucun tap ajoute, aucune constante alto changee).
#define VC34 1 // encore plus de detail cumulus + alto plus petit/moins nombreux (0 = VC33 verbatim)
// Poids de la 3e octave, meme convention que VC33_COARSE / VC33_FINE (elle
// passe par le meme (2 * VC33_STR)). 0.70 est le PLUS GRAND qui tienne le
// budget de scintillement dans les DEUX regimes temporels, mesure :
//   A3    CLOUD_TEMPORAL=1 (defaut)   CLOUD_TEMPORAL=0 (48 pas)
//   0.65     +0.93 / +1.35               +1.34 / +1.69
//   0.70     +1.07 / +1.56               +1.55 / +1.97
//   0.75     +1.23 / +1.80               +1.77 / +2.24  <- depasse
// (tranches 0-600 et 600-1200 blocs ; budget +2 points par tranche.)
#define VC34_FINE2 0.70 // 3e octave de shading, 5-10 blocs a plat / 2.5-5 en hauteur
// Multiplicateurs de frequence de la 3e octave, en ENTIERS (cf le pli du vent
// ci-dessus). X et Z a 3 comme l'octave VC33 : c'est ce qui garde le
// scintillement bas. Y a 6 : c'est ce qui se voit.
#define VC34_SC_XZ 3.0 // frequence horizontale de la 3e octave (entier obligatoire)
#define VC34_SC_Y 6.0 // frequence verticale de la 3e octave (entier obligatoire)
// Fondu de distance PROPRE a la 3e octave, en tuiles de forme, donc PLUS
// PROCHE que celui de VC33 (3.2 / 5.45) puisque le motif est deux fois plus
// fin. L'empreinte d'un pixel au bake demi-res vaut d / 385 blocs : la
// composante verticale de 5.2 blocs tombe sous 2 px vers 1000 blocs, celle de
// 6 blocs vers 1155. 2.47 et 3.69 tuiles = 771 et 1151 blocs encadrent
// exactement cette zone. MESURE : au-dela de 1200 blocs le scintillement
// retombe a +0.19 point (CLOUD_TEMPORAL=1) contre +3.12 sans fondu.
// Le fondu sert AUSSI de porte de cout : au-dela de VC34_FADE3_1 le tap n'est
// pas paye du tout (le test est fait dans la boucle de marche, ou la distance
// est coherente d'un pixel a l'autre dans un warp).
#define VC34_FADE3_0 2.47 // debut du fondu de la 3e octave, en tuiles de forme
#define VC34_FADE3_1 3.69 // fin du fondu ET porte de cout de la 3e octave
// ---- DETAIL DE SILHOUETTE (piste (c) du brief).
// La frange fine livree (0.08) ne deplace la surface que de 0.41 bloc sur une
// transition d'iso-surface qui en fait 5.2 : elle etait invisible par
// construction (mesure VC33). Maintenant que le CORPS a du relief, la coquille
// peut en prendre. VC34_ERO3 remplace ce 0.08 et ne coute RIEN (c'est le meme
// tap gf, deja paye sur la coquille) ; VC34_ERO6 ajoute une octave x6 sur la
// coquille SEULE (0.047 tap par rayon, mesure).
// MESURE (rugosite du contour = perimetre / 4*sqrt(aire), 1 = carre lisse) :
//   VC33            4.091   liseré 1.94 bloc   alpha moyen 0.6155
//   ERO3 0.30       4.230   liseré 1.88        0.6142
//   + ERO6 0.16     4.325   liseré 1.85        0.6136
// AIGUILLES / FLOCONS (vc34_spikes.py, critere de vc32_spikes.py) : 3 a 5
// aiguilles contre 4 pour VC33, pire rapport 10.4 IDENTIQUE, volume nuageux
// 7.82 % -> 7.72 %. L'erosion CASSE les composantes filiformes au lieu d'en
// creer. Scintillement : +0.10 / +0.16 point, negligeable.
#define VC34_ERO3 0.30 // frange fine x3 sur la coquille (0.08 avant VC34, gratuit)
#define VC34_ERO6 0.16 // octave x6 de silhouette sur la coquille (1 tap, coquille seule)
// ---- CE QUI A ETE MESURE PUIS REJETE ------------------------------------
// (b') ASYMETRIE : creuser les ombres de contact plus que les bosses ne sont
//      claires (moitie negative x1.35). A scintillement egal (+1.23/+1.64)
//      elle n'achete que COTON +12.8 % contre +17.1 % pour la 3e octave a
//      +1.30/+1.71, ET elle monte les lobes 12-40 de 8.4 % (l'eponge, encore)
//      ET elle fait deriver la luminance moyenne de -2.4 % : le terme n'est
//      plus a moyenne nulle, il faudrait une constante de rattrapage qui
//      dependrait des poids d'octave. Domine sur tous les axes.
// (d) DECALAGE SUNWARD PROPORTIONNE A L'ELEVATION (offset plus long a soleil
//      bas). Cout nul, benefice nul : a 10 degres d'elevation, allonger
//      l'offset de 4.99 a 11.09 blocs fait passer la profondeur des ombres de
//      contact (p5 du coton) de -0.4252 a -0.4121, soit LEGEREMENT MOINS, et
//      le RMS du coton de 24.12 % a 23.45 %. La raison est structurelle : 5
//      blocs valent deja une demi-longueur d'onde de l'octave fine ; au-dela
//      on depasse la crete voisine et on se decorrele au lieu de s'aligner.
//      L'offset fixe de VC33 est deja au bon endroit.
// ---- BILAN VC34 vs VC33 (contraste RMS par bande, luma, cout) ------------
//   macro > 40 blocs  : 47.50 % -> 47.11 %  (-0.8 %)   forme intacte
//   lobes 12-40       : 13.98 % -> 14.44 %  (+3.3 %)   pas d'eponge
//   COTON 4-12        :  6.54 % ->  8.03 %  (+22.9 %)  <- la cible
//   fin 2-4           :  5.10 % ->  5.67 %  (+11.2 %)
//   grain < 2         : 10.83 % -> 11.92 %  (+10.1 %)
//   luminance moyenne : -0.21 % (les trois octaves sont a moyenne nulle)
//   clamp [-0.94, 1] : sature sur 0.000 % des echantillons
// SCINTILLEMENT (ecart entre deux resolves independants, par tranche) :
//   CLOUD_TEMPORAL=1 : +1.18 / +1.76 / +0.19 / +0.20 points
//   CLOUD_TEMPORAL=0 : +1.65 / +2.14 / +0.37 / -0.04 points
// COUT : +0.374 (3e octave, apres la porte de distance) + 0.047 (coquille)
//   = +0.42 tap 3D par rayon a CQ2, dans le budget de +0.5. Aucun pas de
//   marche ajoute, aucune option de menu touchee.
// ---- PARTIE 2 : LA COUCHE ALTO -------------------------------------------
// Le user veut les puffs alto PLUS PETITS et MOINS NOMBREUX. Deux leviers,
// choisis parce qu'ils sont ORTHOGONAUX (mesure sur le vrai vl_noise.bin,
// vc34_alto.py / vc34_alto_fin.py) :
//   . le ZOOM des features ne change QUE la taille : le seuillage d'un bruit
//     de valeur donne la meme aire a toute echelle (couverture 20.09 % ->
//     19.76 % a features x0.70, soit -1.6 %, du bruit) ;
//   . le masque BANK ne change QUE le nombre : corde moyenne 69.1 -> 68.5
//     blocs quand la couverture tombe de 20.09 % a 12.30 %. Et il ne durcit
//     AUCUN bord, sa maille faisant 1724 blocs.
// Le seuil de puff, lui, fait les deux mais RETRECIT la fenetre du smoothstep
// donc DURCIT les bords : ecarte comme levier principal.
// Enorme avantage du BANK : il est deja PARTAGE, constante pour constante,
// par les TROIS sites du contrat SYNC (dalle 3D altoDensity, variante 2D de
// highClouds, miroir haloVeilCov). Une seule constante pilote les trois, au
// lieu de recalibrer separement deux seuils de puff qui n'ont pas la meme
// fenetre (0.50-0.72 pour la dalle, 0.505-0.66 pour la 2D).
// CLOUD_ALTO_AMOUNT n'est PAS touche : c'est un curseur de menu et VC2_ALTO_AMT
// (= curseur x 0.8) garde exactement son sens.
// MESURE AVANT -> APRES (couverture = % de ciel ou l'opacite depasse 0.25 ;
// taille = corde moyenne des segments couverts, en blocs) :
//   dalle 3D  : couvert 20.09 % -> 14.84 % (x0.74)   corde 69.1 -> 47.9 b (x0.69)
//               corde mediane 42 -> 30 b, p90 162 -> 108 b, trou median 72 -> 60 b
//   variante 2D: couvert 11.17 % ->  7.83 % (x0.70)  corde 59.9 -> 41.8 b (x0.70)
//   halo 22 deg: anneau lisible sur 12.0 % -> 9.5 % du ciel (consequence
//               directe et voulue : moins de voile, moins de halo)
//   largeur de bord 13.8 -> 9.9 blocs : c'est le prix inevitable de "plus
//               petit" (des features x0.70 ont un gradient x1.43), pas un
//               durcissement ajoute par le seuillage.
#define VC34_ALTO_SIZE 0.70 // taille des puffs alto (1.0 = avant VC34)
// Bord bas du masque de nappes. 0.42 -> 0.475 retire 28 % de la couverture
// sans toucher a la taille ni aux bords. Balayage : 0.45 -> x0.83,
// 0.465 -> x0.76, 0.475 -> x0.715, 0.485 -> x0.67, 0.50 -> x0.60.
#define VC34_ALTO_BANK 0.475 // bord bas du masque de nappes alto (0.42 = avant VC34)
// ---- VC35 (HORS MENU, NICHE sous VC3) : COEUR PLEIN + SILHOUETTE A TOURELLES.
// VERDICT UTILISATEUR apres VC34 : "sa moitie droite est TRANSLUCIDE - on voit
// une structure gris sombre A TRAVERS la partie blanche" ; et "c'est cool il y
// a plus de details, mais c'est surtout la FORME GLOBALE qui manque de detail"
// (un DOME LISSE a une seule bosse, au lieu de tourelles de 30-80 blocs).
// ---- DIAGNOSTIC MESURE (vc35_diag.py, vc35_lib.py : modele hors ligne
// identique BIT POUR BIT a VC34 quand la porte est fermee) -----------------
// (1) LE VOLUME EST TROUE. Fraction de VIDE (d == 0) a l'INTERIEUR de
//     l'enveloppe (covS > 0.8), par tranche de hauteur relative hR :
//       hR    0.00  0.12  0.25  0.38  0.50  0.62  0.75  0.88
//       vide   46%   29%   36%   37%   40%   66%   98%  100%   (total 56.9 %)
//     Un tiers a 40 % du CORPS est vide, et le QUART SUPERIEUR de chaque
//     colonne est ANALYTIQUEMENT MORT : a hR = 0.875, covS = 1, le seuil
//     T = (1 - covS*profile) + 0.08 + 0.50*hR vaut 1.236 > 1, donc l'early-out
//     "if (T >= 1.0) return 0.0" tue tout. D'ou LES DEUX defauts d'un coup :
//       . un rayon traverse une succession de bulles et de vides -> il reste de
//         la transmittance -> ON VOIT A TRAVERS (les bulles arriere ombrees
//         vues par les trous des bulles avant = le "voile gris sombre") ;
//       . la silhouette du HAUT n'est pas celle des billows (il n'y a plus de
//         matiere pour eux a sculpter) mais l'iso-contour LISSE de T = 1, une
//         fonction analytique de (covS, hR) : un DOME, exactement le reproche.
// (2) TRANSMITTANCE DES RAYONS DE COEUR (corde d'enveloppe >= 150 blocs),
//     a la marche REELLE du bake (pas warpes + resolve 4 phases de
//     CLOUD_TEMPORAL, qui melange les ALPHAS et non les tau) :
//                          T mediane   T < 0.05   p90 de T
//       reference 512 pas    0.0000      89.6 %     0.058
//       CQ3 (29 pas, livre)  0.0000      85.2 %     0.256   <- 1 rayon sur 10
//       CQ2 (17 pas)         0.0000      73.1 %     0.506      laisse passer
//     La reference elle-meme ne plafonne qu'a 89.6 % : c'est bien le CHAMP qui
//     est poreux, pas seulement la marche. (L'extinction, elle, est SAINE :
//     tau median de reference 12.42 sur une corde de coeur, soit exactement
//     l'epaisseur optique 15-30 d'un vrai cumulus a la corde mesuree - AUCUNE
//     raison de toucher VC_DENSITY ni au facteur de exp(-dens*dt*k).)
// ---- CE QUI A ETE ESSAYE PUIS REJETE EN RENDU ---------------------------
// (a) d = max(d, core) : force un PLATEAU a d = 1 borne par une surface
//     ANALYTIQUE -> mesas a toit plat et murs verticaux (vc35_tri.png).
//     Retenu a la place : ABAISSER LE SEUIL (T -= K * core). La surface reste
//     une iso-surface des billows, seul son NIVEAU descend : la peau est
//     sculptee par les bulles PARTOUT, il n'y a plus aucune surface analytique.
// (b) coeur pilote par covS : MESURE de la largeur de transition en BLOCS
//     (vc35_grad.py), c'est-a-dire l'epaisseur de la peau que les bulles
//     gardent le droit de sculpter :
//       covS  11 blocs   <- un MUR (c'est ce qui faisait les mesas)
//       fld.x 27 blocs
//       fld.y 35 blocs   <- retenu (elargi par une rampe large 0.20 -> 1.10)
//       deep  87 blocs
//     Cible : ~1 echelle de bulle = VC3_TILE/4 = 78 blocs. fld.y est le pilote
//     de hauteur VC32 (moyenne de voisinage a 52 et 73 blocs) : profond dans la
//     masse = colonne HAUTE = coeur plein ; au bord = colonne basse = coquille
//     bulleuse. Il est DEJA calcule et passe en argument -> ZERO tap.
// ---- BILAN VC35 vs VC34 (memes scenes, marche livree) -------------------
//   rayons de coeur T < 0.05 : 85.2 % -> 99.5 % (CQ3) ; 73.1 % -> 97.0 % (CQ2)
//     reference 512 pas       : 89.6 % -> 99.8 % ; p90 de T 0.256 -> 0.000
//     -> LE VOILE DISPARAIT. T mediane 0.0000 (cible <= 0.01), 99.5 % de
//        rayons quasi-opaques (cible >= 95 %).
//   vide interieur 56.9 % -> 24.1 % ; par hR 46/29/36/37/40/66/98/100 %
//     -> 32/6/5/8/11/14/35/81 % : le corps est PLEIN et le sommet garde de la
//     matiere que les billows sculptent (35 % de vide au lieu de 98 %).
//   tourelles par 300 blocs de contour : 3.02 -> 4.08 (+35 %) ; contraste par
//     bande 12-40 blocs 14.44 -> 13.81 %, COTON 4-12 blocs 8.03 -> 8.05 % (INCHANGE :
//     VC33/VC34 sont intacts), grain < 2 blocs 11.92 % -> 10.37 % (-13 %, moins
//     de crenelage : le champ poreux scintillait). Densite moyenne 0.383 -> 0.721.
//   luma : image 0.3359 -> 0.3340 (-0.6 %, dans les +-3 %) ; nuage seul
//     0.4341 -> 0.3989 (-8.1 %) = les bases plates deviennent VRAIMENT ombrees,
//     ce qui est l'effet voulu d'un coeur plein (et non un assombrissement
//     global : l'enveloppe elargie rend la hauteur perdue).
//   scintillement (2 resolves independants) 10.97/15.69/21.49/21.90 % ->
//     11.22/16.05/22.90/22.68 % : +0.25 a +1.4 point, sous la marge de +2.
//   aiguilles / flocons detaches : 0 -> 0 (un coeur plein RATTACHE les
//     composantes fines au lieu d'en creer).
//   cout : voir VC35_COTON_MAX ci-dessous.
// NOTE (ecart assume) : l'ombre au sol (vc3ShadowMod, lib/lighting.glsl) n'est
// PAS touchee. Son 0.45 + 0.65*b avait ete calibre sur des colonnes "remplies a
// 60-80 %" ; elles le sont maintenant a ~76 % de densite moyenne (0.388 ->
// 0.721), donc l'ombre est proportionnellement un peu trop CLAIRE. C'est un
// choix : cette fonction alimente le terrain, la main, les entites et DH, et
// l'utilisateur n'a rien demande sur les ombres. Un cran plus sombre se ferait
// en une ligne (le 0.65) si le rendu in-game le reclame.
// 0 = VC34 verbatim (aucune constante de forme changee, aucune porte).
#define VC35 1 // coeur plein des cumulus + silhouette a tourelles (0 = VC34 verbatim)
// ---- (A) COEUR PLEIN. core = smoothstep(A, B, fld.y) * profile, puis
// T -= K * core. Applique AVANT le retour du chemin cheap, donc le LIGHT MARCH
// (2 pas 3D) et la moyenne analytique des 2 pas lointains (vc3DensMeanLM) le
// voient AUSSI - sans quoi le sommet s'eclairerait a travers un corps que le
// rendu voit plein. ZERO tap : fld.y et profile sont deja la.
// La rampe A -> B est LARGE expres : c'est elle qui fixe l'epaisseur de la peau
// que les bulles sculptent (mesure (b) ci-dessus). 0.20 -> 1.10 sur fld.y
// (dont la plage utile est [0, 1.32]) = ~80 blocs, soit une bulle.
#define VC35_CORE_A 0.20 // debut de la rampe de coeur, sur le pilote de hauteur
#define VC35_CORE_B 1.10 // fin de la rampe de coeur (coeur plein au-dela)
// Profondeur de l'abaissement du seuil. A 0.60, au coeur (core = 1, mi-hauteur)
// T passe de +0.13 a -0.47 : clamp((R - T)/0.15) = 1 pour TOUT R, donc plus une
// seule bulle vide. Balaye : 0.25 -> 95.8 %, 0.40 -> 96.8 %, 0.55 -> 97.4 %,
// 0.60 -> 99.5 % de rayons de coeur opaques (avec l'enveloppe elargie).
#define VC35_CORE_K 0.60 // profondeur du remplissage (abaissement du seuil)
// ---- (B) SILHOUETTE A TOURELLES.
// (B1) FERMETURE SPHERIQUE : la rampe de seuil lineaire 0.50 * hR erodait le
// sommet EN CONE et, combinee au cap d'enveloppe, le tuait analytiquement.
// 1 - sqrt(1 - hR^2) reste BASSE au milieu de la colonne (0.13 a mi-hauteur au
// lieu de 0.25) et ne se ferme que TOUT EN HAUT : les gros billows de 78 blocs
// survivent et font des domes RONDS au lieu d'aiguilles.
#define VC35_CAPK 0.95 // fermeture spherique du sommet (0.50 * hR lineaire avant)
// (B2) CAP D'ENVELOPPE ELARGI. C'est le vrai coupable du dome lisse :
// smoothstep(1.05, 0.55, hR) ne laisse que 28 % de l'enveloppe a hR = 0.875,
// donc T > 1 et le haut est mort. A 1.55, il en reste 58 % : l'enveloppe garde
// de la masse en haut et ce sont la fermeture spherique ET LES BILLOWS qui la
// sculptent. Mesure : vide a hR 0.75 98 % -> 35 %, tourelles +35 %, et la luma
// d'image revient a -0.6 % (la hauteur regagnee compense le coeur plus sombre).
#define VC35_PROF_HI 1.55 // bord haut du cap d'enveloppe (1.05 avant VC35)
// (B3) AMPLITUDE DU LOBE 2D de la hauteur de colonne : c'est le seul terme qui
// donne du relief a la SILHOUETTE GLOBALE dans la bande 20-70 blocs demandee.
// x2.0 double le compte de tourelles (3.46 -> 7.17 par 300 blocs, mesure a
// coeur plein) ; au-dela de x2.5 le compte SATURE et ne fait plus que creuser.
// ZERO tap : vc2Lobe est deja lu. N'affecte que la marche de RENDU (hiRes),
// comme avant : le light march et l'ombre au sol gardent la colonne sans lobe
// (meme classe d'approximation qu'avant VC35, seulement amplifiee x2).
#define VC35_LOB 2.0 // amplitude du lobe de hauteur de colonne (1.0 = avant VC35)
// ---- (C) PORTE DE COUT. Le coeur plein ne coute AUCUN tap par lui-meme, mais
// il en fait payer PLUS : les taps fins de VC33/VC34 sont conditionnes a d > 0,
// et il y a desormais beaucoup moins de vide. Mesure a CQ3, taps 3D par rayon :
//   VC34 4.599 ; VC35 sans porte 5.511 (+0.91, +19.8 %) - hors budget.
// Or le coton est un terme de SHADING : un echantillon a core ~ 1 est a plus
// d'une epaisseur de peau sous la surface d'un corps devenu OPAQUE, sa radiance
// est deja eteinte, il ne peut RIEN montrer. On ne paie donc les taps fins que
// sur la PEAU. Mesure du spectre a la bande du coton (4-12 blocs), qui doit
// rester celui de VC34 (8.03 %) :
//   porte 0.99 -> 5.018 taps, coton 8.04 % ; 0.97 -> 4.914, 8.05 % ;
//   0.90 -> 4.673, 8.03 %. Retenu 0.92 : 4.737 taps a CQ3, soit +0.138 par rayon
//   sur VC34 (budget +0.2 ; +0.229 a CQ2). Coton et luma INCHANGES a la mesure.
// Le nombre d echantillons par rayon BAISSE en plus (21.98 -> 20.39 a CQ3) :
// un corps opaque termine les rayons plus tot.
#define VC35_COTON_MAX 0.92 // au-dela de cette profondeur de coeur, pas de tap fin
// ---- VC36 (HORS MENU, NICHE sous VC35) : TAILLE, SILHOUETTE, TRANSPARENCE.
// VERDICT UTILISATEUR apres VC35 : "les nuages sont trop gros - reduis
// globalement leur taille un peu, et reduis un peu leur hauteur ; leur
// silhouette manque de details, on dirait juste que tu les as grossis ;
// monte-les de 25 blocs ; ET IL Y A TOUJOURS DES PROBLEMES DE TRANSPARENCE."
// ============ LE PALIER REEL DU JOUEUR ====================================
// Il n'existe AUCUN "VeraLux Classic.txt" a cote du pack : Iris tourne donc sur
// les DEFAUTS DU SOURCE, c'est-a-dire CLOUD_QUALITY = 1 (VC_SAMPLES 16,
// VC_SAMPLES_EFF 10, VC_RENDER_DISTANCE 900 -> VC_RDIST_EFF 1350). Tout le
// reglage VC32 -> VC35 avait ete valide a CQ2/CQ3. Opacite des rayons de coeur
// (corde d'enveloppe >= 150 blocs, marche du bake resolue sur ses 4 phases) :
//   reference 512 pas 99.8 %  |  CQ3 99.5 %  |  CQ2 98.5 %  |  CQ1 93.6 %
// et a CQ1 la perte est CONCENTREE sur les rayons RASANTS (0-8 deg
// d'elevation : 86.9 % seulement), ceux qui traversent toute la dalle : leur
// span vaut 1350 blocs, donc le pas fait 135 blocs et une corde de nuage de
// 150 blocs peut etre RATEE par une phase sur quatre -> le resolve rend
// alpha = 0.75 sur un coeur pourtant plein. C'est la moitie du probleme.
// ============ L'AUTRE MOITIE : LE FONDU DE DISTANCE COMPTE DEUX FOIS ======
// La queue de volumetricClouds (lib/clouds.glsl) faisait DEUX fois le meme
// travail avec le meme facteur :
//     col   = mix(col, fogC, fogT);   // la couleur part vers le CIEL
//     alpha *= 1.0 - fogT;            // ET le nuage devient transparent
// avec fogC = getSkyBase(worldDir) * vec3(.80,.87,1.) * .92, c'est-a-dire le
// ciel lui-meme a 8 % pres. Un nuage de coeur OPAQUE (alpha de marche = 1)
// laissait donc voir, MESURE (vc36_audit.py, camera au sol y = 130) :
//   elevation      45    30    20    15    12    10     8     6  degres
//   tHor (blocs)   80   139   220   299   376   454   569   761
//   alpha final  .976  .959  .936  .914  .893  .859  .736  .558
//   part de CIEL  4.7   8.0  12.4  16.4  20.2  25.0  37.9  55.6  %
// La part "couleur" (mix vers fogC) est de la perspective aerienne LEGITIME :
// le nuage devient gris-bleu mais reste une forme pleine. La part "alpha", en
// revanche, est de la VRAIE transparence : le ciel, ses degrades, la lune et
// les cirrus passent au travers. C'est elle qui est retiree ici. Le fondu de
// BORD (edgeF, la dissolution a la distance de rendu) reste sur l'alpha : il
// n'est pas de la brume, c'est la fin du volume marche.
// ---- CE QUI A ETE AUDITE ET DISCULPE (chiffres, pas modele) --------------
// (a) SOUS-INTEGRATION : dt = span / VC_SAMPLES_EFF, chaque phase couvre TOUTE
//     la dalle, et la somme des pas locaux du warp w(u) = (u+u^2)/2 vaut
//     1.000000 x span a N = 10 / 17 / 29. L'extinction integre bien la
//     longueur REELLE. RIEN A CORRIGER (seul le NOMBRE de pas manque).
// (b/d) COMPOSITION : prepare.fsh n'applique aucun facteur sur .a, et
//     deferred.fsh compose exactement color = cl.rgb + color * (1 - cl.a).
//     Le brouillard atmospherique de composite1 (ATMO_FOG / DISTANCE_FOG /
//     perspective aerienne) est dans la branche !isSky : il ne touche JAMAIS
//     un pixel de ciel, donc jamais un nuage vu contre le ciel. Le seul
//     attenuateur d'alpha de toute la chaine est celui corrige ci-dessus.
// (c) BOITE 3x3 DU RESOLVE : la rotation de phase par texel (frameCounter +
//     x + 2y) mod 4 met les quatre phases dans chaque bloc 2x2, donc la boite
//     3x3 encadre la moyenne : elle la contient sur 98.40 % des texels et le
//     clamp introduit +0.00287 de couverture (dans le sens OPAQUE). NON
//     COUPABLE sur les coeurs (elle joue sur les bords, ce qui est son role).
// (f) REPROJECTION A CAMERA IMMOBILE : prepare1 lit p = prevUV*TAAU_S*res*0.5
//     + 0.25 et uvFull = (fc*2+0.5)*pix, donc p = fc + 0.5 EXACTEMENT, le
//     centre du texel courant. a = 0.18, point fixe = moyenne des 4 phases.
//     Aucun melange avec du ciel bleu. TAA_V3 (composite4) reprojette le ciel
//     en rotation pure et retombe sur histUV == uv camera posee. NON COUPABLE.
// (g) LIGHT MARCH (verifie en priorite, vc36_lm.py) : vc3DensMeanLM ET le
//     chemin cheap voient DEJA le coeur VC35. Sur 2651 points de coeur,
//     profondeur optique vers le soleil : 62.05 (livree) contre 26.68 si le
//     light march ignorait le coeur (-62 %) et 70.22 en reference 192 pas.
//     ltA 0.2915 livree / 0.5790 sans coeur / 0.2829 reference. Il n'y a PAS
//     de sur-illumination : le correctif etait deja en place depuis VC35.
// (e) CHEMIN DEVANT LE TERRAIN / DH (composite1) : MEME champ, MEME
//     extinction, mais VC_SAMPLES plein sans temporel -> 99.5 % de coeurs
//     opaques a CQ1 contre 93.6 % pour le bake. La couture existe (6 points
//     d'opacite et moins de bruit du cote terrain) ; VC36_EFF_ADD la reduit
//     a ~1 point sans toucher a ce chemin.
// 0 = VC35 verbatim (aucune constante de forme, aucun facteur d'alpha change).
// NOTE DE ROLLBACK : VC_BASE 210 -> 235 (le "+25 blocs" demande) est un
// CHANGEMENT DE DEFAUT DE MENU, pas une constante de ce bloc : VC36 = 0 ne le
// couvre PAS. Il se reprend par le menu (Nuages -> hauteur de base) ou en
// remettant 210.0 sur sa ligne #define.
#define VC36 1 // taille, silhouette et transparence des cumulus (0 = VC35 verbatim)
// ---- (A) TAILLE GLOBALE x0.80 A RAPPORT CONSERVE ------------------------
// VC36_CELL multiplie VC32_CELL_K (lib/lighting.glsl, VL_CUM_SCALE_EFF) :
// UNE seule source, donc VL_CUM_TILE, VL_CUM_RAD, le rayon des 9 taps du
// pilote de hauteur, le plafond VL_CUM_COLCAP et l'ombre au sol suivent
// ENSEMBLE. Mesure (vc36_geom.py, metrique de vc32_final : masse = composante
// connexe de covS > 0.10, corde = 2*sqrt(aire/pi), hauteur = colH * VC_THICK
// ponderee par l'aire) :
//   VC35 livre (0.66)      corde 297 b  h 101 b  h_p90 139 b  h/corde 0.339
//                                                             dome    0.467
//   x0.80 (K_eff 0.528)    corde x0.805  h x0.889  h_p90 x0.822
// La corde suit exactement, la hauteur MOYENNE pas tout a fait : le plafond
// VL_CUM_COLCAP suit la cellule (147.9 -> 118.7 blocs) mais les colonnes qui
// ne le touchent pas gardent leur formule. D'ou VC36_H.
#define VC36_CELL 0.80 // facteur de taille globale, applique a VC32_CELL_K
// VC36_H multiplie colH APRES son clamp, dans la marche de rendu ET dans
// vc3DensMeanLM : c'est une homothetie VERTICALE pure de la colonne (hR = h /
// colH est inchange, donc le profil normalise, la fermeture spherique et le
// cap d'enveloppe gardent exactement leur forme).
// POURQUOI PAS VC32_SPAN, le levier "evident" : fld.y est AUSSI le pilote du
// coeur VC35 (smoothstep(VC35_CORE_A 0.20, VC35_CORE_B 1.10, fld.y)). Mesure
// (vc36_h.py, part des points de couverture a core > 0.9) :
//   SPAN 0.82 -> max fld.y 1.323 ... 38.5 %   (livre)
//   SPAN 0.74 -> 1.194 ............. 33.1 %
//   SPAN 0.66 -> 1.065 ............. 26.0 %   (deja SOUS VC35_CORE_B)
//   SPAN 0.58 -> 0.935 ............. 12.8 %
// Baisser VC32_SPAN aurait donc RENDU la transparence que VC35 venait de
// retirer. Il est condamne comme levier de hauteur.
// Balayage de VC36_H a K_eff 0.528 (corde x0.805 partout, vc36_final.py qui
// LIT les #define de ce fichier) :
//   1.00 : h x0.889  h_p90 x0.822  rapport 0.375 (+10.6 %)  dome 0.477 (+2.1 %)
//   0.95 : h x0.844  h_p90 x0.781  rapport 0.356 (+5.0 %)   dome 0.453 (-3.0 %)
//   0.91 : h x0.809  h_p90 x0.748  rapport 0.341 (+0.6 %)   dome 0.434 (-7.1 %)
// 0.95 est le seul cran qui tienne les DEUX rapports a 5 % d'ecart ou moins.
#define VC36_H 0.95 // facteur de hauteur de colonne (applique apres le plafond)
// ---- (B) SILHOUETTE : UNE 2e FREQUENCE DE LOBE, PAS PLUS D'EROSION -------
// MESURE QUI DECIDE (vc36_sil.py) : monter l'EROSION MOYENNE (canal G a x1)
// de x1.3, x1.6 ou x2.0 ne deplace PAS le contour - rugosite passe-bande
// 10-40 blocs 6.29 / 6.29 / 6.29 / 6.29, identique a trois chiffres. La raison
// est structurelle : le contour visible est l'iso-alpha 0.5 de la marche, et
// les franges erodees n'ont pas assez de corde pour l'atteindre ; la ligne
// d'horizon est posee par le CHAMP DE HAUTEUR DE COLONNE, pas par la peau.
// C'est deja ce que VC35_LOB avait montre (doubler le lobe de colH : 3.46 ->
// 7.17 tourelles par 300 blocs). Le levier de silhouette est donc une
// deuxieme FREQUENCE de lobe sur colH, pas une octave d'erosion de plus.
// vc2Lobe2 (lib/lighting.glsl) : MEME texture 2D vlCumulusBase, MEME wind,
// offset different, frequence x9 -> bosses de ~33 blocs (x4 en fait ~75).
// Cout : 1 tap 2D de plus sur les seuls echantillons hiRes (le meme tap que
// vc2Lobe paie deja), ZERO tap 3D. La frequence DOIT rester ENTIERE : le vent
// est replie par mod(_, VL_CUM_TILE) et seul un rapport entier rend le pli
// exact (meme contrat que le x4 de vc2Lobe et le x3/x6 de VC34).
// Mesures (tourelles par 300 blocs de contour / rugosite 10-40 blocs) :
//   VC35 livre .................... 4.20 / 4.61
//   taille seule (A ci-dessus) .... 7.20 / 6.22   (des masses plus petites
//                                   donnent deja plus de contour par bloc)
//   + lobe2 x9  amp 0.08 .......... 7.88 / 6.24
//   + lobe2 x9  amp 0.14 .......... 9.24 / 6.25   <- retenu
//   + lobe2 x12 amp 0.08 .......... 9.17 / 6.15
//   + lobe2 x12 amp 0.20 .......... 8.97 / 5.32
// 9.24 par 300 blocs = 7.4 tourelles sur une masse de 240 blocs (cible >= 6).
// CE QUI A ETE MESURE PUIS REJETE : VC3_TILE x0.85 (echelle de sculpture 3D
// reduite de 312 a 265 blocs, billows 78 -> 66). Elle achete de la rugosite
// (10-40 blocs 6.25 -> 6.72, bande fine 4-20 blocs 1.78 -> 2.30) mais elle
// entraine TOUTES les octaves de coton (x3 et x6 sont definies EN TUILES) :
// luma d'image 0.3340 -> 0.3467 (+3.8 %, budget +-3 %) et scintillement
// 600-1200 blocs +2.76 points (budget +2). Hors budget sur deux axes pour un
// gain de rugosite que le lobe2 donne gratuitement. VC3_TILE reste a 312, donc
// le COTON de VC33/VC34 est inchange par construction (mesure directe du terme
// de shading : rms 0.1659 -> 0.1733, moyenne 0.0002 -> 0.0024).
#define VC36_LOB2 0.14 // amplitude du 2e lobe de hauteur de colonne (0 = un seul lobe)
#define VC36_LOB2_F 9.0 // frequence du 2e lobe (ENTIER OBLIGATOIRE : pli du vent)
// ---- (C) TRANSPARENCE ---------------------------------------------------
// VC36_HAZE_A : part du fondu de DISTANCE (la brume, pas le bord) encore
// appliquee a l'ALPHA. 1.0 = comportement VC35 (le fondu comptait deux fois,
// voir l'en-tete) ; 0.0 = la brume n'agit plus que sur la COULEUR, ce qui est
// la perspective aerienne correcte. Le fondu de BORD (edgeF) garde l'alpha en
// entier : c'est la fin du volume marche, pas de la brume.
// Effet mesure (vc36_final.py) sur la part de VRAIE transparence (1 - alpha)
// d'un coeur opaque, camera au sol, VC36_HAZE_A ET VC36_LOWBAND ensemble :
//   elevation   45    30    20    15    12    10     8     6  degres
//   VC35       2.4   4.1   6.4   8.6  10.7  14.1  26.4  44.2  %
//   VC36       0.0   0.0   0.0   0.0   0.0   0.9   7.1  16.9  %
// Ce qui reste sous 8 degres est le fondu de BORD (le nuage est alors a plus
// de 1000 blocs horizontaux, au bord de la portee de rendu) plus l'aplatis-
// sement residuel : c'est voulu, un deck qui s'arrete net serait pire.
#define VC36_HAZE_A 0.0 // part du fondu de brume encore appliquee a l'alpha (1.0 = VC35)
// VC36_LOWBAND : aplatissement d'horizon (alpha *= 1 - (1-lowBand)*K sous
// ~11 deg d'elevation, vu depuis le sol). Il existe pour empecher un MUR blanc
// a l'horizon, et il reste, mais 0.62 retirait 39 % de l'alpha a 5 deg et 30 %
// a 6 deg, EN PLUS du fondu de brume : les deux se cumulaient exactement dans
// la bande ou le joueur voit le plus de ciel nuageux. 0.35 garde l'adoucissement
// sans rendre la bande basse translucide.
#define VC36_LOWBAND 0.35 // aplatissement des nuages rasants (0.62 avant VC36)
// VC36_EFF_ADD : pas AJOUTES au budget temporel VC_SAMPLES_EFF, qui vaut
// ceil(0.6 * VC_SAMPLES). Le 0.6 etait justifie par "le resolve replie les 4
// phases en une marche 4x plus fine" - c'est FAUX pour la COUVERTURE :
// prepare1 melange les ALPHAS, et la moyenne de (1 - exp(-tau_k)) n'est pas
// 1 - exp(-moyenne des tau) (inegalite de Jensen). Une phase qui RATE la corde
// d'un coeur laisse donc passer un quart de ciel apres resolve. Mesure a CQ1
// sur les rayons de coeur (T = transmittance residuelle apres resolve) :
//   EFF 10 (livre) : T<.05 93.6 %  T moyen 0.0206   cout x1.00
//   EFF 12 (+2)    : T<.05 96.0 %  T moyen 0.0126   cout x1.20
//   EFF 13 (+3)    : T<.05 97.6 %  T moyen 0.0076   cout x1.30
//   EFF 16 (plein) : T<.05 98.9 %  T moyen 0.0033   cout x1.60
// +2 est CONSTANT en pas, donc relativement cher la ou c'est necessaire et
// negligeable en haut : 5/10/17/29 -> 7/12/19/31, soit +40 / +20 / +12 / +7 %
// sur la marche cumulus du bake, elle-meme payee sur ~1/4 des pixels.
#define VC36_EFF_ADD 2 // pas ajoutes au budget temporel (0 = VC35 verbatim)
// ---- BILAN VC36 vs VC35 (memes scenes, marche livree, CQ3 sauf mention) --
//   geometrie : corde 297 -> 239 b, hauteur 101 -> 85 b, dome 139 -> 108 b ;
//     rapport h/corde 0.339 -> 0.356 (+5.0 %), dome 0.467 -> 0.453 (-3.0 %),
//     pire petite masse h/l 1.21 -> 1.44 (aucune aiguille, voir plus bas).
//   silhouette : tourelles/300 b 4.20 -> 9.24 (x2.2), rugosite 10-40 b
//     4.61 -> 6.25 (+36 %), 20-80 b 8.58 -> 11.28 (+31 %).
//   coton (terme de shading, mesure directe) : rms 0.1659 -> 0.1733, moyenne
//     0.0002 -> 0.0024, clamp sature sur 0.000 % des echantillons. INCHANGE.
//   opacite de coeur : CQ3 99.5 -> 99.3 % ; CQ1 93.6 -> 94.6 % AVEC
//     VC36_EFF_ADD (86.4 % sans - c'est lui qui paie la reduction de taille).
//   luma : image 0.3339 -> 0.3340 (+0.03 %, budget +-3 %) ; nuage seul
//     0.3989 -> 0.4109 (+3.0 %, des masses plus petites montrent plus de
//     flancs eclaires et moins de ventre).
//   scintillement : 11.22/16.05/22.90/22.68 -> 12.53/17.20/20.44/23.76 %,
//     soit +1.31 / +1.15 / -2.46 / +1.08 point (budget +2).
//   cout : +0.053 tap 3D par rayon (budget +0.2) et un 2e tap 2D sur les
//     echantillons hiRes ; +2 pas de marche sur le bake (VC36_EFF_ADD).
//   aiguilles / flocons detaches : 0 -> 0 (coupe verticale, composantes de
//     6 px ou moins) ; le nombre de composantes passe de 2 a 5 : ce sont des
//     masses SEPAREES, pas des fragments (remplissage 4.4 -> 8.8 %).
//   ALPHA FINAL A L'ECRAN (le chiffre qui repond au verdict : marche resolue
//     x queue de distance, rendu offline vc36_render.py au palier LIVE CQ1,
//     moyenne sur les pixels de nuage des cinq scenes de vc36_render.png) :
//       A gros cumulus 600 b   0.738 -> 0.846
//       B zoom sur la masse    0.861 -> 0.912
//       C soleil bas 14 deg    0.739 -> 0.848
//       D autre scene          0.624 -> 0.916
//       E bande rasante 5 deg  0.728 -> 0.840
//     soit une transparence vue qui passe de 26 / 14 / 26 / 38 / 27 % a
//     15 /  9 / 15 /  8 / 16 %.
// ============================ VC37 =======================================
// VC37 : LA MARCHE VUE DE L'INTERIEUR D'UN NUAGE.
// Rapport du createur, capture en vol a y ~ 250-300 DANS un cumulus, regard
// quasi horizontal, Distant Horizons actif : "le bug de transparence, dans un
// nuage on peut mieux le voir : c'est tout autour comme ca" - une bande claire
// bruitee bornee EN DESSOUS par une LIGNE HORIZONTALE DURE parfaitement
// droite, et sous elle un plan gris-bleu lisse.
//
// DEUX DEFAUTS, tous deux DANS LE PROLOGUE de volumetricClouds, tous deux
// causes par la meme chose : dt = (t1 - t0) / N, donc LA RESOLUTION DE LA
// MARCHE EST DICTEE PAR LA PORTEE TOTALE DU RAYON. Depuis l'interieur d'une
// dalle dense, seuls les 50 premiers blocs comptent (tau = 0.05 * d *
// VC_OPACITY = 0.1 par bloc a d = 1, donc T = 0.0067 des 50 blocs) mais le
// premier pas en fait 56.
//
// (1) L'EXTENSION RASANTE (lib/clouds.glsl) etait gardee par
//     "camPos.y < top", ce qui INCLUT la camera DANS la dalle. Pour un rayon
//     montant depuis l'interieur (0 < dir.y < 0.18) le parcours utile
//     S'ARRETE a tb = (top - camY) / dir.y - au-dela h > 1 et
//     cloudDensityCumulusCov retourne 0 des sa premiere ligne. L'extension
//     allongeait donc t1 jusqu'a VC_RDIST_EFF SUR DU VIDE :
//       camY 300, dir.y 0.179 : tb 531 b -> t1 force a 1350, 1er pas 56.2 b
//       camY 300, dir.y 0.181 : tb 525 b -> t1 =      525, 1er pas 21.9 b
//     soit un SAUT DE x2.57 de la longueur de pas sur la ligne d'ecran
//     PARFAITEMENT HORIZONTALE dir.y = 0.18 (10.37 deg). Mesure du saut
//     d'alpha du bake entre 10 et 11 deg, camera dans un coeur : 0.0837.
//     PREUVE DE NON-PERTE : 8882 echantillons de la queue (t > tb) tires sur
//     4000 rayons, densite > 0.002 sur ZERO d'entre eux. La garde devient
//     "camPos.y < VC_BASE" (l'extension sert la courbure vue d'EN DESSOUS,
//     son intention d'origine). Saut apres correction : 0.0001.
//     Camera sous la dalle ou au-dessus : STRICTEMENT INCHANGE.
//
// (2) LE WARP w(u) = (u + u^2)/2 alloue le premier pas a span/(2N).
//     A CQ1 (VC_SAMPLES 16, VC_SAMPLES_EFF 12) et span 1350 cela fait 56.2 b :
//     les 50 premiers blocs de nuage DENSE autour de la camera sont decides
//     par UN echantillon. Transmittance finale mesuree depuis un coeur
//     (VC36 livre) : bake 0.148, composite1 0.110, REFERENCE 1536 pas 0.036.
//     La marche laisse donc 3 a 4 fois trop de lumiere passer - c'est
//     exactement "on voit l'horizon a travers".
//     VC37 generalise le warp : w(u) = ((1-g)u + (1+g)u^2)/2. w(0) = 0,
//     w(1) = 1 et C1 pour tout g dans [0,1] : MEME portee, MEME nombre de
//     pas, MEME pavage en u des 4 phases temporelles (le resolve de
//     prepare1.fsh n'est pas touche). Seule la REPARTITION change : premier
//     pas x(1-g), dernier pas x(3+g)/3.
#define VC37 1 // marche interieure des cumulus : opacite vue de l'interieur et coutures (0 = VC36 verbatim)
// Force du warp interieur. Mesure a CQ1, camera dans un coeur, contre une
// reference a 1536 pas (erreur = |alpha_marche - alpha_reference|) :
//   g      1er pas   bake T   erreur   composite1 T   erreur   ecart bake/comp1
//   0.00    56.2 b   0.1482   0.1125     0.1104       0.0747   moy 0.1095 p90 0.4886
//   0.50    28.1 b   0.0983   0.0625     0.0700       0.0343   moy 0.0747 p90 0.2704
//   0.80    11.2 b   0.0721   0.0363     0.0526       0.0169   moy 0.0430 p90 0.1326
//   0.90     5.6 b   0.0663   0.0306     0.0534       0.0176   moy 0.0355 p90 0.1181
// L'ECART ENTRE LES DEUX CHEMINS EST la ligne horizontale : les pixels de
// CIEL viennent du bake demi-res (prepare.fsh, VC_SAMPLES_EFF pas, 4 phases)
// et les pixels de TERRAIN / LOD DH du re-march plein-res de composite1.fsh
// (VC_SAMPLES pas) ; la frontiere entre les deux est le bord lointain des LOD
// DH, un CERCLE centre sur le joueur, donc une droite horizontale parfaite.
// CHOIX DE LA VALEUR : g coute des echantillons, parce que des premiers pas
// plus fins font tomber la sortie anticipee (trans < 0.01) un a deux crans
// plus tard. Cout ET precision mesures ensemble, camera dans le coeur le plus
// dense, 4000 rayons a +-15 deg, contre une reference a 1024 pas
// (T de reference 0.0205) :
//   g     taps 3D/rayon (+1 de porte)  ech/rayon   T bake   erreur   ecart
//   0.00     4.37 -> 5.37                5.09      0.0578   0.0382   0.0454
//   0.30     5.29 -> 6.29                5.80      0.0433   0.0238   0.0280
//   0.50     5.95 -> 6.95                6.06      0.0362   0.0167   0.0206
//   0.65     6.39 -> 7.39                6.18      0.0327   0.0130   0.0150
//   0.80     6.97 -> 7.97                6.37      0.0307   0.0111   0.0137
//   0.90     7.40 -> 8.40                6.54      0.0303   0.0108   0.0137
// 0.65 est le GENOU du cout ; 0.80 est quand meme la valeur LIVREE, parce que
// la metrique qui compte ici n'est pas l'erreur moyenne mais LE SAUT A LA
// COUTURE, celui que le createur voit. Mesure independante et plus dense
// (profil d'alpha par elevation, 51 elevations x 320 azimuts, camera dans un
// coeur) :
//                              VC36     g=0.65   g=0.80
//   ecart bake/comp1 moyen     0.0354   0.0194   0.0118
//   ecart A L'HORIZON DH       0.0521   0.0243   0.0139   <- LA LIGNE
//   saut au seuil dir.y=0.18   0.0837   0.0040   0.0001
// 0.80 DIVISE ENCORE PAR DEUX le residu de la ligne par rapport a 0.65, pour
// 8 points de taps de plus (7.97 contre 7.39) et seulement dans la dalle.
// Le defaut a corriger EST une couture visible : on paie ces 8 points.
// 0.90 ne gagne plus rien (0.0137, identique a 0.80) et allonge le dernier
// pas pour rien. Sur une machine juste, 0.65 reste un repli mesure et sain.
// CE COUT N'EST PAYE QUE DANS LA DALLE (voir la porte ci-dessous) : au sol et
// au-dessus des nuages, taps et image sont INCHANGES AU BIT (mesure : taps
// 1.118 -> 1.118 au sol, 0.812 -> 0.812 au-dessus ; max|dRGB| 0.000000).
#define VC37_WARP_G 0.80 // force du warp interieur (0 = VC36 verbatim)
// PORTE DU WARP : densite au POINT DE LA CAMERA, chemin cheap (hiRes = false,
// donc 1 champ 2D + 1 tap 3D, aucun lobe, aucune erosion), correlee a 0.971
// avec la densite hiRes. Elle est calculee sur cameraPosition, donc elle est
// IDENTIQUE POUR TOUS LES PIXELS ET POUR LES TROIS CHEMINS : elle ne peut pas
// fabriquer de couture, et elle varie continument quand on entre dans un
// nuage. Elle n'est evaluee QUE si la camera est dans la dalle (branche
// uniforme) : cout NUL au sol, la ou le joueur est presque toujours.
// POURQUOI UNE PORTE : mesure de l'erreur |alpha - reference| par bin de
// densite a la camera (bake, CQ1) -
//   bin        g=0.00   g=0.50   g=0.80   g=0.90
//   [0.00,0.02) 0.1579   0.1861   0.1928   0.1988   <- g DOIT valoir 0
//   [0.10,0.30) 0.1366   0.1115   0.1094   0.1130
//   [0.55,0.85) 0.1373   0.1060   0.0860   0.0897
//   [0.85,1.01) 0.0973   0.0531   0.0351   0.0283
// Dans un TROU de la dalle (camera entre deux nuages, premier bin) le warp
// fort DEGRADE le champ lointain de 26 % : il faut donc l'eteindre. La
// distribution de densite dans la dalle est bimodale (9.9 % au-dessus de
// 0.10, 9.5 % au-dessus de 0.55), donc la largeur exacte de la porte compte
// peu ; 0.10 / 0.55 encadre proprement les deux modes.
#define VC37_WARP_D0 0.10 // densite camera ou le warp commence (en dessous : VC36 verbatim)
#define VC37_WARP_D1 0.55 // densite camera ou le warp est a pleine force
// ---- BILAN VC37 (camera DANS un coeur a y 300, CQ1, palier livre) --------
//   HORS DE LA DALLE, RIEN NE BOUGE : rendu offline aux cinq altitudes
//     (vc37_render.png), max|dRGB| = 0.000000 a y 130 (sol) ET a y 420
//     (au-dessus). Les deux correctifs sont gardes par l'altitude camera, et
//     l'ancienne garde "camPos.y < top" a la MEME valeur que la nouvelle
//     "camPos.y < VC_BASE" pour toute camera sous VC_BASE.
//   alpha du bake sur les pixels de ciel : 0.814 -> 0.927
//   ECART bake / composite1 (LA LIGNE) : moyen 0.0354 -> 0.0118 (-67 %),
//     max 0.0751 -> 0.0434, A L'HORIZON DH 0.0521 -> 0.0139 (-73 %)
//   SAUT au seuil dir.y = 0.18 : 0.0837 -> 0.0001
//   ARC EN ESCALIER vanilla / LOD DH : ce N'EST PAS la marche des nuages.
//     Depuis l'interieur de la dalle maxDist NE BORNE JAMAIS le rayon (le bas
//     de dalle est a 65 b sous la camera, le sol a 236 b), donc les deux
//     cotes de la frontiere recoivent la MEME marche : ecart mesure a -25 deg
//     0.002 (VC36) -> 0.000 (VC37). L'arc est la couture d'aspect du terrain
//     vanilla / LOD DH elle-meme, vue au travers de la base de nuage, qui est
//     LEGITIMEMENT translucide a cette elevation (fuite 0.156, valeur de
//     reference comprise). Rien a corriger cote nuages.
//   SILHOUETTE FINE (5-20 blocs) : LEVIER MESURE ET REJETE. Une 3e frequence
//     de lobe sur colH (x18 / x27 de VL_CUM_TILE, amplitude 0.04 a 0.10) ne
//     bouge NI la rugosite 10-40 b (6.25 -> 6.17) NI la bande fine 4-20
//     (2.14 -> 2.19), tres en dessous du +40 % vise. RAISON GEOMETRIQUE : la
//     silhouette est l'enveloppe SUPERIEURE de colH le long du rayon, et un
//     rayon rasant traverse la calotte sur une corde de ~50 blocs
//     (2 R sqrt(d/H) pour R 120, H 100, d 5) ; toute modulation de periode
//     plus courte que cette corde est moyennee vers son MAXIMUM, qui est
//     lisse. C'est la meme raison que VC36 avait deja mesuree pour l'erosion
//     3D. La bande 5-20 b n'est pas atteignable par colH ; elle demanderait
//     plus d'echantillons (CLOUD_QUALITY), pas une frequence de plus.
// ---- VC39 : LE TOIT SOUPLE (la silhouette "coton", par la GEOMETRIE) -----
// VC36 (erosion 3D), VC37 (frequence de lobe) et VC38 (raffinement des pas)
// ont chacun MESURE que le CONTOUR NE BOUGE PAS. VC38 en a donne le mecanisme
// chiffre : la silhouette d'un volume marche est le MAXIMUM GLISSANT de la
// densite le long du rayon, c'est-a-dire une DILATATION dont la fenetre vaut
// 30 a 60 blocs a 20 degres d'elevation (balayer 10 blocs de hauteur coute
// 10 / sin 20 = 29 blocs de profondeur). Une dilatation efface TOUT creux
// plus court que sa fenetre, QUELLE QUE SOIT SON AMPLITUDE - d'ou l'echec des
// trois rondes precedentes, qui ajoutaient toutes des FREQUENCES. Ne passent
// que (a) les longueurs plus grandes que la fenetre, (b) ce qui est SEPARE EN
// PROFONDEUR, car le maximum devient alors MULTI-VALUE.
// VC39 construit (b), et il le construit DANS LE CHAMP, pas dans la marche.
//
// CE QUI BLOQUAIT, exactement : hR = clamp(h / colH, 0, 1). Au-dessus de
// colH, hR est GELE a 1, donc le profil d'enveloppe ET la fermeture spherique
// VC35_CAPK sont geles a leur valeur en hR = 1 :
//     T = 2.03 - 0.575 * (covS + 0.6 * coeur)  >=  1.11  a couverture pleine
// et l'early-out "if (T >= 1.0) return 0.0" CLIPPE toute la matiere. Le toit
// etait donc la surface 2D LISSE h = colH, et c'est elle - pas les billows -
// qui posait le contour. Aucun surplomb n'etait possible, par construction.
//
// CE QUE VC39 FAIT, ZERO TAP AJOUTE PAR ECHANTILLON :
//  (A) hRT = min(h / colH, VC39_HMAX) : au-dessus du toit le profil CONTINUE
//      de decroitre au lieu d'etre gele, donc T remonte tout seul et referme
//      la bande - il n'y a pas de plafond dur a remettre a la main.
//  (B) la fermeture spherique est ETIREE sur [0, VC39_HMAX] au lieu de [0, 1]
//      et melangee a l'ancienne par vc39B = smoothstep(VC39_B0, 1, hRT) :
//      SOUS VC39_B0 * colH c'est l'ANCIENNE A L'IDENTIQUE (vc39B = 0),
//      au-dessus c'est une fermeture qui n'atteint VC35_CAPK qu'en VC39_HMAX.
//      T reste alors < 1 bien au-dessus de colH : l'iso-surface R = T(hRT)
//      MONTE au-dessus du toit lisse la ou le billow R (canal R, lobes de
//      78 blocs) est fort, et DESCEND dessous la ou il est faible. Le toit
//      devient une iso-surface 3D, donc multi-valuee en profondeur.
//  (C) VC39_H et VC39_TADD reprennent la masse ajoutee (voir plus bas : il
//      faut les DEUX, elles ne tirent pas dans le meme sens).
// ZERO TAP AJOUTE PAR ECHANTILLON parce que T ne depend d'AUCUNE valeur
// tapee : "if (T >= 1.0) return 0.0" reste AVANT le fetch, inchange. Le seul
// surcout est le NOMBRE d'echantillons qui passent desormais ce test.
//
// DECOUPLAGE TOIT / COEUR (ce qui avait condamne VC32_SPAN en VC36) : le
// coeur VC35 est smoothstep(0.20, 1.10, fld.y) * profile, et profile vaut
// EXACTEMENT 1 des que hR <= 0.55 (smoothstep(1.55, 0.55, hR) sature). Comme
// vc39B = 0 sous VC39_B0 = 0.85, la partie (A)(B) de VC39 ne change RIEN sous
// 0.85 * colH : le pilote de coeur est intact PAR CONSTRUCTION. Seul VC39_H,
// qui est une homothetie, touche encore la colonne entiere - c'est pour cela
// qu'il est garde aussi pres de 1 que le budget luma le permet.
//
// ---- LE RESULTAT (modele offline, palier LIVE CQ3 : VC_SAMPLES_EFF 31,
// 4 phases resolues, contour SOUS-PIXEL, scene "bord contre CIEL BLEU" a
// 639 blocs, 800 x 440, bpp 0.28) ----------------------------------------
//   cas          | 2-5 b | 5-10b | 10-20 | 20-40 | tour | alpha  | scint | taps
//   VC37 livre   | 0.883 | 1.202 | 2.403 | 4.843 | 3.28 | 0.3394 | 11.67 | 3.90
//   VC39         | 1.606 | 2.284 | 3.880 | 6.066 | 5.10 | 0.3407 | 11.81 | 4.10
//   gain          +82 %   +90 %   +61 %   +25 %         +0.4 %  +0.14  +0.20
// La cible etait +40 % sur 5-20 blocs : elle est DEPASSEE (+90 % et +61 %).
// C'est la premiere fois en quatre rondes que le contour bouge.
// Deuxieme scene (E2, autre zone du champ, pitch 24, bpp 0.26) :
//   VC37 0.223 | 0.476 | 0.962 | 1.459   ->   VC39 0.409 | 0.666 | 1.209 |
//   1.858, soit +83 % / +40 % / +26 % / +27 %. Le sens est le meme partout.
//
//   LE MECANISME, VERIFIE (meme decomposition que VC38, marche fine a 1 bloc,
//   800 x 440 rayons). (1) profil de COUPE du champ, corde nulle | (2)
//   ENVELOPPE le long du rayon, premier d > 0.002 | (3) contour alpha
//   converge | (5) marche livree N = 31 :
//     VC37 : (1) 1.722 2.638 5.699 9.201 -> (2) 1.055 1.271 2.330 4.919
//            -> (3) 0.948 1.273 2.443 4.791 -> (5) 0.883 1.202 2.403 4.843
//     VC39 : (1) 2.501 3.622 6.817 10.608 -> (2) 1.830 2.205 3.262 5.378
//            -> (3) 1.727 2.286 3.879 5.875 -> (5) 1.606 2.284 3.880 6.066
//     PERTE (1) -> (2), le passe-bas de la DILATATION :
//            VC37 : -39 % / -52 % / -59 % / -47 %
//            VC39 : -27 % / -39 % / -52 % / -49 %
//   Deux choses ont change, et il faut les distinguer :
//     . le CHAMP est plus riche (5-10 b : 2.638 -> 3.622, +37 %) ;
//     . la dilatation en laisse passer DAVANTAGE (-52 % -> -39 %). Elle n'a
//       pas disparu - elle est geometrique, VC38 l'a demontre - mais le champ
//       lui presente maintenant des structures qu'elle ne peut plus reduire a
//       un seul maximum.
//   Rendement bout-en-bout du detail, bande 5-10 b : 1.202 / 2.638 = 46 %
//   pour VC37, 2.284 / 3.622 = 63 % pour VC39.
//   SIGNATURE DE LA MULTI-VALUATION : chez VC39 le contour alpha (3) est PLUS
//   RUGUEUX que l'enveloppe (2) a 10-20 b (3.879 contre 3.262), alors que
//   chez VC37 les deux se valent (2.443 contre 2.330). L'iso-alpha ne suit
//   plus l'enveloppe exterieure : il coupe dedans et suit les coeurs de
//   tourelle, ce qui n'est possible que si le toit est multi-value.
//
//   CHAMP DE TOIT (carte 1600 x 1600 b, pas 5 b, sommet de d > 0.05) :
//     hauteur mediane 91 -> 89 blocs, p90 107 -> 119, max 111 -> 125. Ce ne
//     sont donc PAS des nuages plus hauts : c'est la meme enveloppe avec des
//     TOURELLES dessus.
//     rugosite du CHAMP : 5-10 b 4.112 -> 5.568 (+35 %), 10-20 2.568 ->
//     3.640 (+42 %), 20-40 3.879 -> 5.239 (+35 %).
//     PROTUBERANCES (toit moins son enveloppe locale a 60 b, seuil 8 b) :
//     59 -> 60 par km2, largeur mediane 24.6 -> 30.4 blocs, hauteur mediane
//     16.9 -> 22.5 blocs, rapport h/l median 0.70 -> 0.81, p95 1.65 -> 1.99,
//     max 2.38 -> 3.05. Les tourelles sont LARGES par construction : leur
//     largeur est celle du billow (lobes de 78 blocs), pas celle d'une
//     frequence ajoutee - c'est ce qui interdit les aiguilles.
//
//   AIGUILLES (metrique vc32_spikes : composante connexe de d > 0.05, plus de
//     18 b de haut, largeur horizontale mini <= 30 b, rapport > 1.5) :
//     6 -> 4, part du volume nuageux 0.20 % -> 0.12 %, PIRE rapport
//     3.20 -> 3.00. VC39 fait MOINS d'aiguilles que le pack livre.
//   FLOCONS (composantes <= 1000 b3) : 9 -> 24 sur 2.56 km2, dont 5 colles a
//     leur porteur (ecart <= 8 b), 6 a plus de 20 blocs et 5 sans porteur ;
//     ecart median 16 blocs. C'EST LA SEULE REGRESSION MESUREE. Ordre de
//     grandeur : 9 par km2, et la grille de mesure (5 blocs) compte comme
//     detache tout col plus fin que 5 blocs - le compte est un MAJORANT.
//     Assume : ce sont les poufs de sommet que la passe cherchait.
//
//   LIGHT MARCH (2 pas 3D + 2 pas analytiques vc3DensMeanLM) : l'esperance
//     analytique E[clamp((R - T)/W)] = 1 - T - W/2 reste VALIDE parce que
//     VC39 ne touche que T et n'introduit AUCUNE dependance en la valeur
//     tapee. Biais contre la moyenne empirique : hR < 0.70 +2.17 % (VC37
//     +1.97 %), hR 0.70-1.00 +1.19 % (VC37 +2.23 %), et la bande hR
//     1.00-1.40, qui etait VIDE (0.000 / 0.000), rend maintenant 0.08269
//     empirique contre 0.08864 analytique (+7.20 %, dans le sens "un peu plus
//     d'ombre", jamais "sur-eclaire").
//     Epaisseur optique contre une reference a 192 pas 3D : bande hR > 0.90,
//     ecart -82.4 % (VC37, 329 points) -> -37.1 % (VC39, 1904 points) ; sur
//     le coeur, -21.6 % -> -19.2 %. VC39 RAPPROCHE le light march de la
//     verite la ou il ajoute de la matiere.
//
//   LES CINQ SCENES DE RENDU (vc39_render.png, CQ3, chaine complete avec
//     queue et bake demi-res) - luma d'image et alpha :
//       A sol y=130      luma +1.89 %   alpha 0.2750 -> 0.2812
//       B trou y=245     luma +1.36 %   alpha 0.2858 -> 0.2836
//       C coeur y=300    luma +1.32 %   alpha 0.9136 -> 0.9032
//       D coeur +12 deg  luma +1.00 %   alpha 0.8979 -> 0.8869
//       E dessus y=420   luma +1.72 %   alpha 0.4501 -> 0.4550
//     Budget luma +-3 % : TENU sur les cinq. ALPHA DE COEUR : -1.14 % et
//     -1.23 %, l'opacite interieure gagnee par VC35 puis VC37 est conservee.
//
//   COUT. Sur la scene de silhouette, +0.20 tap 3D par rayon (3.90 -> 4.10),
//     exactement le budget. DECOMPOSITION : le tap de base RG 2.02 -> 2.36 ;
//     les taps fins x3, x6 et coquille (0.89 / 0.89 / 0.09) INCHANGES. Le
//     surcout est donc integralement le nombre d'echantillons qui passent
//     l'early-out, jamais un tap de plus par echantillon.
//     A DECLARER : camera DANS la dalle, le surcout est plus lourd, parce que
//     le rayon traverse la bande de TOUTES les colonnes qu'il rencontre :
//     scene C 15.46 -> 18.34 taps/rayon (+18.7 %), scene D 18.50 -> 22.62
//     (+22.2 %). Hors de la dalle il est nul (A +0.4 %, B +0.5 %, E -0.0 %).
//     Pour memoire VC37 coutait +82 % dans le meme regime.
//
//   OMBRES AU SOL : ECART ASSUME. cloudShadow est une empreinte 2D
//     (vc2CovShape(fT.x) * (0.70 + fT.y * 0.90)) multipliee par UN tap 3D
//     pris a h = 0.33 (vc3ShadowMod). Aucun de ces trois termes ne lit colH
//     ni T : les tourelles n'existent donc pas dans le proxy. C'etait deja
//     vrai de tout le haut de la colonne, et la masse totale est conservee
//     (toit median 91 -> 89 blocs), donc l'ombre moyenne ne derive pas.
//     Verification : les programmes qui ne consomment que cloudShadow
//     (gbuffers_*) sont INCHANGES AU BIT.
//
// ---- BALAYAGES (scene E1, meme protocole) -------------------------------
//   VC39_HMAX (B0 0.85, porte de masse 0.25-0.55, compensation ajustee) :
//     1.65 : 1.664 2.094 3.769 5.954 | alpha 0.3326 | taps 3.97
//     1.80 : 1.717 2.246 3.995 6.059 | alpha 0.3384 | taps 4.07
//     1.95 : 1.783 2.323 4.071 6.053 | alpha 0.3368 | taps 4.06   <-- RETENU
//     2.10 : 1.758 2.314 4.095 6.049 | alpha 0.3343 | taps 4.04
//     Au-dela de 1.95 la bande 5-10 sature et la compensation doit raccourcir
//     les colonnes de plus de 11 %.
//   VC39_B0 : 0.80 -> 1.634 / 2.071 / 3.750 ; 0.85 -> 1.664 / 2.094 / 3.769 ;
//     0.90 oblige a une compensation de 0.96 et la luma part a +8.9 %. 0.85
//     laisse le coeur VC35 hors d'atteinte (profile sature des hR <= 0.55).
//   PORTE DE MASSE VC39_YG : c'est elle qui tient le budget de taps. A luma
//     egale, SANS porte il faut 4.23 taps/rayon (+0.33, hors budget) ; AVEC,
//     3.97 a 4.10. Elle retire la bande sur la frange plate, ou une tourelle
//     n'a de toute facon aucun sens physique.
//   LES DEUX COMPENSATIONS, et pourquoi il en faut DEUX :
//     VC39_H seul (0.89) : E1 alpha 0.3368 (-0.8 %, parfait vu de dehors)
//       MAIS la scene C passe a +4.89 % de luma et la D a +4.56 % - HORS
//       BUDGET. Raccourcir la colonne retire de la masse AU-DESSUS d'une
//       camera qui est dans le coeur, donc elle s'ECLAIRCIT.
//     VC39_TADD seul (0.14, colonne intacte) : la scene C est sauve, mais E1
//       reste a alpha 0.3886, soit +14.5 % - amincir la bande ne lui retire
//       presque pas de COUVERTURE, une bande fine occulte quand meme.
//     H 0.91 + TADD 0.06 : luma A +1.89 | B +1.36 | C +1.32 | D +1.00 |
//       E +1.72 %. Les cinq dans +-3 %. C'est le couple retenu.
//     Sans aucune compensation : E1 alpha 0.3394 -> 0.3847, +13.3 %.
#define VC39 1 // toit souple des cumulus : tourelles et surplombs (0 = VC37 verbatim)
// Hauteur relative maximale exploree par le profil et par la fermeture
// etiree. hRT est clampe la ; au-dela T depasse 1 et l'early-out reprend, ce
// qui referme la bande sans plafond dur.
#define VC39_HMAX 1.95 // plafond de hauteur relative du toit souple
// Bas de la bande : sous VC39_B0 * colH, (A) et (B) sont INACTIFS au bit pres
// (vc39B = 0). Doit rester au-dessus de 0.55, ou le profil sature et ou vit
// le coeur VC35.
#define VC39_B0 0.85 // debut de la bande de toit souple, en hauteur relative
// Porte de MASSE sur fld.y (pilote de hauteur VC32, moyenne de voisinage a
// 52 / 73 blocs) : une tourelle appartient a une colonne PROFONDE dans la
// masse, pas a la frange plate. Zero tap (fld.y est deja la) et c'est ce qui
// tient le budget de taps (voir le balayage ci-dessus).
#define VC39_YG0 0.25 // bord bas de la porte de masse du toit souple
#define VC39_YG1 0.55 // bord haut de la porte de masse du toit souple
// Compensation 1 : homothetie de colonne, APRES le plafond, exactement comme
// VC36_H. Elle retire de la COUVERTURE. A garder aussi pres de 1 que possible
// car c'est le seul terme de VC39 qui touche encore le bas de la colonne.
#define VC39_H 0.91 // facteur de hauteur de colonne compensant le toit souple
// Compensation 2 : releve le seuil DANS LA BANDE seulement (x vc39B), donc
// elle amincit la matiere ajoutee sans rien changer sous VC39_B0 * colH.
// C'est elle qui sauve la luminance vue depuis l'interieur du nuage.
#define VC39_TADD 0.06 // relevement du seuil dans la bande du toit souple
// ---- Cumulus shaping: layer 1 reuses the altocumulus slab recipe (sharply
// thresholded vnoise cells + low-frequency banks) at cumulus scale: cells ~2.5x
// the alto ones (masses ~100-250 blocks, separated by 60-150 blocks of blue
// sky), flat base, bulging domed tops.
// VC_CUMULUS_SHAPES=1 -> this field; 0 = the original raymarch.
#define VC_CUMULUS_SHAPES 1 // [0 1]
// Horizontal cell scale (larger = wider, more spaced cumulus).
#define VC_CUMULUS_SCALE 1.5 // [0.5 0.75 1.0 1.5 2.0]
// VC_TEXTURED=1: layer-1 cumulus density comes from the PRECOMPUTED textures
// (Nubis / Horizon Zero Dawn technique): a 1024^2 coverage map, two 128^3
// erosion volumes and a 64^3 curl volume, loaded as customTexture in
// shaders.properties. Per marched sample: 1 small 2D tap on clear sky, 9 under
// cloud (width-gated column height - no more pillars), plus 2-3 3D erosion
// taps and 1 refresh tap on lit samples; the procedural path evaluated ~27
// noise octaves. Ground shadows read the very same field. Only active when
// VC_CUMULUS_SHAPES=1. 0 = procedural v5 field, kept bit-identical as fallback.
#define VC_TEXTURED 1 // [0 1]
// CLOUD_SHAFTS (bloc "RAYONS DE NUAGES", plus haut dans ce fichier) : porte
// DERIVEE partagee par le cuiseur (prepare2.fsh), les lecteurs (composite1.fsh
// et son miroir lib/vl_halfres.glsl) et les helpers de lib/lighting.glsl, pour
// qu'ils ne puissent JAMAIS etre en desaccord sur l'existence de la carte.
// Declaree ICI, apres VC_CUMULUS_SHAPES / VC_TEXTURED, parce qu'elle en depend
// (un #if sur un macro pas encore defini le lirait comme 0). Les branches
// PROCEDURALES sont exclues : la CTM reproduit exactement le champ TEXTURE de
// cloudShadowCheap, pas le proxy procedural duplique -- ecart assume, chiffre
// et justifie au bloc RAYONS DE NUAGES.
// La porte porte une VALEUR et un commentaire sans liste (et non la forme nue
// des vieilles portes derivees du pack, CLOUD_PREPARE_ACTIVE et consorts) :
// un "#define NOM" nu peut etre enregistre par Iris comme une case a cocher,
// ce qu'une porte derivee ne doit jamais devenir. Les sites la testent au
// #ifdef, ce qui marche a l'identique.
#if CLOUD_SHAFTS >= 1 && defined VOLUMETRIC_CLOUDS && defined VC_GROUND_SHADOWS \
    && VC_CUMULUS_SHAPES == 1 && VC_TEXTURED == 1
#define CLOUD_SHAFTS_ACTIVE 1 // porte derivee, hors menu
// SHAFT_FAR (bloc "ROUND 2 : SEGMENT LOINTAIN", plus haut dans ce fichier) :
// porte derivee du SEGMENT LOINTAIN. Elle n'existe que SOUS CLOUD_SHAFTS_ACTIVE
// -- le segment lit la carte de transmittance a chaque pas, il ne peut donc pas
// exister sans elle. Meme forme (valeur + commentaire sans liste) et meme
// raison que la porte ci-dessus. Partagee par composite1.fsh, son miroir
// lib/vl_halfres.glsl et les helpers de lib/lighting.glsl.
#if SHAFT_FAR == 1
#define SHAFT_FAR_ACTIVE 1 // porte derivee, hors menu
#endif
#endif
// Curl-noise swirl on the erosion lookup: wind-torn turbulent tops, calm base.
// Only used when VC_TEXTURED=1 (and VC_DETAIL=1).
#define VC_CURL 1.0 // [0.0 0.5 1.0 1.5 2.0 3.0]
// 3D erosion/detail: wispy edges + internal structure. 0.0 = OFF (first lever to pull for perf).
#define VC_CUMULUS_EROSION 1.5 // [0.0 0.5 0.75 1.0 1.25 1.5 2.0]
// Darkening of the flat cumulus underside.
#define VC_CUMULUS_BASE_DARK 0.65 // [0.0 0.25 0.4 0.5 0.65 0.8 1.0]
// Silver lining strength (edge flare toward the sun).
#define VC_CUMULUS_SILVER 1.0 // [0.0 0.5 0.75 1.0 1.5 2.0]
// ---- Cumulus detail ----
// VC_DETAIL=1: fine 4th octave on the cell silhouette (bays and capes),
// high-frequency micro erosion at the edges, internal albedo micro variation
// (wisps). 0 = smooth shapes (cheaper).
#define VC_DETAIL 1 // [0 1]
// Strength of the high-frequency edge erosion (0 = plain edges).
#define VC_DETAIL_STRENGTH 1.0 // [0.0 0.5 0.75 1.0 1.25 1.5 2.0]
// Internal albedo micro variation (wisps): 0 = uniform material.
#define VC_DETAIL_WISPS 0.5 // [0.0 0.25 0.5 0.75 1.0]
// ---- High layers ----
// CLOUD_HIGH_V3=1: cirrus as thin anisotropic filaments (stretched x13, curved)
// and altocumulus as a field of small lit puffs. 0 = the original simple layers.
#define CLOUD_HIGH_V3 1 // [0 1]
// Cirrus amount/opacity (filament banks).
#define CLOUD_CIRRUS_AMOUNT 1.0 // [0.25 0.5 0.75 1.0 1.5 2.0]
// Altocumulus amount/opacity (puff sheets). Default lowered 1.0 -> 0.75
// (creator request): the layer-2 sheet was covering too much of the gap
// between the cumulus tops and the cirrus veil.
#define CLOUD_ALTO_AMOUNT 0.75 // [0.25 0.5 0.75 1.0 1.5 2.0]
// Keep this ABOVE the cumulus tops (VC_BASE + VC_THICK) to avoid overlap.
// Layer 2 raised by 75 blocks (340 -> 415): stays above the new cumulus tops
// (VC_BASE 210 + VC_THICK 160 = 370) and below the cirrus veil.
#define CLOUD_ALTO_HEIGHT 415.0 // [120.0 220.0 280.0 340.0 415.0 420.0 600.0 1000.0 2000.0]
// VOLUMETRIC ALTOCUMULUS (second 3D layer): thin slab marched in 6 steps -
// real domed puffs instead of a flat 2D sheet.
#define ALTO_VOLUMETRIC 1 // [0 1]
// Layer 3 (highest) raised by 100 blocks (460 -> 560); 560 was already listed.
#define CLOUD_CIRRUS_HEIGHT 560.0 // [200.0 380.0 460.0 560.0 700.0 1000.0 2000.0 4000.0]
#define CLOUD_LAYER_ALTO
#define CLOUD_LAYER_CIRRUS
//#define CLOUDS_2D
// ---- Blue-noise march dither ----
// BLUE_NOISE=1: the volumetric marches (cumulus, 3D alto, fog / god rays)
// jitter with a tileable 64^3 blue-noise texture, one z-slice per frame, and
// TAA averages it into smooth gradients - kills the banding terraces seen from
// above the cloud slab. Other dither users (SSR, PCF, contact shadows) are NOT
// affected. 0 = the previous static Bayer dither, bit-identical.
#define BLUE_NOISE 1 // [0 1]
// ---- Baked-noise texture ----
// NOISE_TEX=1: decorative noise fields (VL fog banks, procedural alto/cirrus
// layers, Nether/End skies, Milky Way nebulosity) read a 256^2 baked RGBA8
// texture (vlNoiseTex) instead of stacking arithmetic hash octaves: one
// bilinear tap replaces 4 hashes + 3 mixes per octave. The pattern differs
// slightly (another noise instance); water waves, caustics and every
// cloudShadow-mirrored field keep the arithmetic vnoise (sync). 0 = original
// arithmetic noise, bit-identical.
#define NOISE_TEX 1 // [0 1]
// ---- Half-res cloud pass ----
// CLOUD_HALF_RES=1 (default): the ENTIRE sky cloud chain (cirrus/2D alto
// sheet, volumetric 3D alto, VC_SAMPLES cumulus march, rainbow) is baked by
// a PREPARE pass (prepare.fsh, runs before the gbuffers - clouds only need
// the view ray, never the frame depth) into the lower-left quadrant of
// colortex15 as ONE premultiplied (rgb, coverage) pair - same quadrant
// convention as GI_HALF_RES / VL_HALF_RES, same uv -> NDC mapping as
// deferred (TAAU sub-rect included). deferred.fsh then rebuilds its exact
// layer mix() chain with a single bilinear tap + one composite: the march is
// paid on ~1/4 of the pixels -> cloud cost / ~4 on open skies. Trade-offs:
// cloud edges are reconstructed bilinearly (the sky is smooth; a small
// TAA-averaged jitter hides the 2x2 grid), and the bake also covers sky
// hidden behind terrain, so cave/indoor frames pay a small fixed cost. The
// clouds-in-front-of-terrain pass (composite1) is untouched, still full-res.
// 0 = inline evaluation in deferred.fsh, bit-identical to the legacy path.
#define CLOUD_HALF_RES 1 // [0 1]
// Derived gate shared by prepare.fsh (writer) and deferred.fsh (reader) so
// the two programs can never disagree about the buffer being live.
#if CLOUD_HALF_RES == 1 && (defined VOLUMETRIC_CLOUDS || defined CLOUD_LAYER_ALTO || defined CLOUD_LAYER_CIRRUS)
#define CLOUD_PREPARE_ACTIVE
#endif
// ---- Temporal cloud bake ----
// CLOUD_TEMPORAL=1 (default; only acts with CLOUD_HALF_RES=1): the half-res
// cloud bake is accumulated frame to frame. prepare.fsh marches the cumulus
// with VC_SAMPLES_EFF steps (ceil 0.6 x VC_SAMPLES: 5/10/17/29 for the four
// CLOUD_QUALITY tiers, step length recomputed to span the whole slab) whose
// start offset is interleaved over 4 frames (phase k = frame index mod 4,
// rotated per texel so each 2x2 block holds all four phases, starts in
// quarter k of the first step, the dither jitters inside it), and a second prepare pass
// (prepare1.fsh) blends that bake with the previous resolved quadrant
// reprojected through the TAA camera matrices (sky ray anchored on the
// mid-slab plane y = VC_BASE + VC_THICK/2): mix(history, current, 0.18),
// history clamped into the 3x3 min/max box of the current bake (+10%) so
// ghosting stays bounded and a garbage history (first frame, resolution or
// TAAU change) is washed out in ~6 frames. Four interleaved frames tile one
// step: converged quality = a march 2.4x denser than the one paid for, i.e.
// at least the legacy VC_SAMPLES look for ~60% of the cumulus cost. The
// history lives in the free upper-right area of colortex15 (one exact texel
// copy per quadrant texel, lib/cloud_temporal.glsl). Untouched and still on
// the full VC_SAMPLES: clouds in front of terrain (composite1), the inline
// deferred path (CLOUD_HALF_RES=0), cloudShadow, the light march, the alto
// slab. 0 = legacy single-pass bake (prepare1.fsh then only copies the
// quadrant to keep Iris's buffer flip parity), bit-identical output.
#define CLOUD_TEMPORAL 1 // [0 1]
// VC_SAMPLES_EFF: cumulus sample budget of the temporally resolved bake as
// an integer expression, (3N + 4) / 5 = ceil(0.6 N) for every tier above.
// Read ONLY by the render march of lib/clouds.glsl under CLOUD_TEMPORAL_MARCH
// (defined by prepare.fsh before the include); = VC_SAMPLES when the gate
// is off, so no consumer changes.
// VC36 : + VC36_EFF_ADD pas. Le 0.6 supposait que le resolve replie les 4
// phases en une marche 4x plus fine ; c'est faux pour la COUVERTURE (prepare1
// melange les ALPHAS, Jensen), et a CQ1 une phase sur quatre pouvait RATER la
// corde d'un coeur -> alpha 0.75 sur un nuage plein. Mesure et cout : bloc
// VC36 plus haut. Le budget reste borne par VC_SAMPLES.
// Le plafond est pose PAR LE PREPROCESSEUR (v120 n'a pas de min() entier, et
// la borne d'une boucle deroulee doit rester une expression constante).
#if CLOUD_TEMPORAL == 1
#if VC36 == 1
#if ((VC_SAMPLES * 3 + 4) / 5 + VC36_EFF_ADD) > VC_SAMPLES
#define VC_SAMPLES_EFF VC_SAMPLES
#else
#define VC_SAMPLES_EFF ((VC_SAMPLES * 3 + 4) / 5 + VC36_EFF_ADD)
#endif
#else
#define VC_SAMPLES_EFF ((VC_SAMPLES * 3 + 4) / 5)
#endif
#else
#define VC_SAMPLES_EFF VC_SAMPLES
#endif

// ---- VC2 : macros derivees de la refonte (source unique). A gate 0 chaque
// macro retombe TOKEN POUR TOKEN sur son define v5 -> SPIR-V identique aux
// baselines (preuve harnais vc2_gate0.txt). Les curseurs de menu gardent tout
// leur sens : les decalages/facteurs s'appliquent PAR-DESSUS la valeur choisie.
#if VC2 == 1
// Couche 3 (cirrus) montee de +150 (560 -> 710) et couche 2 (alto) de +50
// (415 -> 465) - demande utilisateur. Sommet cumulus VC2 = 370 max (COLCAP
// atteint 1.0 avec le scale x1.6, lib/lighting.glsl) -> 95 blocs d'ecart sous
// l'alto, sain.
#define VC2_CIRRUS_H (CLOUD_CIRRUS_HEIGHT + 150.0)
#define VC2_ALTO_H (CLOUD_ALTO_HEIGHT + 50.0)
// Taux alto x0.8 : 0.75 -> 0.60 au defaut (demande "autour de 0.60").
// VC34 n'y touche PAS : c'est un curseur de menu, il garde son sens.
#define VC2_ALTO_AMT (CLOUD_ALTO_AMOUNT * 0.8)
// Zoom des features alto et bord bas du masque de nappes : SOURCE UNIQUE des
// trois sites du contrat SYNC (altoDensity, la variante 2D de highClouds, le
// miroir haloVeilCov). VC2 avait agrandi les puffs x1.2 ; VC34 les reduit de
// VC34_ALTO_SIZE et resserre le masque de nappes. Voir le bloc VC34 plus haut
// pour les mesures (couverture x0.70, taille x0.69).
#if VC34 == 1
#define VC2_ALTO_ZOOM (1.0 / (1.2 * VC34_ALTO_SIZE))
#define VC2_ALTO_BANK0 VC34_ALTO_BANK
#else
#define VC2_ALTO_ZOOM (1.0 / 1.2)
#define VC2_ALTO_BANK0 0.42
#endif
// Couverture cumulus x0.85 : 0.40 -> 0.34 au defaut. Mesure (replay 1024^2 de
// cumulus_base.bin, champ VC2 complet) : ciel couvert 27.0 -> 22.7% - plus de
// bleu, entites separees (la pluie melange toujours vers 1.0 : couvert total
// atteignable). Consomme par les sites TEXTURES uniquement (source unique
// lib/lighting.glsl) ; les chemins proceduraux gardent VC_COVERAGE.
#define VC2_COVERAGE (VC_COVERAGE * 0.85)
#else
#define VC2_CIRRUS_H CLOUD_CIRRUS_HEIGHT
#define VC2_ALTO_H CLOUD_ALTO_HEIGHT
#define VC2_ALTO_AMT CLOUD_ALTO_AMOUNT
#define VC2_COVERAGE VC_COVERAGE
// A VC2 = 0 la refonte alto de VC34 ne s'applique pas non plus : les deux
// macros retombent sur les valeurs d'origine, le chemin legacy est intact.
#define VC2_ALTO_ZOOM 1.0
#define VC2_ALTO_BANK0 0.42
#endif
// Distance de rendu cumulus x1.5 (700/900/1400/1800 -> 1050/1350/2100/2700),
// UNIQUEMENT la ou la marche VC2 a pas croissants existe (meme gate que la
// boucle d'eclairage VC2 de lib/clouds.glsl) : le budget d'echantillons par
// tier est INCHANGE, la marche warpe ses pas (fins pres de l'entree, larges
// au-dela de l'ancienne portee - warp quadratique dans volumetricClouds),
// donc l'extension coute ~zero (quelques ALU par pas, aucun pas ajoute).
// Les fallbacks gardent la portee v5 : une marche UNIFORME diluee sur x1.5 y
// perdrait de la finesse pres du joueur.
#if VC2 == 1 && VC_CUMULUS_SHAPES == 1 && VC_TEXTURED == 1
#define VC_RDIST_EFF (VC_RENDER_DISTANCE * 1.5)
#else
#define VC_RDIST_EFF VC_RENDER_DISTANCE
#endif

// ============ WEATHER ============
#define RAIN_WET

// ============ AMBIANCE (main-menu AMBIANCE screen + CONFIG_AMBIANCE dials) ============
// Each feature has an int toggle: 0 compiles it out (bit-identical to the
// previous render), 1 (default) = the creator's intended look.
// DAWN_MIST (composite1): low valley mist, its own analytic height-fog layer
// (closed-form Beer-Lambert, no march) INDEPENDENT of HEIGHT_FOG and
// VOLUMETRIC_LIGHT - when both are on their transmittances simply multiply,
// nothing is counted twice. Exponential profile anchored 2 blocks under the
// eye (local ground): thin at eye level, thick in the hollows below (capped
// at 6x). Driven by the world clock (dense 4h30-7h, dissipating until ~9h30,
// faint at dusk 18h-19h30) plus the wet haze lingering after rain
// (wetness x (1 - rainStrength)). Tinted by the LOCAL sky luminance only
// (cool grey-blue, never the raw sky RGB) with a faint glow toward the
// grazing sun. Never underwater, never in caves (eye skylight gate), mirror
// water keeps the same relief as the other fogs, fades out above ~12-30 deg
// of elevation so the upper sky stays untouched. Lowlands only: the density
// is x exp(-(eyeY - (WATER_LEVEL + 30)) / 40) above sea level + 30, so the
// eye-anchored layer does not follow a flying player.
#define DAWN_MIST 1 // [0 1]
// CONFIG_AMBIANCE: overall mist density.
#define DAWN_MIST_STRENGTH 1.0 // [0.25 0.5 0.75 1.0 1.5 2.0 2.5 3.0]
// CONFIG_AMBIANCE: scale height in blocks (density / e every DAWN_MIST_HEIGHT blocks up).
#define DAWN_MIST_HEIGHT 8.0 // [2.0 3.0 4.0 6.0 8.0 12.0 16.0 20.0 24.0]
// DAWN_MIST_VOL: makes the mist a REAL volumetric medium instead of the flat
// analytic veil described above. 0 = the closed-form layer, bit-identical.
// 1 = the mist density joins the VOLUMETRIC_LIGHT march as one more per-step
// term (exactly like SEALEVEL_MIST or the height fog), so it inherits FOR FREE
// the per-step shadow taps, the cloud shadows, the god-ray phase and the
// dither: the mist is then carved by trees and hills instead of washed flat
// over them. Same height profile, same anchor, same hour / altitude weights
// and the same dials as the analytic layer, multiplied by an animated 3D noise
// field (2 octaves, ~42 / ~11 block lattice, WORLD anchored, ~0.8 block/s
// drift, mean exactly 1.0 -> drifting BANKS). Beyond the 160-block march the
// analytic layer takes over as the TAIL, joined at the same density (the noise
// averages to 1.0), so nothing steps at the march limit. The noise taps are
// paid only during the MIST HOURS OR THE AFTER-RAIN WINDOW (uniform
// branch): dawnMistHourW also carries wetness * (1 - rainStrength), and
// wetness lags rainStrength by minutes, so the field stays alive at any hour
// for a while after a shower - which is exactly when the damp haze should be
// visible. Requires VOLUMETRIC_LIGHT: without a march the analytic layer runs
// the whole ray as before. Wants VOLUMETRIC_QUALITY >= 2 to look its best: at
// quality 1 the march is 8 steps over 160 blocks (20-block steps) against a
// ~42-block bank lattice, so the amplitude is auto-faded (see
// DAWN_MIST_PATCHY) to keep the banks from crawling between frames. The banks
// drift on the WORLD clock (cloudWorldTime), like the clouds: /time set and
// sleeping move them with the world. (composite1.fsh inline march + its
// lib/vl_halfres.glsl mirror, shared field dawnMistDens in lib/common.glsl.)
// ### FIGE PAR LA PASSE "MENUS2" - PLUS AUCUN CONTROLE EN JEU, VALEUR DEFINITIVE 1.
// Raison : c'est le NUMERO DE VERSION du rendu de la brume d'aube (voile plat
// analytique = ancien, volume marche = actuel), pas un reglage d'ambiance. Le
// createur a deja "Brume d'aube" en ON/OFF ; lui demander en plus de choisir
// COMMENT elle est calculee, c'est exactement la liste de bascules dont il ne
// veut plus. La version volumetrique est celle du look livre. Le "// [0 1]" est
// retire pour qu'Iris cesse de l'annoncer comme option. Le repli analytique
// existe toujours dans le code et se rallume a la main ici (valeur 0).
#define DAWN_MIST_VOL 1 // FIGE : rendu volumetrique de la brume d'aube
// CONFIG_AMBIANCE: patchiness of the volumetric mist -- amplitude of the 3D
// noise around the mean density (0 = the smooth analytic profile, 0.6 = banks
// with a 4:1 density ratio, 1.0 = banks with real holes). DAWN_MIST_VOL only.
// NYQUIST GUARD: the value the march really uses is this dial scaled by
// clamp(VL_SAMPLES / 12, 0.35, 1) -- 12 samples (VOLUMETRIC_QUALITY 2) and
// above get the dial as written, the 8- and 4-sample tiers get a calmer field
// because their step is at or under the lattice sampling limit.
#define DAWN_MIST_PATCHY 0.6 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
// CONFIG_AMBIANCE: ambient weight of the MIST BODY inside the march
// (DAWN_MIST_VOL only). The march lights its medium with ambC * 0.22, a haze
// weight, while the analytic tail beyond 160 blocks lights the SAME mist with
// ~0.92 of the local sky luminance: with the back to the sun the phase term is
// near zero, so the marched mist read about 4-5x darker than the layer it
// replaces and the 0.0030 calibration no longer matched (more density only
// made it darker, so DAWN_MIST_STRENGTH could not compensate). The march now
// blends its ambient weight toward this value in proportion to the mist's
// share of the step density, so the near mist and the far tail agree again.
// 0.22 = the legacy haze weight (restores the old, darker look).
#define DAWN_MIST_AMB 0.90 // [0.22 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00]
#if DAWN_MIST == 1 && DAWN_MIST_VOL == 1 && defined VOLUMETRIC_LIGHT
// Derived gate (same pattern as FOG_SHADOWS_ACTIVE / END_STORM_ACTIVE): the
// marched mist only exists when there IS a march to put it in. Every use site
// tests this macro, so DAWN_MIST_VOL = 0 keeps the legacy code paths verbatim.
#define DAWN_MIST_VOL_ACTIVE
#endif
// MOON_PHASE_LIGHT (lib/lighting.glsl moonPhaseLum/moonPhaseW): the drawn
// phase already follows moonPhase, this makes the LIGHT follow too. Full 1.0,
// gibbous 0.78, quarter 0.50, crescent 0.30, new = MOON_PHASE_MIN. Scales the
// moon share of getLightColor, the night ambient, the night-sky base of
// getSkyBase (on top of SKY_NIGHT_BRIGHT) and the disc halo - NOT the stars,
// the Milky Way or MIN_LIGHT (playability). Weighted in only in deep night
// (sun height -0.05 .. -0.25): the phase flips at worldTime 0 while the moon
// sets, so no visible pop.
#define MOON_PHASE_LIGHT 1 // [0 1]
// CONFIG_AMBIANCE: new-moon luminance floor.
#define MOON_PHASE_MIN 0.15 // [0.05 0.1 0.15 0.2 0.25 0.3 0.4 0.5]
// BIOME_CLIMATE (lib/biome.glsl): three camera-UNIFORM weights from the
// smoothed Iris biome temperature / rainfall (custom uniforms biomeTempS /
// biomeHumS, shaders.properties smooth ids 58/59, 0.6 s half-life so biome
// borders glide): hot & dry (desert, badlands, savanna), hot & humid (jungle,
// swamp), cold (snow, peaks). Subtle effects (<= 15% at full weight): hot ->
// paler warm horizon band, +15% warm-tinted atmo fog, slightly warmer noon
// sun; humid -> +15% atmo fog, slight sky desaturation, faint grey-green fog;
// cold -> -15% atmo fog, cooler sky and day ambient (+B -R 4%). Uniform
// branches: zero per-pixel cost. Distinct from BIOME_ATMOSPHERE below (the
// vanilla fogColor tint of the haze), which is untouched. The weights and
// their uniforms are compiled only while this toggle is on.
#define BIOME_CLIMATE 1 // [0 1]
// CONFIG_AMBIANCE: multiplies every biome-climate effect (0 = none, 2 = double).
#define BIOME_CLIMATE_STRENGTH 1.0 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 1.75 2.0]
// RAINBOW_V2 (lib/sky.glsl skyRainbow, called by deferred.fsh inline and by
// the prepare.fsh half-res bake with the same ray): physically graded double
// bow. 0 = the legacy 3-band RAINBOW sketch, bit-identical (the legacy RAINBOW
// boolean stays the master switch: undefined = no bow at all). Needs wet
// ground while the rain stops (wetness x (1 - rainStrength)) and a sun between
// ~1 and ~42 deg up (no bow at noon). Primary bow at 42 deg, 1.8 deg wide (red
// outside 42.4, violet inside 40.6, smooth 6-band hue ramp, pastel), inverted
// secondary at 51 deg (3 deg wide, 0.35x), Alexander's dark band between them
// (sky x0.92), faint white lift just inside the primary. Lit by the direct sun
// color (luma capped at 2.0), so a dusk bow is red-heavy. Sky pixels only:
// hidden by terrain and cumulus, faded by the horizon haze like the sky, cut
// under the horizon, never underwater.
#define RAINBOW_V2 1 // [0 1]
// CONFIG_AMBIANCE: bow brightness (0 = invisible, 1.0 = calibrated, 2 = double).
#define RAINBOW_STRENGTH 1.0 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 1.75 2.0]
// SUN_HALO (lib/clouds.glsl skyHalo22, same two call sites): 22-degree ice
// halo around the sun, and the moon at night (0.5x), wherever the ray crosses
// a THIN high veil: the layer-2 coverage (alto cells and banks, cirrus
// filaments - the very fields the layers draw) re-sampled at the ray / layer
// intersection, with a thick-veil cut (1 - smoothstep(0.45, 0.85, cov)) on the
// ring AND toward the body (a dense alto hides the sun: no halo). Sharp reddish
// inner edge (21.6 deg), diffuse white-blue outer edge (22.8), slightly darker
// sky just inside the ring (x0.96). Evaluated in the 18-26 deg annulus only.
// Additive on the sky pixels under the cumulus, faded by the haze, never
// underwater. The legacy MOON_HALO humidity ring is untouched and adds up.
#define SUN_HALO 1 // [0 1]
// CONFIG_AMBIANCE: halo brightness (0 = invisible, 1.0 = calibrated, 2 = double).
#define SUN_HALO_STRENGTH 1.0 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 1.75 2.0]
// SNOW_SPARKLE (gbuffers_terrain tag + composite1 opaque branch): sunlit snow
// glitters. block.properties id 42 (snow layers, snow block, powder snow) is
// tagged in the material flag colortex2.b with the SNOW band 0.38. Flag bands
// (RGBA8): water 1.0 (>0.95) / nether portal 0.85 (0.82-0.93) / glass 0.7
// (0.6-0.8) / lava 0.58 (0.55-0.62) / emissive+end portal 0.5 (GI gathers skip
// 0.45-0.65) / SNOW 0.38 (0.35-0.42) / entity 0.02 + DH water 0.2 (0.01-0.30,
// the VL F5 bound band) / opaque 0.0. composite1 reads the snow band once and
// neutralises it to 0.0, so every legacy band test (PBR gate, water-column
// probes, entity/lava bands) keeps seeing a plain opaque. Each 1/12-block cell
// of the surface owns one micro-facet (random normal on a 25 deg cap) that
// glints through a narrow GGX lobe (alpha 0.02, capped) when it mirrors the
// sun or moon toward the eye - the ~4% most aligned cells at any view angle,
// fixed in the world so the points only change when the player moves. Light
// color x shadow visibility (the AO block's shadowtex1 tap) x cumulus shadow
// x 0.8 x strength, one glint peaks near 12 HDR (bloom), moon x0.35, none in
// rain or on wet snow, faded out past ~100 blocks.
#define SNOW_SPARKLE 1 // [0 1]
// CONFIG_AMBIANCE: glitter brightness (0 = none, 1.0 = calibrated, 3.0 = triple).
#define SNOW_SPARKLE_STRENGTH 1.0 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0 2.5 3.0]

// ============ DIMENSIONS (main-menu DIMENSIONS screen, lib/dimension.glsl) ============
// RUNTIME Nether / End rendering from the Iris biome uniforms (biome_category
// + biome, double detection, no world folders). DIMENSION_FX 0 compiles every
// dimensional term out: the render is bit-identical to the previous pack in
// every dimension. 1 (default): the Overworld is untouched BY CONSTRUCTION
// (every term is weighted by dimNether()/dimEnd() = 0.0 there) and:
//  NETHER - sun/moon off, ambient = the biome fog chroma (crimson, warped,
//    soul sand, basalt each keep their hue) x NETHER_AMBIENT independent of
//    the zero skylight; LAVA LIGHT from a height map: the shadow pass (shadow.fsh)
//    keeps only the hot emitters (lava full, warm/soul families x0.35/x0.25)
//    along the frozen light axis, so ceilings above lava lakes glow and the
//    volumetric march raises red columns from the lakes (NETHER_VL); dense
//    warm fog 1/110 blocks (NETHER_FOG_DENSITY, NETHER_FOG_BRIGHT) colored by
//    the vanilla fogColor; fog-colored dome; no clouds/godrays/halo/stars;
//    bounded auto-exposure; height fog / dawn mist / golden hour / TC grade off.
//  END - violet-black dome + nebula (END_NEBULA) + cold stars, no Milky Way
//    /sun/moon/aurora; fixed cold directional light END_LIGHT with the normal
//    shadow map, ambient END_AMBIENT; thin violet fog 1/450 + void mist below
//    y = 40; cold VL shafts; godrays / golden hour / TC grade / clouds off.
//    END_STORM (below) layers the volumetric storm + lightning on top of it,
//    and END_BLACKHOLE (below) hangs a lensing black hole with a photon ring
//    and an accretion disk where the invisible End sun sits.
// Debug: DEBUG_VIEW 25 tints the screen red (Nether) / violet (End) / green.
#define DIMENSION_FX 1 // [0 1]
// Nether ambient level (fog-chroma ambient, x0.25 before AMBIENT_INTENSITY).
#define NETHER_AMBIENT 0.45 // [0.2 0.3 0.45 0.6 0.8 1.0]
// Vertical reach of the lava glow in blocks (exp(-blocks / reach)).
#define NETHER_LAVA_REACH 10.0 // [4.0 6.0 8.0 10.0 14.0 18.0 24.0]
// Strength of the lava light on surfaces (ceilings full, walls half, floors quarter).
#define NETHER_LAVA_LIGHT 1.0 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0]
// Strength of the volumetric lava columns in the Nether fog.
#define NETHER_VL 1.0 // [0.0 0.5 1.0 1.5 2.0 3.0]
// Nether fog density multiplier (1.0 = 1/110 blocks).
#define NETHER_FOG_DENSITY 1.0 // [0.3 0.5 0.75 1.0 1.5 2.0 3.0]
// Luminance of the Nether fog / dome (chroma stays the biome fogColor).
#define NETHER_FOG_BRIGHT 1.0 // [0.3 0.5 0.75 1.0 1.25 1.5 2.0]
// NETHER_VOLUMETRIC (composite1 VL march + lib/vl_halfres.glsl mirror, field
// in lib/dimension.glsl netherFogNoise): the Nether fog stops being a uniform
// exponential - every march step scales its density by an animated pseudo-3D
// value-noise field (two vnoiseTex slices blended in y, lattice ~24 blocks in
// xz / 16 blocks per slice in y, drifting (1.2, 0.5) blocks/s like rolling
// smoke, plus one 3x finer octave at 0.3 amplitude; the fine octave is
// skipped below VOLUMETRIC_QUALITY 2, so a Nether march step costs 2 noise
// taps there and 3 at VOLUMETRIC_QUALITY 2-3 - and only those: the Overworld
// patchy-bank tap is folded out in the Nether, where the height fog it feeds
// is zero anyway. At VOLUMETRIC_QUALITY 0 (4 march steps for ~160 blocks, far
// below the lattice) the amplitude is halved, same mean, to keep the
// under-sampled field from flickering before TAA. The field is normalized to
// MEAN 1.0 (to ~0.2 %: the baked noise averages 0.5015, not 0.5), so the
// average optical depth - and the default visibility - matches the uniform
// fog to well under a percent. The
// ambient in-scatter rides the same Beer-Lambert step, so the smoke sheets
// read everywhere in the air, and the lava columns (NETHER_VL) pierce the
// thick pockets brighter. 0 = the previous uniform fog, bit-identical (the
// whole field compiles out).
#define NETHER_VOLUMETRIC 1 // [0 1]
// Amplitude A of the density noise: the per-step multiplier spans [1-A, 1+A]
// around the same mean. 0.0 = uniform fog, 0.45 = calibrated smoke sheets,
// 0.85 = ragged banks. Average density never changes (A is halved internally
// at VOLUMETRIC_QUALITY 0, mean untouched).
#define NETHER_VOLUMETRIC_NOISE 0.45 // [0.0 0.25 0.45 0.65 0.85]
// End nebula brightness (0 = none, 2 = double).
#define END_NEBULA 1.0 // [0.0 0.5 0.75 1.0 1.25 1.5 2.0]
// End directional light (fixed noon sun, cold violet-white).
#define END_LIGHT 0.8 // [0.3 0.5 0.65 0.8 1.0 1.25 1.5]
// End ambient level (skylight-independent).
#define END_AMBIENT 1.0 // [0.3 0.5 0.75 1.0 1.25 1.5]
// ---- END STORM (lib/end_storm.glsl + lib/dimension.glsl) ----
// END_STORM=1 (default): "electric night storm" End. A volumetric storm
// volume surrounds the islands: twisted blue-night pillars rising from a
// dark storm sea under the islands, slowly revolving around the world
// origin (polar vortex, 1 turn / 5 min, helical twist with height), the whole
// lattice drifting through the world (END_STORM_DRIFT) and eroded by a
// drifting fine noise, cleared around the main island (a HARD END_ISLAND_CLEAR
// cylinder plus the sphere + ring hollows) and within ~90 blocks of the
// camera; feature size END_STORM_SCALE,
// march reach END_STORM_RANGE (all below). Lit from above by the fixed
// End light (2-tap self-shadowing), dark violet ambient, cyan multi-scatter
// in the thick lit mass, and from INSIDE by the lightning. Rendered like the
// cumulus: half-res temporal bake (prepare + prepare1, colortex15) composed
// by deferred on the sky, full-res bounded march in composite1 in front of
// distant terrain, inline in deferred when the half-res pass is off. The End
// palette shifts to blue-night (sky, haze, light, ambient; stars + nebula
// kept), the haze takes END_HAZE_DENSITY with an altitude profile (denser
// around the islands) and the closed-form void mist is replaced by the storm
// sea. Uses real time (the End clock is frozen). 0 = the previous End,
// bit-identical at default dials (every storm term compiles out;
// END_HAZE_DENSITY stays live, uniform profile).
#define END_STORM 1 // [0 1]
// Storm pillar density (0.25 = thin wisps, 3.0 = solid walls).
#define END_STORM_DENSITY 1.0 // [0.25 0.5 0.75 1.0 1.5 2.0 3.0]
// Feature size of the storm field: the pillar lattice, its fine erosion and
// the self-shadow taps scale together (4x ratio kept). 1.0 = the original
// 32-block xz / 110-block y lattice, 5.0 = 160-block pillars and gaps to
// match, 8.0 = 256-block cliffs, 12.0 the default (see the x2-3 pass note
// above the define). Coverage is
// scale-invariant within a few percent (the threshold cuts the same noise
// distribution at every scale; numerical integration gives +4% at 1.6 and at
// 3.0, -1% at 0.75), so no recalibration; the main island is protected by the
// scale-INDEPENDENT END_ISLAND_CLEAR cylinder below, not by the hollows. The
// march budget follows span / feature size (clamped to 0.5x - 2.0x the base
// budget), so a small scale with a long END_STORM_RANGE costs more steps
// instead of aliasing AND a coarse scale costs fewer steps instead of
// oversampling empty air: at the 5.0 / 720 defaults the march runs at half the
// previous step count while still sampling 1.6x finer per feature than the
// original 450-block / 1.0 tuning. Erosion wrap: that octave inherits the
// 256-unit vnoiseTex lattice, and since it is ANISOTROPIC (6.5 / 3.0 / 2.4,
// see lib/end_storm.glsl) the shortest world period is the x one, 1260 x this
// scale - 945 blocks at 0.75, which repeats TWICE across the 1800-block field
// at END_STORM_RANGE 900, so pick 1.5 or more for the longest ranges - but
// 6300 blocks at the 5.0 step and 10080 at 8.0 - and 15120 at the NEW 12.0
// default (20160 at 16.0), far past any range: no repeat in view. The z
// period is 3413 x this scale, longer still.
// x2-3 PASS (creator): default 5.0 -> 12.0 (384-block megaliths, ~two
// across the default 720 range - walls rather than a forest). STEP BUDGET
// UNCHANGED: the 0.5 low clamp of the span-per-feature factor is already
// engaged from 5.0 up (raw ratio 0.31 at 5.0, 0.128 at 12.0), so 10 / 12 /
// 16 cost exactly the same steps as 5.0. Delivered path (the live config is
// CLOUD_QUALITY 0): both the prepare bake AND composite1 land on the
// absolute max(8) floor - 8 steps over 690 blocks = 86.2-block mean step,
// i.e. 4.45 taps across a 384-block cell and 0.68 across the 59-block
// erosion cell (sub-1 tap: the erosion octave is undersampled at tier 0,
// the usual source of tower-edge crawl - raise CLOUD_QUALITY to feed it).
// At CLOUD_QUALITY 1 composite1 marches 12 steps (57.5-block step): 6.7 /
// ~1.0 taps, against 2.8 / 0.43 at 5.0 - the bigger field is also the
// better sampled one. Expert define HORS MENU, no "// [..]" list (PIEGE
// IRIS, contract of END_FOG_SHADOWS below): Iris does not register it, a
// stale .txt cannot pin it silently. Rollback = edit the value HERE.
#define END_STORM_SCALE 12.0
// March reach of the storm in blocks: the far arc fades out toward it and
// the composite1 haze veils the rest. The vortex spin is static past 0.9 x
// this range, so higher ranges show longer frozen spiral arms while short
// ranges keep the same anchored look; the step budget follows the range
// (per feature size, clamped 0.5x - 2.0x), so the cost grows with it; the
// prepare1 reprojection anchor sits at 240 blocks inside the band.
#define END_STORM_RANGE 720.0 // [480.0 560.0 640.0 720.0 800.0 900.0]
// DRIFT of the storm field (lib/end_storm.glsl): on top of the vortex the
// whole noise lattice TRANSLATES through the world, so the pillars are built
// and unbuilt as they pass instead of only revolving. 1.0 (default) = 1.5
// blocks/s horizontally plus a 0.15 block/s peak vertical heave that makes the
// towers breathe; 0.0 = the previous purely rotating field, bit-identical.
// frameTimeCounter wraps every 3600 s, so the drift path is an EXACT 3600-s
// closed loop (a circle of radius 859 x this dial, i.e. ~0.1 deg/s of veer:
// locally a straight line for any watchable stretch of time) and the field
// comes back exactly where it started at the wrap - no seam, at any scale, on
// every octave. A straight line instead would have to cover a whole lattice
// period per hour to match up (8192 x END_STORM_SCALE blocks = 27.4 blocks/s
// at the 12.0 default, and only the base octave would match). The vortex, the
// hollows and the island clearing never drift: they read the true world
// position.
#define END_STORM_DRIFT 1.0 // [0.0 0.25 0.5 1.0 1.5 2.0 3.0]
// HARD clearing around the main island, in blocks: the storm density is
// MULTIPLIED by 0 within this horizontal distance of the world origin over the
// island band (y -40 to +120, feathered over 40 blocks above and below), then
// rises by smoothstep to full at twice the distance. Being a multiplier it
// cannot be overcome by END_STORM_SCALE, END_STORM_DENSITY, the drift or the
// noise - nothing ever grows inside it, unlike the sphere + ring hollows
// (kept, they shape the clear air farther out) which were calibrated for
// 32-51 block features and would be swallowed by one 160-block tower.
// 100 (default) = the whole central island and its approach.
#define END_ISLAND_CLEAR 100.0 // [40.0 60.0 80.0 100.0 140.0 200.0]
// SCULPTING of the towers (lib/end_storm.glsl). The old shading read as flat,
// pale cotton for a measurable reason: the End sun is frozen at the ZENITH and
// the noise lattice is stretched 110 x END_STORM_SCALE blocks in y (550 blocks
// at the 5.0 default), so the two self-shadow taps 18 / 50 x SCALE blocks
// STRAIGHT UP read almost the same noise cell as the shaded point - and the
// 50 x 5 = 250-block tap left the storm band (top 230) for EVERY point above
// y = -20, i.e. the whole visible tower body, contributing exactly 0 with its
// 160-block weight. Measured over the lit mass the self-shadow term only
// spanned lt = 0.85..1.00 (a 1.17x range), so a crest at y = 170 and the body
// at y = 60 differed by 18 % of luminance: one flat slab.
// The march now integrates the mass ABOVE the sample in CLOSED FORM (no tap at
// all) and RAKES its light taps sideways so they cross the 32 x SCALE block xz
// lattice instead of climbing the same 550-block y cell. This dial scales the
// whole extinction toward the light: 1.0 gives lt = 0.001 (storm sea) -> 0.026
// (tower base) -> 0.14 (mid) -> 0.94 (crest), a ~700x range, and those same
// two samples now differ by 6x. 0.0 = no self-shadowing at all (the old wash).
// DEFAULT 0.75 ("moins fonces" pass): the mid-tower direct transmittance
// rises 0.14 -> 0.23 (x1.63) and the ladder still spans 0.006 -> 0.955
// (~170x) - the sculpting keeps its read, the body stops sitting in the
// dark. Measured on a mid-tower step (with the x1.30 direct term of
// lib/end_storm.glsl): lit luminance 0.037 -> 0.067 HDR (+82%), island-
// shadowed step 0.016 -> 0.022 (+42%). NOTE the honest frame: the
// INTEGRATED lit/island-shadowed ratio of a full march was already ~2.9-3.1x
// with the old constants and moves to ~3.1-3.4x (+5-9%) - the real gain of
// this pass is the BRIGHTNESS of both sides, not the shadow contrast (any
// 2.3x -> 3.0x reading is a single-step figure at core ~0.6, not the
// rendered pixel). Expert define HORS MENU, no "// [..]" list (PIEGE IRIS,
// contract of END_FOG_SHADOWS below): Iris does not register it, a stale
// .txt cannot pin it silently. Rollback = edit the value HERE.
#define END_STORM_CONTRAST 0.75
// END_FOG_SHADOWS (passe "MEN") : l'OMBRE DES ILES dans l'orage de l'End. Le
// sculpting ci-dessus est un AUTO-ombrage (colonne analytique + 3 taps rakes
// dans le champ de densite) : les iles d'obsidienne n'existent pas dans ce
// champ, donc elles ne pouvaient PAS projeter dans l'orage - alors que la
// shadow map de l'End (soleil fige a midi) fonctionne et carve deja la brume
// violette du march VL (composite1/vl_halfres, taps "vis" par pas). 1 =
// UN tap shadowtex1 brut par pas DENSE du march de l'orage
// (lib/end_storm.glsl, meme mecanique que le VL : biais constant
// VLX_SHADOW_ZSCALE, fail-open hors de la map XY et au-dela du Z du frustum,
// donc l'orage au-dela de shadowDistance est intouche) ; il eteint le terme
// DIRECTIONNEL (crete cyan + rim) du pas ombrage, l'ambiant violet reste.
// 0 = legacy, bit-identique (svE constant 1.0, plie a la compilation).
// Define expert HORS MENU, SANS liste "// [..]" (PIEGE IRIS) : Iris ne
// l'enregistre pas, donc un .txt perime ne peut pas le basculer en silence.
// Rollback = editer la valeur ICI. (VL_FULL_RES garde sa liste, lui : c'est
// un define expert DE FICHIER, son enregistrement est son mecanisme --
// shaders.properties, bloc "NE JAMAIS EXPOSER".)
#define END_FOG_SHADOWS 1 // gate hors menu, sans liste (non enregistre par Iris)
// Cold tint of the storm: how far the LIT crests go cyan and the torn wisp
// edges go magenta over the deep blue-violet body. 0 = the crests keep the raw
// End light hue (blue-white), 1.0 (default) = the full electric look. The
// 0.75 detour is REVERTED: it compensated a disk chroma in dimEndLight that
// was ~3x too saturated (the old (1.504, 0.902, 0.486) constant); with the
// true Planckian disk colour (1.051, 1.007, 0.776) the warmth is mild and
// the full-strength cyan no longer fights it to grey, so the compensation
// lost its reason. Expert define HORS MENU, no "// [..]" list (PIEGE IRIS,
// contract of END_FOG_SHADOWS below): Iris does not register it, a stale
// .txt cannot pin it silently. Rollback = edit the value HERE.
#define END_STORM_TINT 1.0
// SILHOUETTE sharpness: width of the coverage ramp on the noise, as a fraction
// of the original 0.18, kept CENTRED on the same midpoint so the mean coverage
// does not move (1.0 reproduces the old curve exactly). It matters more than
// it looks: the march step is 47-125 blocks at the default dials, so a single
// sample at density 0.3 already paints 87 % opacity - the cottony halo around
// every tower IS that ramp, and 0.55 makes it 45 % narrower.
#define END_STORM_EDGE 0.55 // [0.3 0.45 0.55 0.7 0.85 1.0 1.3]
// End haze density multiplier (1.0 = 1/450 blocks at island altitude).
// Works with or without END_STORM; the altitude profile needs the storm.
#define END_HAZE_DENSITY 1.0 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0 3.0]
// END_LIGHTNING: random strikes (hash of a 1-s slot of frameTimeCounter, no
// history buffer), 0.15-0.4 s with 2-3 sub-flashes, bolt 110-260 blocks from
// the camera inside the storm band. No bolt geometry: a point light inside
// the storm march, a glow on the sky haze and in the volumetric fog, a brief
// half-Lambert light on every surface (no shadow map) and a faint screen
// flash (END_LIGHTNING_FLASH). Rate 1.0 = 10% per second (one strike every
// ~10 s on average), never more than one per second.
#define END_LIGHTNING 1 // [0 1]
#define END_LIGHTNING_RATE 1.0 // [0.25 0.5 0.75 1.0 1.5 2.0 3.0 5.0]
// Lightning color (default magenta).
#define END_LIGHTNING_R 1.0 // [0.0 0.25 0.5 0.75 1.0]
#define END_LIGHTNING_G 0.0 // [0.0 0.25 0.5 0.75 1.0]
#define END_LIGHTNING_B 0.5 // [0.0 0.25 0.5 0.75 1.0]
// Faint full-screen flash on each strike (post-tonemap, <= +0.09).
#define END_LIGHTNING_FLASH 1 // [0 1]
// How hard a strike lights the storm from INSIDE and glows in the haze. The
// old kernel 1.0e4 / (r^2 + 2500) was measurably present and visually nothing:
// for a bolt 150 blocks away it peaked at +30 % of the local tower luminance
// and averaged ~+10 % over the pulse. The kernel is now 4.0e4 / (r^2 + 1800)
// x this dial (+163 % at the same 150 blocks) and the pulse carries a short
// REMANENCE, so the towers keep glowing for a beat after the flash.
#define END_LIGHTNING_POWER 1.0 // [0.0 0.35 0.5 0.75 1.0 1.5 2.0 3.0]
// Procedural bolt CHANNEL: a jagged vertical filament of light drawn inside
// the storm material around the strike (a wobbling core plus a wide halo,
// faded over +-150 blocks of the strike altitude). It is added on lit storm
// samples ONLY, so it never draws a line across clear air, and it costs about
// 20 ALU on the frames where a strike is live. 0 = the point light alone,
// bit-identical to the previous strike.
#define END_LIGHTNING_BOLT 1 // [0 1]
// ---- END BLACK HOLE (lib/blackhole.glsl) ----
// END_BLACKHOLE=1 (default): a supermassive black hole takes the empty spot
// where the invisible End sun hangs. Schwarzschild geometry, BH3 revision -
// ANCHORED ON THE SHADOW AXIS: endBlackHoleDir() now reads
// shadowLightPosition (frozen by the End's fixed_time 6000 + this pack's
// sunPathRotation -35 at exactly 55.0 deg above the horizon), so the hole
// stands EXACTLY where the light that draws every End shadow comes from -
// shadows point away from it, the storm and the fog light from its side,
// and dimEndLight carries its colour (BLACKHOLE_LIGHT below):
//  - an apparent shadow of angular radius theta_s = 3.5 deg x BLACKHOLE_SIZE
//    (12.2 deg ACROSS at the 1.75 default) hanging 55 deg up the shadow
//    axis, lowered 15 deg by the BLACKHOLE_ELEVATION 0.5 default (below):
//    on the axis itself everything bright asks ~14 deg of pitch-up (the
//    26.8-deg slab reach below the centre is the unlit rOut fade, ~0.1 %
//    of the flux), at 0.5 the bright lower disk sits in a level 70-deg
//    view;
//  - a thin white-blue PHOTON RING at its edge, the unresolved pile-up of
//    every image of order >= 2;
//  - STRONG-FIELD LENSING of the whole End background. The deflection is no
//    longer the weak-field 1/theta capped near the rim: it is
//    alpha(u) = ln(1 + A/(u-1)) + R/u with u = theta/theta_s, which is the
//    weak-field law 4/sqrt(27)/u exactly at large u AND the true LOGARITHMIC
//    divergence -ln(u-1) at the photon sphere. It reaches 89 deg at 1.2
//    theta_s, so the sky just outside the rim shows what is BEHIND the hole
//    and the whole cascade of higher-order images falls out on its own;
//  - MAGNIFICATION on the star field (stars are point sources, so the lens
//    scales their FLUX): that is what makes the Einstein ring a real ring of
//    light instead of a pile of dots;
//  - a thick ACCRETION SLAB, not a plane: BLACKHOLE_STEPS samples marched
//    front to back through a torus of half thickness BLACKHOLE_THICK x r, so
//    its near face hides its far face and its edge reads as a solid bar. Its
//    NEAR half is drawn UNLENSED and IN FRONT of the shadow (BLACKHOLE_FRONT)
//    - the Interstellar composition, and the fix for the three disconnected
//    bright patches the edge-on setting used to show;
//  - a real BLACK-BODY colour ramp: T(r) = BLACKHOLE_TEMP x (r_in/r)^0.75,
//    then the gravitational redshift sqrt(1 - Rs/r) and the Doppler factor
//    multiply it, because a black body seen through a redshift g IS a black
//    body at T x g - so the inner rim reddens and dims, one limb goes
//    blue-white and the other deep red, all from one temperature;
//  - a LIVING slab: Keplerian shear, two noise octaves, a 2-arm logarithmic
//    spiral density wave and two hot spots orbiting at the Keplerian speed of
//    their own radius.
// Drawn on the End SKY pixels only (behind the terrain, under the storm and
// the haze) and reused for free by every reflection through getSkyCelestial;
// DEBUG_VIEW 26 false-colours its contributions. Approximation, not a
// geodesic integrator: the deflection is exact in both limits but the slab is
// still intersected along the asymptotic ray, and the near/far split is a
// smoothstep, not a ray trace. 0 = the previous End, bit-identical (every
// term compiles out).
#define END_BLACKHOLE 1 // [0 1]
// Apparent size: 1.75 (default) = a shadow 12.2 deg across (6.1 deg radius)
// with the slab spanning some 35 deg, 1.0 = 7 deg across, 3.0 = a wall of
// night. The lensing, the ring and the slab all scale with it - and so does
// the near half sweeping in front of the shadow, so raising it past 2.5 does
// bury that part of the sky under one glow.
#define BLACKHOLE_SIZE 1.75 // [0.5 0.6 0.75 0.9 1.0 1.15 1.3 1.5 1.75 2.0 2.5 3.0]
// OFFSET below the shadow axis, the hole's anchor (was an absolute position).
// 0 = EXACTLY on the axis: the black hole is where the shadow light comes
// from, every End shadow points away from it - but at 55 deg up, NOTHING
// bright enters a level 70-deg view (measured: frame max 0.029 HDR, ~0.1 %
// of the object's flux under 35 deg; the first bright pixel asks ~14 deg of
// pitch-up). Each step pulls the hole 30 deg x dial lower along the same
// azimuth. DEFAULT 0.5 = 40 deg up: the bright lower disk stands in the
// level frame (max 15.4 HDR there) and shadows point only 15 deg off the
// hole - the visibility/coherence trade this pack ships. 1.0 = 25 deg up,
// the old low framing. Expert define HORS MENU, no "// [..]" list (PIEGE
// IRIS, same contract as END_FOG_SHADOWS below): Iris does not register it,
// a stale .txt cannot pin it silently. Rollback = edit the value HERE.
#define BLACKHOLE_ELEVATION 0.5
// Inclination of the accretion slab, from nearly edge-on to face-on: 0 = 2.4
// deg (edge-on - now a real BAR, since the slab has thickness and its near
// half crosses in front of the shadow instead of being cut by it), 0.3
// (default) = 19 deg, the cinema look, 1.0 = 60 deg.
#define BLACKHOLE_TILT 0.3 // [0.0 0.1 0.2 0.25 0.3 0.35 0.4 0.5 0.6 0.75 0.9 1.0]
// Brightness of the accretion slab (the photon ring keeps its own level, so
// 0 leaves the shadow, the ring and the lensing alone). Intensity only: the
// colour ramp lives in BLACKHOLE_TEMP.
#define BLACKHOLE_DISK_BRIGHT 1.0 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 2.0 3.0]
// How much the fixed End light and ambient take the CHROMA of the accretion
// disk (the true unit-luma Planckian ~4600 K disk colour, lib/dimension.glsl):
// with the hole anchored on the shadow axis this light IS the disk's, so the
// default rises to 0.5. Luminance is preserved exactly at every value - the
// dial recolors, never dims. 0 = exactly the previous End palette. Expert
// define HORS MENU, no "// [..]" list (PIEGE IRIS, contract of
// END_FOG_SHADOWS above): Iris does not register it, a stale .txt cannot pin
// it silently. Rollback = edit the value HERE.
#define BLACKHOLE_LIGHT 0.5
// ---- BLACK HOLE, physical dials (all consumed by lib/blackhole.glsl) ----
// EMITTED temperature at the inner edge of the accretion slab, in kelvin. The
// thin-disc law T(r) = BLACKHOLE_TEMP * (r_in/r)^0.75 runs it down to about a
// third of that at the rim, then the gravitational redshift and the Doppler
// factor shift it again per pixel: the observed element is a black body at
// T x g, so ONE number sets the whole ramp. 7000 K is the Interstellar look
// (white-hot inside, amber rim, blue-white approaching limb, deep red
// receding one); 20000+ K gives a hard blue quasar.
#define BLACKHOLE_TEMP 7000.0 // [3500.0 4500.0 5500.0 7000.0 8500.0 11000.0 15000.0 20000.0 26000.0]
// Strength of the relativistic Doppler asymmetry (beaming + colour shift).
// 0 = none, the cinema cheat where both limbs read the same; 1.0 = the
// physical factor 1/(gamma (1 - beta_los)); above 1 exaggerates it.
#define BLACKHOLE_DOPPLER 1.0 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5]
// HALF THICKNESS of the accretion slab as a fraction of the orbital radius.
// 0 = the infinitely thin disc of the previous revision (a razor line seen
// edge-on); 0.085 = a real torus whose near face hides its far face and whose
// rim reads as a solid bar. This is the dial that makes the hole look 3D.
#define BLACKHOLE_THICK 0.085 // [0.0 0.02 0.04 0.06 0.085 0.12 0.16 0.22]
// Samples taken across the slab, front to back (the self-occlusion). 1 = the
// old thin-disc cost, 4 = the default, 8 = butter-smooth edges.
#define BLACKHOLE_STEPS 4 // [1 2 3 4 5 6 8]
// Amplitude of the 2-arm logarithmic SPIRAL density wave riding the slab.
// 0.0 leaves the filaments alone, bit for bit (mix(x, y, 0.0) == x).
#define BLACKHOLE_SPIRAL 0.35 // [0.0 0.15 0.25 0.35 0.5 0.7]
// Two HOT SPOTS orbiting at the Keplerian speed of their own radius.
// 0 = the block is not compiled at all (bit-identical to no hot spots).
#define BLACKHOLE_HOTSPOTS 1 // [0 1]
// Draw the NEAR half of the slab unlensed and IN FRONT of the shadow (the
// Gargantua composition: the near arc sweeps across the black disc). 0 = the
// previous behaviour, one lensed march over the whole slab, so the disk can
// only pass BEHIND the shadow.
#define BLACKHOLE_FRONT 1 // [0 1]
// Thin bluish polar JETS along the slab axis. OFF by default; at 0 not one
// instruction of the jet is emitted.
#define BLACKHOLE_JET 0 // [0 1]
// Warm DISK-SIDE rim on the storm towers (needs END_STORM and END_BLACKHOLE):
// the accretion disk is the only real source left in the End sky, so the
// pillars standing between the camera and the hole catch an orange
// forward-scatter on their thin edges. One clamped phase evaluation per ray,
// no extra density tap; it only shows within ~35 deg of the hole. 0 = off.
#define END_STORM_BH_TINT 0.5 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0]
// Derived gates. END_STORM_ACTIVE: every storm / lightning term compiles in.
// END_STORM_PREPARE: the storm rides the half-res cloud pipeline (prepare
// bake + prepare1 temporal resolve + deferred composite); without it the
// deferred sky pass marches the storm inline at full resolution.
#if DIMENSION_FX == 1 && END_STORM == 1
#define END_STORM_ACTIVE
#ifdef CLOUD_PREPARE_ACTIVE
#define END_STORM_PREPARE
#endif
#endif
// END_BLACKHOLE_ACTIVE: the whole of lib/blackhole.glsl and its call site in
// skyEndDim (lib/sky.glsl) compile in, plus the palette tint of
// lib/dimension.glsl. Without it not one instruction of the hole is emitted.
#if DIMENSION_FX == 1 && END_BLACKHOLE == 1
#define END_BLACKHOLE_ACTIVE
#endif

// ============ BIOMES & CAVES ============
#define BIOME_ATMOSPHERE
#define BIOME_ATMO_STRENGTH 1.0 // [0.0 0.5 1.0 1.5 2.0 3.0 5.0 8.0]
// Cave fog OFF by default (user: distant dark areas were not blending into
// the fog; deep-fog fix lives in composite1). Toggle still available in menu.
//#define CAVE_FOG
#define CAVE_FOG_STRENGTH 1.0 // [0.0 0.5 1.0 1.5 2.0 3.0 5.0 8.0]

// ============ ATMOSPHERE ============
// ---- DIMENSION DETECTION FIX (deferred.fsh). The naive heuristic
// (luma(skyColor) > 0.004 || fogColor.g > fogColor.r) fails in the Overworld at night
// (skyColor ~ black) as soon as the fog turns NEUTRAL GREY or warm (rain, deep night:
// g <= r), which paints the End's PINK nebula sky over open plains.
// ON: (1) eyeBrightnessSmooth.y > 8 forces Overworld - the Nether and the End have NO
// skylight (y=0 there), so an eye receiving sky light must be in the Overworld;
// (2) neutral grey fog (g >= r) counts as Overworld (the End is purple r>g and the Nether
// orange/crimson r>g, so neither is ever caught by this test).
// 0 = legacy heuristic.
#define DIM_DETECT_FIX 1 // [0 1]
//#define PHYSICAL_SKY
// (off by default: the analytic atmosphere is lighter)
#define ATMO_INTENSITY 1.0 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 2.0 3.0 5.0 8.0]
#define RAYLEIGH_STRENGTH 1.0 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 2.0 3.0 5.0 8.0]
#define MIE_STRENGTH 1.0 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0 3.0 5.0 8.0 12.0]
#define ATMO_ALTITUDE_BOOST 1.0 // [0.0 0.5 1.0 2.0 4.0 8.0 16.0 32.0]
#define FOG_DENSITY 1.0 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0 3.0 4.0 6.0 10.0 20.0]
// DISTANCE_FOG : le "mur" de brouillard vanilla en toute fin de render distance
// (fogF exponentiel de composite1, rescale a dhRenderDistance quand DH est actif).
// 0 = OFF (defaut) : seuls les brouillards VOLUMETRIQUES (ATMO_FOG, HEIGHT_FOG,
// VOLUMETRIC_LIGHT, CAVE_FOG) habillent la distance. 1 = ancien comportement EXACT.
// NB : FOG_DENSITY ne pilote QUE ce mur -> inerte quand DISTANCE_FOG=0.
#define DISTANCE_FOG 0 // [0 1]
// DH_EDGE_FADE : avec DISTANCE_FOG=0, la fin des LODs Distant Horizons couperait
// NET contre le ciel (silhouette de terrain tronquee a dhRenderDistance -> pop).
// 1 = fondu doux des ~10 derniers % de dhRenderDistance vers la couleur d'horizon
// (pixels DH uniquement, terrain vanilla et ciel intacts). 0 = coupe brute.
#define DH_EDGE_FADE 1 // [0 1]
// DH_WATER_CLIP : les programmes dh_* n'ont QUE le depth buffer DH (dhDepthTex*)
// pour leur test de profondeur — la geometrie vanilla n'y existe pas — et dh_water
// blende directement dans colortex0 : une nappe d'ocean LOD a 600 blocs se
// composait PAR-DESSUS un mur vanilla a 5 blocs ("l'eau a travers les murs").
// 1 (defaut) = dh_water.fsh discard tout fragment LOD situe derriere l'opaque
// vanilla du meme pixel (Z vue via gbufferProjectionInverse contre depthtex1 —
// opaque seul : l'ocean LOD reste visible a travers une vitre ; marge 2 blocs
// cote maintien pour l'anneau de couture). 0 = comportement brut d'avant.
// dh_terrain n'en a pas besoin : il dessine en phase OPAQUE, AVANT le terrain
// vanilla, qui recouvre donc ses pixels — et depthtex1 n'est pas encore fige la.
#define DH_WATER_CLIP 1 // [0 1]
// DH_FOG_SCALE : les brouillards de distance ANALYTIQUES (ATMO_FOG + miroir DH,
// AERIAL_PERSPECTIVE, traine HEIGHT_FOG, traine DAWN_MIST — composite1) ont des
// densites par bloc ABSOLUES calibrees pour un monde qui s'arrete a far
// (~192-384) : avec DH le terrain porte a dhRenderDistance (512-1024+) et les
// memes constantes en faisaient un MUR (~50 % de voile des ~230 blocs, ~90 % a
// 512 — le LOD etait efface, a l'inverse du but de DH ; les silhouettes LOD
// sortaient meme PLUS brumeuses que le ciel derriere elles). 1 (defaut) = quand
// DH est actif, chaque distance caracteristique est multipliee par
// dhRange/far — soit densites x (far / max(dhRenderDistance, far)), le facteur
// dhFogK de composite1. C'est EXACTEMENT la transformation que le fogF de
// DISTANCE_FOG applique deja (far*0.85 -> dhRange*0.85) : le brouillard
// redevient la meme fonction de la profondeur RELATIVE (dist/portee) que le
// rendu vanilla calibre. UN facteur unique applique aux DEUX cotes de la
// couture vanilla/DH -> aucune marche a la frontiere. La marche VL (0-160),
// CAVE_FOG et les brouillards d'eau ne bougent pas (milieux du champ proche).
// Mesure a dhRenderDistance 512 / far 192 (midi, niveau mer, ray horizontal) :
// contraste terrain 50 % a ~230 blocs avant -> ~430 blocs (84 % de la portee)
// apres ; a 512 blocs le terrain garde ~42 % de contraste au lieu de ~10 %.
// 0 = mur d'avant, bit-identique (dhFogK = 1.0).
#define DH_FOG_SCALE 1 // [0 1]
// Perspective aérienne : in-scattering doré vers le soleil sur les reliefs lointains.
//#define AERIAL_PERSPECTIVE
//#define SQUARE_SUN
#define SUN_SIZE 0.04 // [0.005 0.01 0.02 0.03 0.04 0.06 0.08 0.10 0.2 0.5 1.0]
// ---- CONFIG_SKY appearance dials (getSkyBase, lib/sky.glsl). The analytic
// gradient is THE shared source: sky dome, reflections and fogs all inherit
// any tint set here (intended). Defaults = exact current render.
// Final per-channel multipliers on the whole gradient.
#define SKY_TINT_R 1.0 // [0.7 0.8 0.9 0.95 1.0 1.05 1.1 1.2 1.3]
#define SKY_TINT_G 1.0 // [0.7 0.8 0.9 0.95 1.0 1.05 1.1 1.2 1.3]
#define SKY_TINT_B 1.0 // [0.7 0.8 0.9 0.95 1.0 1.05 1.1 1.2 1.3]
// Horizon-band brightness relative to the zenith (scales the horizon colors, day and night).
#define SKY_HORIZON_LIFT 1.0 // [0.7 0.8 0.9 0.95 1.0 1.05 1.1 1.2 1.3]
// Night-sky luminance (scales the night zenith/horizon base colors only).
#define SKY_NIGHT_BRIGHT 1.0 // [0.5 0.65 0.8 0.9 1.0 1.15 1.3 1.6 2.0]
// ---- SKY_DUSK_V2 (HORS MENU) : la bande du crepuscule sans magenta.
// BUG UTILISATEUR "l'eau devient mauve avec le brouillard" - CAUSE PROUVEE PAR
// MESURE (agent eau, getSkyBase seul, sans eau ni brouillard, soleil a -0.05) :
// lib/sky.glsl interpolait EN RGB du bleu du ciel directement vers le
// rouge-orange (1.0, 0.34, 0.09) ; tout point intermediaire est magenta (rouge
// + bleu, vert absent) : teinte 326 deg / violet 0.369 a 110 deg du soleil.
// L'eau le MONTRE parce qu'au-dela de 90 blocs elle est un miroir de ciel
// (PERF_WATER_FAR_SIMPLE) et que les voiles (VL, ATMO_FOG) portent le meme
// ciel. WATER_FOG_HUE a corrige ce que l'eau ajoutait (+16.5 deg vers le
// violet) ; ceci corrige la source.
// FIX : le chemin passe par un neutre chaud (peche dore, vert eleve) et ne
// rejoint le rouge-orange profond qu'au carre du poids : couleur du coeur du
// coucher IDENTIQUE, seule la transition change (gris-lavande pale au lieu de
// magenta franc). 0 = ligne d'origine verbatim.
#define SKY_DUSK_V2 1 // transition du crepuscule via un neutre chaud (0 = melange RGB direct d'origine)

// DEBANDING : bruit triangulaire +-1/255 juste avant la quantification 8 bits
// (final.fsh) — les MARCHES de degrade (ciel, brouillard, flous, bloom)
// deviennent invisibles. Demande user : "AUCUN pixel visible".
// ### FIGE PAR LA PASSE "MENUS2" - PLUS AUCUN CONTROLE EN JEU, VALEUR DEFINITIVE 1.
// Mot du createur : "ya des toggles genre debanding, retire, ce sera toujours ON
// par defaut pour toujours, donc juste retirer". C'est une correction technique
// de la quantification 8 bits, invisible quand elle marche et laide quand elle
// manque : il n'existe aucune raison de la couper, donc aucune raison de la
// montrer. Le "// [0 1]" est retire pour qu'Iris cesse de l'annoncer comme
// option (une vieille config portant DEBAND=0 ne peut plus la neutraliser).
#define DEBAND 1 // FIGE : anti-banding, toujours actif

// ============ ANTI-ALIASING TEMPOREL ============
// TAA : accumulation frame-à-frame → edges lisses + GI stabilisé
#define TAA
// audit : TAA ON par defaut — le denoiser PT, le motion blur (compile DANS
// #ifdef TAA) et la stabilite des reflets en dependent ; il etait off.
// ISSUE 1 : force du jitter sous-pixel (transforme le TAA en supersampling temporel).
// Gate par MULTIPLICATION dans les vsh (jamais #if sur un float). 0.0 = pas de jitter.
#define TAA_JITTER 1.0 // [0.0 0.25 0.5 0.75 1.0]
// ISSUE 3 : rejet du fantome TAA sur les silhouettes d'entites mobiles devant le ciel.
// Selection RUNTIME sur un INT (#if sur int autorise). 0 = off, 1 = on.
#define TAA_GHOST_REJECT 1 // [0 1]
// A2 TAAU : TAA UPSCALING (experimental, defaut OFF). Le rendu 3D tourne en
// sous-resolution dans le coin BAS-GAUCHE du framebuffer (echelle lineaire
// TAAU_RENDER_SCALE) et composite4 reconstruit la pleine resolution avec le
// jitter temporel Halton. TAAU_S (lib/common.glsl) = TAAU_RENDER_SCALE quand
// actif, sinon 1.0 — toutes les multiplications se plient alors a la
// compilation (zero cout, zero difference OFF). Necessite TAA actif (gate
// "defined TAA" dans common.glsl). Slider int : #if autorise.
// TAA_UPSCALING : derive de TAA_MODE (bloc AXES DE MENU, haut de ce fichier)
// Echelle lineaire du rendu TAAU (0.75 = ~56% des pixels shades par frame).
// Inerte tant que TAA_UPSCALING = 0.
// TAAU_RENDER_SCALE : derive de TAA_MODE (bloc AXES DE MENU, haut de ce fichier)

// ---- TAA_V2 : POLISH DU RESOLVE TEMPOREL (composite4) ----
// Plainte a l'origine de la passe : "pas si stable, des fois des clignotements,
// le moindre mouvement rend le resultat pas ouf".
// DIAGNOSTIC (modele numerique 1D, scratchpad taa_sim3.py / taa_sweep.py -- un
// MODELE, pas une prediction du jeu : 1D, niveaux de gris, reprojection camera
// exacte). Ecart-type TEMPOREL par pixel, image posee, camera immobile :
//   bande HAUTE FREQUENCE (feuillage + eclats HDR) : 0.108 avant TAA
//                                                 -> 0.0133 apres (-88 %)  OK
//   bande LISSE mais BRUITEE DANS LE TEMPS (GI/SSR
//   denoises : sigma SPATIAL ~ 0)               : 0.0122 avant TAA
//                                                 -> 0.0112 apres (-8 %)   NON
// La deuxieme ligne EST le clignotement. La boite de clipping du resolve est
// batie sur le voisinage 3x3 de l'image COURANTE, c'est-a-dire sur une mesure
// SPATIALE : sur une surface spatialement lisse qui varie dans le TEMPS, sigma
// vaut ~0, la boite se referme sur l'image courante et l'historique est ecrase
// a chaque image -- le TAA n'y fait litteralement plus rien. Baisser le poids
// de melange n'y change RIEN : le clip agit AVANT le melange.
// LE CORRECTIF : chaque pixel mesure sa propre instabilite temporelle
// (moyenne exponentielle de |delta luma| entre l'image courante et
// l'historique BRUT) et la range dans colortex7.a -- un canal libre : rien
// dans le pack ne lit l'alpha de colortex7 (composite1 n'en prend que .rgb),
// et les 5 lectures Catmull-Rom du resolve ramenent deja le vec4 complet, donc
// la statistique coute ZERO tap. L'image suivante, la demi-largeur de la boite
// recoit un terme ADDITIF k*instabilite, dans les memes unites (tonemappees).
// ADDITIF et pas multiplicatif : un terme en facteur de sigma est nul la ou
// sigma est nul, c'est-a-dire exactement sur la surface a proteger (mesure :
// widening x sigma -> 0.0096 sur la bande lisse, widening additif -> 0.0053).
// MESURE (k=2.0, plafond 0.04, palier "Eleve") contre le resolve livre :
//   scintillement haute frequence  0.01327 -> 0.00679  (-49 %)
//   scintillement surface lisse    0.01123 -> 0.00534  (-52 %)
//   ERREUR vs l'anticrenelage exact 0.0570 -> 0.0308  (-46 %, donc plus NET
//                                   en meme temps que plus stable)
//   scintillement en panoramique   0.05161 -> 0.04127 (-20 %)
//   PRIX ASSUME : tramage (ghosting) derriere un objet mobile +17 %.
// Le plafond TAA_INST_CAP est ce qui borne ce prix : au-dela de 4 % de luma
// affichee, un changement n'est plus un scintillement, c'est un vrai
// changement, et la boite ne doit pas l'absorber.
// 0 = composite4 VERBATIM (rollback : le SPIR-V redevient identique au livre,
// verifie par hash). HORS menu, SANS liste (PIEGE IRIS : Iris ne l'enregistre
// pas, un .txt perime ne peut pas le basculer).
#define TAA_V2 1 // gate hors menu, sans liste (non enregistre par Iris)
// TAA_QUALITY : derive en 3 paliers (bloc AXES DE MENU, haut de ce fichier).
// Constantes de calibration, HORS menu, inertes a TAA_V2 = 0.
// Largeur du fondu de l'historique au BORD de l'ecran, en pixels. Le code
// livre basculait le melange a 1.0 (image courante BRUTE, non anticrenelee) des
// que la reprojection sortait de [0,1] : un texel de crenelage pur colle a un
// voisin converge, soit une bande qui rampe sur le bord fuyant a chaque
// mouvement de camera. 0 rendrait la falaise d'origine.
#define TAA_EDGE_PX 3.0 // fondu de bord d'ecran, en pixels
// Elargissement de la boite avec la DISTANCE de reprojection (en pixels,
// sature a 2) : plus l'historique a voyage, moins son reechantillonnage est
// fiable. Palier "Eleve" seulement.
#define TAA_VEL_GAMMA 0.35 // gamma += k * min(deplacement_px, 2)
// Gain du terme additif d'instabilite (palier "Eleve"). Mesures au meme
// plafond 0.04 -- scintillement haute frequence, puis surcout de tramage :
//   k = 1.0  0.00897  (+6 %)      k = 2.0  0.00679  (+17 %, LIVRE)
//   k = 1.5  0.00766  (+10 %)     k = 2.5  0.00609  (+24 %)
#define TAA_INST_K 2.0 // demi-largeur additive = k * min(instabilite, cap)
// Plafond de l'instabilite prise en compte, en luma TONEMAPPEE : c'est lui qui
// borne le tramage. Mesures a k = 2.0 : plafond 0.04 -> +17 %, 0.06 -> +30 %,
// 0.08 -> +57 %, 0.10 -> +105 %. C'est ce genou de la courbe qui fixe 0.04.
#define TAA_INST_CAP 0.04 // plafond de l'instabilite absorbee
// Taux de la moyenne exponentielle de l'instabilite (0.25 = ~4 images).
#define TAA_INST_RATE 0.25 // taux de la moyenne exponentielle
// Garde de silhouette : quand la dilatation de vitesse a pris le mouvement d'un
// voisin PLUS PROCHE (d0 > dClose), l'historique appartient a un autre objet.
// L'elargissement est coupe des que les deux reprojections divergent de tant de
// pixels. C'est ce qui empeche le terme d'instabilite de faire trainer le
// lisere d'un pixel autour d'une main ou d'un mob.
#define TAA_SIL_PX 2.0 // divergence de reprojection coupant l'elargissement

// ---- TAA_V3 : CORRECTIF DE REGRESSION DE TAA_V2 SUR LE CIEL ----
// PLAINTE UTILISATEUR apres la livraison de TAA_V2 : "le TAA est devenu
// TERRIBLE, surtout avec les nuages : le moindre mouvement, ca devient
// n'importe quoi" + "un effet de transparence sur les nuages, je vois les
// nuages derriere les nuages".
// CAUSE, TROUVEE ET MESUREE (modele 1D de la CHAINE NUAGES complete : bake
// demi-res interleave -> resolve prepare1 -> composition -> TAA ; scratchpad
// cl_lib.py / cl_run2.py / cl_fix.py / cl_worst.py) :
// composite4 NE REPROJETTE PAS LE CIEL. Un pixel dont tout le voisinage 3x3
// est du ciel a dClose == 1.0, le bloc de reprojection est saute et
// l'historique est lu a histUV == uv -- au MAUVAIS endroit de l'ecran des que
// la camera tourne. Le code livre y survivait parce que la boite de variance
// jetait cet historique perime ; l'elargissement par instabilite de TAA_V2
// (cran Eleve) ouvre exactement cette boite. Mesures, camera a 45 deg/s en
// marchant, contre le resolve precedent (cran Moyen) :
//   erreur moyenne         0.088 -> 0.344  (x3.9)
//   energie de fantome     34 % -> 72 %
//   longueur de trainee    0.48 -> 2.14 images (l'image affichee a deux images
//                          de retard EN MOYENNE : c'est le double de nuages)
// Trois aggravations en cascade, toutes verifiees :
//   1. mvPx vaut 0 sur tout le ciel (uv - histUV == 0), donc TOUTE garde de
//      vitesse de ce fichier y est AVEUGLE.
//   2. la garde de silhouette de TAA_V2 ne peut JAMAIS se declencher en plein
//      ciel (d0 == dClose == 1.0) : elle ne protegeait que le lisere d'un
//      pixel la ou le ciel touche le terrain.
//   3. la boite elargie est le DENOMINATEUR du rejet de fantome : elargir la
//      boite eteignait le garde-fou cense borner le prix de l'elargissement,
//      exactement la ou ce prix etait le plus grand.
// Et TAA_INST_CAP borne le cout MOYEN, jamais le cout LOCAL : au meme plafond
// 0.04, la moyenne est multipliee par 3.9 mais le p99 monte a 1.22 et le pic a
// 1.89, soit le contraste plein des nuages -- le fantome est aussi lumineux
// que le nuage. D'ou un plafond dur en plus (TAA_INST_MAX).
// LE CORRECTIF : le ciel se reprojette en ROTATION PURE a l'infini (le meme
// calcul que MOTION_BLUR reconstruit deja pour lui-meme, donc le flou de
// mouvement est inchange), et l'elargissement est borne des trois cotes.
// MESURES apres correctif (moyenne / p99), contre le cran Moyen precedent :
//   panoramique lent 20 deg/s   0.140 -> 0.077   p99 0.880 -> 0.484
//   panoramique 60 deg/s        0.118 -> 0.039   p99 0.685 -> 0.218
//   45 deg/s + marche           0.088 -> 0.026   p99 0.517 -> 0.159
// (chiffres avec CT_V2 ; le correctif TAA seul donne 0.106 / 0.101 / 0.034.)
// 0 = TAA_V2 tel que livre a la ronde precedente. HORS menu, SANS liste.
#define TAA_V3 1 // gate hors menu, sans liste (non enregistre par Iris)
// Part de l'elargissement d'instabilite conservee SUR LE CIEL. 0 = eteint :
// l'elargissement existe pour les surfaces lisses mais bruitees dans le temps
// (GI/SSR denoises), qui n'existent pas dans le ciel, et le modele n'y mesure
// AUCUN gain (scintillement 0.3680 -> 0.3669, soit rien) pour tout le prix de
// la regression.
#define TAA_INST_SKY 0.0 // 0 = elargissement coupe sur le ciel
// Vitesse ecran (px/image) ou l'elargissement commence a s'effacer, et ou il
// est nul : au-dela, un historique aussi loin doit etre REJETE, pas accueilli
// par une boite plus large.
#define TAA_INST_V0 1.0 // debut du fondu de l'elargissement
#define TAA_INST_V1 4.0 // fin du fondu : plus aucun elargissement
// Plafond DUR du terme additif, en luma tonemappee. TAA_INST_CAP plafonne
// l'instabilite LUE ; celui-ci plafonne la demi-largeur REELLEMENT ajoutee,
// widScale compris -- et widScale n'est borne par RIEN : a TAA_CLAMP_TONEMAP=0
// il vaut 1/(1-y)^2, soit jusqu'a 100 sur un pixel proche du blanc, donc un
// terme additif jusqu'a 8.0 dans une boite dont la luma tient dans [0, 1].
// C'est la seule borne de ce chemin-la.
// CALIBRATION sur le modele TERRAIN de la ronde precedente (bande haute
// frequence, bande lisse temporellement bruitee, barre mobile ; scratchpad
// tsim.py). Scintillement HF / scintillement LISSE / tramage de la barre :
//   sans plafond (0.08)  0.00679   0.00534   0.0840
//   0.05                 0.00818   0.00534   0.0775   <- retenu
//   0.03                 0.00972   0.00532   0.0747
//   0.02                 0.01074   0.00530   0.0733
//   0.01                 0.01201   0.00737   0.0724
//   cran Moyen (sans)    0.01327   0.01123   0.0717
// 0.05 garde 100 % du gain sur la bande LISSE -- la surface pour laquelle tout
// l'elargissement existe -- et 78 % du gain haute frequence, en rendant plus de
// la MOITIE du surcout de tramage : le "+17 %" annonce a la ronde precedente
// tombe a +8 % contre le cran Moyen. En dessous de 0.03 on paie le gain haute
// frequence sans rien gagner de plus sur la bande lisse.
#define TAA_INST_MAX 0.05 // demi-largeur additive maximale
// Poids de l'elargissement sur les canaux de CHROMA. La statistique de
// colortex7.a est un ecart de LUMA : rien ne justifie d'ouvrir Co et Cg de la
// meme quantite absolue (leur amplitude est bien plus etroite, donc le meme
// nombre les ouvre proportionnellement bien plus). Demi-poids, meme convention
// que la distance de rejet du fantome.
#define TAA_INST_CHROMA 0.5 // chroma a demi-poids dans l'elargissement

// ============ POST-PROCESS ============
// BLOOM : derive de BLOOM_LEVEL (bloc AXES DE MENU, haut de ce fichier)
// BLOOM_STRENGTH : derive de BLOOM_LEVEL (bloc AXES DE MENU, haut de ce fichier)
#define BLOOM_THRESHOLD 1.5 // [0.0 0.25 0.5 0.8 1.0 1.2 1.5 1.8 2.2 3.0 5.0 8.0]
// EXPOSURE : derive de IMG_EXPOSURE (bloc AXES DE MENU, haut de ce fichier)
#define AUTO_EXPOSURE
// SATURATION : derive de IMG_SATURATION (bloc AXES DE MENU, haut de ce fichier)
// VIGNETTE : derive de VIGNETTE_LEVEL (bloc AXES DE MENU, haut de ce fichier)
// TONEMAP_CONTRAST : derive de IMG_CONTRAST (bloc AXES DE MENU, haut de ce fichier)
// VIBRANCE : derive de IMG_SATURATION (bloc AXES DE MENU, haut de ce fichier)
#define WB_TEMPERATURE 0.0 // [-0.5 -0.35 -0.25 -0.15 -0.10 -0.05 0.0 0.05 0.10 0.15 0.25 0.35 0.5]
#define WB_TINT 0.0 // [-0.5 -0.35 -0.25 -0.10 -0.05 0.0 0.05 0.10 0.25 0.35 0.5]
//#define FXAA
#define PURKINJE
#define FILM_GRAIN

// ============ TEXTURES PBR (labPBR : Patrix, Vanilla PBR…) ============
#define PBR_TEXTURES
#define NORMAL_STRENGTH 1.0 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0 3.0 5.0 8.0]
#define PBR_EMISSIVE 1.0 // [0.0 0.5 1.0 1.5 2.0 3.0 5.0 8.0 12.0 20.0]
//#define PBR_REFLECTIONS
#define PBR_REFLECT_STRENGTH 1.0 // [0.0 0.5 0.75 1.0 1.5 2.0 3.0 5.0 8.0]
// ============ PBR_ROUGHNESS_V2 - real glossy lobe on opaque surfaces ============
// Legacy path (0): the reflection WEIGHT collapsed with roughness
// (reflW = smooth2 * (0.35 + 0.65 * smooth2)) and the only blur was a 2-tap
// directional jitter of +-12 deg. Net result: a rough material LOST its
// reflection instead of becoming glossy, so everything still VISIBLE was
// razor sharp -> "every reflection looks like a mirror" whatever the resource
// pack's specular map asks for.
// V2 (1) decouples QUANTITY from SHARPNESS, the way microfacet theory does:
//  - energy: reflW = mix(0.55, 1.0, smooth2). Identical at smooth2 = 1 (the
//    existing mirrors do not move), ~4x stronger at smooth2 = 0.3.
//  - horizon: roughness-aware Fresnel (F_SchlickRoughness) so a rough
//    dielectric does not become a grazing-angle mirror. Exact legacy curve at
//    roughness 0.
//  - shape: GGX half-vector importance sampling with alpha = (1 - smoothness)^2
//    (the labPBR convention), adaptive tap count, spatio-temporal rotation so
//    TAA integrates the lobe instead of showing it as noise.
//  - footprint: the SSR hit color is filtered by a 4-tap rotated cross whose
//    radius grows with alpha AND with the screen-space distance the ray
//    travelled (a rough ray that goes far spreads a wider cone).
//  - sky: the analytic fallback is softened toward the lobe average.
// 0 = legacy path, bit-identical.
#define PBR_ROUGHNESS_V2 1 // [0 1]
// Max GGX taps for the widest lobes. 1 keeps the legacy single-ray cost
// everywhere (blur then comes from the screen-space cross only). Near-mirror
// surfaces (alpha < 0.012, i.e. smoothness 0.89+) and low-weight reflections
// always stay at 1 tap whatever this value, so raising it costs nothing on true
// mirrors -- but a polished metal at smoothness 0.85 DOES go from 1 to 2 rays.
// The internal table tops out at 4, so 6 was rigorously identical to 4: removed.
// NOTE at the shipped default of 3: this value is a CEILING (nTaps = min(nTaps,
// PBR_ROUGH_TAPS)), so the internal 4-tap tier -- alpha >= 0.30, i.e. smoothness
// <= 0.452 -- is never reached as shipped, and the direction spread caps at
// 0.25 + 0.09 * 3 = 0.52 instead of 0.61. The lobe is already very wide there
// (~29-33 deg RMS), so the visual difference is small; set 4 if you want the
// rough half of the scale to keep widening. Cost of doing so: +1 ssrRay and
// +1 getSkyAll on smoothness <= 0.452 pixels only, which are skipped head-on
// anyway.
// PBR_ROUGH_TAPS : derive de PBR_QUALITY (bloc AXES DE MENU, haut de ce fichier)
// ============ PBR_ROUGHNESS_V3 - the reflected CONTENT follows the lobe ============
// V2 built a correct GGX lobe but only ever aimed the RAYS with it. Three leaks
// kept metals looking like flawless mirrors whatever the specular map asks for
// (measured on the pack actually enabled here, Vanilla Mashup 1.5:
// iron_block_s = R 222/255 -> smoothness 0.871, G 255/255 -> metal):
//  1. SKY. The analytic fallback -- the dominant content of any Overworld
//     reflection that leaves the screen -- was evaluated ONCE along the mean
//     direction, and widened only when alpha > 0.15. alpha = (1-s)^2,
//     so that threshold means smoothness < 0.613: iron (alpha 0.017), gold
//     (0.047), obsidian, quartz and packed ice ALL fell below it and got a
//     pixel-sharp sky, stars and sun disc included, however many GGX rays were
//     spent. V3 evaluates the sky along EACH tap's own direction (so the lobe
//     really integrates it, TAA included) and, for wide lobes, replaces V2's
//     vertical-only tilt with a SAME-COST 2-sample ring taken along a random
//     axis ORTHOGONAL to the reflected ray, re-drawn per pixel and per frame.
//  2. METALS. baseRefl = mix(fres, 1.0, metalness) is exactly 1.0 for a metal --
//     no roughness term, no horizon term. Combined with reflW's 0.55 floor, the
//     ROUGHEST possible metal still replaced 55% of its own shading with a
//     reflection head-on, while a dielectric at the same angle got 3%. Metals
//     were the only material in the pack showing a full-strength reflection.
//     V3 gives them the same roughness-aware horizon as dielectrics; at
//     roughness 0 that term is exactly 1.0, so real mirrors do not move.
//     SCOPE, measured: this bites on ROUGH metals (amtMax 0.6175 -> 0.1714 at
//     smoothness 0.15, -72%) and is almost a no-op on POLISHED ones -- iron at
//     the 0.871 its specular map asks for only drops 0.9420 -> 0.9263, i.e.
//     -1.7%, and stays a mirror by construction. To actually calm a polished
//     metal down, use PBR_REFLECT_FLOOR above or lower the R channel of the
//     block's _s texture in the resource pack.
//  3. FOOTPRINT. The screen-space blur radius grew as 0.55 * alpha * travel and
//     was capped at 0.006 sub-rect uv (~11 px at 1920). A perturbed NORMAL
//     spreads the REFLECTED ray by TWICE its own angle, so that ramp under-counts
//     the cone by ~3x: iron had to travel 66% of the screen just to reach its cap
//     and sat around 4 px at normal distances -- a mirror. The cap also switched
//     in one step at alpha 0.45, so smoothness 0.5, 0.3 and 0.15 all shared one
//     footprint. V3 uses the physical 1.7 * alpha * travel, a cap continuous in
//     alpha up to 0.024 (~46 px), and a two-ring 9-tap past 0.0045 so a wide
//     radius reads as a blur instead of 5 ghosts.
// NOTE on dimensions: the sky term (1) is multiplied by the pixel SKYLIGHT, and
// the End and the Nether have none -- there skyF is 0 and the reflection IS the
// screen-space hit, so (2) and (3) are what change the look. In the Overworld all
// three act, and (1) dominates on anything reflecting open sky.
// 0 = exact V2 behaviour, bit-identical. Requires PBR_ROUGHNESS_V2 = 1.
#define PBR_ROUGHNESS_V3 1 // [0 1]
// Multiplier on the V3 screen-space footprint radius cap (point 3 above). 1.0 =
// calibrated default. Raise for a creamier glossy blur on rough surfaces, lower
// if distant reflections smear. No effect when PBR_ROUGHNESS_V3 = 0.
#define PBR_ROUGH_BLUR 1.0 // [0.5 0.75 1.0 1.25 1.5 2.0]
// ============ PBR_REFLECT_FLOOR - how much a SMOOTH surface may overwrite ============
// The reflection WEIGHT is reflW = mix(PBR_REFLECT_FLOOR, 1.0, smoothness), and
// this floor is what a near-mirror keeps whatever the rest of the lobe does.
// It is the reason a polished labPBR metal still reads as a mirror even with
// PBR_ROUGHNESS_V3 on: V3 shapes the DIRECTION of the lobe, this sets its
// STRENGTH. Iron in Vanilla Mashup asks for smoothness 0.871, so V3's
// roughness-aware metal horizon only trims it by 1.7% -- correct physics, but
// not what "metals are too mirror-like" usually means. Lower this instead:
//   0.55 = calibrated default, BIT-IDENTICAL to the V2/V3 tuning
//   0.35 = smooth surfaces blend roughly half as hard, rough ones barely move
//   1.00 = every surface reflects at full Fresnel weight (the old "everything
//          is chrome" look)
// Only read when PBR_ROUGHNESS_V2 = 1; the legacy weight curve ignores it.
#define PBR_REFLECT_FLOOR 0.55 // [0.20 0.30 0.35 0.45 0.55 0.70 0.85 1.0]
// ============ RAY TRACED REFLECTIONS (SSR complet, labPBR + repli vanilla) ============
// Le rayon marche la VRAIE geometrie de la scene. Smoothness/metalness :
// specular map labPBR si presente, sinon REPLI PAR BLOC (block.properties
// 40/41 + blocs-metal) -> fonctionne aussi en textures vanilla. Desaturation
// REFLECT_DESAT partagee avec l'eau. L'EAU N'EST PAS CONCERNEE (elle garde
// toujours son propre SSR). Pas de RT = toggle RT_REFLECTIONS OFF.
// MODE : 0 = RT pur (seule la geometrie TOUCHEE par le rayon se reflete,
// aucun repli ciel — le rendu le plus "RTX") ; 1 = combine (RT + repli ciel
// analytique quand le rayon sort de l'ecran — le plus complet visuellement).
#define RT_REFLECTIONS
// MODE 3 = PT PUR : AUCUN rayon ecran, TOUT passe par le monde voxel (+ repli
// ciel) — reflets 100% coherents (rien ne disparait aux bords d'ecran), mais
// tout ce qui est reflete est voxelise (denoiser PT_REFLECT_SOFT conseille).
// PT EN VEILLE (demande user 2026-08) : mode 1 par defaut = reflets ecran +
// ciel, la voxelisation ne tourne pas. Tout le systeme PT (modes 2/3, grille
// bloc, DDA) reste dans le code — remettre 2 ici pour le reactiver. Les
// reglages PT sont retires du MENU en attendant.
// !! REACTIVATION : remettre AUSSI clear=true (1er bool) sur les image.voxelImg*
// dans shaders.properties (passes a false par l'audit perf, PT dormant) !!
#define RT_REFLECT_MODE 1 // [0 1 2 3]
// ============ PT REFLECTIONS — reflets HORS-ECRAN (mode 2, voxel) ============
// Quand le rayon ECRAN ne touche rien (sort du champ, geometrie cachee), il
// CONTINUE dans la copie VOXEL du monde (grille clipmap ecrite par la passe
// d'ombre) -> les reflets montrent AUSSI ce qui est hors ecran / derriere la
// camera. Hit voxel : albedo x (soleil x ombre shadow-map + ambiant ciel),
// emissifs boostes. Portee/finesse : VOXEL_SCALE et VOXEL_CASCADES.
#define PT_REFLECT_STEPS 64 // [16 24 32 48 64 96 128 192 256]
// Portee des rayons hors-ecran : le fondu d'approche suit CETTE distance
// (pas de clip net — les hits proches de la limite fondent vers le repli).
// Portee en CHUNKS (1 chunk = 16 blocs) — demande user. PT_REFLECT_DISTANCE
// (blocs) est DERIVE : le code en aval n'a pas change.
#define PT_REFLECT_CHUNKS 6 // [2 4 6 8]
// audit : liste plafonnee a 8 chunks — la portee reelle = min(128 blocs grille
// bloc, couverture cascades ~96, shadowDistance) ; la plage 12..32 etait inerte.
#define PT_REFLECT_DISTANCE (float(PT_REFLECT_CHUNKS) * 16.0)
#define PT_REFLECT_WATER 1 // [0 1]
#define PT_REFLECT_STRENGTH 1.0 // [0.25 0.5 0.75 1.0 1.25 1.5 2.0]
#define PT_REFLECT_SUN 0.85 // [0.3 0.5 0.7 0.85 1.0 1.3]
#define PT_REFLECT_AMBIENT 0.45 // [0.2 0.3 0.45 0.6 0.8 1.0]
#define PT_REFLECT_EMISSIVE 2.0 // [0.0 0.5 1.0 1.5 2.0 3.0 5.0 8.0]
// PT_WATER_NORMAL : influence des VAGUES sur la direction des rayons PT de
// l'eau. 0 = normale aplatie (parfaitement stable), 1 = normale complete
// (pleine distorsion). Le DDA bloc rend les hits stables -> 0.3 ne scintille pas.
#define PT_WATER_NORMAL 0.3 // [0.0 0.15 0.3 0.5 0.75 1.0]
// PT_REFLECT_SOFT : DENOISER des reflets voxel — jitter conique du rayon par
// pixel/frame (le crenelage voxel devient un bruit fin que le TAA lisse en
// FLOU doux) + fondu des hits lointains. 0.0 = rayons nets (voxels visibles).
#define PT_REFLECT_SOFT 0.3 // [0.0 0.15 0.3 0.5 0.75 1.0]
// SSR_PREV_FRAME : reflets DANS les reflets — la couleur des hits SSR vient
// de la frame PRECEDENTE COMPLETE (sortie TAA colortex7 : reflets, brouillards
// et volumetriques deja composes) reprojetee -> l'eau reflete une eau qui
// reflete, les miroirs se repondent. 0 = frame courante sans reflets (ancien).
#define SSR_PREV_FRAME 1 // [0 1]
//#define PBR_POM
#define POM_DEPTH 0.15 // [0.01 0.05 0.10 0.15 0.25 0.35 0.50 0.75 1.0 2.0]
// Pas de POM_SAMPLES : le POM de gbuffers_terrain.fsh est un parallax a un seul
// tap (pas de boucle de marche), il ne lit que POM_DEPTH. Voir le bloc
// MATIERES PBR (PBR_QUALITY) en tete de ce fichier.

// ============ TONEMAP ============
// AgX : tonemap filmique moderne, garde la teinte des hautes lumières. Prioritaire
// sur ACES s'il est activé. OFF par défaut — active-le pour comparer avec ACES.
//#define AGX_TONEMAP
// ACES filmic : noirs profonds, hautes lumières crémeuses, couleurs cinématiques
#define ACES_TONEMAP

// ============ EXTRAS CINÉMATIQUES ============
#define LENS_FLARE
#define LENS_FLARE_STRENGTH 1.0 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0 3.0 5.0]
//#define AURORA
#define AURORA_BRIGHTNESS 1.0 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0 3.0 5.0 8.0 12.0]
// E5 STARS_V2 : refonte realiste du champ d'etoiles — amas & vides, magnitudes
// en loi de puissance (rares brillantes, myriade de faibles), couleurs
// stellaires subtiles, pole celeste incline, scintillement discret par etoile,
// coeur de largeur angulaire fixe (stable en TAA). 0 = ancien champ 3 couches.
// Star engine locked to v2 (user removed the selector; v1 kept as dead fallback).
#define STARS_V2 1
// STAR_BRIGHTNESS : derive de STAR_LEVEL (bloc AXES DE MENU, haut de ce fichier)
// [E6] Taille angulaire du coeur gaussien des etoiles (multiplicateur de la
// largeur ~1.4 px de STARS_V2). 1.0 = ancienne taille exacte ; defaut 1.2 =
// un poil plus grandes (retour user). Le halo des brillantes suit (x9 sigma2).
#define STAR_SIZE 1.2 // [0.8 0.9 1.0 1.1 1.2 1.35 1.5 1.75 2.0]
// MILKYWAY_BRIGHTNESS : derive de STAR_LEVEL (bloc AXES DE MENU, haut de ce fichier)
//#define SHOOTING_STARS
// R6 lens droplets rework (composite5): a few near-still drops that refract
// slightly + rare thin trails sliding down, quick fade. No full-screen warp.
// 0 = off, 1 = subtle, 2 = strong. Defaut livre : 0 (desactive) - le menu
// affiche donc "Desactive" tant que le joueur n'y touche pas.
#define CAMERA_DROPLETS 0 // [0 1 2]
//#define DOF
#define DOF_STRENGTH 1.0 // [0.0 0.25 0.5 1.0 1.5 2.0 3.0 5.0 8.0]
// DOF_V2 (composite5) : polish du DOF -- CoC "objectif mince" simplifie
// |1 - dFocus/d| (sature vers ~9 px x DOF_STRENGTH sur un fond lointain,
// grossit vite au tres proche, plafond 16 px ; DOF_STRENGTH reste le seul
// dial joueur), disque de Vogel 12 taps tourne par pixel (hash spatial --
// PAS de dither temporel, la passe tourne APRES le resolve TAA), poids de
// couverture par tap (un tap NET dont le disque n'atteint pas le pixel ne
// fuit plus dans un bokeh voisin) et fondu sub-pixel du seuil (le V1
// basculait net/floute d'un coup a coc>0.8). L'aberration chromatique
// s'accroche aux pixels floutes (les taps r/b du disque echantillonnent les
// coordonnees aberrees : le bokeh garde ses franges au lieu de perdre la CA).
// LIMITE CONNUE (gather pur, pas de scatter) : un avant-plan floute devant un
// fond net garde une silhouette coupee au rasoir -- le pixel de fond a
// cocC = 0 et ne lance jamais la boucle, donc le bokeh du proche ne peut pas
// deborder sur lui. C'est un compromis assume (V1 faisait pire dans les deux
// sens), pas un bug a rechercher ; un vrai near-field demanderait une passe
// de scatter separee, hors budget. 0 = ancien DOF exact. HORS menu, SANS
// liste (PIEGE IRIS : Iris ne l'enregistre pas, un .txt perime ne peut pas
// le basculer) ; rollback = editer la valeur ici.
#define DOF_V2 1 // gate hors menu, sans liste (non enregistre par Iris)
#define CHROMATIC_ABERRATION
#define RAINBOW
#define GODRAYS
#define GODRAY_STRENGTH 1.0 // [0.0 0.25 0.5 1.0 1.5 2.0 3.0 5.0 8.0 12.0]
// GODRAY_SAMPLES : derive de SUNRAY_QUALITY (bloc AXES DE MENU, haut de ce fichier)
// R5 ancre solaire (godrays ecran, composite5) : 1 = l'extraction ne retient que les
// pixels de CIEL (depth>=1) situes dans le disque circumsolaire -> les nuages/terrain/
// eau brillants LOIN du soleil ne peuvent plus semer de raies (ancre "haut-gauche"
// fantome observee alors que le soleil etait au centre). 0 = ancien comportement exact.
// HORS menu, SANS liste (PIEGE IRIS : Iris ne l'enregistre pas, un .txt
// perime ne peut pas le basculer) ; rollback = editer la valeur ici.
#define GODRAY_ANCHOR_FIX 1 // gate hors menu, sans liste (non enregistre par Iris)
// Screen godrays over WATER (composite5): 1 = the fan added to a water pixel is
// weighted by the AIR share of that pixel's path (camera -> surface against
// camera -> floor, floor 0.25). The whole godray block is gated on
// isEyeInWater == 0, so without this a lake seen from the bank carried the
// screen fan ON TOP of the underwater shafts the volumetric march already
// draws behind its surface, while a diver saw only the march: two ray systems
// from outside, one from inside. Opaque pixels are bit-identical (depthtex1
// and depthtex0 agree there). 0 = previous behaviour.
// OUT of the menu (reversible technical gate).
#define GODRAY_WATER_SPLIT 1 // [0 1]
#define TAA_CLAMP_TONEMAP 1 // [0 1]
#define BLOOM_PHYSICAL 1 // [0 1]
// C: bloom pyramide MIP — brightpass dedie (composite2) + somme LOD 1..6 (composite5,
// colortex3 mippee). Poids normalises a 1.0 = energie constante. 0 = chaine d'origine.
#define BLOOM_MIP 1 // [0 1]
// C: half-res bloom -- composite2 (brightpass+blurH) and composite3 (blurV)
// shade only the lower-left quadrant of colortex3 (1 quadrant texel = 1
// full-res pixel at uv*2, ~4x fewer bloom pixels; outside the quadrant they
// write black so the BLOOM_MIP pyramid never averages stale texels). Tap
// offsets are HALVED in quadrant space so the on-screen blur radius stays
// unchanged (composite2's scene taps land on the exact legacy full-res
// coordinates). composite5 reads the quadrant at uv*0.5 -- plain bilinear is
// enough, bloom has no silhouettes -- and the MIP ladder shifts 1..6 -> 0..5
// (one quadrant mip == one full-res mip coarser => same on-screen halo
// widths). Composes with TAAU: quadrant of the render sub-rect (0.5*TAAU_S).
// 0 = legacy full-res chain, bit-identical.
#define BLOOM_HALF_RES 1 // [0 1]
#define MOTION_BLUR_STRENGTH 1.0 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0 3.0]
#define MOTION_BLUR_SAMPLES 8 // [4 6 8 12 16]
// MB_V2 (composite4) : polish du motion blur -- longueur normalisee par
// frameTime sur un obturateur 1/60 s (meme trainee a 60 et 240 fps ; le V1
// retrecissait quand les fps montaient), plafond dur a 3 % de l'ecran (le
// V1 COUPAIT tout au-dela de 5 % : pop en rotation rapide), ciel reprojete
// en rotation pure (le V1 laissait un ciel NET colle a un sol floute
// pendant un pan), gather symetrique dithere (hash spatial : la passe EST
// le resolve TAA, un dither temporel scintillerait), taps ponderes par
// profondeur relative (la main / un mob tres proche n'est plus traine dans
// la trainee d'un pixel lointain) et fondu du champ proche (la main ne
// bave plus ; le fondu lit la profondeur DILATEE dClose, celle dont vient la
// velocite, pour que le lisere d'1 px autour de la main fonde comme la main).
// Normalisation valable de 15 a 240 fps (le clamp 0.25..4.0 sature au-dela :
// a 480 fps la trainee retombe a la moitie de 60 fps). 0 = ancien motion
// blur exact. HORS menu, SANS liste (PIEGE IRIS : Iris ne l'enregistre pas,
// un .txt perime ne peut pas le basculer) ; rollback = editer la valeur ici.
#define MB_V2 1 // gate hors menu, sans liste (non enregistre par Iris)
//#define MOTION_BLUR
#define LIGHTNING_FX
#define BOSS_FX
#define LAVA_OVERLAY
// DAMAGE_FX (composite5): dark blood-red edge flash + brief radial blur when the
// player takes damage, scaled by the fraction of max health just lost (Iris
// currentPlayerHealth vs its smooth()-lagged copy, shaders.properties id 57).
// Half heart = subtle rim, 3+ hearts = violent flash; decays with a 0.7 s
// half-life (~gone in 1.5 s). Inert in creative/spectator and on respawn.
// DAMAGE_FX : derive de DAMAGE_LEVEL (bloc AXES DE MENU, haut de ce fichier)
// DAMAGE_FX_STRENGTH : derive de DAMAGE_LEVEL (bloc AXES DE MENU, haut de ce fichier)
#define MOON_HALO
// SHARPEN : derive de SHARPEN_LEVEL (bloc AXES DE MENU, haut de ce fichier)
// Force de la nettete adaptative (unsharp mask, final.fsh). Etait codee en dur a 0.38 (trop douce).
// 0.38 = ancien comportement EXACT. 0.6 = nette franche. 1.0+ = tres marquee (peut creer des halos
// aux contours / faire ressortir le grain). Sans effet si SHARPEN_LEVEL est a 0.
// SHARPEN_STRENGTH : derive de SHARPEN_LEVEL (bloc AXES DE MENU, haut de ce fichier)
const float centerDepthHalflife = 1.0; // [0.0 0.1 0.25 0.5 1.0 2.0 4.0 8.0 16.0]

// ============ RAY TRACING VOXEL (RTX maison — GI path-tracee) ============
// VOXEL_GI : illumination globale par lancer de rayons dans la grille voxel.
// La lumiere rebondit depuis le monde voxelise, HORS-ECRAN inclus. Le vrai "RTX".
// (En chantier : lourd + bruite pour l'instant. Necessite shadowDistance pour remplir la grille.)
// On/off en SLIDER (1=ON, 0=OFF) car les toggles booleens ne s'affichent pas dans
// le menu de cet Iris. ON par defaut pour que tu voies la GI tout de suite.
#define VOXEL_GI 0 // [0 1]
#define VOXEL_GI_STRENGTH 1.0 // [0.0 0.1 0.25 0.5 0.75 1.0 1.5 2.0 3.0 5.0 8.0 12.0 20.0 50.0 100.0]
// RTX_BUFFER_PURGE : VRAM-only gate, the image is bit-identical in both states.
// 1 (default) = when RTX is fully OFF (VOXEL_GI=0, FULL_PATH_TRACE=0) the RTX-only
// history buffers colortex8/9/10/12 (40 bytes/px total: ~79 MiB @1080p, ~141 MiB
// @1440p per copy; Iris keeps main+alt pairs, so up to double) keep ZERO
// reference in any program (format block in
// composite5 compiled out; samplers and RENDERTARGETS already gated), so Iris
// never allocates them. 0 = legacy: format declarations always present.
// Has no effect while VOXEL_GI=1 (buffers are then needed and allocated anyway).
#define RTX_BUFFER_PURGE 1 // [0 1]
// ---- CLIPMAP VOXEL (cascades imbriquees) ----
// VOXEL_CASCADES grilles 256^3 centrees camera, echelles croissantes : cascade i a une
// taille de voxel s_i = VOXEL_SCALE * 2^i. Cascade 0 = la plus FINE (detail pres),
// cascades suivantes = 2x/4x/8x plus grossieres mais 2x/4x/8x plus de portee. La GI lit
// toujours la cascade la plus fine qui couvre le point -> fin PRES + portee LOIN.
// VOXEL_CASCADES=1 = ancienne grille mono (securite, RENDU IDENTIQUE a avant).
// VRAM : 128 MiB / cascade (256^3 RGBA16F). 6 images sont declarees inconditionnellement
// dans shaders.properties (les directives image.X ne sont PAS gatables par #if) -> 768 MiB
// alloues MEME a VOXEL_CASCADES<6. Pour recuperer la VRAM en mono-grille (debug VRAM), il
// FAUT aussi supprimer a la main les lignes image.voxelImg1..voxelImg5 (pas seulement baisser le slider).
// COUT CONSTANT : passer de 4 a 6 images = +256 MiB allous EN PERMANENCE meme si le slider reste a 3.
// A render distance 32 (deja lourde, RTX 3070 Ti 8 Go) c'est soutenable ; NE PAS depasser 6 cascades
// par defaut (8 images = 1 GiB = risque d'eviction VRAM a RD32).
// PLUS DE DETAIL : le detail PRES vient UNIQUEMENT d'un VOXEL_SCALE plus fin (cascade 0 plus fine,
// ex 0.125/0.25). Les cascades 4/5 (grossieres) n'ajoutent PAS de detail pres : elles donnent une
// couverture LOINTAINE plus large (moins de bruit/cout loin), TOUJOURS plafonnee par shadowDistance.
// Recette "plus de detail a portee egale" : baisse VOXEL_SCALE ET monte VOXEL_CASCADES pour que les
// cascades grossieres couvrent encore shadowDistance. Garde 128*VOXEL_SCALE <= shadowDistance (cascade 0).
// LIMITE REELLE DE PORTEE : la passe d'ombre ne voxelise que dans shadowDistance (ci-dessus,
// 128 blocs par defaut). Les cascades grossieres ne se remplissent donc QUE jusqu'a
// shadowDistance ; au-dela elles restent vides (= miss, pas d'occlusion fantome). Ajouter des
// cascades NE REPOUSSE PAS la portee au-dela de shadowDistance : ca reduit le bruit/cout loin
// a portee egale. Pour vraiment porter plus loin : monte shadowDistance (slider Ombres) ET
// VOXEL_GI_DISTANCE, au prix du FPS (cout dominant = passe d'ombre, ~ rayon^2).
#define VOXEL_CASCADES 3 // [1 2 3 4 5]
// (plafonne a 5 : voxelImg5 est reserve a la GRILLE BLOC des PT reflections)

// Taille d'un voxel en blocs pour la cascade 0 (BASE du clipmap). Cascade i = VOXEL_SCALE*2^i.
// Plus PETIT = plus fin pres ; les cascades suivantes prennent le relais pour la portee.
// La grille fait 256^3 cellules FIXES par cascade. CONTRAINTE CLIPMAP : garde
// 128*VOXEL_SCALE <= shadowDistance, sinon la cascade 0 a des cellules exterieures NON
// remplissables (au-dela de shadowDistance) qui, etant la cascade la plus fine, masquent
// les cascades grossieres = anneau de faux miss. Avec base 0.5 (extent 64 <= 128) c'est
// automatique ; evite VOXEL_SCALE 2.0/4.0 (extent 256/512 > 128) sauf si tu montes shadowDistance.
// 0.1875 = 3 texels d'une texture 16x16 (3/16) — assez fin pour lire le motif
// des textures dans les reflets voxel, assez gros pour que la passe d'ombre
// remplisse la grille sans trous (8192 sur 384 blocs ~ 2 fragments/cellule).
// LUMIERES COLOREES : 0.5 par defaut -> cellule LPV = 1 bloc, flood 15 cellules
// = ~15 blocs de portee de COULEUR (aligne sur la portee lightmap vanilla).
// L'ancien 0.1875 (reflets PT fins) ne portait la teinte qu'a ~5.6 blocs.
#define VOXEL_SCALE 0.5 // [0.0625 0.1 0.125 0.1875 0.25 0.5 1.0]
// audit : 2.0/4.0 retires de la liste (extent 512/1024 > fenetre ±128 = anneau
// de faux miss, la doc du fichier les declarait deja casses).

// DEBUG : quelle cascade afficher en DEBUG_VIEW==13 (0 = la plus fine). Constante de
// compilation. Si DEBUG_CASCADE >= VOXEL_CASCADES, retombe proprement sur la cascade 0.
#define DEBUG_CASCADE 0 // [0 1 2 3 4 5]
#define VOXEL_GI_SAMPLES 4 // [1 2 4 6 8 12 16 24 32 48 64 96 128 256]
#define VOXEL_GI_DISTANCE 24 // [4 8 12 16 24 32 48 64 96 128 192 256 384 512]

// JALON 11 — NB DE REBONDS GI. 1 = comportement mono-rebond historique (porte de secours).
// >1 = chaque rayon REBONDIT : a chaque hit albedo il accumule sa contribution puis CONTINUE
// (nouvelle dir = cosineHemisphere(-dir), faute de normale voxel = approximation) ; un hit
// emissif termine le chemin (source). Le multi-rebond ETALE l'emissif (glowstone remplit la
// piece = resout le "pur RTX un seul cote") et multiplie le color-bleeding. Cout ~lineaire en
// BOUNCES ; bruit croissant (variance Monte-Carlo composee). A BOUNCES>=2 monter VOXEL_GI_SAMPLES
// (>=6) ou TAA_GI_FRAMES pour compenser le 2e rebond emissif tres bruite.
#define BOUNCES 2 // [1 2 3 4 5 6 8 12 16]

// JALON 11 — CIEL EN GI (sky-on-miss). 0 = un rayon GI qui MISS renvoie 0 (actuel : le ciel
// n'eclaire pas la GI). 1 = on ajoute la vraie couleur du ciel dans la direction du rayon
// (eclairage d'environnement reel). N'affecte PAS les ombres directes (shadow map). [0 1]
// car les toggles booleens ne s'affichent pas dans ce menu Iris (cf. VOXEL_GI/VOXEL_REFLECTIONS).
#define SKY_GI 0 // [0 1]

// JALON 11 — force du terme ciel-en-GI. ATTENTION : ce terme passe ENSUITE par la teinte chaude
// (1.0,0.95,0.82) * VOXEL_GI_STRENGTH (composite5:809) -> il STACKE multiplicativement avec
// VOXEL_GI_STRENGTH (2.0 en profile.RTX). 0.5 = point de depart calibre pour ce stacking ; baisse
// encore si l'exterieur est delave/jaune cote soleil, monte pour un environment lighting plus marque.
// Sans effet si SKY_GI=0.
#define SKY_GI_STRENGTH 0.5 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0 3.0 5.0 8.0]

// JALON 5 : fraction de l'ambiant ciel PLAT conservee quand VOXEL_GI==1. La GI voxel
// fournit desormais l'indirect/ambiant directionnel -> on baisse l'ambiant plat pour
// eviter le double-comptage (sinon scene ~2x trop claire). 1.0 = comme avant (GI=bonus) ;
// 0.0 = GI voxel seule. Defaut 0.35 = filet de securite (8 rayons -> evite les coins
// noirs bruites) ; le profil RTX le pinne a 0.0 (le RTX fournit tout l'indirect).
// N'affecte PAS le fog/eau (getAmbientColor reste intact) ni les ombres directes.
#define VOXEL_GI_AMBIENT 0.35 // [0.0 0.1 0.2 0.25 0.35 0.5 0.75 1.0 1.5 2.0 3.0]

// JALON 5 : gain HDR pre-tonemap de l'emissif voxel. L'emissif est ajoute AVANT ACES :
// pour qu'il survive a la compression de la courbe (et reste lumineux apres tonemap), on
// le multiplie ici. 3.0 = bon point de depart ; monte si la lave/glowstone parait fade,
// baisse si ca crame. Se combine avec EMISSIVE_VOXEL_STRENGTH (cote shadow.fsh).
#define EMISSIVE_GI_GAIN 3.0 // [0.0 0.5 1.0 1.5 2.0 3.0 4.0 6.0 8.0 12.0 20.0 50.0 100.0]

// ---- JALON 7 : REFLETS VOXEL HORS-ECRAN (eau) ----
// Tire 1 rayon miroir dans le clipmap voxel pour les surfaces d'EAU HORIZONTALE (lac/ocean) :
// ramene le reflet de la GEOMETRIE HORS-ECRAN (derriere / hors champ) que le SSR ecran
// (composite1) ne peut PAS voir. COMPLEMENT du SSR, pas un remplacement : on AJOUTE seulement
// ce que le SSR rate (un HIT de geometrie voxel), attenue par Fresnel. Le CIEL n'est PAS
// re-reflete ici (composite1 le fait deja analytiquement via getSkyAll, sans bornes ecran) :
// un MISS voxel (ciel / hors grille) ne touche PAS l'image -> aucun double-comptage du ciel,
// l'eau a ciel ouvert reste IDENTIQUE a avant le Jalon 7. PORTEE : EAU SEULEMENT, par choix.
// Les reflets PBR des blocs lisses (pierre/metal) restent en SCREEN-SPACE via composite1 ;
// les etendre au voxel ici serait risque (pas de lecture rugosite, overlap SSR PBR) -> hors
// scope volontaire. Tres econome (1 rayon, eau horizontale uniquement) mais l'utilisateur lag
// deja a 6 cascades / RD32 -> defaut ON avec une FORCE moderee (0.35, anti double-comptage
// on-screen residuel). Le profil non-RTX (VOXEL_GI=0) le desactive AUTO (bloc gate #if
// VOXEL_GI==1). On/off en SLIDER [0 1] (les toggles booleens ne s'affichent pas dans ce menu
// Iris), comme VOXEL_GI. Porte de secours = VOXEL_REFLECTIONS 0 -> rendu actuel exact.
#define VOXEL_REFLECTIONS 0 // [0 1]
// Force du reflet voxel ajoute. 0.35 = complement discret (defaut, anti-lag + anti sur-comptage
// de la geometrie deja reflechie a l'ecran par le SSR) ; monte vers 0.75-1.0 pour des reflets
// hors-ecran plus francs, baisse si l'eau parait surchargee par rapport au SSR.
#define REFLECTION_STRENGTH 0.35 // [0.0 0.1 0.25 0.35 0.5 0.75 1.0 1.5 2.0 3.0 5.0 8.0]
// Budget d'iterations du rayon de reflexion (le pas grossit avec la distance, comme la GI).
// Plus haut = reflets hors-ecran plus lointains mais plus cher. 24 = bon compromis (proche de
// la portee GI), baisse a 16 si lag, monte a 32-48 pour de l'eau face a des builds lointains.
#define REFLECTION_STEPS 24 // [4 8 12 16 20 24 32 48 64 96 128 256]

// ---- JALON 7b : REFLETS VOXEL HORS-ECRAN sur OPAQUE GLOSSY/METAL ----
// Etend le repli reflets voxel (eau seule) aux surfaces opaques lisses/metal : complement
// hors-ecran du SSR de composite1. 0 = OFF -> rendu EXACT actuel (gate #if). HONNETE :
// depend d'un pack LabPBR (smoothness colortex2.a + metalness colortex11.g) ; SANS pack,
// smoothness=0 ET metalness=0 -> aucun pixel ne passe le seuil -> effet ET cout NULS.
// Le profil non-RTX (VOXEL_GI=0) le desactive AUTO (le bloc est sous #if VOXEL_GI==1).
#define VOXEL_REFLECTIONS_OPAQUE 0 // [0 1]
// Seuil de gloss = max(smoothness, metalness) au-dessus duquel on trace un rayon voxel.
// Haut = moins de pixels tracent (moins cher) ; bas = plus de surfaces refletent (plus cher).
// 0.5 = surfaces franchement lisses/metal. Monte a 0.6-0.7 si lag (le rayon voxel est partage
// avec l'eau via REFLECTION_STEPS, pas de budget separe). Compare en RUNTIME (jamais en #if).
#define REFLECT_OPAQUE_THRESHOLD 0.5 // [0.2 0.3 0.4 0.5 0.6 0.7 0.8]
// Force du reflet voxel opaque ADD. PLUS FAIBLE que l'eau (0.35) car le SSR ecran a deja
// ajoute le reflet on-screen a color -> anti double-comptage residuel. Monte pour des metaux
// plus francs hors-ecran, baisse si l'opaque parait surcharge par rapport au SSR.
#define REFLECTION_STRENGTH_OPAQUE 0.25 // [0.0 0.1 0.15 0.25 0.35 0.5 0.75 1.0 1.5 2.0]

// ---- TUNING CONTACT_SHADOWS (composite1) : defauts = valeurs actuelles -> aucun changement
// visuel hors activation du toggle. Ajuster si le contact parait trop fort/faible apres test.
// STEPS/BIAS sont des constantes int/float comparees/utilisees en RUNTIME (jamais en #if).
// CONTACT_SHADOW_STEPS : derive de SHADOW_QUALITY
#define CONTACT_SHADOW_STRENGTH 0.55 // [0.1 0.25 0.35 0.45 0.55 0.7 0.85 1.0]
#define CONTACT_SHADOW_THICKNESS 0.55 // [0.1 0.2 0.35 0.45 0.55 0.75 1.0 2.0]
#define CONTACT_SHADOW_BIAS 0.012 // [0.004 0.008 0.012 0.02 0.03 0.05]

// ---- JALON 6 : BLOCS EMISSIFS DANS LA GI VOXEL ----
// Les blocs lumineux (lave, glowstone, torches, lanternes, sea lantern, shroomlight,
// froglights, magma, feu, end rod, soul fire, amethyste...) EMETTENT leur propre lumiere
// coloree DANS la GI voxel : ils eclairent les surfaces autour, HORS-ECRAN inclus.
// Detection = material ID (block.properties 20-24), deja porte par matS dans la passe d'ombre.
// Encodage : le voxel reste 1 RGBA16F ; alpha=2.0 => emissif & rgb=radiance emise (alpha=1.0
// => solide & rgb=albedo, comportement Jalon 3). L'occupation reste alpha>0.5 (occlusion +
// 1er-hit) pour les deux : un bloc emissif occulte comme un solide.
// PORTE DE SECOURS : EMISSIVE_VOXEL 0 => comportement Jalon 3 EXACT (l'emissif est traite
// comme un albedo ordinaire). On/off en SLIDER (les toggles booleens ne s'affichent pas dans
// ce menu Iris), comme VOXEL_GI. ON par defaut.
#define EMISSIVE_VOXEL 0 // [0 1]
// Force de l'emission injectee dans la GI. Grosses limites : la lave/glowstone doivent
// pouvoir illuminer franchement une piece sombre. Defaut 0.5 : au-dela la couleur (rouge
// lave, blanc-chaud glowstone) tend a clipper au blanc dans le buffer sRGB ou la GI est
// ajoutee -> monte le slider pour plus de puissance, baisse-le pour garder la teinte.
#define EMISSIVE_VOXEL_STRENGTH 0.5 // [0.0 0.1 0.25 0.5 0.75 1.0 1.5 2.0 3.0 4.0 6.0 8.0 12.0 20.0 50.0 100.0]

// ---- FIX ECRITURE : PRIORITE + DILATATION EMISSIVE (voxelisation, shadow.fsh) ----
// Corrige le bug "un bloc emissif n'eclaire que d'un cote / seulement une partie de ses voxels".
// 0 = imageStore direct ACTUEL (comportement identique : meme test de bornes, meme store unique).
// 1 = au write voxel (ON gate aussi sur EMISSIVE_VOXEL=1, sinon sans effet ET sans surcout) :
//  (a) PRIORITE : une cellule deja emissive (a=2) n'est PLUS ecrasee par un bloc solide voisin (a=1) ;
//  (b) DILATATION : un bloc emissif remplit aussi ses voxels voisins VIDES (halo 1 voxel, 6 faces)
//      -> le 2x2x2 complet du bloc devient emissif et il emet de TOUS les cotes. La dilatation
//      n'ecrit QUE dans les cellules vides (a<0.5) -> ne transforme jamais un mur solide adjacent en
//      source (anti-fuite a travers les murs). LIMITE CONNUE : une geometrie SOUS-BLOC d'1 voxel
//      d'epaisseur (vitre/dalle/tapis a VOXEL_SCALE=0.5) collee a une source PEUT laisser fuir un peu
//      de lumiere (la course non atomique peut lire 'vide' et ecrire l'emissif dans l'unique voxel) ;
//      mettre 0 si une fuite est visible sur vitres fines.
// HONNETE : imageLoad/imageStore non atomiques entre fragments concurrents -> best-effort statistique,
// pas une garantie 100%. La grille etant re-voxelisee chaque frame + l'accumulation temporelle lissent
// le residuel. La dilatation ajoute aussi de l'OCCUPATION (a>0.5) aux cellules d'air voisines -> les
// sources voxelisees grossissent d'~1/2 bloc pour l'occlusion/les reflets voxel (benin, voulu pour
// emettre de tous cotes). COUT par fragment et PAR cascade ACTIVE (VOXEL_CASCADES=3 par defaut, PAS 6) :
// +1 imageLoad/fragment albedo (cout dominant), +6 imageLoad et jusqu'a +6 imageStore/fragment emissif.
// Le levier de cout est shadowDistance + densite de geometrie ombree. Si lag : voir la variante
// "cascade 0 seulement" dans shadow.fsh. VALIDATION : DEBUG_VIEW 13 (le cube emeraude devient plein/
// teinte au raymarch) + DEBUG_VIEW 18 (heatmap des hits : les deux cotes chauffent). NB la vue 17 lit
// la cellule d'AIR devant la face -> elle peut rester partielle cote ombre, ce n'est PAS la bonne preuve.
#define EMISSIVE_VOXEL_FILL 1 // [0 1]

// ---- JALON 12 : NEE EMISSIF (gather voxel local) ----
// FIX du bug "emissif un seul cote / selon l'angle". 0 = emissif RANDOM-HIT ACTUEL EXACT
// (porte de secours byte-identique). 1 = a chaque point ombre on echantillonne le champ
// emissif LOCAL par rayons courts (marchVoxelP) aimes par la normale, avec falloff 1/r^2
// -> eclairage OMNIDIRECTIONNEL propre depuis les blocs lumineux (chaque surface FACE a la
// source est eclairee, pas seulement celle qui capte un rayon aleatoire). Alimente la MEME
// giEmissive -> accumulation/checkerboard/gain INCHANGES. Inerte si EMISSIVE_VOXEL=0.
// HONNETE : ce n'est PAS du vrai NEE (les rayons qui ratent une source sont jetes) ; le grain
// residuel est masque par l'EMA colortex10. COUT : aux defauts (VOXEL_GI_SAMPLES=4, BOUNCES=1)
// ce gather DOUBLE ~ le cout de ray-march voxel par pixel ; sur profile.RTX (samples=6,
// BOUNCES=2) il ajoute ~33%. Le damier (GI_CHECKERBOARD=1) le paie sur 1 pixel/2. Si lag :
// baisse EMISSIVE_NEE_SAMPLES (4-6) ou EMISSIVE_NEE_RADIUS d'abord.
#define EMISSIVE_NEE 0 // [0 1]
// Nb de rayons de gather par pixel. 12 par defaut = assez de hits pour tuer le "un seul cote"
// pres d'une petite source ; baisse a 6-8 si lag sur 3070 Ti, monte a 16-24 si grain residuel.
#define EMISSIVE_NEE_SAMPLES 12 // [1 2 4 6 8 12 16 24 32 48 64 128]
// Rayon de gather en BLOCS : porte des rayons courts. Plus grand = capte des sources plus
// lointaines mais plus cher (reach grimpe). 8 = bon compromis interieur.
#define EMISSIVE_NEE_RADIUS 8.0 // [1.0 3.0 5.0 8.0 12.0 16.0 24.0 32.0 48.0 64.0 128.0]
// Gain de calibrage : l'integration (1/r^2) a une echelle DIFFERENTE du random-hit ET passe
// ENSUITE par EMISSIVE_GI_GAIN (3.0 en profile.RTX) -> le niveau changera a l'activation.
// Calibre ici jusqu'a retrouver le rendu voulu. 1.0 = depart ; descends a 0.5 si EMISSIVE_GI_GAIN
// est deja eleve (profile.RTX).
#define EMISSIVE_NEE_GAIN 1.0 // [0.0 0.1 0.25 0.5 0.75 1.0 1.5 2.0 3.0 5.0 8.0 12.0 20.0]

// ---- JALON 13 : DOUCEUR / PORTEE DU FALLOFF EMISSIF ----
// 0.0 = falloff 1/(1+0.5 d^2) ACTUEL EXACT (porte de secours ; la lampe meurt en ~4 blocs).
// >0 = inverse-carre FENETRE borne au rayon : noyau brillant pres de la source + remplissage doux
// jusqu'a ~EMISSIVE_NEE_RADIUS puis extinction smoothstep -> 0 EXACTEMENT au rayon (facon lumiere
// de bloc MC). Plus grand = remplit plus loin / plus doux. 0.5 = noyau marque, 2.0+ = halo large.
// NOTE : la selection est RUNTIME (pas #if) cote shader -> ce define est un FLOAT (pas un entier).
// IMPORTANT CALIBRAGE : ce falloff est BEAUCOUP plus lumineux a mi-distance que l'ancien (~8x a 5
// blocs a R=12). Avec EMISSIVE_NEE_GAIN=2.0 le proche-champ peut cramer : 1er reglage si trop vif =
// baisser EMISSIVE_NEE_GAIN (2.0 -> 1.5). Mettre 0.0 retablit l'ancien falloff a l'identique.
#define EMISSIVE_NEE_SOFT 1.0 // [0.0 0.5 1.0 1.5 2.0 3.0 5.0 8.0 12.0]

// ---- JALON 14 : BIAIS D'ORIGINE DU GATHER EMISSIF (debug anti-leak) ----
// Decalage de l'origine du rayon de gather emissif (gatherEmissiveNEE, composite5) en MULTIPLES
// de VOXEL_SCALE, AVANT le ray-march. 0.0 = origine pile sur la surface (capte le voxel emissif
// adjacent au max, mais risque self-hit / leak d'arete). 0.25 = comportement ACTUEL EXACT (quart
// de voxel anti-leak). Plus HAUT = pousse l'origine loin de la surface -> moins de leak mais
// l'emissif des sources collees au sol/mur s'eteint (etouffe). Teste 0.0 si une glowstone au sol
// parait trop sombre, 0.5-1.0 si la lumiere fuit a travers un mur fin.
#define EMISSIVE_NEE_BIAS 0.25 // [0.0 0.1 0.25 0.5 0.75 1.0 1.5 2.0 3.0 5.0]

// ---- JALON 16 : FIX ONE-SIDED — part de rayons SPHERE complete (omnidirectionnel) ----
// 0.0 = repli EXACT actuel (100% cosine-hemisphere aimee par la normale : un bloc emissif
// n'eclaire que les faces qui le regardent -> emeraude one-sided). >0 = fraction de rayons tires
// sur la SPHERE complete -> capte une source sur le cote / derriere -> un bloc emissif eclaire de
// maniere plus omnidirectionnelle. Visibilite (marchVoxelP, 1er occupant) INCHANGEE -> anti-leak garde.
// FLOAT (selection runtime cote shader, comme EMISSIVE_NEE_SOFT). 0.5 = moitie/moitie.
// NOTE : ~la moitie des rayons sphere partent SOUS la surface (perdus) -> pour un cote sombre propre,
// monte EMISSIVE_NEE_SAMPLES (16-24) quand OMNI>0, ou augmente EMISSIVE_NEE_OMNI_GAIN.
#define EMISSIVE_NEE_OMNI 0.0 // [0.0 0.25 0.5 0.75 1.0]
// Poids relatif des rayons sphere vs hemisphere (calibrage luminosite cote sombre). 1.0 = neutre.
#define EMISSIVE_NEE_OMNI_GAIN 1.0 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0]

// ===================== HYBRIDE TEINTE (Architecte) =====================
// CHEMIN PRINCIPAL anti 3-symptomes. 0 = pur-RTX gather actuel (repli byte-identique).
// 1 = base d'eclairage emissif = lightmap vanilla colortex2.x (OMNI+STABLE+LISSE+gratuite),
// TEINTEE par la couleur du gather voxel (or/vert/cyan) ; le gather voxel retrograde a un
// simple BOUNCE de contact colore (EMISSIVE_HYBRID_BOUNCE). Resout #1 #2 #3 par construction.
#define EMISSIVE_HYBRID 0 // [0 1]
// Intensite de la base lightmap teintee (terme stable). 1.0 = niveau lampe MC nominal.
#define EMISSIVE_HYBRID_GAIN 1.0 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0 3.0 4.0 6.0]
// Part residuelle du gather voxel path-trace (bounce de contact colore). 0.0 = base seule
// (le plus stable). 0.3 = soupcon de rebond RTX. 1.0 = gather a pleine force (en plus de la base).
#define EMISSIVE_HYBRID_BOUNCE 0.3 // [0.0 0.1 0.25 0.3 0.5 0.75 1.0]
// Courbe gamma de la lightmap (comme lighting.glsl lm.x^curve). 2.0 = doux, 3.0 = contraste MC.
#define EMISSIVE_HYBRID_CURVE 2.2 // [1.0 1.5 2.0 2.2 2.5 3.0]

// ===================== FIX VOXELISATION E/W (Expert voxel) =====================
// 0 = halo 6-faces actuel (repli byte-exact). 1 = stamp 3x3x3 (26 voisins) only-empty :
// remplit le 2x2x2 complet du bloc + halo 1-voxel SYMETRIQUE (faces ET diagonales) -> les
// cotes E/W sont semes meme si la passe d'ombre ne rasterise que la face haut/bas. Resout
// 'un seul cote' a la SOURCE (benefique en pur-RTX ET en bounce hybride). Anti-leak preserve
// (ecriture conditionnee a la cellule vide a<0.5).
#define EMISSIVE_FILL_RADIUS 1 // [0 1]

// ===================== FIX GATHER PUR-RTX (Experts temporel+sampling) =====================
// Lecture TRILINEAIRE du champ emissif au point d'impact (au lieu du nearest hit.rgb) -> la
// radiance lue est CONTINUE en translation = attenue le step de re-snap. Cellules vides
// MASQUEES (on ne mixe que les voisins .a>0.5) pour ne pas baver du noir aux bords. 0 = nearest (repli).
#define EMISSIVE_VOXEL_TRILINEAR 1 // [0 1]
// Reset DOUX de l'accumulation : sur disocclusion, repart de N frames (alpha=1/N) au lieu de
// count=1 (alpha=1 = re-roll franc). 1 = reset sec actuel (repli). 4 = transition ~invisible.
#define EMISSIVE_RESET_FRAMES 4 // [1 2 4 8]
// Tolerance de disocclusion emissive (multiplicateur). 0.5 = actuel (trop strict en mouvement).
// 1.0 = aussi tolerant que l'albedo (le reset doux gere deja la trainee).
#define EMISSIVE_DISOCC_SCALE 1.0 // [0.25 0.5 0.75 1.0 1.5 2.0]
// =======================================================================

// ---- JALON 15 : LPV — INJECTION + PROPAGATION DE LUMIERE (remplace le gather emissif) ----
// 0 = gather actuel EXACT (gatherEmissiveNEE, byte-identique). 1 = champ LPV (compute composite.csh).
// STAGE 1 = injection + lecture DIRECTE trilineaire (PAS de propagation) : SEULES les surfaces a
// ~1 bloc d'une source s'eclairent. STAGE 2 (a venir) = flood -> la lave inonde la zone.
// Mutuellement exclusif avec EMISSIVE_NEE cote consommation : sous EMISSIVE_LPV=1, le #elif de
// composite5 fait que NEE n'alimente plus giEmissive, et la garde de la boucle GI (ligne ~980)
// inclut EMISSIVE_LPV pour que la branche emissive 'break' sans accumuler (anti double-comptage).
// Slider [0 1] (les toggles booleens ne s'affichent pas dans ce menu Iris, cf. VOXEL_GI/EMISSIVE_NEE).
// LUMIERES COLOREES (A3) : toggle du menu (ecran AMBIANCE, « Lumieres colorees »), OFF par
// defaut — a 1 la chaine complete se reveille : voxelisation cascade 0 (shadow.fsh),
// injection (composite.csh), flood 128^3 (composite_a..d), pont forward de lib/lighting.glsl
// (sampleLPVForward) SANS PT ; cout estime ~1-3.5 ms selon GPU (le flood 128^3 domine
// et ne depend PAS du nombre de lumieres : 4 passes x 2.1 M cellules x ~94 imageLoad a
// midi en plaine comme en grotte ; pic supplementaire sur les grandes surfaces
// emissives - mer de lave : 26 load + jusqu'a 27 store par fragment emissif de la passe
// d'ombre), d'ou le defaut OFF (POTATO l'epingle a 0). A 0 les kernels retournent
// immediatement, MAIS l'OFF n'est pas gratuit : les directives image de
// shaders.properties ne sont pas gatables par #if, donc le clear=true de voxelImg
// (128 MiB) + les 5 dispatchs nuls + leurs barrieres coutent ~0.25-0.5 ms par frame
// meme a 0, et voxelImg/lightImg/lightImgB (160 MiB VRAM) restent alloues (detail dans
// shaders.properties, bloc image.voxelImg).
// COULEUR (MISSION LUM) : la radiance injectee est la couleur FIXE par famille de
// lib/cl_colors.glsl — plus jamais l'albedo de texture (torche brune, hue qui danse).
// Le chemin composite5 reste gate VOXEL_GI.
#define EMISSIVE_LPV 0 // [0 1]
// Gain de calibrage du champ -> giEmissive. Echelle DIFFERENTE du random-hit/NEE et passe ENSUITE
// par EMISSIVE_GI_GAIN (1.0 en profile.RTX) -> RECALIBRER a l'activation. EN STAGE 1 (lecture directe,
// effet faible et tres local), monter a 5-8 pour VOIR si l'infra marche, puis recalibrer en Stage 2.
#define LPV_STRENGTH 1.0 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0 3.0 5.0 8.0]
// (STAGE 2, documentaire en Stage 1) Attenuation PAR BLOC du flood : att = LPV_ATTEN^step. Plus bas =
// portee courte, plus haut = inonde plus loin. 0.78 = depart interieur MC. INERTE tant qu'aucun .csh de flood.
#define LPV_ATTEN 0.78 // [0.5 0.6 0.7 0.78 0.85 0.9 0.95 0.97]
// (STAGE 2) Portee du flood. 0 = injection seule (= Stage 1 exact, pas de propagation).
// 2 = flood court (passes step 8+4 ; c/d en copie). 4 = flood complet (step 8+4+2+1, portee ~15 blocs).
// Les passes desactivees deviennent des copies de parite (resultat toujours en lightImg/A). INERTE si EMISSIVE_LPV=0.
#define LPV_PASSES 4 // [0 2 4]

// ---- LUMIERES COLOREES (pont forward LPV -> gbuffers, lib/lighting.glsl sampleLPVForward) ----
// Force du POP additif : radiance LPV coloree AJOUTEE au shading (falloff par le flood = lumiere
// spherique), garde-fou lightmap contre les fuites. 0.0 = teinte seule (aucun ajout d'energie).
// 0.35 defaut (demande user « juste colorer vanilla mais colore et jolie ») : la TEINTE fait
// le travail (CL_TINT_MIX), le pop additif reste discret — zero look « RTX ».
#define CL_STRENGTH 0.35 // [0.0 0.25 0.35 0.5 0.75 1.0 1.5 2.0 3.0]
// Part de la TEINTE LPV dans la couleur torche vanilla la ou le champ a de l'energie
// (l'INTENSITE reste pilotee par la lightmap = falloff spherique fiable, zero fuite).
// 0.0 = teinte orange vanilla partout ; 1.0 = couleur du champ seule.
// NB : CL_TINT_MIX et CL_STRENGTH ne pilotent que la chaine v1 (CL_V2=0) - la v2
// remplace la chrominance a 100% et n'ajoute AUCUNE energie (voir bloc CL_V2).
#define CL_TINT_MIX 0.85 // [0.0 0.25 0.5 0.7 0.85 1.0]

// ---- MISSION CL2 : APPLICATION v2 DES LUMIERES COLOREES (reconstruction) ----
// 0 = chaine v1 EXACTE (flood max-par-luma + teinte partielle CL_TINT_MIX + pop additif
// CL_STRENGTH) - porte de secours bit-identique. 1 = v2, principe Complementary :
//   FLOOD  = DIFFUSION ADDITIVE amortie (les couleurs se MELANGENT : rouge + vert ->
//            degrade passant par le jaune) en ESPACE CARRE (graine au carre a l'injection,
//            racine a la lecture -> fronts perceptuellement doux), avec CONVERGENCE
//            TEMPORELLE : l'injection n'efface plus les cellules d'air, elle herite du
//            champ de la frame precedente (volume qui defile avec la camera) -> pose =
//            fondu chromatique ~5-10 frames, casse = dissolution douce, zero pop.
//   APPLICATION = la couleur du champ REMPLACE integralement la chrominance de la
//            lumiere de torche (normalisee en luminance : zero energie ajoutee, zero
//            gris), l'INTENSITE et la PORTEE restent 100% lightmap vanilla ; plancher
//            +5% de couleur chaude avant normalisation -> fondu continu vers
//            getTorchColor() la ou le champ s'eteint, jamais de noir ni de delave ;
//            fondu quadratique vers vanilla des la moitie de la portee du volume
//            (aucune couture au bord des +-64 blocs) ; offset normal 0.55 cellule
//            (0.5 exact ferait scintiller dalles/tapis - anti bords de voxel).
// Constantes internes CLV2_* SANS liste : pas des options Iris, calibrees par simulation
// (grille 49^3, cluster source 3x3x3) - convergence ~8 frames, profil axial monotone,
// champ borne par la graine (aucun pompage) ; avec l'historique post-stride-1
// (composite_e) : zeros dans r=12 = 0.0%, (1,1,1)=0.0916, (3,3,3)=0.0208, profil
// diagonal monotone, une porte de 1 cellule laisse passer la lumiere.
// CL_V2 lui-meme SANS liste aussi (piege Iris : un define a liste est parse comme
// option meme hors menu -> compte dans la comparaison de profils sans etre visible
// ni reinitialisable ; il n'apparait dans AUCUN ecran de shaders.properties).
// Gate interne, comme les CLV2_*. Les cinq dials v1 (LPV_STRENGTH, LPV_ATTEN,
// LPV_PASSES, CL_STRENGTH, CL_TINT_MIX) gardent leur liste : precedent v1 assume,
// LPV_PASSES est en outre un vrai palier consomme par les gates des .csh.
#define CL_V2 1 // out-of-menu gate, 0 = v1 winner-takes-all chain bit-identical
// Retention du champ par cellule d'air a chaque passe (memoire intra/inter-frame).
#define CLV2_KEEP 0.30
// Poids de transfert par voisin (x LPV_ATTEN^pas en espace carre). 6 faces a tous les pas
// + 12 diagonales d'arete au pas 1 seulement (gate anti-fuite de coin : une des deux faces
// partagees doit etre ouverte).
#define CLV2_XFER 0.14
// Gain applique a la graine AU CARRE a l'injection (portee de DOMINANCE de teinte, pas de
// luminosite : la normalisation en luminance efface l'echelle absolue). 16, MESURE
// (simulation convergee ; purete = part de la chrominance source dans le torchCol final) :
// soul 0.94 a 1 bloc, 0.66 a 6, 0.43 a 10, 0.17 a 15 ; glowstone 0.68 a 6, 0.19 a 15 ;
// redstone 0.46 a 6. Le point 50/50 tombe vers ~9 blocs (soul/glowstone, ~5 redstone) :
// au-dela de ~10 blocs le plancher CLV2_WARM_FLOOR (luma fixe 0.0299 > champ decode)
// DOMINE et l'anneau exterieur revient a l'orange vanilla - assume. Pour pousser la
// dominance vers 15 blocs, BAISSER CLV2_WARM_FLOOR (0.02 -> 50/50 vers 13-14 blocs)
// plutot que monter ce boost : il agit en racine (x4 de boost = x2 de champ decode).
#define CLV2_SEED_BOOST 16.0
// Plancher de couleur chaude (fraction de getTorchColor) ajoute AVANT la normalisation :
// jamais de noir, fondu continu champ -> vanilla (remplace le seuil dur v1).
#define CLV2_WARM_FLOOR 0.05
// Fondu de distance (metrique Chebyshev camera) en FRACTION de la demi-portee du volume
// (LPV_HALF x LPV_SCALE = 64 blocs au VOXEL_SCALE 0.5 par defaut) : debut a la moitie
// (32 blocs), remix quadratique complet a 0.9375 (60 blocs), AVANT le bord -> aucune
// couture, et le fondu suit automatiquement la portee si VOXEL_SCALE change.
#define CLV2_FADE_HALF 0.5
#define CLV2_FADE_END 0.9375
// Garde-fou du champ (anti-NaN / anti-emballement, cap preservant la teinte a l'injection).
#define CLV2_CLAMP 1024.0
// ---- MISSION CL3 : deux gardes TEMPORELS de l'heritage (composite.csh) ----
// Cap de l'HERITAGE d'air : le champ legitime est borne par la graine max possible
// (canal palette max 1.0 x EMISSIVE_VOXEL_STRENGTH, au carre, x CLV2_SEED_BOOST) - au
// defaut 0.5^2*16 = 4.0. Heriter jusqu'a CLV2_CLAMP (1024 = filet anti-NaN du flood,
// 256x la graine) laissait le garbage d'allocation (activation de l'option, alt-tab,
// F3+R) survivre ~11 frames d'arc-en-ciel (simule : luma 424 -> <0.05 en 11 frames).
// Borne a 2x la graine max, le meme garbage tombe a 3.35 et s'eteint en ~6 frames au
// niveau d'une lueur legitime - plus aucun flash "wtf". Suit EMISSIVE_VOXEL_STRENGTH
// automatiquement (un EVS crank a 100 garde son plafond via le min avec CLV2_CLAMP).
#define CLV2_INHERIT_CAP min(CLV2_CLAMP, EMISSIVE_VOXEL_STRENGTH * EMISSIVE_VOXEL_STRENGTH * CLV2_SEED_BOOST * 2.0)
// HYSTERESIS de frustum (shadow.culling=true) : une source qui SORT du volume
// rasterise (torche derriere la camera, bord d'ecran en strafe) disparait du voxel
// grid et son seed s'effondrait a ~0.44/frame en espace carre -> pompage 90.6% de la
// teinte a 2 blocs sur un blink 3on/3off (simule). Desormais une cellule d'air dont
// l'HISTORIQUE est une source (flag 2) et qui n'est PAS observable (hors du frustum
// vue retreci a 92%, ou au-dela de 0.9*shadowDistance) garde un seed EPINGLE decroissant
// x CLV2_SRC_HOLD/frame (espace carre) : blink 3on/3off -> ondulation 13.4% (simule).
// NB le hold n'est PAS invisible par construction : la bande 92-100% du frustum reste
// A L'ECRAN (~9% des cellules visibles a FOV 90) et une cellule tenue eclaire vers
// l'interieur - c'est CLV2_HOLD_FRAMES qui borne le fantome d'une torche cassee dans
// cette bande. Une cellule re-observee sans source redevient de l'air ordinaire
// (voie rapide, dissolution ~2 frames).
#define CLV2_SRC_HOLD 0.90
// Deux gardes du hold (composite.csh) : (1) ENVELOPPE DE LEGITIMITE - lightImgB n'est
// jamais clear (shaders.properties), donc a la 1re frame apres allocation/F3+R un
// alpha garbage dans (1.5,inf) epinglerait du garbage rgb comme "source tenue", hors
// de la contraction x0.44 du flood ; le hold est refuse si le canal max depasse la
// graine legitime max (+1%), soit (1.0*max(TORCH_R/G/B) * EVS)^2 * CLV2_SEED_BOOST -
// le garbage uniforme, ecrase au cap d'heritage (2x cette graine aux dials 1.0), est
// toujours au-dessus. (2) BORNE TEMPORELLE - l'alpha encode l'age de la tenue
// (2 = source fraiche, +1 par frame tenue) et le hold s'arrete apres CLV2_HOLD_FRAMES
// frames : le blink de culling dure 3 frames, 10 le couvre avec marge sans laisser de
// fantome perceptible. L'age exact est transparent pour toute la chaine (les tests
// avals ne regardent que a>1.5 = source / 0.5<a<1.5 = solide ; le flood epingle en
// stockant self tel quel et composite_e copie tel quel : l'alpha survit a la frame).
#define CLV2_HOLD_FRAMES 10

// ---- MISSION CL_V3 : RECONSTRUCTION des lumieres colorees (architecture propre) ----
// Remplace TOUTE la chaine ci-dessus (voxelisation fragment de shadow.fsh, injection
// composite.csh, flood 4 passes composite_a..d, historique composite_e, hysteresis
// CLV2_INHERIT_CAP/SRC_HOLD) par trois briques :
//   1. VOXELISATION PAR ID, COTE VERTEX (shadow.vsh) : chaque sommet de TERRAIN ecrit
//      l'ID de famille lumineuse (ou 1=solide, 0=air) au centre de son bloc via
//      at_midBlock dans cl3VoxImg (r32ui, 128^3, 1 bloc/cellule, aligne bloc). Tous les
//      sommets d'un bloc ecrivent le MEME entier -> aucune course possible. Les entites
//      sont exclues FAIL-CLOSED (at_midBlock absent -> pas d'ecriture) : le joueur ne
//      peut plus etre voxelise en mur, donc plus d'ombre coloree qui le suit.
//   2. DIFFUSION TEMPORELLE PERSISTANTE, 1 PASSE/FRAME (composite.csh) : lightImg /
//      lightImgB en ping-pong par PARITE DE FRAME (frameCounter pair -> ecrit A, impair
//      -> ecrit B ; l'autre volume est l'historique). Air = somme des 6 voisines de
//      face / CL3_DIV (les couleurs se MELANGENT par construction), source = couleur
//      de table AU CARRE (lib/cl_colors.glsl), solide = zero. Defilement par delta de
//      bloc camera, garde teleport. La lumiere s'etablit en ~0.5 s (30 frames) - VOULU
//      (anti-pop), et une source culled derriere la camera s'eteint en fondu au lieu
//      de strober (l'hysteresis CL3 devient inutile).
//   3. LECTURE (sampleLPVForward, lib/lighting.glsl) : trilineaire pur (les solides
//      valent zero - plus de skip/renormalisation qui scintillait), racine APRES
//      interpolation, offset 0.55 voxel le long de la NORMALE GEOMETRIQUE (sort du
//      voxel solide de la surface - fix du clignotement dans les coins), fondu
//      quadratique vers getTorchColor des la moitie de la portee. Les lecteurs
//      echantillonnent le volume ACHEVE de la frame precedente (parite opposee) :
//      forward et deferred voient le MEME champ, zero couture.
// A 0 : chaine CL_V2/v1 ci-dessus intacte (porte de secours bit-identique).
// Gate interne SANS liste (meme piege Iris que CL_V2) ; les constantes CL3_* aussi.
#define CL_V3 1 // out-of-menu gate: 1 = CL3 rebuild (vertex ID voxel + 1-pass temporal diffusion), 0 = legacy CL_V2/v1 chain
// Grille CL3 : 128^3 cellules de 1.0 bloc FIXE (independant de VOXEL_SCALE - la
// voxelisation par bloc n'a de sens qu'alignee bloc), centree camera, snap au bloc.
#define CL3_RES 128 // cells per axis (1.0 block/cell, +-64 blocks around the camera)
#define CL3_HALF 64 // half extent in cells (= CL3_RES / 2)
// Diviseur de diffusion : air = somme(6 faces)/CL3_DIV. Rayon spectral de l'operateur
// = 6/6.42 = 0.9346 < 1 -> champ borne par la graine, ~6.5% de perte par pas = portee
// bornee, convergence ~30 frames (simule, scratchpad cl3v3_sim.py).
#define CL3_DIV 6.42 // diffusion divisor (spectral radius 6/6.42 = 0.9346 < 1, bounded field)
// Cap de lecture d'historique (les volumes persistants ne sont jamais clear) : la
// graine legitime max est (1.0 * max TORCH_R/G/B)^2 <= ~2 aux dials <= 1.4 ; le
// garbage d'allocation (enable, alt-tab) est ecrase a ce niveau et meurt en <1 s au
// rythme 0.9346/frame, sans flash. Scrub NaN/Inf AVANT le clamp (min/max contre un
// NaN rend l'AUTRE operande : clamper d'abord blanchirait le NaN en valeur pleine).
#define CL3_CAP 2.0 // history read cap (max legitimate seed; allocation garbage dies in <1 s)
// Garde teleport : delta camera >= 24 blocs en 1 frame -> historique inutilisable,
// le champ repart de zero (30 frames d'etablissement, invisible sous l'ecran de TP).
#define CL3_TELEPORT 24 // teleport guard in blocks/frame (history dropped beyond this)

// ---- JALON 3 : ACCUMULATION TEMPORELLE DE LA GI VOXEL ----
// Lisse le scintillement de la GI en moyennant la frame courante avec les frames
// precedentes (reprojection + rejet d'historique en disocclusion). PORTE DE SECOURS :
// mets 0 pour revenir a la GI brute du Jalon 2 (utile si l'accumulation casse).
#define TEMPORAL_ACCUM 1 // [0 1]
// Fenetre d'accumulation : nb max de frames moyennees. + bas = reagit vite mais reste
// un peu bruite ; + haut = tres lisse mais "traine" sur les changements lents (jour/nuit).
#define TAA_GI_FRAMES 32 // [2 4 8 12 16 24 32 48 64 128 256]
// Seuil de disocclusion en BLOCS (a la distance de l'oeil = 1 ; mis a l'echelle plus loin) :
// si le pixel reprojete s'est deplace de plus que ca, on jette l'historique (nouvelle geo).
#define DISOCCLUSION_THRESHOLD 0.5 // [0.1 0.25 0.5 0.75 1.0 1.5 2.0 3.0 5.0 8.0]

// ============ JALON 4 : DENOISE ============
// ---- STABILISATION TEMPORELLE DE L'EMISSIF (priorite : tue le clignotement) ----
// L'emissif voxel (Jalon 6) etait ajoute HORS accumulation -> clignote (peu de rayons
// touchent une petite source par frame + textures lave/feu animees). On l'accumule
// desormais dans un buffer dedie (colortex10) avec la MEME reprojection que la GI albedo,
// MAIS sans le clamp anti-firefly dur (c'est lui qui causait le fade-in du Jalon 5). Un gate
// anti-trainee + une montee rapide sur allumage evitent smear et fade-in d'etat.
// PORTE DE SECOURS : EMISSIVE_ACCUM 0 => add brut exact (comportement Jalon 6).
// Slider (les toggles booleens ne s'affichent pas dans ce menu Iris), comme VOXEL_GI.
#define EMISSIVE_ACCUM 1 // [0 1]
// Fenetre d'accumulation de l'emissif. + bas = reagit vite mais reste un peu instable ;
// + haut = tres lisse mais traine un peu sur la lave animee. 16 = bon compromis.
#define EMISSIVE_ACCUM_FRAMES 16 // [1 2 4 8 12 16 24 32 48 64 128]

// ---- JALON 13 : DENOISE SPATIAL DE L'EMISSIF (tue le grain) ----
// A-trous edge-aware (depth + normale + variance-luma) sur colortex10 (emissif accumule), applique
// UNIQUEMENT a la valeur ajoutee a l'image -> colortex10 reste NON denoise (jamais de re-entree dans
// l'historique, comme le denoise GI). Coherent checkerboard (colortex10 est dense). TOGGLE SEPARE de
// GI_DENOISE : tu peux isoler l'emissif (VOXEL_GI_STRENGTH=0) et le denoiser quand meme.
// 0 = OFF (ajout brut, EXACTEMENT le comportement d'avant ce jalon).
#define EMISSIVE_DENOISE 1 // [0 1]
// Force : 0 = quasi passthrough, 1 = nominal, >1 = sigmas plus larges (plus lisse, bave un peu plus
// aux aretes). Baisse a 0.75 si un halo apparait autour d'une glowstone.
#define EMISSIVE_DENOISE_STRENGTH 1.0 // [0.0 0.5 0.75 1.0 1.5 2.0 3.0 5.0 8.0]
// Permissivite du wL variance-aware : sigma_luma = PHI x ecart-type local (plafonne). Plus HAUT =
// lisse plus fort les surfaces planes (tue plus de grain) ; baisse a 2 si un halo borde les sources.
#define EMISSIVE_LUMA_PHI 3.0 // [0.5 1.0 2.0 3.0 4.0 6.0 8.0 12.0 20.0 50.0]

// ---- DENOISE SPATIAL A-TROUS (edge-avoiding wavelet) sur la GI diffuse ----
// Lisse le grain residuel de la GI diffuse accumulee (colortex8) par un filtre a-trous
// edge-aware : poids d'arret sur depth RELATIF (depthtex0 linearise), normale monde
// (colortex1) et luminance. Lit les voisins de colortex8 frame n-1 (1 frame de retard,
// acceptable car la GI est deja lissee temporellement). PORTE DE SECOURS : GI_DENOISE 0 = Jalon 5 exact.
#define GI_DENOISE 1 // [0 1]
// Force du filtre : 0 = quasi passthrough, 1 = nominal, >1 = elargit les sigmas (plus lisse,
// bave un peu plus aux aretes). Baisse a 0.5 si les coins/contacts paraissent etales.
#define DENOISE_STRENGTH 1.0 // [0.0 0.5 0.75 1.0 1.5 2.0 3.0 5.0 8.0]

// ============ FIX A : ANTI-FIREFLY / FIX B : ANTI LIGHT-LEAK (rayons GI) ============
// ---- ANTI-FIREFLY (clamp RELATIF par rayon ; couvre 1ere frame / disocclusion / damier frais) ----
// Le clamp EMA (accumulateGI) ne s'applique QUE quand un historique est trouve : 1ere frame,
// disocclusion et pixels frais du checkerboard = un seul rayon touchant une source vive passe SANS
// borne = point lumineux. Ici on borne chaque rayon par rapport a la MOYENNE COURANTE des rayons
// deja tires (un outlier isole est ecrete, une GI uniformement vive n'est PAS bridee car sa moyenne
// monte avec elle). Agit donc meme sans historique temporel. 0 = OFF (comportement actuel exact).
#define GI_FIREFLY_CLAMP 1 // [0 1]
// MULTIPLICATEUR du clamp : un rayon est limite a GI_FIREFLY_MAX x (moyenne courante des rayons) +
// un petit plancher absolu. PLUS BAS = tue plus de points mais peut adoucir la GI a fort contraste ;
// PLUS HAUT = laisse passer des rayons plus vifs (moins de clamp). 3 = bon compromis (un rayon vaut
// au plus 3x la moyenne locale). La charge utile voxel etant sous-unitaire, ce reglage RELATIF est
// ce qui tue reellement les "points qui font la lumiere" (un cap absolu eleve serait inerte).
#define GI_FIREFLY_MAX 3.0 // [1.0 1.5 2.0 2.5 3.0 4.0 6.0 8.0 12.0 20.0 50.0]

// ---- DENOISE A-TROUS MULTI-PASS (style SVGF : paliers a dilatation croissante 1,2,4) ----
// atrousGI fait deja 2 paliers (1,2) en un appel. 3 AJOUTE un palier (dilatation 4) = noyau effectif
// plus large -> tue le grain basse-frequence residuel SANS latence (toujours 1 appel, voisins frame
// n-1, memes arrets depth/normale/luma). 2 = comportement actuel EXACT (porte de secours). Si les
// contacts/geometries fines paraissent floues, repasser a 2 ou baisser DENOISE_STRENGTH a 0.75.
#define GI_DENOISE_PASSES 3 // [2 3]

// ---- CLAMP SPATIAL ANTI-FIREFLY (tue les outliers isoles que le clamp par-rayon laisse passer) ----
// atrousGI ne fait qu'un BLUR pondere : il moyenne un pixel trop vif sans jamais l'ECRETER. Le clamp
// par-rayon (GI_FIREFLY_CLAMP) part d'une moyenne nulle -> le 1er rayon d'un pixel frais (disocclusion
// / 1ere frame / damier) n'est PAS borne ; le clamp EMA (accumulateGI) n'agit que s'il existe un
// historique. Resultat : un point lumineux isole survit -> "le pixel qui apparait". Ici on borne la
// luminance du pixel CENTRAL a moyenne_voisins + K*ecart-type (et au plus le voisin le plus brillant),
// AVANT le filtrage, en gardant la teinte (ratio luma). Ne touche QUE les vrais spikes (centre >>
// voisinage) ; une zone uniformement vive n'est PAS ecretee. ~8 texelFetch. 0 = OFF (comportement
// actuel EXACT, code non compile). C'est le levier DECISIF du Jalon 10 contre le grain residuel.
// NOTE : les stats viennent de colortex8 (GI frame n-1, comme le filtre a-trous) -> sur un pixel
// FRAICHEMENT disoccle, si tous les voisins ont gN.a<0.5, cnt reste bas et le clamp ne fait rien :
// dans ce cas la mitigation reelle est TAA_GI_FRAMES (fenetre EMA plus longue), pas ce clamp.
#define GI_SPATIAL_CLAMP 1 // [0 1]
// Tolerance : centre limite a moyenne + K x ecart-type des voisins valides. PLUS BAS = ecrete plus
// agressivement (tue plus de points, peut adoucir un peu le contraste de contact / manger les petits
// contacts lumineux 1px) ; PLUS HAUT = plus permissif. 2.0 = defaut sur : seuls les outliers francs
// sont touches (le clamp est unidirectionnel + alimente un denoise luma-aware, mieux vaut prudent).
// Baisser vers 1.25-1.5 si le grain persiste ; monter si la GI parait plate/terne.
#define GI_SPATIAL_CLAMP_K 2.0 // [0.5 0.75 1.0 1.25 1.5 2.0 2.5 3.0 5.0 8.0]

// ---- DENOISE GI FORT (Jalon 10C : tue le grain des surfaces planes) ----
// Le wL (poids luma) de l'a-trous legacy utilise un sigma FIXE : sur une zone PLATE mais BRUITEE
// (VOXEL_GI_SAMPLES rayons), il prend le bruit Monte-Carlo pour un bord de luminance et PROTEGE les
// points brillants au lieu de les moyenner (auto-sabotage : le denoise preserve le grain qu'il
// devrait tuer). STRONG=1 rend wL VARIANCE-AWARE (sigma_luma = GI_LUMA_PHI x ecart-type local de la
// luma, deja calcule par le bloc clamp 3x3, PLAFONNE a l'echelle legacy pour ne pas baver sur les
// vrais gradients de contact/ombre douce) : permissif quand c'est bruite (VRAI lissage des surfaces
// planes), strict SEULEMENT sur un vrai bord. Ajoute aussi un 4e palier (dilatation 8 = noyau ~17x17)
// SI GI_DENOISE_PASSES=3. depth+normale INCHANGES -> AUCUNE bavure d'arete. 0 = comportement actuel
// EXACT (porte de secours byte-identique ET zero-cout). Levier DECISIF du Jalon 10C contre le grain.
#define GI_DENOISE_STRONG 1 // [0 1]
// Permissivite du wL variance-aware : sigma_luma = GI_LUMA_PHI x sqrt(variance 3x3), PLAFONNE a
// l'echelle legacy (le plafond empeche le box-blur sur les vrais gradients). PLUS HAUT = lisse plus
// fort les surfaces planes (tue plus de grain) ; PLUS BAS = preserve mieux les contacts/ombres douces.
// 3.0 = depart SUR (conservateur) ; monte a 4-6-8 si du grain persiste, baisse a 2 si les contacts/
// ombres douces bavent ou si un halo apparait autour de la glowstone. Sans effet si GI_DENOISE_STRONG=0.
#define GI_LUMA_PHI 3.0 // [0.5 1.0 2.0 3.0 4.0 6.0 8.0 12.0 20.0 50.0]

// ---- ANTI LIGHT-LEAK (biais d'origine du rayon GI) ----
// L'origine GI etait wpos + wn*0.6 : biais FIXE, normale seule, non proportionnel a VOXEL_SCALE ->
// la lumiere fuit a travers blocs fins / aretes. Ce reglage cale le biais sur la taille de voxel
// cascade-0 (comme les reflets, composite5:781). EN MULTIPLES de VOXEL_SCALE. Trop BAS = self-
// occlusion (points noirs sur surfaces planes) ; trop HAUT = la GI "decolle" des surfaces et le
// contact darkening disparait. 1.2 (~0.6 bloc a scale 0.5) reproduit ~l'ancien comportement ;
// 1.5 = compromis anti-leak conseille (combine au pre-pas demi-voxel cote composite5).
#define GI_RAY_BIAS 1.5 // [0.0 0.25 0.5 0.75 1.0 1.2 1.5 2.0 2.5 3.0 5.0 8.0]

// Test d'occlusion au TOUT 1er pas du rayon (arete). marchVoxel saute le test au i==0 (anti self-
// hit) : a une arete convexe, la cellule occluante adjacente est justement celle sautee = fuite.
// Comme l'origine est deja poussee > 1 voxel hors de la surface (GI_RAY_BIAS + pre-pas demi-voxel),
// tester i==0 redevient SUR et bouche la fuite d'arete. ATTENTION : marchVoxel est PARTAGE avec le
// chemin reflets eau (originR deja biaise > 1 voxel, sur la aussi). DEFAUT 0 = saut i==0 actuel
// (porte de secours, AUCUN changement sur la GI NI sur les reflets). Passer a 1 SEULEMENT si, apres
// GI_RAY_BIAS=1.5 + pre-pas, une fuite d'arete persiste ; si des surfaces planes noircissent,
// repasser a 0 et/ou monter GI_RAY_BIAS d'un cran.
#define GI_EDGE_OCCLUSION 0 // [0 1]

// ============ MODE EXPERIMENTAL : OMBRE SOLEIL FULL PATH-TRACED (voxel) ============
// 0 = HYBRIDE ACTUEL EXACT (ombre directe = shadow map PCSS, BYTE-identique). 1 = l'ombre
// directe du soleil/lune vient d'un RAY-MARCH dans les voxels (toute la lumiere passe par le
// path tracer). HONNETE : ombres cubiques/blocky (resolution VOXEL_SCALE), plus de bruit, plus
// lent, et PROBABLEMENT MOINS BEAU que la PCSS. Necessite VOXEL_GI=1 (sans grille, pas d'ombre
// voxel -> on garde la shadow map). GATE STRICT : ABSENT des profils -> defaut 0 = repli hybride exact.
#define FULL_PATH_TRACE 0 // [0 1]
// CONFLIT DE TAMPON, explicite : colortex12 a DEUX proprietaires possibles et
// ils sont incompatibles. A FULL_PATH_TRACE=1 c'est le terme direct pur
// (RGBA16F, PLEIN ECRAN, ecrit par gbuffers_terrain, lu par composite5) ; le
// chantier RAYONS DE NUAGES en fait la carte de transmittance des cumulus
// (R8, CTM_RES^2, ecrite par prepare2). Ni le format ni la TAILLE ne peuvent
// etre les deux a la fois, et un programme ne peut rendre que dans des cibles
// de MEME taille -- gbuffers_terrain ecrirait dans colortex0/1/2/5/11 plein
// ecran ET dans un colortex12 de 1024^2.
// LA GARDE EST LARGE (elle ne teste PAS CLOUD_SHAFTS) et c'est VOULU :
// "size.buffer.colortex12" de shaders.properties n'est pas conditionnable --
// un fichier .properties ne connait pas les #define -- donc le tampon est
// redimensionne MEME a CLOUD_SHAFTS 0. Reactiver le path tracing demande donc
// AUSSI de retirer cette ligne de shaders.properties. Ecart assume : une
// erreur de compilation qui dit quoi faire vaut mieux qu'un rendu
// silencieusement faux, dans une combinaison que rien n'active par defaut
// (FULL_PATH_TRACE 0, absent des quatre profils).
#if FULL_PATH_TRACE == 1
#error "FULL_PATH_TRACE veut colortex12 en RGBA16F plein ecran, or RAYONS DE NUAGES le redimensionne : retirer la ligne size.buffer.colortex12 de shaders.properties et mettre CLOUD_SHAFTS=0, ou remettre FULL_PATH_TRACE=0."
#endif
// Rayons d'ombre soleil par pixel (penombre). 1 = ombre dure, 1 march (le moins cher). 2-8 =
// penombre douce jitteree dans le cone solaire (plus cher, plus de bruit ; pas de denoise temporel
// dedie au 1er jet -> scintillement en mouvement).
#define FPT_SUN_SAMPLES 1 // [1 2 4 8]
// Pas du ray-march d'ombre (budget perf). Plafonne par shadowDistance (la grille n'est remplie que la).
// Baisse si lag. Le pas est FIXE (cascade-locale) pour ce march d'ombre -> anti light-leak murs fins.
#define FPT_SUN_STEPS 24 // [8 16 24 32 48 64 96 128]
// Rayon angulaire du "soleil" pour la penombre (tan de l'angle ; ~0.03 = disque un peu elargi,
// plus grand = ombres plus molles). Sans effet si FPT_SUN_SAMPLES=1.
#define FPT_SUN_RADIUS 0.03 // [0.005 0.01 0.02 0.03 0.05 0.08 0.12 0.2]
// Biais anti self-shadow le long du rayon soleil, en multiples de VOXEL_SCALE. Trop BAS = acne
// (points noirs sur surfaces planes ensoleillees) ; trop HAUT = peter-panning (l'ombre se detache
// du pied des objets). marchVoxel saute deja i==0 -> 0.25 suffit en general.
#define FPT_LIGHT_BIAS 0.25 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0]

// ============ JALON 8 : CHECKERBOARD GI (demi-cadence) ============
// OPTIMISATION : ne lance le ray-march cher (VOXEL_GI_SAMPLES rayons) que sur la MOITIE des
// pixels par frame (damier 2x2 alternant avec frameCounter). Les pixels "sautes" reutilisent
// l'historique temporel reprojete (colortex8/9 GI + colortex10 emissif) au lieu de relancer
// des rayons -> ~2x moins de rayons. Invisible car la GI est diffuse basse-frequence, accumulee
// (TAA_GI_FRAMES) et denoisee (a-trous) : le damier est masque. Un pixel saute SANS historique
// valide (disocclusion / 1ere frame / hors-ecran) ray-marche QUAND MEME (anti trou-noir).
// PORTE DE SECOURS : GI_CHECKERBOARD 0 => comportement EXACT d'avant (chaque pixel ray-marche).
// Slider (les toggles booleens ne s'affichent pas dans ce menu Iris), comme VOXEL_GI. Se cumule
// avec la baisse de VOXEL_GI_SAMPLES/VOXEL_GI_DISTANCE du profil RTX. NE PAS desactiver
// TEMPORAL_ACCUM ni GI_DENOISE avec ce mode : ce sont eux qui rendent le damier invisible.
#define GI_CHECKERBOARD 1 // [0 1]

// ============ DEBUG ============
#define DEBUG_VIEW 0 // [0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31]
// PF: view 30 = PHYSICS_FIELD_SYNC probe (composite1 -> colortex5, displayed
// raw by final.fsh like views 21..24/27/28). Fausses couleurs :
//   NOIR       le battement de l'ocean PHYSICS MOD est PERIME sur cette frame
//              (mod absent, ocean eteint, ou PHYSICS_FIELD_SYNC = 0) -> tous
//              les effets d'eau restent sur le champ du pack.
//   ROUGE      battement VIVANT, mais ce pixel-ci ne porte pas l'estampille de
//              la frame courante (ce n'est pas une surface d'ocean du mod).
//   VERT       ce pixel EST une surface d'ocean du mod cette frame ; la
//              LUMINOSITE du vert = la waviness locale (0 = cote calme,
//              1 = plein large).
//   BLEU (mele) hauteur du champ physics REIMPLEMENTE (vlxPhysSlope /
//              vlxPhysHeight) lue au point monde du pixel : c'est LE test du
//              drift. Si les franges bleues glissent CONTINUMENT d'un chunk a
//              l'autre, l'hypothese "le champ du mod est continu entre chunks"
//              tient ; si elles se decalent en marches sur les frontieres de
//              chunk (16 blocs), elle est fausse et il faut publier le drift
//              par chunk au lieu d'un seul drift global.
// PR: view 31 = PHYS_REAL probe (composite1 -> colortex5, displayed raw by
// final.fsh). Fausses couleurs, peintes UNIQUEMENT quand le battement de
// l'ocean du mod est vivant (sinon tout est NOIR, comme la vue 30) :
//   ROUGE      la CARTE DE RIDES recopiee, lue au xz monde du pixel (valeur
//              BRUTE, saturee a 12). C'EST LE TEST DEMANDE : jeter un objet
//              dans l'eau doit dessiner un ANNEAU ROUGE, le bateau un V.
//              Rouge partout noir alors que l'ocean du mod est a l'ecran =
//              la copie ne passe pas (image non liee, ou PHYS_REAL 0).
//   VERT       norme de la PENTE reconstruite de la normale que le mod
//              affiche (base + rides). A hauteur de vagues 0 et sans ride,
//              elle est EXACTEMENT nulle : plus une trace de vert.
//   BLEU       la densite caustique livree (0.4 x densite : gris moyen = 1.0,
//              donc une image UNIFORMEMENT bleu sombre = aucune caustique).
// G2 GLASS: view 28 = GLASS_SEE_THROUGH probe, false colours, painted on GLASS
// PIXELS ONLY (composite1 -> colortex5, displayed as-is by final.fsh). One look
// through the offending pane answers the whole question in two seconds:
//   BLACK  = the GLASS branch never ran on this pixel - the shader does not see
//            glass here (wrong colortex2.b band, or a resource-pack block that
//            block.properties does not list as material 30).
//   RED    = branch reached, but NO water measured behind the pane.
//   YELLOW = red + green: a water column WAS measured in the shadow map, but
//            the view ray crosses no submerged span.
//   WHITE / PINK = a submerged span exists and the water column is being drawn;
//            the BLUE amount is the span LENGTH (0.20 for about one block,
//            saturated at 24 blocks).
// So: anything still RED is a pane where the water was not detected, anything
// turning white is dressed. Panes only - water, terrain and sky stay black.
// UW2: view 27 = the direction the UNDERWATER BEAMS actually use, painted as
// RGB = dir * 0.5 + 0.5 (composite1 -> colortex5, displayed by final.fsh).
// WATER pixels and a submerged eye get the beam direction, everything else
// gets the raw air lightW, so the two read side by side in one screenshot:
// if UW_SUN_COHERENT is doing its job the water is VISIBLY greener (a bigger
// +y) than the land, and it stops changing once the sun drops past 48.59 deg
// of incidence. Same colour on the whole water body = every shaft term shares
// one direction; two different greens = a term escaped the unification.
// BH2: view 26 = END BLACK HOLE contributions in false colour (deferred.fsh,
// End sky pixels only). RED = photon ring, GREEN = far half of the accretion
// slab seen through the lens, BLUE = near half, unlensed, in front of the
// shadow, MAGENTA = inside the shadow. Everything NOT neon keeps its normal
// look, so a bright shape that stays grey-blue is an END STORM tower
// (lib/end_storm.glsl) and NOT a second black hole - that is the check the
// creator's "there are 3 black holes?" report needs, in two seconds.
// DIMENSION_FX: view 25 = dimension detection (final.fsh): RED tint = Nether,
// VIOLET = End, GREEN = Overworld (grey when DIMENSION_FX is off).
// R6 EAU : vue 23 = refl RGB final de l'eau (composite1, transporte via colortex5) ;
// vue 24 = R confiance SSR (hit) / G poids reflet (reflW) / B fresnel. Hors eau : albedo attenue.
// H: vues 19/20 = shadow map couleur / profondeur (final.fsh). 13/14 pris par composite6.
// R5 OMBRES : vue 21 = facteur d'ombre RECU par pixel (luma BRUT de sampleShadowPCF,
// recalcule dans gbuffers_terrain/entities, transporte via colortex5 et affiche TEL QUEL
// par final.fsh — aucun post-process). Vue 22 = classification du texel d'ombre au pixel
// recepteur (R6 tag-RGB) : BLANC eclaire, NOIR ombre opaque (occludeur dans shadowtex1),
// ROUGE bande SOLIDE tex0-only (le fix occulte pleinement ici — rouge sous poulet/sapling
// = ombre attendue en jeu), BLEU bande EAU, CYAN bande VERRE/PORTAIL, VERT bande solide
// a alpha<0.9 (ecriture partielle, occulte quand meme), JAUNE anomalie s0>s1, MAGENTA
// hors shadow map. BLANC sous une entite = profondeur ABSENTE de shadowtex0 (probleme
// emetteur Iris, pas le tag). Eau/mains : albedo inchange.
//#define DEBUG_SPLIT

// ============ DIVERS ============
#define MIN_LIGHT 0.0 // [0.0 0.005 0.01 0.02 0.03 0.05 0.08 0.12]
// ---- WIND ON PLANTS (screen CONFIG_WIND) ----
// OFF BY DEFAULT EVERYWHERE (creator's request). Both toggles use the pack's
// commented-define idiom: at OFF the whole sway block disappears at preprocess
// time in gbuffers_terrain.vsh, so there is NO vertex displacement and no cost,
// and TAA/normals keep no trace of any motion (geometry is strictly static).
// The Distant Horizons path (dh_terrain.vsh) never swayed and still does not.
//#define WAVING_FOLIAGE
#define WAVING_STRENGTH 1.0 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0 3.0 5.0 8.0 12.0]
#define WAVING_SPEED 1.0 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0 3.0 5.0 8.0 12.0]
// Size of the gust pattern in world space: <1 = long lazy waves crossing a
// field, >1 = short choppy ripples. 1.0 = the historical pattern, exactly.
#define WAVING_SCALE 1.0 // [0.25 0.5 0.75 1.0 1.25 1.5 2.0 3.0 4.0]
// Extra amplitude while it rains: amp *= 1.0 + rainStrength * this.
// 0.0 = the storm no longer shakes the plants. 1.5 = historical behavior.
#define WAVING_RAIN_BOOST 1.5 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0 3.0 5.0]
// Underwater plants only (kelp, seagrass): extra amplitude of the slow current
// sway, amp *= 1.0 + this. Requires WAVING_WATER_PLANTS. 1.8 = historical.
#define WAVING_WATER_AMOUNT 1.8 // [0.0 0.25 0.5 0.75 1.0 1.4 1.8 2.5 3.5 5.0]
//#define WAVING_WATER_PLANTS
#define SUBSURFACE_STRENGTH 1.0 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0 3.0 5.0 8.0]
// Plancher d'ombre du feuillage : 0 = ombres dures (avant), 0.45 = douces, 0.75 = tres douces.
#define FOLIAGE_SHADOW_FLOOR 0.2 // [0.0 0.1 0.2 0.3 0.45 0.6 0.8 1.0]
// Force de l'ombre RECUE sous le feuillage (subsurface>0 uniquement) : 1.0 = ombre
// pleine/dense, 0.0 = comportement plancher seul (ancien). No-op EXACT hors feuillage.
#define FOLIAGE_SHADOW_STRENGTH 1.0 // [0.0 0.25 0.5 0.75 1.0]
// Teinte VERTE de l'ombre sous le feuillage (lumiere filtree par les feuilles).
// 0.0 = ombre neutre, 0.35 = verdit franchement les zones sombres, 1.0 = tres vert.
#define FOLIAGE_SHADOW_TINT 0.35 // [0.0 0.15 0.25 0.35 0.5 0.75 1.0]

// ============ [CONFIG] - CREATOR'S TUNING LAB ============
// Expert dials behind the main-menu CONFIG screen. EVERY default equals the
// exact current behavior: the pack renders identically until a slider moves.

// ---- Water seen from OUTSIDE (composite1 reference column) ----
// WATER COLOUR MODEL V2 (master switch). 0 = the previous constant set,
// BIT-IDENTICAL. 1 = the reworked model documented at the top of
// composite1.fsh: absorption re-derived from the published pure-water +
// CDOM absorption spectra instead of the old hand-set triple, in-scatter
// chroma rotated from desaturated slate to sea cyan AT CONSTANT Rec.709
// LUMINANCE, per-channel absorption restored on the submerged view, flat
// (depth-independent) submerged veil density, and a much lighter horizon
// sky floor so distant water stays a mirror instead of turning milky.
// Every dial on this screen keeps working in both modes; three of them
// change RANGE of effect (see the .lang comments): WATER_FOG_BLUE now
// slides gray -> sea cyan instead of gray -> slate, WATER_CLARITY and
// UW_CLARITY now act on a clearer starting point underwater.
#define WATER_COLOR_V2 1 // [0 1]
// WATER COLOUR MODEL V3 (EAU3). Requires WATER_COLOR_V2 = 1; at 0 the whole
// pass is BIT-IDENTICAL to V2. What it changes, and why (all three points were
// MEASURED on the V2 build before being touched -- see the WCOL_V3 block at the
// top of composite1.fsh for the tables):
//   (1) THE LIGHT LEG. The WATER band of the colored shadow (lib/lighting.glsl)
//       handed the water's SURFACE ALBEDO back as if it were a TRANSMITTANCE:
//       at the shipped ocean tint that constant is (0.024, 0.192, 0.796), i.e.
//       97.6% of the RED is removed from the sun on EVERY submerged surface, at
//       ZERO depth exactly as much as at twenty blocks. That single
//       depth-INDEPENDENT multiplier is what flattened the depth gradient: the
//       delivered hue sat at 269-270 deg from 0.5 to 8 blocks of view path.
//       V3 replaces it by exp(-k * t) over the water thickness the shadow map
//       already measures, with the SAME published absorption spectrum the view
//       leg uses (VLX_WATER_K_* below).
//   (2) THE VEIL. V2 dissolved the floor with a GRAY exp2(-0.288 d) on top of
//       the per-channel absorption: 0.1996 per block of achromatic extinction,
//       4.6x the blue absorption coefficient, applied equally to all three
//       channels. V3 replaces it by a per-channel SCATTERING coefficient b, so
//       the column becomes one honest single-scattering medium
//       (T = exp(-(a + b) d), in-scatter share = 1 - T) instead of two stacked
//       attenuations. The blue floor survives 15% longer at 3 blocks and 77%
//       longer at 12.
//   (3) THE DEEP CHROMA. Re-derived as the water-leaving reflectance
//       b_b / (a + b_b), at the SAME Rec.709 luminance as V2 (0.3587), so the
//       deep water changes HUE and not BRIGHTNESS -- the "milky powder-blue"
//       failure mode is a luminance one and cannot come back through this door.
#define WATER_COLOR_V3 1 // [0 1]
// Published absorption spectrum of the water column, per BLOCK, shared by the
// view leg (composite1 waterColumn) and the light leg (lib/lighting.glsl).
// MIRROR of WCOL_K_OUT in composite1.fsh -- the two MUST stay equal, which is
// why the numbers live here and are read from both files.
// Pope & Fry 1997 pure water + Bricaud/Morel/Prieur 1981 CDOM a_g(440)=0.03,
// sampled at the sRGB primaries (R 611 nm, G 549 nm, B 465 nm) = (0.2937,
// 0.0695, 0.0313) per metre, x1.36 metres of water per block (the single
// artistic scale, criterion in the composite1 WCOL block).
#define VLX_WATER_K_R 0.399
#define VLX_WATER_K_G 0.095
#define VLX_WATER_K_B 0.043
// Derived master gate: V3 only takes effect on top of V2.
#if WATER_COLOR_V2 == 1 && WATER_COLOR_V3 == 1
    #define WCOL_V3 1
#else
    #define WCOL_V3 0
#endif

/* ============ EAU9 / WATER_COLOR_V4 -- L'EAU N'EST PAS DE L'EAU PURE =========
   Rapport, dixieme fois : "un bleu trop bleu, bleu bleu, pas realiste", en
   regardant le CORPS de l'eau depuis la surface. Les neuf passes precedentes
   ont chacune corrige un vrai defaut du MODELE. Celle-ci ne touche pas au
   modele : elle constate qu'il est PARAMETRE POUR LA MAUVAISE EAU.

   ---- LE DIAGNOSTIC, MESURE SUR LES CONSTANTES LIVREES ELLES-MEMES ----------
   WCOL_K_OUT (0.399, 0.095, 0.043) par bloc a ete ajuste au moindre carre sur
   a_w(Pope & Fry 1997) + a_cdom(Bricaud, Morel & Prieur 1981) echantillonnes a
   611/549/465 nm : residu RMS 2.6 %, et il en sort a_y(440) = 0.029 m^-1.
   VERIFICATION INDEPENDANTE, sur une constante qui n'entrait PAS dans
   l'ajustement : WCOL_B_SCAT / 1.36 moins le b_w de Morel 1974 donne un b_p
   particulaire qui colle a la loi de Morel 1988 b_p(550) = 0.416 Chl^0.766 a
   1.0 % pres, pour Chl = 0.12 mg/m3. Les DEUX constantes -- derivees a deux
   passes differentes, par deux raisonnements differents -- designent la meme
   eau : a_y(440) ~ 0.03, Chl ~ 0.12. C'est la mer des Sargasses. Jerlov type I.
   L'eau la plus claire, la plus bleue et LA PLUS SATUREE de la planete.
   (Le commentaire de VLX_WATER_K_* ci-dessus le dit d'ailleurs en toutes
   lettres depuis EAU3 : "CDOM a_g(440)=0.03". Personne n'avait remarque que
   c'etait une valeur d'ocean oligotrophe du milieu de l'Atlantique.)
   Ordres de grandeur publies pour a_y(440), m^-1 (Bricaud et al. 1981 ;
   Nelson & Siegel 2013) : ocean ouvert 0.01-0.05 | cotier 0.1-0.5 |
   rivieres et lacs 0.5-2 | marais a eau noire 2-10. Une eau que le joueur
   regarde -- un lac, une riviere, une mer bordee de plage -- n'est JAMAIS de
   type I. Le modele avait raison ; ses deux boutons etaient au bout de leur
   course du cote "eau distillee".

   ---- CE QUE V4 CHANGE : LES DEUX BOUTONS, RIEN D'AUTRE ---------------------
   Trois ancres, melangees par le CLIMAT DU BIOME (lib/biome.glsl, uniformes
   camera, cout nul) :
     CLEAR  a_y(440) 0.030  Chl 0.12  = WCOL_K_OUT / WCOL_B_SCAT / WT_DEEP AU
            BIT PRES. Biomes froids / geles : l'eau polaire EST de type I-II,
            et le rendu livre y est donc rigoureusement inchange.
     MID    a_y(440) 0.150  Chl 0.45  Jerlov cotier 1 / cas 2 de Morel : mer de
            plateau temperee, lac clair, riviere. LE DEFAUT.
     DARK   a_y(440) 0.850  Chl 1.60  marais / mangrove / jungle.
   L'absorption et la diffusion sont des DELTAS poses sur les constantes
   livrees, a l'echelle que le pack declare lui-meme (x1.36 m/bloc) :
     k(V4) = WCOL_K_OUT + 1.36 [ a_cdom(a_y) - a_cdom(0.03)
                               + a_ph(Chl)  - a_ph(0.12) ]   a 611/549/465 nm
   avec a_cdom(l) = a_y(440) exp(-0.016 (l - 440)) (Bricaud 1981, S median de la
   bande publiee 0.014-0.018) et a_ph = a*_ph Chl^0.75 (tassement de Bricaud
   et al. 1995), a*_ph etant un modele a trois bandes cale sur les POSITIONS et
   LARGEURS publiees (Soret 440, accessoires 490, Qy 675 ; Prieur &
   Sathyendranath 1981) -- un modele de forme, pas une table recopiee, et c'est
   ecrit ici pour que personne ne lui prete une precision qu'il n'a pas.
   LA CHROMA D'IN-SCATTER passe par la MEME chaine que EAU4 : reflectance
   sortant de l'eau R(l) = b_b/(a + b_b), integree contre CIE 1931 2 deg x D65,
   convertie par la matrice sRGB, puis projetee dans le gamut vers son propre
   point achromatique. VALIDATION DE LA CHAINE : rejouee sur l'eau LIVREE elle
   redonne (0.0720, 0.4025, 0.7665) contre le (0.0720, 0.4045, 0.7462) que EAU4
   avait derive -- 3 % sur le vert, zero sur le rouge, sur une derivation faite
   il y a quatre passes par un autre chemin. La chaine est la bonne.

   ---- L'ECART DE TEINTE QUE EAU8 PORTAIT DEJA, ET POURQUOI IL PREND SA -----
   ---- RETRAITE ------------------------------------------------------------
   La chroma PHYSIQUE de l'eau livree tombe a 211.5 deg de teinte ; le pack
   livre WT_DEEP a 192.0. EAU8 portait donc deja une rotation ARTISTIQUE de
   -19.1 deg (a luminance Rec.709 exacte, saturation x0.9035) dont le but ecrit
   etait justement de sortir le milieu du bleu primaire. V4 fait la meme chose
   PHYSIQUEMENT. Empiler les deux, c'est compter deux fois et finir vert.
   La rotation decroit donc lineairement entre a_y(440) = 0.030 (pleine, donc
   l'ancre CLEAR reproduit le reglage approuve par le createur au bit pres) et
   a_y(440) = 0.098 (nulle) -- 0.098 etant le point, RESOLU et non choisi, ou le
   CDOM reel a deplace la teinte d'exactement autant que la rotation le faisait.

   ---- CE QUI EST UN CHOIX ET PAS DE LA PHYSIQUE, DIT FRANCHEMENT ------------
   La MAGNITUDE de la diffusion. Physiquement, Chl 0.45 multiplierait b par
   ~4.8 et le fond se dissoudrait en ~1.5 bloc au lieu de 6-7 : ce serait un
   changement de CLARTE, pas de COULEUR, et le createur n'a pas demande a voir
   moins loin. La FORME spectrale de b reste donc physique (Morel 1988,
   lambda^-1) mais sa luminance Rec.709 est bornee a x1.15 a MID et x1.60 a
   DARK. Le pack assume deja cet axe separement : WATER_CLARITY vaut 1.5.
   Cout mesure de la borne : lisibilite du fond a 3 blocs, luma de absorb*visW
   0.4511 -> 0.3827 (-15 %) a MID, -58 % a DARK (un marais EST trouble).

   ---- BALAYAGE DES SITES, ET LA SEULE EXCEPTION, NOMMEE -------------------
   Tous les sites qui construisent une Beer-Lambert d'eau ou lisent une chroma
   de milieu passent par les accesseurs, y compris les SIX qui fabriquent leur
   exponentielle a la main et qu'un grep sur waterColumn ne voit pas (piege que
   le bloc EAU7 documente pour l'avoir subi) : colonne libre, colonne derriere
   une VITRE, deux colonnes de FACES CULLEES, teinte des CAUSTIQUES (quatre
   sites v3/v4/v5/v6, a la surface et sur le fond), colonne IMMERGEE, repli de
   REFLEXION TOTALE, et la jambe de LUMIERE. Verifie hors composite1 :
   dh_water.fsh n'a aucun spectre d'eau (son propre commentaire le dit et le
   grep le confirme), lib/program_water_fragment.glsl non plus, et
   lib/vl_halfres.glsl consomme vlxWaterShadowT() -- il suit donc sans etre
   touche, ce qui est exactement ce qu'on veut d'une fonction partagee.
   L'EXCEPTION : uwShaftTint (WT_SHAFT_*, teinte des puits de lumiere
   sous-marins, composite1.fsh et son miroir lib/vl_halfres.glsl) ne suit PAS.
   Deux raisons, la premiere honnete et la seconde technique. (1) Ce n'est pas
   la chroma du MILIEU mais celle de la LUMIERE qui y survit, et son absorption
   est deja tarifee par vlxWaterShadowT() qui, lui, suit le biome ; EAU8 note
   d'ailleurs que cette famille porte deja un decalage assume de 6.4 deg par
   rapport au milieu au cran livre. (2) Ses deux sites sont dans des regions
   tenues par d'autres passes en cours au moment de l'ecriture. A rouvrir si les
   puits de lumiere d'un marais sont signales comme trop bleus par rapport a
   l'eau qui les porte -- l'ecart y serait le plus grand (204 contre 140 deg).

   ---- CE QUE CA DONNE, MESURE (sable, midi, defauts livres) -----------------
   LE FILTRE POSE SUR LE FOND -- le terme dont le bloc EAU7 dit qu'il decide
   84-97 % du pixel de champ proche -- normalise au bleu, a 2 blocs de chemin :
     livre  (0.528, 0.944, 1.000)      MID  (0.673, 1.156, 1.000)
   Le rouge survit 27 % de mieux et le VERT PASSE DEVANT LE BLEU. Teinte livree
   du sable sous 10 / 20 / 40 blocs : 173.6 / 190.4 / 212.1 deg -> 136.0 /
   129.3 / 122.3. Le sable reste du sable au lieu de virer cyan puis bleu.
   COLONNE (vue plongeante), saturation HSV / teinte par profondeur :
     livre  2 bl 0.289/99.4  5 0.628/160.1  10 0.878/176.8  20 0.855/191.2  40 0.808/192.2
     MID    2 bl 0.363/89.4  5 0.609/135.3  10 0.842/146.4  20 0.761/165.9  40 0.731/172.3
     DARK   2 bl 0.585/68.5  5 0.774/90.4   10 0.598/102.4  20 0.517/101.1  40 0.517/101.0
   PIXEL FINAL, MIROIR COMPRIS (le seul chiffre qui compte vraiment), pire
   saturation sur 1-60 blocs : livre 0.777 -> MID 0.734 -> DARK 0.717. La barre
   de realisme de cette passe (0.75) est franchie, et elle ne l'etait pas.
   NON-REGRESSION : la luminance Rec.709 de la chroma vaut 0.358481 AUX TROIS
   ANCRES, donc n'importe quel poids de biome -- un melange lineaire de
   couleurs de meme luminance -- la conserve EXACTEMENT. La regle de luminance
   constante que EAU2 a EAU8 defendent tient ici PAR CONSTRUCTION, pas par
   verification. Luminance de la colonne seule a 0.5 / 3 / 20 blocs :
   0.0149/0.0669/0.1319 -> 0.0184/0.0777/0.1330, soit +23 % / +16 % / +0.8 % ;
   c'est reel, c'est le seul poste de luminance qui bouge, et a 0.5 bloc ce
   terme pese 0.3-0.5 % du pixel (table EAU7), donc invisible.
   PERF_WATER_FAR_SIMPLE : il appelle la MEME waterColumn() avec un chemin de
   1e3, donc son asymptote est la limite de la branche complete PAR
   CONSTRUCTION -- ecart de teinte a la couture 70-90 blocs mesure a 0.0000 deg
   aux trois ancres. Rien a corriger la, et c'est verifie plutot que suppose.
   JAMBE DE LUMIERE (vlxWaterShadowT) : elle lit le MEME melange, donc le
   spectre reste unique. Transmittance sous 2.12 blocs de soleil :
   (0.429, 0.818, 0.913) -> (0.419, 0.768, 0.697) a MID. Le bleu cesse de
   sur-vivre a la jambe de lumiere, ce qui de-cyanise le fond une deuxieme fois
   -- et c'est le deuxieme terme le plus fort selon EAU7 (40.5 %).
   CAUSTIQUES et VITRES : leurs beer4S / absorbG / absorbU sont batis a la main
   sur le meme spectre, donc ils suivent sans site nouveau (voir la liste des
   sept sites dans composite1.fsh).
   0 = V3/EAU4 au bit pres. Hors menu (pas de liste d'options).
   ============================================================================ */
#define WATER_COLOR_V4 1 // eau naturelle CDOM + chlorophylle par biome (0 = V3/EAU4 verbatim)

// Ancres MID et DARK. CLEAR n'est pas ici : c'est WCOL_K_OUT / WCOL_B_SCAT /
// WCOL_SCAT_DEEP eux-memes, lus sur place, pour qu'aucune copie ne puisse
// deriver de l'original.
#define WCOL4_K_MID_R 0.410124
#define WCOL4_K_MID_G 0.124806
#define WCOL4_K_MID_B 0.170389
#define WCOL4_B_MID_R 0.133048
#define WCOL4_B_MID_G 0.148056
#define WCOL4_B_MID_B 0.174802
#define WCOL4_C_MID_R 0.072000
#define WCOL4_C_MID_G 0.440151
#define WCOL4_C_MID_B 0.393045
#define WCOL4_K_DARK_R 0.473248
#define WCOL4_K_DARK_G 0.294543
#define WCOL4_K_DARK_B 0.854511
#define WCOL4_B_DARK_R 0.185099
#define WCOL4_B_DARK_G 0.205994
#define WCOL4_B_DARK_B 0.243204
#define WCOL4_C_DARK_R 0.244015
#define WCOL4_C_DARK_G 0.411909
#define WCOL4_C_DARK_B 0.166285
// Position du biome sur l'axe CLEAR(0) - MID(0.5) - DARK(1), a partir des trois
// poids climatiques uniformes de lib/biome.glsl. Un biome neutre -- ocean,
// riviere, lac, plaine, foret : temperature 0.5, pluviometrie 0.4-0.5, donc les
// trois poids valent 0 -- tombe sur MID, qui est le defaut et porte l'essentiel
// du rendu. FROID (ocean gele, riviere gelee, plaine enneigee, taiga) descend a
// CLEAR, donc au rendu LIVRE AU BIT PRES -- et c'est aussi juste physiquement,
// l'eau polaire est bien de type Jerlov I-II. CHAUD+HUMIDE (marais, mangrove,
// jungle) monte vers DARK.
// OU CHAQUE BIOME TOMBE REELLEMENT, calcule sur les temperature/pluviometrie
// vanilla et non estime :
//   ocean / deep_ocean / river / warm-cold ocean / plains / lush_caves  t = 0.500
//   taiga 0.463 | forest & dark_forest 0.575 | savanna 0.524 | desert 0.560
//   swamp & mangrove_swamp 0.734 | jungle 0.778
//   frozen_ocean / frozen_river / snowy_plains 0.000  (= rendu livre, bit pres)
// LE COEFFICIENT HUMIDE EST 0.30 ET NON 0.40, et la raison est un artefact
// assume du signal : les poids sont ceux du biome ou se trouve la CAMERA, donc
// depuis une plage de jungle l'ocean prend la teinte de la jungle. A 0.40 la
// jungle tombait a t = 0.87 (teinte de colonne 127 deg, franchement olive) ;
// a 0.30 elle tombe a 0.778 (143 deg) et le marais a 0.734 -- colonne a 2 blocs
// teinte 77 deg saturation 0.49, soit le brun-vert vise, sans qu'une mer bordant
// une jungle vire au bouillon. Lisibilite du fond en marais : luma de absorb*visW
// a 3 blocs 0.451 -> 0.273 au lieu de 0.246.
// CHAUD+SEC ne bouge presque pas (+0.06) : une oasis ou une mer chaude peu
// profonde est un peu plus productive, pas trouble.
// L'ECART AU BASE EST MULTIPLIE PAR BIOME_CLIMATE_STRENGTH (lib/biome.glsl),
// comme tout autre effet biome-climat du pack : le cran existant du joueur
// commande donc l'ampleur de l'ecart entre biomes. A la force 0 toute l'eau est
// sur WCOL4_T_BASE -- la correction de realisme s'applique encore, seule la
// variation par biome s'arrete.
// SECURITE : BIOME_CLIMATE a 0, ou l'uniforme rejete (biomeOkW() = 0), rend les
// trois poids litteralement nuls -> t = WCOL4_T_BASE -> MID partout. C'est le
// defaut voulu ET un repli sur, jamais un "froid partout".
#define WCOL4_T_BASE 0.50
#define WCOL4_T_HUMID 0.30
#define WCOL4_T_HOT 0.06
#define WCOL4_T_COLD 0.50
// Derived master gate -- the SAME layering rule the pack already applies to V3
// on V2, and for the same reason. V4's deltas are measured FROM the V3 spectrum
// and its chroma anchors come out of the V3 single-scattering model; laid on the
// legacy V2 constants (WCOL_K_OUT (0.405, 0.176, 0.092) is a different medium
// entirely, and WCOL_UW_* are three staged chromas there instead of one) they
// would be arithmetic without a meaning. So V4 only exists on top of V3, and
// WATER_COLOR_V3 = 0 stays bit-identical to V2 exactly as EAU3 documents.
#if WCOL_V3 == 1 && WATER_COLOR_V4 == 1
    #define WCOL_V4 1
#else
    #define WCOL_V4 0
#endif
// LES FAMILLES IMMERGEES SUIVENT, ET CE N'EST PAS OPTIONNEL. La chroma vue de
// DEHORS passe de 192.0 a 172.3 deg au cran MID. Laisser WT_UWC (colonne vue
// depuis SOUS l'eau) et WT_GLASS (eau derriere une vitre et faces d'eau cullees,
// vues de DEHORS) a 192.0 rouvrirait un ecart dedans/dehors de 19.7 deg, soit
// PLUS que les 14.7 deg que EAU4 existe pour fermer -- et sur les sites de vitre
// il serait carrement incoherent, puisque leur ABSORPTION suit deja le biome.
// Aucune constante nouvelle n'est derivee pour autant : les trois familles sont
// la MEME chroma a leur luminance Rec.709 propre (regle EAU4/EAU8), et c'est
// verifie -- WT_DEEP x 0.357247 reproduit WT_UWC a 2.8e-5 pres, WT_DEEP x
// 0.876399 reproduit WT_GLASS a 1.7e-5 pres. Les ancres V4 sont donc mises a
// l'echelle de la meme facon : pas de deuxieme derivation, donc rien qui puisse
// deriver. Luminances historiques conservees a 1e-6 pres a TOUS les crans.
#define WCOL4_L_UWC 0.357247
#define WCOL4_L_GLASS 0.876399

// Strength of the swamp/mangrove murk (extra absorption + hue pull toward
// the vanilla biome tint). 1.0 = the legacy amount. V2 default 0.25 keeps
// a hint of murk without turning swamps into a different fluid.
// Read only when WATER_COLOR_V2 = 1.
#define WATER_TURBIDITY 0.25 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0]
// Block-light (torch/lava) contribution to the water veil, as a fraction of
// the legacy amount. 1.0 = legacy. Lower keeps torch-lit pools from going
// orange; 0.0 makes an unlit cave pool read as pure dark water.
// Read only when WATER_COLOR_V2 = 1.
#define WATER_TORCH_SCATTER 0.25 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0]
// Per-channel multipliers of the aWat absorption: raising a channel kills
// that channel FASTER with depth (shallow-water tint, channel by channel).
#define WATER_ABSORB_R 1.0 // [0.25 0.5 0.75 1.0 1.25 1.5 2.0 2.5 3.0]
#define WATER_ABSORB_G 1.0 // [0.25 0.5 0.75 1.0 1.25 1.5 2.0 2.5 3.0]
#define WATER_ABSORB_B 1.0 // [0.25 0.5 0.75 1.0 1.25 1.5 2.0 2.5 3.0]
// Multiplies the path-veil rate, i.e. how fast the floor dissolves: 0.288
// under the V2 column model (re-derived as ln(4)/0.399 = 3.474 blocks), 0.29
// in legacy. The two are within 0.7%, so this dial reads the same on both.
#define WATER_VEIL_DENSITY 1.0 // [0.5 0.65 0.8 0.9 1.0 1.15 1.3 1.6 2.0]
// Veil hold-off in blocks of path: the first WATER_VEIL_START blocks stay
// veil-free (absorption untouched). 0.0 = veil from the first millimetre.
#define WATER_VEIL_START 0.0 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0 3.0]
// Multiplies the GGX alpha of the sun glint (size/softness of the sparkle
// lobe; intensity stays on WATER_SUN_GLINT).
#define WATER_GLINT_SIZE 1.0 // [0.25 0.5 0.75 1.0 1.5 2.0 3.0 4.0]
// Sun-glint HDR ceiling. V2 clipped the lobe with min(spec, 40): MEASURED at
// the shipped alpha, the raw GGX peak is 218 at 10 blocks and 182 at 20, so the
// clip fires out to a half-angle of 0.58-0.61 deg while the lobe's OWN
// half-width is only 0.45-0.49 deg -- the entire visible core of every sparkle
// was flattened to the SAME radiance, which is why the sun path read as one
// smooth streak instead of a field of separate grains. Under WATER_COLOR_V3
// this is a SOFT knee (cap*x/(cap+x)) instead of a clip: strictly monotonic, so
// the per-facet brightness variation survives (a facet 0.1 deg off specular and
// one 0.5 deg off no longer return the same number) and the brightest grain
// lands slightly BELOW the old ceiling (34.8 instead of 40 at 20 blocks).
// HOW MUCH SURVIVES, over the pairs the clip genuinely flattened (raw >= 40,
// all of which V2 returned as exactly 40, i.e. 1.0x): peak / 40-level is
// 33.80/20.0 = 1.69x at the measured 10-block peak of 218 and 34.75/20.0 =
// 1.74x at raw 265. It is provably never brighter than the old clip either -
// cap*x/(cap+x) < min(x, cap) for every x > 0 - so it cannot add a firefly.
// Raise for harder, more contrasty sparkles; lower to calm the sea.
#define WATER_GLINT_KNEE 40.0 // [10.0 20.0 30.0 40.0 60.0 90.0 140.0]
// Scales the MID-ANGLE Fresnel damper (0.95 * this): mirror presence at
// medium view angles; the grazing mirror is untouched (damper fades to 1).
#define WATER_MIRROR_ANGLE 1.0 // [0.5 0.65 0.8 0.9 1.0 1.15 1.3 1.6 2.0]
// Weight of the refracted-sun forward-scatter glow at sunset (glowW).
#define WATER_SCATTER_SUNSET 1.0 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 2.0]

// ---- Submerged eye (composite1 UW paths) ----
// Per-channel multipliers of the shared submerged-column in-scatter chroma
// (slate 0.19/0.42/0.72 x 0.80, three sites factored into SCAT_UW_BASE).
#define UW_FOG_R 1.0 // [0.25 0.5 0.75 1.0 1.25 1.5 2.0 2.5 3.0]
#define UW_FOG_G 1.0 // [0.25 0.5 0.75 1.0 1.25 1.5 2.0 2.5 3.0]
#define UW_FOG_B 1.0 // [0.25 0.5 0.75 1.0 1.25 1.5 2.0 2.5 3.0]
// Residual DEPTH DESATURATION of the submerged fog chroma. V2 uses ONE chroma
// at every depth, which also dropped the saturation drain the old three-stage
// staging carried: at 12 blocks down and 20 blocks of view the delivered
// max/min channel ratio is 4.3 against legacy's 1.33, so deep water can read
// as a single very saturated wall. Raise this to drain the hue back toward
// neutral WITH DEPTH; Rec.709 luminance is preserved, so it never changes how
// bright the water is - it is the submerged twin of WATER_FOG_BLUE.
// 0.0 = the flat V2 chroma at every depth. Read only when WATER_COLOR_V2 = 1.
#define UW_FOG_DESAT 0.35 // [0.0 0.15 0.25 0.35 0.5 0.65 0.8 1.0]
// Luminance of the eye-submerged fog color (wfogC light drive).
#define UW_FOG_BRIGHT 1.0 // [0.25 0.4 0.6 0.8 1.0 1.25 1.5 2.0]
// DIVIDES the eye-submerged fog density: higher = longer sight underwater.
#define UW_CLARITY 1.0 // [0.5 0.75 1.0 1.25 1.5 2.0 2.5 3.0]
// Strength of the caustic light dancing on the floor while submerged.
#define UW_CAUSTIC_LIGHT 1.0 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 2.0]

// ---- Time-of-day color grade (composite5, post-tonemap) ----
// 4 periods with CONTINUOUS weights: day/night from sun height, the twilight
// band split into dawn vs dusk by the MC clock (worldTime 0 = sunrise,
// 6000 = noon, 12000 = sunset, 18000 = midnight). Per period: TEMP warm/cool
// shift (R vs B), SAT saturation, BRIGHT multiplier. Applied as DELTAS from
// neutral -> all-default sliders leave the pixel bit-identical.
// TC_ENABLE 0 compiles the whole grade out.
// ### FIGE PAR LA PASSE "MENUS2" - PLUS AUCUN CONTROLE EN JEU, VALEUR DEFINITIVE 1.
// Raison DOUBLE. (1) C'est l'interrupteur de compilation d'une CHAINE interne,
// pas un effet : "Etalonnage horaire ON/OFF" ne dit rien au createur. (2) Aux
// douze valeurs livrees ci-dessous (TEMP 0.0, SAT 1.0, BRIGHT 1.0 sur les quatre
// periodes) le grade est applique en DELTAS depuis le neutre, donc il est
// STRICTEMENT bit-identique a l'image sans grade : le basculer ne changeait
// litteralement aucun pixel. Il doit rester a 1 pour que les douze dials
// ci-dessous restent reglables a la main. Le "// [0 1]" est retire pour qu'Iris
// cesse de l'annoncer comme option.
#define TC_ENABLE 1 // FIGE : chaine d'etalonnage horaire toujours compilee
#define TC_DAWN_TEMP 0.0 // [-1.0 -0.6 -0.3 -0.15 0.0 0.15 0.3 0.6 1.0]
#define TC_DAWN_SAT 1.0 // [0.5 0.7 0.85 0.95 1.0 1.05 1.15 1.3 1.5]
#define TC_DAWN_BRIGHT 1.0 // [0.7 0.8 0.9 0.95 1.0 1.05 1.1 1.2 1.3]
#define TC_DAY_TEMP 0.0 // [-1.0 -0.6 -0.3 -0.15 0.0 0.15 0.3 0.6 1.0]
#define TC_DAY_SAT 1.0 // [0.5 0.7 0.85 0.95 1.0 1.05 1.15 1.3 1.5]
#define TC_DAY_BRIGHT 1.0 // [0.7 0.8 0.9 0.95 1.0 1.05 1.1 1.2 1.3]
#define TC_DUSK_TEMP 0.0 // [-1.0 -0.6 -0.3 -0.15 0.0 0.15 0.3 0.6 1.0]
#define TC_DUSK_SAT 1.0 // [0.5 0.7 0.85 0.95 1.0 1.05 1.15 1.3 1.5]
#define TC_DUSK_BRIGHT 1.0 // [0.7 0.8 0.9 0.95 1.0 1.05 1.1 1.2 1.3]
#define TC_NIGHT_TEMP 0.0 // [-1.0 -0.6 -0.3 -0.15 0.0 0.15 0.3 0.6 1.0]
#define TC_NIGHT_SAT 1.0 // [0.5 0.7 0.85 0.95 1.0 1.05 1.15 1.3 1.5]
#define TC_NIGHT_BRIGHT 1.0 // [0.7 0.8 0.9 0.95 1.0 1.05 1.1 1.2 1.3]

// ============ FIX MENU IRIS (warnings "unable to resolve") ============
// Iris ne reconnait un #define booleen comme OPTION que s'il apparait dans AU MOINS
// un #ifdef/#ifndef simple quelque part dans le pack. Les usages composes
// ("#if defined X && defined Y", "#elif defined X") n'enregistrent PAS l'usage.
// VL_BLOCKLIGHT / ACES_TONEMAP / PBR_REFLECTIONS / PBR_POM n'etaient utilises QUE
// dans de tels composes (composite1:1207/1250, composite5:1515, composite1:557,
// gbuffers_terrain:30/221) -> "Unable to resolve ... menu element" au chargement.
// Ces 4 blocs vides sont des NO-OPS de compilation (aucun code genere) dont le seul
// role est d'enregistrer l'usage aupres du scanner d'options d'Iris. REVERSIBLE :
// supprimer ce bloc restaure exactement l'etat precedent (warnings compris).
#ifdef VL_BLOCKLIGHT
#endif
#ifdef ACES_TONEMAP
#endif
#ifdef PBR_REFLECTIONS
#endif
#ifdef PBR_POM
#endif

// ============ PORTE DERIVEE : TERRAIN DIFFERE (PERF_DEFERRED, LOT C piece 2) ============
// Posee en FIN de fichier parce qu'elle depend de FULL_PATH_TRACE et VOXEL_GI,
// definis bien apres le bloc LOT C ou vit PERF_DEFERRED (doc complete la-bas).
// Consommee par gbuffers_terrain.fsh, deferred.fsh et deferred1.fsh UNIQUEMENT :
// un seul site de verite pour la condition, les trois fichiers ne peuvent pas
// diverger. Porte a VALEUR + commentaire, jamais au menu (regle "NE JAMAIS
// EXPOSER" de shaders.properties) : aucune vieille config ne peut l'epingler.
#if PERF_DEFERRED == 1 && !(FULL_PATH_TRACE == 1 && VOXEL_GI == 1)
#define VLX_DEFERRED_ACTIVE 1 // porte derivee - voir le bloc PERF_DEFERRED (LOT C piece 2)
#endif

// ============ PERF_CLOUD_REMARCH : SORTIE ANTICIPEE RAYON-SEUL DU RE-MARCH ============
// Site unique : le bloc "cumulus AUSSI DEVANT le terrain lointain" de
// composite1.fsh. Ce bloc re-marche volumetricClouds() en PLEINE resolution et
// a plein VC_SAMPLES sur les pixels de terrain / LOD DH, borne a la profondeur
// du terrain (le bake demi-res de prepare.fsh ne connait pas la profondeur : il
// tourne AVANT les gbuffers, donc les nuages derriere une montagne ne peuvent
// pas y etre coupes -- ce re-march est structurellement obligatoire).
//
// CE QUE LA PORTE FAIT (et ne fait PAS). Elle ne touche NI le nombre de pas, NI
// la resolution, NI le resultat : elle HISSE devant les taps de profondeur la
// part de la sortie anticipee de volumetricClouds() qui ne depend QUE du rayon.
// Prologue de lib/clouds.glsl (camY = cameraPosition.y, top = VC_BASE+VC_THICK) :
//     |dir.y| < 1e-3 et camY hors de [VC_BASE, top]      -> return 0
//     |dir.y| >= 1e-3 et max(ta, tb) <= 0                -> return 0
// avec ta = (VC_BASE-camY)/dir.y et tb = (top-camY)/dir.y. En resolvant les
// signes, ces deux cas se reduisent EXACTEMENT a :
//     camY <  VC_BASE : vide <=> dir.y <  1e-3
//     camY >  top     : vide <=> dir.y > -1e-3
//     camY dans le slab : jamais vide
// Aucun de ces trois cas ne fait intervenir maxDist : le test est donc valable
// AVANT de connaitre la profondeur du terrain, et un pixel qu'il ecarte aurait
// de toute facon recu vec4(0.0) -> mix(color, 0, 0) = color. SORTIE IDENTIQUE
// AU BIT, quelle que soit la scene ; seule la porte 0 restaure l'ORDRE des
// instructions d'origine (rollback verbatim prouve par hash SPIR-V).
//
// CE QUE CELA ECONOMISE, sur les pixels ecartes : les taps depthtex1 /
// dhDepthTex1 / depthtex0 / colortex2, le toView + length (distO), le memo
// getSkyBase, et l'entree dans le corps inline du march.
//
// POURQUOI CE N'EST PAS "UNIFIER LE RE-MARCH AVEC LE BAKE". Mesure prealable
// (modele geometrique exact + rendu ecran pondere, 1080p / FOV 70) : pour un
// oeil SOUS la base des cumulus, le re-march est vivant SI ET SEULEMENT SI le
// point de terrain touche est AU-DESSUS de VC_BASE (invariant verifie sur
// 12000 cas, 0 ecart). Sur un panorama d'overworld normal comme sur une scene
// fermee, cela fait 0.000 % de l'ecran : le re-march n'y coute QUE sa sortie
// anticipee, et il n'y a donc RIEN a unifier. Le march reel n'existe qu'avec
// l'oeil a hauteur de nuages (sommet > 210 : 63 % de l'ecran ; vol > 370 :
// 68 %). Chiffres complets dans le rapport de mission.
#define PERF_CLOUD_REMARCH 1 // sortie anticipee rayon-seul du re-march nuages devant terrain (0 = verbatim)

// ============ PERF_CAUSTIC_LOD : LE PIXEL DE CAUSTIQUE ============
// HORS MENU, memes regles que le LOT C (pas de liste // [..], commentaire
// apres la valeur pour le -Set du harnais). Sites : les trois sites caustiques
// de composite1.fsh (a travers l'eau, rivage, immerge). N'ENTRE PAS dans la
// marche VL ni dans lib/vl_halfres.glsl (vlCa4Vol y garde son cout).
//
// LA FACTURE, MESUREE (probes isolees compilees en SPIR-V, spirv-opt -O, puis
// comptage DYNAMIQUE : la boucle du ladder wave3Eval est emise ROULEE, donc le
// comptage statique sous-estime -- meme mise en garde que CALIBRATION V5 L
// dans lib/water.glsl, dont ce comptage reproduit les 199 ops/iteration) :
//     vlCa4Net (defauts, v6)         2166 ALU / pixel
//       dont 3 x vlCa5Slope          1785      (82.4 %)
//       dont 9 photons + mise forme   381      (17.6 %)
//     vlCa4Vol (1 pente, sans jacobien) 822
//     shadowVis1                        126 ALU + 1 tap shadowtex1
// Le poste est donc la PENTE, pas les photons : un LOD sur les 9 photons ne
// peut pas rendre plus de 17.6 % et est rejete d'entree.
//
// DEUX LEVIERS SUR LA PENTE ONT ETE MESURES ET REJETES. Les deux economisaient
// beaucoup ; aucun n'est invisible, a AUCUNE distance ou le terme existe encore.
// Protocole : terme v6 fini, convergence TAA (moyenne sur 16 tirages de dither),
// passe-bas a l'empreinte de pixel de la distance testee (d/771 bloc a 1080p /
// fov 70, le chiffre du pack lui-meme, CALIBRATION V5 A), 3 sites x 3 instants.
// La reference de "invisible" n'est PAS 1.0 : c'est la correlation entre deux
// tirages TAA independants du terme INCHANGE, soit +0.999 -- le plancher de
// bruit du terme.
//   (1) JACOBIEN A DISTANCE (3 evaluations de pente -> 1, M = identite, ce que
//       fait deja vlCa4Vol) : -60.2 % d'ALU (2166 -> 861). MAIS correlation
//       +0.883 a 0 bloc, maximum +0.954 vers 50-60 blocs, et elle REDESCEND
//       ensuite (+0.890 a 120) ; |delta|/rms jamais sous 36 % ; et le terme
//       ressort 4.6 % a 9.3 % PLUS CLAIR (vlCa4S0 est ajuste sur la
//       distribution AVEC jacobien), donc une marche d'exposition a la ligne
//       de coupe. La raison est structurelle, se lit dans le splat et a ete
//       MESUREE : le deplacement ajoute par le jacobien, |(M - I).o|/rad, est
//       EXACTEMENT INVARIANT en `soft` (o et rad sont tous deux en 1/sf), a
//       1.533 rayons de splat rms, alors que la deviation |d0|/rad decroit avec
//       `soft` -- 3.426 / 2.741 / 2.056 / 1.713 / 1.370 / 1.199 a soft 1.00 /
//       0.80 / 0.60 / 0.50 / 0.40 / 0.35. Leur rapport monte donc de 0.45 a
//       1.28 : quand le defocus de distance est grand ouvert, le jacobien est
//       le terme DOMINANT, pas le terme negligeable. Un LOD de jacobien au loin
//       est a l'envers. REJETE.
//   (2) CA5_OCT 4 -> 2 A DISTANCE : -40.7 % d'ALU (2166 -> 1284). Correlation
//       +0.23 (proche) a +0.43 (150 blocs) contre +0.999, et |delta|/rms ~200 %
//       : ce n'est pas "moins de detail", c'est UNE AUTRE MER. La deviation d0
//       est la SOMME des pentes de tous les barreaux ; retirer les barreaux 2-3
//       (pas 1.98 et 0.99 bloc, correlations +0.445 et +0.212 avec la mer
//       visible, CALIBRATION V5 M) deplace le paquet de photons partout.
//       CA5_OCT 3 ne monte qu'a +0.70. Le critere d'empreinte de pixel dit la
//       meme chose : le barreau le plus fin que CA5_OCT 4 porte a un pas de
//       0.99 bloc, qui ne passe sous 2 empreintes qu'a 0.99*771/2 = 382 blocs,
//       soit 2.5x au-dela de la coupe dure a 150 blocs du terme lui-meme. Il
//       n'existe donc AUCUNE distance de coupe qui satisfasse le critere.
//       (Et le contrat de REGISTRATION -- les faisceaux volumetriques doivent
//       tomber sur les taches qu'ils eclairent -- serait viole en prime, la
//       marche VL gardant CA5_OCT 4.) REJETE.
//
// CE QUE LA PORTE LIVRE, les deux leviers qui ne coutent RIEN a l'image :
//  A. LE TAP D'OMBRE PASSE DEVANT LE CHAMP (les 3 sites, arms CAUSTIC_FACING
//     1 et 0). Le tap shadowVis1 etait pris a l'INTERIEUR de la branche qui
//     avait deja paye les 2166 ALU : un fond entierement a l'ombre payait tout
//     puis multipliait par zero (mix(vec3(1.0), X fini, 0.0) == vec3(1.0), et
//     color *= vec3(1.0) est exact). La porte replie le tap DANS le masque de
//     sortie anticipee. Le NOMBRE de taps ne change pas (le tap reste sous le
//     meme predicat caW > 0.004) ; seul l'ordre change. shadowVis1 renvoie
//     step(), donc 0.0 ou 1.0 exactement : caW * 1.0 == caW au bit pres et
//     caW * 0.0 == 0.0, le second test est donc exactement "shadowVis1 != 0".
//     SORTIE IDENTIQUE AU BIT, quelle que soit la scene. GAIN : 2166 ALU sur
//     2292, soit -94.5 % du pixel, sur CHAQUE pixel de caustique a l'ombre ;
//     0 ailleurs. Part d'ecran (densite h/s^2 : la part des pixels du plan
//     au-dela de s vaut s_min/s, modele du LOT C qui redonne ses 3 % / 17 %) :
//     nulle en pleine mer a midi, et -- oeil DANS l'ombre, le cas "je lagge en
//     regardant l'ocean" d'une plage au pied d'une falaise -- une paroi de
//     12 blocs au-dessus d'un fond a 4 blocs porte son ombre a 44 blocs au
//     soleil de 20 deg, soit 95 % des pixels de caustique vus de la plage
//     (s_min 3) et 73 % vus de la falaise (s_min 15). Rien n'est approxime :
//     le gain est 100 % du champ la ou il y a de l'ombre, 0 ailleurs.
//     LE SITE RIVAGE N'A PAS DE TAP et n'en recoit pas : sa detection d'ombre
//     coloree (shadowcolor0) EST son test d'ombre, elle est deja devant le
//     champ, et shadowVis1 y serait un second test faux (le fragment est SEC).
//  B. COUPE DE DISTANCE DU SITE IMMERGE (isEyeInWater == 1), qui n'en avait
//     AUCUNE : les deux sites oeil-sec coupent a 150 blocs (PERF_OCEAN), le
//     site immerge payait le champ complet jusqu'au bout du rendu. Sous l'eau
//     la visibilite est courte : le brouillard est exp2(-0.040*d) (WCOL_UW_DENS,
//     densite PLATE), donc a 50 blocs il ne reste que 25.0 % de la couleur du
//     fond et a 64 blocs 17.0 %. Fondu du POIDS sur 50 -> 64, puis zero
//     evaluation. LES DEUX BORNES SONT ANCREES, pas choisies : 50 est la ou
//     soft4U (16 -> 50) a fini de s'elargir, donc aucune seconde loi de
//     distance ne se superpose a la premiere (l'argument de CALIBRATION V5 E) ;
//     64 est la distance ou le poids caustique immerge du pack LUI-MEME atteint
//     deja exactement zero en v3 (caDistU = 1 - smoothstep(28, 64, dist)). A
//     CAUSTICS_V4 == 0 && CAUSTIC_BLUR_FADE == 0 la coupe est donc un pur
//     PORTAIL aligne sur ce zero -> rendu IDENTIQUE AU BIT, exactement comme le
//     caCut4 du site a-travers-l'eau. Amplitude residuelle supprimee, mesuree :
//     <= 2.8 % rms du pixel dans la bande de fondu, <= 1.8 % a la coupe.
//     PART D'ECRAN (densite h/s^2, oeil immerge) : 4.7 % des pixels du fond
//     depuis 2 blocs au-dessus (s_min 3), 23.4 % depuis 10 blocs (s_min 15) --
//     et c'est la vue "je nage au-dessus d'un tombant".
// ECARTS ASSUMES : (B) supprime les caustiques immergees au-dela de 64 blocs
// meme a UW_CLARITY 3.0 / WATER_FOG_DENSITY 0.1 (eau artificiellement claire) ;
// la coupe honore CAUSTIC_DIST_FADE 0.0 ("pas de fondu de distance") en ne
// coupant rien, comme les deux autres sites.
#define PERF_CAUSTIC_LOD 1 // tap d'ombre devant le champ caustique + coupe de distance du site immerge (0 = verbatim)

// ================= CAUSTIC_DEPTH_BLUR_V4 =================
// "Les caustiques sont plus floues plus c'est profond, comme l'ombre qui
// devient plus floue plus elle est loin." L'analogue PCSS de la penombre,
// applique a la PROFONDEUR D'EAU au lieu de la distance de vue.
//
// LE NOM. Ce bloc s'appelle CAUSTIC_DEPTH_BLUR_V4 et PAS "CAUSTIC_DEPTH_BLUR"
// PARCE QUE CE SYMBOLE EST DEJA PRIS : ligne 3572 de ce fichier,
// "#define CAUSTIC_DEPTH_BLUR 3.0 // [1.0 ... 24.0]" est un CRAN DE MENU vivant
// qui pilote deja le flou de profondeur du bras LEGACY v3, via
// causticDepthBlur() dans lib/water.glsl :
//     clamp((depthM - 2.5) / max(CAUSTIC_DEPTH_BLUR * 4.0, 8.0), 0.0, 1.0)
// Le redefinir en porte 0/1 ne serait pas une collision de nom benigne : a 1 le
// denominateur tomberait de max(12,8)=12 a max(4,8)=8, donc le flou legacy de
// TOUT LE MONDE deviendrait 1.5x plus rapide en profondeur, et a 0 idem (8).
// D'ou le suffixe. CONSEQUENCE UTILE, ET C'EST LE DIAGNOSTIC DE LA DEMANDE :
// le bras LEGACY v3 A DEJA ce flou de profondeur depuis toujours -- c'est
// exactement ce que fait causticDepthBlur -- et le chemin PAR DEFAUT
// (CAUSTIC_QUALITY 2 -> CAUSTICS_V4/V5/V6 = 1, le filet de densite de photons)
// n'en avait AUCUN : son seul `soft` etait f(distance de vue). Le joueur qui
// dit "elles ne floutent pas avec la profondeur" est sur le chemin v4/v6.
// Ce bloc ne fait donc que donner au filet de photons l'effet que le bras
// analytique avait deja, et rien d'autre.
//
// LA PHYSIQUE, ET POURQUOI d_ref N'EST PAS LE DISQUE SOLAIRE. L'elargissement
// de l'empreinte d'un photon avec la profondeur d a deux sources :
//   (a) le disque solaire, 0.53 deg = 0.00925 rad dans l'air, donc 0.00694 rad
//       DANS L'EAU (Snell, n = 1.3333) -- la meme demi-largeur angulaire que le
//       PCSS du pack utilise pour la penombre ;
//   (b) la diffusion multiple du milieu, dont le lobe avant fait quelques
//       degres (fonction de phase de type Petzold).
// Elles s'ajoutent en quadrature avec la largeur intrinseque r0 = CA4_PRAD =
// 0.1439 bloc, ce qui donne exactement la forme livree ci-dessous :
//     r(d) = r0 * sqrt(1 + (d / d_ref)^2)
// (a) SEUL donnerait d_ref = r0 / 0.00694 = 20.7 blocs, soit x1.11 a 10 blocs :
// INVISIBLE. C'est (b) qui domine, et CDB_DREF 2.8 correspond a une demi-
// largeur effective de 0.1439/2.8 = 0.051 rad = 2.9 deg, ce qui EST le lobe
// avant d'une eau naturelle. Le disque solaire est donc cite comme le
// mecanisme jumeau du PCSS, pas comme la source du chiffre livre.
// CIBLES DEMANDEES ET ATTEINTES, largeur d'empreinte a CDB_DREF 2.8 :
//     1 bloc x1.06 (quasi net) | 4 blocs x1.74 | 10 blocs x3.71
//
// LE LEVIER, ET POURQUOI IL N'Y EN A QU'UN. vlCa4Net a deja le parametre exact :
// `soft` elargit ENSEMBLE le disque de splat (CA4_PRAD/sf) et l'espacement des
// photons (CA4_PSPACE/sf), rapport conserve -- une vraie defocalisation, pas un
// fondu alpha. Et comme r ~ 1/soft, la loi ci-dessus s'ecrit d'un seul coup :
//     soft_profondeur = inversesqrt(1 + (d / CDB_DREF)^2)
// puis soft_total = soft_vue * soft_profondeur. AUCUNE nouvelle machinerie de
// filtrage : le flou passe par le levier calibre du pack.
//
// LA BAISSE DE CONTRASTE VIENT AVEC, ET ELLE EST MESUREE. Elargir l'empreinte
// baisse `de` (la deflexion exprimee en rayons de splat), donc aplatit le
// terme. Profil p99.9/mediane mesure sur le port numpy du filet v6 (6 patchs de
// 12x12 blocs, 12 tirages de dither, mer WAVES_V3, soleil au zenith), soft_vue
// = 1 :
//     profondeur   0.5     1      2      4      8     12
//     AVANT       6.741  6.741  6.741  6.741  6.741  6.741   (aucune dependance)
//     APRES       6.478  5.801  4.216  2.462  1.668  1.470
// L'ELARGISSEMENT SEUL SATURE A 2.0 ET C'EST POURQUOI CDB_CSTR EXISTE : quand
// rad depasse la deflexion, u = |M o + d0|^2 / rad^2 -> |M o_normalise|^2, donc
// le terme converge vers le motif du JACOBIEN, pas vers 1.0 -- contraste 1.89,
// mesure, jamais moins. Une eau de 12 blocs garderait une modulation 1.9:1
// visible. Le fondu de contraste explicite k(d) ci-dessous continue la ou
// l'elargissement s'arrete, et il est PHYSIQUE dans le meme sens : il tire le
// terme vers 1.0, c'est-a-dire vers "plus de caustique du tout", ce qui est
// l'etat d'une eau assez profonde.
//
// L'EXPOSITION. C'est la seule chose que ce bloc devait garantir et elle a
// coute une mesure. Le terme est centre sur 1 par construction (vlCa6Mean
// normalise la moyenne a chaque `de`) MAIS SEULEMENT AU RESIDU DE FIT PRES, et
// ce residu marche le long de l'axe `soft` : moyenne mesuree 0.9942 a soft 1,
// 0.9373 a soft 0.5, 1.0034 a soft 0.05, soit une derive d'ensemble de -4.7 %.
// SANS CORRECTION, la lame de fond serait un assombrissement progressif du sol
// avec la profondeur -- exactement le defaut que la demande interdit.
// CE N'EST PAS UN DEFAUT QUE CE BLOC INTRODUIT : le fondu de distance DEJA
// LIVRE (soft4 : 1.00 -> 0.35 sur 30->110 blocs) porte la MEME derive sur le
// MEME axe, mesuree -4.4 % d'ensemble et -9.2 % au pire patch. Le bloc ne la
// corrige donc pas dans l'absolu (ce serait changer le rendu livre a
// profondeur nulle) : il corrige EXACTEMENT ce que lui-meme ajoute, par le
// RAPPORT rho(soft_vue)/rho(soft_total). A profondeur nulle soft_total ==
// soft_vue, le rapport vaut 1.0 exactement, et le pixel est le pixel d'avant.
// rho EST MESUREE, pas choisie : moyenne d'ensemble du terme sur 10 patchs
// aleatoires x 16 valeurs de soft, normalisee a soft 1, puis ajustee par un
// polynome de degre 3 (3 FMA, ni sqrt ni division). Erreur max du RAPPORT sur
// toutes les paires (soft_vue, soft_total) : 0.70 %, rms 0.26 %.
// RESULTAT MESURE, derive de la moyenne APRES/AVANT :
//     soft_vue 1.00 (pres) : +0.05 / +0.17 / +0.33 / +0.07 / -0.12 / -0.06 %
//     soft_vue 0.35 (loin) : +0.03 / +0.13 / +0.45 / +1.15 / +1.84 / +2.11 %
// aux six profondeurs du tableau. Le pire, +2.11 %, n'existe qu'au-dela de 110
// blocs de distance de vue ET il va DANS LE BON SENS : le terme livre y est
// 4.1 % SOUS la moyenne exacte 1.0, et le fondu de contraste l'y ramene. La
// dispersion PAR PATCH reste +-9.5 % au pire, inchangee en amplitude par
// rapport aux -9.2 % que le fondu de distance livre deja : c'est le residu de
// fit de vlCa6Mean, il depend des statistiques locales du champ et aucune
// fonction de `soft` ne peut l'atteindre. Dit, pas cache.
//
// CE QUE CE BLOC NE TOUCHE PAS. (1) Les faisceaux volumetriques immerges
// (vlCa4Vol, marche VL) : le contrat d'enregistrement dit qu'un faisceau et la
// tache qu'il eclaire sont le meme filament a la meme position monde, et il
// tient toujours -- flouter la tache au SOL ne deplace pas le filament, ca
// elargit son empreinte a l'arrivee. Physiquement le faisceau devrait lui aussi
// s'elargir le long du trajet ; ce n'est pas fait ici (la marche VL est hors
// perimetre) et c'est un ecart assume, invisible tant que le faisceau est vu de
// cote et non en enfilade. (2) Le bras legacy v3, qui a deja son propre flou de
// profondeur (voir LE NOM ci-dessus). (3) CAUSTIC_FACING, PERF_CAUSTIC_LOD,
// CAUSTIC_DIST_FADE, CAUSTIC_SHALLOW_FADE : composes, pas defaits -- le bloc
// n'agit que sur l'argument `soft` et sur le gain final du terme.
//
// 0 = verbatim : vlCaNetD() se reduit textuellement a l'appel vlCa4Net()
// d'origine aux six sites (verifie au SPIR-V, binaire identique).
#define CAUSTIC_DEPTH_BLUR_V4 1 // flou des caustiques par PROFONDEUR D'EAU sur le filet de photons (0 = verbatim)

// Profondeur de reference de la loi r(d) = r0*sqrt(1 + (d/CDB_DREF)^2), en
// blocs. 2.8 = les trois cibles demandees a la fois (x1.06 / x1.74 / x3.71 a
// 1 / 4 / 10 blocs) et un lobe avant de diffusion de 2.9 deg. Plus petit =
// flou plus tot.
#define CDB_DREF 2.8
// Plancher du facteur de profondeur : l'elargissement sature a x1/0.20 = x5,
// atteint vers 13.7 blocs de colonne. Au-dela c'est CDB_CSTR qui continue.
// Borne aussi le domaine ou rho a ete mesuree (soft_total >= 0.35*0.20 = 0.07).
#define CDB_SMIN 0.20
// Force du fondu de contraste k = mix(1, sqrt(soft_profondeur), CDB_CSTR).
// 0.0 = elargissement seul (contraste plancher 2.0 en eau profonde) ;
// 1.0 = livre (1.47 a 12 blocs).
#define CDB_CSTR 1.0
// rho(s) = ((E3*s + E2)*s + E1)*s + E0 : moyenne d'ensemble MESUREE du terme a
// `soft` = s, normalisee a s = 1. Seul son RAPPORT est lu, donc la constante
// globale est libre. Domaine de mesure s dans [0.055, 1.0], borne par le clamp
// du site. Voir "L'EXPOSITION" ci-dessus.
// L'ARGUMENT EST CA4_STEEP * CA4_SHARP * soft, pas soft : c'est de/1.60, la
// variable sur laquelle rho a ete balayee. Les deux crans valent 1.0 par
// defaut, donc le produit se replie a 1.0 et le chemin par defaut est
// inchange au bit ; aux coins du menu il divise par deux la derive
// d'exposition (6.56 % -> 3.51 % au pire, table dans lib/water.glsl).
#define CDB_E0  1.0371491
#define CDB_E1 -0.3772981
#define CDB_E2  0.4932031
#define CDB_E3 -0.1516255

// ===================== WATER_FOG_HUE =====================
// "L'eau devient une espece de MAUVE avec le brouillard -- reduire cet effet."
// TOUT CE BLOC EST UNE MESURE. Port numpy de getSkyBase / getLightColor /
// getAmbientColor / waterSkyTint / waterColumn / la chaine reflW / farCol /
// les deux voiles (VL, ATMO_FOG), evalue sur 1485 echantillons
// hauteur-de-soleil x densite-de-brouillard x azimut x distance.
// INDICE DE VIOLET utilise partout ci-dessous : min(R,B)/G - 1, borne a 0.
// C'est la DEFINITION du mauve donnee dans la demande -- "rouge + bleu sans
// vert" -- et pas la teinte HSV, qui compte un bleu pur comme violet et ne
// separe donc pas les deux cas. 0 = le vert n'est pas dans le creux.
//
// ---- CE QUI A ETE MESURE, ET DANS QUEL ORDRE ------------------------------
// (1) LA CAUSE RACINE N'EST PAS DANS L'EAU. lib/sky.glsl, la bande de
//     crepuscule : sky = mix(sky, vec3(1.0, 0.34, 0.09), duskF*sunAmt*horiz*1.45).
//     C'est un mix RGB entre un ciel BLEU et un rouge SATURE, et tout poids
//     intermediaire passe par le magenta -- c'est une propriete de
//     l'interpolation, pas un reglage. getSkyBase SEUL, sans eau et sans
//     brouillard, a l'horizon, soleil a -0.05 :
//         azimut     90     105     110     120     135     180
//         teinte    9.2   347.2   326.5   259.2   231.1   227.1
//         violet  0.000   0.186   0.369   0.235   0.000   0.000
//     Le pic est a ~110 deg du soleil, ou le poids de la bande vaut 0.039 :
//     assez pour injecter du rouge, trop peu pour emporter le bleu. LE CIEL
//     LUI-MEME EST MAUVE LA, avant toute ligne de code d'eau.
//     Hors perimetre de ce bloc (lib/sky.glsl). Correctif d'une ligne pour qui
//     l'aura : interpoler la bande en teinte/luminance, ou passer par un point
//     intermediaire orange (~vec3(1.0, 0.55, 0.20)) au lieu d'aller droit du
//     bleu au rouge.
// (2) POURQUOI L'EAU LE MONTRE PLUS QUE LE CIEL. Passe ~90 blocs
//     PERF_WATER_FAR_SIMPLE possede le pixel et reflW est epingle a 0.98 : le
//     pixel d'eau EST le ciel reflechi a 98 %, sur une grande surface unie
//     juste devant le joueur, la ou le ciel lui-meme n'est qu'une bande sombre.
//     Puis les deux voiles (VL et ATMO_FOG, appliques APRES la branche eau)
//     ajoutent leur propre chroma : au pire cas mesure (soleil -0.05, azimut
//     110, 150 blocs) le terme ATMO_FOG porte lui-meme un violet de 0.356
//     parce qu'il est proportionnel a ce meme ciel, et l'in-scatter VL est
//     CHAUD (teinte 7.4 deg, pilote par gAmbC dont le crepuscule reste
//     vec3(0.85,0.55,0.40) alors que gLightC est deja passe au bleu lunaire).
//     C'est le "avec le brouillard" de la demande : le brouillard ne cree pas
//     le mauve, il l'amene au-dessus du seuil visible.
// (3) CE QUE L'EAU AJOUTE VRAIMENT, ET QUI EST REPARABLE ICI. waterSkyTint()
//     tourne le ciel reflechi de +16.5 deg VERS le violet, A TOUTE HEURE :
//     son axe cible WST_TARGET = (+0.237, -0.167, +0.957) est rouge-POSITIF et
//     vert-NEGATIF. Mesure a l'oppose du soleil (azimut 180), 150 blocs :
//         ciel brut      0.0345 0.0477 0.0799  teinte 222.5  violet 0.000
//         apres WST      0.0449 0.0454 0.0727  teinte 239.0  violet 0.000
//     Le rouge monte de +30 % et le vert descend de 5 %. Le ciel n'est PAS
//     mauve la (violet 0.000) et l'eau non plus encore -- mais la MARGE DE
//     VERT qui protege le pixel est passee de R/G 0.708 a R/G 0.989 : WST en a
//     mange 96 %. Le voile chaud qui suit fait alors basculer R au-dessus de G
//     et le pixel final sort a 248.9 deg. C'EST LE SEUL ENDROIT OU L'EAU REND
//     MAUVE UN CIEL QUI NE L'EST PAS, et c'est le premier des deux correctifs.
//     POURQUOI PERSONNE NE L'AVAIT VU : WST a bien une porte de luminance,
//     (1 - smoothstep(WST_HI0, WST_HI1, Y)) avec WST_HI0 = 1.5 -- calibree pour
//     le DISQUE SOLAIRE reflechi (Y ~ 30). La luminance d'un ciel de
//     crepuscule vaut 0.021 a 0.047. Mesuree sur toute la grille, la porte
//     totale de WST vaut EXACTEMENT 1.0000 a midi comme a la nuit tombee. Il
//     manquait la moitie basse.
//
// ---- CE QUI EST LIVRE ------------------------------------------------------
// (A) STAND-DOWN BASSE LUMINANCE de waterSkyTint (lib/water_sky_tint.glsl) :
//     w *= smoothstep(WFH_LO0, WFH_LO1, Y). Bornes prises sur la mesure, pas
//     choisies -- luminance du ciel reflechi : 0.883 a midi, 0.883 l'apres-midi,
//     0.538 a 7 deg d'elevation, 0.045 au crepuscule. 0.06 -> 0.30 laisse donc
//     un facteur 9 de marge au-dessus du jour et un facteur 1.3 sous le
//     crepuscule. Porte mesuree : 1.000 pour toute hauteur de soleil >= 0.08
//     (NO-OP EXACT, verifie a 1.7e-16 de changement relatif), 0.86 a sh 0.05,
//     0.26 a sh 0.02, 0.000 des sh <= -0.02. La transition dure les dernieres
//     minutes du coucher et suit la LUMINANCE PAR DIRECTION, donc la bande de
//     coucher elle-meme (lumineuse) garde son traitement pendant que le ciel
//     oppose (sombre) le perd.
// (B) GARDE DU CREUX VERT sur la sortie de la branche eau (composite1.fsh,
//     vlxWaterHueGuard) : remonte G vers min(R,B) de WFH_NOTCH, A LUMINANCE
//     Rec.709 CONSTANTE (renormalisation exacte, dLuma mesure 0.00 %).
//     ELLE S'AUTO-DESACTIVE : quand G >= min(R,B) -- c'est-a-dire quand le
//     pixel n'est pas dans le coin magenta -- le max() la rend rigoureusement
//     identite. Mesure : 0 echantillon touche pour sh >= 0.30, 15 sur 540 a
//     sh 0.15 (soleil a 8.6 deg, heure doree) avec un creux de 0.8 a 3.2 %,
//     306 sur 810 au crepuscule avec un creux jusqu'a 30.9 %. Elle ne connait
//     donc ni l'heure ni le brouillard : elle ne connait que le defaut.
// RESULTAT MESURE sur les 1485 echantillons, (A)+(B) :
//     violet moyen  0.0269 -> 0.0183  (-32 %)
//     pire cas mesure isolement (sh -0.05, az 110, 150 blocs) :
//         teinte 336.3 -> 353.3 deg, violet 0.219 -> 0.037  (-83 %)
//     a l'oppose du coucher (az 150/180, 150 blocs, le cas courant) :
//         teinte 248.9 -> 239.5 deg, violet 0.058 -> 0.000  (-100 %)
// EXPOSITION : (B) est neutre par construction. (A) ne l'est pas tout a fait,
// et c'est mesure et assume : les deux max() par canal en aval (le plancher
// anti-noir WATER_HORIZON_SKY et ssrLocalAmb) ne conservent pas la luminance,
// donc changer la chroma en amont la bouge un peu. |dLuma| moyen 0.095 %,
// 57 echantillons sur 1485 au-dessus de 1 %, 19 au-dessus de 2 %, maximum
// 2.87 % -- tous au crepuscule profond a l'oppose du soleil, sur des pixels
// dont la luminance vaut 0.021 a 0.047. En plein jour c'est 0 au bit.
// CE QUI RESTE, ET POURQUOI. Le violet maximal de la grille ne tombe que de
// 0.303 a 0.291 : il vit a ~110 deg du soleil ou le CIEL fait deja 0.369 tout
// seul (1) et ou les deux voiles hors branche (2) le reinjectent apres la
// garde. Aucun correctif cote eau ne peut y aller. La cause est nommee en (1)
// avec son correctif d'une ligne.
//
// 0 = verbatim : (A) et (B) disparaissent tous les deux du flux de jetons.
#define WATER_FOG_HUE 1 // corrige la derive mauve du pixel d'eau au crepuscule / sous brouillard (0 = verbatim)

// Bornes du stand-down (A), en luminance Rec.709 du ciel reflechi. Voir la
// table de luminances ci-dessus : 9x de marge au-dessus du jour.
#define WFH_LO0 0.06
#define WFH_LO1 0.30
// Force de la garde (B). 1.0 = le creux magenta est entierement comble ;
// 0.0 = garde inerte. Mesure a 0.5 : violet moyen 0.0211 au lieu de 0.0183.
#define WFH_NOTCH 1.0
