/* VertaLux - COLORED LIGHTS PALETTE: THE single id -> color table for every
   emissive block family (block.properties ids). This file exists because the
   old voxel radiance was col.rgb (texture albedo) * family tint: the AVERAGE
   texture color polluted the light (a torch is mostly BROWN stick, a lantern
   mostly dark metal frame), the non-atomic voxel write races made the winning
   texel - and so the HUE - change frame to frame, and animated textures
   (fire/lava/sea lantern) modulated the tint. Fix (creator request "une couleur
   a chaque bloc de lumiere"): the CAST light color is now a FIXED, clean color
   per block TYPE, defined HERE and nowhere else.

   CONSUMERS (keep this the only table - never re-inline a per-family chain):
     - shadow.fsh (voxelization): clLightColor() is the radiance written into
       the voxel grid, i.e. the color a block's LIGHT casts through the LPV
       chain (composite.csh injection -> composite_a..d flood -> forward bridge
       sampleLPVForward in lib/lighting.glsl) and through the dormant PT paths.
       Intensity is NOT decided here: the vanilla lightmap keeps driving the
       falloff/range on screen (CL_TINT_MIX swaps TINT only), and the
       texture-luma mask eMask (with clMaskFloor below) keeps state-dependent
       blocks honest - an unlit redstone lamp / copper bulb, bare cave vines or
       an idle sculk sensor read as dark texels and emit ~0.
     - gbuffers_terrain.fsh (on-screen glow): clScreenTint() styles the visible
       HDR boost of the emissive TEXTURE itself (multiplies albedo, so the
       flame keeps its texture detail). Same family keys, tuned separately: it
       is a look multiplier (values may exceed 1), not a light color. It
       replaces the old duplicated eTint chain whose "keep in sync with
       shadow.fsh" comment contract this file retires.
     - clMaskFloor(): the per-family eMask floor shared by BOTH files above
       (dark textures that must still emit: lava crust, redstone torch head,
       full metal blocks).

   Families (block.properties): 17 verdant green, 18 pale violet, 19 amber,
   20 warm orange, 21 lava, 22 soul, 23 cold white, 24 amethyst cluster,
   26 redstone torch, 27 redstone block, 28 emerald, 29 diamond,
   31..38 optional metal blocks (toggle-gated at the caller, not here: the
   functions just answer for the id they are given).

   GLSL 120-safe on purpose (plain if/else chains). Only dependency: TORCH_R/G/B
   from lib/settings.glsl, which BOTH consumers include before this file. No
   #define here beyond the include guard (Iris parses bare top-of-line defines
   as options). */
#ifndef CL_COLORS_GLSL
#define CL_COLORS_GLSL

// Fixed LIGHT color per family (linear RGB radiance, max channel ~1.0 so the
// CL_TINT_MIX luma normalization in lib/lighting.glsl stays well conditioned).
// Family 20 equals the getTorchColor() hue BY CONSTRUCTION: it multiplies the
// same TORCH_R/G/B dials (lib/settings.glsl) as getTorchColor() itself
// (lib/lighting.glsl), so outside the LPV range the fallback matches the field
// color WHATEVER the dials say - no visible seam even off the defaults (the
// dials stay registered by Iris through a value-listed bare #define, so a .txt
// can move them without the option being on any screen). Red families have a low
// luma by nature: the flood (max-by-luma) keeps them local, which matches
// vanilla (redstone light level 7 vs torch 14) - do not "fix" it by boosting.
vec3 clLightColor(float id) {
    vec3 c = vec3(1.00 * TORCH_R, 0.52 * TORCH_G, 0.18 * TORCH_B); // 20 warm orange: torch, lantern, jack o'lantern, campfire, fire, redstone lamp, copper bulb (lit), magma
    if      (id > 16.5 && id < 17.5) c = vec3(0.45, 1.00, 0.50); // 17 verdant green: verdant froglight, glow lichen
    else if (id > 17.5 && id < 18.5) c = vec3(0.80, 0.60, 1.00); // 18 pale violet: end rod, pearlescent froglight
    else if (id > 18.5 && id < 19.5) c = vec3(1.00, 0.72, 0.25); // 19 amber: glowstone, shroomlight, ochre froglight, cave vines
    else if (id > 20.5 && id < 21.5) c = vec3(1.00, 0.40, 0.08); // 21 lava: deep red-orange
    else if (id > 21.5 && id < 22.5) c = vec3(0.35, 0.75, 1.00); // 22 soul blue-cyan: soul torch/lantern/fire, sculk
    else if (id > 22.5 && id < 23.5) c = vec3(0.85, 0.95, 1.00); // 23 cold white: sea lantern, conduit, beacon
    else if (id > 23.5 && id < 24.5) c = vec3(0.75, 0.45, 1.00); // 24 amethyst cluster: violet
    else if (id > 25.5 && id < 26.5) c = vec3(1.00, 0.12, 0.06); // 26 redstone torch: red
    else if (id > 26.5 && id < 27.5) c = vec3(1.00, 0.14, 0.08); // 27 redstone block: red
    else if (id > 27.5 && id < 28.5) c = vec3(0.15, 1.00, 0.35); // 28 emerald block: green
    else if (id > 28.5 && id < 29.5) c = vec3(0.30, 0.85, 1.00); // 29 diamond block: cyan
    else if (id > 30.5 && id < 31.5) c = vec3(1.00, 0.75, 0.30); // 31 gold block: warm gold
    else if (id > 31.5 && id < 32.5) c = vec3(0.90, 0.92, 0.95); // 32 iron block: neutral white
    else if (id > 32.5 && id < 33.5) c = vec3(0.65, 0.45, 0.85); // 33 netherite block: dark violet
    else if (id > 33.5 && id < 34.5) c = vec3(0.80, 0.45, 1.00); // 34 amethyst block: violet
    else if (id > 34.5 && id < 35.5) c = vec3(1.00, 0.55, 0.28); // 35 copper block: copper orange
    else if (id > 35.5 && id < 36.5) c = vec3(0.85, 0.72, 0.55); // 36 raw iron: dull neutral
    else if (id > 36.5 && id < 37.5) c = vec3(1.00, 0.75, 0.35); // 37 raw gold: dull gold
    else if (id > 37.5 && id < 38.5) c = vec3(0.95, 0.55, 0.35); // 38 raw copper: dull orange
    return c;
}

// On-screen glow tint (gbuffers_terrain emissive boost, multiplies albedo).
// Values 20..38 are byte-identical to the chain they replace - the visible
// look of every existing block is unchanged. 17/18/19 follow their light hue.
vec3 clScreenTint(float id) {
    vec3 c = vec3(1.25, 0.95, 0.62);                             // 20 warm gold
    if      (id > 16.5 && id < 17.5) c = vec3(0.55, 1.30, 0.65); // 17 verdant green
    else if (id > 17.5 && id < 18.5) c = vec3(1.05, 0.85, 1.35); // 18 pale violet
    else if (id > 18.5 && id < 19.5) c = vec3(1.30, 0.98, 0.52); // 19 amber (near the old warm gold: glowstone's look barely moves)
    else if (id > 20.5 && id < 21.5) c = vec3(1.40, 0.78, 0.38); // 21 lava
    else if (id > 21.5 && id < 22.5) c = vec3(0.35, 0.95, 1.50); // 22 soul cyan
    else if (id > 22.5 && id < 23.5) c = vec3(0.88, 1.02, 1.20); // 23 cold moonlight
    else if (id > 23.5 && id < 24.5) c = vec3(1.20, 0.62, 1.50); // 24 amethyst
    else if (id > 25.5 && id < 26.5) c = vec3(1.50, 0.15, 0.10); // 26 redstone torch
    else if (id > 26.5 && id < 27.5) c = vec3(1.45, 0.18, 0.14); // 27 redstone block
    else if (id > 27.5 && id < 28.5) c = vec3(0.20, 1.45, 0.45); // 28 emerald block
    else if (id > 28.5 && id < 29.5) c = vec3(0.35, 1.20, 1.45); // 29 diamond block
    else if (id > 30.5 && id < 31.5) c = vec3(1.35, 1.00, 0.45); // 31 gold block
    else if (id > 31.5 && id < 32.5) c = vec3(1.05, 1.08, 1.12); // 32 iron block
    else if (id > 32.5 && id < 33.5) c = vec3(0.85, 0.62, 1.05); // 33 netherite block
    else if (id > 33.5 && id < 34.5) c = vec3(1.10, 0.55, 1.45); // 34 amethyst block
    else if (id > 34.5 && id < 35.5) c = vec3(1.40, 0.70, 0.32); // 35 copper block
    else if (id > 35.5 && id < 36.5) c = vec3(1.05, 0.85, 0.62); // 36 raw iron
    else if (id > 36.5 && id < 37.5) c = vec3(1.20, 0.85, 0.42); // 37 raw gold
    else if (id > 37.5 && id < 38.5) c = vec3(1.25, 0.68, 0.45); // 38 raw copper
    return c;
}

// Shared eMask floor: minimum emission for families whose texture is too dark
// for the smoothstep(0.30, 0.80, luma) mask. Same values the two duplicated
// chains used to carry (lava 0.65 / redstone torch 0.70 / metal blocks 0.60,
// netherite 0.65). Families that rely on the mask for their unlit STATE
// (20 lamp/bulb/vines, 22 sculk) must stay at 0.0 - a floor would make the
// unlit variant glow. Family 26 is safe to floor ONLY because block.properties
// filters it by blockstate (:lit=true): the floor can never meet an OFF torch.
float clMaskFloor(float id) {
    float f = 0.0;
    if      (id > 20.5 && id < 21.5) f = 0.65; // 21 lava (animated dark crust)
    else if (id > 25.5 && id < 26.5) f = 0.70; // 26 redstone torch, lit-only (dark head -> real red light)
    else if (id > 32.5 && id < 33.5) f = 0.65; // 33 netherite block (darkest metal)
    else if (id > 30.5 && id < 38.5) f = 0.60; // 31..38 other metal blocks (mid-tone metal under-emits)
    return f;
}

#endif // CL_COLORS_GLSL
