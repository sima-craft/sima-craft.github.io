/*
    VertaLux - lighting engine.
    PCSS shadows (variable penumbra), colored shadows (stained glass), moving
    cloud shadows on terrain, sky ambient, blue cave minimum light, held light.
    Everything is computed in linear (HDR) space.
    Requires lib/common.glsl, lib/biome.glsl (biome climate weights used by
    getLightColor / getAmbientColor), lib/dimension.glsl (DIMENSION_FX Nether /
    End weights and palettes) and lib/distort.glsl to be included first.
    ATTRIBUTION: the colored-lights APPLICATION recipe (CL_V2/CL_V3 blocks here, in
    gbuffers_hand.fsh and gbuffers_textured*.fsh) is openly inspired by the
    colored-light chain of Complementary Reimagined (EminGT) - warm floor before a
    luminance normalization, 0.55-cell normal offset, hand/textured/terrain split.
    The legacy flood kernel (strided passes, lib/lpv_flood.glsl), the palette
    (lib/cl_colors.glsl), the temporal chain and the CL_V3 rebuild (vertex-side
    block-id voxelization + one-pass frame-parity diffusion, lib/settings.glsl
    MISSION CL_V3) are original to VertaLux.
*/

uniform sampler2D shadowtex0;
uniform sampler2D shadowtex1;
uniform sampler2D shadowcolor0;
#if SHADOW_V2 == 1
// Hardware depth-compare views of the SAME two depth maps (Iris feature flag
// SEPARATE_HARDWARE_SAMPLERS + const bool shadowHardwareFiltering0/1 in
// lib/settings.glsl): one shadow2D tap = a 2x2 bilinear PCF. shadowtex0/1
// above stay raw depth for the blocker search and every other reader.
uniform sampler2DShadow shadowtex0HW;
uniform sampler2DShadow shadowtex1HW;
// Frame index for the blue-noise slice of the Vogel-disc rotation. Guarded:
// composite.fsh / composite1.fsh / deferred.fsh / prepare.fsh declare the same
// uniform under this guard after including this file.
#ifndef VL_FRAMECOUNTER_DECL
#define VL_FRAMECOUNTER_DECL
uniform int frameCounter;
#endif
#endif
uniform mat4 shadowModelView;
uniform mat4 shadowProjection;
uniform mat4 gbufferModelViewInverse;
uniform vec3 shadowLightPosition;
uniform vec3 sunPosition;
uniform vec3 upPosition;
uniform vec3 cameraPosition;
uniform float rainStrength;
uniform float wetness;
uniform int moonPhase;
// worldTime / worldDay are declared in lib/common.glsl (always included BEFORE
// this file) for the cloudWorldTime() helper; they also drive the star dome
// rotation (sky.glsl) and sunrise/sunset selection below.
uniform float frameTimeCounter;
uniform int heldBlockLightValue;
uniform int heldBlockLightValue2; // offhand light source
// Guarded: lib/dimension.glsl declares the same uniform under this guard, so
// either include order compiles.
#ifndef VL_FOGCOLOR_DECL
#define VL_FOGCOLOR_DECL
uniform vec3 fogColor;
#endif

float sunHeight() {
    return dot(normalize(sunPosition), normalize(upPosition));
}

// Height of the ACTIVE light (sun by day, moon by night - Iris swaps
// shadowLightPosition automatically). Used by godrays and caustics.
float lightHeight() {
    return dot(normalize(shadowLightPosition), normalize(upPosition));
}

// MOON_PHASE_LIGHT: luminance of the moon by phase. Iris moonPhase: 0 full,
// 4 new, symmetric on both sides (k = 0..4). Full 1.0, gibbous 0.78, quarter
// 0.50, crescent 0.30, new = MOON_PHASE_MIN (CONFIG_AMBIANCE). Floats only:
// the int min() overload does not exist in the #version 120 gbuffers.
float moonPhaseLum() {
#if MOON_PHASE_LIGHT == 1
    float ph = float(moonPhase);
    float k = min(ph, 8.0 - ph);
    return (k < 0.5) ? 1.0 : (k < 1.5) ? 0.78 : (k < 2.5) ? 0.50 : (k < 3.5) ? 0.30 : MOON_PHASE_MIN;
#else
    return 1.0;
#endif
}
// Deep-night weighted phase factor (sh = sun height): 1.0 while the sun is
// above -0.05, the full phase luminance below -0.25. The phase flips at
// worldTime 0 (sun at the horizon, moon setting) where this is exactly 1.0,
// so the moon/ambient/sky terms never pop. Applied to NIGHT terms only.
float moonPhaseW(float sh) {
#if MOON_PHASE_LIGHT == 1
    return mix(1.0, moonPhaseLum(), 1.0 - smoothstep(-0.25, -0.05, sh));
#else
    return 1.0;
#endif
}

// Direct light color (sun by day, moon by night)
vec3 getLightColor() {
    float sh = sunHeight();
    float dayF  = smoothstep(-0.03, 0.2, sh);
    // Dusk band is ASYMMETRIC around the horizon: below it the orange is cut
    // (end of civil twilight) so nights stay lunar rather than golden.
    float duskF = clamp(1.0 - abs(sh) * 5.0, 0.0, 1.0) * smoothstep(-0.14, -0.04, sh);
    // Moonrise: once Iris swaps the shadow light to the MOON, the dusk tint must
    // stop coloring the active light, otherwise the moon briefly wears sun color.
    duskF *= smoothstep(0.0, 0.25, dot(normalize(sunPosition), normalize(shadowLightPosition)));
    // Continuity at the Iris sun/moon swap (exactly at sh=0): without this gate
    // duskF is ~1 at the swap and the binary gate above snaps the color in one
    // frame. Here duskF reaches 0 AT the swap; the dusk peak shifts to sh~0.06
    // and the below-horizon afterglow is carried by the AMBIENT term instead
    // (getAmbientColor has no such gate).
    duskF *= smoothstep(0.0, 0.05, sh);

    // SUN_TINT_TEMP MULTIPLIES here: dividing would invert the slider direction.
    vec3 day   = vec3(1.0, 0.97 * SUN_TINT_TEMP, 0.90 * SUN_TINT_TEMP * SUN_TINT_TEMP) * 4.6 * SUN_INTENSITY;
    #if BIOME_CLIMATE == 1
    // Hot & dry biome: the noon sun a touch warmer (dust-laden air). Day term
    // only, so dusk and night keep their palettes.
    day *= mix(vec3(1.0), vec3(1.0, 0.985, 0.95), biomeHotW() * BIOME_CLIMATE_STRENGTH);
    #endif
    // Sunrise = warm golden pink, sunset = deep fire red; separated by worldTime.
    bool amG = (worldTime > 21000 || worldTime < 3000);
    // Deep hues at moderate gain: ACES pushes high-intensity dusk toward white,
    // so the gold/fire look comes from the tint, not from the multiplier.
    vec3 dusk  = (amG ? vec3(1.0, 0.46, 0.15) * 2.2 : vec3(1.0, 0.30, 0.08) * 2.3) * SUN_INTENSITY;
    // Moonlight: silvery blue
    vec3 night = vec3(0.15, 0.21, 0.38) * 0.30 * MOON_INTENSITY;
    #if MOON_PHASE_LIGHT == 1
    // Moon share follows the phase (deep-night weighted, see moonPhaseW).
    night *= moonPhaseW(sh);
    #endif

    vec3 c = mix(night, day, dayF);
    c = mix(c, dusk, duskF);
#if DIMENSION_FX == 1
    // Nether: no sun or moon at all (the lava height map lights it instead).
    // End: fixed cold directional light (noon sun frozen there, shadows kept).
    // Both weights are exactly 0.0 in the Overworld (lib/dimension.glsl).
    c *= 1.0 - dimNether();
    c = mix(c, dimEndLight(), dimEnd());
    // Vanilla syncs the global rain state into every dimension (the Nether /
    // End level data derive from the Overworld's): the frozen dimensional
    // light must not dim with an Overworld storm. The weight is exactly 0.0
    // in the Overworld, so the factor there is bit-identical.
    return c * (1.0 - 0.85 * rainStrength * (1.0 - max(dimNether(), dimEnd())));
#else
    return c * (1.0 - 0.85 * rainStrength);
#endif
}

// Ambient color coming from the sky
vec3 getAmbientColor() {
    float sh = sunHeight();
    float dayF  = smoothstep(-0.05, 0.2, sh);
    // Same asymmetric dusk band as getLightColor: no golden ambient at night.
    float duskF = clamp(1.0 - abs(sh) * 4.0, 0.0, 1.0) * smoothstep(-0.14, -0.04, sh);

    // AMBIENT_COOL (CONFIG_LIGHT): day ambient temperature - >1 cooler (R down,
    // B up), <1 warmer. Exact legacy color at 1.0; dusk/night stay untouched.
    vec3 day   = vec3(0.55 * (2.0 - AMBIENT_COOL), 0.72, 1.00 * AMBIENT_COOL) * 0.72;
    #if BIOME_CLIMATE == 1
    // Cold biome: cooler day ambient (+B -R 4% at full weight); dusk/night untouched.
    day *= mix(vec3(1.0), vec3(0.96, 1.0, 1.04), biomeColdW() * BIOME_CLIMATE_STRENGTH);
    #endif
    vec3 dusk  = vec3(0.85, 0.55, 0.40) * 0.52; // warm golden-hour ambient
    vec3 night = vec3(0.09, 0.13, 0.25) * 0.42; // readable lunar blue
    #if MOON_PHASE_LIGHT == 1
    // Night ambient follows the moon phase (MIN_LIGHT cave floor untouched).
    night *= moonPhaseW(sh);
    #endif

    vec3 c = mix(night, day, dayF);
    c = mix(c, dusk, duskF * 0.7);
#if DIMENSION_FX == 1
    // Nether: biome fog chroma x NETHER_AMBIENT; End: fixed violet ambient.
    // Applied BEFORE AMBIENT_INTENSITY so that dial keeps its global meaning.
    // shadeSurface makes these independent of the (zero) skylight there.
    c = mix(c, dimNetherAmbient(), dimNether());
    c = mix(c, dimEndAmbient(), dimEnd());
    // Same rain lock as getLightColor: the skyless dimensional ambient must
    // not dim with an Overworld storm (weight exactly 0.0 in the Overworld).
    return c * (1.0 - 0.45 * rainStrength * (1.0 - max(dimNether(), dimEnd()))) * AMBIENT_INTENSITY;
#else
    return c * (1.0 - 0.45 * rainStrength) * AMBIENT_INTENSITY;
#endif
}

vec3 getTorchColor() {
    // CONFIG_LIGHT: per-channel creator dials (1.0 = exact vanilla torch tint)
    return vec3(1.0 * TORCH_R, 0.52 * TORCH_G, 0.18 * TORCH_B);
}

/*
    COLORED LIGHTS - forward bridge to the LPV field (compute chain composite.csh + flood a..d).
    v120 gbuffers cannot imageLoad, so lightImg is read through its Iris SAMPLER (lightSampler,
    declared in shaders.properties). ADDRESSING must be an EXACT copy of the world-aligned snap in
    lib/lpv.glsl (sampleLPV): cell = f(p, cameraPosition) IDENTICAL to the injection write - any
    deviation offsets the field and the tint drifts. Manual trilinear, 8 texture3D taps (Iris custom
    image samplers are NEAREST), EXCLUDING SOLID cells (flag .a in [0.5,1.5] -> weight 0, then
    renormalize) so no tint is sucked out of a wall.
    lightImg encoding: .rgb = radiance, .a = flag (0 empty, 2 source); both are readable here.
*/
#if EMISSIVE_LPV == 1
uniform sampler3D lightSampler;   // sampler for the custom image lightImg (128^3, rgba16f)
#if CL_V3 == 1
// CL_V3 (lib/settings.glsl): the diffusion (composite.csh) ping-pongs lightImg /
// lightImgB by FRAME PARITY (even frame writes A, odd writes B). EVERY reader -
// forward gbuffers (run before the compute) and the deferred passes (run after) -
// samples the volume COMPLETED LAST frame: odd frame -> A (written on the even
// frame N-1), even frame -> B. One frame of latency on a ~30-frame convergence is
// invisible, and both pipeline halves see the SAME finished field (zero seam).
uniform sampler3D lightSamplerB;
#ifndef VL_FRAMECOUNTER_DECL
#define VL_FRAMECOUNTER_DECL
uniform int frameCounter;
#endif
#endif

vec3 sampleLPVForward(vec3 worldRelCam, vec3 normalW) {
#if CL_V3 == 1
    // ==== CL_V3 read: 128^3 BLOCK grid (1.0 block/cell, lib/settings.glsl) ====
    // Sample point pushed 0.55 voxel along the GEOMETRIC normal - not 0.50 exactly:
    // half a voxel lands slab/carpet points right ON the cell boundary and the
    // winning texel flickers with sub-texel camera motion ("clignote dans les
    // coins"); 0.55 keeps the point safely inside the AIR cell off the surface.
    vec3 p = worldRelCam + normalW * 0.55;
    // Same block-aligned snap as the writer (shadow.vsh) at s = 1.0, +CL3_HALF.
    vec3 camBlock = floor(cameraPosition);
    vec3 g = p + (cameraPosition - camBlock) + (64.0 - 0.5);   // CL3_HALF = 64
    vec3 b = floor(g);
    vec3 f = g - b;
    // Frame parity, v120-safe (no & operator in the forward gbuffers).
    int cl3Par = frameCounter - 2 * (frameCounter / 2);
    // PLAIN trilinear, 8 taps (custom image samplers are NEAREST): solid cells hold
    // exactly zero, so no skip/renormalize is needed - the legacy skip+renormalize
    // was a discontinuous weight flip and one of the corner-flicker sources.
    vec3 acc = vec3(0.0);
    for (int ix = 0; ix < 2; ix++)
    for (int iy = 0; iy < 2; iy++)
    for (int iz = 0; iz < 2; iz++) {
        vec3 cc = b + vec3(float(ix), float(iy), float(iz));
        if (cc.x < 0.0 || cc.y < 0.0 || cc.z < 0.0 || cc.x > 127.5 || cc.y > 127.5 || cc.z > 127.5) continue;
        vec4 L;
        if (cl3Par == 1) L = texture3D(lightSampler,  (cc + 0.5) / 128.0);   // exact texel center
        else             L = texture3D(lightSamplerB, (cc + 0.5) / 128.0);
        float w = ((ix == 1) ? f.x : 1.0 - f.x)
                * ((iy == 1) ? f.y : 1.0 - f.y)
                * ((iz == 1) ? f.z : 1.0 - f.z);
        acc += L.rgb * w;
    }
    // v120-safe NaN/Inf/garbage scrub (isnan is 130+): a NaN fails every comparison,
    // so !(sum < big) catches NaN, +Inf and absurd magnitudes in one test. Only ever
    // fires on the very first frames after enable (persistent volumes are not
    // cleared and the first read precedes the first diffusion write).
    acc = max(acc, vec3(0.0));
    if (!(acc.x + acc.y + acc.z < 1.0e6)) acc = vec3(0.0);
    // sqrt AFTER the trilinear (field lives in SQUARED space: composite.csh seeds
    // palette^2) -> perceptually soft fronts; then the quadratic Chebyshev range
    // fade from HALF the grid reach (32 blocks) to 60 blocks: the field dies before
    // the +-64 border, so the application's warm floor takes over CONTINUOUSLY =
    // exact getTorchColor() fallback, no seam at the edge.
    vec3 v = sqrt(acc) * LPV_STRENGTH;
    vec3 ap = abs(p);
    float cheb = max(ap.x, max(ap.y, ap.z)) * (1.0 / 64.0);   // fraction of the 64-block half-reach
    float k = clamp((cheb - CLV2_FADE_HALF) / (CLV2_FADE_END - CLV2_FADE_HALF), 0.0, 1.0);
    return v * (1.0 - k * k);
#else
    float s = VOXEL_SCALE * 2.0;               // = LPV_SCALE (lib/lpv.glsl), 128^3 grid
#if CL_V2 == 1
    // Step out 0.55 cell along the normal (not 0.50: exactly half lands slab/carpet
    // sample points right ON the cell boundary and the winning texel flickers with
    // sub-texel camera motion - the extra 0.05 keeps the point safely in the air cell).
    vec3 p = worldRelCam + normalW * (0.55 * s);
#else
    // Step out half an LPV cell along the normal so the sample point leaves the solid shell of
    // its own surface; otherwise all taps land inside the wall.
    vec3 p = worldRelCam + normalW * (0.5 * s);
#endif
    vec3 camBlock = floor(cameraPosition / s);  // SAME snap as lpv.glsl (ivec3 <-> floor equivalent)
    vec3 g = (p + (cameraPosition - camBlock * s)) / s + 64.0 - 0.5;   // LPV_HALF = 64
    vec3 b = floor(g);
    vec3 f = g - b;
    vec3 acc = vec3(0.0);
    float ws = 0.0;
    for (int ix = 0; ix < 2; ix++)
    for (int iy = 0; iy < 2; iy++)
    for (int iz = 0; iz < 2; iz++) {
        vec3 c = b + vec3(float(ix), float(iy), float(iz));
        if (c.x < 0.0 || c.y < 0.0 || c.z < 0.0 || c.x > 127.5 || c.y > 127.5 || c.z > 127.5) continue;
        vec4 L = texture3D(lightSampler, (c + 0.5) / 128.0);  // exact texel center (nearest-safe)
        if (L.a > 0.5 && L.a < 1.5) continue;  // SOLID cell: radiance ignored (anti-leak)
        float w = ((ix == 1) ? f.x : 1.0 - f.x)
                * ((iy == 1) ? f.y : 1.0 - f.y)
                * ((iz == 1) ? f.z : 1.0 - f.z);
        acc += L.rgb * w;
        ws  += w;
    }
#if CL_V2 == 1
    // v2 decode - MIRROR of sampleLPV (lib/lpv.glsl): sqrt AFTER the trilinear (field is
    // seeded squared by composite.csh), then quadratic Chebyshev range fade from half the
    // volume reach so the tint glides to the vanilla warm fallback before the +-64 border.
    if (ws <= 1e-4) return vec3(0.0);
    vec3 vD = sqrt(max(acc / ws, vec3(0.0))) * LPV_STRENGTH;
    vec3 apD = abs(p);
    float chebD = max(apD.x, max(apD.y, apD.z)) / (64.0 * s);   // fraction of the volume half-reach (LPV_HALF = 64)
    float kD = clamp((chebD - CLV2_FADE_HALF) / (CLV2_FADE_END - CLV2_FADE_HALF), 0.0, 1.0);
    return vD * (1.0 - kD * kD);
#else
    return (ws > 1e-4) ? (acc / ws) * LPV_STRENGTH : vec3(0.0);
#endif
#endif // CL_V3
}
#endif

/*
    SHARED CUMULUS COVERAGE (VC_TEXTURED=1) - SINGLE SOURCE OF TRUTH.
    Lives HERE, not in clouds.glsl, because lighting.glsl is ALWAYS included
    first (deferred.fsh / composite1.fsh / every gbuffers program). cloudShadow
    below AND the raymarch in lib/clouds.glsl therefore call the SAME function:
    the ground shadows cannot desync from the visible clouds any more (the old
    proxy re-typed ~15 constants by hand, which was the standing sync contract).
    Kept outside the VOLUMETRIC_CLOUDS / VC_GROUND_SHADOWS gates on purpose:
    clouds.glsl needs it even when ground shadows are off.
    The sampler declaration is guarded so clouds.glsl may repeat it harmlessly.
*/
#if VC_TEXTURED == 1
#ifndef VL_CUMULUS_BASE_DECL
#define VL_CUMULUS_BASE_DECL
uniform sampler2D vlCumulusBase;   // customTexture: 1024^2 R8, blur=true clamp=false
#endif

// World blocks spanned by ONE 1024^2 tile: 2667 x 1.5 = 4000 blocks at the
// default VC_CUMULUS_SCALE. MEASURED on cumulus_base.bin (mask at
// VC_COVERAGE=0.40): median cell chord ~51 blocks, area-weighted median ~172,
// plus a few 350-600 block systems. The map is NOT band-limited (85% of its
// variance is already gone at a 125-block lag), so nothing below may assume
// smoothness. VC_CUMULUS_SCALE keeps its meaning: larger = larger, more
// spaced clouds.
#if VC2 == 1
// VC2 size boost x1.6 ("de jolis gros nuages"): ONE source - VL_CUM_TILE,
// VL_CUM_RAD and VL_CUM_COLCAP all derive from it, so the morphological
// width gates, the height caps, the lobe tap and the ground shadows scale
// together. Measured (1024^2 replay of the FULL VC2-v2 field, defaults with
// the x0.85 coverage cut): mass chords median 102 -> 148 blocks,
// area-weighted median 172 -> 250, p90 369; distinct masses (>40x40)
// 6.1 -> 3.4 per km^2 (-44%) - fewer, clearly bigger consolidated entities.
// COLCAP reaches 1.0 (RAD 224 > VC_THICK): grand cores may fill the slab
// (tops at 370, still 95 blocks under the raised alto at 465). The slider
// VC_CUMULUS_SCALE keeps its meaning on top of the boost.
// VC32 : le boost x1.6 est ramene par VC32_CELL_K (voir settings.glsl) - une
// fois la HAUTEUR reparee, des masses de 442 blocs lisent comme une banque
// couverte ; ~330 blocs pour 100-140 de haut lisent comme la photo.
// VC36 : x VC36_CELL par-dessus (0.80). UNE seule source, donc VL_CUM_TILE,
// VL_CUM_RAD, le rayon des 9 taps du pilote de hauteur, le plafond
// VL_CUM_COLCAP, le tap de lobe et l'ombre au sol retrecissent ENSEMBLE.
#if VC32 == 1
#if VC36 == 1
#define VL_CUM_SCALE_EFF (VC_CUMULUS_SCALE * 1.6 * VC32_CELL_K * VC36_CELL)
#else
#define VL_CUM_SCALE_EFF (VC_CUMULUS_SCALE * 1.6 * VC32_CELL_K)
#endif
#else
#define VL_CUM_SCALE_EFF (VC_CUMULUS_SCALE * 1.6)
#endif
#else
#define VL_CUM_SCALE_EFF VC_CUMULUS_SCALE
#endif
#define VL_CUM_TILE (2667.0 * VL_CUM_SCALE_EFF)
// Morphological radius in blocks (140 at defaults), proportional to the tile
// so the width/height guarantees below hold at every VC_CUMULUS_SCALE.
#define VL_CUM_RAD (VL_CUM_TILE * 0.035)
// Ceiling on the column-height fraction: filled height never exceeds
// VL_CUM_RAD blocks (the raymarch re-clamps colH with this).
#define VL_CUM_COLCAP clamp(VL_CUM_RAD / VC_THICK, 0.08, 1.0)

// Calibrated base-field value in [0,1] at one position. COST: 1 texture2D tap.
// Calibration measured on the .bin (min 0.03, max 0.91, mean 0.35, bell
// shaped): stretching 0.14..0.58 to 0..1 makes it nearly uniform, which turns
// VC_COVERAGE into ~the fraction of sky actually covered.
float vlCumulusCn(vec2 xz, vec2 wind) {
    float raw = texture2D(vlCumulusBase, (xz + wind) * (1.0 / VL_CUM_TILE)).r;
    return clamp((raw - 0.14) * (1.0 / 0.44), 0.0, 1.0);
}

// Shared wind advection (same vector as every other cloud layer). mod() folds
// it back into ONE tile: exact for a repeating texture (no jump), and it keeps
// the uv small so float32 still resolves it on worlds thousands of days old.
// VC33_WIND == VC_WIND * VC33_SPEED1 (lib/settings.glsl): the LAYER-1 speed
// factor, applied at every layer-1 wind site so the ground shadow, the probes
// and the 3D volume can never desync from what the march draws. At gate 0 the
// macro falls back token-for-token on VC_WIND.
vec2 vlCumulusWind(float t) {
    return mod(t * vec2(7.0, 2.4) * VC33_WIND, VL_CUM_TILE);
}

// Coverage remap - the ONLY place the threshold lives. Soft remap instead of a
// hard cut: 0.0 = clear sky, 0.40 (default) = separated masses with real blue
// between them (measured 30.6% footprint), 1.0 = overcast. Monotone in cn AND
// in cvS: raising VC_COVERAGE can only raise cov at every point, which is what
// makes the height driver below grow WITH coverage instead of against it.
float vlCumulusCovRemap(float cn, float cvS) {
    return clamp((cn - (1.0 - cvS)) / cvS, 0.0, 1.0) * smoothstep(0.0, 0.05, cvS);
}

#if VC2 == 1
/*
    VC2 SHARED SHAPERS - single source for the reworked cumulus, next to the
    field helpers so the render (lib/clouds.glsl), cloudShadow AND
    cloudShadowCheap below consume the very same curves (no mirrored constant).
*/
// Coverage steepening - the ONLY edge-sharpening site. Knots measured on
// cumulus_base.bin (replay, VC_COVERAGE 0.40): the steep 0.62 shoulder turns
// the horizontal density edge (0.05 -> 0.60) from 23 blocks into 16. The toe
// was raised 0.06 -> 0.08 with the v2 big-cell pass: it prunes the straggly
// fringe cells so the fewer, bigger masses read as CONSOLIDATED entities
// (with the x0.85 coverage cut: 22.7% of sky covered, distinct masses -44%).
// Monotone in cov, so every "raising coverage raises density" contract of
// the v5 remap still holds.
float vc2CovShape(float cov) {
    return smoothstep(0.08, 0.62, cov);
}

// Medium-scale LOBE driver - the cauliflower silhouette the v5 column height
// lacked (coverage-saturated interiors all shared one colH -> mesa tops).
// SAME base texture at x4 frequency: with the x1.6 tile boost the bumps land
// at ~20-70 blocks, several domes per 150-300 block mass. x4 is an INTEGER
// on purpose: the wind is folded by mod(_, VL_CUM_TILE) (vlCumulusWind), and
// a non-integer frequency made the lobe pattern JUMP by a fractional tile at
// every wind wrap (the first VC2 drop used 3.7 and had that latent pop); an
// integer ratio is wrap-exact. Decorrelation from the coverage tap comes from
// the scale gap itself (85% of the map's variance is gone at a 125-block lag,
// so a 4x zoom shares no visible structure) plus the fixed (0.31, 0.67)-tile
// offset. Advected by the same wind so the lobes ride the cloud they sculpt.
// 1 extra 2D tap, paid on hiRes density samples only (render march; the light
// march and the ground shadow keep the unlobed column - same approximation
// class as their existing no-3D-erosion contract).
float vc2Lobe(vec2 xz, vec2 wind) {
    float raw = texture2D(vlCumulusBase, ((xz + wind) * 4.0 + vec2(0.31, 0.67) * VL_CUM_TILE) * (1.0 / VL_CUM_TILE)).r;
    return clamp((raw - 0.14) * (1.0 / 0.44), 0.0, 1.0);
}
#if VC36 == 1
// VC36 : DEUXIEME frequence de lobe (VC36_LOB2_F = 9, contre 4 pour vc2Lobe) :
// des bosses de ~33 blocs au lieu de ~75, soit plusieurs tourelles PAR dome.
// C'est le SEUL levier qui deplace vraiment le contour : la mesure du bloc
// VC36 de lib/settings.glsl montre que monter l'erosion (x1.3 a x2.0) laisse
// la rugosite 10-40 blocs a 6.29 au chiffre pres, parce que la ligne
// d'horizon est l'iso-alpha 0.5 de la marche et que les franges erodees n'ont
// pas la corde pour l'atteindre : c'est colH qui dessine la silhouette.
// MEME texture, MEME vent, offset different -> 1 tap 2D de plus, sur les seuls
// echantillons hiRes (meme politique que vc2Lobe : le light march et l'ombre
// au sol gardent la colonne sans lobe). VC36_LOB2_F DOIT rester ENTIER : le
// vent est replie par mod(_, VL_CUM_TILE) et seul un rapport entier rend le
// pli exact (meme contrat que le x4 ci-dessus).
float vc2Lobe2(vec2 xz, vec2 wind) {
    float raw = texture2D(vlCumulusBase, ((xz + wind) * VC36_LOB2_F + vec2(0.73, 0.19) * VL_CUM_TILE) * (1.0 / VL_CUM_TILE)).r;
    return clamp((raw - 0.14) * (1.0 / 0.44), 0.0, 1.0);
}
#endif
#endif

// VC2 erosion-grain scale, SINGLE SOURCE (moved here from lib/clouds.glsl so
// the VC3 shape tile below shares it - clouds.glsl derives its erosion tiles
// VL_DET*_TILE, 3:9 integer-ratio contract, from this very macro): x1.3 while
// the cells grew x1.6 - deliberately SUB-proportional, a finer relative grain
// gives the bigger masses MORE cauliflower bumps each.
#if VC2 == 1
#define VC2_DET_SCALE (VC_CUMULUS_SCALE * 1.3)
#else
#define VC2_DET_SCALE VC_CUMULUS_SCALE
#endif

#if VC2 == 1 && VC3 == 1
/*
    VC3 SHARED 3D-SHAPE ACCESS - single source for the bubble volume, next to
    the other cumulus helpers so the render (lib/clouds.glsl) and the ground
    shadow below sample the SAME texture with the SAME advection.
    cumulus_shape3d.bin (128^3 RG8, generated offline by vc3_gen.py: seeded
    PERIODIC jittered-grid worley + PERIODIC gradient-lattice perlin, both
    wrap-exact by construction; measured seam-gradient ratio 0.90-1.04 vs the
    interior on all 3 axes = no seam):
      R = base billows: worley-FBM 4/8/16 cells/axis (0.62/0.28/0.10) x0.74
          + perlin-FBM 3/6/12 octaves x0.26, histogram-equalized to ~uniform
          [0,1] (so shader thresholds have a direct fill-fraction meaning);
          at VC3_TILE = 160 * VC2_DET_SCALE (312 blocks at defaults) the main
          lobes are ~78 blocks: several domes per 150-300 block mass;
      G = HF erosion: worley-FBM 10/20 cells/axis (0.65/0.35), equalized
          (~31/16-block buds at the base tap, /3 on the fine tap).
*/
#define VC3_TILE (160.0 * VC2_DET_SCALE)
#ifndef VC3_SHAPE_DECL
#define VC3_SHAPE_DECL
uniform sampler3D vlCumulusShape; // customTexture: 128^3 RG8, blur=true clamp=false
#endif
// Shape advection: same wind family as the v2 erosion but +6% drift vs the
// coverage (HALF the v2 +12%: the shape now defines WHOLE volumes and a fast
// differential reads as the cloud sliding through its own skin). mod() folds
// it into one shape tile - exact for the base tap AND the x3 fine tap
// (integer frequency ratio).
// VC33_WIND carries the layer-1 speed factor, so the +6% differential stays a
// RATIO: the shape keeps drifting 6% faster than the coverage at any speed.
vec3 vc3ShapeWind(float t) {
    return mod(vec3(t * 7.0, t * -0.35, t * 2.4) * (VC33_WIND * 1.06), VC3_TILE);
}
// Ground-shadow modulation: 1 RG8 tap of the REAL volume at the projection
// plane (the same density-barycentre height the 2D proxy projects from).
// 0.45 + 0.65 * b: the equalized channel has mean 0.5 -> mean factor 0.775.
// VC3 columns are only ~60-80% filled (bubble model), so a proportionally
// lighter shadow is the CORRECT brightness - and it now breaks up over the
// real inter-lobe canyons instead of being a uniform blot.
float vc3ShadowMod(vec2 cp, float t) {
    vec3 p = vec3(cp.x, VC_BASE + VC_THICK * 0.33, cp.y) + vc3ShapeWind(t);
    float b = texture3D(vlCumulusShape, p * (1.0 / VC3_TILE)).r;
    return 0.45 + 0.65 * b;
}
#if VC33 == 1
// VC33 lengths derived from the shape tile (single source, next to it), so the
// sunward offset and the distance fade follow VC_CUMULUS_SCALE instead of
// being block counts that would be wrong at any other scale. At the defaults:
// offset 5.0 blocks (~half a wavelength of the x3 octave, whose worley-10
// cells are 10.4 blocks), fade 998 -> 1700 blocks. See the VC33 block of
// lib/settings.glsl for the measurements behind the three numbers.
#define VC33_SUNOFF (VC3_TILE * VC33_SUNOFF_F)
#define VC33_FADE_NEAR (VC3_TILE * VC33_FADE0)
#define VC33_FADE_FAR (VC3_TILE * VC33_FADE1)
#if VC34 == 1
// VC34 : le fondu de la 3e octave, meme unite (tuiles de forme) donc il suit
// VC_CUMULUS_SCALE comme celui de VC33, mais DEUX FOIS PLUS PROCHE puisque le
// motif est deux fois plus fin - 771 -> 1151 blocs au defaut. C'est aussi la
// porte de cout : au-dela de VC34_FADE3_FAR le tap n'est pas paye.
// La 3e octave reutilise VC33_SUNOFF : 5.0 blocs restent une demi-longueur
// d'onde de sa composante HORIZONTALE (x3, comme l'octave VC33).
#define VC34_FADE3_NEAR (VC3_TILE * VC34_FADE3_0)
#define VC34_FADE3_FAR (VC3_TILE * VC34_FADE3_1)
#endif
#endif
#endif

// Coverage only, 1 tap. t = cloudWorldTime() (same clock as the render, so
// /time set and sleeping move shadows and clouds together). Also used alone by
// the light-march coverage refresh in lib/clouds.glsl.
float vlCumulusCoverage(vec2 xz, float t) {
    float cvS = clamp(mix(VC2_COVERAGE, 1.0, rainStrength * 0.95), 0.0, 1.0); // full rain = near-total overcast; VC2_COVERAGE == VC_COVERAGE at gate 0
    if (cvS <= 0.0) return 0.0;
    return vlCumulusCovRemap(vlCumulusCn(xz, vlCumulusWind(t)), cvS);
}

/*
    COLUMN-HEIGHT DRIVER - the anti-"towers" contract, GEOMETRIC this time.
    Height is driven by MORPHOLOGICAL EROSION of the coverage itself: a column
    may only rise where coverage survives a min() over a sampled cross around
    the point, i.e. where the point is surrounded by VISIBLE cloud:
      . tier A (mid domes):   cover on the +-VL_CUM_RAD/2 cross -> local width
        >= VL_CUM_RAD, height budget VL_CUM_RAD/2 (tops at 70 blocks default);
      . tier B (grand cores): cover on the full +-VL_CUM_RAD cross too (its 4
        outer taps AND tier A's inner ones, which also plug ring-jumping over
        gaps) -> width >= 2*VL_CUM_RAD, total height budget VL_CUM_RAD.
    Each tier caps its own contribution, so filled height <= half the
    guaranteed width BY CONSTRUCTION, at every VC_COVERAGE / VC_CUMULUS_SCALE /
    VC_THICK. The remap being monotone, min(cov) == remap(min(cn)): the erosion
    runs on cn and is remapped once per ring.
    MEASURED on the PREVIOUS hard-min saturation (.bin replay, VC_THICK=160,
    scale 1.5) - the soft ramps below keep the same caps and footprint but
    reach full height deeper inside the masses (mid slopes sit lower):
    at VC_COVERAGE=0.40 the covered sky is 26-block pancakes (median), ~5.1%
    of it is 48+ blocks tall, grand cores reach ~107 blocks (soft-ramp replay;
    pre-rework hard-min saturation measured 118-140) at width/height
    p10 = 2.2; "towers" (width < 2*height among the 48+ tall) are 0.26% of the
    covered surface - the pointwise driver this replaces measured 84%. Heights
    GROW with coverage (48+ tall fraction, pre-rework reference: 5.4% / 10.6% / 32.3% at coverage
    0.20 / 0.40 / 0.70): scattered fair-weather cumulus stay flat pancakes,
    stratocumulus decks get thick - the old driver had it inverted.
*/
float vlCumulusTiers(float cvA, float cvB) {
    // Per-tier height budgets in units of the 0.72 colH swing. The clamps
    // keep the guarantee at extreme VC_THICK/scale combos (budgets hit 0).
    float cA = clamp((0.5 * VL_CUM_RAD / VC_THICK - 0.16) * (1.0 / 0.72), 0.0, 0.385);
    float cB = max(clamp((VL_CUM_RAD / VC_THICK - 0.16) * (1.0 / 0.72), 0.0, 0.993) - cA, 0.0);
    // budget * WIDE smoothstep, not min(smoothstep, budget): the old hard min
    // saturated tier A at cvA ~0.14 and tier B at cvB ~0.25, so each tier shot
    // from 0 to its full budget across a razor-thin spatial band - read as
    // straight cylinder flanks topped by a rectangular tower. The wide bands
    // spread each rise over most of the eroded-coverage ramp and are C1 at
    // BOTH ends (no kink where the slope meets the plateau): domes, not mesas.
    // Anti-tower guarantee UNCHANGED: smoothstep <= 1 keeps every contribution
    // <= its budget, so filled height stays <= half the guaranteed width.
#if VC2 == 1
    // VC2 ramps: steeper and earlier (0.65/0.80 -> 0.50/0.70 upper knots) so
    // domes rise much closer to the cell edge instead of only deep inside the
    // largest masses. Measured on cumulus_base.bin (1024^2 replay, v2
    // defaults with the x1.6 cell boost, full VC2 column formula): 48+ tall
    // fraction of the covered sky 4.1% -> 28.6%, median column 26 -> 45
    // blocks, towers among 48+ tall scanline runs 0.1% (width/height
    // p10 = 2.14) - the budget caps (cA/cB above, unchanged) still bound
    // every contribution and the wider cells restore the full v5 margin.
    return cA * smoothstep(0.05, 0.50, cvA) + cB * smoothstep(0.08, 0.70, cvB);
#else
    return cA * smoothstep(0.05, 0.65, cvA) + cB * smoothstep(0.08, 0.80, cvB);
#endif
}

#if VC32 == 1
// VC32 : transfert PROFONDEUR -> HAUTEUR, en remplacement des budgets par
// palier de vlCumulusTiers (voir le bloc VC32 de lib/settings.glsl pour la
// mesure qui condamne l'ancien : erosion par minimum -> pilote a 0.000 de
// mediane, toutes les colonnes sur leur plancher, crepes de 45 blocs).
// 'deep' = moyenne ponderee du meme voisinage 9 taps, remappee : 0 au bord
// d'une masse, ~1 au coeur d'une grande masse. La sortie est exprimee dans
// l'unite que clouds.glsl attend (colH = 0.22 + 0.08*covS + 0.62*y) : le
// facteur 1/0.62 fait de VC32_SPAN une amplitude DIRECTE en unites de colH.
// ANTI-AIGUILLE : une moyenne de voisinage est structurellement faible sur une
// petite masse isolee, donc elle reste basse - la garantie ne depend plus d'un
// budget calcule, mais de la nature meme du pilote (mesure : pire petite masse
// < 150 blocs a un rapport hauteur/largeur de 1.02, aucune aiguille).
float vlCumulusTiers32(float deep) {
    return (VC32_SPAN * (1.0 / 0.62)) * pow(smoothstep(0.05, 0.70, deep), VC32_GAMMA);
}
#endif

// Full cumulus field: x = coverage [0,1], y = height driver [0,0.993].
// COST: 1 tap on clear sky, 9 taps inside coverage - all on the same 1 MB R8
// 2D texture (bilinear, high spatial coherence), well below one 128^3 3D tap.
vec2 vlCumulusField(vec2 xz, float t) {
    float cvS = clamp(mix(VC2_COVERAGE, 1.0, rainStrength * 0.95), 0.0, 1.0); // full rain = near-total overcast; VC2_COVERAGE == VC_COVERAGE at gate 0
    if (cvS <= 0.0) return vec2(0.0);
    vec2 wind = vlCumulusWind(t);
    float cn0 = vlCumulusCn(xz, wind);
    float cov = vlCumulusCovRemap(cn0, cvS);
    if (cov < 0.015) return vec2(cov, 0.0); // same early-out as the density
#if VC32 == 1
    // VC32 : MEMES 9 taps, MEMES anneaux (rayons x VC32_RADK), combines en
    // MOYENNE au lieu d'un minimum - cout strictement identique. Le minimum
    // mesurait "suis-je a plus de VL_CUM_RAD de tout trou" (faux presque
    // partout depuis le boost de cellules) ; la moyenne mesure "a quelle
    // profondeur dans la masse suis-je", ce qui DOME le sommet par
    // construction : haut au coeur, bas au bord.
    float rA32 = VL_CUM_RAD * 0.5 * VC32_RADK;
    float avA = 0.25 * (vlCumulusCn(xz + vec2(rA32, 0.0), wind)
                      + vlCumulusCn(xz - vec2(rA32, 0.0), wind)
                      + vlCumulusCn(xz + vec2(0.0, rA32), wind)
                      + vlCumulusCn(xz - vec2(0.0, rA32), wind));
    float dB32 = VL_CUM_RAD * VC32_RADK * 0.7071;
    float avB = 0.25 * (vlCumulusCn(xz + vec2(dB32, dB32), wind)
                      + vlCumulusCn(xz - vec2(dB32, dB32), wind)
                      + vlCumulusCn(xz + vec2(dB32, -dB32), wind)
                      + vlCumulusCn(xz - vec2(dB32, -dB32), wind));
    float deep = vlCumulusCovRemap(0.34 * cn0 + 0.36 * avA + 0.30 * avB, cvS);
    // Meme aplatissement par la pluie que la branche v2 (source unique : le
    // raymarch ET cloudShadow en heritent).
    return vec2(cov, vlCumulusTiers32(deep) * (1.0 - rainStrength * 0.65));
#else
    float rA = VL_CUM_RAD * 0.5;
    float mnA = min(cn0, min(min(vlCumulusCn(xz + vec2(rA, 0.0), wind),
                                 vlCumulusCn(xz - vec2(rA, 0.0), wind)),
                             min(vlCumulusCn(xz + vec2(0.0, rA), wind),
                                 vlCumulusCn(xz - vec2(0.0, rA), wind))));
    // Outer ring rotated 45 degrees (verifier fix): axial alignment with the
    // inner cross let narrow DIAGONAL mask gaps slip between both rings. Same
    // distance (|(d,d)| = VL_CUM_RAD), same cost, no desync (single source).
    float dB = VL_CUM_RAD * 0.7071;
    float mnB = min(mnA, min(min(vlCumulusCn(xz + vec2(dB, dB), wind),
                                 vlCumulusCn(xz - vec2(dB, dB), wind)),
                             min(vlCumulusCn(xz + vec2(dB, -dB), wind),
                                 vlCumulusCn(xz - vec2(dB, -dB), wind))));
    // Rain flattens the deck (nimbostratus are flat, not towering); single
    // source, so the raymarch AND cloudShadow inherit the same flattening.
    return vec2(cov, vlCumulusTiers(vlCumulusCovRemap(mnA, cvS), vlCumulusCovRemap(mnB, cvS)) * (1.0 - rainStrength * 0.65));
#endif
}
#endif

/*
    2D cloud shadow on the ground: cheap proxy of the volumetric cloud field
    (same coordinates, same leading octaves) so shadows travel with the clouds.
*/
#ifdef VOLUMETRIC_CLOUDS
#ifdef VC_GROUND_SHADOWS
float cloudShadow(vec3 wp, vec3 lightDirW) {
#if DIMENSION_FX == 1
    // No cloud deck in the Nether / End: the Overworld cumulus field must never
    // darken their light (surfaces, particles, hand, VL probes all go through
    // here). Uniform branch, free in the Overworld.
    if (dimNether() > 0.5 || dimEnd() > 0.5) return 1.0;
#endif
    // Grazing sun: the /y projection blows up (stretched pattern that reveals
    // the projection direction) and used to cut off abruptly. The offset is
    // clamped and the shadow fades to 1.0 below ~0.22 sun height, where light
    // crosses too much atmosphere to cast crisp cloud shadows anyway.
    float sunUpF = smoothstep(0.06, 0.22, lightDirW.y);
    if (sunUpF <= 0.0) return 1.0;
    // Projection plane at VC_THICK*0.33: the vertical profile piles the matter
    // low (flat base at 6% of the slab, plateau to 0.74*colH, colH <= 0.88),
    // so the density barycentre sits near h~0.33, not mid-slab. Projecting
    // from mid-slab offset grazing shadows by ~28/tan(elev) blocks.
    vec2 cp = wp.xz + lightDirW.xz / max(lightDirW.y, 0.25) * (VC_BASE + VC_THICK * 0.33 - wp.y);
#if VC_CUMULUS_SHAPES == 0 || VC_TEXTURED == 0
    // World-time SYNC: same clock as the cloud render (clouds.glsl receives
    // cloudWorldTime() at its call sites). Using another clock would make the
    // ground shadows drift from the visible clouds after /time set or sleeping.
    // Only the procedural branches read this; the textured branch advects
    // inside vlCumulusField and must not pay an unused per-pixel compute.
    vec2 wind = cloudWorldTime() * vec2(7.0, 2.4) * VC33_WIND;
#endif
#if VC_CUMULUS_SHAPES == 1
#if VC_TEXTURED == 1
    // TEXTURED path: calls the EXACT function the raymarch uses
    // (vlCumulusField above) - zero duplicated constants, so ground shadows
    // follow the visible clouds by construction. Cost: 1 tap on clear sky,
    // 9 taps under cloud. The composite1 volumetric-light probes (csA/csB) go
    // through here too and therefore inherit the same field for free.
    vec2 fT = vlCumulusField(cp, cloudWorldTime());
    // Shadow follows column thickness (same intent as the procedural proxy):
    // grand cores (y up to ~0.99) cast full shadow, flat pancakes (y=0) a
    // light penumbra. CLOUD_SHADOW_SOFTNESS keeps its usual meaning.
#if VC2 == 1 && VC3 == 1
    // VC3: same sharpened 2D footprint (position = the weather map, i.e. the
    // REAL masses by construction) x 1 tap of the true 3D volume at the
    // projection plane (vc3ShadowMod above): the shadow lightens over the
    // inter-lobe canyons and its mean matches the ~60-80% bubble fill.
    float dT = clamp(vc2CovShape(fT.x) * (0.70 + fT.y * 0.90)
                   * (0.80 + CLOUD_SHADOW_SOFTNESS * 0.50)
                   * vc3ShadowMod(cp, cloudWorldTime()), 0.0, 1.0);
#elif VC2 == 1
    // VC2: the footprint follows the SHARPENED coverage the render draws
    // (vc2CovShape, single source above) - shadow edges crisp up exactly
    // where the cloud edges did; the thickness weighting is unchanged.
    float dT = clamp(vc2CovShape(fT.x) * (0.70 + fT.y * 0.90)
                   * (0.80 + CLOUD_SHADOW_SOFTNESS * 0.50), 0.0, 1.0);
#else
    float dT = clamp(fT.x * (0.70 + fT.y * 0.90)
                   * (0.80 + CLOUD_SHADOW_SOFTNESS * 0.50), 0.0, 1.0);
#endif
    dT = smoothstep(0.0, 1.0, dT);
    return 1.0 - dT * CLOUD_SHADOW_DARKNESS * sunUpF;
#else
    // Cumulus 2D proxy = the SAME field as cloudFieldCumulus in clouds.glsl
    // (2-octave smooth mass + silhouette octave (+ detail), threshold-lifting
    // banks, scattered small cumulus - same frequencies, thresholds and wind).
    // DUPLICATED here because lighting.glsl is included BEFORE clouds.glsl:
    // any edit there MUST be mirrored here or ground shadows desync from clouds.
    vec2 pC = cp + wind;
    vec2 qmC = vec2(pC.x * 0.0028, pC.y * 0.0038) / VC_CUMULUS_SCALE;
    float MC = vnoise(qmC) * 0.62 + vnoise(qmC * 2.31 + 19.7) * 0.26;
    float mkC = MC + vnoise(qmC * 7.3 + 2.9) * 0.12;
    #if VC_DETAIL == 1
    mkC = mkC * 0.92 + vnoise(qmC * 16.9 + 5.1) * 0.08;
    #endif
    float bankC = smoothstep(0.28, 0.62, fbm3(pC * 0.00027 + 17.3));
    float covC = clamp(mix(VC_COVERAGE, 1.0, rainStrength * 0.95), 0.0, 1.0); // full rain = near-total overcast
    float thBC = mix(0.60, 0.34, covC) + (1.0 - bankC) * 0.12;
    float bigC = smoothstep(thBC, thBC + 0.13, mkC);
    vec2 qsC = vec2(pC.x * 0.010, pC.y * 0.013) / VC_CUMULUS_SCALE;
    float scC = vnoise(qsC) * 0.70 + vnoise(qsC * 2.63 + 7.7) * 0.30;
    float thSC = mix(0.74, 0.58, covC);
    float smC = smoothstep(thSC, thSC + 0.10, scC) * (0.30 + 0.70 * bankC);
    float covF = max(bigC, smC * 0.85) * smoothstep(0.0, 0.05, covC);
    covF = max(covF, rainStrength * rainStrength * 0.85); // rain overcast floor (MIRROR of cloudFieldCumulus)
    float massC = smoothstep(thBC, thBC + 0.30, MC) * (1.0 - rainStrength * 0.65); // rain flattening, mirrored from cloudFieldCumulus
    // Shadow follows column thickness: cores of large systems (massC->1) cast
    // full shadow, flat edges cast light penumbra, so ground shadows track
    // cloud relief. CLOUD_SHADOW_SOFTNESS keeps its usual meaning.
    float d = clamp(covF * (0.70 + massC * 0.90) * (0.80 + CLOUD_SHADOW_SOFTNESS * 0.50), 0.0, 1.0);
    d = smoothstep(0.0, 1.0, d);
    return 1.0 - d * CLOUD_SHADOW_DARKNESS * sunUpF;
#endif
#else
    float cov = clamp(mix(VC_COVERAGE, 1.0, rainStrength * 0.95), 0.0, 1.0); // full rain = near-total overcast
    float covLo = max(0.20 - (cov - 0.45) * 0.44, 0.0);
    float covL = cov * smoothstep(covLo, 0.70, vnoise((cp + wind * 0.6) * 0.0010)) * 1.5;
    float base = fbm((cp + wind) * 0.0060);
    float d = clamp((base - (1.0 - covL) * 0.52 - 0.08) * (2.0 + CLOUD_SHADOW_SOFTNESS * 2.5), 0.0, 1.0);
    d = smoothstep(0.0, 1.0, d);
    return 1.0 - d * CLOUD_SHADOW_DARKNESS * sunUpF;
#endif
}

#ifdef CLOUD_SHAFTS_ACTIVE
/*
    CLOUD_SHAFTS (bloc "RAYONS DE NUAGES" de lib/settings.glsl) -- SOURCE
    UNIQUE de l'opacite du proxy 2D des cumulus AU PLAN DES NUAGES.

    Rend le dT que cloudShadowCheap calcule, AVANT CLOUD_SHADOW_DARKNESS et
    SANS sunUpF : c'est exactement ce qu'un texel de la carte de transmittance
    (colortex12, cuite par prepare2.fsh) doit contenir. La fonction est
    appelee par le CUISEUR et par cloudShadowCheap lui-meme, donc il n'existe
    qu'un seul endroit ou vivent la courbe et le champ -- un bord de faisceau
    tombe la ou tombe le bord d'ombre au sol par construction, pas par une
    constante recopiee.

    Elle suit PERF_CSHADOW_CHEAP comme son appelant : 5 taps (centre + croix
    interne) au reglage livre, le champ COMPLET de cloudShadow (9 taps +
    vc3ShadowMod) quand le dial demande le champ complet partout. Le contrat
    "la carte contient ce que cloudShadowCheap aurait rendu" reste donc vrai
    dans les deux reglages.

    Ne prend QUE cp : la projection (et son plancher CTM_MIN_LY, different de
    celui de cloudShadow) appartient a l'appelant.
*/
float vlCloudOpacityAtPlane(vec2 cp) {
#if PERF_CSHADOW_CHEAP == 1
    float cvS = clamp(mix(VC2_COVERAGE, 1.0, rainStrength * 0.95), 0.0, 1.0); // full rain = near-total overcast; VC2_COVERAGE == VC_COVERAGE at gate 0
    if (cvS <= 0.0) return 0.0;
    vec2 wind = vlCumulusWind(cloudWorldTime());
    float cn0 = vlCumulusCn(cp, wind);
    float cov = vlCumulusCovRemap(cn0, cvS);
    float hgt = 0.0;
    if (cov >= 0.015) { // same clear-sky early-out as vlCumulusField: 1 tap
#if VC32 == 1
        float rA32 = VL_CUM_RAD * 0.5 * VC32_RADK;
        float avA = 0.25 * (vlCumulusCn(cp + vec2(rA32, 0.0), wind)
                          + vlCumulusCn(cp - vec2(rA32, 0.0), wind)
                          + vlCumulusCn(cp + vec2(0.0, rA32), wind)
                          + vlCumulusCn(cp - vec2(0.0, rA32), wind));
        float deep = vlCumulusCovRemap(0.42 * cn0 + 0.58 * avA, cvS);
        hgt = vlCumulusTiers32(deep) * (1.0 - rainStrength * 0.65);
#else
        float rA = VL_CUM_RAD * 0.5;
        float mnA = min(cn0, min(min(vlCumulusCn(cp + vec2(rA, 0.0), wind),
                                     vlCumulusCn(cp - vec2(rA, 0.0), wind)),
                                 min(vlCumulusCn(cp + vec2(0.0, rA), wind),
                                     vlCumulusCn(cp - vec2(0.0, rA), wind))));
        float cvA = vlCumulusCovRemap(mnA, cvS);
        hgt = vlCumulusTiers(cvA, cvA) * (1.0 - rainStrength * 0.65);
#endif
    }
#if VC2 == 1
    float dT = clamp(vc2CovShape(cov) * (0.70 + hgt * 0.90)
                   * (0.80 + CLOUD_SHADOW_SOFTNESS * 0.50), 0.0, 1.0);
#else
    float dT = clamp(cov * (0.70 + hgt * 0.90)
                   * (0.80 + CLOUD_SHADOW_SOFTNESS * 0.50), 0.0, 1.0);
#endif
    return smoothstep(0.0, 1.0, dT);
#else
    // PERF_CSHADOW_CHEAP = 0 : cloudShadowCheap EST cloudShadow, donc la carte
    // porte le champ complet (9 taps + le tap 3D de vc3ShadowMod) -- meme
    // expression que la branche texturee de cloudShadow ci-dessus.
    vec2 fT = vlCumulusField(cp, cloudWorldTime());
#if VC2 == 1 && VC3 == 1
    float dT = clamp(vc2CovShape(fT.x) * (0.70 + fT.y * 0.90)
                   * (0.80 + CLOUD_SHADOW_SOFTNESS * 0.50)
                   * vc3ShadowMod(cp, cloudWorldTime()), 0.0, 1.0);
#elif VC2 == 1
    float dT = clamp(vc2CovShape(fT.x) * (0.70 + fT.y * 0.90)
                   * (0.80 + CLOUD_SHADOW_SOFTNESS * 0.50), 0.0, 1.0);
#else
    float dT = clamp(fT.x * (0.70 + fT.y * 0.90)
                   * (0.80 + CLOUD_SHADOW_SOFTNESS * 0.50), 0.0, 1.0);
#endif
    return smoothstep(0.0, 1.0, dT);
#endif
}

/*
    GEOMETRIE DE LA CARTE (CTM) - trois expressions minuscules, appelees a
    l'identique par le CUISEUR (prepare2.fsh) et par les LECTEURS (ctmShadow
    ci-dessous). Elles ne lisent que cameraPosition et la direction de lumiere
    du MEME frame : cuiseur et lecteurs tombent donc sur la meme grille PAR
    CONSTRUCTION, sans uniform custom et sans stocker l'origine nulle part.
*/
// Deplacement xz par bloc de chute verticale, plancher CTM_MIN_LY (derive au
// bloc RAYONS DE NUAGES : c'est la hauteur de soleil a laquelle un point 160
// blocs sous la camera se projette juste au bord de la carte).
vec2 vlCtmShear(vec3 lightDirW) {
    return lightDirW.xz / max(lightDirW.y, CTM_MIN_LY);
}
// Point camera PROJETE sur le plan des nuages = centre de la carte avant
// ancrage. Centrer la ici (et non sur cameraPosition.xz) divise par deux
// l'etendue necessaire : sans ce centrage il faudrait couvrir l'offset de
// projection ET son excursion.
vec2 vlCtmCpCam(vec2 shear) {
    return cameraPosition.xz + shear * ((VC_BASE + VC_THICK * 0.33) - cameraPosition.y);
}
// ANCRAGE MONDE : decalage du centre dans sa cellule. La grille se pose sur un
// reseau monde de pas CTM_CELL, donc les centres de texel ne rampent pas quand
// la camera bouge (seul le soleil, qui tourne lentement, la fait glisser d'une
// cellule a la fois).
vec2 vlCtmSnap(vec2 cpCam) {
    return cpCam - floor(cpCam * (1.0 / CTM_CELL)) * CTM_CELL;
}

/*
    LECTURE DE LA CARTE : 1 tap bilineaire.

    PAS de sunUpF ici -- c'est tout l'objet du chantier : les faisceaux doivent
    VIVRE au couchant. Le fondu au ras de l'horizon est porte par les
    consommateurs (lightUp pour la marche VL, un smoothstep(-0.02, 0.06, L.y)
    pour fogSunVis), qui savent, eux, ce qu'ils eclairent.

    Hors de la carte -> 1.0 (fail-open, contrat du pack partout ailleurs).
    Au-dessus du plan de projection -> fondu vers 1.0 sur l'epaisseur restante :
    un point DANS ou AU-DESSUS de la dalle n'est pas ombre par elle.

    PRECISION : rel est forme SANS passer par les coordonnees absolues (la
    soustraction wp - cameraPosition est deja payee par l'appelant), donc la
    perte a 30 M de blocs est celle que le pack paie deja partout ailleurs.

    colortex12 : PARTAGE DE TAMPON. Le tampon appartient au path tracing
    dormant (FULL_PATH_TRACE : terme direct RGBA16F plein ecran, ecrit par
    gbuffers_terrain, lu par composite5) -- il n'est alloue ni reference nulle
    part aux valeurs par defaut (VOXEL_GI 0, FULL_PATH_TRACE 0 : les deux
    samplers et les deux listes RENDERTARGETS sont dans des #if). CLOUD_SHAFTS
    le reprend en R8 CTM_RES^2 (size.buffer, shaders.properties) ; les deux
    usages sont mutuellement exclusifs et un #error de lib/settings.glsl le
    dit clairement si on essaie d'allumer les deux.
    La declaration est gardee : composite5.fsh declare aussi ce sampler, mais
    il n'inclut PAS ce fichier (verifie) -- la garde protege les inclusions
    futures, pas un conflit existant.
*/
#ifndef VLX_CTM_DECL
#define VLX_CTM_DECL
uniform sampler2D colortex12;   // CLOUD_SHAFTS: carte de transmittance, R8 CTM_RES^2
#endif
float ctmShadow(vec3 wp, vec3 lightDirW, float darkness) {
#if DIMENSION_FX == 1
    // Meme neutralite que cloudShadow / cloudShadowCheap : aucune couche de
    // cumulus dans le Nether / l'End, et le cuiseur y fait discard (la carte y
    // contient donc du perime qu'il ne faut jamais lire). Branche uniforme,
    // gratuite en Overworld.
    if (dimNether() > 0.5 || dimEnd() > 0.5) return 1.0;
#endif
    float dy = (VC_BASE + VC_THICK * 0.33) - wp.y;
    float slabW = smoothstep(0.0, VC_THICK * 0.33, dy);
    if (slabW <= 0.0) return 1.0;
    vec2 shear = vlCtmShear(lightDirW);
    vec2 rel = (wp.xz - cameraPosition.xz) - shear * (wp.y - cameraPosition.y);
    vec2 uvC = (rel + vlCtmSnap(vlCtmCpCam(shear)) + CTM_RANGE) * (1.0 / (2.0 * CTM_RANGE));
    if (uvC.x < 0.0 || uvC.x > 1.0 || uvC.y < 0.0 || uvC.y > 1.0) return 1.0;
    return 1.0 - texture2D(colortex12, uvC).r * darkness * slabW;
}
#endif

/*
    PERF_CSHADOW_CHEAP - reduced-tap coverage probe for the SECONDARY
    consumers ONLY: the fogSunVis probes (composite1.fsh), the RSM receiver
    gate (composite.fsh) and the csA/csB VL-march probes (composite1.fsh AND
    its mirror lib/vl_halfres.glsl). The cloud RENDER and shadeSurface (the
    visible ground shadow) keep the full cloudShadow above.
    Same projection plane, same coverage remap, same shadow curve as
    cloudShadow's textured branch, but the cumulus field is probed with
    5 taps (center + inner cross) instead of vlCumulusField's 9: the outer
    diagonal ring only exists to drive the tier-B grand-core height, so this
    variant feeds vlCumulusTiers the INNER erosion for both tiers. mnB <= mnA
    by construction, so the only possible deviation is a slight OVER-estimate
    of the tier-B height share deep inside a mass (shadow marginally darker
    there, identical on clear sky / at the edges / under the rain flattening
    - every constant comes from the single-source helpers above, nothing is
    duplicated). The consumers modulate fog / VL / bounce weights that are
    then dithered, TAA-resolved or filtered, so the residual is invisible;
    cost drops from up to 9 field taps to at most 5.
    On the procedural paths (VC_CUMULUS_SHAPES == 0 or VC_TEXTURED == 0)
    there is no tap ring to trim: falls back to cloudShadow verbatim - and
    the gate at 0 is a pure pass-through in EVERY configuration.
*/
float cloudShadowCheap(vec3 wp, vec3 lightDirW) {
#if PERF_CSHADOW_CHEAP == 1 && VC_CUMULUS_SHAPES == 1 && VC_TEXTURED == 1
#if DIMENSION_FX == 1
    // Same Nether/End neutrality as cloudShadow (uniform branch, free).
    if (dimNether() > 0.5 || dimEnd() > 0.5) return 1.0;
#endif
    // Same grazing-sun fade / early-out as cloudShadow.
    float sunUpF = smoothstep(0.06, 0.22, lightDirW.y);
    if (sunUpF <= 0.0) return 1.0;
    // Same projection plane (density barycentre at h ~ 0.33 of the slab).
    vec2 cp = wp.xz + lightDirW.xz / max(lightDirW.y, 0.25) * (VC_BASE + VC_THICK * 0.33 - wp.y);
#ifdef CLOUD_SHAFTS_ACTIVE
    // CLOUD_SHAFTS : SOURCE UNIQUE. Le corps ci-dessous a ete extrait tel quel
    // dans vlCloudOpacityAtPlane() (meme champ, memes courbes, memes taps) pour
    // que le cuiseur de la carte et cette sonde ne puissent pas diverger. La
    // valeur rendue est identique token pour token ; seul le nombre de sites
    // change. A CLOUD_SHAFTS 0 le texte d'origine reprend, verbatim (preuve
    // par hash SPIR-V).
    return 1.0 - vlCloudOpacityAtPlane(cp) * CLOUD_SHADOW_DARKNESS * sunUpF;
#else
    float cvS = clamp(mix(VC2_COVERAGE, 1.0, rainStrength * 0.95), 0.0, 1.0); // full rain = near-total overcast; VC2_COVERAGE == VC_COVERAGE at gate 0
    if (cvS <= 0.0) return 1.0;
    vec2 wind = vlCumulusWind(cloudWorldTime());
    float cn0 = vlCumulusCn(cp, wind);
    float cov = vlCumulusCovRemap(cn0, cvS);
    float hgt = 0.0;
    if (cov >= 0.015) { // same clear-sky early-out as vlCumulusField: 1 tap
#if VC32 == 1
        // VC32 : meme pilote par MOYENNE que vlCumulusField, sur les 5 taps de
        // cette variante (centre + croix interne ; l'anneau externe n'existe
        // pas ici). Ecart assume, de meme nature que celui deja documente en
        // en-tete pour l'erosion : le voisinage moyenne est plus PETIT, donc la
        // profondeur est legerement SUR-estimee au coeur des grandes masses
        // (ombre marginalement plus epaisse la, identique au bord et sur ciel
        // clair). La POSITION des ombres, elle, suit la meme carte meteo.
        float rA32 = VL_CUM_RAD * 0.5 * VC32_RADK;
        float avA = 0.25 * (vlCumulusCn(cp + vec2(rA32, 0.0), wind)
                          + vlCumulusCn(cp - vec2(rA32, 0.0), wind)
                          + vlCumulusCn(cp + vec2(0.0, rA32), wind)
                          + vlCumulusCn(cp - vec2(0.0, rA32), wind));
        float deep = vlCumulusCovRemap(0.42 * cn0 + 0.58 * avA, cvS);
        hgt = vlCumulusTiers32(deep) * (1.0 - rainStrength * 0.65);
#else
        float rA = VL_CUM_RAD * 0.5;
        float mnA = min(cn0, min(min(vlCumulusCn(cp + vec2(rA, 0.0), wind),
                                     vlCumulusCn(cp - vec2(rA, 0.0), wind)),
                                 min(vlCumulusCn(cp + vec2(0.0, rA), wind),
                                     vlCumulusCn(cp - vec2(0.0, rA), wind))));
        float cvA = vlCumulusCovRemap(mnA, cvS);
        // Inner erosion feeds BOTH tiers (see header); same rain flattening
        // as vlCumulusField so the deck goes flat with the render.
        hgt = vlCumulusTiers(cvA, cvA) * (1.0 - rainStrength * 0.65);
#endif
    }
    // Same thickness -> darkness curve as cloudShadow's textured branch.
#if VC2 == 1
    // VC2 parity with cloudShadow: same shared coverage shaper, so the cheap
    // probes (fog / VL / RSM) see the same crisper footprint.
    float dT = clamp(vc2CovShape(cov) * (0.70 + hgt * 0.90)
                   * (0.80 + CLOUD_SHADOW_SOFTNESS * 0.50), 0.0, 1.0);
#else
    float dT = clamp(cov * (0.70 + hgt * 0.90)
                   * (0.80 + CLOUD_SHADOW_SOFTNESS * 0.50), 0.0, 1.0);
#endif
    dT = smoothstep(0.0, 1.0, dT);
    return 1.0 - dT * CLOUD_SHADOW_DARKNESS * sunUpF;
#endif // CLOUD_SHAFTS_ACTIVE (source unique) vs texte d'origine
#else
    return cloudShadow(wp, lightDirW);
#endif
}
#endif
#endif

/*
    ===== OMBRES PIXEL-PERFECT (PIXEL_SHADOWS, lib/settings.glsl) =====
    Snap du RECEVEUR sur la grille des texels de bloc. Doc complete, tableau de
    resolution et perimetre au bloc "OMBRES PIXEL-PERFECT" de lib/settings.glsl.
    Ici, seulement la mecanique et ses deux precautions :

    (1) CENTRE DE TEXEL, pas noeud de grille. Un texel de bloc k couvre
        [n + k/G, n + (k+1)/G] en coordonnees monde, donc c'est floor(w*G) qui
        identifie le texel et (floor(w*G) + 0.5)/G qui en vise le centre. Le
        resultat est constant sur toute la cellule -> tous les pixels d'ecran
        d'un meme texel de bloc lisent la meme visibilite -> marches nettes,
        alignees sur les pixels de la texture.
    (2) PRECISION. cameraPosition peut valoir des centaines de milliers de
        blocs ; multiplier ca par G en float32 detruirait la grille. On
        decompose donc la camera en partie ENTIERE et partie FRACTIONNAIRE de
        grille et on ne fait le floor que sur des nombres de l'ordre de
        shadowDistance*G. Resultat mathematiquement identique a
        (floor(w_abs*G)+0.5)/G, mais exact partout ou l'on joue.
    (3) AXE DOMINANT PRESERVE + REPROJECTION SUR LE PLAN TANGENT : voir le bloc
        de settings. Sur une face de bloc, la correction (3) vaut exactement 0.
*/
#if PIXEL_SHADOWS == 1
// xz absolus (monde) -> centre du texel de bloc. Utilise par les caustiques,
// qui travaillent deja en monde absolu (world0.xz / world1.xz).
vec2 vlxPixSnapXZ(vec2 wxz) {
    return (floor(wxz * PIXEL_SHADOW_GRID) + 0.5) / PIXEL_SHADOW_GRID;
}

// Receveur en espace VUE -> receveur snappe, toujours en espace vue (les
// appelants ne changent pas de forme). viewNormal sert UNIQUEMENT a choisir
// l'axe a ne pas bouger ; une normale nulle (particules / main, qui passent la
// direction de la lumiere ou zero) desactive la reprojection (3).
vec3 vlxPixSnapView(vec3 viewPos, vec3 viewNormal) {
    // mat3(gbufferModelViewInverse) est une rotation pure dans Iris (l'origine
    // de l'espace vue EST la camera), donc w = mat3(gmvi) * viewPos est la
    // position monde RELATIVE a la camera -- exactement ce que toShadowClip et
    // shadowReceiverV2 recalculent juste apres.
    vec3 w  = mat3(gbufferModelViewInverse) * viewPos;
    vec3 nW = mat3(gbufferModelViewInverse) * viewNormal;
    // (2) camera coupee en entier + fraction de grille
    vec3 co  = cameraPosition * PIXEL_SHADOW_GRID;
    vec3 coR = co - floor(co);
    vec3 wS  = (floor(w * PIXEL_SHADOW_GRID + coR) + 0.5 - coR) / PIXEL_SHADOW_GRID;
    // (3) axe monde dominant de la normale : on le laisse EXACT
    vec3 an = abs(nW);
    vec3 ax = (an.x >= an.y && an.x >= an.z) ? vec3(1.0, 0.0, 0.0)
            : ((an.y >= an.z) ? vec3(0.0, 1.0, 0.0) : vec3(0.0, 0.0, 1.0));
    vec3 wOut = mix(wS, w, ax);
    // ... puis on remet le point sur SON plan tangent en ne bougeant que le
    // long de cet axe : constant par cellule (donc les marches restent nettes)
    // et nul sur une face alignee sur un axe.
    float nA = dot(nW, ax);
    wOut += ax * ((abs(nA) > 1e-3) ? dot(nW, w - wOut) / nA : 0.0);
    // monde-relatif -> vue : v * M == transpose(M) * v, et transpose d'une
    // rotation est son inverse, donc ceci vaut mat3(gbufferModelView) * wOut
    // sans avoir a declarer un uniforme de plus.
    return wOut * mat3(gbufferModelViewInverse);
}
#define VLX_PIX_RECV(p, n) vlxPixSnapView(p, n)
#define VLX_PIX_FLOOR(p) vlxPixSnapView(p, vec3(0.0, 1.0, 0.0))
#define VLX_PIX_XZ(w) vlxPixSnapXZ(w)
#else
#define VLX_PIX_RECV(p, n) (p)
#define VLX_PIX_FLOOR(p) (p)
#define VLX_PIX_XZ(w) (w)
#endif

// Maps a view-space point into shadow map clip space, offset along the normal
// to avoid shadow acne.
vec3 toShadowClip(vec3 viewPos, vec3 viewNormal) {
    vec4 wpos = gbufferModelViewInverse * vec4(viewPos, 1.0);
    vec3 wnorm = mat3(gbufferModelViewInverse) * viewNormal;
    wpos.xyz += wnorm * (0.012 + length(viewPos) * 0.0018); // small normal-offset keeps contact shadows of foliage/entities attached; raise it if flat terrain shows acne
    vec4 spos = shadowProjection * (shadowModelView * wpos);
    return spos.xyz;
}

// Same mapping, entered from a CAMERA-RELATIVE world position (world minus
// cameraPosition, i.e. exactly what mat3(gbufferModelViewInverse) * viewPos
// gives and what toShadowClip computes internally before its normal offset).
// No normal offset: the only caller, the UW_SUN_COHERENT shadow probe of the
// volumetric march, already passes toShadowClip(p, vec3(0.0)) today and needs
// to move that point sideways in WORLD space, not in view space.
// toShadowClipWorld(mat3(gbufferModelViewInverse) * p) is identical to
// toShadowClip(p, vec3(0.0)) by construction.
vec3 toShadowClipWorld(vec3 wRel) {
    vec4 spos = shadowProjection * (shadowModelView * vec4(wRel, 1.0));
    return spos.xyz;
}

#ifdef SHAFT_FAR_ACTIVE
/*
    ROUND 2 -- SEGMENT LOINTAIN. Doc complete (mecanisme, constantes, mesures,
    ecarts assumes) : bloc "ROUND 2 : SEGMENT LOINTAIN" de lib/settings.glsl.

    SOURCE UNIQUE. Le corps du segment vit ICI et NULLE PART AILLEURS : les
    deux chemins de marche (composite1.fsh, reference VL_FULL_RES=1, et son
    miroir lib/vl_halfres.glsl) l'APPELLENT avec un bloc textuellement
    identique. C'est plus fort qu'un diff : il n'y a aucune arithmetique a
    tenir en phase entre les deux fichiers.

    v120-safe : composite.fsh (qui inclut le miroir) est en #version 120.
*/

/*
    POIDS DE DONNEE DE LA CARTE. ctmShadow ci-dessus fail-open a 1.0 hors
    carte -- ce qui est le bon choix pour une OMBRE (un faux faisceau sombre
    est pire qu'un manquant), mais le mauvais pour un milieu ADDITIF : la
    brume y existerait sans qu'aucune colonne ne puisse y etre gravee, soit
    exactement le voile que ce chantier doit eviter. Ce poids vaut 1 au coeur
    de la carte, 0 dehors, avec une rampe de SHAFT_FAR_EDGE pour que le terme
    se dissolve au lieu de tracer un bord net dans le ciel. Meme regle que
    UW_SHAFT_FIX3 (C) dans la marche : pas de donnee, pas de lumiere reclamee.

    L'algebre uv est celle de ctmShadow, deliberement RECOPIEE plutot
    qu'extraite : ctmShadow doit rester BIT-IDENTIQUE a la livraison du
    round 1 (preuve par hash SPIR-V a SHAFT_FAR 0), et une extraction
    changerait son texte. Les trois helpers de geometrie (vlCtmShear /
    vlCtmCpCam / vlCtmSnap) restent partages, donc la GRILLE ne peut pas
    diverger ; seule la conversion en uv est ecrite deux fois.
*/
float vlCtmDataW(vec3 wp, vec3 lightDirW) {
    // Au-dessus du plan de projection la carte n'a rien a dire (ctmShadow y
    // rend 1.0 par le fondu slabW) : ce n'est pas un trou de donnee.
    if (wp.y >= (VC_BASE + VC_THICK * 0.33)) return 1.0;
    vec2 shear = vlCtmShear(lightDirW);
    vec2 rel = (wp.xz - cameraPosition.xz) - shear * (wp.y - cameraPosition.y);
    vec2 uvC = (rel + vlCtmSnap(vlCtmCpCam(shear)) + CTM_RANGE) * (1.0 / (2.0 * CTM_RANGE));
    vec2 e2 = min(uvC, vec2(1.0) - uvC);
    return smoothstep(0.0, SHAFT_FAR_EDGE, min(e2.x, e2.y));
}

/*
    LE SEGMENT. In-scatter ADDITIF de [tStart, tEnd] le long de worldDir, en
    unites de lightC, SANS extinction appliquee a la scene (l'appelant
    multiplie par sa propre transmittance de fin de marche et n'y touche pas).

    ESPACEMENT A POIDS EGAL : les bornes de bin sont l'inversion exacte de la
    transmittance d'un milieu homogene de densite sigma (celle de l'ALTITUDE
    CAMERA), donc chaque point porte le meme poids de brume. dt_i est la
    largeur du bin, ce qui fait de la somme une quadrature valable QUEL QUE
    SOIT le vrai profil d'altitude. Meme schema qu'au round 1, ou l'espacement
    lineaire gardait un biais de -0.021 a -0.035 quel que soit le nombre de
    pas ; ici sigma*segL vaut ~0.2, donc les deux se rapprochent, et le repli
    lineaire (invLn = 0) couvre proprement le cas sigma*segL -> 0.
*/
vec3 vlShaftFar(vec3 worldDir, vec3 lightDirW, vec3 lightC, float phaseHG,
                float cosT, float lightUpW, float tStart, float tEnd,
                float dither) {
#if DIMENSION_FX == 1
    // Meme neutralite que ctmShadow : pas de cumulus, donc pas de colonnes, et
    // le Nether / l'End ont deja leur propre milieu dans la marche proche.
    if (dimNether() > 0.5 || dimEnd() > 0.5) return vec3(0.0);
#endif
    float segL = tEnd - tStart;
    if (segL <= 1.0 || lightUpW <= 0.0) return vec3(0.0);
    // Phase : le HG du tronc (deja calcule, boost dusk inclus) melange au
    // terme moleculaire normalise 3/(16 pi) * (1 + cos^2). C'est la part
    // Rayleigh qui porte les colonnes a 90 deg et de dos, ou le lobe avant
    // est mort.
    float phF = mix(phaseHG, 0.0596831 * (1.0 + cosT * cosT), SHAFT_ISO);
    vec3 kC = lightC * (phF * lightUpW);
    float dens0 = SHAFT_TAU / SHAFT_FAR_END;
    float invH = 1.0 / SHAFT_H;
    // sigma de reference pour la REPARTITION des points seulement.
    float sig = dens0 * exp(-max(cameraPosition.y - WATER_LEVEL, 0.0) * invH);
    float E = exp(-sig * segL);
    float oneE = 1.0 - E;
    float invLn = (E < 0.99995) ? (1.0 / log(E)) : 0.0; // 0 -> repli lineaire
    vec3 acc = vec3(0.0);
    float trans = 1.0;
    float prevB = 0.0;
    for (int i = 0; i < SHAFT_FAR_STEPS; i++) {
        float fb = float(i + 1) / float(SHAFT_FAR_STEPS);
        float fs = (float(i) + dither) / float(SHAFT_FAR_STEPS);
        float b1 = (invLn == 0.0) ? (fb * segL) : (segL * log(1.0 - fb * oneE) * invLn);
        float ts = (invLn == 0.0) ? (fs * segL) : (segL * log(1.0 - fs * oneE) * invLn);
        float dti = max(b1 - prevB, 0.0);
        prevB = b1;
        vec3 wp = cameraPosition + worldDir * (tStart + ts);
        // Profil d'altitude ET plafond de la couche melangee : les cumulus se
        // forment SUR l'inversion qui plafonne les aerosols, donc la brume
        // s'arrete a la base de la dalle. C'est ce plafond qui empeche le
        // segment de voiler un nuage DEJA DESSINE, sans lire aucune couverture.
        float d = dens0 * exp(-max(wp.y - WATER_LEVEL, 0.0) * invH)
                * (1.0 - smoothstep(VC_BASE - VC_THICK * 0.33, VC_BASE, wp.y));
        // Pas de "break" ici : une camera AU-DESSUS de la dalle qui regarde
        // vers le bas commence par des pas hors couche et rentre ensuite.
        if (d > 0.0) {
            float vis = ctmShadow(wp, lightDirW, CLOUD_SHADOW_DARKNESS)
                      * vlCtmDataW(wp, lightDirW);
            // 1 tap shadowtex1, uniquement tant que le pas est dans la portee
            // de la carte d'ombre : les montagnes creusent la brume, et au-dela
            // le tap n'est meme pas paye. Fail-open hors carte et au-dela du Z
            // du frustum, comme partout dans la marche.
            if (tStart + ts < shadowDistance) {
                vec3 sc = toShadowClipWorld(wp - cameraPosition);
                float fD = getDistortFactor(sc.xy);
                vec3 sp = distortShadow(sc, fD) * 0.5 + 0.5;
                if (sp.x > 0.0 && sp.x < 1.0 && sp.y > 0.0 && sp.y < 1.0) {
                    float zb = sp.z - 0.0008 * (VLX_SHADOW_ZSCALE * 2.0);
                    float s1 = step(zb, texture2D(shadowtex1, sp.xy).r);
                    vis *= mix(s1, 1.0, step(1.0, zb));
                }
            }
            float a = exp(-d * dti);
            acc += trans * kC * vis * (1.0 - a);
            trans *= a;
        }
    }
    return acc;
}
#endif

#if WCOL_V3 == 1
/*
    WATER_COLOR_V3 -- THE LIGHT LEG OF THE WATER COLUMN.

    THE BUG THIS REPLACES, MEASURED, not assumed. shadow.fsh writes the water's
    own texel (vanilla water_still x biome tint) into the WATER band of
    shadowcolor0, and both PCF samplers below decoded it, boosted its saturation
    x1.4 and used it as the light that reaches every SUBMERGED surface. That is
    a surface ALBEDO used as a TRANSMITTANCE. At the shipped ocean tint
    (texel ~0.30/0.42/0.70, biome 0.247/0.463/0.894) the decoded, boosted
    constant is (0.0237, 0.1922, 0.7961):
      * it removes 97.6% of the RED and 81% of the GREEN from the sun,
      * it does so at 0.1 block of water exactly as hard as at 20,
      * and composite1's Beer-Lambert column then applies a SECOND absorption
        on top of it.
    Consequence measured on a sand floor (albedo 0.76/0.70/0.50) at noon: the
    floor arriving into waterColumn() is (0.350, 1.173, 2.742) instead of
    (5.470, 4.957, 3.375) -- already blue, already dark, already contrast-free.
    Delivered hue then sits at 269-270 deg from 0.5 to 8 blocks of view path and
    the whole 0.5 -> 20 block sweep travels 17.6 deg of hue for a 7.2x luminance
    range. THAT is the "no gradient, milky blue, washed-out bottom" report; it is
    not the in-scatter, whose share of the pixel is only 6.7% at 2 blocks and
    11.7% at 3.

    WHAT V3 DOES INSTEAD. The sun reaching a submerged receiver has crossed a
    KNOWN thickness of water: the shadow map holds the water surface in
    shadowtex0 and the receiver's own depth z, and the difference between them is
    that thickness measured ALONG THE LIGHT AXIS -- which is exactly the leg the
    light travelled, so no lightWy factor is applied here (that factor converts an
    axis distance into a VERTICAL one and belongs to shadowZToVertical, whose
    consumers want a height). Beer-Lambert over that path with the SAME published
    spectrum the view leg uses (VLX_WATER_K_*, mirror of WCOL_K_OUT) and the SAME
    clarity scaling (WATER_DEPTH_DENSITY / WATER_CLARITY) and the SAME per-channel
    dials (WATER_ABSORB_*), so one dial moves both legs of the column together.
    The x1.4 saturation boost is NOT applied to it: that boost exists to make a
    stained-glass ALBEDO read as a tint, and a physical transmittance needs none.

    PACKING: sp.z = (z_clip * VLX_SHADOW_ZSCALE) * 0.5 + 0.5 and the light camera
    is orthographic, so one block along the axis packs to
    |shadowProjection[2].z| * VLX_SHADOW_ZSCALE * 0.5 -- hence the inverse below.
    Same constant as shadowZToVertical() in composite1.fsh, minus its lightWy.

    THREE CONSUMERS, NOT TWO. Besides the two samplers below, the VOLUMETRIC
    light march reads the same WATER band per step (composite1.fsh and its
    mirror lib/vl_halfres.glsl) and now calls this function on the same
    difference, so the beam inside the water and the light it deposits on the
    floor it lights are priced by one spectrum and one set of dials. Until that
    was fixed the march still decoded the tag as a tint: a CONSTANT
    (0.0741, 0.1945, 0.6258), luma 0.2000, R/B 0.118 at EVERY depth, against
    this function's (0.4505, 0.8270, 0.9176), luma 0.7535, R/B 0.491 at 2 blocks
    under a zenith sun -- the beam was 3.77x darker and 4.2x bluer than its own
    lit spot, and the two only crossed near 13 blocks. Under V2 both legs were
    the same constant and agreed by construction, so this mismatch was created
    by V3 and did not exist before it.

    KNOWN, ACCEPTED GAP: the WATER band only exists when SHADOW_TEX1_GATE_FIX = 1.
    With that option at 0 there is no tag to tell water from stained glass, so
    all three consumers fall back to the raw shadowcolor0 rgb and the V3 light
    leg is silently inactive -- the same water then renders as it did under V2.
    The shipped default is 1 and nothing else in the pack reads that combination.
*/
vec3 vlxWaterShadowT(float dzPacked) {
    float t = max(dzPacked, 0.0) * (2.0 / VLX_SHADOW_ZSCALE)
            / max(abs(shadowProjection[2].z), 1e-6);
    t *= WATER_DEPTH_DENSITY / WATER_CLARITY;   // same path scaling as waterColumn()
    // GUARD: a receiver just under the surface can read a slightly NEGATIVE dz
    // through the PCF bias; max() above already pins that to a transmittance of
    // exactly 1.0, i.e. "no water crossed", which is the correct answer there.
    // EAU9 / WATER_COLOR_V4 -- THE LIGHT LEG READS THE SAME MEDIUM AS THE VIEW
    // LEG, AND IT IS THE POINT OF ROUTING IT THROUGH vlxWaterMix3(). If the sun's
    // transmittance kept the pure-water spectrum while the column moved onto this
    // biome's CDOM, the beam and the water it travels through would be two
    // different fluids again -- the defect class EAU4 exists to close, and the one
    // EAU3 already had to fix once on this exact function. The mixer's CLEAR
    // anchor is VLX_WATER_K_* itself, so the OFF state is the same medium.
    // MEASURED, at MID: transmittance under 2.12 blocks of sun goes
    // (0.429, 0.818, 0.913) -> (0.419, 0.768, 0.697). The blue stops
    // over-surviving the light leg, which de-cyanises the floor a SECOND time --
    // and per EAU7 this leg owns 40.5% of that damage.
    // THE OFF BRANCH IS WRITTEN OUT INSTEAD OF LETTING kLeg FOLD TO THE SAME
    // CONSTANT, and the reason is measured, not stylistic: a local initialised
    // from an expression defers constant folding from glslc to spirv-opt for the
    // whole module, and the two folders disagree in the LAST BIT of an unrelated
    // constant elsewhere in the file (slateC, 0.0973193944 against 0.0973194018).
    // Nothing about the rendering changes at 7.6e-8, but "V4 = 0 is the old pack"
    // should not need an asterisk, so the three lines are written twice and the
    // preprocessor hands glslc the pre-EAU9 text verbatim. T is declared in BOTH
    // branches, so nothing below this block depends on which one ran.
#if WCOL_V4 == 1
    vec3 kLeg = vlxWaterMix3(vec3(VLX_WATER_K_R, VLX_WATER_K_G, VLX_WATER_K_B),
                             vec3(WCOL4_K_MID_R,  WCOL4_K_MID_G,  WCOL4_K_MID_B),
                             vec3(WCOL4_K_DARK_R, WCOL4_K_DARK_G, WCOL4_K_DARK_B));
    vec3 T = exp(-t * vec3(kLeg.r * WATER_ABSORB_R,
                           kLeg.g * WATER_ABSORB_G,
                           kLeg.b * WATER_ABSORB_B));
#else
    vec3 T = exp(-t * vec3(VLX_WATER_K_R * WATER_ABSORB_R,
                           VLX_WATER_K_G * WATER_ABSORB_G,
                           VLX_WATER_K_B * WATER_ABSORB_B));
#endif
    // EAU7 -- CHROMA BOUND, NOT A CANCELLATION. This leg is the SECOND strongest
    // term destroying the floor's hue (40.5% of the R/B loss at 2 blocks of view
    // path; the view leg pays 51.3%, the caustic tint 8.1%) and it went missing
    // from every water enumeration the pack ever wrote. The direct term is
    // already multiplied by (0.57,0.87,0.94) under 1.41 block and (0.43,0.82,
    // 0.91) under 2.12 BEFORE composite1 lays its own Beer-Lambert on the same
    // pixel, so the red is absorbed TWICE with the same spectrum. The DARKENING
    // must stay -- it is what makes depth read as depth -- so only the chroma is
    // pulled back, at EXACTLY constant Rec.709 luminance (mix toward luma() is
    // luminance-preserving by construction, so luma(result) == luma(T)).
    // Posed HERE and not at the call sites on purpose: all four consumers (the
    // legacy sampler, sampleShadowPCFV2, the VL march in composite1.fsh and its
    // mirror lib/vl_halfres.glsl) then move together, so the beam and the spot
    // it lights cannot drift apart again. WLEG_CHROMA_CUT 0.0 = pre-EAU7.
    return mix(T, vec3(luma(T)), WLEG_CHROMA_CUT);
}
#endif

/*
    PCSS shadows: blocker search estimates penumbra size (the farther the
    occluder, the softer the shadow), then a Vogel-disk PCF.
    Returns RGB visibility - stained glass tints the light.
*/
vec3 sampleShadowPCF(vec3 shadowClip, float dither) {
    float f = getDistortFactor(shadowClip.xy);
    vec3 sp = distortShadow(shadowClip, f) * 0.5 + 0.5;

    if (sp.x < 0.0 || sp.x > 1.0 || sp.y < 0.0 || sp.y > 1.0) return vec3(1.0);

    // Bias is expressed in tex-z units calibrated for a 0.5 packing; the
    // (VLX_SHADOW_ZSCALE * 2.0) factor keeps the same WORLD-space bias for any
    // SHADOW_Z_SCALE (exact no-op at 0.5).
    float bias = (0.00012 + 0.00010 * f) * (VLX_SHADOW_ZSCALE * 2.0); // ~0.14 block of Peter-Pan; if flat terrain shows acne under a grazing sun, raise the normal-offset in toShadowClip BEFORE touching this bias.
    float z = sp.z - bias;
    // Receiver BEYOND the shadow frustum Z range: nothing testable, so fail
    // OPEN (lit) and let shadeSurface's sfade/lightmap take over. A step() here
    // would return a false BLACK in the distance.
    if (z >= 1.0) return vec3(1.0);
#if PIXEL_SHADOWS == 1 && PIXEL_SHADOW_HARD == 1
    // ---- PIXEL_SHADOWS + PIXEL_SHADOW_HARD : bord DUR, un seul tap ----
    // Variante BINAIRE hors menu (PIXEL_SHADOW_HARD, lib/settings.glsl). Par
    // defaut (0) c'est le #else qui s'applique : le receveur est snappe PUIS
    // filtre par la PCSS normale autour du centre du texel -- "flouter puis
    // pixeliser" : la penombre garde sa largeur physique (elle grandit avec
    // la distance au bloqueur) et chaque texel de bloc recoit UNE valeur.
    // Le receveur a deja ete ramene au centre de son texel de bloc par
    // getShadow / le site appelant, donc tous les pixels de ce texel lisent
    // CE tap : elargir le noyau ne ferait qu'effacer la marche qu'on cherche.
    // Meme decodage de teinte (verre, bande eau) que la boucle PCF ci-dessous,
    // au meme offset 0 -- seul le nombre de taps change (2 au lieu de
    // 2 + 10 + 2*SHADOW_SAMPLES).
    {
        float z0 = texture2D(shadowtex0, sp.xy).r;
        float s0 = step(z, z0);                                 // everything
        float s1 = step(z, texture2D(shadowtex1, sp.xy).r);     // opaque only
        vec3 col = vec3(1.0);
#if WCOL_V3 == 1
        float wTagV3 = 0.0;
#endif
#if SHADOW_TEX1_GATE_FIX == 1
        if (s0 < s1) {
            vec4 sc0 = texture2D(shadowcolor0, sp.xy);
            float tagMx = max(max(sc0.r, sc0.g), sc0.b);
#if WCOL_V3 == 1
            if (tagMx < 0.325) { col = vlxWaterShadowT(z - z0); wTagV3 = 1.0; }
#else
            if (tagMx < 0.325)      col = clamp(sc0.rgb / 0.30, 0.0, 1.0);
#endif
            else if (tagMx < 0.675) col = clamp((sc0.rgb - 0.35) / 0.30, 0.0, 1.0);
            else s1 = 0.0;
        }
#else
        if (s0 < s1) col = texture2D(shadowcolor0, sp.xy).rgb;
#endif
#if WCOL_V3 == 1
        if (wTagV3 < 0.5) col = max(mix(vec3(luma(col)), col, 1.4), vec3(0.0));
#else
        col = max(mix(vec3(luma(col)), col, 1.4), vec3(0.0));
#endif
        return s1 * mix(col, vec3(1.0), s0);
    }
#else
    float texel = 1.0 / float(shadowMapResolution) / f;

    float radius;
    #ifdef PCSS
        // Blocker search: 5 samples
        float searchR = 12.0 * texel;
        float blockerSum = 0.0;
        float blockerCnt = 0.0;
        float blocker0Cnt = 0.0;
        for (int i = 0; i < 5; i++) {
            float a = float(i) * 2.4 + dither * 6.2831853;
            float r = sqrt((float(i) + 0.5) / 5.0);
            vec2 o = vec2(cos(a), sin(a)) * r * searchR;
            float zb = texture2D(shadowtex1, sp.xy + o).r;
            if (zb < z) { blockerSum += zb; blockerCnt += 1.0; }
            // tex0 too (translucents: water/glass) for the early-out below
            if (texture2D(shadowtex0, sp.xy + o).r < z) blocker0Cnt += 1.0;
        }
        // Early-out: NO blocker at all (opaque or translucent) inside the search
        // radius (12 texels >> the blocker-free PCF radius of ~0.4 texel x
        // SOFTNESS) means full sun, so the SHADOW_SAMPLES PCF taps are skipped.
        // This is the majority case outdoors during the day.
        if (blockerCnt < 0.5 && blocker0Cnt < 0.5) return vec3(1.0);
        // Penumbra tuning: the real sun (0.53 deg) gives ~0.01 block of penumbra
        // per block of occluder distance. Floor 0.30 keeps contact shadows crisp
        // (a higher floor dissolves small casters such as entities), slope 35
        // and cap 4 control distant softness. Both remain user-drivable through
        // the SHADOW_SOFTNESS / LIGHT_SIZE sliders.
        float penumbra = 0.30;
        if (blockerCnt > 0.5) {
            float zb = blockerSum / blockerCnt;
            // (z - zb) is in PACKED tex-z units (proportional to
            // VLX_SHADOW_ZSCALE) and the 35.0 slope is calibrated for packing
            // 0.5, hence the (0.5 / VLX_SHADOW_ZSCALE) compensation: without it
            // the SHADOW_Z_SCALE slider silently changes shadow softness.
            // LIGHT_SIZE is now calibrated in real-sun units (default 3.0, see
            // lib/settings.glsl): (LIGHT_SIZE * 0.25 / 3.0) folds to exactly
            // 0.25 at that default (left-to-right: 0.75 / 3.0), so this legacy
            // path stays bit-identical to the pre-V2 pack.
            penumbra += clamp((z - zb) * 35.0 * (0.5 / VLX_SHADOW_ZSCALE) * (LIGHT_SIZE * 0.25 / 3.0) * float(shadowMapResolution) * 0.001, 0.0, 4.0);
        }
        radius = penumbra * texel * SHADOW_SOFTNESS * 1.2;
        radius = max(radius, 0.6 * texel); // anti-alias floor: never below ~0.6 texel (clean hard edges, no staircasing)
    #else
        radius = SHADOW_SOFTNESS * 2.5 * texel;
    #endif

    vec3 shadow = vec3(0.0);
    for (int i = 0; i < SHADOW_SAMPLES; i++) {
        float a = float(i) * 2.4 + dither * 6.2831853;
        float r = sqrt((float(i) + 0.5) / float(SHADOW_SAMPLES));
        vec2 o = vec2(cos(a), sin(a)) * r * radius;

        // z0 hoisted out of the step(): WATER_COLOR_V3 needs the RAW depth of the
        // translucent blocker to price the light leg (vlxWaterShadowT above).
        // No extra tap, and step() sees the same value it always did.
        float z0 = texture2D(shadowtex0, sp.xy + o).r;
        float s0 = step(z, z0);                                 // everything
        float s1 = step(z, texture2D(shadowtex1, sp.xy + o).r); // opaque only

        vec3 col = vec3(1.0);
#if WCOL_V3 == 1
        // 1.0 once the WATER band handed back a physical transmittance: the x1.4
        // saturation boost below must not touch it (see vlxWaterShadowT).
        float wTagV3 = 0.0;
#endif
#if SHADOW_TEX1_GATE_FIX == 1
        // RGB-band receiver tag (blend-robust; encoded in shadow.fsh). The tag lives in
        // RGB BANDS and alpha is forced to 1.0 on write so it survives the Iris shadow
        // pass alpha blend (an alpha-encoded tag gets destroyed and light tints vanish).
        // max(rgb) < 0.325 = WATER (tint decoded), < 0.675 = GLASS/PORTAL (tint decoded),
        // otherwise SOLID tex0-only OR a texel never written (white clear) -> FULL
        // OCCLUSION in both cases. Fail-safe: small casters shadow as soon as their depth
        // is in shadowtex0, even if their color write does not land.
        if (s0 < s1) {
            vec4 sc0 = texture2D(shadowcolor0, sp.xy + o);
            float tagMx = max(max(sc0.r, sc0.g), sc0.b);
#if WCOL_V3 == 1
            if (tagMx < 0.325) { col = vlxWaterShadowT(z - z0); wTagV3 = 1.0; }
#else
            if (tagMx < 0.325)      col = clamp(sc0.rgb / 0.30, 0.0, 1.0);
#endif
            else if (tagMx < 0.675) col = clamp((sc0.rgb - 0.35) / 0.30, 0.0, 1.0);
            else s1 = 0.0;
        }
#else
        if (s0 < s1) col = texture2D(shadowcolor0, sp.xy + o).rgb;
#endif
        // boost the tint of colored shadows (blue water, stained glass)
#if WCOL_V3 == 1
        // ... but never the V3 water leg: it is already a transmittance.
        if (wTagV3 < 0.5) col = max(mix(vec3(luma(col)), col, 1.4), vec3(0.0));
#else
        col = max(mix(vec3(luma(col)), col, 1.4), vec3(0.0)); // clamp >=0: the 1.4 extrapolation can push channels negative
#endif
        shadow += s1 * mix(col, vec3(1.0), s0);
    }
    return shadow / float(SHADOW_SAMPLES);
#endif
}

#if PERF_WATER_SHADOW == 1 && SHADOW_V2 == 1
/*
    C1a (LOT C, lib/settings.glsl) - ombre allegee de la SURFACE D'EAU.
    GATE DOUBLE : les samplers shadowtex0/1HW (sampler2DShadow) n'existent que
    sous SHADOW_V2 == 1 (voir leur declaration en tete de ce fichier). Au
    chemin legacy SHADOW_V2 == 0 (hors menu), l'eau garde son sampleShadowPCF
    complet -- le gate est INERTE la-bas, note au bloc LOT C de settings.glsl.
    Un seul consommateur : le wShadow de la branche eau de composite1 (qui
    reste volontairement sur la chaine legacy sous SHADOW_V2, voir le
    commentaire du site). Memes clip/distorsion/biais/early-out que
    sampleShadowPCF ci-dessus, budget reduit :
      - recherche de bloqueur : 3 positions (6 taps : tex1 brut pour la
        penombre + tex0HW pour l'early-out eclaire) au lieu de 5x2 = 10 ;
      - PCF : 6 taps MATERIELS (shadow2D 2x2 bilineaire par tap, memes
        samplers shadowtex0/1HW que sampleShadowPCFV2) au lieu de
        SHADOW_SAMPLES x 2-3 taps logiciels ;
      - viewDist > 60 blocs : recherche SAUTEE ENTIEREMENT (penombre FIXE
        1.1 texel -- l'ombre y module un reflet quasi pur ciel, la largeur
        exacte de penombre est invisible) + sonde eclairee 2 taps tex0HW
        pour que l'ocean lointain ENSOLEILLE (cas majoritaire) coute 2 taps
        et pas 12.
    Retour SCALAIRE : wShadow n'est consomme qu'en luma. La teinte des
    ombres colorees (verre / bande eau) passe a un passe-partout NEUTRE 0.65
    par tap translucide (s0 < s1) -- ecart assume, documente au gate.
    Fail-open identique au legacy (hors carte / hors plage Z -> 1.0).
*/
float sampleShadowWaterLite(vec3 shadowClip, float dither, float viewDist) {
    float f = getDistortFactor(shadowClip.xy);
    vec3 sp = distortShadow(shadowClip, f) * 0.5 + 0.5;

    if (sp.x < 0.0 || sp.x > 1.0 || sp.y < 0.0 || sp.y > 1.0) return 1.0;

    // Meme calibration de biais que sampleShadowPCF (voir la note la-bas).
    float bias = (0.00012 + 0.00010 * f) * (VLX_SHADOW_ZSCALE * 2.0);
    float z = sp.z - bias;
    if (z >= 1.0) return 1.0;
#if PIXEL_SHADOWS == 1 && PIXEL_SHADOW_HARD == 1
    // ---- PIXEL_SHADOWS + PIXEL_SHADOW_HARD : bord DUR, un seul tap 2x2 materiel ----
    // Variante BINAIRE hors menu ; par defaut (PIXEL_SHADOW_HARD 0) le #else
    // garde la recherche de bloqueur + les 6 taps PCF autour du receveur
    // snappe (meme contrat que les deux echantillonneurs ci-dessus).
    // Meme contrat que le tap dur de sampleShadowPCF : le receveur est deja au
    // centre de son texel de bloc, la penombre n'a plus de sens. 2 taps au lieu
    // de 6 a 12. Le passe-partout neutre 0.65 du translucide est conserve.
    {
        float s1 = shadow2D(shadowtex1HW, vec3(sp.xy, z)).r; // opaque seulement
        float s0 = shadow2D(shadowtex0HW, vec3(sp.xy, z)).r; // tout
        s1 = max(s1, s0);
        return s0 + (s1 - s0) * 0.65;
    }
#else
    float texel = 1.0 / float(shadowMapResolution) / f;

    float penumbra = 1.1; // > 60 blocs : largeur fixe, aucune recherche payee
    #ifdef PCSS
    if (viewDist < 60.0) {
        // Recherche 3 positions, meme rayon 12 texels / meme spirale que le
        // legacy (angle d'or 2.4, dither identique) -> meme penombre moyenne.
        float searchR = 12.0 * texel;
        float blockerSum = 0.0;
        float blockerCnt = 0.0;
        float lit0 = 0.0;
        for (int i = 0; i < 3; i++) {
            float a = float(i) * 2.4 + dither * 6.2831853;
            float r = sqrt((float(i) + 0.5) / 3.0);
            vec2 o = vec2(cos(a), sin(a)) * r * searchR;
            float zb = texture2D(shadowtex1, sp.xy + o).r;
            if (zb < z) { blockerSum += zb; blockerCnt += 1.0; }
            // tex0 en COMPARE materiel : couvre opaque ET translucide pour
            // l'early-out (le meme role que le blocker0Cnt legacy).
            lit0 += shadow2D(shadowtex0HW, vec3(sp.xy + o, z)).r;
        }
        // Plein soleil sur les 3 positions : les 6 taps PCF sont sautes
        // (majorite du plein jour, meme contrat que l'early-out legacy).
        if (blockerCnt < 0.5 && lit0 > 2.999) return 1.0;
        penumbra = 0.30;
        if (blockerCnt > 0.5) {
            float zb = blockerSum / blockerCnt;
            // Meme pente/plancher/plafond que le legacy (voir sampleShadowPCF).
            penumbra += clamp((z - zb) * 35.0 * (0.5 / VLX_SHADOW_ZSCALE) * (LIGHT_SIZE * 0.25 / 3.0) * float(shadowMapResolution) * 0.001, 0.0, 4.0);
        }
    }
    #endif
    float radius = max(penumbra * texel * SHADOW_SOFTNESS * 1.2, 0.6 * texel);
    #ifdef PCSS
    if (viewDist >= 60.0) {
        // Sonde eclairee 2 taps (centre + bord du disque PCF, tex0 = tout) :
        // sans elle le lointain ENSOLEILLE paierait toujours les 6 taps.
        float aP = dither * 6.2831853;
        float litP = shadow2D(shadowtex0HW, vec3(sp.xy, z)).r
                   + shadow2D(shadowtex0HW, vec3(sp.xy + vec2(cos(aP), sin(aP)) * radius, z)).r;
        if (litP > 1.999) return 1.0;
    }
    #endif

    // PCF 6 taps materiels, meme disque de Vogel que le legacy.
    float shadow = 0.0;
    for (int i = 0; i < 6; i++) {
        float a = float(i) * 2.4 + dither * 6.2831853;
        float r = sqrt((float(i) + 0.5) / 6.0);
        vec2 o = vec2(cos(a), sin(a)) * r * radius;
        float s1 = shadow2D(shadowtex1HW, vec3(sp.xy + o, z)).r; // opaque seulement
        float s0 = shadow2D(shadowtex0HW, vec3(sp.xy + o, z)).r; // tout
        s1 = max(s1, s0);
        // s0 = part pleinement eclairee, (s1 - s0) = part sous un caster
        // translucide -> passe-partout neutre 0.65 (ecart documente au gate).
        shadow += s0 + (s1 - s0) * 0.65;
    }
    return shadow * (1.0 / 6.0);
#endif
}
#endif

#if SHADOW_V2 == 1
/*
    SHADOW_V2 - texel-proportional bias, hardware PCF, physical PCSS.
    Geometry (Iris ortho frustum: near 0.05 / far 256, light camera 100 blocks
    from the player): packed depth per block along the light axis =
    0.5 * SHADOW_Z_SCALE * |shadowProjection[2].z| (7.8e-4 at Z_SCALE 0.2),
    undistorted texel T0 = 2 * shadowDistance / res (0.1875 blk MEDIUM, 0.125
    HIGH). The distortion u = x / f(d), f = d*S + (1-S), magnifies by 1/f
    tangentially and by (1-S)/f^2 radially: the texel footprint is T0*f
    tangential and T0*f^2/(1-S) radial (both 0.019 blk at the player for
    MEDIUM, 0.0125 HIGH; at d=0.5 the radial texel is already 3*T0). Tb below
    is the footprint of ONE texel measured along the receiver's uphill
    direction (the only direction that can cause acne), i.e. between the two.
    Legacy numbers this replaces (MEDIUM / HIGH at the player): depth bias
    0.0665 blk = 3.5 / 5.3 texels, normal offset 0.012-0.02 blk, PCF floor 0.6
    * T0 = 6 texels radius (0.225 / 0.15 blk blur DIAMETER even at contact),
    blocker disc of 5 taps at 0.71-2.13 blk from the receiver and NO center tap
    (a thin post loses ~1/3 of its shadow, verified by simulation), and 10-13%
    self-shadowing of flat ground below 35 deg of sun. Foot of a vertical thin
    caster on flat ground starts at bias*cos(sunElev): 2-4.4 texels legacy vs
    0.8-1.4 texels here, on top of a blur floor 6x smaller.
    BIAS: n_off = Tb * (1 + 1.5*(1-NdotL)) along the normal, depth bias b =
    Tb * SHADOW_BIAS_TEXELS along the light. With every tap plane-compensated
    (below), only the 2x2 hardware footprint (<= 1.41 texels along uphill, plus
    ~0.2 texel of per-vertex distortion error near the player) can self-shadow:
    the condition n_off/cos(theta) + b >= delta*tan(theta) holds with a margin
    >= x1.5 at every angle along the map axes (theta 45: 3.2 vs 1.6; 80: 14.4
    vs 9.1; 89: 144 vs 92). When uphill runs diagonally between the coarse
    radial and the fine tangential axis (d >= 0.3), the true L1 extent of the
    2x2 corners reaches ~2.3x the 1.41*Tb model and the real margin tightens
    to ~1.05-1.15x — only on corner texels of <= 10% bilinear weight at sun
    <= 10 deg, so the residual is absorbed by that weight (exhaustive
    simulation, elev 5-80 / d 0.02-0.85 / phi 0-45, exact and per-vertex maps,
    MEDIUM+HIGH: vis = 1.000 everywhere). SHADOW_BIAS_TEXELS below ~1.0 eats
    this diagonal reserve first (far receivers at grazing sun). Far away Tb
    grows with the coarse texels, so acne stays impossible.
    RECEIVER-PLANE BIAS: every tap compares against the tangent-plane depth at
    its own offset (gradient g from the GEOMETRIC normal, see shadowReceiverV2),
    so a floor lit by a low sun does not self-shadow inside wide penumbrae (the
    legacy gray halo around tree shadows at sun elevation < 35 deg) and the
    blocker search no longer sees the receiver's own plane uphill (clean
    early-out on lit floors). Clamped at |n.z| >= 0.15 (tan <= 6.6).
    PCSS: penumbra RADIUS = 0.5 * 0.0093 * LIGHT_SIZE * SHADOW_SOFTNESS *
    blocker distance (blocks along the light, from the packed delta), floor 1
    distorted texel, cap VLX_PCSS_CAP. Taps are generated as a circle in WORLD
    space and mapped to uv through the Jacobian J of the distortion, so the
    penumbra is round on the ground instead of radially smeared at distance.
    The blocker-search disc is the largest penumbra this receiver can have
    (lsize x distance to the near plane, capped), probed with a center tap plus
    VLX_SEARCH_TAPS, which follows SHADOW_QUALITY: 4 / 5 / 8 / 10.
*/
#define VLX_SUN_ANGLE 0.0093
#define VLX_PCSS_CAP 2.0
// VLX_SEARCH_TAPS follows SHADOW_QUALITY. It was 5 / 5 / 8 / 8 -- flat on BOTH
// the 0->1 and the 2->3 step, so the top tier bought nothing here. The tiers
// now move at every step: the blocker-search disc is what sets how STABLE the
// penumbra width is (a badly sampled disc makes the penumbra flicker between
// neighbouring pixels), so it belongs on the same ladder as SHADOW_SAMPLES.
// Tier 1 keeps its shipped 5 (default tier, non-regression rule); tier 0 drops
// to 4 (it is the "Bas" tier and each tap costs 2 texture reads), tier 3 goes
// to 10. Cost: 2 shadow taps per search tap.
#if SHADOW_QUALITY >= 3
#define VLX_SEARCH_TAPS 10
#elif SHADOW_QUALITY == 2
// PERF_SHADOW_TAPS (LOT B, B1, lib/settings.glsl) : 8 -> 6 a CE palier
// seulement, jumeau du SHADOW_SAMPLES 12 -> 8 du meme gate. 6 reste au-dessus
// des 5 du palier 1 : la monotonie de l'axe tient aux deux compteurs.
#if PERF_SHADOW_TAPS == 1
#define VLX_SEARCH_TAPS 6
#else
#define VLX_SEARCH_TAPS 8
#endif
#elif SHADOW_QUALITY == 1
#define VLX_SEARCH_TAPS 5
#else
#define VLX_SEARCH_TAPS 4
#endif

// Receiver setup shared by sampleShadowPCFV2 and debugShadowClassify.
// sp   = distorted map position after the normal offset (xy in [0,1], z packed)
// zRef = sp.z minus the depth bias (packed)
// J    = shadow-view xy offset in blocks -> distorted uv offset (mat2)
// g    = receiver-plane depth gradient (packed depth per block of xy offset)
// Tb   = texel footprint used for the bias (blocks): the size of ONE map texel
//        measured along the receiver's uphill direction (between the tangential
//        T0*f and the radial T0*f^2/(1-S) footprints), tangential when face-on.
// hw   = true: compare with the hardware 2x2 samplers (uphill texel < 2x the
//        tangential one: the whole near field, and side-lit surfaces at any
//        distance). false: far sun-aligned receivers, where the radial texel is
//        up to 5x the tangential one and a footprint-sized bias would eat the
//        first half block of every shadow (simulated: 39% of a 2-block pillar's
//        shadow at 100 blocks). There the taps compare against the LINEAR-
//        interpolated raw depth, exact on planes with the per-tap plane term,
//        so the bias drops to 1/4 of a texel (legacy-level contact far away).
// Returns false outside the map (callers fail open).
bool shadowReceiverV2(vec3 viewPos, vec3 viewNormal, out vec3 sp, out float zRef, out mat2 J, out vec2 g, out float Tb, out bool hw) {
#if PIXEL_SHADOWS == 1
    // PIXEL_SHADOWS, piege du PLAN RECEVEUR : la pente ci-dessous vient de
    // dFdx/dFdy(viewPos). Une position SNAPPEE a des derivees nulles a
    // l'interieur d'un texel et enormes a la frontiere, donc le gradient est
    // pris AVANT le snap -- et ici, hors du if (NdotL < 0.999), donc en
    // controle uniforme, ce que dFdx exige formellement de toute facon.
    vec3 nGeoP = cross(dFdx(viewPos), dFdy(viewPos));
    // ... puis, et seulement ensuite, le receveur est ramene au centre de son
    // texel de bloc. C'est LE site unique du snap pour tout le chemin V2 :
    // shadeSurface (terrain, entites, main, eau, terrain differe de deferred1)
    // et debugShadowClassify passent tous par ici.
    viewPos = vlxPixSnapView(viewPos, viewNormal);
#endif
    vec3 pS = (shadowModelView * (gbufferModelViewInverse * vec4(viewPos, 1.0))).xyz;
    vec3 nS = mat3(shadowModelView) * (mat3(gbufferModelViewInverse) * viewNormal);
    float nl = length(nS);
    // Normal-less receivers (light-direction offset of particles/hand): +z is the light.
    nS = (nl > 1e-4) ? nS / nl : vec3(0.0, 0.0, 1.0);
    float NdotL = clamp(nS.z, 0.0, 1.0);
    float P00 = abs(shadowProjection[0][0]);                   // clip units per block (ortho xy)
    float texel = 1.0 / float(shadowMapResolution);
    vec4 sc = shadowProjection * vec4(pS, 1.0);
    float f = getDistortFactor(sc.xy);
    // Jacobian of u = x / f(d), d = cbrt(|x|^3 + |y|^3): du_i/dx_j = delta_ij/f - x_i*f'(d)*dd_j/f^2,
    // then clip -> uv (x P00 x 0.5). Column-major mat2 (J * v). Evaluated at the
    // un-offset position (the offset below moves it by ~2 texels: no visible change).
    // f'(d) comes from getDistortDeriv (lib/distort.glsl): the legacy constant
    // slope S under SHADOW_LOD_V2 0 (bit-identical to the old hard-coded
    // VLX_SHADOW_DISTORT here), the plateau/ramp analytic derivative under 1 --
    // Tb, the PCSS disc and the hw gate below all follow the real local texel.
    vec2 x = sc.xy;
    float d = pow(abs(x.x * x.x * x.x) + abs(x.y * x.y * x.y), 1.0 / 3.0);
    vec2 dd = vec2(x.x * abs(x.x), x.y * abs(x.y)) / max(d * d, 1e-6);
    float fi = 1.0 / f;
    float k = getDistortDeriv(d, f) * fi * fi;
    J = mat2(fi - x.x * k * dd.x, -x.y * k * dd.x,
             -x.x * k * dd.y, fi - x.y * k * dd.y) * (0.5 * P00);
    // Tangent plane: dz_view = -(n.xy . o) / n.z per block of xy offset, packed with dPerBlock
    // (shadowProjection[2].z < 0: farther = larger depth). The plane comes from the
    // GEOMETRIC normal (screen derivatives of viewPos, orientation-free since g is
    // invariant under n -> -n): the shading normal may be normal-mapped (PBR) or a
    // wave normal (water), and a fake slope would turn the receiver's own flat
    // surface into a blocker inside wide penumbrae. On crease / silhouette pixels
    // the derivative quad straddles two faces, so a derivative normal more than
    // 30 degrees away from the shading normal falls back to the shading normal.
    // Particles / hand pass the light direction as normal (NdotL = 1): no plane.
    float dPerBlock = 0.5 * VLX_SHADOW_ZSCALE * abs(shadowProjection[2].z);
    g = vec2(0.0);
    float Tt = 2.0 * f * texel / P00;                          // tangential footprint T0*f
    Tb = Tt;                                                   // face-on: no uphill direction
    if (NdotL < 0.999) {
#if PIXEL_SHADOWS == 1
        vec3 nG = mat3(shadowModelView) * (mat3(gbufferModelViewInverse) * nGeoP); // derivee prise avant le snap, voir le haut de la fonction
#else
        vec3 nG = mat3(shadowModelView) * (mat3(gbufferModelViewInverse) * cross(dFdx(viewPos), dFdy(viewPos)));
#endif
        float nGl = length(nG);
        nG = (nGl > 1e-12 && abs(dot(nG, nS)) > 0.866 * nGl) ? nG / nGl : nS;
        float nz = (nG.z >= 0.0) ? max(nG.z, 0.15) : min(nG.z, -0.15);
        g = nG.xy * (dPerBlock / nz);
        // Texel footprint along the uphill direction: one uv texel along J*up.
        float upl = length(nG.xy);
        if (upl > 1e-3) Tb = texel / max(length(J * (nG.xy / upl)), 1e-6);
    }
    hw = Tb < 2.0 * Tt;
    float bk = hw ? 1.0 : 0.25;
    // Slope-scaled normal offset: 1 texel face-on, 2.5 texels grazing.
    pS += nS * (bk * Tb * (1.0 + 1.5 * (1.0 - NdotL)));
    sc = shadowProjection * vec4(pS, 1.0);
    f = getDistortFactor(sc.xy);
    sp = distortShadow(sc.xyz, f) * 0.5 + 0.5;
    zRef = sp.z - bk * Tb * SHADOW_BIAS_TEXELS * dPerBlock;
    return !(sp.x < 0.0 || sp.x > 1.0 || sp.y < 0.0 || sp.y > 1.0);
}

vec3 sampleShadowPCFV2(vec3 viewPos, vec3 viewNormal, float dither) {
    vec3 sp; float zRef; mat2 J; vec2 g; float Tb; bool hw;
    if (!shadowReceiverV2(viewPos, viewNormal, sp, zRef, J, g, Tb, hw)) return vec3(1.0);
    // Receiver beyond the frustum Z range: nothing testable, fail open (see legacy).
    if (zRef >= 1.0) return vec3(1.0);
#if PIXEL_SHADOWS == 1 && PIXEL_SHADOW_HARD == 1
    // ---- PIXEL_SHADOWS + PIXEL_SHADOW_HARD : bord DUR, un seul tap ----
    // Variante BINAIRE hors menu (PIXEL_SHADOW_HARD, lib/settings.glsl). Par
    // defaut (0) c'est le #else qui s'applique : le receveur est snappe PUIS
    // filtre par la PCSS normale autour du centre du texel -- "flouter puis
    // pixeliser" : la penombre garde sa largeur physique (elle grandit avec
    // la distance au bloqueur) et chaque texel de bloc recoit UNE valeur.
    // shadowReceiverV2 a deja ramene le receveur au centre de son texel de
    // bloc : tous les pixels d'ecran de ce texel lisent CE tap, donc la
    // penombre PCSS (recherche de bloqueurs + disque de Vogel) n'aurait plus
    // rien a dimensionner et ne ferait qu'effacer la marche. On garde le tap
    // 2x2 MATERIEL la ou le chemin V2 l'utilise (hw) : il n'adoucit pas le
    // bord visible, il anti-crenele la quantification propre a la CARTE ; sur
    // les receveurs lointains alignes soleil (hw == false) V2 compare la
    // profondeur brute, donc step(). Meme decodage de teinte / meme
    // comptabilite s0/s1 que la boucle PCF, au meme offset 0.
    // 2 a 3 taps au lieu de 2 + 2*VLX_SEARCH_TAPS + 2*SHADOW_SAMPLES.
    {
        float zt = min(zRef, 0.99999);
        float s1, s0;
        if (hw) {
            s1 = shadow2D(shadowtex1HW, vec3(sp.xy, zt)).r;
            s0 = shadow2D(shadowtex0HW, vec3(sp.xy, zt)).r;
        } else {
            s1 = step(zt, texture2D(shadowtex1, sp.xy).r);
            s0 = step(zt, texture2D(shadowtex0, sp.xy).r);
        }
        s1 = max(s1, s0);
        vec3 col = vec3(1.0);
#if WCOL_V3 == 1
        float wTagV3 = 0.0;
#endif
        if (s0 < s1 - 0.001) {
            vec4 sc0 = texture2D(shadowcolor0, sp.xy);
#if SHADOW_TEX1_GATE_FIX == 1
            float tagMx = max(max(sc0.r, sc0.g), sc0.b);
#if WCOL_V3 == 1
            if (tagMx < 0.325) { col = vlxWaterShadowT(zt - texture2D(shadowtex0, sp.xy).r); wTagV3 = 1.0; }
#else
            if (tagMx < 0.325)      col = clamp(sc0.rgb / 0.30, 0.0, 1.0);
#endif
            else if (tagMx < 0.675) col = clamp((sc0.rgb - 0.35) / 0.30, 0.0, 1.0);
            else s1 = s0;
#else
            col = sc0.rgb;
#endif
        }
#if WCOL_V3 == 1
        if (wTagV3 < 0.5) col = max(mix(vec3(luma(col)), col, 1.4), vec3(0.0));
#else
        col = max(mix(vec3(luma(col)), col, 1.4), vec3(0.0));
#endif
        return vec3(s0) + (s1 - s0) * col;
    }
#else
    float dPerBlock = 0.5 * VLX_SHADOW_ZSCALE * abs(shadowProjection[2].z);
    float texel = 1.0 / float(shadowMapResolution);
    // Penumbra RADIUS per block of blocker distance (real sun x LIGHT_SIZE x SOFTNESS).
    float lsize = 0.5 * VLX_SUN_ANGLE * LIGHT_SIZE * SHADOW_SOFTNESS;
    // Disc rotation: spatio-temporal blue noise (new slice per frame, TAA
    // integrates it); static slice without TAA. Fallbacks keep the old dither.
#if BLUE_NOISE == 1
    float rotA = blueDither(gl_FragCoord.xy, frameCounter) * 6.2831853;
#elif defined TAA
    float rotA = fract(dither + float(frameCounter - (frameCounter / 64) * 64) * 0.618034) * 6.2831853;
#else
    float rotA = dither * 6.2831853;
#endif

    float rPen;
#ifdef PCSS
    // ---- Blocker search (RAW depth) over the largest possible penumbra here ----
    float maxDist = (sp.z - 0.5 * (1.0 - VLX_SHADOW_ZSCALE)) / dPerBlock; // blocks to the near plane
    float rSearch = min(lsize * maxDist, VLX_PCSS_CAP);
    // Center tap first: a receiver right behind a thin caster never early-outs as lit.
    float zc1 = texture2D(shadowtex1, sp.xy).r;
    float zc0 = texture2D(shadowtex0, sp.xy).r;
    float blockerSum = 0.0, blockerCnt = 0.0, blocker0Sum = 0.0, blocker0Cnt = 0.0;
    if (zc1 < zRef) { blockerSum += zRef - zc1; blockerCnt += 1.0; }
    if (zc0 < zRef) { blocker0Sum += zRef - zc0; blocker0Cnt += 1.0; }
    for (int i = 0; i < VLX_SEARCH_TAPS; i++) {
        float a = float(i) * 2.4 + rotA;
        vec2 dir = vec2(cos(a), sin(a));
        vec2 jd = J * dir;                                   // uv per block along dir
        float R = max(rSearch, 2.0 * texel / max(length(jd), 1e-6));
        float r = sqrt((float(i) + 0.5) / float(VLX_SEARCH_TAPS)) * R;
        vec2 uvo = sp.xy + jd * r;
        float zt = min(zRef + dot(g, dir * r), 0.99999);      // receiver-plane depth at the tap
        float zb1 = texture2D(shadowtex1, uvo).r;
        float zb0 = texture2D(shadowtex0, uvo).r;
        if (zb1 < zt) { blockerSum += zt - zb1; blockerCnt += 1.0; }
        if (zb0 < zt) { blocker0Sum += zt - zb0; blocker0Cnt += 1.0; }
    }
    // No blocker of any kind in the disc: full sun, PCF skipped (majority outdoors).
    if (blockerCnt < 0.5 && blocker0Cnt < 0.5) return vec3(1.0);
    // Penumbra from the mean blocker distance (opaque first, translucent otherwise).
    float distB = (blockerCnt > 0.5) ? blockerSum / blockerCnt : blocker0Sum / max(blocker0Cnt, 1.0);
    rPen = min(lsize * distB / dPerBlock, VLX_PCSS_CAP);
#else
    // PCSS off: fixed radius of 2.5 distorted texels x softness (legacy semantics).
    rPen = SHADOW_SOFTNESS * 2.5 * Tb;
#endif

    // ---- PCF: hardware 2x2 compare per tap, world-space Vogel disc, 1-texel floor ----
    vec3 shadow = vec3(0.0);
    for (int i = 0; i < SHADOW_SAMPLES; i++) {
        float a = float(i) * 2.4 + rotA;
        vec2 dir = vec2(cos(a), sin(a));
        vec2 jd = J * dir;
        float R = max(rPen, texel / max(length(jd), 1e-6));    // floor: ONE distorted texel in this direction
        float r = sqrt((float(i) + 0.5) / float(SHADOW_SAMPLES)) * R;
        vec2 uvo = sp.xy + jd * r;
        float zt = min(zRef + dot(g, dir * r), 0.99999);
        float s1, s0;
        if (hw) {
            s1 = shadow2D(shadowtex1HW, vec3(uvo, zt)).r;     // opaque-only visibility (0..1), 2x2 bilinear compare
            s0 = shadow2D(shadowtex0HW, vec3(uvo, zt)).r;     // everything
        } else {
            s1 = step(zt, texture2D(shadowtex1, uvo).r);       // far sun-aligned: linear raw depth (plane-exact)
            s0 = step(zt, texture2D(shadowtex0, uvo).r);
        }
        s1 = max(s1, s0);
        vec3 col = vec3(1.0);
#if WCOL_V3 == 1
        float wTagV3 = 0.0;   // see vlxWaterShadowT / the legacy sampler above
#endif
        if (s0 < s1 - 0.001) {
            // Translucent or tex0-only blocker inside the footprint: same RGB-band tag
            // decode as the legacy path (encoded in shadow.fsh). SOLID band / never-written
            // texel -> the tex0-only caster occludes: visibility becomes s0.
            vec4 sc0 = texture2D(shadowcolor0, uvo);
#if SHADOW_TEX1_GATE_FIX == 1
            float tagMx = max(max(sc0.r, sc0.g), sc0.b);
#if WCOL_V3 == 1
            // ONE extra raw tap, and only here: the hardware-compare path returns a
            // FILTERED visibility, not a depth, so the water surface's own depth has
            // to be read back to price the light leg. This branch is entered only
            // under a translucent blocker (already paying the shadowcolor0 tap), so
            // the cost lands on submerged pixels alone.
            if (tagMx < 0.325) { col = vlxWaterShadowT(zt - texture2D(shadowtex0, uvo).r); wTagV3 = 1.0; }
#else
            if (tagMx < 0.325)      col = clamp(sc0.rgb / 0.30, 0.0, 1.0);
#endif
            else if (tagMx < 0.675) col = clamp((sc0.rgb - 0.35) / 0.30, 0.0, 1.0);
            else s1 = s0;
#else
            col = sc0.rgb;
#endif
        }
#if WCOL_V3 == 1
        if (wTagV3 < 0.5) col = max(mix(vec3(luma(col)), col, 1.4), vec3(0.0));
#else
        col = max(mix(vec3(luma(col)), col, 1.4), vec3(0.0));
#endif
        // s0 of the footprint is fully lit, (s1 - s0) passes through the tint.
        shadow += s0 + (s1 - s0) * col;
    }
    return shadow / float(SHADOW_SAMPLES);
#endif
}
#endif

vec3 getShadow(vec3 viewPos, vec3 viewNormal, float dither) {
#if SHADOW_V2 == 1
    // PIXEL_SHADOWS : le snap du receveur vit DANS shadowReceiverV2 (il doit
    // arriver apres la derivee du plan receveur), rien a faire ici.
    return sampleShadowPCFV2(viewPos, viewNormal, dither);
#else
    // Chemin legacy : pas de plan receveur, le snap se pose donc au bord.
    return sampleShadowPCF(toShadowClip(VLX_PIX_RECV(viewPos, viewNormal), viewNormal), dither);
#endif
}

#if DIMENSION_FX == 1
/*
    NETHER LAVA LIGHT (DIMENSION_FX) - hot-emitter HEIGHT MAP.
    In the Nether the sun/moon term is zero and the shadow map is useless for
    shadows (the moon is frozen at the zenith, tilted by sunPathRotation), so
    shadow.fsh repurposes the pass there: only the hot emitters keep their
    depth (lava = family 21 at full weight, warm family 20 x0.35, soul family
    22 x0.25), every other fragment is pushed to the far plane. shadowtex0 thus
    holds, per light column, the depth of the TOPMOST emitter and shadowcolor0
    its weighted tint (depth 1.0 = no emitter). The light axis is fixed, so the
    map is stable frame to frame.
    Receiver: same clip + distortion chain as sampleShadowPCF; |dz| converted
    to VERTICAL blocks with the shadowZToVertical calibration of composite1
    (packing VLX_SHADOW_ZSCALE, ortho term shadowProjection[2].z, x lightWy);
    glow = tint * exp(-blocks / NETHER_LAVA_REACH). Ceilings over lava lakes
    glow, the volumetric march raises columns from the lakes (composite1 +
    lib/vl_halfres.glsl call lavaGlowAt per step with the position they already
    projected). EROSION: the column is probed at the center and at +-1.5
    blocks on both map axes, every probe must hold an emitter and the
    farthest one sets the distance - the enclosed 1-block lava springs the
    wastes are riddled with (16 per chunk) and thin falls never glow through
    the rock, lakes and rivers do. 5 depth taps + 1 color tap per call.
    Only emitters on the FAR side of the receiver count (lava below it): a
    lava sea above a cave ceiling does not glow through the rock; hanging
    glowstone (family 20) no longer lights the floor under it (vanilla block
    light already does).
    KNOWN LIMITS: no occluder test beyond that erosion (rock between a lake
    and the receiver is ignored - the exponential reach bounds the leak), and
    the light-aware shadow culling (shadow.culling=true) only keeps sections
    that can cast INTO the view frustum along the (near-vertical) light axis:
    a lake just below the frustum - at your feet while you look up at the
    ceiling over it - is dropped, and its ceiling glow / VL columns pop with
    the camera pitch. Opt-in mitigation documented in shaders.properties
    (shadow.culling=reversed + const float voxelDistance).
*/
// sp = distorted shadow-map position of the receiver (xy in [0,1], z packed);
// f = its distortion factor (getDistortFactor of the clip xy);
// lightWy = |world light direction . up| (vertical share of the light axis).
vec3 lavaGlowAt(vec3 sp, float f, float lightWy) {
    if (sp.x < 0.0 || sp.x > 1.0 || sp.y < 0.0 || sp.y > 1.0 || sp.z >= 1.0) return vec3(0.0);
    // 1.5 blocks expressed in distorted map uv (ortho x scale, /f, *0.5)
    float du = 1.5 * abs(shadowProjection[0][0]) * 0.5 / f;
    float zL = texture2D(shadowtex0, sp.xy).r;
    zL = max(zL, texture2D(shadowtex0, sp.xy + vec2( du, 0.0)).r);
    zL = max(zL, texture2D(shadowtex0, sp.xy + vec2(-du, 0.0)).r);
    zL = max(zL, texture2D(shadowtex0, sp.xy + vec2(0.0,  du)).r);
    zL = max(zL, texture2D(shadowtex0, sp.xy + vec2(0.0, -du)).r);
    if (zL > 0.9999) return vec3(0.0);   // a probe without emitter: no lake here
    // Far side of the receiver only (emitter BELOW it along the light axis):
    // a lava sea above a cave ceiling must not glow through the rock. Tiny
    // tolerance (PCF-bias calibration) so the lake surface still lights itself.
    float dz = zL - sp.z;
    if (dz < -0.0002 * (VLX_SHADOW_ZSCALE * 2.0)) return vec3(0.0);
    // Packed dz -> vertical blocks (same calibration as shadowZToVertical)
    float blocks = max(dz, 0.0) * (2.0 / VLX_SHADOW_ZSCALE)
                 / max(abs(shadowProjection[2].z), 1e-6) * max(lightWy, 0.15);
    return texture2D(shadowcolor0, sp.xy).rgb * exp(-blocks / NETHER_LAVA_REACH);
}

// Surface receiver: view-space point + normal (normal offset as the PCF).
vec3 lavaBelow(vec3 viewPos, vec3 viewNormal) {
    vec3 sc = toShadowClip(viewPos, viewNormal);
    float f = getDistortFactor(sc.xy);
    vec3 sp = distortShadow(sc, f) * 0.5 + 0.5;
    float lightWy = abs(normalize(mat3(gbufferModelViewInverse) * shadowLightPosition).y);
    return lavaGlowAt(sp, f, lightWy);
}
#endif

#if DEBUG_VIEW == 22
// Shadow debug view: classifies the shadow texel at the RECEIVER pixel (center tap,
// SAME math as sampleShadowPCF: distortion, z packing, bias). Answers in-world
// "does the receiver see the occluder?".
//   WHITE   = lit (s0=s1=1)
//   BLACK   = opaque shadow (s1=0, occluder present in shadowtex1)
//   RED     = SOLID tex0-only band -> full occlusion
//   BLUE    = WATER band, CYAN = GLASS/PORTAL band (tinted)
//   GREEN   = solid band with alpha<0.9 (partial write; still occludes)
//   YELLOW  = anomaly s0>s1, MAGENTA = outside the shadow map
// WHITE under an entity means its depth is MISSING from shadowtex0 (caster-side
// issue, not the tag). Compiled only in this debug view.
vec3 debugShadowClassify(vec3 viewPos, vec3 viewNormal) {
#if SHADOW_V2 == 1
    // Same receiver setup as sampleShadowPCFV2 (normal offset, texel bias).
    vec3 sp; float z; mat2 J; vec2 g; float Tb; bool hw;
    if (!shadowReceiverV2(viewPos, viewNormal, sp, z, J, g, Tb, hw)) return vec3(0.5, 0.0, 0.5);
#else
    // PIXEL_SHADOWS : meme receveur snappe que le chemin legacy de getShadow,
    // pour que la vue de debug reste diagnostique de ce qui est reellement lu.
    vec3 shadowClip = toShadowClip(VLX_PIX_RECV(viewPos, viewNormal), viewNormal);
    float f = getDistortFactor(shadowClip.xy);
    vec3 sp = distortShadow(shadowClip, f) * 0.5 + 0.5;
    if (sp.x < 0.0 || sp.x > 1.0 || sp.y < 0.0 || sp.y > 1.0) return vec3(0.5, 0.0, 0.5);
    float bias = (0.00012 + 0.00010 * f) * (VLX_SHADOW_ZSCALE * 2.0); // same calibration as sampleShadowPCF
    float z = sp.z - bias;
#endif
    float s0 = step(z, texture2D(shadowtex0, sp.xy).r);
    float s1 = step(z, texture2D(shadowtex1, sp.xy).r);
    if (s0 > 0.5 && s1 > 0.5) return vec3(1.0);
    if (s0 < 0.5 && s1 < 0.5) return vec3(0.0);
    if (s0 < 0.5 && s1 > 0.5) {
#if SHADOW_TEX1_GATE_FIX == 1
        vec4 scD = texture2D(shadowcolor0, sp.xy);
        float mxD = max(max(scD.r, scD.g), scD.b);
        if (mxD < 0.325) return vec3(0.1, 0.3, 1.0);   // BLUE  = WATER band (tint expected)
        if (mxD < 0.675) return vec3(0.1, 1.0, 0.9);   // CYAN  = GLASS/PORTAL band (tinted)
        if (scD.a < 0.9) return vec3(0.1, 1.0, 0.1);   // GREEN = solid band, alpha<0.9 (partial write)
        return vec3(1.0, 0.0, 0.0);                    // RED   = SOLID band -> full occlusion
#else
        return (texture2D(shadowcolor0, sp.xy).a > 0.2) ? vec3(0.1, 0.3, 1.0) : vec3(1.0, 0.0, 0.0);
#endif
    }
    return vec3(1.0, 1.0, 0.0);
}
#endif

/*
    Full surface shading.
    subsurface > 0: approximate subsurface scattering (foliage).
*/
// ===== FULL_PATH_TRACE variant of shadeSurface, exporting the pure DIRECT term =====
// shadeSurface itself is left alone: its signature is shared with entities/water and changing it
// would break their compilation even at FULL_PATH_TRACE=0. This sibling exists only under the gate
// and is called only by gbuffers_terrain. It matches shadeSurface exactly EXCEPT:
//   (1) shadow = 1 - sun visibility is delegated to the composite5 voxel trace;
//   (2) it exports directOut = albedo * getLightColor() * diff, the SAME quantity (without
//       visibility) that is baked into colortex0, so composite5 can subtract it exactly for any
//       albedo. cloudShadow is included so the lit region matches.
#if FULL_PATH_TRACE == 1 && VOXEL_GI == 1
vec3 shadeSurfaceFPT(vec3 albedo, vec3 normal, vec2 lm, vec3 viewPos, float dither, float subsurface, out vec3 directOut) {
    directOut = vec3(0.0);
    vec3 L = normalize(shadowLightPosition);
    float NdotL = clamp(dot(normal, L), 0.0, 1.0);
    float diff = mix(NdotL, 0.6 + 0.4 * NdotL, subsurface);

    vec3 shadow = vec3(1.0);   // sun visibility DELEGATED to the voxel trace (composite5)
    // Foliage shadow floor (no-op when subsurface=0): same as shadeSurface.
    shadow = mix(shadow, max(shadow, vec3(FOLIAGE_SHADOW_FLOOR)), subsurface);

    // Pure direct term (cloudShadow included for parity with the lit region; baked + exported).
    vec3 lightCol = getLightColor();
    float cloudS = 1.0;
    #ifdef VOLUMETRIC_CLOUDS
    #ifdef VC_GROUND_SHADOWS
        vec3 wpFPT = (gbufferModelViewInverse * vec4(viewPos, 1.0)).xyz + cameraPosition;
        vec3 lightDirWFPT = normalize(mat3(gbufferModelViewInverse) * shadowLightPosition);
        cloudS = cloudShadow(wpFPT, lightDirWFPT);
    #endif
    #endif
    vec3 direct = lightCol * diff * shadow * cloudS;
    // directOut = pure sun contribution (shadow already 1) as baked into colortex0.
    directOut = albedo * lightCol * diff * cloudS;

    if (subsurface > 0.0) {
        float backlit = pow(clamp(dot(normalize(viewPos), L), 0.0, 1.0), 6.0);
        direct += lightCol * shadow * cloudS * backlit * subsurface * 0.85 * SUBSURFACE_STRENGTH;
    }

    float skyl = lm.y * lm.y;
    vec3 ambient = getAmbientColor() * skyl;
    ambient *= VOXEL_GI_AMBIENT;
    // Same gates as shadeSurface, kept in lockstep (GI-RSM pass): RTGI is NOT
    // computed by composite.fsh when SSGI is on (its block is gated
    // "#if defined RTGI && !defined SSGI"), so compensating for it here would
    // remove ambient for a bounce that never arrives; and the SSGI/RSM
    // compensation applies here too, because composite1 adds their bounce to
    // this surface as well under FULL_PATH_TRACE. Both keep the promise
    // "matches shadeSurface exactly except (1) and (2)" true.
    #if defined RTGI && !defined SSGI
        ambient *= mix(1.0, RTGI_BOUNCE_AMBIENT, skyl);
    #endif
    #if (defined SSGI || defined VLX_RSM_ACTIVE) && !defined VLX_DH_NO_GI_COMP
        ambient *= mix(1.0, GI_BOUNCE_AMBIENT, skyl);
    #endif
    ambient += toLinear(fogColor) * 0.35 * (1.0 - skyl) + getTorchColor() * 0.006 * (1.0 - skyl);

    float torch = lm.x * lm.x * lm.x * 2.0 + lm.x * 0.08;
    #ifdef VANILLA_BLOCKLIGHT
        torch *= VANILLA_TORCH;
    #else
        torch = 0.0;
    #endif
    float held = float(max(heldBlockLightValue, heldBlockLightValue2)) / 15.0; // offhand counts too
    torch += held * held * 2.5 * HELD_LIGHT_STRENGTH / (1.0 + dot(viewPos, viewPos) * 0.05);

    vec3 caveFloor = vec3(0.8, 0.95, 1.3) * MIN_LIGHT * max(skyl * skyl, 0.005);

    // directOut is already linear and already multiplied by albedo: exactly the sun share below.
    // KNOWN GAP (colored lights): NO EMISSIVE_LPV bridge here - whoever revives the
    // path tracer (FULL_PATH_TRACE=1 + VOXEL_GI=1) gets terrain block light in plain
    // vanilla orange while entities/water/DH (on shadeSurface) stay colored. The site
    // to mirror is the EMISSIVE_LPV block of shadeSurface (sampleLPVForward + the CL_V2
    // luminance-normalized chrominance swap; at CL_V2=0 the v1 tint + CL_STRENGTH
    // additive pop) - or factor that block-light term into one shared helper.
    return albedo * (direct + ambient + getTorchColor() * torch + caveFloor);
}
#endif

vec3 shadeSurface(vec3 albedo, vec3 normal, vec2 lm, vec3 viewPos, float dither, float subsurface) {
    vec3 L = normalize(shadowLightPosition);
    float NdotL = clamp(dot(normal, L), 0.0, 1.0);
    float diff = mix(NdotL, 0.6 + 0.4 * NdotL, subsurface);

    vec3 shadow = vec3(0.0);
#if DIMENSION_FX == 1
    // Dimension weights (exactly 0/1, uniform - lib/dimension.glsl). Nether:
    // the direct term is zero and the shadow map holds the lava height map,
    // so the PCSS is skipped (shadow = 1 keeps the SHADOW_TINT delta neutral).
    // End: the PCSS runs normally on the frozen-noon map.
    float dimN = dimNether();
    float dimE = dimEnd();
    if (dimN > 0.5) shadow = vec3(1.0);
    else
#endif
    if (diff > 0.001) {
        // Past the shadow map: fall back to the sky lightmap
        float sfade = smoothstep(0.85, 1.0, length(viewPos) / shadowDistance);
        vec3 farSh = vec3(lm.y * lm.y);
#if DIMENSION_FX == 1
        // End: no skylight data there -> beyond the shadow range fall back to LIT
        // (distant islands / structures must not go black).
        farSh = mix(farSh, vec3(1.0), dimE);
#endif
        if (sfade >= 1.0) {
            // Early-out: at sfade 1 the PCSS result would be fully overwritten
            // by the mix below - a large win on DH / distant terrain fragments.
            shadow = farSh;
        } else {
            shadow = getShadow(viewPos, normal, dither);
            shadow = mix(shadow, farSh, sfade);
        }
    }
    // Shadow RECEIVED under foliage (subsurface>0): soft floor, adjustable strength, and a GREEN
    // tint standing in for light filtered through leaves. Exact no-op on any other surface
    // (subsurface=0) because mix(..., subsurface) cancels it.
    // Note: this is the RECEIVER side only; foliage/entity shadow CASTING lives in
    // shadow.vsh/shadow.fsh + shaders.properties.
    {
        vec3 folFloored = max(shadow, vec3(FOLIAGE_SHADOW_FLOOR));
        vec3 folStrong  = mix(folFloored, shadow, FOLIAGE_SHADOW_STRENGTH);
        float folL      = luma(folStrong);
        vec3 folTinted  = mix(folStrong, folStrong * vec3(0.55, 1.0, 0.45), FOLIAGE_SHADOW_TINT * (1.0 - folL));
        shadow = mix(shadow, folTinted, subsurface);
    }
    vec3 direct = getLightColor() * diff * shadow;

    // Foliage backlight: light transmitted through the leaves
    if (subsurface > 0.0) {
        float backlit = pow(clamp(dot(normalize(viewPos), L), 0.0, 1.0), 6.0);
        direct += getLightColor() * shadow * backlit * subsurface * 0.85 * SUBSURFACE_STRENGTH;
    }

    // Clouds crossing the sun darken the ground
    #ifdef VOLUMETRIC_CLOUDS
    #ifdef VC_GROUND_SHADOWS
    // cloudShadow costs ~17 noise evaluations and is pointless when direct is
    // already zero (full shadow, cave, moonless night) - same result, no cost.
    if (luma(direct) > 1e-4) {
        vec3 wp = (gbufferModelViewInverse * vec4(viewPos, 1.0)).xyz + cameraPosition;
        vec3 lightDirW = normalize(mat3(gbufferModelViewInverse) * shadowLightPosition);
        direct *= cloudShadow(wp, lightDirW);
    }
    #endif
    #endif

#if DIMENSION_FX == 1
    // NETHER LAVA LIGHT (height map, see lavaGlowAt): the glow comes from
    // below, so ceilings take it fully, walls about half, up-facing floors a
    // quarter. Faded out past the shadow range like the PCSS. One extra
    // shadow fetch per pixel, Nether only (uniform branch).
    if (dimN > 0.5) {
        vec3 nWL = mat3(gbufferModelViewInverse) * normal;
        float wUp = 0.25 + 0.75 * clamp(-nWL.y * 0.5 + 0.5, 0.0, 1.0);
        float reachL = 1.0 - smoothstep(0.85, 1.0, length(viewPos) / shadowDistance);
        direct += lavaBelow(viewPos, normal) * (1.3 * NETHER_LAVA_LIGHT * wUp * reachL);
    }
#ifdef END_STORM_ACTIVE
    // END LIGHTNING on surfaces (lib/dimension.glsl endLightningState): a
    // brief point light at the bolt, squared half-Lambert (soft, no shadow
    // map), soft inverse square. Additive, End only (uniform branch).
    if (dimE > 0.5) {
        vec3 bPL;
        vec3 bCL;
        float flL = endLightningState(frameTimeCounter, cameraPosition, bPL, bCL);
        if (flL > 0.001) {
            vec3 wpL = (gbufferModelViewInverse * vec4(viewPos, 1.0)).xyz + cameraPosition;
            vec3 nWE = mat3(gbufferModelViewInverse) * normal;
            vec3 tbL = bPL - wpL;
            float d2L = dot(tbL, tbL);
            float hlL = dot(nWE, tbL * inversesqrt(max(d2L, 1.0))) * 0.5 + 0.5;
            direct += bCL * (flL * hlL * hlL * 1.2e4 / (d2L + 2500.0));
        }
    }
#endif
#endif

    float skyl = lm.y * lm.y;
    // Sky ambient: strictly proportional to sky exposure - 0 in caves
    vec3 ambient = getAmbientColor() * skyl;
#if DIMENSION_FX == 1
    // Nether / End have NO skylight (lm.y = 0): their ambient is independent
    // of it. Adds the missing (1 - skyl) share, exactly 0 in the Overworld.
    ambient += getAmbientColor() * ((1.0 - skyl) * max(dimN, dimE));
#endif
    // SHADOW_TINT (CONFIG_LIGHT) < 1.0: pull the sky ambient toward its own
    // luma in SHADOWED areas only (weighted by sun visibility; lit areas keep
    // the full tint, direct light swamps them anyway). Delta form: exact no-op
    // at the 1.0 default. Applied BEFORE the dimensional fogColor term below.
    ambient += (vec3(luma(ambient)) - ambient)
             * ((1.0 - SHADOW_TINT) * (1.0 - clamp(luma(shadow), 0.0, 1.0)));
    #if VOXEL_GI == 1
        // Voxel GI supplies the indirect term, so the flat sky ambient is scaled down to avoid
        // double counting. Does NOT touch the dimensional fogColor*0.35 term below.
        ambient *= VOXEL_GI_AMBIENT;
    #endif
    // RTGI + SSGI both defined: composite.fsh gates its RTGI block with
    // "#if defined RTGI && !defined SSGI", so in that combination the RTGI is
    // NOT computed - the old bare #ifdef removed 65 % of the sky ambient for a
    // bounce that never arrives (and multiplied with the SSGI compensation
    // below, x0.30 total). Same gate on both sides now.
    #if defined RTGI && !defined SSGI
        ambient *= mix(1.0, RTGI_BOUNCE_AMBIENT, skyl);
    #endif
    #if (defined SSGI || defined VLX_RSM_ACTIVE) && !defined VLX_DH_NO_GI_COMP
        // SAME PATTERN, GAP CLOSED BY THE GI-RSM PASS. The two blocks above
        // exist so an indirect term computed elsewhere is not counted twice on
        // top of the flat sky ambient; the SSGI and the RSM had no such
        // compensation at all. composite1 adds their bounce to this surface's
        // colour (color += gi * albedo), so the sky ambient has to give up the
        // share the bounce now supplies. It only became due with this pass: the
        // RSM is now ON by default at GI_QUALITY 2 and 3, and it also got an
        // area normalisation that raised its output. Weighted by skyl exactly
        // like the RTGI line, so it is a strict no-op in caves - where there is
        // no sun to bounce and the bounce is 0 anyway.
        // GI_BOUNCE_AMBIENT (lib/settings.glsl) is 0.85, not the voxel GI's
        // 0.35: one partial sun bounce COMPLETES the sky ambient, it does not
        // replace it. 1.0 restores the pre-pass behaviour exactly.
        // VLX_DH_NO_GI_COMP (dh_terrain.fsh / dh_water.fsh) opts the DH LOD
        // programs OUT: composite1 classes DH pixels as sky (isDHpix, so the
        // opaque reinjection "color += gi * albedo" never runs on them) and
        // composite.fsh's "d0 < 1.0" test leaves their gi at 0 - the LOD would
        // give up 15 % of its sky ambient and receive NOTHING back, a visible
        // brightness step exactly on the vanilla/DH seam. The LODs keep the
        // full ambient instead; physically right too, the bounce is already
        // ~0 beyond RSM_FADE_FAR (112 blocks), far inside the LOD start.
        ambient *= mix(1.0, GI_BOUNCE_AMBIENT, skyl);
    #endif
    // Dimensional ambient: Nether/End keep their atmosphere while overworld caves get almost
    // nothing (fogColor is near black there). The 0.35 factor darkens caves and keeps the
    // Nether warm.
    ambient += toLinear(fogColor) * 0.35 * (1.0 - skyl) + getTorchColor() * 0.006 * (1.0 - skyl);

    float torch = lm.x * lm.x * lm.x * 2.0 + lm.x * 0.08;
    #ifdef VANILLA_BLOCKLIGHT
        torch *= VANILLA_TORCH;
    #else
        torch = 0.0;   // vanilla block light fully cut (GI/emissive only)
    #endif
    float held = float(max(heldBlockLightValue, heldBlockLightValue2)) / 15.0; // offhand counts too
    // HELD block light: kept separate from the lightmap torch term. Under EMISSIVE_LPV it keeps
    // the vanilla torch tint, because the source moves with the player and the LPV never sees it.
    float heldT = held * held * 2.5 * HELD_LIGHT_STRENGTH / (1.0 + dot(viewPos, viewPos) * 0.05);

    // Minimum floor: 0.5% deep underground, so a torch stays mandatory
    vec3 caveFloor = vec3(0.8, 0.95, 1.3) * MIN_LIGHT * max(skyl * skyl, 0.005);

#if EMISSIVE_LPV == 1
    // COLORED LIGHTS: the TINT comes from the LPV field (red redstone torch, bluish white sea
    // lantern, amber glowstone - each family's FIXED palette color, lib/cl_colors.glsl, sets
    // its hue; never a texture sample), while the INTENSITY stays driven by the vanilla
    // lightmap (reliable spherical falloff, no leaking through walls). With no LPV energy
    // (out of range, Nether/End without a shadow pass, empty grid) it falls back exactly to
    // getTorchColor() - whose hue equals the palette's warm family 20, so the seam is invisible.
    vec3 wrelCL  = (gbufferModelViewInverse * vec4(viewPos, 1.0)).xyz;
    vec3 wnrmCL  = mat3(gbufferModelViewInverse) * normal;
    vec3 lpvCL   = sampleLPVForward(wrelCL, wnrmCL);
    vec3 torchCol = getTorchColor();
#if CL_V2 == 1 || CL_V3 == 1
    // ===== v2/v3 application: full chrominance replacement, zero added energy =====
    // (CL_V3 reuses this recipe unchanged - only the FIELD feeding sampleLPVForward
    // was rebuilt. The color never carries the energy: it is luminance-normalized
    // below, then multiplied by the vanilla blocklight intensity.)
    // Field colour + CLV2_WARM_FLOOR of the vanilla warm (never black), NORMALIZED to the
    // vanilla torch luminance: the LPV decides the HUE only, the lightmap keeps 100% of
    // the intensity and reach. Where the field fades (distance, range fade, out of grid)
    // the floor takes over CONTINUOUSLY -> exact getTorchColor() fallback, no threshold,
    // no 15% orange residue desaturating cold sources, no additive losange pop, and two
    // mixed sources give their true additive blend (soul+torch -> pale, never gray).
    // Recipe inspired by Complementary Reimagined's colored-light application (see the
    // attribution note in this file's header): field + warm floor, then normalize to the
    // vanilla torch luminance.
    vec3 clC = lpvCL + torchCol * CLV2_WARM_FLOOR;
    // Guard raised 1e-5 -> 1e-3 (CL3): in normal operation it still NEVER fires
    // (luma(clC) >= luma(floor) = 0.0299 by construction, 0.0179 even at the min TORCH_*
    // dials - simulated: dead-field saturation stays exactly vanilla 0.82, no chroma
    // explosion possible). It only bites on NaN/garbage frames (fresh enable, alt-tab),
    // where it bounds the worst-case normalization gain to ~600x instead of ~60000x -
    // one dim wrong-tinted frame instead of a full-screen saturated flash.
    torchCol = clC * (luma(getTorchColor()) / max(luma(clC), 1e-3));
    // NOTE (assumed): LUMINANCE is preserved exactly (luma() is a linear dot product and
    // the guard never fires - luma(floor) = 0.0299), but individual CHANNELS exceed
    // 1.0 on very saturated low-luma sources: redstone (families 26/27) reaches
    // ~(1.85, 0.27, 0.13) at 1 block vs (1.0, 0.52, 0.18) vanilla; lava (family 21)
    // similar. Times torch (up to ~2.08) and albedo, the red zone can clip to pure red
    // before the tonemap while the Rec.709 luminance stays identical to vanilla.
    // Deliberate (Complementary behaves the same); if it ever bothers, bound it with a
    // saturation mix toward the vanilla hue rather than touching the normalization.
    vec3 blockLight = torchCol * torch + getTorchColor() * heldT;
#else
    float lpvLum = luma(lpvCL);
    if (lpvLum > 1e-4) {
        // Tint normalized to the SAME luma as the vanilla torch, so the swap changes COLOR, not
        // energy. Faded in by field presence (epsilon threshold rejects background noise).
        vec3 lpvTint = lpvCL * (luma(getTorchColor()) / lpvLum);
        torchCol = mix(torchCol, lpvTint, CL_TINT_MIX * smoothstep(0.0005, 0.004, lpvLum));
    }
    // Additive pop: raw LPV radiance (falloff comes from the flood = smooth spherical light),
    // guarded by smoothstep(lm.x) so a wall cuts the lightmap and therefore the pop (anti-leak).
    vec3 blockLight = torchCol * torch + getTorchColor() * heldT
                    + lpvCL * CL_STRENGTH * smoothstep(0.035, 0.10, lm.x);
#endif
#else
    // Fallback path: plain vanilla torch color for both lightmap and held light.
    vec3 blockLight = getTorchColor() * (torch + heldT);
#endif

    return albedo * (direct + ambient + blockLight + caveFloor);
}
