/*
    Multi-layer clouds:
    layer 1 (VC_BASE 210, thickness VC_THICK 160): volumetric cumulus - flat
      pancakes (~26 blocks) everywhere, mid domes up to ~70 blocks on masses
      >= 140 wide, rare grand cores up to ~140 on systems >= 280 wide
      (measured, textured path), dark flat base, broad cauliflower tops,
      eroded wispy edges. Column height is WIDTH-GATED (morphological erosion
      of the coverage, lib/lighting.glsl): a small cell gives a low pancake,
      never a pillar. (VC_CUMULUS_SHAPES=0 falls back to the "cloud sea".)
    layer 2 (~415): volumetric altocumulus (thin 6-step slab) + 2D cirrus (~560) above.
    Requires common.glsl and lighting.glsl included first.
*/

// Cloud banks vs clear patches
float cloudPatch(vec2 xz, float t) {
    // VC33_WIND = VC_WIND * VC33_SPEED1: layer-1 speed factor, applied at EVERY
    // cumulus wind site (this procedural fallback included) so nothing can
    // drift apart. Alto (11.0, 4.0) and cirrus (18.0, 6.0) keep VC_WIND.
    vec2 wind = t * vec2(7.0, 2.4) * VC33_WIND;
    return vnoise((xz + wind * 0.6) * 0.0010);
}

// Fallback cloud density (VC_CUMULUS_SHAPES=0). PLANET_RADIUS is large enough
// to stay subtle yet visible at the horizon: far clouds sink and curve away.
float cloudDensity(vec3 wp, float t) {
    // Curvature: a point far from the player "falls" by d^2/(2R), so the sheet
    // follows the planet instead of being an infinite flat ceiling
    float yEff = wp.y;
    #ifdef CLOUD_CURVATURE
        vec2 dxz = wp.xz - cameraPosition.xz;
        // From above the layer the additive term overshoots the bounds and
        // clips, so the curvature is faded out from the upper half of the slab.
        float curvFade = 1.0 - clamp((cameraPosition.y - VC_BASE - VC_THICK * 0.5) / (VC_THICK * 0.5), 0.0, 1.0);
        yEff += dot(dxz, dxz) / (2.0 * PLANET_RADIUS) * curvFade;
    #endif
    float h = (yEff - VC_BASE) / VC_THICK;
    if (h < 0.0 || h > 1.0) return 0.0;

    float cov = clamp(mix(VC_COVERAGE, 1.0, rainStrength * 0.95), 0.0, 1.0); // full rain = near-total overcast
    // The cloudPatch low threshold drops with coverage: at VC_COVERAGE=1.0
    // nearly every cell contributes -> a fully overcast sky is reachable.
    float covLo = max(0.20 - (cov - 0.45) * 0.44, 0.0);
    float covL = cov * smoothstep(covLo, 0.70, cloudPatch(wp.xz, t)) * 1.5;
    if (covL < max(0.03 * (1.0 - cov * 0.9), 0.003)) return 0.0;

    vec2 wind = t * vec2(7.0, 2.4) * VC33_WIND;
    vec2 pp = wp.xz + wind;
    // Small tight cells (mackerel pattern)
    float base = fbm(pp * 0.0060);

    // The densest cells dome upward
    float colH = clamp(base * 1.7 - 0.50, 0.18, 1.0);
    // Slightly sharper top taper (0.55): reads better when seen from above
    float profile = smoothstep(0.0, 0.07, h) * smoothstep(colH, colH * 0.55, h);

    float d = base * profile - (1.0 - covL) * 0.52;
    if (d <= 0.0) return 0.0;

    // Billowy 3D erosion: cauliflower edges
    vec3 dp = vec3(pp.x, wp.y * 2.4, pp.y);
    float ero = vnoise3(dp * 0.030) * 0.65 + vnoise3(dp * 0.085) * 0.35;
    ero = 1.0 - abs(ero * 2.0 - 1.0);
    d -= (1.0 - ero) * 0.13 * (1.0 - clamp(d * 5.0, 0.0, 1.0));

    return clamp(d * 6.0, 0.0, 1.0) * VC_DENSITY;
}

#if VC_CUMULUS_SHAPES == 1
#if VC_TEXTURED == 1
// ---- TEXTURED CUMULUS (Nubis / Horizon Zero Dawn technique) --------------
// Density is read from PRECOMPUTED tileable textures instead of stacked runtime
// noise. Tap budget per marched sample: 1 (2D) on clear sky; 9 (2D) inside
// coverage (width-gated height driver); a LIT sample adds 1 curl + 1-2 erosion
// 3D taps (VC_DETAIL=1) and 1 refresh 2D tap in the light march. Worst case
// 13 taps - the procedural path evaluated ~27 noise octaves per lit sample.
//   . vlCumulusBase    1024^2 R8         2D coverage, ~4000 blocks per tile
//   . vlCumulusDetail1 128^3  R8         cauliflower erosion, ~54-block tile
//   . vlCumulusDetail2 128^3  R8         fine fringe erosion, ~18-block tile
//   . vlCumulusCurl    64^3 RGBA8_SNORM  swirl, ALREADY in [-1,1] (no *2-1)
// The COVERAGE and the column-height driver live in lib/lighting.glsl
// (vlCumulusField): that file is included BEFORE this one and cloudShadow must
// run the EXACT same formula. Single source of truth -> ground shadows can no
// longer desync from the visible clouds.
// MEASURED shapes (formula replayed on cumulus_base.bin) at defaults
// VC_CUMULUS_SCALE=1.5 / VC_THICK=160 / VC_COVERAGE=0.40:
//   . 30.6% of the sky covered, real blue gaps between the masses;
//   . median cloud: 26-block pancake; mid domes to 70 blocks on masses >= 140
//     wide (~5.1% of the covered sky is 48+ tall, soft-ramp replay); grand cores ~107 blocks
//     on systems >= 280 wide, width/height p10 = 2.2;
//   . "towers" (width < 2*height): 0.26% of the covered surface (shallow necks
//     between merged masses) - the pointwise driver this replaces measured 84%.
#ifndef VL_CUMULUS_BASE_DECL
#define VL_CUMULUS_BASE_DECL
uniform sampler2D vlCumulusBase;
#endif
uniform sampler3D vlCumulusDetail1;
uniform sampler3D vlCumulusDetail2;
uniform sampler3D vlCumulusCurl;

// Tile periods in world BLOCKS, tied to VC_CUMULUS_SCALE so the cauliflower
// stays proportional to the clouds. They are exact INTEGER RATIOS of each other
// (curl = 3 x detail1 = 9 x detail2) so ONE mod() folds the wind advection for
// all three lookups without shifting any of the three patterns.
// VC2_DET_SCALE (x1.3 under VC2, VC_CUMULUS_SCALE at gate 0) now lives in
// lib/lighting.glsl next to the other shared cumulus helpers: the VC3 shape
// tile derives from the same macro (single source).
#define VL_DET2_TILE (12.0 * VC2_DET_SCALE)   // ~18 blocks at v5 defaults, ~23 under VC2
#define VL_DET1_TILE (36.0 * VC2_DET_SCALE)   // ~54 blocks at v5 defaults, ~70 under VC2
#define VL_CURL_TILE (108.0 * VC2_DET_SCALE)  // ~162 blocks at v5 defaults, ~211 under VC2

// Shared 2D field - SAME CONTRACT as the procedural path:
// x = coverage in [0,1], y = height driver in [0,0.993].
// COST: 1 texture2D tap on clear sky, 9 inside coverage (see lib/lighting.glsl).
vec2 cloudFieldCumulus(vec2 xz, float t) {
    return vlCumulusField(xz, t);
}

#if VC2 == 1
// VC2: relative height inside the LOCAL column, exported by the hiRes density
// call for the lighting loop (per-cell ambient gradient / base darkening).
// The v5 lighting keyed those on SLAB height: a 26-block pancake lived in the
// bottom 16% of the 160-block slab, so its whole body - top faces included -
// was priced as "belly" (full VC_CUMULUS_BASE_DARK, pure belly ambient). That
// is the uniform grey wash of the user report. Only hiRes calls write it (the
// light-march cheap calls must not clobber the render sample's value).
float vc2HRel = 0.0;
#endif

#if VC2 == 1 && VC3 == 1 && VC_TEXTURED == 1 && VC33 == 1 && VC_DETAIL == 1
// VC33 "coton": local relief signal exported by the hiRes density call, exactly
// like vc2HRel above (same contract: only hiRes writes it, and the lighting
// loop must READ IT BEFORE the light march, whose cheap density calls return
// before this block). Mean EXACTLY zero - both channels are histogram
// equalized, so E[g] = 0.5 - hence the shading factor built from it averages
// to 1 and the cloud's mean luminance is untouched (measured +-0.5%).
float vc33Coton = 0.0;
// Sunward offset of the fine tap, in world blocks, set once per march by
// volumetricClouds (uniform for the whole ray: lightDirW does not vary along
// it). Initialised so any path that reads it before a march is defined.
vec3 vc33SunOff = vec3(0.0);
#if VC34 == 1
// VC34 third octave, exported SEPARATELY from vc33Coton (same hiRes-only
// contract) because it gets its OWN, closer distance fade: its pattern is
// twice as fine, so it falls under the half-res bake's 2-pixel footprint at
// half the distance. Mean exactly zero like the other two.
float vc34Coton3 = 0.0;
// Distance gate written by the march loop BEFORE each density call: false =
// the sample is past VC34_FADE3_FAR, where the octave has faded to nothing,
// so the tap is not paid at all. Coherent inside a warp (neighbouring pixels
// are at the same step index and nearly the same distance), so the branch is
// a real saving, not just a masked-out lane.
bool vc34Near = true;
#endif
#endif

// hiRes=false: cheap variant (no 3D erosion) for the light march.
// fld = field precomputed by the caller. The light march reuses it for the two
// near steps and REFRESHES the coverage once at step 2 (measured on the .bin:
// coverage is 48% decorrelated at a 63-block lag and 92% at 148, so freezing
// it across the whole march shadowed each cloud with its neighbour's coverage;
// see cloudOpticalDepthCumulus).
// Vertical profile: flat base (condensation ramp over 6% of the slab), body,
// short rounded cap. Height comes from the WIDTH-GATED driver only.
float cloudDensityCumulusCov(vec3 wp, float t, bool hiRes, vec2 fld) {
    float h = (wp.y - VC_BASE) / VC_THICK;
    if (h < 0.0 || h > 1.0) return 0.0;

    if (fld.x < 0.015) return 0.0;

#if VC2 == 1 && VC3 == 1
    // ---- VC3 BUBBLE FIELD ------------------------------------------------
    // The 3D texture DEFINES the volume; the 2D weather map is only the
    // ENVELOPE. d = clamp((base3 - T) / W): an iso-surface of the tileable
    // billow field, with a threshold T that
    //   . falls inside coverage (envelope term 1 - covS*profile),
    //   . RISES with relative height (+0.50*hR): the top of each column
    //     breaks into separate worley domes,
    //   . reaches 1 at the coverage edge: the fringe is detached puffs.
    // Offline-calibrated on the real texture (vc3_render.py / vc3_consts):
    //   T0 = 0.08  interior base fill ~85%: consolidated flat-ish bases with
    //              thin creases (the photo's dense body);
    //   T1 = 0.50  top fill collapses to isolated cores: real domes;
    //   W  = 0.15  iso transition ~12 blocks on 78-block lobes: crisp but
    //              not aliased bubble surfaces.
    // Measured on the probe grid: mid-height interior d mean 0.82, std 0.35,
    // 13% true canyons; silhouette IoU between hR 0.25 and 0.75 = 0.17
    // (v2 extruded field: 0.86) - silhouettes now change with height and
    // lobes overhang. VC_DENSITY keeps its meaning as the final multiplier.
    float covS = vc2CovShape(fld.x);
    if (covS < 0.015) return 0.0;

    // Column height: v2 formula kept verbatim (weather-map contract), lobe
    // modulation on the render march only, exactly like v2.
    float colH = 0.22 + 0.08 * covS + 0.62 * fld.y;
    if (hiRes) {
        float lobe = vc2Lobe(wp.xz, vlCumulusWind(t));
#if VC35 == 1
        // VC35 (B3): x VC35_LOB. The ONLY term that gives the GLOBAL
        // silhouette relief in the 20-70 block band the user asked for
        // ("tourelles"): measured 3.46 -> 7.17 turrets per 300 blocks of
        // contour at x2.0, saturating past x2.5. Zero taps - vc2Lobe is
        // already fetched. Render march only, exactly as before.
        colH += (lobe - 0.55) * (0.08 + 0.14 * smoothstep(0.0, 0.30, fld.y)) * VC35_LOB;
#else
        colH += (lobe - 0.55) * (0.08 + 0.14 * smoothstep(0.0, 0.30, fld.y));
#endif
#if VC36 == 1
        // VC36 (B) : 2e frequence de lobe (x9), l'octave de SILHOUETTE que
        // l'erosion ne pouvait pas donner (mesure : bloc VC36 de settings).
        // Enveloppe (0.35 + 0.65 * ss) au lieu du (0.08 + 0.14 * ss) du lobe
        // principal : le terme est deja borne par son amplitude VC36_LOB2, et
        // il doit rester VISIBLE sur les petites masses, pas seulement sur les
        // grands systemes - c'est la ou "on dirait juste que tu les as grossis"
        // se voyait le plus. 1 tap 2D, marche de RENDU seulement.
        colH += (vc2Lobe2(wp.xz, vlCumulusWind(t)) - 0.55) * VC36_LOB2
              * (0.35 + 0.65 * smoothstep(0.0, 0.30, fld.y));
#endif
    }
    colH = clamp(colH, 0.06, VL_CUM_COLCAP);
#if VC36 == 1
    // VC36 (A) : homothetie VERTICALE de la colonne, APRES le plafond. hR est
    // h / colH, donc le profil normalise, la fermeture spherique VC35_CAPK et
    // le cap d'enveloppe VC35_PROF_HI gardent EXACTEMENT leur forme : c'est
    // une mise a l'echelle, pas une deformation. Applique aussi dans
    // vc3DensMeanLM plus bas (le light march doit voir la meme colonne).
    colH *= VC36_H;
#endif
#if VC39 == 1
    // VC39 (C) : COMPENSATION DE MASSE du toit souple. (A) et (B) plus bas
    // ajoutent de la matiere au-dessus de VC39_B0 * colH ; VC39_H la reprend
    // sur la hauteur de colonne pour que l'image ne s'eclaircisse pas.
    // MEME place et MEME forme que VC36_H (homothetie verticale APRES le
    // plafond), donc hR, le profil normalise et les deux fermetures gardent
    // exactement leur forme. Applique aussi dans vc3DensMeanLM plus bas.
    colH *= VC39_H;
#endif
    float hR = clamp(h / max(colH, 1e-4), 0.0, 1.0);
    if (hiRes) vc2HRel = hR;
#if VC35 == 1
    // ---- VC35: FULL CORE + LIVE TOP (zero taps) --------------------------
    // (B2) WIDER envelope cap. At 1.05 only 28% of the envelope survived at
    // hR = 0.875, so T > 1 and the TOP QUARTER of every column was
    // ANALYTICALLY DEAD (measured 98-100% void): the upper silhouette was the
    // smooth iso-contour of T = 1 - a DOME - and not the billows, which had no
    // matter left to sculpt. That is the user's "forme globale sans detail".
    // (B1) SPHERICAL closure instead of the linear 0.50 * hR ramp: it stays
    // LOW through the middle of the column (0.13 at mid height instead of
    // 0.25) and only closes right at the top, so the 78-block billows survive
    // and make ROUND domes rather than the cone the linear ramp eroded.
#if VC39 == 1
    // ---- VC39 (A)(B) : TOIT SOUPLE - la seule voie qui bouge le contour ---
    // hR est CLAMPE a 1 : au-dessus de colH le profil ET la fermeture
    // spherique sont GELES a leur valeur en hR = 1, ce qui donne
    // T = 2.03 - 0.575 * (covS + 0.6 * core) >= 1.11 meme a couverture
    // pleine ; l'early-out "T >= 1" CLIPPE donc TOUTE la matiere. Le toit
    // etait la surface 2D LISSE h = colH, et c'est elle - pas les billows -
    // qui posait la silhouette (VC36 et VC37 avaient bute la-dessus sans
    // pouvoir l'expliquer, VC38 l'a chiffre).
    // (A) hRT = min(h / colH, VC39_HMAX) : au-dessus du toit le profil
    //     CONTINUE de decroitre au lieu d'etre gele, donc T remonte et
    //     referme la bande tout seul - pas de plafond dur a remettre.
    // (B) la fermeture spherique est ETIREE sur [0, VC39_HMAX] au lieu de
    //     [0, 1] et melangee a l'ancienne par vc39B : SOUS VC39_B0 * colH
    //     c'est l'ANCIENNE A L'IDENTIQUE (vc39B = 0), au-dessus c'est une
    //     fermeture qui n'atteint VC35_CAPK qu'en VC39_HMAX.
    // Resultat : T reste < 1 jusqu'a ~1.27 * colH, donc l'iso-surface
    // R = T(hRT) MONTE au-dessus du toit lisse la ou le billow R (lobes de
    // 78 blocs) est fort et DESCEND dessous la ou il est faible. Le toit
    // devient 3D, donc MULTI-VALUE en profondeur : c'est la seule chose que
    // le maximum glissant du rayon (dilatation de 30-60 blocs) laisse passer.
    // vc39B porte aussi une PORTE DE MASSE sur fld.y (pilote de hauteur
    // VC32) : une tourelle appartient a une colonne profonde dans la masse,
    // pas a la frange plate - et cela evite de payer le tap de base sur toute
    // la peripherie (c'est ce qui tient le budget : +0.17 tap/rayon).
    // ZERO TAP AJOUTE PAR ECHANTILLON : T ne depend d'aucune valeur tapee,
    // donc "if (T >= 1.0) return 0.0" reste AVANT le fetch, inchange.
    float hRT = min(h / max(colH, 1e-4), VC39_HMAX);
    float vc39B = smoothstep(VC39_B0, 1.0, hRT)
                * smoothstep(VC39_YG0, VC39_YG1, fld.y);
    float vc39Q = hRT * (1.0 / VC39_HMAX);
    float vc39S0 = sqrt(max(1.0 - hR * hR, 0.0));
    float vc39S1 = sqrt(max(1.0 - vc39Q * vc39Q, 0.0));
    float profile = smoothstep(0.0, 0.05, h) * smoothstep(VC35_PROF_HI, 0.55, hRT);
    float T = (1.0 - covS * profile) + 0.08
            + VC35_CAPK * (1.0 - (vc39S0 + (vc39S1 - vc39S0) * vc39B))
            + VC39_TADD * vc39B;
#else
    float profile = smoothstep(0.0, 0.05, h) * smoothstep(VC35_PROF_HI, 0.55, hR);
    float T = (1.0 - covS * profile) + 0.08
            + VC35_CAPK * (1.0 - sqrt(max(1.0 - hR * hR, 0.0)));
#endif
    // (A) FULL CORE. fld.y is the VC32 height driver - a 9-tap neighbourhood
    // mean at 52/73 blocks - so it is a REAL distance into the mass: measured
    // 35 blocks of transition where covS has only 11 (a covS-keyed core makes
    // VERTICAL WALLS and flat-topped mesas; rejected in render, vc35_tri.png).
    // We LOWER THE THRESHOLD rather than forcing d = max(d, core): the surface
    // stays an iso-surface of the billow field and only its LEVEL drops, so
    // the skin is still sculpted by the bubbles EVERYWHERE - no analytic
    // surface is ever exposed. Placed BEFORE the cheap-path return below, so
    // the light march and vc3DensMeanLM see the same full core (otherwise the
    // top lights through a body the render march sees as solid).
    float vc35Core = smoothstep(VC35_CORE_A, VC35_CORE_B, fld.y) * profile;
    T -= VC35_CORE_K * vc35Core;
#else
    // Envelope: flat condensation base (5% ramp) + SOFT cap (1.05/0.55): the
    // top taper now comes from the RISING THRESHOLD (bubbly domes), not from
    // squashing the envelope - the v2 hard cap re-created smooth mesa tops.
    float profile = smoothstep(0.0, 0.05, h) * smoothstep(1.05, 0.55, hR);
    float T = (1.0 - covS * profile) + 0.08 + 0.50 * hR;
#endif
    // Zero-tap early-out: T >= 1 means even base3 = 1 cannot reach d > 0.
    if (T >= 1.0) return 0.0;

    vec3 wD = vc3ShapeWind(t);
    vec2 s1 = texture3D(vlCumulusShape, (wp + wD) * (1.0 / VC3_TILE)).rg;
    float d = clamp((s1.r - T) * (1.0 / 0.15), 0.0, 1.0);
    if (!hiRes) return d * VC_DENSITY; // light-march near steps: base tap only
    if (d <= 0.0) return 0.0;

    if (VC_CUMULUS_EROSION > 0.001) {
        // HF worley erosion from the SAME tap (G channel - zero extra taps):
        // edge-gated, stronger in the cap zone. /1.5 normalizes the
        // VC_CUMULUS_EROSION dial so its default (1.5) is exactly the
        // offline-calibrated strength.
        float edge = 1.0 - clamp(d * 2.4, 0.0, 1.0);
        float capW = smoothstep(0.5, 1.0, hR);
        d -= (1.0 - s1.g) * (0.10 + 0.26 * capW) * (VC_CUMULUS_EROSION * (1.0 / 1.5))
           * max(edge, 0.25) * smoothstep(0.03, 0.30, h);
        if (d <= 0.0) return 0.0;
        #if VC_DETAIL == 1
        // Fine fringe: G at x3 frequency (integer ratio: the wind fold stays
        // exact), fixed offset decorrelates it from the medium buds. Only
        // paid where an edge survived (same policy as v2's det2).
        float edge2 = 1.0 - clamp(d * 2.4, 0.0, 1.0);
        if (edge2 > 0.18 && VC_DETAIL_STRENGTH > 0.001) {
            float gf = texture3D(vlCumulusShape, (wp + wD + vec3(41.0, 17.0, 67.0)) * (3.0 / VC3_TILE)).g;
#if VC33 == 1 && VC34 == 1
            // VC34 : la frange passe de 0.08 a VC34_ERO3 - MEME tap, cout nul.
            // A 0.08 elle ne deplacait la surface que de 0.41 bloc sur une
            // transition d'iso-surface qui en fait 5.2 : invisible (mesure
            // VC33). Maintenant que le corps a du relief, le bord peut suivre.
            // Conditionne AUSSI a VC33 : le detail de silhouette n'a de sens
            // qu'avec le coton, et surtout VC33 = 0 doit rester "VC32
            // verbatim" - sans ce garde, la densite fuirait dans ce rollback.
            d -= (1.0 - gf) * VC34_ERO3 * VC_DETAIL_STRENGTH * edge2 * smoothstep(0.03, 0.30, h);
            if (d <= 0.0) return 0.0;
            // Octave x6 de SILHOUETTE, coquille SEULE (le seul tap ajoute ici :
            // 0.047 par rayon, mesure). Decalage fixe, PAS sunward : un bord
            // qui bougerait avec le soleil se lirait comme un defaut.
            // Multiplicateur entier -> le pli du vent reste exact.
            float g6 = texture3D(vlCumulusShape, (wp + wD + vec3(23.0, 91.0, 13.0)) * (6.0 / VC3_TILE)).g;
            d -= (1.0 - g6) * VC34_ERO6 * VC_DETAIL_STRENGTH * edge2 * smoothstep(0.03, 0.30, h);
            if (d <= 0.0) return 0.0;
#else
            d -= (1.0 - gf) * 0.08 * VC_DETAIL_STRENGTH * edge2 * smoothstep(0.03, 0.30, h);
            if (d <= 0.0) return 0.0;
#endif
        }
        #endif
    }
#if VC33 == 1 && VC_DETAIL == 1
    // ---- VC33 COTON : relief fin, par le SHADING seul --------------------
    // Le champ de densite au-dessus reste BIT-IDENTIQUE a VC32 : silhouette,
    // cloudShadow, vc3ShadowMod, sondes csA/csB, CT_ANCHOR et le compte
    // d'aiguilles ne bougent pas d'un bit. La raison est mesuree (bloc VC33 de
    // lib/settings.glsl) : 76 % de la lumiere vient d'echantillons a d >= 0.95
    // - le champ SATURE 5 blocs sous la peau - donc deplacer l'iso-surface ne
    // peut toucher que le lisere (4.3 % de l'image). Le corps ne peut etre
    // sculpte que par la LUMIERE.
    // Deux octaves, chacune de moyenne EXACTEMENT nulle (canaux egalises,
    // E[g] = 0.5), donc la luminance moyenne du nuage est conservee :
    //   . s1.g (x1, bosses de 16-31 blocs) : c'est le canal .g du fetch RG
    //     deja lu pour l'erosion -> ZERO tap ajoute. Signe + : dense = je suis
    //     SUR une bosse, elle prend la lumiere ;
    //   . le tap x3 (bosses de 5-10 blocs) DECALE VERS LE SOLEIL de
    //     VC33_SUNOFF blocs. Signe - : dense entre moi et le soleil = OMBRE DE
    //     CONTACT dans le creux. C'est ce decalage qui fait lire du relief au
    //     lieu d'une texture plaquee (verifie en rendu contre l'offset nul).
    // Ce tap x3 existait deja pour la frange fine mais n'etait paye que sur la
    // coquille (edge2 > 0.18 : 8.4 % des echantillons) ; il l'est desormais
    // sur tous ceux qui ont d > 0 - le seul cout ajoute par VC33
    // (+0.42 tap 3D par rayon a CQ2, mesure).
    // La pluie l'eteint : un nimbostratus est une nappe plate sans relief.
    vc33Coton = 0.0;
#if VC34 == 1
    vc34Coton3 = 0.0;
#endif
#if VC35 == 1
    // VC35 (C) COST GATE. The full core costs no tap of its own, but it makes
    // the VC33/VC34 fine taps (gated on d > 0) fire far more often: 4.599 ->
    // 5.511 3D taps/ray at CQ3, out of budget. The coton is a SHADING term:
    // a sample at core ~ 1 sits more than one skin thickness inside a body
    // that is now OPAQUE, its radiance is already extinguished and it can show
    // NOTHING. So the fine taps are paid on the SKIN only. Measured on the
    // coton band (4-12 blocks), which must stay VC34's 8.03%: gate 0.99 ->
    // 5.018 taps / 8.04%, 0.97 -> 4.914 / 8.05%, 0.90 -> 4.673 / 8.03%.
    // At 0.92: ~4.72 taps = +0.12 per ray over VC34, coton and luma unchanged.
    if (VC_DETAIL_STRENGTH > 0.001 && vc35Core < VC35_COTON_MAX) {
#else
    if (VC_DETAIL_STRENGTH > 0.001) {
#endif
        float gS = texture3D(vlCumulusShape, (wp + wD + vc33SunOff + vec3(41.0, 17.0, 67.0)) * (3.0 / VC3_TILE)).g;
        vc33Coton = (VC33_COARSE * (s1.g - 0.5) + VC33_FINE * (0.5 - gS))
                  * (2.0 * VC33_STR) * VC_DETAIL_STRENGTH
                  * smoothstep(0.03, 0.30, h) * (1.0 - rainStrength * 0.85);
#if VC34 == 1
        // ---- VC34 : 3e octave, ANISOTROPE -------------------------------
        // (VC34_SC_XZ, VC34_SC_Y, VC34_SC_XZ) = (3, 6, 3) : 5-10 blocs a plat,
        // 2.5-5 blocs en hauteur. Le rayon est quasi horizontal, donc c'est la
        // frequence HORIZONTALE qui fixe le scintillement le long du rayon -
        // en la gardant a x3 (celle de l'octave VC33, deja validee) on paie
        // la moitie du scintillement d'une octave x6 isotrope tout en donnant
        // PLUS de contraste dans la bande 4-12 blocs (8.39 % contre 7.39 %,
        // mesure a cout et amplitude egaux). Chaque composante doit rester
        // ENTIERE : le vent est mod(., VC3_TILE) et le pli ne reste exact que
        // si une translation de VC3_TILE vaut un nombre entier de periodes.
        // Meme decalage sunward que la x3 (deja calcule, cout nul) : 5 blocs
        // sont toujours une demi-longueur d'onde de sa composante horizontale,
        // donc elle porte aussi une ombre de contact et non une texture
        // plaquee. Signe - identique. Offset fixe (5, 83, 29) different de
        // (41, 17, 67) pour la decorreler de l'octave VC33.
        // vc34Near : la porte de distance, ecrite par la boucle de marche.
        if (vc34Near) {
            float g3 = texture3D(vlCumulusShape, (wp + wD + vc33SunOff + vec3(5.0, 83.0, 29.0))
                     * (vec3(VC34_SC_XZ, VC34_SC_Y, VC34_SC_XZ) / VC3_TILE)).g;
            vc34Coton3 = (VC34_FINE2 * (0.5 - g3))
                       * (2.0 * VC33_STR) * VC_DETAIL_STRENGTH
                       * smoothstep(0.03, 0.30, h) * (1.0 - rainStrength * 0.85);
        }
#endif
    }
#endif
    return clamp(d, 0.0, 1.0) * VC_DENSITY;
#elif VC2 == 1
    // ---- VC2 PROFILE ----------------------------------------------------
    // Replay-measured on cumulus_base.bin (1024^2 grid, v2 defaults: x1.6
    // cell boost + x0.85 coverage cut, lib/lighting.glsl / settings.glsl):
    // covered sky 21-23% (v5 30.5% - much more blue between cells), mass
    // chords median 148 / area-weighted 250 / p90 369 blocks (the requested
    // 150-300 band), distinct masses -44%; median column 45 blocks (v5 26),
    // p90 53, 48+ tall 28.6% of the covered sky (v5 4.1%); towers (width <
    // height among 48+ scanline runs) 0.1% at width/height p10 2.14 - the
    // x1.6 width gates restored the v5 anti-tower margin at full dome height.
    // Coverage steepening: shared shaper (lib/lighting.glsl) - the shadow
    // uses the very same curve.
    float covS = vc2CovShape(fld.x);
    if (covS < 0.015) return 0.0;

    // Column: 0.22 floor (35 blocks - every puff reads as a volume, still
    // wider than tall for the 51-block median cell), +0.08 pointwise dome
    // (max 13 extra blocks: too small to build a tower on its own), +0.62
    // width-gated swing (floor+swing caps at 0.84, and VL_CUM_COLCAP re-caps
    // at 140 blocks like v5).
    float colH = 0.22 + 0.08 * covS + 0.62 * fld.y;
    if (hiRes) {
        // Medium-scale lobes (render march only, see vc2Lobe): +-0.04 half
        // swing on lone pancakes up to +-0.11 on big systems, pivot 0.55 so
        // the term carves slightly more than it raises (towers stay rare).
        float lobe = vc2Lobe(wp.xz, vlCumulusWind(t));
        colH += (lobe - 0.55) * (0.08 + 0.14 * smoothstep(0.0, 0.30, fld.y));
    }
    colH = clamp(colH, 0.06, VL_CUM_COLCAP);

    float hR = clamp(h / max(colH, 1e-4), 0.0, 1.0);
    if (hiRes) vc2HRel = hR;
    // Flat base kept from v5 (5% condensation ramp: sharp, slightly crisper
    // than the 6% ramp) + rounded cap over the TOP 42% of EACH column - the
    // v5 cap ran over the top 26% of colH measured from the slab floor, which
    // on a pancake was a near-vertical wall.
    float profile = smoothstep(0.0, 0.05, h) * smoothstep(1.0, 0.58, hR);
    // Per-CELL shoulders: the silhouette narrows toward ITS OWN top (v5 used
    // h*h*0.16 on SLAB height - identically zero over a pancake, hence the
    // vertical-walled ribbon discs). 0.42 pulls the d=0 line in by up to 42%
    // of the sharpened coverage at the cap: domed flanks at every cell size.
    float d = (covS - hR * hR * 0.42) * profile;
    if (d <= 0.003) return 0.0;

    if (hiRes && VC_CUMULUS_EROSION > 0.001) {
        // Same advection contract as v5 (12% faster drift, folded by mod).
        vec3 wD = mod(vec3(t * 7.0, t * -0.35, t * 2.4) * (VC33_WIND * 1.12), VL_CURL_TILE);
        vec3 pD = wp + wD;
        // Erosion weights on the RELATIVE column: the cap zone is the top 45%
        // of each cell (v5 keyed capW on slab colH - dead on pancakes), the
        // belly stays crisp. Slightly stronger than v5 (0.14 -> 0.16, cap
        // boost 0.6 -> 0.7): the cauliflower has to bite the new lobes.
        float wH   = smoothstep(0.03, 0.35, h);
        float edge = 1.0 - clamp(d * 2.4, 0.0, 1.0);
        float capW = smoothstep(0.55, 1.0, hR);
        #if VC_DETAIL == 1
        vec3 curl = texture3D(vlCumulusCurl, pD * (1.0 / VL_CURL_TILE)).xyz;
        // Swirl amplitude follows the EROSION grain (VC2_DET_SCALE), not the
        // cell size: turbulence stays proportional to the bumps it distorts.
        pD += curl * ((2.5 + 6.0 * h) * VC_CURL * VC2_DET_SCALE);
        #endif
        float n1 = texture3D(vlCumulusDetail1, pD * (1.0 / VL_DET1_TILE)).r;
        d -= (1.0 - n1) * 0.16 * (1.0 + 0.7 * capW) * VC_CUMULUS_EROSION * wH * max(edge, 0.30);
        if (d <= 0.0) return 0.0;
        #if VC_DETAIL == 1
        if (edge > 0.18 && VC_DETAIL_STRENGTH > 0.001) {
            float n2 = texture3D(vlCumulusDetail2, pD * (1.0 / VL_DET2_TILE)).r;
            d -= (1.0 - n2) * 0.085 * (1.0 + 0.7 * capW) * VC_DETAIL_STRENGTH * edge * max(wH, 0.30);
            if (d <= 0.0) return 0.0;
        }
        #endif
        d *= 0.80 + 0.20 * n1; // light internal structure, solid matter
    }

    // Gain 3.1 (v5: 2.6): cores opaque in ~2 steps, fringe crisper - the
    // second half of the measured 23 -> 16 block edge tightening.
    return clamp(d * 3.1, 0.0, 1.0) * VC_DENSITY;
#else
    // Column height driven by the WIDTH-GATED driver only (lib/lighting.glsl):
    // floor 0.16 = 26-block pancakes, tier A domes to 70 blocks (width >= 140
    // guaranteed), tier B grand cores to 140 (width >= 280) - each tier caps
    // its height at half its guaranteed width, so ratio >= 2 by construction.
    // VL_CUM_COLCAP re-clamps the FLOOR too for pathological VC_THICK/scale
    // combos (e.g. scale 0.5 + VC_THICK 512, where 0.16 alone = 82 blocks).
    // Never feed fine detail into colH: that is the "towers" bug.
    // Floor scaled with the guaranteed width (verifier fix): a fixed 0.16 slab
    // floor (26 blocks) broke the >2 ratio at VC_CUMULUS_SCALE 0.5 where cells
    // shrink to ~45 blocks. Identical at default scale (0.306 > 0.16).
    float colH = min(min(0.16, max(VL_CUM_RAD * 0.35 / VC_THICK, 0.05)) + 0.72 * fld.y, VL_CUM_COLCAP);
    // Flat base (ramp over 6% of VC_THICK) + short rounded cap toward colH.
    float profile = smoothstep(0.0, 0.06, h) * smoothstep(colH, colH * 0.74, h);
    // Shoulders drawing in with altitude (free) -> domed flanks, not cylinders.
    float d = (fld.x - h * h * 0.16) * profile;
    if (d <= 0.003) return 0.0;

    if (hiRes && VC_CUMULUS_EROSION > 0.001) {
        // ADVECTION: the detail drifts 12% faster than the coverage, so the
        // silhouettes keep EVOLVING instead of being frozen onto the mass; the
        // slow -y drift reads as buds growing upward. mod() folds the offset
        // into one curl tile - exact for all three lookups (integer ratios) and
        // it keeps the uv small enough for float32 on very old worlds.
        vec3 wD = mod(vec3(t * 7.0, t * -0.35, t * 2.4) * (VC33_WIND * 1.12), VL_CURL_TILE);
        vec3 pD = wp + wD;
        // Erosion weights: nothing at the flat belly, edges only, never cores.
        float wH   = smoothstep(0.05, 0.45, h);      // 0 at the base -> crisp belly
        float edge = 1.0 - clamp(d * 2.4, 0.0, 1.0); // 1 at the edge, 0 in the core
        // Cap zone (top ~third of the column): erosion boosted there so the
        // rounded cap is gnawed by the 3D detail instead of ending on smooth
        // colH isolines - seen at grazing angles from above, those isolines
        // read as stacked terraces. Zero at the belly/flanks (capW = 0).
        float capW = smoothstep(colH * 0.68, colH, h);
        #if VC_DETAIL == 1
        // CURL: RGBA8_SNORM, values are ALREADY in [-1,1] - do NOT do *2-1.
        // Amplitude grows with altitude (~4 -> 13 blocks at defaults):
        // turbulent moutonne tops, undisturbed flat base.
        vec3 curl = texture3D(vlCumulusCurl, pD * (1.0 / VL_CURL_TILE)).xyz;
        pD += curl * ((2.5 + 6.0 * h) * VC_CURL * VC_CUMULUS_SCALE);
        #endif
        // Cauliflower erosion: a LOW texel carves matter away. Routed through
        // wH/edge so the belly stays crisp and the cores stay solid.
        float n1 = texture3D(vlCumulusDetail1, pD * (1.0 / VL_DET1_TILE)).r;
        d -= (1.0 - n1) * 0.14 * (1.0 + 0.6 * capW) * VC_CUMULUS_EROSION * wH * max(edge, 0.28);
        if (d <= 0.0) return 0.0;
        #if VC_DETAIL == 1
        // Fine fringe (~18-block tile) -> ragged outlines. Only paid for when
        // the edge survived the first pass.
        if (edge > 0.18 && VC_DETAIL_STRENGTH > 0.001) {
            float n2 = texture3D(vlCumulusDetail2, pD * (1.0 / VL_DET2_TILE)).r;
            d -= (1.0 - n2) * 0.075 * (1.0 + 0.6 * capW) * VC_DETAIL_STRENGTH * edge * max(wH, 0.30);
            if (d <= 0.0) return 0.0;
        }
        #endif
        d *= 0.80 + 0.20 * n1; // light internal structure, solid matter
    }

    // Gain 2.6: saturated cores (opaque in 2-3 steps), wispy fringe
    return clamp(d * 2.6, 0.0, 1.0) * VC_DENSITY;
#endif // VC2 (textured profile above, v5 verbatim here)
}
#else
// ---- PROCEDURAL v5 FALLBACK (VC_TEXTURED=0), kept BIT-IDENTICAL ------------
// ---- Cumulus shapes: wide flat HORIZONTAL masses, much wider than tall.
// SILHOUETTE and HEIGHT are deliberately DECOUPLED:
//   . SILHOUETTE (covF) : sharply thresholded cells;
//   . HEIGHT     (massN): SMOOTH large-scale mass field (2 octaves >= ~230
//     blocks, WIDE 0.30 threshold band) - only the CORES of big systems rise,
//     edges and small cells stay LOW and FLAT.
// Coupling them (height following covF and a fine dome field) is what produces
// vertical walls/pillars: any narrow cell above the threshold then fills the
// whole slab. Do not reintroduce it.
// Expected shapes (VC_CUMULUS_SCALE=1.5, VC_THICK=160):
//   . big systems (rare): ~350-600 blocks wide, 60-120 filled height (160 only
//     in the core of very large masses) -> width/height ratio ~2.5-5x, core
//     rise spread over ~130-150 horizontal blocks;
//   . scattered small cumulus (frequent): 40-100 blocks, ~38-tall pancakes;
//   . top domes: radius ~55-70 blocks (rounded, not cones);
//   . banks vs clear sky: ~3-4 km scale.
// SANITY CHECK: an isolated 50-block cell above the threshold gives massN=0
// (the smooth field does not see it) -> colH floor -> ~27-38 block pancake,
// NOT a 160-block pillar.
// SYNC: this mask is DUPLICATED constant by constant in cloudShadow
// (lib/lighting.glsl) - any change here must be mirrored there.

// Shared 2D field: returns vec2(thresholded coverage, smooth height driver)
vec2 cloudFieldCumulus(vec2 xz, float t) {
    vec2 wind = t * vec2(7.0, 2.4) * VC33_WIND;
    vec2 p = xz + wind;
    // Smooth large-scale mass (~536x395 then ~232x171 blocks at defaults),
    // anisotropic along x = wind direction -> slightly stretched systems.
    vec2 qm = vec2(p.x * 0.0028, p.y * 0.0038) / VC_CUMULUS_SCALE;
    float M = vnoise(qm) * 0.62 + vnoise(qm * 2.31 + 19.7) * 0.26;
    // Silhouette: mass + medium octave (~73 blocks) -> crisp bays and capes
    float mk = M + vnoise(qm * 7.3 + 2.9) * 0.12;
    #if VC_DETAIL == 1
    // Fine octave (~32 blocks) on the OUTLINE only, renormalized - height
    // never depends on it, so no pillar can appear.
    mk = mk * 0.92 + vnoise(qm * 16.9 + 5.1) * 0.08;
    #endif
    // Banks vs large clear patches: a bank RAISES THE THRESHOLD (large-scale
    // modulator).
    float bank = smoothstep(0.28, 0.62, fbm3(p * 0.00027 + 17.3));
    float cov = clamp(mix(VC_COVERAGE, 1.0, rainStrength * 0.95), 0.0, 1.0); // full rain = near-total overcast
    float thB = mix(0.60, 0.34, cov) + (1.0 - bank) * 0.12;
    float big = smoothstep(thB, thB + 0.13, mk);
    // 2nd family: scattered low cumulus (~40-100 blocks), frequent inside
    // banks, a few survivors in clear areas (adds variety).
    vec2 qs = vec2(p.x * 0.010, p.y * 0.013) / VC_CUMULUS_SCALE;
    float sc = vnoise(qs) * 0.70 + vnoise(qs * 2.63 + 7.7) * 0.30;
    float thS = mix(0.74, 0.58, cov);
    float sm = smoothstep(thS, thS + 0.10, sc) * (0.30 + 0.70 * bank);
    // Kill switch: at VC_COVERAGE=0 the sky is CLEAR (rain brings clouds back
    // through cov).
    float covF = max(big, sm * 0.85) * smoothstep(0.0, 0.05, cov);
    // Rain overcast floor (verifier fix): thresholds alone left 15-25% blue sky
    // at full rain on this procedural path. MIRRORED in cloudShadow.
    covF = max(covF, rainStrength * rainStrength * 0.85);
    // HEIGHT driver: the smooth mass M ONLY (WIDE 0.30 band) - big system
    // cores rise, everything else stays flat.
    // Rain flattens the deck (nimbostratus are flat, not towering); MIRRORED
    // in cloudShadow (lib/lighting.glsl).
    float massN = smoothstep(thB, thB + 0.30, M) * (1.0 - rainStrength * 0.65);
    return vec2(covF, massN);
}

// hiRes=false: cheap variant (no 3D erosion) for the light march.
// fld = precomputed field. In this PROCEDURAL fallback the light march keeps
// the origin field for ALL its steps - a v5 perf trade kept bit-identical.
// Honest caveat: the silhouette octaves go down to ~73 blocks, so the outer
// steps can shadow with stale coverage (the textured path refreshes instead).
// Vertical profile: common FLAT base (condensation over ~6% of the slab),
// SHORT rounded cap (top 24% of the column, avoids cones), shoulders drawing
// in with altitude -> domed flanks rather than cylinders.
float cloudDensityCumulusCov(vec3 wp, float t, bool hiRes, vec2 fld) {
    float h = (wp.y - VC_BASE) / VC_THICK;
    if (h < 0.0 || h > 1.0) return 0.0;

    if (fld.x < 0.015) return 0.0;

    vec2 wind = t * vec2(7.0, 2.4) * VC33_WIND;
    vec2 pp = wp.xz + wind;
    // WIDE top domes (~143x111 blocks -> radius 55-70): a single SMOOTH octave
    // gives round cauliflowers (a fine octave here produces spikes).
    vec2 qd = pp * vec2(0.0105, 0.0135) / VC_CUMULUS_SCALE;
    float dome = vnoiseTex(qd); // baked-texture tap (NOISE_TEX); not part of the cloudShadow mirror

    // Column height. Floor 0.17 keeps isolated 40-60 block puffs at ~27 blocks
    // tall (wider than tall); the +0.07*smoothstep term restores ~0.24 as soon
    // as the smooth mass exists. The rise is driven by the SMOOTH mass alone.
    // Cores land at 0.54-0.96 = 86-154 filled blocks.
    float colH = 0.17 + 0.07 * smoothstep(0.0, 0.25, fld.y) + fld.y * (0.30 + dome * 0.42);
    // Flat base (ramp over 6% of VC_THICK) + short cap toward colH.
    float profile = smoothstep(0.0, 0.06, h) * smoothstep(colH, colH * 0.76, h);
    // Drawn-in shoulders: the silhouette narrows with altitude (free, no extra
    // noise) -> domed tops even where covF is saturated.
    float d = (fld.x - h * h * 0.16) * profile;
    if (d <= 0.003) return 0.0;

    // 3-octave billowy erosion: zero at the base (crisp flat belly), sculpts
    // flanks and tops, leaves cores solid; features slightly stretched along x
    // (downwind). hiRes only.
    if (hiRes && VC_CUMULUS_EROSION > 0.001) {
        vec3 dp = vec3(pp.x * 0.85, wp.y * 2.1, pp.y);
        float ero = vnoise3(dp * 0.026) * 0.50 + vnoise3(dp * 0.074) * 0.32
                  + vnoise3(dp * 0.19) * 0.18;
        ero = 1.0 - abs(ero * 2.0 - 1.0);
        float wH = smoothstep(0.05, 0.45, h);        // 0 at the base -> crisp belly
        float edge = 1.0 - clamp(d * 2.4, 0.0, 1.0); // 1 at the edge, 0 in the core
        d -= (1.0 - ero) * 0.17 * VC_CUMULUS_EROSION * wH * max(edge, 0.28);
        if (d <= 0.0) return 0.0;
        #if VC_DETAIL == 1
        // Micro-erosion (~3-5 blocks) on edges -> fine ragged outlines.
        // Only paid for when the edge survived the previous pass.
        if (edge > 0.18 && VC_DETAIL_STRENGTH > 0.001) {
            float hf = 1.0 - abs(vnoise3(dp * 0.34) * 2.0 - 1.0);
            d -= (1.0 - hf) * 0.085 * VC_DETAIL_STRENGTH * edge * max(wH, 0.30);
            if (d <= 0.0) return 0.0;
        }
        #endif
        d *= 0.80 + 0.20 * ero; // light internal structure, solid matter
    }

    // Gain 2.6: saturated cores (opaque in 2-3 steps), wispy fringe
    return clamp(d * 2.6, 0.0, 1.0) * VC_DENSITY;
}
#endif
// Convenience entry point: recomputes the field itself. SHARED by both paths
// (textured and procedural). volumetricClouds hoists the field instead (one
// evaluation for density + light march); kept for any external caller.
float cloudDensityCumulus(vec3 wp, float t, bool hiRes) {
    float h = (wp.y - VC_BASE) / VC_THICK;
    if (h < 0.0 || h > 1.0) return 0.0;
    return cloudDensityCumulusCov(wp, t, hiRes, cloudFieldCumulus(wp.xz, t));
}

#if VC2 == 1 && VC3 == 1 && VC_TEXTURED == 1
// VC3 analytic mean fill for the FAR light steps (ZERO taps): with the base
// channel histogram-equalized (uniform on [0,1]), the expectation of
// clamp((b - T)/W) over b is exactly (1 - T - W/2) for T + W <= 1: the far
// mass shadows through its 2D envelope while the 2 near steps (below) sample
// the real bubbles. Same column formula as the cheap density (no lobe).
float vc3DensMeanLM(vec3 wp, vec2 fld) {
    float h = (wp.y - VC_BASE) / VC_THICK;
    if (h < 0.0 || h > 1.0) return 0.0;
    float covS = vc2CovShape(fld.x);
    if (covS < 0.015) return 0.0;
    float colH = clamp(0.22 + 0.08 * covS + 0.62 * fld.y, 0.06, VL_CUM_COLCAP);
#if VC36 == 1
    // VC36 (A) : meme homothetie verticale que la marche de rendu, sans quoi
    // les 2 pas analytiques ombreraient a travers une colonne plus haute que
    // celle que le rendu dessine. Zero tap.
    colH *= VC36_H;
#endif
#if VC39 == 1
    // VC39 (C) : meme compensation de masse que la marche de rendu, sinon les
    // 2 pas analytiques ombreraient a travers une colonne plus haute que
    // celle que le rendu dessine. Zero tap.
    colH *= VC39_H;
#endif
    float hR = clamp(h / max(colH, 1e-4), 0.0, 1.0);
#if VC35 == 1
    // VC35: the two FAR light steps must price the SAME full core as the
    // render march, or the sun would light straight through a body the render
    // sees as solid. Still ZERO taps: lowering T by VC35_CORE_K * core simply
    // moves the analytic mean, since E[clamp((R - T)/W)] = 1 - T - W/2 holds
    // for any T (and saturates at 1 once T <= -W, which is exactly the deep
    // core). Same expression as the render march above, minus the lobe -
    // unchanged approximation class.
#if VC39 == 1
    // VC39 : le light march doit voir le MEME toit souple que le rendu, sinon
    // les tourelles seraient eclairees a travers un vide. L'esperance
    // analytique reste EXACTE : VC39 ne touche que T, il n'introduit AUCUNE
    // dependance en la valeur tapee, donc E[clamp((R - T) / W)] = 1 - T - W/2
    // vaut encore (verifie : biais 0.00 % dans la bande, vc39_lm.py).
    float hRT = min(h / max(colH, 1e-4), VC39_HMAX);
    float vc39B = smoothstep(VC39_B0, 1.0, hRT)
                * smoothstep(VC39_YG0, VC39_YG1, fld.y);
    float vc39Q = hRT * (1.0 / VC39_HMAX);
    float vc39S0 = sqrt(max(1.0 - hR * hR, 0.0));
    float vc39S1 = sqrt(max(1.0 - vc39Q * vc39Q, 0.0));
    float profile = smoothstep(0.0, 0.05, h) * smoothstep(VC35_PROF_HI, 0.55, hRT);
    float T = (1.0 - covS * profile) + 0.08
            + VC35_CAPK * (1.0 - (vc39S0 + (vc39S1 - vc39S0) * vc39B))
            + VC39_TADD * vc39B
            - VC35_CORE_K * smoothstep(VC35_CORE_A, VC35_CORE_B, fld.y) * profile;
#else
    float profile = smoothstep(0.0, 0.05, h) * smoothstep(VC35_PROF_HI, 0.55, hR);
    float T = (1.0 - covS * profile) + 0.08
            + VC35_CAPK * (1.0 - sqrt(max(1.0 - hR * hR, 0.0)))
            - VC35_CORE_K * smoothstep(VC35_CORE_A, VC35_CORE_B, fld.y) * profile;
#endif
#else
    float profile = smoothstep(0.0, 0.05, h) * smoothstep(1.05, 0.55, hR);
    float T = (1.0 - covS * profile) + 0.08 + 0.50 * hR;
#endif
    return clamp(1.0 - T - 0.075, 0.0, 1.0) * VC_DENSITY;
}
#endif

// Optical depth toward the sun: PROGRESSIVE steps (tight near the point ->
// fine self-shadowing of the buds, wider afterwards -> overall mass). Uses the
// cheap density (hiRes=false): the light march never pays for the 3D erosion.
// fld = field at wp, hoisted by the caller (volumetricClouds already paid for
// it for the density) - no redundant evaluation here any more.
float cloudOpticalDepthCumulus(vec3 wp, vec3 lightDir, float t, vec2 fld) {
    #ifdef CLOUD_FAST_SHADOW
        const int CLO_STEPS = 3;
    #else
        const int CLO_STEPS = 4;
    #endif
    float acc = 0.0;
    float fr = 0.10;
    float prev = 0.0;
    vec2 fldOD = fld;
    for (int j = 0; j < CLO_STEPS; j++) {
        vec3 p = wp + lightDir * (VC_THICK * fr);
#if VC_TEXTURED == 1
        // Steps land at 16/34/71/148 blocks along lightDir. MEASURED on the
        // .bin: coverage is 48% decorrelated at 63 blocks and 92% at 148 -
        // frozen at the origin, the outer steps integrated the WRONG cloud's
        // coverage (visible as bad self-shadowing at low sun). One refresh tap
        // at step 2 re-anchors both outer steps; it is paid for by the
        // redundant origin tap this rework removed. Refreshing the height
        // driver would cost 8 more taps; instead it is TIGHTENED for free:
        // a column is never taller than its point-coverage bound.
        if (j == 2) {
            float covR = vlCumulusCoverage(p.xz, t);
            fldOD = vec2(covR, min(fldOD.y, vlCumulusTiers(covR, covR)));
        }
#endif
#if VC2 == 1 && VC3 == 1 && VC_TEXTURED == 1
        // VC3: the 2 NEAR steps (16/34 blocks) sample the REAL 3D volume
        // (1 RG tap each - this is what self-shadows the bubbles against each
        // other, the relief the extruded field could never show); the far
        // steps price the mean fill analytically (0 taps, vc3DensMeanLM).
        acc += ((j < 2) ? cloudDensityCumulusCov(p, t, false, fldOD)
                        : vc3DensMeanLM(p, fldOD)) * (VC_THICK * (fr - prev));
#else
        acc += cloudDensityCumulusCov(p, t, false, fldOD) * (VC_THICK * (fr - prev));
#endif
        prev = fr;
        fr *= 2.1;
    }
    return acc;
}
#endif

// Secondary march toward the light: cloud self-shadowing (Beer's law)
float cloudLightMarch(vec3 wp, vec3 lightDir, float t) {
    float acc = 0.0;
    #ifdef CLOUD_FAST_SHADOW
        const int CL_STEPS = 3; // 3-step self-shadowing instead of 4 (perf)
    #else
        const int CL_STEPS = 4;
    #endif
    float st = VC_THICK / float(CL_STEPS);
    vec3 p = wp;
    for (int j = 0; j < CL_STEPS; j++) {
        p += lightDir * st;
        acc += cloudDensity(p, t);
    }
    return exp(-acc * st * 0.032 * min(VC_OPACITY * 0.75, 4.0));
}

float hgPhase(float c, float g) {
    return (1.0 - g * g) / (12.566 * pow(1.0 + g * g - 2.0 * g * c, 1.5));
}

// ---- CLOUD_TEMPORAL: sample budget of the RENDER march (cumulus only) ----
// prepare.fsh defines CLOUD_TEMPORAL_MARCH before including this file: its
// half-res bake is temporally resolved by prepare1.fsh, so it marches
// VC_SAMPLES_EFF steps (ceil 0.6 x VC_SAMPLES, lib/settings.glsl) with a
// 4-frame interleaved start. Every other caller (deferred inline path,
// composite1 clouds-in-front-of-terrain) has no history and keeps the full
// VC_SAMPLES. cloudShadow (lib/lighting.glsl), the light march and the alto
// slab never depended on VC_SAMPLES.
#if CLOUD_TEMPORAL == 1 && defined CLOUD_TEMPORAL_MARCH
#define VC_MARCH_SAMPLES VC_SAMPLES_EFF
#else
#define VC_MARCH_SAMPLES VC_SAMPLES
#endif

// VC37 (2) : le warp de la marche VC2, generalise.
//   VC36 : w(u) = (u + u^2)/2          dw/du = (1 + 2u)/2
//   VC37 : w(u) = ((1-g)u + (1+g)u^2)/2  dw/du = ((1-g) + 2(1+g)u)/2
// w(0) = 0, w(1) = 1 et C1 pour tout g dans [0,1] : la portee et le nombre de
// pas ne changent pas, seule la REPARTITION change (1er pas x(1-g)). Le
// pavage en u des 4 phases temporelles est intact, donc prepare1.fsh
// (CLOUD_TEMPORAL / CT_V2) n'est pas touche. g est nul hors de la dalle, donc
// la vue depuis le sol est bit-identique a VC36.
// Ecrit en macro parce que le warp est recalcule a QUATRE endroits du corps
// (wp, la porte de distance VC34, le fondu VC33, puis dtL) : ces
// recalculs sont voulus, voir les commentaires VC33 / VC34 sur place.
// VC37_W N'A VOLONTAIREMENT PAS DE PARENTHESES EXTERIEURES. Elle n'est
// utilisee que dans le contexte "vcSpan * 0.5 * VC37_W(u)" et le produit
// flottant N'EST PAS ASSOCIATIF : avec des parentheses l'expression devient
// (vcSpan*0.5) * (u*(1+u)) au lieu du ((vcSpan*0.5)*u) * (1+u) de VC36, et le
// SPIR-V du rollback VC37 = 0 differe (verifie : 11 hash sur 31 changeaient).
// Sans elles, gate 0 se reduit TOKEN POUR TOKEN a l'expression VC36 et les
// 31 hash sont identiques. Les parenthese internes autour de (u), elles, ne
// changent aucune association.
#if VC37 == 1
#define VC37_W(u) (u) * (vcG1 + vcG2 * (u))
#define VC37_DW(u) (vcG1 + 2.0 * vcG2 * (u))
#else
#define VC37_W(u) (u) * (1.0 + (u))
#define VC37_DW(u) (1.0 + 2.0 * (u))
#endif

/*
    Main cumulus raymarch. Returns (color, alpha).
    maxDist: clouds are drawn IN FRONT of distant terrain and can be flown over.
    frameOff: interleave phase 0..3 of the temporal bake (frame index mod 4,
    rotated per texel by prepare.fsh; CLOUD_TEMPORAL_MARCH only, compiled out
    otherwise); the 7-argument wrapper below passes 0.
*/
#if VC_CAST_SHADOWS == 1
// Ombre PORTEE (terrain / joueur) sur un point de nuage, en coordonnees monde
// ABSOLUES. Voir le bloc VC_CAST_SHADOWS de lib/settings.glsl pour le pourquoi.
// FAIL-OPEN partout ou la shadow map ne dit rien : hors du cadre XY, hors de
// la plage Z, ou soleil sous l'horizon -> 1.0 (nuage eclaire). C'est LA
// propriete qui evite de noircir toute la couche lointaine.
// shadowtex1 (et pas 0) : on veut l'occultation par les OPAQUES ; l'eau et le
// verre ne doivent pas assombrir un nuage.
float vlCloudCastShadow(vec3 wpAbs) {
    vec3 sc = toShadowClipWorld(wpAbs - cameraPosition);
    float f = getDistortFactor(sc.xy);
    vec3 sp = distortShadow(sc, f) * 0.5 + 0.5;
    if (sp.x < 0.0 || sp.x > 1.0 || sp.y < 0.0 || sp.y > 1.0) return 1.0;
    float zc = sp.z - VC_SHADOW_BIAS * (VLX_SHADOW_ZSCALE * 2.0);
    if (zc >= 1.0 || zc <= 0.0) return 1.0; // hors plage de profondeur -> eclaire
    return step(zc, texture2D(shadowtex1, sp.xy).r);
}
#endif

vec4 volumetricClouds(vec3 camPos, vec3 dir, vec3 lightDirW, vec3 fogCol, float dither, float t, float maxDist, float frameOff) {
    float top = VC_BASE + VC_THICK;
    float t0;
    float t1;
    if (abs(dir.y) < 1e-3) {
        if (camPos.y < VC_BASE || camPos.y > top) return vec4(0.0);
        t0 = 0.0;
        // Shortened range for a horizontal view from inside the layer:
        // 24 samples over 900 blocks = 37-block steps, far better resolved
        // than 83-block steps over 2000 blocks (clouds "vanishing")
#if VC2 == 1 && VC_CUMULUS_SHAPES == 1 && VC_TEXTURED == 1
        // VC2: in-layer range follows the x1.5 distance extension (same gate
        // as VC_RDIST_EFF and the warped loop). The warp keeps the NEAR steps
        // finer than the v5 uniform ones (first step 0.75x the old dt), only
        // the far tail stretches - in-slab detail near the player improves.
        t1 = 1350.0;
#else
        t1 = 900.0;
#endif
    } else {
        float ta = (VC_BASE - camPos.y) / dir.y;
        float tb = (top - camPos.y) / dir.y;
        t0 = max(min(ta, tb), 0.0);
        t1 = max(ta, tb);
        if (t1 <= 0.0) return vec4(0.0);
        // Grazing view toward the horizon: curvature brings very distant
        // clouds into frame, so the march is extended. ONLY below the layer -
        // looking DOWN from above, the extension diluted VC_SAMPLES over empty
        // space under the sheet (thin, noisy clouds).
#if VC37 == 1
        // VC37 (1) : la garde etait "camPos.y < top", donc elle incluait aussi
        // la camera DANS la dalle - et la, l'extension ne peut RIEN ramener.
        // Un rayon montant depuis l'interieur (0 < dir.y < 0.18) sort par le
        // haut a tb = (top - camY) / dir.y ; au-dela wp.y > top, donc
        // cloudDensityCumulusCov retourne 0 des sa premiere ligne
        // ("if (h < 0.0 || h > 1.0) return 0.0"). Forcer t1 a VC_RDIST_EFF
        // n'ajoutait que des echantillons NULS, et comme dt = (t1-t0)/N cela
        // DILUAIT le budget sur du vide, exactement le defaut que le
        // commentaire ci-dessus decrit pour la vue d'en haut. Pire, la borne
        // dure a dir.y = 0.18 se lit comme une LIGNE HORIZONTALE PARFAITE :
        // a camY 300, le premier pas saute de 56.2 b (dir.y 0.179) a 21.8 b
        // (dir.y 0.181). Mesure de non-perte : 8882 echantillons de queue sur
        // 4000 rayons, densite > 0.002 sur 0 (bloc VC37 de lib/settings.glsl).
        // La courbure que cette extension modelise n'existe que vue d'EN
        // DESSOUS de la dalle : c'est ce que la garde dit maintenant.
        if (dir.y > -0.001 && dir.y < 0.18 && camPos.y < VC_BASE) t1 = max(t1, VC_RDIST_EFF); // downward aim from inside the sheet is excluded on purpose; VC_RDIST_EFF == VC_RENDER_DISTANCE outside the VC2 textured path
#else
        if (dir.y > -0.001 && dir.y < 0.18 && camPos.y < top) t1 = max(t1, VC_RDIST_EFF); // downward aim from inside the sheet is excluded on purpose; VC_RDIST_EFF == VC_RENDER_DISTANCE outside the VC2 textured path
#endif
    }
    t1 = min(min(t1, t0 + VC_RDIST_EFF), maxDist);
    if (t1 <= t0 + 0.01) return vec4(0.0);

    // Step length from the EFFECTIVE budget (VC_SAMPLES_EFF on the temporal
    // bake): the march always spans the whole [t0, t1] slab section.
    float dt = (t1 - t0) / float(VC_MARCH_SAMPLES);
#if BLUE_NOISE == 1
    // Real jitter ABOVE the slab too: blue noise is uncorrelated between
    // neighbours and TAA averages it, unlike the old 8x8 Bayer whose +-dt
    // pattern made purple dots. The former 0.5 pin removed ALL dithering seen
    // from above -> the march quantized the tops into dt-thick terraces.
    float jitter = dither;
#else
    // Seen from above, the 8x8 Bayer pattern creates purple dots: the +-dt
    // offset between adjacent pixels alternates hit/miss on fine cloud detail.
    // Jitter is pinned to 0.5 (fixed mid-step) there to kill that noise.
    float jitter = (camPos.y > top) ? 0.5 : dither;
#endif
#if CLOUD_TEMPORAL == 1 && defined CLOUD_TEMPORAL_MARCH
    // 4-frame interleave (CLOUD_TEMPORAL): phase k starts in quarter k of the
    // first step and the dither (or the above-slab 0.5 pin) jitters inside
    // that quarter, so 4 consecutive frames tile one step and the temporal
    // resolve (prepare1.fsh) folds them into a 4x finer march. The offset
    // stays inside [0, dt): no sample is pushed past t1.
    jitter = (frameOff + jitter) * 0.25;
#endif
    float tt = t0 + dt * jitter;

    float cosT = dot(dir, lightDirW);
#if VC2 == 1 && VC3 == 1 && VC_CUMULUS_SHAPES == 1 && VC_TEXTURED == 1 && VC33 == 1 && VC_DETAIL == 1
    // VC33 : decalage sunward du tap fin, constant sur tout le rayon
    // (lightDirW ne varie pas le long d'un rayon) - calcule UNE fois par
    // marche, jamais par echantillon.
    vc33SunOff = lightDirW * VC33_SUNOFF;
#endif
#if VC_CUMULUS_SHAPES == 1
#if VC2 == 1 && VC_TEXTURED == 1
    // ---- VC2 CUMULUS LIGHTING: 3-octave multiscatter, per-cell ambient ----
    // Multi-scatter approximation RE-DERIVED as a truncated series: octave i
    // models scattering order group i with gain a^i (energy left after i
    // bounces), extinction sigma*b^i (multiply-scattered light has diffused
    // around the direct blockers, so it sees a THINNER effective medium) and
    // a phase whose eccentricity shrinks by c^i (each bounce randomizes the
    // direction -> high orders near-isotropic). a=0.52, b=0.28, c=0.60 were
    // fitted offline against the v5 two-octave curve on measured targets
    // (numeric replay, noon light/ambient luma 4.35/0.51): sunlit tops +7%,
    // mid lit faces +26%, DEEP CORES +126% (the dirty-grey -> white shift the
    // user asked for), silver lining within -11% of v5. a<1 bounds the series
    // (sum 1.7904); b<<a is what carries light INTO the cores.
    float duskC = clamp(1.0 - abs(sunHeight()) * 4.0, 0.0, 1.0) * smoothstep(-0.14, -0.04, sunHeight()); // asymmetric (night fix), same as v5
    vec3 sunC = getLightColor() * 3.6 * CLOUD_BRIGHTNESS; // same anchor as v5: CLOUD_BRIGHTNESS keeps its meaning
    // Palette kept from v5 verbatim (validated look: alto-matched tops, clean
    // blue-grey bellies, golden dusk term, CONFIG_CLOUDS dials all live).
    vec3 ambT = (getAmbientColor() * 1.12 + getLightColor() * 0.04) * CLOUD_WHITE;
    vec3 bellyTint = vec3(0.33, 0.37, 0.46)
                   + (vec3(0.33, 0.37, 0.46) - vec3(0.3867)) * (CLOUD_BELLY_COOL - 1.0);
    vec3 ambB = getAmbientColor() * bellyTint * CLOUD_BELLY_BRIGHT + getLightColor() * duskC * 0.45;

    // Rain overcast: same collapse as v5 (sun dies, ambients go slate); the
    // phase collapse moves into the hoisted octaves below.
    float rainG = rainStrength;
    sunC *= 1.0 - rainG * 0.72;
    vec3 slate = getAmbientColor() * vec3(0.66, 0.66, 0.70);
    ambT = mix(ambT, slate, rainG * 0.80);
    ambB = mix(ambB, slate * 0.62, rainG * 0.80);

    float sigL = 0.032 * clamp(VC_OPACITY * 0.75, 1.1, 4.0); // v5 floor kept

    // Phase octaves HOISTED (cosT is constant along the ray - zero per-sample
    // phase cost). Dual lobe per octave: forward g=0.76 (tight silver rim)
    // + back g=-0.24 at 0.35 weight (retro fill), renormalized by 1.35 so
    // each octave stays a unit phase mix; octave g's shrink by c=0.60
    // (0.76/0.456/0.2736 fwd, -0.24/-0.144/-0.0864 back). Rain mixes every
    // octave toward isotropic 1/4pi = 0.0796 (flat deck, no modelled relief)
    // with the same 0.85 share v5 used.
    float ph0 = (hgPhase(cosT, 0.76)   + 0.35 * hgPhase(cosT, -0.24))   * (1.0 / 1.35);
    float ph1 = (hgPhase(cosT, 0.456)  + 0.35 * hgPhase(cosT, -0.144))  * (1.0 / 1.35);
    float ph2 = (hgPhase(cosT, 0.2736) + 0.35 * hgPhase(cosT, -0.0864)) * (1.0 / 1.35);
    ph0 = mix(ph0, 0.0796, rainG * 0.85);
    ph1 = mix(ph1, 0.0796, rainG * 0.85);
    ph2 = mix(ph2, 0.0796, rainG * 0.85);

    #if VC_DETAIL == 1
    // Wind precomputed to advect the wisps along with the cloud mass (v5)
    vec2 wWind = t * vec2(7.0, 2.4) * VC33_WIND;
    #endif

    vec3 acc = vec3(0.0);
    float trans = 1.0;

    // ---- VC2 warped march: the x1.5 distance costs ZERO extra samples ----
    // Uniform parameter u = (i + jitter)/N mapped through w(u) = (u + u^2)/2
    // (w(0) = 0, w(1) = 1, C1): local step = span * (1 + 2u) / (2N). With the
    // span grown x1.5 that is 0.75x the OLD uniform step at entry and 2.25x
    // at the far cap: near clouds are sampled FINER than v5, the extension is
    // paid only in the far tail (exactly the requested "grow the step size
    // beyond the old range instead of adding steps"). The 4-frame temporal
    // interleave lives inside jitter, so the phases still tile the entry step
    // in u-space and the resolve (prepare1.fsh) is untouched. Extinction uses
    // the LOCAL step length dtL.
    float vcSpan = t1 - t0;
    float vcInvN = 1.0 / float(VC_MARCH_SAMPLES);
#if VC37 == 1
    // VC37 (2) : g, la force du warp, portee par la DENSITE AU POINT DE LA
    // CAMERA. Trois proprietes qui en font le bon pilote :
    //  . elle est la MEME pour tous les pixels et pour les TROIS chemins (bake
    //    demi-res, fallback inline de deferred, re-march de composite1), parce
    //    qu'elle ne depend que de cameraPosition : elle ne peut pas fabriquer
    //    de couture, ce qui serait echanger un defaut contre un autre ;
    //  . elle varie continument quand on entre dans un nuage : pas de pop ;
    //  . elle est nulle des qu'on est dans un TROU de la dalle, cas ou le warp
    //    fort degraderait le champ LOINTAIN (mesure : bloc VC37 de settings).
    // Cout : la branche est UNIFORME (cameraPosition est un uniform), donc
    // ZERO au sol. A l'interieur : un champ 2D + un tap 3D par rayon, une
    // seule fois, hors boucle - le chemin cheap (hiRes = false) sort juste
    // apres le tap de base, sans lobe ni erosion, et n'ecrit AUCUNE des
    // globales du march (vc2HRel / vc33Coton / vc34Coton3 sont toutes sous
    // "if (hiRes)" ou apres le return cheap).
    float vcG1 = 1.0;
    float vcG2 = 1.0;
    if (camPos.y >= VC_BASE && camPos.y <= top) {
        float vcGw = VC37_WARP_G * smoothstep(VC37_WARP_D0, VC37_WARP_D1,
                                              cloudDensityCumulusCov(camPos, t, false, cloudFieldCumulus(camPos.xz, t)));
        vcG1 = 1.0 - vcGw;
        vcG2 = 1.0 + vcGw;
    }
#endif
    for (int i = 0; i < VC_MARCH_SAMPLES; i++) {
        float u = (float(i) + jitter) * vcInvN;
        vec3 wp = camPos + dir * (t0 + vcSpan * 0.5 * VC37_W(u));
#if VC2 == 1 && VC3 == 1 && VC_TEXTURED == 1 && VC33 == 1 && VC_DETAIL == 1 && VC34 == 1
        // VC34 : porte de distance de la 3e octave, posee AVANT l'appel de
        // densite pour que le tap ne soit pas paye du tout au-dela du fondu
        // (ou l'octave vaut deja zero). Distance recalculee, jamais hoistee :
        // a gate 0 la ligne wp ci-dessus doit rester token pour token celle de
        // VC33. Coherente dans un warp -> vrai gain, pas une voie masquee.
        vc34Near = (t0 + vcSpan * 0.5 * VC37_W(u)) < VC34_FADE3_FAR;
#endif
        // Field hoisted exactly like v5: one evaluation feeds density + light march.
        float hIn = (wp.y - VC_BASE) / VC_THICK;
        vec2 fld = (hIn < 0.0 || hIn > 1.0) ? vec2(0.0) : cloudFieldCumulus(wp.xz, t);
        float d = cloudDensityCumulusCov(wp, t, true, fld); // hiRes: exports vc2HRel
        if (d > 0.002) {
            float hR = vc2HRel; // BEFORE the light march (its cheap density calls do not write it, but stay explicit)
#if VC2 == 1 && VC3 == 1 && VC_TEXTURED == 1 && VC33 == 1 && VC_DETAIL == 1
            // VC33: read the coton BEFORE the light march (same contract as
            // vc2HRel) and fade it out where the half-res bake can no longer
            // resolve it. MESURE : au-dela de 1200 blocs sans fondu il ajoute
            // 2.5 points de scintillement residuel pour un motif deja sous 2 px
            // d'empreinte ; avec le fondu on retombe sur la baseline livree.
            // Distance recalculee plutot que hoistee : a gate 0 la ligne wp
            // ci-dessus doit rester token pour token celle de VC32.
            float vc33T = t0 + vcSpan * 0.5 * VC37_W(u);
#if VC34 == 1
            // VC34 : la 3e octave a son PROPRE fondu, deux fois plus proche
            // (771 -> 1151 blocs), parce que son motif est deux fois plus fin
            // et passe donc sous les 2 px d'empreinte du bake demi-res deux
            // fois plus tot. Les deux termes s'additionnent avant le clamp ;
            // mesure : le clamp ne sature sur AUCUN echantillon (p1 -0.593,
            // p99 +0.588 contre la borne -0.94).
            float coton = clamp(vc33Coton * smoothstep(VC33_FADE_FAR, VC33_FADE_NEAR, vc33T)
                              + vc34Coton3 * smoothstep(VC34_FADE3_FAR, VC34_FADE3_NEAR, vc33T),
                                -0.94, 1.0);
#else
            float coton = clamp(vc33Coton * smoothstep(VC33_FADE_FAR, VC33_FADE_NEAR, vc33T), -0.94, 1.0);
#endif
#endif
            float od = cloudOpticalDepthCumulus(wp, lightDirW, t, fld);
            // Beer octaves: T_i = exp(-od sig b^i). msum feeds the sun term
            // through the phase octaves; the normalized plain sum ltA drives
            // ambient modulation and relief (1 at od=0, ~0 in deep shadow).
            float t0e = exp(-od * sigL);
            float t1e = exp(-od * sigL * 0.28);
            float t2e = exp(-od * sigL * 0.0784);
            float msum = t0e * ph0 + 0.52 * t1e * ph1 + 0.2704 * t2e * ph2;
            float ltA = (t0e + 0.52 * t1e + 0.2704 * t2e) * (1.0 / 1.7904);
            // Powder 1-exp(-6d): a thin lit fringe scatters little toward the
            // eye - rescues the dark rims on lit edges (and its complement
            // feeds the silver term). 6 puts the knee at d~0.35: fringe only.
            float powder = 1.0 - exp(-d * 6.0);
            // Dark flat base per CELL (hR), not per slab: pancake TOPS are no
            // longer priced as belly - the core fix for the grey-wash report.
            float baseDark = 1.0 - VC_CUMULUS_BASE_DARK * (1.0 - smoothstep(0.0, 0.55, hR)) * powder;
            // From above: zenith boost shaded by ltA like v5 (troughs stay dark).
            float zenith = (camPos.y > top) ? hR * hR * 0.30 * ltA : 0.0;
            // Ambient gradient on the RELATIVE column too: every cell shows
            // shaded base -> bright top. Slightly lower floor than v5
            // (0.34+0.40*lt -> 0.30+0.46*ltA): a touch more relief contrast,
            // sunlit sum calibrated within +6% of v5 at the top.
            float aH = smoothstep(0.12, 0.85, hR);
#if VC_CAST_SHADOWS == 1
            // Ombre portee (joueur/terrain) : SOLEIL uniquement, jamais
            // l'ambiante du ciel. Paye 1 tap, ici, sur les seuls echantillons
            // qui ont deja passe le seuil de densite.
            float cShad = vlCloudCastShadow(wp);
#else
            float cShad = 1.0;
#endif
#if VC2 == 1 && VC3 == 1 && VC_TEXTURED == 1 && VC33 == 1 && VC_DETAIL == 1
            // VC33 : le coton module le SOLEIL en entier et l'ambiante du ciel
            // a VC33_AMB seulement - les ventres a l'ombre restent lisses,
            // comme sur photo, et seules les faces eclairees prennent la
            // texture de chou-fleur. Facteur de moyenne 1 (E[g] = 0.5 sur les
            // deux canaux egalises) : la luminance moyenne du nuage ne bouge
            // pas (mesure -0.5 %), donc CLOUD_BRIGHTNESS garde son calibrage.
            vec3 S = sunC * msum * (0.35 + powder * 0.85) * cShad * (1.0 + coton)
                   + mix(ambB, ambT * (1.0 + zenith), aH) * (0.30 + 0.46 * ltA) * (1.0 + coton * VC33_AMB);
#else
            vec3 S = sunC * msum * (0.35 + powder * 0.85) * cShad
                   + mix(ambB, ambT * (1.0 + zenith), aH) * (0.30 + 0.46 * ltA);
#endif
            S *= baseDark;
            #if VC_DETAIL == 1
            // Wisps kept from v5: albedo micro-variation, silhouette untouched.
            float wisp = vnoise3(vec3(wp.x + wWind.x, wp.y * 1.8, wp.z + wWind.y) * 0.052);
            S *= 1.0 + (wisp - 0.5) * 0.55 * VC_DETAIL_WISPS;
            #endif
            // Silver lining: v5 term on the octave-summed transmittance.
            float silver = pow(max(cosT, 0.0), 8.0) * ltA * (1.0 - powder);
            // Le lisere est du soleil direct : il suit la meme ombre portee.
            S += sunC * silver * 0.28 * CLOUD_SILVER * VC_CUMULUS_SILVER * (1.0 - rainG) * cShad;

            // Extinction over the LOCAL warped step (v5 contract, dt -> dtL).
            float dtL = vcSpan * 0.5 * VC37_DW(u) * vcInvN;
            float a = exp(-d * 0.05 * dtL * VC_OPACITY);
            acc += trans * S * (1.0 - a);
            trans *= a;
            if (trans < 0.01) break;
        }
    }
#else
    // ---- Contrasted cumulus lighting: cream sun faces, blue-grey bellies ----
    // Tight forward lobe (g=0.72): the sunlit face pops, the shaded face falls
    // back -> the relief is modelled instead of reading as a flat mass.
    float phase = hgPhase(cosT, 0.72) + hgPhase(cosT, -0.22) * 0.45 + 0.030;

    float duskC = clamp(1.0 - abs(sunHeight()) * 4.0, 0.0, 1.0) * smoothstep(-0.14, -0.04, sunHeight()); // asymmetric (night fix)
    vec3 sunC = getLightColor() * 3.6 * CLOUD_BRIGHTNESS;
    // Alto-matched palette (layer 2 look): tops are near-PURE sky ambient -
    // the old 0.10 light term tinted every core a dirty warm grey at noon -
    // and the belly is a brighter, CLEANER blue-grey (never green/yellow).
    // CLOUD_WHITE (CONFIG_CLOUDS): creator dial on the sunlit-top brightness.
    vec3 ambT = (getAmbientColor() * 1.12 + getLightColor() * 0.04) * CLOUD_WHITE;
    // Blue-grey belly (the mass blocks the sky) + golden grazing light at dusk.
    // CLOUD_BELLY_COOL shifts the belly tint around its grey mean (delta form:
    // exact no-op at 1.0); CLOUD_BELLY_BRIGHT scales the sky-ambient share only.
    vec3 bellyTint = vec3(0.33, 0.37, 0.46)
                   + (vec3(0.33, 0.37, 0.46) - vec3(0.3867)) * (CLOUD_BELLY_COOL - 1.0);
    vec3 ambB = getAmbientColor() * bellyTint * CLOUD_BELLY_BRIGHT + getLightColor() * duskC * 0.45;

    // Rain overcast: nimbostratus. The direct sun collapses, the phase goes
    // near-isotropic (a flat deck models no relief) and both ambients drop to
    // a dark neutral slate; getLightColor/getAmbientColor already rain-dim.
    float rainG = rainStrength;
    phase = mix(phase, 0.08, rainG * 0.85);
    sunC *= 1.0 - rainG * 0.72;
    vec3 slate = getAmbientColor() * vec3(0.66, 0.66, 0.70);
    ambT = mix(ambT, slate, rainG * 0.80);
    ambB = mix(ambB, slate * 0.62, rainG * 0.80);

    // Light extinction with a FLOOR (decoupled from a low VC_OPACITY): cores
    // still self-shadow on "light" clouds -> real contrast.
    float sigL = 0.032 * clamp(VC_OPACITY * 0.75, 1.1, 4.0);

    #if VC_DETAIL == 1
    // Wind precomputed to advect the wisps along with the cloud mass
    vec2 wWind = t * vec2(7.0, 2.4) * VC33_WIND;
    #endif

    vec3 acc = vec3(0.0);
    float trans = 1.0;

    for (int i = 0; i < VC_MARCH_SAMPLES; i++) {
        vec3 wp = camPos + dir * tt;
        // Field hoisted out of cloudDensityCumulus: ONE evaluation feeds the
        // density AND the light march (they used to evaluate it twice).
        // Out-of-slab samples (grazing-view march extension) still pay zero
        // taps, exactly like the old h early-out.
        float hIn = (wp.y - VC_BASE) / VC_THICK;
        vec2 fld = (hIn < 0.0 || hIn > 1.0) ? vec2(0.0) : cloudFieldCumulus(wp.xz, t);
        float d = cloudDensityCumulusCov(wp, t, true, fld);
        if (d > 0.002) {
            float od = cloudOpticalDepthCumulus(wp, lightDirW, t, fld);
            // Multi-scatter approximation (2 Beer octaves): the wider 2nd
            // octave keeps cores alto-white instead of dull grey, still modelled
            float lt = exp(-od * sigL) * 0.55 + exp(-od * sigL * 0.20) * 0.45;
            float h = clamp((wp.y - VC_BASE) / VC_THICK, 0.0, 1.0);
            float powder = 1.0 - exp(-d * 7.0);
            // DARK flat base: the belly blocks the sky (sun AND ambient)
            float baseDark = 1.0 - VC_CUMULUS_BASE_DARK * (1.0 - smoothstep(0.0, 0.50, h)) * powder;
            // Seen from above, a uniform zenith boost flattens everything into
            // a white carpet with no visible shadows. It is modulated by lt
            // here (the troughs between domes do not get it) and the ambient
            // leans more on lt -> relief is drawn by the shadowing.
            float zenith = (camPos.y > top) ? h * h * 0.30 * lt : 0.0;
            vec3 S = sunC * lt * phase * (0.30 + powder * 0.95)
                   + mix(ambB, ambT * (1.0 + zenith), h) * (0.34 + 0.40 * lt); // raised ambient floor: shaded faces stay clean, not dead grey
            S *= baseDark;
            #if VC_DETAIL == 1
            // Wisps: internal albedo micro-variation (~20-block features,
            // advected by the wind). Modulates the SOURCE, not the density, so
            // internal structure shows without altering the silhouette.
            // Costs 1 vnoise3 per lit sample.
            float wisp = vnoise3(vec3(wp.x + wWind.x, wp.y * 1.8, wp.z + wWind.y) * 0.052);
            S *= 1.0 + (wisp - 0.5) * 0.55 * VC_DETAIL_WISPS;
            #endif
            // Silver lining: thin sunward edge where light punches through
            float silver = pow(max(cosT, 0.0), 8.0) * lt * (1.0 - powder);
            S += sunC * silver * 0.28 * CLOUD_SILVER * VC_CUMULUS_SILVER * (1.0 - rainG); // no edge flare on a rain deck

            float a = exp(-d * 0.05 * dt * VC_OPACITY);
            acc += trans * S * (1.0 - a);
            trans *= a;
            if (trans < 0.01) break;
        }
        tt += dt;
    }
#endif // VC2 lighting arm (v5 verbatim above at 0 or VC_TEXTURED == 0)
#else
    float phase = hgPhase(cosT, 0.60) * 1.0 + hgPhase(cosT, -0.20) * 0.30 + 0.035;

    float duskC = clamp(1.0 - abs(sunHeight()) * 4.0, 0.0, 1.0) * smoothstep(-0.14, -0.04, sunHeight()); // asymmetric (night fix)
    vec3 sunC = getLightColor() * 2.2 * CLOUD_BRIGHTNESS;
    // CONFIG_CLOUDS dials mirrored from the textured path (exact no-op at 1.0),
    // so the sliders are never silently dead on this legacy raymarch.
    vec3 ambT = (getAmbientColor() * 0.90 + getLightColor() * 0.08) * CLOUD_WHITE;
    // Golden hour: cloud bellies catch fire under grazing light.
    // Cool tint = textured bellyTint normalized by its grey mean, delta form.
    vec3 bellyCool = vec3(1.0) + vec3(-0.147, -0.043, 0.190) * (CLOUD_BELLY_COOL - 1.0);
    vec3 ambB = getAmbientColor() * 0.35 * bellyCool * CLOUD_BELLY_BRIGHT + getLightColor() * duskC * 0.55;

    vec3 acc = vec3(0.0);
    float trans = 1.0;

    for (int i = 0; i < VC_MARCH_SAMPLES; i++) {
        vec3 wp = camPos + dir * tt;
        float d = cloudDensity(wp, t);
        if (d > 0.002) {
            float lt = cloudLightMarch(wp, lightDirW, t);
            float h = clamp((wp.y - VC_BASE) / VC_THICK, 0.0, 1.0);
            float powder = 1.0 - exp(-d * 3.5);
            // From above: tops receive more zenith light
            float zenith = (camPos.y > top) ? h * h * 0.45 : 0.0;
            vec3 S = sunC * lt * phase * (0.6 + powder * 0.7) + mix(ambB, ambT * (1.0 + zenith), h) * 0.50;

            #ifdef CLOUD_SILVER_LINING
                // Silver lining: looking toward the sun (cosT->1) through a thin
                // area where light passes (high lt), the cloud edge blazes.
                // Purely additive term.
                float silver = pow(max(cosT, 0.0), 6.0) * lt;
                S += sunC * silver * 0.6 * CLOUD_SILVER;
            #endif

            float a = exp(-d * 0.05 * dt * VC_OPACITY);
            acc += trans * S * (1.0 - a);
            trans *= a;
            if (trans < 0.01) break;
        }
        tt += dt;
    }
#endif

    float alpha = 1.0 - trans;
    if (alpha < 1e-4) return vec4(0.0);

    // Fade distant clouds into the horizon haze.
    // Range must be measured as the HORIZONTAL distance of the entry point:
    // fading on t0 (distance ALONG the ray) dissolves the cloud carpet into a
    // RING around the nadir when seen from altitude, because t0 climbs fast on
    // oblique aims.
    float tHor = t0 * length(dir.xz);
    // Aerial perspective: far clouds turn a discreet blue-grey (thin distant
    // bands) instead of a milky white veil, and the haze rises more slowly.
    // The VC_CUMULUS_SHAPES=0 branch keeps the original values.
    #if VC_CUMULUS_SHAPES == 1
    const float fogK = 0.00030;
    vec3 fogC = fogCol * vec3(0.80, 0.87, 1.00) * 0.92;
    #else
    const float fogK = 0.00038;
    vec3 fogC = fogCol;
    #endif
    #ifdef CLOUD_EDGE_FADE
    // EDGE fade: clouds whose ENTRY t0 approaches the range cutoff
    // (VC_RENDER_DISTANCE) dissolve into haze instead of stopping abruptly.
    // Based on t0 vs VC_RENDER_DISTANCE: nearby/overhead clouds (small t0) stay
    // OPAQUE, only the far arc fades.
    // At short ranges (< 1000) the fade starts later (~90-block band) instead
    // of eating 25% of the field, so the near sky does not look empty.
    float edgeStart = (VC_RDIST_EFF < 1000.0) ? max(0.75, 1.0 - 100.0 / VC_RDIST_EFF) : 0.75; // VC_RDIST_EFF == VC_RENDER_DISTANCE outside the VC2 textured path
    float edgeF = smoothstep(VC_RDIST_EFF * edgeStart, VC_RDIST_EFF * 0.98, tHor);
    // Brume et fondu de BORD sont separes sous VC36 (ils n'agissent plus sur
    // les memes canaux) ; a gate 0 la ligne reste TOKEN POUR TOKEN celle de
    // VC35, sans variable locale supplementaire.
#if VC36 == 1
    float hazeT = 1.0 - exp(-tHor * fogK);
    float fogT = max(hazeT, edgeF);
#else
    float fogT = max(1.0 - exp(-tHor * fogK), edgeF);
#endif
    vec3 col = acc / alpha;
    col = mix(col, fogC, fogT);
#if VC36 == 1
    // VC36 (C) : LE FONDU DE DISTANCE NE COMPTE PLUS DEUX FOIS. La ligne
    // d'origine etait "alpha *= 1.0 - fogT" JUSTE APRES avoir deja repeint la
    // couleur en fogC = getSkyBase * (.80,.87,1.) * .92, c'est-a-dire le ciel
    // lui-meme : le nuage devenait couleur de ciel ET transparent, deux fois
    // le meme fondu avec le meme facteur. Un coeur OPAQUE laissait passer
    // 12.4 % de ciel a 20 degres d'elevation, 25.0 % a 10, 55.6 % a 6 (mesure
    // vc36_audit.py, camera au sol). C'est la "transparence qui persiste".
    // La perspective aerienne CORRECTE est le mix de couleur seul, a
    // couverture constante : la forme reste pleine, elle vire au gris-bleu.
    // edgeF, lui, RESTE sur l'alpha : ce n'est pas de la brume, c'est la fin
    // du volume marche (sans quoi le bord de la portee redevient un mur).
    // VC36_HAZE_A = 1.0 restitue le comportement VC35 exactement.
    alpha *= 1.0 - max(edgeF, hazeT * VC36_HAZE_A);
#else
    alpha *= 1.0 - fogT;
#endif
    #else
    float fogT = 1.0 - exp(-tHor * fogK);
    vec3 col = acc / alpha;
    col = mix(col, fogC, fogT);
    // Reduced alpha fade: more opaque clouds at the horizon
    // VC36 NE TOUCHE PAS cette branche (CLOUD_EDGE_FADE non defini) : elle n'a
    // pas de fondu de BORD pour prendre le relais, donc c'est ce 0.50 qui fait
    // seul la dissolution a la distance de rendu. Le retirer y remettrait le
    // mur que CLOUD_EDGE_FADE avait justement supprime.
    alpha *= 1.0 - fogT * 0.50;
    #endif

    #if VC_CUMULUS_SHAPES == 1
    // Horizon flattening: from the ground, grazing clouds (< ~11 deg) thin into
    // translucent bluish bands instead of a white wall. Neutralized when the
    // camera is inside or above the sheet (flying through: clouds stay solid).
    // The upper bound FOLLOWS THE SLAB: with the current VC_BASE / VC_THICK the
    // bottom edge of the cumulus deck sits around 9-10 deg of elevation at the
    // shipped VC_RENDER_DISTANCE (atan(146 / 192) for a 12-chunk view), so the
    // old 0.11 (= 6.3 deg) gate had fallen entirely UNDER the deck and never
    // fired: the low edge lost its softening and was left to edgeF alone.
    // 0.19 (= 10.9 deg) puts the fade back across the real grazing band.
    float belowF = clamp((VC_BASE - camPos.y) / 40.0, 0.0, 1.0);
    float lowBand = smoothstep(0.015, 0.19, abs(dir.y));
#if VC36 == 1
    // VC36 (C) : 0.62 -> VC36_LOWBAND. Cet aplatissement reste (il empeche un
    // MUR blanc a l'horizon) mais il retirait 30 a 39 % de l'alpha entre 5 et
    // 6 degres, EN PLUS du fondu de brume ci-dessus : les deux se cumulaient
    // exactement dans la bande ou le joueur voit le plus de ciel nuageux, et
    // c'est aussi la bande ou la marche a CQ1 est la plus grossiere (span de
    // dalle 1350 blocs). Les trois defauts tombaient au meme endroit.
    alpha *= 1.0 - (1.0 - lowBand) * VC36_LOWBAND * belowF;
#else
    alpha *= 1.0 - (1.0 - lowBand) * 0.62 * belowF;
#endif
    #endif

    return vec4(col, alpha);
}

// Legacy 7-argument entry point (deferred inline path, composite1 clouds in
// front of terrain): no temporal interleave. Without CLOUD_TEMPORAL_MARCH the
// extra argument is compiled out above, so this is a pure pass-through.
vec4 volumetricClouds(vec3 camPos, vec3 dir, vec3 lightDirW, vec3 fogCol, float dither, float t, float maxDist) {
    return volumetricClouds(camPos, dir, lightDirW, fogCol, dither, t, maxDist, 0.0);
}

// ============ VOLUMETRIC ALTOCUMULUS (2nd 3D layer) ============
// Thin slab [CLOUD_ALTO_HEIGHT .. +26] marched in 6 steps: real domed puffs
// above the cumulus instead of a flat 2D sheet. Same cell field as the 2D alto
// plus a domed vertical profile. Costs ~1/4 of the cumulus pass.
#if defined CLOUD_LAYER_ALTO && ALTO_VOLUMETRIC == 1
float altoDensity(vec3 wp, float t) {
    float h = (wp.y - VC2_ALTO_H) / 26.0; // VC2: layer raised +50 (415 -> 465); == CLOUD_ALTO_HEIGHT at gate 0
    if (h < 0.0 || h > 1.0) return 0.0;
    vec2 p = wp.xz + t * vec2(11.0, 4.0) * VC_WIND;
#if VC2 == 1
    // VC2: puff features enlarged x1.2 (user request) - the whole 3-octave
    // stack rides qc, so one coordinate shrink scales every octave together;
    // the bank mask below keeps its own scale (placement/quantity untouched).
    // VC34: the user came back asking for SMALLER puffs - VC2_ALTO_ZOOM folds
    // the x1.2 and VC34_ALTO_SIZE into one constant (lib/settings.glsl), so
    // the three SYNC sites still read from a single source.
    vec2 qc = vec2(p.x * 0.011, p.y * 0.0148) * VC2_ALTO_ZOOM;
#else
    vec2 qc = vec2(p.x * 0.011, p.y * 0.0148);
#endif
    float puff = vnoiseTex(qc) * 0.52 + vnoiseTex(qc * 2.63 + 7.7) * 0.31
               + vnoiseTex(qc * 6.1 + 2.9) * 0.17;
    // VC34: VC2_ALTO_BANK0 (0.42 before VC34) thins the SHEETS - the "fewer
    // clouds" half of the request. Chosen over raising the puff threshold
    // because it changes the COUNT without touching puff size and without
    // narrowing any smoothstep window (its own lattice is 1724 blocks wide,
    // so no edge is hardened). == 0.42 at gate 0 and whenever VC2 == 0.
    float bank = smoothstep(VC2_ALTO_BANK0, 0.70, fbm3Tex(p * 0.00058 + 17.3));
    float prof = smoothstep(0.0, 0.25, h) * smoothstep(1.0, 0.45, h);
    // Rain fade (parity with the 2D alto/cirrus): the layer dissolves under
    // the overcast deck instead of poking through thin spots.
    // VC2_ALTO_AMT = CLOUD_ALTO_AMOUNT x0.8 (0.60 at defaults; == the slider at gate 0).
    return smoothstep(0.50, 0.72, puff) * bank * prof * 1.6 * VC2_ALTO_AMT * (1.0 - rainStrength * 0.85);
}
vec4 volumetricAlto(vec3 camPos, vec3 dir, vec3 lightDirW, float dither, float t) {
    float aBase = VC2_ALTO_H;
    float aTop = VC2_ALTO_H + 26.0;
    if (abs(dir.y) < 1e-3) return vec4(0.0);
    float ta = (aBase - camPos.y) / dir.y;
    float tb = (aTop - camPos.y) / dir.y;
    float t0 = max(min(ta, tb), 0.0);
    float t1 = max(ta, tb);
    if (t1 <= 0.0 || t0 * max(abs(dir.y), 0.05) > 900.0) return vec4(0.0);
    t1 = min(t1, t0 + 220.0);
    float dt = (t1 - t0) / 6.0;
    float tt = t0 + dt * dither;
    vec3 sunC = getLightColor() * 2.6;
    vec3 ambT = getAmbientColor();
    float cosT = dot(dir, lightDirW);
    float phase = hgPhase(cosT, 0.55) + 0.06;
    vec3 acc = vec3(0.0);
    float trans = 1.0;
    for (int i = 0; i < 6; i++) {
        vec3 wp = camPos + dir * tt;
        float d = altoDensity(wp, t);
        if (d > 0.003) {
            // 1-tap self-shadowing: models each puff (sun face vs belly)
            float lt = exp(-altoDensity(wp + lightDirW * 14.0, t) * 5.0);
            float hN = clamp((wp.y - aBase) / 26.0, 0.0, 1.0);
            // CLOUD_ALTO_BRIGHT (CONFIG_CLOUDS): layer-2 source brightness, shading only.
            vec3 S = (sunC * lt * phase + mix(ambT * vec3(0.45, 0.50, 0.60), ambT, hN) * 0.55) * CLOUD_ALTO_BRIGHT;
            float aStep = exp(-d * 0.16 * dt);
            acc += trans * S * (1.0 - aStep);
            trans *= aStep;
            if (trans < 0.03) break;
        }
        tt += dt;
    }
    float alpha = 1.0 - trans;
    if (alpha < 1e-3) return vec4(0.0);
    // horizon fade on HORIZONTAL distance (consistent with the cumulus pass)
    float fogT = 1.0 - exp(-t0 * length(dir.xz) * 0.0009);
    alpha *= 1.0 - fogT;
    return vec4(acc / max(alpha, 1e-4), alpha);
}
#endif

/*
    High layers (2D, world-anchored): altocumulus + cirrus.
    Composited BEHIND the volumetric cumulus.
*/
#if CLOUD_HIGH_V3 == 1
// Cirrus: thin ice filaments stretched x13 along the wind, curved by a slow
// warp (uncinus hooks), grouped in BANKS separated by blue sky, strong forward
// scatter near the sun, blazing at dusk.
// Altocumulus: field of small puffs (~90 blocks) in finite sheets, relief lit
// toward the sun (bright faces / shaded troughs), realistic opacities.
vec4 highClouds(vec3 camPos, vec3 dir, vec3 sunDir, float t) {
    vec3 col = vec3(0.0);
    float alpha = 0.0;
    float horizF = smoothstep(0.015, 0.10, abs(dir.y));
    if (horizF <= 0.0) return vec4(0.0);
    float cosS = dot(dir, sunDir);
    float duskH = clamp(1.0 - abs(sunHeight()) * 3.5, 0.0, 1.0) * smoothstep(-0.14, -0.04, sunHeight()); // asymmetric (night fix)
    vec3 lc = getLightColor();
    vec3 amb = getAmbientColor();

    // --- Cirrus (~VC2_CIRRUS_H: 710 under VC2, CLOUD_CIRRUS_HEIGHT at gate 0) ---
    #ifdef CLOUD_LAYER_CIRRUS
    {
        float tc = (VC2_CIRRUS_H - camPos.y) / dir.y;
        if (tc > 0.0) {
            vec2 p = camPos.xz + dir.xz * tc + t * vec2(18.0, 6.0) * VC_WIND;
            // Anisotropic frame: u along the wind, v across
            vec2 axW = normalize(vec2(18.0, 6.0));
            vec2 q = vec2(dot(p, axW), dot(p, vec2(-axW.y, axW.x)));
#if VC2 == 1
            // VC2: cirrus features x0.8 (user request). One coordinate zoom
            // BEFORE the warp: filaments, cross fibres AND the streak
            // curvature (freq and 480-block amplitude alike, both in q units)
            // shrink together, proportions intact. The bank mask stays on p:
            // sheet placement/quantity untouched. MIRRORED in haloVeilCov.
            q *= 1.25;
#endif
            // Slow streak curvature (transverse undulation ~240 blocks)
            q.y += (vnoise(vec2(q.x * 0.00040, q.y * 0.0014) + 3.1) - 0.5) * 480.0;
            // fbm stretched x13 -> filaments; + high-frequency cross fibres
            float n = fbm(vec2(q.x * 0.00032, q.y * 0.00415));
            n = n * 0.74 + vnoise(vec2(q.x * 0.0012, q.y * 0.0165)) * 0.26;
            // Low-frequency banks: cirrus sheets, not a uniform veil
            float bank = smoothstep(0.34, 0.78, fbm3(p * 0.00016 + 41.2));
            float cm = smoothstep(0.46, 0.80, n) * bank;
            cm = cm * cm * (3.0 - 2.0 * cm); // sharpen the streaks
            cm *= horizF * (1.0 - rainStrength * 0.7) * 0.34 * CLOUD_CIRRUS_AMOUNT;
            // Thin ice: forward scatter near the sun + blaze at sunset
            vec3 cirC = amb * 0.80 + lc * (0.55 + 0.90 * pow(max(cosS, 0.0), 6.0));
            cirC += lc * duskH * 0.80;
            alpha = clamp(cm, 0.0, 1.0);
            col = cirC * alpha; // premultiplied: no ghost cirrus tint under the alto
        }
    }
    #endif

    // --- Altocumulus (~VC2_ALTO_H), composited IN FRONT of the cirrus ---
    // (this 2D version is DISABLED when ALTO_VOLUMETRIC=1: the 3D slab replaces it)
    #if defined CLOUD_LAYER_ALTO && ALTO_VOLUMETRIC == 0
    {
        float ta = (VC2_ALTO_H - camPos.y) / dir.y;
        if (ta > 0.0) {
            vec2 p = camPos.xz + dir.xz * ta + t * vec2(11.0, 4.0) * VC_WIND;
            // Slightly anisotropic cell field -> near-regular rows
#if VC2 == 1
            vec2 q = vec2(p.x * 0.011, p.y * 0.0148) * VC2_ALTO_ZOOM; // SYNC: same puff zoom as the 3D slab (VC2 x1.2, VC34 x VC34_ALTO_SIZE)
#else
            vec2 q = vec2(p.x * 0.011, p.y * 0.0148);
#endif
            float puff = vnoiseTex(q) * 0.52 + vnoiseTex(q * 2.63 + 7.7) * 0.31
                       + vnoiseTex(q * 6.1 + 2.9) * 0.17;
            // Finite sheets (banks): never paves the whole sky
            // SYNC: same VC2_ALTO_BANK0 as the 3D slab. Its own puff window
            // (0.505-0.66) is left alone on purpose - it is NARROWER than the
            // slab's (0.50-0.72), so raising it instead would have hardened
            // this flat sheet's edges much more than the slab's.
            float bank = smoothstep(VC2_ALTO_BANK0, 0.70, fbm3Tex(p * 0.00058 + 17.3));
            float am = smoothstep(0.505, 0.66, puff) * bank;
            if (am > 0.001) {
                // Relief: field gradient toward the sun -> bright face / shaded trough
                float sunLow = clamp(1.0 - sunDir.y * 1.6, 0.5, 1.8);
                vec2 so = normalize(sunDir.xz + vec2(1e-4)) * 0.045 * sunLow;
                float puff2 = vnoiseTex(q + so) * 0.52 + vnoiseTex((q + so) * 2.63 + 7.7) * 0.31
                            + vnoiseTex((q + so) * 6.1 + 2.9) * 0.17;
                float shade = clamp((puff - puff2) * 9.0 + 0.5, 0.0, 1.0);
                vec3 bright = amb * 0.92 + lc * (0.42 + 0.45 * duskH);
                vec3 darkC  = amb * vec3(0.38, 0.42, 0.52) + lc * duskH * 0.18;
                vec3 altoC = mix(bright, darkC, shade) * CLOUD_ALTO_BRIGHT; // CONFIG_CLOUDS layer-2 dial
                // Silver edge on the sun side of the thin puffs
                altoC += lc * pow(max(cosS, 0.0), 10.0) * 0.35 * (1.0 - am);
                am *= horizF * (1.0 - rainStrength * 0.5) * 0.62 * VC2_ALTO_AMT; // VC2: x0.8; == slider at gate 0
                am = clamp(am, 0.0, 1.0);
                col = col * (1.0 - am) + altoC * am; // premultiplied "over"
                alpha = alpha * (1.0 - am) + am;
            }
        }
    }
    #endif

    alpha = clamp(alpha, 0.0, 1.0);
    // Un-premultiply: the consumer (deferred) does mix(sky, rgb, a)
    return vec4(col / max(alpha, 1e-4), alpha);
}
#else
vec4 highClouds(vec3 camPos, vec3 dir, vec3 sunDir, float t) {
    vec3 col = vec3(0.0);
    float alpha = 0.0;
    float horizF = smoothstep(0.015, 0.10, abs(dir.y));

    // --- Cirrus (VC2_CIRRUS_H): filaments stretched by the wind ---
    #ifdef CLOUD_LAYER_CIRRUS
    {
        float tc = (VC2_CIRRUS_H - camPos.y) / dir.y; // VC2 raises the plane; pattern untouched on this legacy branch
        if (tc > 0.0) {
            vec2 p = camPos.xz + dir.xz * tc + t * vec2(18.0, 6.0) * VC_WIND;
            float warp = vnoiseTex(p * 0.0016) * 60.0;
            float n = fbmTex(vec2((p.x + warp) * 0.0011, p.y * 0.0040));
            n = n * 0.75 + fbmTex(vec2(p.x * 0.0038, p.y * 0.0012)) * 0.25;
            float cm = pow(smoothstep(0.42, 0.86, n), 1.7) * 0.42;
            cm *= horizF * (1.0 - rainStrength * 0.6);
            vec3 cc = getLightColor() * 0.40 + getAmbientColor() * 0.90;
            col = cc;
            alpha = cm;
        }
    }
    #endif

    // --- Altocumulus (VC2_ALTO_H): regular mackerel pattern ---
    #ifdef CLOUD_LAYER_ALTO
    {
        float ta = (VC2_ALTO_H - camPos.y) / dir.y; // VC2 raises the plane; pattern untouched on this legacy branch
        if (ta > 0.0) {
            vec2 p = camPos.xz + dir.xz * ta + t * vec2(11.0, 4.0) * VC_WIND;
            float n = vnoiseTex(p * 0.0050) * 0.55 + vnoiseTex(p * 0.016) * 0.30 + vnoiseTex(p * 0.045) * 0.15;
            float sunLow = clamp(1.0 - sunDir.y * 2.0, 0.3, 1.6);
            vec2 so = normalize(sunDir.xz + vec2(1e-4)) * (22.0 * sunLow);
            float n2 = vnoiseTex((p + so) * 0.0050) * 0.55 + vnoiseTex((p + so) * 0.016) * 0.30 + vnoiseTex((p + so) * 0.045) * 0.15;
            float shade = clamp((n - n2) * 6.0 + 0.5, 0.0, 1.0);
            float am = smoothstep(0.54, 0.74, n) * 0.55;
            am *= horizF * (1.0 - rainStrength * 0.4);
            vec3 bright = getLightColor() * 0.35 + getAmbientColor() * 0.85;
            vec3 dark   = getAmbientColor() * 0.55;
            vec3 ac = mix(bright, dark, shade * 0.6) * CLOUD_ALTO_BRIGHT; // CONFIG_CLOUDS layer-2 dial

            col = mix(col, ac, am);
            alpha = alpha + am * (1.0 - alpha);
        }
    }
    #endif

    return vec4(col, clamp(alpha, 0.0, 1.0));
}
#endif

// ============ SUN_HALO: 22-degree halo on the thin high veils ============
#if SUN_HALO == 1 && (defined CLOUD_LAYER_ALTO || defined CLOUD_LAYER_CIRRUS)
/*
    Veil coverage of the high layers along the view ray, 0..1. Re-samples the
    SAME fields the layers draw (alto cells + banks of highClouds /
    altoDensity, cirrus filaments + banks) at the ray / layer-height
    intersection, so the halo only exists where a veil is actually on screen.
    SYNC CONTRACT: any change to those fields above must be mirrored here.
    The 3D alto slab is priced analytically (mid-slab density x path length,
    same extinction as the march) - no second march. Paid only inside the
    18-26 deg annulus around the body (see skyHalo22).
*/
float haloVeilCov(vec3 camPos, vec3 dir, float t) {
    float horizF = smoothstep(0.015, 0.10, abs(dir.y));
    if (horizF <= 0.0) return 0.0;
    float cov = 0.0;
    #ifdef CLOUD_LAYER_ALTO
    {
        float hA = VC2_ALTO_H; // VC2 mirror: same raised plane as the layers
        #if CLOUD_HIGH_V3 == 1 && ALTO_VOLUMETRIC == 1
        hA += 13.0; // middle of the 26-block slab
        #endif
        float ta = (hA - camPos.y) / dir.y;
        if (ta > 0.0) {
            vec2 p = camPos.xz + dir.xz * ta + t * vec2(11.0, 4.0) * VC_WIND;
            #if CLOUD_HIGH_V3 == 1
#if VC2 == 1
            vec2 q = vec2(p.x * 0.011, p.y * 0.0148) * VC2_ALTO_ZOOM; // SYNC mirror of the puff zoom (VC2 x1.2, VC34 x VC34_ALTO_SIZE)
#else
            vec2 q = vec2(p.x * 0.011, p.y * 0.0148);
#endif
            float puff = vnoiseTex(q) * 0.52 + vnoiseTex(q * 2.63 + 7.7) * 0.31
                       + vnoiseTex(q * 6.1 + 2.9) * 0.17;
            // SYNC mirror of VC2_ALTO_BANK0 (0.42 before VC34). Thinning the
            // sheets thins the veil too, so the 22 deg ring is readable on
            // 12.0 % -> 9.5 % of the sky: fewer veils, fewer halos - the
            // direct and intended consequence, not a regression.
            float bank = smoothstep(VC2_ALTO_BANK0, 0.70, fbm3Tex(p * 0.00058 + 17.3));
            #if ALTO_VOLUMETRIC == 1
            // Slab opacity: mid-slab density x path through the slab (26 /
            // |dir.y|, capped at 220 like the march), 0.8 = mean of the domed
            // vertical profile, 0.16 = the march extinction.
            float dA = smoothstep(0.50, 0.72, puff) * bank * 1.6 * VC2_ALTO_AMT * (1.0 - rainStrength * 0.85);
            float lenA = min(26.0 / max(abs(dir.y), 0.118), 220.0);
            cov = 1.0 - exp(-dA * 0.16 * lenA * 0.8);
            #else
            cov = smoothstep(0.505, 0.66, puff) * bank * (1.0 - rainStrength * 0.5) * 0.62 * VC2_ALTO_AMT;
            #endif
            // Near-invisible ice sheet the puffs sit in (a bank is a sheet
            // with holes): thin-veil floor so the ring stays continuous
            // across a bank and only breaks on the opaque cores.
            cov = max(cov, 0.25 * bank * min(VC2_ALTO_AMT, 1.0) * (1.0 - rainStrength * 0.85));
            #else
            float n = vnoiseTex(p * 0.0050) * 0.55 + vnoiseTex(p * 0.016) * 0.30 + vnoiseTex(p * 0.045) * 0.15;
            cov = smoothstep(0.54, 0.74, n) * 0.55 * (1.0 - rainStrength * 0.4);
            #endif
        }
    }
    #endif
    #ifdef CLOUD_LAYER_CIRRUS
    {
        float tc = (VC2_CIRRUS_H - camPos.y) / dir.y; // VC2 mirror: raised plane
        if (tc > 0.0) {
            vec2 p = camPos.xz + dir.xz * tc + t * vec2(18.0, 6.0) * VC_WIND;
            float cm = 0.0;
            #if CLOUD_HIGH_V3 == 1
            vec2 axW = normalize(vec2(18.0, 6.0));
            vec2 q = vec2(dot(p, axW), dot(p, vec2(-axW.y, axW.x)));
#if VC2 == 1
            q *= 1.25; // VC2 mirror of the x0.8 cirrus feature zoom (highClouds)
#endif
            q.y += (vnoise(vec2(q.x * 0.00040, q.y * 0.0014) + 3.1) - 0.5) * 480.0;
            float n = fbm(vec2(q.x * 0.00032, q.y * 0.00415));
            n = n * 0.74 + vnoise(vec2(q.x * 0.0012, q.y * 0.0165)) * 0.26;
            float bank = smoothstep(0.34, 0.78, fbm3(p * 0.00016 + 41.2));
            cm = smoothstep(0.46, 0.80, n) * bank;
            cm = cm * cm * (3.0 - 2.0 * cm);
            cm *= (1.0 - rainStrength * 0.7) * 0.34 * CLOUD_CIRRUS_AMOUNT;
            #else
            float warp = vnoiseTex(p * 0.0016) * 60.0;
            float n = fbmTex(vec2((p.x + warp) * 0.0011, p.y * 0.0040));
            n = n * 0.75 + fbmTex(vec2(p.x * 0.0038, p.y * 0.0012)) * 0.25;
            cm = pow(smoothstep(0.42, 0.86, n), 1.7) * 0.42 * (1.0 - rainStrength * 0.6);
            #endif
            cov = cov + cm - cov * cm; // union of the two veils
        }
    }
    #endif
    return clamp(cov, 0.0, 1.0) * horizF;
}

// Thin-veil weight: a dense veil hides the body, no halo
float haloThinW(float cov) {
    return cov * (1.0 - smoothstep(0.45, 0.85, cov));
}

/*
    22-degree halo (ice-crystal refraction) around the sun by day and the moon
    by night (0.5x), where the ray crosses a THIN high veil. Called by
    deferred.fsh (inline) and prepare.fsh (half-res bake) with the same ray,
    after the high layers and before the cumulus. Real halos are asymmetric:
    sharp reddish inner edge (21.6 deg), diffuse white-blue outer edge (22.8),
    darker sky just inside. Lit by the direct light color (luma capped at
    2.0). Returns the additive ring; dark = factor for the sky inside the
    ring (x0.96 at full weight), applied by the caller.
*/
vec3 skyHalo22(vec3 camPos, vec3 dir, vec3 sunDir, float t, out float dark) {
    dark = 1.0;
    float sh = sunDir.y;
    // Body gates: sun by day, moon at half strength by night; both fade at
    // the horizon where the disc is cut by the terrain and the haze.
    float sunG = smoothstep(0.0, 0.08, sh);
    float moonG = smoothstep(0.0, 0.08, -sh) * 0.5;
    float bodyG = max(sunG, moonG);
    if (bodyG <= 0.001) return vec3(0.0);
    vec3 bodyDir = (sunG >= moonG) ? sunDir : -sunDir;
    float cosT = dot(dir, bodyDir);
    // 18..26 deg annulus only: not even the veil taps are paid outside
    if (cosT < 0.8988 || cosT > 0.9511) return vec3(0.0);
    // Thin veil on the ring AND toward the body (a dense alto hides the sun)
    float w = haloThinW(haloVeilCov(camPos, dir, t)) * bodyG * SUN_HALO_STRENGTH;
    if (w <= 0.001) return vec3(0.0);
    w *= 1.0 - smoothstep(0.45, 0.85, haloVeilCov(camPos, bodyDir, t));
    float th = acos(cosT) * 57.29578;
    // Asymmetric ring profile: sharp inside, diffuse outside. Explicit
    // square (pow of a negative base is undefined in GLSL -> NaN on some
    // drivers, and this feeds the TAA / bloom history).
    float xr = (th - 22.0) / ((th < 22.0) ? 0.6 : 1.1);
    float ring = exp(-xr * xr);
    vec3 tint = mix(vec3(1.0, 0.55, 0.40), vec3(0.85, 0.92, 1.0), smoothstep(21.4, 22.8, th));
    // Slightly darker just inside the ring (nothing is refracted under 22
    // deg): x0.96 at the thin-veil peak (haloThinW tops out near 0.48).
    dark = 1.0 - 0.08 * w * smoothstep(18.0, 19.5, th) * (1.0 - smoothstep(20.5, 21.8, th));
    vec3 lc = getLightColor();
    lc *= min(1.0, 2.0 / max(luma(lc), 1e-3));
    return lc * tint * ring * 0.10 * w;
}
#endif
