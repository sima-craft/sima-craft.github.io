/*
    CLOUD_TEMPORAL - layout of colortex15 shared by the two half-res cloud
    passes: prepare.fsh (reduced march + history carry) and prepare1.fsh
    (temporal resolve). Included only while CLOUD_TEMPORAL == 1; requires
    settings.glsl and common.glsl (TAAU_S) first. Everything is in quadrant
    TEXELS: quadrant texel (i, j) holds the ray of full-res pixel (2i, 2j).
      X = 0.5 * TAAU_S * res        quadrant size (fractional allowed)
      G = floor(X + 1.5)            last column / row written by the march:
          the legacy 2-texel guard band, i.e. exactly the texels kept by the
          "uv > 0.5 * TAAU_S + 2 px -> discard" test of prepare.fsh
      C = min(floor(X - 0.5), res - 1 - G)
          last quadrant texel whose HISTORY COPY still fits: texel (i, j)
          with 1 <= i <= C.x, 1 <= j <= C.y is copied to (i, j) + G, i.e.
          into the otherwise unused upper-right area, clear of the guard
          band. At TAAU_S = 1 this is one texel short of the quadrant (two
          on an odd dimension) - the price of the 2-texel guard band; those
          edge texels (and texel 0, whose copy would land on the guard band)
          borrow their neighbour's history: the resolve clamps its tap p
          (texel units) into [1.5, C + 0.5], the band where a bilinear tap
          touches texels floor(p - 0.5) and + 1 inside [1, C]. Below
          TAAU_S = 1 the whole quadrant fits.
    Why a copy at all: Iris ping-pongs colortexN between main and alt. With
    two prepare passes, prepare reads main (last frame) and writes alt,
    prepare1 reads alt and writes main, deferred reads main and the buffer
    ends the frame un-flipped. The resolve can therefore only see what
    prepare wrote this frame, so prepare must carry the previous resolved
    quadrant into alt next to its raw march. RGBA16F texel-center copy: exact.
*/
vec2 ctGuard(vec2 res) {
    return floor(0.5 * TAAU_S * res + 1.5);
}
vec2 ctCopyMax(vec2 res) {
    return min(floor(0.5 * TAAU_S * res - 0.5), res - 1.0 - ctGuard(res));
}
