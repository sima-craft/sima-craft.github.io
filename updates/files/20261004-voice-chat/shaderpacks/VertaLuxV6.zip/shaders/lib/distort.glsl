/*
    VertaLux — shadow map distortion.
    Concentrates shadow map resolution near the player:
    close shadows stay sharp, distant ones remain acceptable.
*/

// SHADOW_DISTORT_STRENGTH: slider in lib/settings.glsl, included BEFORE this file
// by all consumers. Fallback 0.85 applies if a program ever includes distort.glsl
// without settings.glsl. The VLX_SHADOW_DISTORT alias avoids a second
// "#define SHADOW_DISTORT_STRENGTH" (Iris' option scanner would flag the option
// as ambiguous and drop the slider from the menu). Writer (shadow.vsh) and all
// readers (lighting PCF/PCSS, composite1 caustics/AO/glint/godrays, composite RSM)
// must share these THREE functions (factor, derivative, packing) so the
// distortion curve stays globally consistent. NOTE: with SHADOW_LOD_V2 = 1
// (default) the curve is the PLATEAU one below and this constant is only its
// legacy fallback; the near-field magnification is then SHADOW_SHARP_LEVEL's
// VLX_LOD_M0, not (1 - S).
#ifdef SHADOW_DISTORT_STRENGTH
    #define VLX_SHADOW_DISTORT SHADOW_DISTORT_STRENGTH
#else
    #define VLX_SHADOW_DISTORT 0.85
#endif

// Same alias mechanism for the Z packing (SHADOW_Z_SCALE, lib/settings.glsl):
// scales the shadow frustum depth range (z*0.2 = 5x range vs 2x for 0.5).
// Fallback 0.5 if distort.glsl is included without settings.glsl.
// WRITER (shadow.vsh) and ALL readers (lighting.glsl PCF/PCSS, composite RSM,
// composite1 caustics/godrays) must go through VLX_SHADOW_ZSCALE.
#ifdef SHADOW_Z_SCALE
    #define VLX_SHADOW_ZSCALE SHADOW_Z_SCALE
#else
    #define VLX_SHADOW_ZSCALE 0.5
#endif

// Same alias for the LOD gate (SHADOW_LOD_V2, lib/settings.glsl). Fallback 0:
// a program that includes distort.glsl without settings.glsl gets the legacy
// curve, which only depends on VLX_SHADOW_DISTORT (the plateau constants below
// need shadowDistance and the VLX_LOD_* tables, which live in settings.glsl).
#ifdef SHADOW_LOD_V2
    #define VLX_SHADOW_LOD SHADOW_LOD_V2
#else
    #define VLX_SHADOW_LOD 0
#endif

// Same alias for the LOT B gate PERF_DISTORT_LUT (lib/settings.glsl): 1 swaps
// the ramp's Cardano solver for the fitted rational spline below. Fallback 0:
// a program that includes distort.glsl without settings.glsl keeps the exact
// solver (and the legacy curve does not go through either branch anyway).
#ifdef PERF_DISTORT_LUT
    #define VLX_DISTORT_LUT PERF_DISTORT_LUT
#else
    #define VLX_DISTORT_LUT 0
#endif

/*
    THE CURVE. Writing q = |uv radius| and d = |clip radius| (both in the L3
    norm below, so "radius" means the same superellipse on both sides):
      legacy (SHADOW_LOD_V2 0, bit-identical to the shipped pack):
        f(d) = S*d + (1-S), S = VLX_SHADOW_DISTORT, u = x / f.
      LOD  (SHADOW_LOD_V2 1): a true near-field PLATEAU, then a cubic ramp
        (C1 junction -- h''=0 on the ramp side only, see below).
        The curve is DEFINED through its inverse world = h(map), because any h
        with h' > 0 and h(1) = 1 gives a fold-free, full-coverage distortion
        (h' is also exactly the RADIAL texel ratio vs an undistorted map):
          plateau  q <= qa : h(q) = M0*q / (1 - TILT*q)      (f = M0 + TILT*d)
          ramp     q >  qa : h(q) = aE + H1*D + E*D^3, D = q - qa
        with, all POSED AS CONST BELOW (driver folds them):
          M0   = plateau texel ratio (1/M0 = central magnification), from
                 SHADOW_SHARP_LEVEL via the VLX_LOD_M0 table in settings.glsl;
          aE   = clip radius of the plateau = min(R / shadowDistance, QMAX*M0*K)
                 with R in blocks from SHADOW_SHARP_RANGE (VLX_LOD_R table) --
                 the min() is the AREA/STABILITY BUDGET: the plateau may not
                 claim more than QMAX of the map radius, QMAX = min(0.72, 6*M0)
                 (see the SHADOW LOD block of lib/settings.glsl for the sizing);
          K    = 1 + KAPPA = 1.08: the plateau is TILTED by KAPPA = 0.08 --
                 f grows 8% across the plateau (the radial texel h', which
                 goes as K^2, grows 1.08^2 = 16.6%, and h' is the reference
                 of every texel table) -- so f stays STRICTLY increasing --
                 sampleShadowPCFV2's jacobian needs f' > 0, not just f'>= 0;
          qa   = aE / (M0*K);   H1 = M0*K*K  (= h' at the junction, C1);
          E    = (1 - aE - H1*(1-qa)) / (1-qa)^3   (> 0 by the QMAX clamp;
                 makes h(1) = 1 EXACT, so the map still covers the whole
                 shadowDistance disk -- no hole at the border).
        The ramp is CUBIC so h'' = 0 on ITS side of the junction; the plateau
        side keeps h''(qa-) = 2*M0*TILT*K^3 (~0.063 at the defaults), so the
        joint is C1, NOT C2 -- and C1 is the property that matters: h' (the
        radial texel) is continuous, so the jacobian J and the V2 bias Tb
        move continuously and no shadow edge pops. Per-vertex interpolation
        error of shadow.vsh on 1-block faces (estimator: chord sag =
        |q''|*dw^2/8 converted to texels, with q'' = -h''/h'^3) peaks at
        1-2.8 px over the 64 tier combos WITH the 6*M0 clamp (1.3 px at the
        default L2/R0 on SHADOW_QUALITY 0; legacy curve: 0.6-0.7 px).
        Without that clamp the same cubic reached ~4.8 px on the clamped x10
        combos, and a quadratic ramp (h'' jump at the junction) computed
        ~7x worse still -- warp concentrated on the junction ring, a ring
        that FOLLOWS the camera. Hence cubic + per-level clamp.
        FORWARD EVALUATION (f from d, what every caller needs): the plateau
        piece is closed-form; the ramp solves E*D^3 + H1*D = d - aE, a
        depressed cubic with ONE real root (E,H1 > 0), by Cardano:
          s = (d - aE)/E,  p = H1/E,
          w = cbrt(s/2 + sqrt(s^2/4 + p^3/27)),  D = w - p/(3w),
        then f = d / (qa + D). w >= sqrt(p/3) > 0: no division hazard, and
        D -> 0 smoothly as d -> aE+ (the two pieces join exactly).
        DERIVATIVE (getDistortDeriv): f' = TILT on the plateau; on the ramp,
        from q' = 1/h'(q) = 1/(H1 + 3E*D^2):  f' = (q - d*q') / q^2.
        Monotonicity (checked over all 64 tier combos): q strictly increasing
        (h' > 0), f strictly increasing (h' is increasing, so h/q < h'), and
        beyond the border (d > 1, map corners) both keep growing like legacy.
        ALU COST OF THE TOGGLE: the two menu AXES are free (every VLX_LOD_*
        constant folds at compile time, all 16 notches cost the same), but
        SHADOW_LOD_V2 = 1 itself is NOT free versus legacy: the ramp branch
        costs cbrt(pow) + sqrt + cbrt(pow) + 3 divisions per call where the
        legacy curve cost one cbrt(pow) + 1 mad, and the ramp covers almost
        the whole disk (the plateau is 12 of 192 blocks at the defaults).
        Loop-site call counts: RSM (composite.fsh) 3 calls per sample x
        RSM_SAMPLES up to 24 = up to 72 Cardano solves per GI pixel; the VL
        march (composite1.fsh + its mirror lib/vl_halfres.glsl) 1 per step;
        receivers (lib/lighting.glsl) ~1-3 per shaded pixel. The same
        accounting sits next to the "free axes" claim in the SHADOW LOD
        block of lib/settings.glsl.
        --------------------------------------------------------------------
        PERF_DISTORT_LUT (LOT B, B2) -- the ANALYTIC LUT that replaces the
        Cardano solve above (gate 0 keeps that solver verbatim). No texture:
        the cubic E*D^3 + H1*D = x (x = d - aE) reduces, via D = sqrt(p)*u
        with p = H1/E, to the UNIVERSAL one-parameter root
            u^3 + u = y,   y = x / (H1*sqrt(p)),   g(y) = that root
        (odd, g(0)=0, g'(0)=1, ~ y^(1/3) at infinity) -- ONE curve for every
        menu combo, so the coefficients could be fitted OFFLINE ONCE
        (scratchpad b2_fit5.py, Gauss-Newton weighted by the error INDUCED on
        f across all 64 SHARP_LEVEL x SHARP_RANGE x SHADOW_QUALITY combos).
        THE FIT: 3 C1 rational segments in y (value+slope continuity built
        into the parametrisation; g(0)=0 and g'(0)=1 EXACT, so the
        plateau/ramp junction stays C1 like the true curve):
            y in [0,2)   : (cubic)/(quadratic)
            y in [2,12)  : (cubic)/(quadratic)
            y in [12,inf): (quadratic)/(linear) -- its LINEAR asymptote IS
                           the out-of-map safety tail: fitted g >= exact g
                           beyond the fitted range (checked to y=200), so
                           q_hat = d/f grows monotonically and geometry
                           outside the map can never be pulled back in.
        MEASURED (b2_fit5.py + b2_verify_glsl.py, float32 Horner exactly as
        written below, 64 combos, d dense in [aE, 1]):
            max |f_fit/f_exact - 1|          = 0.261 %  (< 0.3 % target;
                                               worst at M0=0.14 R=12 sd=384,
                                               d = 1.0, the map border)
            junction band d in [aE, 1.5*aE]  = 0.086 %
            coverage |q(1) - 1|              <= 0.0026
            f_fit strictly increasing        checked d in [aE, 3], g' > 0
                                             checked y in [0, 200]
        WHY 0.261 % IS SAFE FOR ACNE: the writer (shadow.vsh) and every
        reader use THESE SAME functions, so the fit error cancels exactly
        between map write and map read; what must agree is the BIAS with the
        JACOBIAN, and getDistortDeriv below differentiates the SAME rational
        piece analytically (max 0.12 % against the finite difference of the
        fitted curve itself). The absolute 0.261 % only shifts which world
        ring lands on the outer map texels (~1 block at shadowDistance 384).
        COST: the y remap and sqrt(p) are constant expressions
        (inversesqrt/sqrt of compile-time consts -- folded by the driver), so
        the ramp costs 2-3 compares + ~8 mad + 2 div, against
        cbrt(pow) + sqrt + cbrt-free 3 div for Cardano: the exp2/log2 pair of
        the pow() is gone entirely.
*/
#if VLX_SHADOW_LOD == 1
// Derived once, at global scope, from settings.glsl's tables. GLSL 120 only
// allows operators and ?: in const initializers (no min()), hence the ternary.
const float VLX_LOD_QMAXF = (6.0 * VLX_LOD_M0 < 0.72) ? 6.0 * VLX_LOD_M0 : 0.72;
const float VLX_LOD_AREQ  = VLX_LOD_R / shadowDistance;
const float VLX_LOD_ACAP  = VLX_LOD_QMAXF * VLX_LOD_M0 * 1.08;
const float VLX_LOD_AE    = (VLX_LOD_AREQ < VLX_LOD_ACAP) ? VLX_LOD_AREQ : VLX_LOD_ACAP;
const float VLX_LOD_QA    = VLX_LOD_AE / (VLX_LOD_M0 * 1.08);
const float VLX_LOD_TILT  = 0.08 * VLX_LOD_M0 / VLX_LOD_AE;
const float VLX_LOD_H1    = VLX_LOD_M0 * (1.08 * 1.08);
const float VLX_LOD_E     = (1.0 - VLX_LOD_AE - VLX_LOD_H1 * (1.0 - VLX_LOD_QA))
                          / ((1.0 - VLX_LOD_QA) * (1.0 - VLX_LOD_QA) * (1.0 - VLX_LOD_QA));
const float VLX_LOD_P     = VLX_LOD_H1 / VLX_LOD_E;
#endif

float getDistortFactor(vec2 v) {
    float d = pow(abs(v.x * v.x * v.x) + abs(v.y * v.y * v.y), 1.0 / 3.0);
#if VLX_SHADOW_LOD == 1
    if (d <= VLX_LOD_AE) return VLX_LOD_M0 + VLX_LOD_TILT * d;
#if VLX_DISTORT_LUT == 1
    // PERF_DISTORT_LUT ramp: fitted rational spline for g(y), the root of
    // u^3 + u = y (see the LUT section of the header for the derivation,
    // the offline fit and the measured error). The remap constant
    // inversesqrt(P)/H1 = 1/(H1*sqrt(p)) folds at compile time.
    float y = (d - VLX_LOD_AE) * (inversesqrt(VLX_LOD_P) / VLX_LOD_H1);
    float g;
    if (y < 2.0) {
        g = (y + (2.41839457 + 0.337441117 * y) * (y * y))
          / (1.0 + (2.32481837 + 2.17753124 * y) * y);
    } else if (y < 12.0) {
        float t = y - 2.0;
        g = (1.00092936 + (2.534287 + (0.845025361 + 0.0144874444 * t) * t) * t)
          / (1.0 + (2.27606201 + 0.3466658 * t) * t);
    } else {
        float t = y - 12.0;
        g = (2.1451273 + (0.14577396 + 0.000542358321 * t) * t)
          / (1.0 + 0.0358357057 * t);
    }
    // D = sqrt(p) * g, q = qa + D, f = d / q  (sqrt(P) folds like the remap)
    return d / (VLX_LOD_QA + g * sqrt(VLX_LOD_P));
#else
    float s = (d - VLX_LOD_AE) / VLX_LOD_E;
    float w = pow(0.5 * s + sqrt(0.25 * s * s + VLX_LOD_P * VLX_LOD_P * VLX_LOD_P * (1.0 / 27.0)), 1.0 / 3.0);
    return d / (VLX_LOD_QA + w - VLX_LOD_P / (3.0 * w));
#endif
#else
    return d * VLX_SHADOW_DISTORT + (1.0 - VLX_SHADOW_DISTORT);
#endif
}

// df/dd of the curve above, evaluated from (d, f) with NO second Cardano:
// on the ramp q = d/f recovers the map radius the factor call already solved
// for. Consumed by sampleShadowPCFV2's jacobian (lib/lighting.glsl), which
// used to hard-code the legacy slope VLX_SHADOW_DISTORT -- keep every reader
// of the SLOPE of the curve on this function, exactly like the factor itself.
// SHADOW_LOD_V2 0 returns that constant, so the V2 bias path stays
// bit-identical to the shipped pack.
float getDistortDeriv(float d, float f) {
#if VLX_SHADOW_LOD == 1
    if (d <= VLX_LOD_AE) return VLX_LOD_TILT;
#if VLX_DISTORT_LUT == 1
    // PERF_DISTORT_LUT: the derivative of the SAME fitted piece the factor
    // call selected (bias/jacobian coherence -- see the header). q = d/f
    // recovers qa + sqrt(p)*g exactly as computed there, and
    // dq/dd = g'(y) * sqrt(p) * dy/dd = g'(y) / H1.
    float y = (d - VLX_LOD_AE) * (inversesqrt(VLX_LOD_P) / VLX_LOD_H1);
    float rN; float rNp; float rD; float rDp;
    if (y < 2.0) {
        rN  = y + (2.41839457 + 0.337441117 * y) * (y * y);
        rNp = 1.0 + (4.83678913 + 1.01232335 * y) * y;
        rD  = 1.0 + (2.32481837 + 2.17753124 * y) * y;
        rDp = 2.32481837 + 4.35506248 * y;
    } else if (y < 12.0) {
        float t = y - 2.0;
        rN  = 1.00092936 + (2.534287 + (0.845025361 + 0.0144874444 * t) * t) * t;
        rNp = 2.534287 + (1.69005072 + 0.0434623323 * t) * t;
        rD  = 1.0 + (2.27606201 + 0.3466658 * t) * t;
        rDp = 2.27606201 + 0.6933316 * t;
    } else {
        float t = y - 12.0;
        rN  = 2.1451273 + (0.14577396 + 0.000542358321 * t) * t;
        rNp = 0.14577396 + 0.00108471664 * t;
        rD  = 1.0 + 0.0358357057 * t;
        rDp = 0.0358357057;
    }
    float q = d / f;
    float qp = ((rNp * rD - rN * rDp) / (rD * rD)) / VLX_LOD_H1;
    return (q - d * qp) / (q * q);
#else
    float q = d / f;
    float dl = q - VLX_LOD_QA;
    return (q - d / (VLX_LOD_H1 + 3.0 * VLX_LOD_E * dl * dl)) / (q * q);
#endif
#else
    return VLX_SHADOW_DISTORT;
#endif
}

vec3 distortShadow(vec3 pos, float factor) {
    return vec3(pos.xy / factor, pos.z * VLX_SHADOW_ZSCALE);
}
