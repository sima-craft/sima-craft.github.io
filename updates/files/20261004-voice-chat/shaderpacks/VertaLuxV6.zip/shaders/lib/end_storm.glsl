/*
    VertaLux - END STORM (END_STORM_ACTIVE, lib/settings.glsl): the
    volumetric storm of the End and its march. Clean-room design after the
    look of an "electric night storm" End; no code is shared with any other
    pack. Requires settings, common (vnoiseTex), distort (getDistortFactor /
    distortShadow / VLX_SHADOW_ZSCALE, for END_FOG_SHADOWS), dimension
    (palette, endLightningState), lighting (shadow samplers + matrices,
    toShadowClipWorld) and clouds.glsl (hgPhase, VC_MARCH_SAMPLES)
    included first. Included by prepare.fsh (half-res temporal bake),
    deferred.fsh (composite / inline fallback) and composite1.fsh (bounded
    march in front of distant terrain). Every caller passes cameraPosition
    and frameTimeCounter (the End world clock is frozen, so real time drives
    the vortex and the erosion drift).

    VOLUME (endStormDensity), world-anchored:
      - band, PLACEMENT PASS ("the space between the islands and the void
        below, never the platforms"; heights in world y):
            230 ---- top roll-off ends: open zenith
        150..230 --- crests taper out (thr +0.12 progressive)
        110..150 --- full towers (thr 0.58): the crowns above the islands
         85..110 --- notch feathers out
         55..85  --- PLAYABLE BAND, outer islands: thr 0.65 - the wispy
                     fill is gone, only tower CORES pierce (pinched waist).
                     MEASURED honestly: the clearing only bites above y~50
                     (-0% at 35, -26% at 45, -42% at 50, full -48% from 55
                     up - islands with surfaces at y 40-50 keep 74-91% of
                     the old storm), and at SCALE 12 a piercing core is a
                     384-block wall: a horizontal ray at y 70 drops from
                     mean alpha 0.59 to 0.47 (median 0.97 -> 0.00) - over
                     half the azimuths open fully, ~46% stay >= 80% walled.
                     "Half-cleared, rarer but 2.4x wider walls", not clear.
         35..55  --- notch feathers in; sea envelope starts at 30
          0..35  --- roots: thr slides 0.58 -> 0.50, the towers thicken
                     into their feet right under the islands
        -45..0   --- storm sea builds to full (thr 0.36)
       -120..-45 --- solid sea over the void (march floor -120);
      - vortex: the xz lattice is rotated about the world origin by t / 300 s
        (1 turn / 5 min) + y / 72 (helical twist), full inside 200 blocks of
        the origin, static past END_STORM_RANGE x 0.9 (648 blocks at the
        default range, 432 at the 480 minimum: the fade end follows the reach
        so every range setting keeps anchored spiral arms around the main
        island instead of a world that turns as a whole);
      - lattice stretched 32 x END_STORM_SCALE blocks in xz and 110 x
        END_STORM_SCALE in y (pseudo-3D noise from two blended vnoiseTex
        slices), two octaves -> twisted vertical towers covering ~2/3 of the
        horizon from an outer island. The density threshold is applied to the
        same noise distribution at every scale, so the coverage is scale-
        invariant within a few percent (numerical integration over the whole
        band: +4% at 1.6 and at 3.0, -1% at 0.75 - no drift with scale, no
        recalibration);
      - erosion: a finer noise (same ratio at every scale, it rides the
        scaled lattice) drifting with time TEARS the soft edges. ANISOTROPIC
        (6.5 / 3.0 / 2.4, against the isotropic 4.0 it used to be): the gaps
        are compressed across the vortex arms and stretched along them, so
        they read as filaments wrapped around the spiral instead of round
        blobs, and the bite is SQUARED in the noise so only genuinely low
        values eat material - peak 0.46 against the old flat 0.30, but the
        same mean (0.153 vs 0.150), i.e. the average coverage does not move.
        It inherits the 256-unit vnoiseTex lattice wrap, so the shortest world
        period is now the x one, 1260 x END_STORM_SCALE blocks: at
        END_STORM_SCALE 0.75 with END_STORM_RANGE 900 (945 vs 1800 blocks of
        visible diameter) the pattern repeats twice across the field - but at
        SCALE 1.5 it is 1890 blocks and at the 12.0 default 15120, far past
        any range: no repeat in view. The base octaves (8192 x and 3034 x
        SCALE) never repeat in view at any scale;
      - drift (END_STORM_DRIFT): the noise lattice TRANSLATES through the
        world, applied to the field coordinates BEFORE the vortex - 1.5
        blocks/s in xz plus a 0.15 block/s peak vertical heave at dial 1.0 -
        so the towers are built and unbuilt as the field passes instead of
        only revolving. The path is an EXACT 3600-s loop
        (endStormDriftOffset), so it crosses the frameTimeCounter wrap with
        no seam, on every octave, at every scale;
      - island exclusion (END_ISLAND_CLEAR), HARD and scale-independent: a
        final MULTIPLIER, exactly 0 within END_ISLAND_CLEAR blocks of the
        world origin over the island band (y -40..+120, feathered 40 blocks
        each way), smoothstepping back to 1 at twice that distance. Nothing
        can grow over the main island whatever END_STORM_SCALE, the density
        or the noise do - the hollows below shape the clear air, this is the
        law that guarantees it;
      - hollows: sphere (60-95, y x0.8) around (0, 100, 0) and a ring of
        radius 150 (tube 70-100) around it -> the main island sits in clear
        air up to ~235 blocks; quadratic clearing within END_STORM_CLEAR
        blocks of the camera (the storm is scenery, never in the face).
    MARCH (endStormMarch): END_STORM_STEPS steps (1.5x the CLOUD_QUALITY
    tier budget, x0.6 under the temporal bake like the cumulus, then indexed
    on span / feature size, clamped to 0.5x - 2.0x with an absolute floor of
    8, so neither dial can starve the sampling nor spend steps on features
    far larger than the step) from
    30 to min(END_STORM_RANGE, maxDist) blocks inside the band,
    front-weighted step distribution,
    blue-noise jitter and the 4-frame interleave of the temporal bake
    (frameOff).
    SCULPTING (why the towers used to read as flat white cotton, and what
    replaced it). The End light is frozen 55 deg up and the lattice is
    stretched 110 x END_STORM_SCALE blocks in y (1320 at the 12.0 default),
    so the two old self-shadow taps 18 / 50 x SCALE blocks STRAIGHT UP read
    almost the same noise cell as the shaded point - and the 250-block one
    left the band (top 230) for every sample above y = -20, i.e. the whole
    visible tower body, contributing exactly 0 with its 160-block weight.
    Over the lit mass the term only spanned lt = 0.85..1.00, a 1.17x range:
    a crest at y = 170 and the body at y = 60 came out 18 % apart in
    luminance and everything read as one pale slab. Per lit step now:
      - the mass ABOVE the sample in CLOSED FORM (no tap): the band envelope
        integrates to 175 - y up to y = 120 and to 0 by y = 175, taken at the
        local density inside one y cell and at the mean coverage past it;
      - 3 RAKED taps (shadeDir = the light steepened by +0.35 of horizontal
        along ITS OWN azimuth - the black hole's side, see the shadeDir
        comment) at 0.18 / 0.50 / 1.00 of a reach capped by the room left
        under y = 230, weighted 0.20 / 0.32 / 0.48 - raked because they must
        cross the 32 x SCALE block xz lattice to see any relief at all;
      - lt = exp(-tau) and a second, 4.5x thinner Beer octave lt2 that only
        tints (multi-scattering without the milky lift). END_STORM_CONTRAST
        scales tau: at 1.0, lt runs 0.001 (storm sea) -> 0.026 (tower base)
        -> 0.14 (mid) -> 0.94 (crest), a ~700x range, and those same two
        samples now sit 6x apart;
      - END_FOG_SHADOWS (1, lib/settings.glsl): everything above is SELF-
        shadowing in the density field, which the islands are not part of,
        so they could not cast into the storm. ONE raw shadowtex1 tap per
        dense step (same mechanics as the composite1 VL march: constant
        VLX_SHADOW_ZSCALE bias, fail-open outside the map XY and past the
        frustum Z) multiplies the DIRECTIONAL terms only - crest light and
        rim - so a step in the shade of an obsidian island keeps its violet
        ambient, its lightning and its black-hole rim but loses the frozen-
        noon sun. Beyond shadowDistance the tap fails open: the far arc is
        bit-identical, only the near field is carved;
      - colours: deep night-violet body graded over the whole band (near
        black in the sea), cold CYAN on the lit crests and MAGENTA on the
        thin torn edges (END_STORM_TINT), everything dimmed inside the core
        so a tower reads as a solid; the ambient share is ~40 % of the old
        one and is occluded by lt2;
      - the lightning as a point light 4x the old kernel (+163 % of the local
        tower luminance at 150 blocks against +30 %) plus, under
        END_LIGHTNING_BOLT, a jagged vertical channel drawn on storm material
        only, so the strike lights the pillars from within;
      - under END_BLACKHOLE_ACTIVE, a warm accretion-orange rim on the thin
        edges of the towers standing toward the hole (END_STORM_BH_TINT).
    Returns (color, alpha) like volumetricClouds; the far arc fades out
    toward END_STORM_RANGE (the composite1 haze veils it afterwards, so no
    fog is added here).

    KNOWN, ACCEPTED (same behaviour as the cumulus): composite1 includes this
    file WITHOUT CLOUD_TEMPORAL_MARCH, so its VC_MARCH_SAMPLES is VC_SAMPLES
    (not VC_SAMPLES_EFF) and its step budget is larger than the prepare bake's.
    The FIELD is identical (no shape seam), but the opacity integration differs
    slightly between a sky pixel (bake) and the adjacent terrain pixel
    (composite1) along island silhouettes. The absolute step-length gap grows
    with END_STORM_RANGE (~17 blocks at the default 720 range).
*/
#ifdef END_STORM_ACTIVE

// END_STORM_SCALE (feature size) and END_STORM_RANGE (march reach) are menu
// dials in lib/settings.glsl.
#define END_STORM_CLEAR 90.0
// Step budget: 1.5x the cumulus budget of the caller (VC_MARCH_SAMPLES =
// VC_SAMPLES, or VC_SAMPLES_EFF under the temporal bake): the storm spans
// up to ~690 blocks (default range) against a ~160-block cumulus slab
// section, and most steps cross clear air (2 noise taps, no lighting).
// END_STORM_RANGE and END_STORM_SCALE are INDEPENDENT dials, so that base
// budget is then indexed on the marched span PER FEATURE, relative to the
// original tuning (450-block span at END_STORM_SCALE 1.0): a long reach over
// small features crosses many more pillars per step and would alias/band,
// while a coarse scale crosses FEWER features per step and needs FEWER steps.
// The factor is clamped to [0.5, 2]. High bound 2: the worst menu combo
// (range 900 at scale 0.75, lowest tier) asks for 2.6x, which would mean 187
// steps on the ultra tier in composite1 - capping at 2x takes that combo from
// 0.40 to 0.80 samples per pillar, i.e. within ~20% of the 1.03 the coarsest
// fixed 480 / 1.0 state used to give, for double the cost instead of triple.
// Low bound 0.5 (was 1: the old 720 / 1.6 defaults landed at 0.96 and the
// floor pinned them to the base budget): from SCALE 5.0 up the clamp is the
// binding term (raw ratio 0.31 at 5.0, 0.128 at the 12.0 default - 690
// blocks of span against the 5400 that 450 x SCALE allows), so 5 / 10 / 12 /
// 16 all march the SAME step count and the bigger features only get better
// sampled: on the ultra composite1 tier 36 steps over 690 blocks = 19.2
// blocks of mean step, i.e. 20 taps across a 384-block base cell (12.0
// default) and 3.2 across its 59-block erosion cell, against 8.4 / 2.1 at
// SCALE 5 and 5.1 / 1.28 in the 450 / 1.0 reference. The floor also guards the near-field ramps that do NOT shrink
// with the feature size: the front-weighted distribution puts ~0.14 x
// END_STORM_STEPS inside the 90-block camera clearing (5 steps on that ultra
// tier, 3 on the one below) and ~0.19 x inside the 100 -> 200 block island
// ramp. The absolute max(8) floor only ever binds on the lowest quality tier,
// whose prepare budget already IS 8, so no tier is ever pushed ABOVE the step
// count it had before.
// Constant expression: GLSL 1.20 allows built-in calls on constant arguments
// inside a const initializer (4.3.3).
const int END_STORM_STEPS = int(max(8.0, ceil(float((VC_MARCH_SAMPLES * 3 + 1) / 2)
    * clamp((END_STORM_RANGE - 30.0) / (450.0 * END_STORM_SCALE), 0.5, 2.0))));

// Field drift (END_STORM_DRIFT): world-space translation of the noise lattice,
// evaluated ONCE per ray by the march and handed to every density tap.
// frameTimeCounter wraps at 3600 s, so a straight line can only avoid a seam
// if it covers a whole lattice period in that hour: 256 (vnoiseTex) x 32 x
// END_STORM_SCALE = 8192 x SCALE blocks, i.e. 2.28 x SCALE blocks/s = 27.4
// blocks/s at the 12.0 default, 18x the speed asked for - and even then only
// the BASE octave would match (the 2.7x octave and the 4x erosion would still
// jump). A closed path solves it exactly instead: the offset is a circle of
// radius 859.44 x END_STORM_DRIFT walked once per 3600 s, so the field is
// EXACTLY where it started when the clock wraps - no seam, every octave, every
// scale - at a constant 859.44 x 2 pi / 3600 = 1.5 blocks/s per dial unit. The
// direction veers by 360 deg/hour = 0.1 deg/s (6 deg per minute of play, a
// 29-block sagitta over 450 blocks of travel), so over any watchable stretch
// it reads as a fixed world direction. The vertical component shares the
// phase: +-85.944 x DRIFT blocks, peak speed 0.15 blocks/s, a slow heave that
// makes the towers grow and settle. At END_STORM_DRIFT 0 every component is
// exactly 0 and the field is bit-identical to the pre-drift one.
vec3 endStormDriftOffset(float t) {
    float ph = t * (6.2831853 / 3600.0);
    float s = sin(ph);
    return vec3(s * (859.44 * END_STORM_DRIFT),
                s * (85.944 * END_STORM_DRIFT),
                cos(ph) * (859.44 * END_STORM_DRIFT));
}

// Pseudo-3D value noise: two baked 2D slices (vnoiseTex lattice units)
// blended along y, each y cell shifting the slice by a fixed offset.
float endNoise3(vec3 p) {
    float yi = floor(p.y);
    float yf = p.y - yi;
    yf = yf * yf * (3.0 - 2.0 * yf);
    vec2 o = vec2(37.7, 17.3);
    return mix(vnoiseTex(p.xz + yi * o), vnoiseTex(p.xz + (yi + 1.0) * o), yf);
}

// Storm density at a world point. drift = the field translation of this frame
// (endStormDriftOffset, constant along a ray); camT = distance from the camera
// along the ray (camera clearing); fine = apply the erosion (skipped by the
// light taps).
float endStormDensity(vec3 wp, vec3 drift, float t, float camT, bool fine) {
    // Vertical band: nothing above ~230 (a solid sea below ~0, see thr)
    float band = 1.0 - smoothstep(150.0, 230.0, wp.y);
    if (band <= 0.0) return 0.0;
    // Hollows around the main island: sphere + ring, y flattened x0.8
    float r = length(wp.xz);
    float yc = (wp.y - 100.0) * 0.8;
    float hollow = smoothstep(60.0, 95.0, length(vec3(wp.x, yc, wp.z)))
                 * smoothstep(70.0, 100.0, length(vec2(r - 150.0, yc)));
    // HARD main-island exclusion (END_ISLAND_CLEAR), independent of the field
    // scale: a MULTIPLIER, exactly 0 inside the cylinder of radius
    // END_ISLAND_CLEAR around the world origin over the island band, back to 1
    // at twice that radius. The hollows above are a SHAPE calibrated for 32-51
    // block features; one 160-block tower (SCALE 5) or 256-block one (SCALE 8)
    // would swallow them, so the guarantee lives here instead. It is exact:
    // GLSL smoothstep(a, b, x) returns exactly 0.0 for x <= a, and
    // mix(u, v, 1.0) is exactly v, so isl is a hard 0.0 over the island and
    // the env early-out below returns before a single noise tap - whatever
    // END_STORM_SCALE, END_STORM_DENSITY, the drift or the noise value.
    // islB feathers the band edges over 40 blocks, so the storm sea below the
    // island and the open air above it still join the field smoothly.
    float islB = smoothstep(-80.0, -40.0, wp.y) * (1.0 - smoothstep(120.0, 160.0, wp.y));
    float isl = mix(1.0, smoothstep(END_ISLAND_CLEAR, 2.0 * END_ISLAND_CLEAR, r), islB);
    // Camera clearing (quadratic ramp)
    float cc = min(camT / END_STORM_CLEAR, 1.0);
    float env = band * hollow * isl * cc * cc;
    if (env <= 0.002) return 0.0;
    // Vortex: polar rotation + helical twist, faded out away from the origin.
    // The fade end follows END_STORM_RANGE (x0.9 -> 648 at the default range,
    // 432 at the 480 minimum): the static arms must start well inside the
    // reach, otherwise short ranges show the whole visible field turning.
    // Accepted artifact: when frameTimeCounter wraps (once per hour), the
    // spin-scaled angle in the fade ring and the erosion drift below jump
    // for 1 frame (3600 s = 12 full turns, so spin 0/1 zones are continuous;
    // the erosion offset covers 180 of its 256 lattice units in that hour);
    // the temporal resolve hides it within a few frames. END_STORM_DRIFT is
    // NOT part of this: its path closes exactly on the 3600 s period.
    float spin = 1.0 - smoothstep(200.0, END_STORM_RANGE * 0.9, r);
    float ang = (t * (6.2831853 / 300.0) + wp.y * (1.0 / 72.0)) * spin;
    float ca = cos(ang);
    float sa = sin(ang);
    // Drift applied to the FIELD coordinates, BEFORE the vortex: only the
    // lattice travels. Every world-anchored term (spin radius, twist height,
    // band, threshold, hollows, island clearing) already read the TRUE wp
    // above, so the spiral centre and the island stay nailed to (0, 0).
    vec2 pxz = wp.xz + drift.xz;
    vec2 xz = vec2(ca * pxz.x - sa * pxz.y, sa * pxz.x + ca * pxz.y);
    // Stretched lattice (32 x END_STORM_SCALE blocks in xz, 110 x
    // END_STORM_SCALE in y) -> vertical pillars, two octaves
    vec3 q = vec3(xz.x, (wp.y + drift.y) * (32.0 / 110.0), xz.y) * (1.0 / (32.0 * END_STORM_SCALE));
    float n = endNoise3(q) * 0.62 + endNoise3(q * 2.7 + vec3(11.0, 3.0, 7.0)) * 0.38;
    // Coverage threshold: clumpy towers around the islands (~15% of the
    // volume), tapering above 120 so the zenith stays mostly open, a
    // continuous sea below the islands. PLACEMENT PASS (creator: "pas si
    // bien place") - the storm dresses the space BETWEEN the islands and the
    // void BELOW them, never the platforms themselves:
    //  - SEA raised: the envelope starts dropping at y 30 (was 20) and is
    //    full by -45 (was -60), so the fill thickens right under the island
    //    band and the towers visibly ROOT into it;
    //  - PLAYABLE NOTCH: +0.07 of threshold across y 55..85 (feathered
    //    35..55 / 85..110), the band the outer islands occupy. That pushes
    //    the coverage ramp from n = 0.62..0.72 up to 0.69..0.79: the wispy
    //    fill (the ramp's lower half) disappears from the platforms while
    //    the tower CORES still cross, pinched at the waist - feet below the
    //    islands, crowns above, clear air to play in between. KNOWN LIMIT
    //    (measured on the real field): the smoothstep(35, 55) feather means
    //    the clearing only starts at y~50 (-0% at 35, -42% at 50, full -48%
    //    from 55), so islands whose surface sits at y 40-50 stay mostly
    //    stormed; widening to 20..40 (+0.09) is the dial if the whole band
    //    must clear.
    float thr = mix(0.58, 0.36, smoothstep(30.0, -45.0, wp.y))
              + 0.12 * smoothstep(120.0, 230.0, wp.y)
              + 0.07 * smoothstep(35.0, 55.0, wp.y) * (1.0 - smoothstep(85.0, 110.0, wp.y));
    // Coverage ramp, CENTRED on the old midpoint thr + 0.09 so END_STORM_EDGE
    // narrows the transition without moving the mean coverage; at EDGE 1.0 the
    // two bounds are exactly thr and thr + 0.18, i.e. the previous curve.
    float ew = 0.18 * END_STORM_EDGE;
    float e0 = thr + 0.09 - ew * 0.5;
    float d = smoothstep(e0, e0 + ew, n);
    if (fine) {
        // Drifting fine erosion, now ANISOTROPIC (6.5 / 3.0 / 2.4 against the
        // old isotropic 4.0): the torn gaps are compressed across the vortex
        // arms and stretched along them, so they read as filaments wrapped
        // around the spiral instead of round blobs. Still ONE tap. The x
        // period of that octave becomes 256 / 6.5 x 32 x SCALE = 1260 x SCALE
        // blocks (6300 at the 5.0 default, far past any range; the small-scale
        // + long-range caveat of END_STORM_SCALE is unchanged in kind).
        float ero = endNoise3(vec3(q.x * 6.5, q.y * 3.0, q.z * 2.4)
                            + vec3(t * 0.05, t * -0.03, t * 0.02));
        // SQUARED bite: the erosion only eats where the fine noise is genuinely
        // low, so instead of shaving every edge by a constant it TEARS
        // filaments out of them. Peak bite 0.46 against the old flat 0.30, but
        // the MEAN bite is 0.46/3 = 0.153 against 0.30/2 = 0.150 - the average
        // coverage is unchanged to ~2 %, only its edge statistics move.
        float ee = 1.0 - ero;
        d = max(d - 0.46 * ee * ee, 0.0);
    }
    return d * env * END_STORM_DENSITY;
}

// Storm march along a world ray. dither = blue-noise jitter, t = real time,
// maxDist = opaque bound (1.0e9 on the sky), frameOff = temporal phase 0..3
// (prepare bake only; 0 elsewhere).
vec4 endStormMarch(vec3 camPos, vec3 dir, vec3 lightDirW, float dither, float t, float maxDist, float frameOff) {
    // Band [-120, 230]: the sea keeps a floor well under the void limit
    float t0 = 30.0;
    float t1 = min(END_STORM_RANGE, maxDist);
    if (abs(dir.y) > 1e-3) {
        float ta = (-120.0 - camPos.y) / dir.y;
        float tb = (230.0 - camPos.y) / dir.y;
        float tOut = max(ta, tb);
        if (tOut <= 0.0) return vec4(0.0);
        t0 = max(t0, min(ta, tb));
        t1 = min(t1, tOut);
    } else if (camPos.y < -120.0 || camPos.y > 230.0) {
        return vec4(0.0);
    }
    if (t1 <= t0 + 1.0) return vec4(0.0);

    float jitter = dither;
#if CLOUD_TEMPORAL == 1 && defined CLOUD_TEMPORAL_MARCH
    // 4-frame interleave of the temporal bake (same contract as the cumulus:
    // phase k starts in quarter k of the first step, prepare1 resolves)
    jitter = (frameOff + jitter) * 0.25;
#endif
    float span = t1 - t0;
    float invN = 1.0 / float(END_STORM_STEPS);
    float cosT = dot(dir, lightDirW);
    // Mild forward lobe + isotropic floor (the light comes from above)
    float phase = hgPhase(cosT, 0.45) * 0.6 + 0.032;
    // Backward lobe: a crest the ray only grazes keeps a cold halo
    float phaseB = hgPhase(cosT, -0.22) * 0.22;
    vec3 lightCol = dimEndLight() * 9.0;
    // RAKED shadow ray, now ALONG THE LIGHT'S OWN AZIMUTH. The End light is
    // frozen 55 deg up (fixed_time 6000 + sunPathRotation -35) - the axis
    // the black hole is anchored on (lib/blackhole.glsl endBlackHoleDir) and
    // the axis the END_FOG_SHADOWS island tap below reads - while the
    // lattice is 110 x END_STORM_SCALE blocks tall (1320 at the 12.0
    // default): a near-vertical march reads the same y cell forever, so the
    // rake still steepens the ray SIDEWAYS, but along normalize(lightDirW.xz)
    // instead of the old fixed (0.615, -0.788) azimuth. ONE light, ONE side:
    // the self-shadow, the island shadows and the disk-side rim all rake the
    // storm from the black hole's side now (the AXIS MISMATCH the island-tap
    // comment used to carry is resolved by construction). +0.35 of
    // horizontal on top of the light's own 0.574 makes the far tap cross
    // ~0.5 of a 384-block xz cell at the defaults - the same relief-carving
    // travel as the old 0.55 tilt at scale 5. The azimuth fallback only
    // fires if the light stands at the exact zenith (sunPathRotation 0).
    vec2 azL = (dot(lightDirW.xz, lightDirW.xz) > 1e-6)
             ? normalize(lightDirW.xz) : vec2(0.615, -0.788);
    vec3 shadeDir = normalize(lightDirW + vec3(azL.x, 0.0, azL.y) * 0.35);
    // Vertical share of that ray: used to keep every tap under the band top.
    // The End light always points up (fixed noon), the max() only guards a
    // degenerate uniform.
    float invShadeY = 1.0 / max(shadeDir.y, 0.30);
    float sMax = (1.70 * 32.0) * END_STORM_SCALE;
    // Coherence height of the field: past one y cell the column above a point
    // decorrelates from its local density and falls back to the mean coverage.
    float yCell = 110.0 * END_STORM_SCALE;
    float sigL = 0.018 * END_STORM_CONTRAST;
    // Cold cyan on the lit crests, magenta on the torn edges (END_STORM_TINT).
    vec3 crestT = mix(vec3(1.0), vec3(0.52, 0.98, 1.24), END_STORM_TINT);
    vec3 rimT = mix(vec3(1.0), vec3(1.15, 0.42, 1.30), END_STORM_TINT * 0.85);
    // Field drift: one evaluation per ray (it depends only on t), shared by
    // the density tap and every light tap so the lattice never tears.
    vec3 drift = endStormDriftOffset(t);
    // Lightning: one state evaluation per ray
    vec3 bP;
    vec3 bC;
    float fl = endLightningState(t, camPos, bP, bC);
#ifdef END_BLACKHOLE_ACTIVE
    // Disk-side warm rim (END_STORM_BH_TINT): ONE clamped forward lobe toward
    // the hole per ray (lib/blackhole.glsl endBlackHoleDir, included before
    // this file by every caller). Clamped at 0.55 so looking straight at the
    // disk adds a rim and never a second sun. Declared and read INSIDE this
    // same guard only.
    float bhP = min(hgPhase(dot(dir, endBlackHoleDir()), 0.72), 0.55) * END_STORM_BH_TINT;
#endif

    vec3 acc = vec3(0.0);
    float trans = 1.0;
    float tw = 0.0; // scattering-weighted depth (far fade)
    float ww = 0.0;
    for (int i = 0; i < END_STORM_STEPS; i++) {
        float u = (float(i) + jitter) * invN;
        // Front-weighted distribution: dt grows from 0.55x to 1.45x the mean
        float tt = t0 + span * u * (0.55 + 0.45 * u);
        float dt = span * invN * (0.55 + 0.90 * u);
        vec3 wp = camPos + dir * tt;
        float d = endStormDensity(wp, drift, t, tt, true);
        if (d > 0.003) {
            // How deep inside a tower this sample sits: 0 on a torn edge, 1 in
            // the heart. END_STORM_DENSITY is divided back out, so that dial
            // moves the MASS and never the sculpting.
            float core = clamp(d * (1.0 / END_STORM_DENSITY), 0.0, 1.0);
            // MASS ABOVE THE SAMPLE, in closed form and WITHOUT A TAP.
            // Integrating the band envelope (flat up to y = 120, rolling off to
            // 230) from the sample to the top gives exactly 175 - y below
            // y = 120 and reaches 0 by y = 175. Inside one y cell the column IS
            // the local density (the lattice is vertically coherent over
            // 110 x SCALE blocks); past it the field decorrelates and the mean
            // coverage (~0.15) takes over, which keeps small feature sizes from
            // over-darkening. This one term is what makes the towers dark at
            // the base and luminous on the crests: lt runs 0.001 (storm sea) ->
            // 0.026 (base) -> 0.14 (mid) -> 0.94 (crest). The two old vertical
            // taps spanned 0.85..1.00 and could not.
            float hAb = max(175.0 - wp.y, 0.0);
            float colUp = d * min(hAb, yCell)
                        + (0.15 * END_STORM_DENSITY) * max(hAb - yCell, 0.0);
            // 3 RAKED taps at growing distance with growing weights (0.20 /
            // 0.32 / 0.48 of the marched length, no erosion): the local relief
            // laid over the analytic column. The reach is capped by the room
            // left under the band top, so no tap ever falls into the dead air
            // above y = 230 the way the old fixed 50 x SCALE one did for every
            // sample above y = -20.
            float sLen = min(sMax, max(230.0 - wp.y, 30.0) * invShadeY);
            float odT = sLen
                * (0.20 * endStormDensity(wp + shadeDir * (sLen * 0.18), drift, t, tt, false)
                 + 0.32 * endStormDensity(wp + shadeDir * (sLen * 0.50), drift, t, tt, false)
                 + 0.48 * endStormDensity(wp + shadeDir * sLen, drift, t, tt, false));
            float tau = (colUp + odT) * sigL;
            // TWO OCTAVES OF BEER (multi-scattering approximation): the first
            // carries the crisp direct light, the second is 4.5x thinner and
            // only ever TINTS, so the deep mass keeps a coloured glow instead
            // of the milky grey lift a plain ambient floor would give.
            float lt = exp(-tau);
            float lt2 = exp(-tau * 0.22);
            float powder = 1.0 - exp(-d * 4.0);
            // ---- END_FOG_SHADOWS: island shadows carved INTO the storm ----
            // tau above is SELF-shadowing (storm material only): the obsidian
            // islands are not in that field, so they never cast into the
            // storm - while the same frozen-noon shadow map already carves
            // the violet VL haze between pillars (composite1 "vis" trunk).
            // ONE raw shadowtex1 tap per DENSE step, VL-march mechanics:
            // constant VLX_SHADOW_ZSCALE bias, opaque-only depth, fail-open
            // outside the map XY and past the frustum Z (the storm beyond
            // shadowDistance is bit-identical). dir * tt IS the camera-
            // relative step position (every call site passes cameraPosition
            // as camPos), so no world-coordinate digit cancellation.
            // Weights the DIRECTIONAL terms only (crest light + rim below):
            // a shaded step keeps its violet ambient, its second Beer
            // octave, its lightning and its black-hole rim - it only loses
            // the sun. At END_FOG_SHADOWS 0, svE is the constant 1.0 and
            // every product folds away at compile time.
            // AXIS MATCH (was "AXIS MISMATCH, ASSUMED"): the storm's SELF-
            // shadow now rakes along the LIGHT'S OWN azimuth (shadeDir
            // above), the same axis this tap reads through toShadowClipWorld
            // and the same axis the black hole is anchored on
            // (lib/blackhole.glsl) - the disagreement this note used to
            // accept is gone by construction; only the rake's extra 0.35 of
            // horizontal tilt separates the two, on one SHARED azimuth.
            float svE = 1.0;
#if END_FOG_SHADOWS == 1
            {
                vec3 scE = toShadowClipWorld(dir * tt);
                float fE = getDistortFactor(scE.xy);
                vec3 spE = distortShadow(scE, fE) * 0.5 + 0.5;
                if (spE.x > 0.0 && spE.x < 1.0 && spE.y > 0.0 && spE.y < 1.0) {
                    float zbE = spE.z - 0.0008 * (VLX_SHADOW_ZSCALE * 2.0); // constant world-space bias (VL march)
                    svE = step(zbE, texture2D(shadowtex1, spE.xy).r);
                    svE = max(svE, step(1.0, zbE)); // beyond the frustum Z range: fail-open
                    // Edge ramp toward the fail-open, over the last 0.02 of
                    // the DISTORTED map -- same convention as the VL march
                    // (composite1 shOK, UW_SHAFT_FIX3 (C)) and lighting.glsl's
                    // sfade. Without it svE snaps to 1.0 on a HARD circle at
                    // shadowDistance (192 blocks at the shipped SHADOW_QUALITY
                    // 1) that swims with the camera, and svE gates the direct
                    // term that DOMINATES the crests.
                    float edgeE = smoothstep(0.5, 0.48, max(abs(spE.x - 0.5), abs(spE.y - 0.5)));
                    svE = mix(1.0, svE, edgeE);
                }
            }
#endif
            float h = clamp((wp.y + 120.0) * (1.0 / 350.0), 0.0, 1.0);
            // Body: near-black indigo in the storm sea -> deep night violet up
            // top. "MOINS FONCES" PASS: both ends x1.35 (the sea end stays
            // near-black, ~0.002 HDR; a mid-tower ISLAND-SHADOWED step rises
            // 0.016 -> 0.022 HDR, +42%) - the direct term still leads below.
            vec3 body = mix(vec3(0.0061, 0.0047, 0.0203), vec3(0.0250, 0.0263, 0.0702), h);
            // Direct light: self-shadowed, island-shadowed (svE), and dimmed
            // inside the heart so the volume reads as a solid, not a lamp.
            // x1.30 DIRECT - the term the island shadow cuts (mix(1.30, 0.39,
            // .) IS the old mix(1.0, 0.30, .) x 1.30): with END_STORM_CONTRAST
            // now defaulting to 0.75 (mid-tower lt 0.14 -> 0.23) a LIT step
            // gains +79..85% and a shadowed one +46..53% (both measured on
            // the full march). HONEST FRAME for the shadow-contrast target:
            // the INTEGRATED lit/island-shadowed pixel ratio was already
            // ~2.9-3.1x with the old constants and lands at ~3.1-3.4x
            // (+5-9%); the "2.3x -> 3.0x" reading is a single-step figure at
            // core ~0.6, not the rendered pixel. This pass's real gain is
            // brightness on both sides of the shadow, and the look-at-hole /
            // look-away asymmetry (~3.8x), not a jump in shadow legibility.
            vec3 S = lightCol * crestT
                   * (svE * lt * phase * (0.26 + 0.74 * powder) * mix(1.30, 0.39, core));
            // Second Beer octave, deep blue-violet (x1.25, same hue: the
            // coloured glow the shadowed mass keeps under the ambient raise)
            S += vec3(0.078, 0.119, 0.263) * (lt2 * (0.25 + 0.75 * core) * (phase * 3.2 + 0.05));
            // Ambient, strongly occluded by the surrounding mass
            S += body * (mix(1.0, 0.26, core) * (0.22 + 0.78 * lt2));
            // RIM: thin torn material catching the light reads magenta-cold,
            // and the backward lobe lights the crests the view only grazes.
            // Sun-lit term -> follows the island shadow (svE) like the crest
            // (1.75 = the old 1.35 x the same 1.30 direct raise).
            float rim = (1.0 - core) * (1.0 - core);
            S += rimT * (rim * lt * (phase + phaseB) * (1.75 * svE));
#ifdef END_BLACKHOLE_ACTIVE
            // Disk-side warm rim: the accretion orange on the thin edges only
            S += vec3(1.00, 0.46, 0.14) * (bhP * lt * (0.30 + 0.70 * (1.0 - core)));
#endif
            if (fl > 0.001) {
                // Point light INSIDE the storm (soft inverse square). 4x the
                // old kernel with a tighter core: +163 % of the local tower
                // luminance for a bolt 150 blocks away, against the old +30 %
                // peak / ~+10 % mean that the creator could not see.
                vec3 tb = bP - wp;
                S += bC * ((fl * (4.0e4 * END_LIGHTNING_POWER)) / (dot(tb, tb) + 1800.0))
                        * (0.45 + 0.55 * powder);
#if END_LIGHTNING_BOLT == 1
                // BOLT CHANNEL: a wobbling vertical filament through the
                // strike (two sine pairs, ~35 blocks of jag), a hot core about
                // 85 blocks wide plus a ~250-block halo, faded over +-150
                // blocks of the strike altitude. Drawn on STORM MATERIAL ONLY
                // (we are inside the d > 0.003 branch), so it never paints a
                // line across clear air - it lights the tower from within.
                vec2 wob = vec2(sin(wp.y * 0.043 + bP.z * 0.17), cos(wp.y * 0.031 + bP.x * 0.13)) * 26.0
                         + vec2(sin(wp.y * 0.121 + 1.7), cos(wp.y * 0.097)) * 9.0;
                vec2 dxz = wp.xz - (bP.xz + wob);
                float r2b = dot(dxz, dxz);
                float dyb = (wp.y - bP.y) * (1.0 / 150.0);
                float glow = exp2(-r2b * (1.0 / 1800.0)) * 6.0 + exp2(-r2b * (1.0 / 20000.0));
                S += bC * (fl * glow * exp2(-dyb * dyb * 2.0) * (2.0 * END_LIGHTNING_POWER));
#endif
            }
            float a = exp(-d * 0.08 * dt);
            float w = trans * (1.0 - a);
            acc += S * w;
            tw += tt * w;
            ww += w;
            trans *= a;
            if (trans < 0.01) break;
        }
    }
    float alpha = 1.0 - trans;
    if (alpha < 1e-4) return vec4(0.0);
    vec3 col = acc / alpha;
    // Far arc: fades out toward the range limit (the haze veils the rest)
    float tAvg = tw / max(ww, 1e-6);
    alpha *= 1.0 - smoothstep(END_STORM_RANGE * 0.72, END_STORM_RANGE * 0.98, tAvg);
    return vec4(col, alpha);
}

#endif // END_STORM_ACTIVE
