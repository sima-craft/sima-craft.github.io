// ============ WATER_SKY_TINT - the ONE tint of the sky seen IN THE WATER ============
// SHARED HEADER. This function used to live inside composite1.fsh; it moved
// here so the Distant Horizons ocean can call it too (dh_water.fsh builds its
// own sky reflection out of getAmbientColor/getLightColor, so it is INVISIBLE
// to a grep for getSky* and was skipped once already -- exactly the
// forgotten-site defect class this pack has now paid for five times). It
// depends only on luma() (lib/common.glsl) and the WST_* constants
// (lib/settings.glsl), so it must be included AFTER those two, and it compiles
// unchanged under both the 430 profile of composite1 and the 330 of dh_water.
// EAU6. That audit (documented in lib/settings.glsl) proved that past ~8 blocks
// the water pixel IS the reflected sky (70.1% at 10 blocks, 96.3% at 20, 98.7%
// at 60), that the mirror is not more SATURATED than the column but PALER, and
// that it pins the delivered hue at 204-205 deg whatever the medium does. It
// also proved that desaturating harder is NOT the lever (REFLECT_DESAT 0.40 ->
// 0.52 moves the delivered hue by 0.7 deg at 20 blocks). The lever left is the
// sky's own HUE, and this function is it: the creator keeps the strong mirror
// (WATER_REFLECTIVITY 1.5, the x1.5 Fresnel overdrive he asked for) and pays
// for it here instead. An assumed ARTISTIC choice, not physics.
// THE REAL SKY IS NOT TOUCHED: this function is called from WATER sites only
// (see the five-site list in lib/settings.glsl -- four in composite1 plus the
// DH ocean's reflDH). The dome, the pane's own mirror, PBR metals, wet ground
// and every fog read the untouched getSkyBase / getSkyAll.
// MECHANIC: the same chroma projection as WATER_TINT, run a third way. The work
// vector is the ZERO-LUMA chroma c = sky - luma(sky); its DIRECTION is pulled
// toward a fixed target direction and its length reset to |c| * WST_SAT. A mix
// of two zero-luma vectors is zero-luma and normalize() keeps it so, hence
// luma(result) == luma(sky) BY CONSTRUCTION (measured: 1.1e-7% relative worst
// case over 5 distances x 4 paliers, i.e. the model's own double-precision
// round-off). That is not a cosmetic property: reflSkyL is luma(reflSky), so an
// exactly luminance-preserving tint leaves the three dark-hit fades, 'hit',
// reflW and therefore wMirror untouched -- and with wMirror, the ATMO_FOG
// relief, the submerged VL step density, the HEIGHT_FOG tail and the VL-apply
// fogKeepW. This palier moves CHROMA and nothing else.
// Pulling the DIRECTION rather than rotating by a
// fixed angle makes the transform OVERSHOOT-FREE: a sky already at the target
// stops there, so a twilight blue that starts further round cannot run off into
// magenta.
// TWO GATES, and they are why the sun survives:
//  (a) AZURE GATE: weighted by how close the input chroma direction is to the
//      pack's own day-sky chroma (WST_AZURE). Day sky 0.9957..0.9995 -> full;
//      the SUNSET BAND SEEN TOWARD THE SUN -0.911..-0.967 -> exactly zero. The
//      gold path on the water is untouched at all four paliers (measured: 0.0
//      deg of hue and 0.00% of luminance at 5/10/20/60 blocks).
//  (b) HIGHLIGHT SPARE: fades out above WST_HI0 of HDR luminance. Diffuse sky
//      tops out near 0.95-1.2; the solar disc sits at ~24. MEASURED SOLAR PEAK,
//      noon, palier 3 (the strongest): in (25.6096, 24.1062, 21.6776), out
//      (25.6096, 24.1062, 21.6776) -- BIT-IDENTICAL.
//      The two gates cross at the disc's rim, which is exactly where a ring
//      would show. CORRECTED CLAIM (an earlier note here credited the wrong
//      mechanism and measured the wrong variable): |c| does NOT pass through
//      zero at the rim. Re-measured, its minimum is 0.0476 -- 7.6% of the
//      0.6279 of the bare zenith sky -- reached at disc value t = 0.188, where
//      Y = 5.09 and the HIGHLIGHT SPARE has therefore ALREADY forced w = 0. The
//      rim is protected by gate (b) alone; the |c| -> 0 story plays no part.
//      The old "60 steps, monotone, slope 3.33" profile swept the DISC VALUE,
//      not the SCREEN POSITION, so it could not answer the ring question at all
//      (t itself collapses from 1 to 0 across ~10% of the disc radius).
//      SWEPT IN ANGLE INSTEAD, at the default SUN_SIZE 0.04: |out - in| runs
//      0 -> 0.354 (linear HDR) over 0.0327 deg, i.e. 0.49 px at a 70 deg field
//      in 1080p -- under one pixel, harmless.
//      ASSUMED LIMIT, WRITTEN DOWN: SUN_SIZE is a menu slider up to 1.0
//      (lib/settings.glsl). The same ramp spans 1.26 px at SUN_SIZE 0.1,
//      2.55 px at 0.2 and 5.64 px at 0.5, so a thin chromatic fringe around the
//      REFLECTED sun becomes visible from ~0.1 up. Accepted rather than fixed:
//      widening WST_HI0..WST_HI1 to spread the ramp would move every shipped
//      number in the shipped tables (lib/settings.glsl); the default is 0.04.
// The surface's own GGX GLINT is not a sky term (it is built on gLightC) and is
// neither read nor written here.
// PALIER 0 IS A NO-OP BY CONSTRUCTION: the function returns its argument before
// touching anything, and the two reference directions are FUNCTION-LOCAL consts
// so palier 0 emits no symbol for this feature at all. VERIFIED IN SPIR-V, and
// the exact claim is worth stating precisely because the harness overstates it
// either way. glslc without -O does not inline, so the RAW module still carries
// an identity OpFunction and three OpFunctionCall -- 327300 bytes against the
// reference build's 326940, a debug-build artefact, not a behaviour. Run both
// through spirv-opt -O --strip-debug (what a real driver does) and the two
// modules match instruction for instruction: 49832 instructions compared, 0
// differences after ID renumbering, and all 69 opcode counts equal. Palier 0
// is the shipped water, not an approximation of it.
// The two reference directions are FUNCTION-LOCAL consts, not file-scope ones,
// so palier 0 emits no symbol at all for this feature -- that is what makes the
// SPIR-V byte-identical rather than merely equivalent.
vec3 waterSkyTint(vec3 sky) {
#if WATER_SKY_TINT == 0
    return sky;
#else
    const vec3 WST_AXIS_AZURE  = vec3(WST_AZURE_R, WST_AZURE_G, WST_AZURE_B);
    const vec3 WST_AXIS_TARGET = vec3(WST_TARGET_R, WST_TARGET_G, WST_TARGET_B);
    float Y = luma(sky);
    vec3  c = sky - vec3(Y);                  // zero-luma chroma (Rec.709)
    float cl = length(c);
    if (cl < 1e-5) return sky;                // achromatic (cloud, moonlit grey): nothing to pivot
    vec3  u = c * (1.0 / cl);
    float w = smoothstep(WST_GATE0, WST_GATE1, dot(u, WST_AXIS_AZURE))
            * (1.0 - smoothstep(WST_HI0, WST_HI1, Y));
#if WATER_FOG_HUE == 1
    // WATER_FOG_HUE (A) -- THE MISSING HALF OF THE LUMINANCE GATE. The line
    // above stands the tint down for a sky that is too BRIGHT (WST_HI0 1.5:
    // the reflected solar disc, Y ~ 30). Nothing stood it down for a sky that
    // is too DIM, and measured over a full sun-height sweep the total gate is
    // EXACTLY 1.0000 at midnight as at noon. That matters because
    // WST_AXIS_TARGET is red-POSITIVE and green-NEGATIVE: on a twilight sky
    // (Y 0.021..0.047) it lifts red +30% and cuts green -5%, which spends 96%
    // of the green margin that keeps the pixel out of the magenta wedge -- and
    // the warm VL / ATMO_FOG veils applied after the water branch then tip it
    // over. Full derivation, the share table and the before/after in the
    // WATER_FOG_HUE block of lib/settings.glsl.
    // Y is the luminance of THIS ray's sky, so the bright sunset band keeps its
    // treatment while the dim anti-sun sky loses it, in the same frame.
    // 1.000 for every sun height >= 0.08 (an exact no-op, verified at 1.7e-16
    // relative), 0.000 from -0.02 down.
    w *= smoothstep(WFH_LO0, WFH_LO1, Y);
#endif
    if (w <= 0.0) return sky;                 // sunset band, solar disc: untouched
    vec3  d = mix(u, WST_AXIS_TARGET, WST_PULL);
    d *= 1.0 / max(length(d), 1e-6);
    vec3  r = mix(c, d * (cl * WST_SAT), w);
    // Gamut guard: shrink the chroma until no OUTPUT channel is negative. The
    // test is on the reconstructed pixel (Y + r), not on the chroma alone --
    // every chromatic colour has a negative chroma component by definition, so
    // testing r < 0 would take the branch on ~98% of pixels to then multiply by
    // exactly 1.0. Measured on the real predicate: it fires on 0 of 218700
    // samples (81 sun heights x 36 azimuths x 25 elevations x 3 paliers) and no
    // sample leaves with a negative channel -- a pure safety net, which is what
    // it should be. A scalar on a zero-luma vector, so the luminance survives it
    // untouched.
    float mn = Y + min(min(r.r, r.g), r.b);
    if (mn < 0.0) r *= Y / (Y - mn);
    return vec3(Y) + r;
#endif
}
