/* VertaLux - shared utility functions (included first by every program) */

// ============ TAAU - render scale (TAA upscaling) ============
// TAAU_S = linear fraction of the framebuffer covered by the 3D render, in the
// BOTTOM-LEFT corner. gbuffers/dh map gl_Position into that sub-rect, pre-TAA
// passes work in UV [0..TAAU_S], composite4 rebuilds full resolution, post-TAA
// passes sample scene buffers at uv * TAAU_S.
// Gated on TAA: without TAA composite4 is a passthrough and the scene would
// stay a postage stamp in the corner. At 1.0 every "x * TAAU_S" / "x / TAAU_S"
// folds at compile time, so the path is free when disabled.
// settings.glsl is always included BEFORE common.glsl; an undefined
// TAA_UPSCALING evaluates to 0 in the preprocessor -> TAAU_S = 1.0.
#if defined TAA && TAA_UPSCALING == 1
    #define TAAU_S TAAU_RENDER_SCALE
#else
    #define TAAU_S 1.0
#endif

float luma(vec3 c) {
    return dot(c, vec3(0.2126, 0.7152, 0.0722));
}

// Sub-pixel TAA jitter. Halton(2,3), period 16, indexed by frameCounter.
// Returns NDC offset (+/-0.5 screen pixel): the vsh multiplies by w*(2/res),
// composite4 converts back to UV to de-jitter the reprojection.
vec2 taaJitterNDC(int frame) {
    // Halton(2,3) mod 16 precomputed: this runs per vertex, so the table
    // replaces a per-vertex loop that only ever produced 16 constants.
    int m = frame - (frame / 16) * 16;
    vec2 h;
    if      (m == 0)  h = vec2(0.5,     0.33333334);
    else if (m == 1)  h = vec2(0.25,    0.66666669);
    else if (m == 2)  h = vec2(0.75,    0.11111111);
    else if (m == 3)  h = vec2(0.125,   0.44444445);
    else if (m == 4)  h = vec2(0.625,   0.77777779);
    else if (m == 5)  h = vec2(0.375,   0.22222222);
    else if (m == 6)  h = vec2(0.875,   0.55555556);
    else if (m == 7)  h = vec2(0.0625,  0.88888890);
    else if (m == 8)  h = vec2(0.5625,  0.03703704);
    else if (m == 9)  h = vec2(0.3125,  0.37037037);
    else if (m == 10) h = vec2(0.8125,  0.70370370);
    else if (m == 11) h = vec2(0.1875,  0.14814815);
    else if (m == 12) h = vec2(0.6875,  0.48148148);
    else if (m == 13) h = vec2(0.4375,  0.81481481);
    else if (m == 14) h = vec2(0.9375,  0.25925926);
    else              h = vec2(0.03125, 0.59259259);
    return h - 0.5;
}

vec3 toLinear(vec3 c) {
    return pow(max(c, 0.0), vec3(2.2)); // max: pow() of a negative component returns NaN
}

vec3 toSrgb(vec3 c) {
    return pow(c, vec3(1.0 / 2.2));
}

// Ordered dithering (Bayer matrix) to break up banding
float bayer2(vec2 a) {
    a = floor(a);
    return fract(a.x * 0.5 + a.y * a.y * 0.75);
}
#define bayer4(a)  (bayer2(0.5 * (a)) * 0.25 + bayer2(a))
#define bayer8(a)  (bayer4(0.5 * (a)) * 0.25 + bayer2(a))

float hash12(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

float hash13(vec3 p) {
    p = fract(p * 0.1031);
    p += dot(p, p.zyx + 31.32);
    return fract((p.x + p.y) * p.z);
}

float vnoise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float a = hash12(i);
    float b = hash12(i + vec2(1.0, 0.0));
    float c = hash12(i + vec2(0.0, 1.0));
    float d = hash12(i + vec2(1.0, 1.0));
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

// Value noise WITH its analytic gradient: returns vec3(value, d/dx, d/dy).
// SAME lattice and SAME smoothstep as vnoise above, so vnoiseD(p).x ==
// vnoise(p) exactly - it is the derivative that is added, not another field.
// Reading a gradient this way costs ~4 extra mul/add over vnoise, where a
// finite difference would cost 2 more full evaluations (8 more hash12).
// Used by the CAUSTICS_V4 photon estimator (lib/water.glsl), which needs the
// wave SLOPE three times per pixel and never needs the height itself.
vec3 vnoiseD(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    vec2 u = f * f * (3.0 - 2.0 * f);
    vec2 du = 6.0 * f * (1.0 - f); // d(smoothstep)/df
    float a = hash12(i);
    float b = hash12(i + vec2(1.0, 0.0));
    float c = hash12(i + vec2(0.0, 1.0));
    float d = hash12(i + vec2(1.0, 1.0));
    // Bilinear form: a + (b-a)u.x + (c-a)u.y + (a-b-c+d)u.x*u.y
    float k1 = b - a;
    float k2 = c - a;
    float k3 = a - b - c + d;
    return vec3(a + k1 * u.x + k2 * u.y + k3 * u.x * u.y,
                du.x * (k1 + k3 * u.y),
                du.y * (k2 + k3 * u.x));
}

// 3D value noise (volumetric clouds)
float vnoise3(vec3 p) {
    vec3 i = floor(p);
    vec3 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float n000 = hash13(i);
    float n100 = hash13(i + vec3(1.0, 0.0, 0.0));
    float n010 = hash13(i + vec3(0.0, 1.0, 0.0));
    float n110 = hash13(i + vec3(1.0, 1.0, 0.0));
    float n001 = hash13(i + vec3(0.0, 0.0, 1.0));
    float n101 = hash13(i + vec3(1.0, 0.0, 1.0));
    float n011 = hash13(i + vec3(0.0, 1.0, 1.0));
    float n111 = hash13(i + vec3(1.0, 1.0, 1.0));
    return mix(mix(mix(n000, n100, f.x), mix(n010, n110, f.x), f.y),
               mix(mix(n001, n101, f.x), mix(n011, n111, f.x), f.y), f.z);
}

// ============ DAWN MIST field (DAWN_MIST_VOL) ============
// SHARED by the composite1.fsh inline VL march and its lib/vl_halfres.glsl
// mirror: a duplicated field would drift between the full-res and half-res
// paths and the two would stop matching. Fully parameterised - no uniform is
// read here, so the file stays include-order independent.
#ifdef DAWN_MIST_VOL_ACTIVE
// Hour / humidity weight, IDENTICAL to the analytic layer of composite1:
// dense 4h30-7h (build-up from 3h30), dissipating until 9h30, faint at dusk
// (18h-19h30, x0.35), zero by day, plus the damp haze lingering once the rain
// stops (wetness lags rainStrength). tf = float(worldTime).
float dawnMistHourW(float tf, float wet, float rain) {
    float w = max(smoothstep(21500.0, 22500.0, tf), 1.0 - smoothstep(1000.0, 3500.0, tf));
    w = max(w, 0.35 * smoothstep(11500.0, 12200.0, tf) * (1.0 - smoothstep(13500.0, 14300.0, tf)));
    return clamp(w + wet * (1.0 - rain) * 0.6, 0.0, 1.0);
}
// Per-march-step mist density at world point wp. The height term is EXACTLY
// the point-wise density the analytic layer integrates in closed form:
//   d0 * min(exp(-(y - anchorY) * k), 6)
// (d0 at the anchor, / e every 1/k blocks up, capped at 6x below it), so the
// analytic tail beyond the march and this march term describe the same medium.
// On top of it, a WORLD-anchored animated 3D noise field turns the sheet into
// banks: 2 octaves, ~42 blocks horizontal / ~11 blocks vertical lattice (the
// second octave at 2.37x -> ~18 / ~4.6 blocks), drifting ~0.8 block/s. Both
// call sites pass the WORLD clock (cloudWorldTime) in t, NOT frameTimeCounter:
// the mist is gated by the world hour (dawnMistHourW reads worldTime), so
// /time set, sleeping and a changed tick speed must move the banks WITH the
// world - the same convention the clouds follow. cloudWorldTime() advances
// 1.0/s in normal play, so these drift constants need no rescaling, and the
// 3600 s frameTimeCounter wrap can no longer jump the field.
// The remap keeps the field's MEAN at exactly 1.0 (vnoise3 has mean 0.5), which
// is what makes the analytic tail the correct average of this term -> no
// density step at the march limit, for ANY patchy. patchy = 0 costs zero noise
// taps and returns the smooth analytic profile.
float dawnMistDens(vec3 wp, float d0, float anchorY, float k, float t, float patchy) {
    float h = d0 * min(exp(-(wp.y - anchorY) * k), 6.0);
    // Skip the taps where there is nothing to modulate: patchy = 0 (compile
    // time), or a step so far above the layer that 160 blocks of it would add
    // less than 1.6e-4 of optical depth. Returning the bare h there is also
    // the exact MEAN of the field, so the tail stays joined.
    if (patchy < 0.001 || h < 1e-6) return h;
    vec3 q = wp * vec3(0.0238, 0.0909, 0.0238) + vec3(t * 0.018, 0.0, t * -0.013);
    float n = vnoise3(q) * 0.65
            + vnoise3(q * 2.37 + vec3(11.3, 5.1, 7.9)) * 0.35;
    return h * (1.0 - patchy + 2.0 * patchy * n);
}
#endif

float fbm(vec2 p) {
    float v = 0.0;
    float a = 0.5;
    for (int i = 0; i < 5; i++) {
        v += a * vnoise(p);
        p = p * 2.13 + vec2(7.7);
        a *= 0.5;
    }
    return v;
}

// 3-octave variant (cheap proxy: cloud shadows on the ground)
float fbm3(vec2 p) {
    float v = 0.0;
    float a = 0.5;
    for (int i = 0; i < 3; i++) {
        v += a * vnoise(p);
        p = p * 2.13 + vec2(7.7);
        a *= 0.5;
    }
    return v;
}

// ============ BAKED NOISE TEXTURE (NOISE_TEX) ============
// 256^2 RGBA8 home-baked noise (customTexture vlNoiseTex, bilinear + REPEAT):
// R/G = two smoothed periodic value noises (ONE lattice unit = ONE texel, so
// vnoiseTex keeps the EXACT spatial scale of vnoise - critical for 1:1 swaps),
// B = periodic Worley F1 (dark at feature points, ~8-texel cells), A = uniform
// white noise. vnoiseTex samples p/256: one bilinear tap replaces 4 hash12 +
// 3 mixes per octave; the field simply tiles every 256 noise units (call sites
// are decorative fog/cloud/sky fields far below that scale). The pattern is
// ANOTHER noise instance than vnoise: NEVER swap a site that must stay in sync
// with an arithmetic copy (cloudShadow mirrors in lib/lighting.glsl, water
// waves/caustics) - those keep vnoise.
// NOISE_TEX=0 -> arithmetic fallbacks, bit-identical to the original pack.
#if NOISE_TEX == 1
#ifndef VL_NOISE_TEX_DECL
#define VL_NOISE_TEX_DECL
uniform sampler2D vlNoiseTex;
#endif
float vnoiseTex(vec2 p) {
    return texture2D(vlNoiseTex, p / 256.0).r;
}
#else
float vnoiseTex(vec2 p) {
    return vnoise(p);
}
#endif

// fbm/fbm3 twins on the baked texture (same lacunarity, gain and offsets, so
// NOISE_TEX=0 makes them bit-identical to fbm/fbm3).
float fbmTex(vec2 p) {
    float v = 0.0;
    float a = 0.5;
    for (int i = 0; i < 5; i++) {
        v += a * vnoiseTex(p);
        p = p * 2.13 + vec2(7.7);
        a *= 0.5;
    }
    return v;
}

float fbm3Tex(vec2 p) {
    float v = 0.0;
    float a = 0.5;
    for (int i = 0; i < 3; i++) {
        v += a * vnoiseTex(p);
        p = p * 2.13 + vec2(7.7);
        a *= 0.5;
    }
    return v;
}

// ============ CLOUDS - WORLD TIME ============
// Cloud advection follows WORLD time (Iris worldTime/worldDay), not the real
// clock: /time set, sleeping or a changed tick speed move the clouds WITH the
// world. In normal play worldTime advances 20 ticks/s, so cloudWorldTime()
// grows by 1.0/s, matching frameTimeCounter - wind speeds need no rescaling.
// Declared here because common.glsl is included by ALL programs (v120 and
// v430); unused Iris uniforms are harmless in the programs that ignore them.
// mod 128 days caps float precision loss on old worlds (~153600 s max, step
// ~1/64 s); the trade-off is one cloud jump every 128 in-game days.
// v120 has no integer % operator, hence float mod().
uniform int worldTime;
uniform int worldDay;
float cloudWorldTime() {
    return mod(float(worldDay), 128.0) * 1200.0 + float(worldTime) * 0.05;
}

// ============ BLUE-NOISE DITHER (volumetric marches only) ============
// 64^3 tileable blue noise (customTexture vlBlueNoise, NEAREST + REPEAT).
// Screen xy wraps every 64 px through REPEAT, so gl_FragCoord passes unscaled;
// a new z-slice each frame decorrelates successive frames and TAA averages the
// march jitter into smooth gradients (the static 8x8 Bayer left banding).
// v120-safe: float mod(), no bitwise ops. Callers pass the frameCounter
// uniform; the slice freezes without TAA (no accumulation -> would shimmer).
#if BLUE_NOISE == 1
#ifndef VL_BLUE_NOISE_DECL
#define VL_BLUE_NOISE_DECL
uniform sampler3D vlBlueNoise;
#endif
float blueDither(vec2 fragCoord, int frame) {
    #ifdef TAA
    float slice = (mod(float(frame), 64.0) + 0.5) * (1.0 / 64.0);
    #else
    float slice = 0.5 * (1.0 / 64.0); // static slice: no flicker without TAA
    #endif
    return texture3D(vlBlueNoise, vec3(fragCoord * (1.0 / 64.0), slice)).r;
}
#endif
