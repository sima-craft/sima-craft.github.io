/* CORPS PARTAGE des translucides (fragment) : near-transparent water with
   waves, glass with micro-relief, nether portal (vanilla animated texture
   lifted to HDR).
   Compile deux fois :
     - gbuffers_water.fsh   -> chemin normal (eau vanilla, champ wave3) ;
     - physics_ocean_v2.fsh -> variante ocean de PHYSICS MOD PRO
       (VLX_PHYSICS_OCEAN_PROGRAM) : la normale ecrite au gbuffer est celle
       du champ de vagues SIMULE du mod, donc SSR / Fresnel / glint GGX /
       wMirror (composite1, via colortex1) eclairent les vagues du mod.
   The final look (absorption, caustics, reflections, refraction) is built in
   composite1; this pass only writes tint, normal and material flag.
   Writes: colortex0 color+alpha, 1 normal, 2 lightmap + flag, 5 biome water tint.
   Material flag (colortex2.b): 0 = other, 0.5 = emissive, 0.7 = glass,
   0.85 = portal, 1.0 = water (0.38 = snow, gbuffers_terrain only, SNOW_SPARKLE).
   Keep in sync with composite1. */

#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/distort.glsl"
#include "/lib/biome.glsl"
#include "/lib/dimension.glsl"
#include "/lib/lighting.glsl"
#include "/lib/water.glsl"

/* ===== PHYSICS MOD PRO : ocean dynamique (voir program_water_vertex.glsl) == */
#if defined VLX_PHYSICS_OCEAN_PROGRAM && PHYSICS_MOD_SUPPORT == 1
    #define PHYSICS_OCEAN
#endif
#ifdef PHYSICS_OCEAN
#include "/lib/physicsmod_ocean.glsl"
    varying vec3 physics_localPosition;
    varying float physics_localWaviness;
#if PHYSICS_FIELD_SYNC == 1
    // PHYSICS_FIELD_SYNC (lib/settings.glsl) : canal lateral vers composite.
    // Les deux images sont declarees dans shaders.properties (leur nom EST le
    // nom de l'uniforme image ici). imageStore exige GL 4.2, d'ou le
    // "#version 430 compatibility" de physics_ocean_v2.fsh - gbuffers_water.fsh
    // reste en 120 et ne voit jamais ce bloc (PHYSICS_OCEAN n'y est pas defini).
    layout(rgba32f) uniform image2D physOceanParams;
    layout(r32ui)  uniform uimage2D physOceanPix;
#if PHYS_REAL == 1
    // PHYS_REAL (lib/settings.glsl) : la TEXTURE DE RIDES du mod
    // (physics_ripples : sillages, impacts) n'est liee qu'a ce programme et au
    // programme ombre. Ces deux images la republient pour composite.
    layout(r16f)    uniform image2D physRipple;
    layout(rgba32f) uniform image2D physRipParams;
#if PHYS_REAL_V2 == 1
    // PHYS_REAL_V2 (lib/settings.glsl) : la carte de WAVINESS ancree monde.
    // cameraPosition (lib/lighting.glsl, inclus par ce corps) ne sert qu'au
    // rayon d'ecriture PHYS_REAL_V2_WAVR, pas a l'indexation.
    layout(rg16f)   uniform image2D physWavMap;
#endif
    // Index dense du fragment dans le framebuffer : il faut la largeur.
    #ifndef VL_VIEWW_DECL
    #define VL_VIEWW_DECL
    uniform float viewWidth;
    #endif
#endif
    // Guard: frameCounter est deja declare plus haut dans la chaine d'includes
    // par lib/lighting.glsl (rotation PCF bruit bleu, meme garde) ; un uniforme
    // en double est une erreur GLSL.
    #ifndef VL_FRAMECOUNTER_DECL
    #define VL_FRAMECOUNTER_DECL
    uniform int frameCounter;
    #endif
#endif
#endif

// WAVE_FAST_NORMALS: hoisted wind transform + tighter octave LOD (see
// waveNormalWorldFast, lib/water.glsl). Only covers the choppy V2 normals;
// the V3 two-layer path keeps the original evaluator. Both branches define
// the macro, so call sites below stay gate-free.
#if WAVE_FAST_NORMALS == 1 && WAVES_V2 == 1 && WAVE_NORMALS_V3 == 0
    #define WAVE_NORMAL_FUNC waveNormalWorldFast
#else
    #define WAVE_NORMAL_FUNC waveNormalWorld
#endif

uniform sampler2D gtexture;
uniform mat4 gbufferModelView;
// Player velocity is reconstructed from previousCameraPosition + frameTime
// (standard, reliable Iris uniforms).
uniform int isEyeInWater;
uniform vec3 previousCameraPosition;
uniform float frameTime;
#if RIPPLE_BIOME_GATE == 1
// Iris built-in (>= 1.6.1): precipitation of the CAMERA biome.
// 0 = none (desert), 1 = rain, 2 = snow. Gates the rain impact rings.
uniform int biome_precipitation;
#endif

#ifdef WATER_RIPPLES
// Water entry/exit splash impulse. Two exponential followers of the same
// isEyeInWater state (smooth() ids 41/42, see shaders.properties). The SLOW
// follower (half-life 1.6 s; Iris smooth unit is 0.1 s per value) acts as a
// CLOCK: |target - slow| = 0.5^(age/1.6), so the age of the last transition is
// reconstructed WITHOUT GLSL state and the ring radius is strictly increasing.
// If Iris ever pinned these uniforms to 0 (rejected expression), dev = 0 and
// the effect goes silent instead of producing artifacts.
uniform float rippleSplashFast;
uniform float rippleSplashSlow;
// FROZEN WORLD ANCHORS (smooth() ids 43-48, see shaders.properties).
// splashIn* = camera position FROZEN at water ENTRY (snaps to the camera while
// out of water, half-life ~1000 s once submerged); splashOut* is the mirror
// image, the EXIT position held while emerged. The ring is drawn around
// worldPos - anchor, so it stays PLANTED in the world instead of following the
// camera while swimming.
uniform float splashInX;
uniform float splashInY;
uniform float splashInZ;
uniform float splashOutX;
uniform float splashOutY;
uniform float splashOutZ;
#if RIPPLES_V5 == 1
// PLAYER-CENTERED ripples. eyePosition (Iris-only vec3 uniform) is the world
// position of the player MODEL's head: same as cameraPosition in first person,
// but NOT in third person (F5) - that mismatch was the old wake offset.
// Feet are roughly eyePosition.y - 1.62 when standing (wide windows are used so
// swimming and boats still match).
uniform vec3 eyePosition;
// Splash anchors: same frozen followers as ids 43-48 but on eyePosition
// (smooth ids 49-54, see shaders.properties). Same zero-uniform fallback: if
// Iris rejected eyePosition in a custom expression, the anchor is (0,0,0) and
// the yGate in splashRingSlope silences the ring, with no artifacts.
uniform float splashIn2X;
uniform float splashIn2Y;
uniform float splashIn2Z;
uniform float splashOut2X;
uniform float splashOut2Y;
uniform float splashOut2Z;
#endif

// Wave packet at the ring front: 2-3 thin crests (wavelength ~0.7 block) under a
// gaussian envelope centered on the front, front energy ~ 1/sqrt(radius).
// Returns an xz SLOPE (a normal perturbation, not a painted circle).
vec2 splashPacket(vec2 dxz, float radius, float amp) {
    float r = length(dxz);
    float dR = r - radius;
    if (r < 0.05 || abs(dR) > 1.6) return vec2(0.0);
    float packet = sin(dR * 9.0) * exp(-dR * dR * 2.8);
    return (dxz / r) * packet * amp * inversesqrt(max(radius, 0.5));
}

// WORLD-ANCHORED impulse ring. wpos = ABSOLUTE world position of the fragment
// (worldPos = wp + cameraPosition, see the vsh). Anchor depends on state:
// submerged -> frozen ENTRY point, emerged -> frozen EXIT point. The swap at a
// transition is intentional: the old ring vanishes, a new one is born.
// TUNING: if the expansion looks too slow/fast, the only knob is the 1.6
// constant on the age line (half-life of smooth id 42: 16 x 0.1 s).
vec2 splashRingSlope(vec3 wpos) {
    float dev = abs(float(isEyeInWater) - rippleSplashSlow);
    // Too young (< ~0.07 s, anchor still freezing) or too old (~9 s) -> silent.
    if (dev > 0.97 || dev < 0.02) return vec2(0.0);
    float age = -1.6 * log2(dev); // inverse of dev = 0.5^(age/1.6)
    #if RIPPLES_V5 == 1
    // Anchor = frozen PLAYER position (eyePosition) at the transition, so in
    // third person the ring is born on the body, not 4 blocks behind.
    // In first person this is strictly identical to the camera anchors below.
    vec3 anchor = (isEyeInWater == 1) ? vec3(splashIn2X, splashIn2Y, splashIn2Z)
                                      : vec3(splashOut2X, splashOut2Y, splashOut2Z);
    #else
    vec3 anchor = (isEyeInWater == 1) ? vec3(splashInX, splashInY, splashInZ)
                                      : vec3(splashOutX, splashOutY, splashOutZ);
    #endif
    vec3 d3 = wpos - anchor;
    // yGate is the zero-uniform fallback: if Iris rejected the anchor
    // expressions, anchor = (0,0,0) and |dy| ~ 62 on a vanilla sea -> silent
    // ring, no artifacts. It also limits the effect to water planes near the
    // entry/exit height (no ghost ring on a lake far below).
    float yGate = 1.0 - smoothstep(3.5, 5.0, abs(d3.y));
    if (yGate <= 0.0) return vec2(0.0);
    // STRICTLY increasing radius (~1.9 block/s).
    float radius = 0.45 + age * 1.9;
    float amp = (1.0 - smoothstep(0.90, 0.97, dev)) // soft birth
              * smoothstep(0.02, 0.10, dev)         // soft death
              * yGate;
    // Slope scaled like the swell (x WATER_NORMAL_STRENGTH) so both react to the same slider.
    return splashPacket(d3.xz, radius, amp) * 0.85 * RIPPLE_SPLASH_STRENGTH * WATER_NORMAL_STRENGTH;
}
#endif

// ===== Nether portal (PORTAL_FX) =====
// The nether_portal block is TRANSLUCENT, so Iris routes it HERE (gbuffers_water),
// not to gbuffers_terrain. The VANILLA texture is kept: nether_portal.png is an
// atlas animation stepped by the game itself (one frame per tick), so 'col'
// already holds the current frame and NOTHING is re-animated with
// frameTimeCounter. The former procedural "energy core" (domain-warped fbm
// filaments + sparks + heavy view parallax) is gone: its warp field, itself
// drifting, was injected x1.9 into a 2x finer field, so the thin filament mask
// strobed several times per second and every head turn slid the deep layer by
// up to ~9 pattern units - the "hyper-accelerated" look. Its spiral advection
// also rotated ABSOLUTE world coords (ang ~ t*0.05..0.11), sweeping the field
// at |p|*0.05 u/s - the dominant strobe far from the world origin.

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 normal;
varying vec3 viewPos;
varying vec3 worldPos;
varying float mat;

void main() {
    bool isWater = (mat > 7.5 && mat < 8.5);
    bool isGlass = (mat > 29.5 && mat < 30.5);
    // Gate: with PORTAL_FX 0, isPortal stays false and the plain rendering is used.
    bool isPortal = false;
    #if PORTAL_FX == 1
        isPortal = (mat > 24.5 && mat < 25.5);
    #endif

    vec3 albedo;
    float alpha;
    if (isWater) {
        // Near transparent: the bottom stays visible, composite1 does the rest.
        // Surface tint is desaturated by 0.5 x WATER_TINT_DESAT so close-up water
        // is not a flat saturated vanilla patch. DESAT = 0.0 keeps the raw tint.
        albedo = mix(toLinear(glcolor.rgb), vec3(luma(toLinear(glcolor.rgb))), 0.5 * WATER_TINT_DESAT) * 0.18;
        // NOT THE SHIPPED ALPHA -- READ THIS BEFORE MEASURING ANYTHING HERE.
        // This 0.25 is a PLACEHOLDER for the water branch only. Every water
        // fragment overwrites it further down, in the `if (isWater)` block just
        // before the DRAWBUFFERS write: a horizontal surface takes
        // mix(0.08 + 0.07 * WATER_SURFACE_PRESENCE, 0.38, fresG), i.e. ~0.15 at
        // normal incidence with the shipped PRESENCE 1.0, and a vertical
        // waterfall face takes max(0.32 + fallFoam * 0.30, mix(0.32, 0.62,
        // fresG)). An EAU7 audit priced this layer at 1.8-3.0% of the delivered
        // pixel by reading 0.25 as the final value; the real near-field weight
        // is about 0.6x that. The place to change the surface's presence is
        // WATER_SURFACE_PRESENCE at the real site, never this line.
        alpha = 0.25;
    } else {
        vec4 col = texture2D(gtexture, texcoord) * glcolor;
        if (isGlass && col.a < 0.05) {
            // Clear glass: keep a nearly invisible surface so it can still catch
            // reflections and light (works with resource packs)
            albedo = vec3(0.03);
            alpha = 0.15;
        } else {
            // Never discard the portal: low-alpha texels would punch flag/normal
            // holes in the vanilla sheet (resource packs may use low alpha).
            // isPortal is false when PORTAL_FX = 0, so behavior is unchanged there.
            if (col.a < 0.05 && !isPortal) discard;
            albedo = toLinear(col.rgb);
            alpha = col.a;
        }
    }

    vec3 normalV = normalize(normal);
    float fallFoam = 0.0;
    float physicsFoam = 0.0; // ecume du champ PHYSICS MOD (reste 0 hors ocean physics)
    bool vertFace = false; // true on a VERTICAL water face (waterfall). Declared OUTSIDE the
                           // #ifdef WATER_WAVES gate so low presets still compile.
    #ifdef WATER_WAVES
        vec3 wn = mat3(gbufferModelViewInverse) * normalV;
        if (isWater && wn.y > 0.5) {
            // Murky water (swamp) = calm and oily; oceans = full swell
            float murkW = 1.0 - luma(glcolor.rgb);
            #ifdef PHYSICS_OCEAN
                // Normale de vague du MOD (espace monde, +Y haut) : champ
                // physics_wavePixel = vagues simulees + ripples du mod
                // (sillages, impacts) + ecume. REMPLACE wave3NormalWorld ici :
                // c'est la normale qui part au gbuffer (colortex1), donc SSR /
                // Fresnel / glint GGX / wMirror de composite1 eclairent LES
                // VAGUES DU MOD. Le flatten murk/grazing n'est pas reapplique :
                // le champ du mod porte deja son facteur cote (waviness) et sa
                // propre attenuation. Nos rides pluie/plongeon s'ajoutent
                // ensuite par-dessus, comme sur l'eau normale (meme curseur) -
                // le ring de plongeon peut doubler legerement les ripples
                // propres du mod, cosmetique et assume.
                WavePixelData vlxWave = physics_wavePixel(physics_localPosition.xz,
                                                          physics_localWaviness,
                                                          physics_iterationsNormal,
                                                          physics_gameTime);
                physicsFoam = vlxWave.foam;
                // Feuille unique vue des deux cotes : normale retournee au dos
                // (meme convention que l'injection officielle du mod).
                vec3 wnorm = gl_FrontFacing ? vlxWave.normal : -vlxWave.normal;
            #elif WAVES_V3 == 1
                // v3: exact-derivative normal, grazing-angle flattening and
                // (near field only) parallax occlusion. The distance fade is no
                // longer a slope gain but a view-angle one, so no chopFade is
                // built at all here; murky water reads calm AND oily, hence both
                // a lower amplitude and a stronger flattening.
                vec3 vdirW = mat3(gbufferModelViewInverse) * normalize(viewPos);
                vec3 wnorm = wave3NormalWorld(worldPos, vdirW, frameTimeCounter,
                                              WAVE_STRENGTH * mix(1.0, 0.6, murkW),
                                              WAVE3_FLATTEN * mix(1.0, 2.0, murkW),
                                              length(viewPos)); // WAVE_LOD
            #else
            float dist = length(viewPos);
            float chopFade = 1.0 / (1.0 + dist * 0.04);
            chopFade *= mix(1.0, 0.45, murkW);
            vec3 wnorm = WAVE_NORMAL_FUNC(worldPos.xz, frameTimeCounter,
                                          WAVE_STRENGTH * mix(1.0, 0.6, murkW), chopFade);
            #endif
            wnorm = normalize(vec3(wnorm.x * WATER_NORMAL_STRENGTH, wnorm.y, wnorm.z * WATER_NORMAL_STRENGTH)); // x,z = slopes (slider), y = up. Neutral at 1.0.

            #ifdef WATER_RIPPLES
                // (a) Dive/surface impulse: a single WORLD-ANCHORED ring at the
                //     entry/exit point (frozen anchors, smooth ids 43-48) that
                //     expands and damps out (splashRingSlope, top of file).
                //     It perturbs the NORMAL and does not follow the camera.
                wnorm.xz += splashRingSlope(worldPos);


                // (c) Rain: random droplet impacts over 2 cell layers at
                //     different scales so no grid is visible. Each cycle replays
                //     a short ring that expands (~1.1 block/s) then dies, at a
                //     DIFFERENT impact point. Open sky only.
                float rainRip = rainStrength * smoothstep(0.80, 0.95, lmcoord.y) * RIPPLE_RAIN_STRENGTH;
                #if RIPPLE_BIOME_GATE == 1
                // Camera-biome gate: no rings in deserts (no rainfall) or where
                // it snows instead of raining. 0 none, 1 rain, 2 snow.
                rainRip *= float(biome_precipitation == 1);
                #endif
                if (rainRip > 0.01) {
                    for (int L = 0; L < 2; L++) {
                        float scL = (L == 0) ? 1.0 : 1.63;
                        vec2 pp = worldPos.xz * scL + float(L) * 17.31;
                        vec2 cellR = floor(pp);
                        float h0 = hash12(cellR + float(L) * 3.7);
                        float lifeT = frameTimeCounter * (1.3 + 0.6 * h0) + h0 * 11.0;
                        float cyc = floor(lifeT);
                        float ph = fract(lifeT);
                        vec2 hit = vec2(hash12(cellR + cyc * 0.173), hash12(cellR + cyc * 0.377 + 9.1)) * 0.7 + 0.15;
                        vec2 dxz = (fract(pp) - hit) / scL; // back to BLOCK units
                        float rr = length(dxz);
                        // Density follows rain strength: some cycles stay silent
                        float on = step(hash12(cellR + cyc * 0.731), 0.25 + 0.65 * rainStrength);
                        float rad = ph * 0.55; // ring front EXPANDS with the phase
                        float dR = rr - rad;
                        // Capillary TRAIN: crisp leading crest + 2-3 trailing
                        // rings BEHIND the front (dR < 0), dead water ahead of
                        // it -- reads as concentric circles, not noise.
                        float env = exp(-dR * dR * ((dR > 0.0) ? 260.0 : 34.0));
                        float born = smoothstep(0.0, 0.12, ph); // no pop at impact
                        float ring = sin(dR * 30.0) * env * born * (1.0 - ph) * (1.0 - ph);
                        // Scaled by WATER_NORMAL_STRENGTH like the swell, so one slider drives both.
                        wnorm.xz += (dxz / max(rr, 0.03)) * ring * on * 0.85 * rainRip * WATER_NORMAL_STRENGTH / scL;
                    }
                }
                wnorm = normalize(wnorm);
            #endif

            normalV = normalize(mat3(gbufferModelView) * wnorm);
        } else if (isWater && wn.y < -0.5) {
            // Bottom face (seen from underwater): mirrored waves, same ripple as
            // the top face but with the normal pointing down
            float murkW2 = 1.0 - luma(glcolor.rgb);
            #ifdef PHYSICS_OCEAN
                // Meme champ du mod que la face du dessus (meme feuille vue par
                // en dessous) ; miroir applique plus bas comme pour wave3.
                WavePixelData vlxWave2 = physics_wavePixel(physics_localPosition.xz,
                                                           physics_localWaviness,
                                                           physics_iterationsNormal,
                                                           physics_gameTime);
                vec3 wnorm2 = vlxWave2.normal;
            #elif WAVES_V3 == 1
                // Same field as the top face (it is the same sheet, seen from
                // below), flattened with the same view-angle law; the normal is
                // mirrored after the ripples, as before.
                vec3 vdirW2 = mat3(gbufferModelViewInverse) * normalize(viewPos);
                vec3 wnorm2 = wave3NormalWorld(worldPos, vdirW2, frameTimeCounter,
                                               WAVE_STRENGTH * 0.55 * mix(1.0, 0.50, murkW2),
                                               WAVE3_FLATTEN * mix(1.0, 2.0, murkW2),
                                               length(viewPos)); // WAVE_LOD
            #else
            float dist2 = length(viewPos);
            float cf2 = 1.0 / (1.0 + dist2 * 0.06) * mix(1.0, 0.40, murkW2);
            vec3 wnorm2 = WAVE_NORMAL_FUNC(worldPos.xz, frameTimeCounter,
                                           WAVE_STRENGTH * 0.55 * mix(1.0, 0.50, murkW2), cf2);
            #endif
            #ifdef WATER_RIPPLES
                // The dive ring is mostly seen FROM BELOW (right after entering
                // the water), so apply the same WORLD-ANCHORED perturbation; the
                // normal is mirrored with the rest of the wave below.
                wnorm2.xz += splashRingSlope(worldPos);
                wnorm2 = normalize(wnorm2);
            #endif
            // Opposite normal: same wave, face seen from below. Must use the same
            // WATER_NORMAL_STRENGTH as the top face or the slider only drives half
            // of the water surfaces.
            wnorm2 = normalize(vec3(wnorm2.x * WATER_NORMAL_STRENGTH, wnorm2.y, wnorm2.z * WATER_NORMAL_STRENGTH));
            normalV = normalize(mat3(gbufferModelView) * vec3(-wnorm2.x, -wnorm2.y, -wnorm2.z));
        } else if (isWater) {
            // Vertical water (waterfalls): multi-octave downward flow.
            vertFace = true; // vertical face -> lower fresnel reflection floor applied later
            vec3 tdir = normalize(vec3(wn.z, 0.0, -wn.x) + vec3(1e-4));
            // True OUT-OF-PLANE binormal (perpendicular to both the face and the flow).
            // It is what CARVES the vertical channels; tdir and up are tangent to the
            // face, so perturbing only those leaves the relief FLAT.
            vec3 binrm = normalize(cross(wn, tdir));
            // Distance falloff: kills high-frequency shimmer far away.
            float fallFade = 1.0 / (1.0 + length(viewPos) * 0.05);
            float u = dot(worldPos.xz, tdir.xz);
            float vY = worldPos.y;
            float ft = frameTimeCounter;
            float fall = ft * WATER_FALL_SPEED;
            float meander = vnoise(vec2(u * 1.3, vY * 0.5 + fall *0.4)) - 0.5;
            float uu = u + meander * 0.6;
            float s1 = vnoise(vec2(uu * 2.2, vY * 1.0 + fall *1.0));
            float s2 = vnoise(vec2(uu * 5.0, vY * 2.2 + fall *1.7)) * 0.6;
            float s3 = vnoise(vec2(uu * 10.0, vY * 4.0 + fall *2.6)) * 0.35;
            float streak = s1 + s2 + s3;
            // VERTICAL derivative (channel troughs) and HORIZONTAL one (stream edges).
            float dStreakV = (vnoise(vec2(uu * 5.0, vY * 2.2 + fall *1.7 + 0.15)) * 0.6
                            - vnoise(vec2(uu * 5.0, vY * 2.2 + fall *1.7 - 0.15)) * 0.6);
            float dStreakU = (vnoise(vec2(uu * 5.0 + 0.15, vY * 2.2 + fall *1.7)) * 0.6
                            - vnoise(vec2(uu * 5.0 - 0.15, vY * 2.2 + fall *1.7)) * 0.6);
            // Relief rebuilt on the true out-of-plane binormal + tdir + vertical drop,
            // all damped with distance (fallFade) to avoid shimmering.
            vec3 nW2 = normalize(
                  wn
                + binrm * dStreakU * 1.10 * WATER_FALL_RELIEF * fallFade
                + tdir * (s1 - 0.5) * 0.35 * WATER_FALL_RELIEF * fallFade
                - vec3(0.0, 1.0, 0.0) * dStreakV * 0.30 * WATER_FALL_RELIEF * fallFade);
            normalV = normalize(mat3(gbufferModelView) * nW2);
            // Foam only on real crests (high threshold) + distance fade: fewer wide bands.
            fallFoam = smoothstep(1.25, 1.75, streak) * fallFade;
            // Base wall kept fairly clear, with local foam on top.
            alpha = max(alpha, 0.32 + fallFoam * 0.30);
        }
    #endif
    #ifdef GLASS_EFFECTS
        if (isGlass && GLASS_DISTORTION > 0.01) {
            // Glass micro-relief: subtly irregular reflections and refraction
            vec2 gn = vec2(vnoise(worldPos.yz * 2.3 + worldPos.x),
                           vnoise(worldPos.xy * 2.3 + worldPos.z)) - 0.5;
            normalV = normalize(normalV + vec3(gn * 0.06 * GLASS_DISTORTION, 0.0));
        }
    #endif

    float dither = bayer8(gl_FragCoord.xy);
    vec3 color = shadeSurface(albedo, normalV, lmcoord, viewPos, dither, 0.0);

    // White waterfall foam, lit locally
    if (fallFoam > 0.0) {
        color += (getAmbientColor() + getLightColor() * 0.4)
               * fallFoam * 0.45 * (lmcoord.y * lmcoord.y * 0.92 + 0.08);
    }

    if (isWater) {
        // Water must look right ON ITS OWN (it is visible behind glass, where the
        // composite pass cannot dress it): fresnel sky reflection + opacity that
        // rises at grazing angles.
        float ndv = clamp(dot(normalV, -normalize(viewPos)), 0.0, 1.0);
        float fresG = 0.02 + 0.98 * pow(1.0 - ndv, 5.0);
        // On a vertical water wall the fresnel term collapses (dull water), so apply a
        // reflectivity floor. Horizontal water is untouched (vertFace stays false there).
        fresG = max(fresG, vertFace ? WATER_FALL_REFLECT_FLOOR : 0.0);
        float skyl2 = lmcoord.y * lmcoord.y;
        #ifdef WATER_SKY_REFLECT
        color += (getAmbientColor() * 0.65 + getLightColor() * 0.03) * fresG * skyl2;
        #endif
        // Do NOT overwrite the alpha of vertical waterfalls: the 0.32 + fallFoam
        // value set in the vertical branch must survive to the blend stage.
        if (vertFace) alpha = max(alpha, mix(0.32, 0.62, fresG));
        // ROOT CAUSE of five failed water-color rounds: the surface layer was
        // blended at 50-85% opacity, painting shaded vanilla-blue + sky sheen
        // OVER the floor BEFORE composite1's water model ever ran -- tuning the
        // composite only ever touched half the pixel. THE DESIGN DECISION that
        // followed: this pass writes as close to NO surface colour as it can.
        // Every bit of hue the translucent blend lays down here is hue the
        // composite can no longer control, because it arrives already
        // multiplied into the pixel and OUTSIDE the path-driven Beer-Lambert
        // column that is the actual water model. So the alpha below stays a
        // thin presence term driven by fresnel alone, never a paint layer.
        // The small floor is kept for exactly one case: water seen THROUGH
        // glass skips the composite dressing entirely, and at alpha 0 it would
        // disappear.
        else alpha = mix(0.08 + 0.07 * WATER_SURFACE_PRESENCE, 0.38, fresG); // near-field presence dial (0.15 default: water visibly EXISTS)

        #ifdef PHYSICS_OCEAN
        // Ecume du champ PHYSICS MOD (cretes + trainees worley du mod, deja
        // dosee par ses reglages foamAmount/foamOpacity) : eclairee comme
        // l'ecume de cascade (locale, jamais HDR) + une presence alpha pour
        // que la colonne Beer-Lambert de composite1 ne la dissolve pas. Elle
        // vient APRES le calcul d'alpha ci-dessus pour y survivre.
        if (physicsFoam > 0.001) {
            color += (getAmbientColor() + getLightColor() * 0.4)
                   * physicsFoam * 0.55 * (lmcoord.y * lmcoord.y * 0.92 + 0.08);
            alpha = max(alpha, physicsFoam * 0.6);
        }
        #endif
    }

    // ===== Nether portal: vanilla texture, native animation, HDR glow =====
    #if PORTAL_FX == 1
    if (isPortal) {
        // 'albedo' / 'alpha' are the vanilla nether_portal.png texel (current
        // animation frame, vanilla translucency - see the note above main()).
        // The portal is its own light source: the texel replaces the lightmap
        // shading and is lifted to HDR (x2.0 at the defaults: bright swirls reach
        // luma ~0.5-0.7, inside the BLOOM_MIP knee -> soft violet halo; dark
        // texels stay dark). PORTAL_GLOW 0 leaves a dim but visible sheet.
        // The gbuffer normal stays the flat face normal: composite1 (flag 0.85)
        // only adds the optional NETHER_PORTAL_WOBBLE sub-pixel shimmer.
        color = albedo * (0.6 + EMISSIVE_BOOST * 0.175 * PORTAL_GLOW);
    }
    #endif

    float flag = isWater ? 1.0 : (isGlass ? 0.7 : (isPortal ? 0.85 : 0.0));

/* DRAWBUFFERS:0125 */
    gl_FragData[0] = vec4(color, alpha);
    gl_FragData[1] = vec4(normalV * 0.5 + 0.5, 1.0);
    gl_FragData[2] = vec4(lmcoord, flag, 1.0);
    // Biome water tint (alpha 0 for glass: do not overwrite the albedo)
    gl_FragData[3] = vec4(glcolor.rgb, isWater ? 1.0 : 0.0);

#if defined PHYSICS_OCEAN && PHYSICS_FIELD_SYNC == 1
    // ===== PHYSICS_FIELD_SYNC : PUBLICATION DU CHAMP (voir settings.glsl) ====
    // composite1 n'a AUCUN acces aux UBO du mod : ces deux images sont le seul
    // pont. Ecrit APRES les gl_FragData, donc jamais pour un fragment jete
    // (les `discard` de ce corps sont tous plus haut).
    if (isWater) {
        // (a) ESTAMPILLE PAR PIXEL. Un texel vaut "surface d'ocean physics de
        // CETTE frame" ssi (v >> 8) == uint(frameCounter) - exact, aucun faux
        // positif possible (contrairement a un compteur modulo). Les 8 bits bas
        // portent la waviness locale, que composite1 rend au champ.
        // Le pixel est celui du framebuffer : composite1 est un pass PRE-TAA qui
        // travaille dans les memes coordonnees ecran que le gbuffer (il lit
        // colortex0/depthtex a `uv` NU, pas a uv*TAAU_S - cette regle-la est
        // celle des passes POST-TAA), donc ivec2(gl_FragCoord.xy) des deux
        // cotes, y compris dans le sous-rect TAAU.
        imageStore(physOceanPix, ivec2(gl_FragCoord.xy),
                   uvec4((uint(frameCounter) << 8)
                         | uint(clamp(physics_localWaviness, 0.0, 1.0) * 255.0 + 0.5),
                         0u, 0u, 0u));
        // (b) PARAMETRES GLOBAUX + BATTEMENT. Sous-echantillonne 1 fragment sur
        // 16 (grille 4x4) : toutes ces valeurs sont identiques d'un fragment a
        // l'autre, la seule raison d'ecrire souvent est de garantir AU MOINS UNE
        // ecriture par frame, et marteler 32 octets depuis un million de
        // fragments serialiserait la ligne de cache. Un ocean couvrant moins de
        // 4x4 pixels ne publie pas : a cette taille il n'y a rien a synchroniser.
        // DRIFT : worldPos est la position monde ABSOLUE du fragment,
        // physics_localPosition le meme sommet dans le maillage du mod ; les
        // deux sont interpoles lineairement, donc leur difference est EXACTE sur
        // le triangle. HYPOTHESE ASSUMEE (verifiable par DEBUG_VIEW 30) : ce
        // drift est le meme dans tous les chunks - il doit l'etre, sinon les
        // vagues du mod auraient des coutures aux frontieres de chunk.
        if (fract(gl_FragCoord.x * 0.25) < 0.25 && fract(gl_FragCoord.y * 0.25) < 0.25) {
            imageStore(physOceanParams, ivec2(0, 0),
                       vec4(physics_gameTime, physics_oceanHeight,
                            physics_oceanWaveHorizontalScale, float(frameCounter)));
            vec2 vlxDrift = worldPos.xz - (physics_localPosition.xz
                                           - vec2(physics_waveOffsetX, physics_waveOffsetZ));
            imageStore(physOceanParams, ivec2(1, 0),
                       vec4(vlxDrift, clamp(physics_localWaviness, 0.0, 1.0),
                            float(physics_iterationsNormal)));
#if PHYS_REAL == 1
            // (c) PARAMETRES DE LA CARTE DE RIDES. normalSampleDistance est
            // recalcule EXACTEMENT comme physics_waveNormal le fait
            // (texelWorldSize = max(2*range/texSize, 0.001), plafonne a
            // PHYSICS_RIPPLE_NORMAL_SAMPLE_WORLD_DISTANCE) ; le lecteur y
            // applique en plus son propre plancher d'un texel de la COPIE.
            // CENTRE MONDE de la carte : physics_rippleUv echantillonne a
            // (position + modelOffset + range)/(2 range), donc la carte est
            // centree sur le point monde ou position + modelOffset = 0 ;
            // worldPos.xz - (localPosition.xz + modelOffset.xz) EST ce point,
            // exact par chunk (difference de deux quantites interpolees
            // lineairement sur le triangle).
            float vlxRipTS = float(textureSize(physics_ripples, 0).x);
            float vlxNsd = min(max((physics_rippleRange * 2.0) / max(vlxRipTS, 1.0),
                                   0.001),
                               PHYSICS_RIPPLE_NORMAL_SAMPLE_WORLD_DISTANCE);
            imageStore(physRipParams, ivec2(0, 0),
                       vec4(vlxRipTS, physics_rippleRange, vlxNsd,
                            float(frameCounter)));
            imageStore(physRipParams, ivec2(1, 0),
                       vec4(worldPos.xz - (physics_localPosition.xz
                            + vec2(physics_modelOffsetX, physics_modelOffsetZ)),
                            0.0, 0.0));
#endif
        }
#if PHYS_REAL == 1
        // (d) COPIE DE LA TEXTURE DE RIDES, 4 texels CONSECUTIFS par fragment
        // ocean. physics_ripples n'existe que dans ce programme ; composite ne
        // peut la lire que par cette copie.
        // INDEX TOURNANT : base = 4*idx + frameCounter*ROT, modulo N^2. Un
        // ocean qui couvre 12.6 % d'un ecran 1080p recopie TOUTE la carte
        // chaque frame ; a 5 % il lui faut 2.5 frames et la rotation (ROT
        // impair, donc premier avec 2^20) deplace la fenetre pour combler.
        // Les rides du mod avancent a 1-2 blocs/s : 3 frames = 0.05-0.10 bloc
        // de retard. MESURES : pr_m4.py D.
        // RE-ECHANTILLONNAGE (texture() au centre du texel de DESTINATION) et
        // pas copie texel a texel : le lecteur travaille en uv sur [0,1], la
        // destination doit donc couvrir la portee entiere quelle que soit la
        // taille de la source - qu'elle soit plus grande (sous-echantillonnage
        // bilineaire) ou plus petite (sur-echantillonnage).
        // Course benigne : deux fragments qui viseraient le meme texel y
        // ecrivent la MEME valeur (la source ne change pas dans la frame).
        uint vlxRMask = uint(PHYS_REAL_RIPN * PHYS_REAL_RIPN - 1);
        uint vlxRIdx = uint(int(gl_FragCoord.y) * int(viewWidth)
                            + int(gl_FragCoord.x));
#if PHYS_REAL_V2 == 1
        // PHYS_REAL_V2 : 8 texels par fragment au lieu de 4 - un ocean qui
        // couvre 6.3 % d'un ecran 1080p recopie alors TOUTE la carte chaque
        // frame (12.6 % avant), donc plus aucune couture d'age au front des
        // anneaux dans ce regime (mesure pr2_m2.py D3).
        uint vlxRBase = (vlxRIdx * uint(PHYS_REAL_V2_RIPK)
                         + uint(frameCounter) * uint(PHYS_REAL_ROT)) & vlxRMask;
#else
        uint vlxRBase = (vlxRIdx * 4u + uint(frameCounter) * uint(PHYS_REAL_ROT))
                        & vlxRMask;
#endif
#if PHYS_REAL_V2 == 1
        for (int k = 0; k < PHYS_REAL_V2_RIPK; k++) {
#else
        for (int k = 0; k < 4; k++) {
#endif
            int b = int((vlxRBase + uint(k)) & vlxRMask);
            ivec2 dst = ivec2(b & (PHYS_REAL_RIPN - 1), b / PHYS_REAL_RIPN);
            vec2 suv = (vec2(dst) + 0.5) * (1.0 / float(PHYS_REAL_RIPN));
            imageStore(physRipple, dst,
                       vec4(texture(physics_ripples, suv).r, 0.0, 0.0, 0.0));
        }
#if PHYS_REAL_V2 == 1
        // (e) CARTE DE WAVINESS ANCREE MONDE. Un store par fragment ocean (4
        // octets) : c'est ce qui garantit qu'aucune cellule VISIBLE ne reste
        // sans ecriture, meme minuscule a l'ecran. La course "dernier gagne"
        // subsiste DANS la cellule, et c'est tout l'interet : dans 4 blocs la
        // waviness est quasi constante, donc le gagnant n'importe plus (mesure
        // pr2_m2.py D4 : une dispersion intra-cellule de 0.10 n'induit que
        // 0.17-0.39 fois le bruit propre de l'estimateur, contre 0.6-1.2 fois
        // pour la dispersion GLOBALE d'aujourd'hui).
        // RAYON D'ECRITURE : la grille est periodique tous les 512 blocs ; en
        // bornant les ecrivains a 250 blocs autour de la camera, l'empreinte
        // fait 500 blocs et aucune cellule lointaine ne peut se replier sur une
        // cellule proche. Un ocean au-dela de 250 blocs ne publie pas sa
        // waviness - les lecteurs y retombent sur la valeur globale, c'est-a-
        // dire sur le comportement d'avant.
        // ESTAMPILLE : mod(frameCounter, 1024) + 1, donc jamais 0 - 0 est la
        // valeur d'une image jamais ecrite, et le lecteur la refuse.
        vec2 vlxWRel = worldPos.xz - cameraPosition.xz;
        if (dot(vlxWRel, vlxWRel)
            < PHYS_REAL_V2_WAVR * PHYS_REAL_V2_WAVR) {
            imageStore(physWavMap,
                       ivec2(mod(floor(worldPos.xz * (1.0 / PHYS_REAL_V2_WAVC)),
                                 float(PHYS_REAL_V2_WAVN))),
                       vec4(clamp(physics_localWaviness, 0.0, 1.0),
                            mod(float(frameCounter), PHYS_REAL_V2_WAVM) + 1.0,
                            0.0, 0.0));
        }
#endif
#endif
    }
#endif
}
