/* VertaLux - LPV STAGE 2: light-field PROPAGATION (flood) kernel.
   Kept SEPARATE from lib/lpv.glsl because it touches lightImg AND lightImgB and is included ONLY
   by the flood compute passes (composite_a..composite_d). composite5.fsh / lib/lpv.glsl never see
   it, so the consumer side never hits 'undeclared identifier lightImgB'.

   PREREQUISITES (declared by the INCLUDER - the .csh - BEFORE the #include):
     - settings.glsl (LPV_ATTEN, EMISSIVE_LPV, LPV_PASSES) and common.glsl (luma()) included.
     - layout(rgba16f) uniform image3D lightImg ;     // A
     - layout(rgba16f) uniform image3D lightImgB ;    // B
     - #define LPVF_SRC  <lightImg|lightImgB>          // image READ  this pass
     - #define LPVF_DST  <lightImgB|lightImg>          // image WRITTEN this pass
     - #define LPVF_STEP <8|4|2|1>                      // neighbour distance in cells

   WHY SRC/DST MACROS INSTEAD OF AN image3D PARAMETER?
     Passing an image3D as a function parameter without a format qualifier is spec-legal in GLSL
     4.30 but untested on this Iris/driver combination. The macros reference the uniforms directly,
     so there is one shared body and no image-as-parameter. The .csh picks the ping-pong direction
     by (re)defining LPVF_SRC/LPVF_DST.

   ADDRESSING: direct cell indices (no world space). Ping-pong is EXPLICIT and driven by the .csh
   (Iris custom image3D are persistent, never auto-flipped). The FINAL result must land in
   lightImg (A) because sampleLPV in composite5 reads lightImg -> use an EVEN pass count (4).

   ENCODING (same as the composite.csh injection): .rgb = radiance, .a = flag
   (0 EMPTY, 1 SOLID, 2 SOURCE).

   ONE step (= LPVF_STEP) for a cell c:
     - SOLID (a in [0.5,1.5]) -> writes vec4(0,0,0,1): stays solid, blocks, zero radiance.
     - otherwise: best = self.rgb; for each of the 6 axis neighbours at distance LPVF_STEP:
         if IN BOUNDS, neighbour NOT solid, and NO cell on the SEGMENT c..neighbour is solid,
         candidate = neighbour.rgb * pow(LPV_ATTEN, step); keep it when luma(candidate) >
         luma(best). MAX-by-LUMA preserves hue and never over-counts energy - and it is
         WINNER-TAKES-ALL: two sources of different colors never MIX (no yellow between a
         red and a green lamp; each cell holds the single luma winner and the only blending
         is the 1-cell trilinear read). The boundary between two sources sits where their
         attenuated lumas cross, so the higher-luma palette color owns proportionally more
         cells (soul 0.683 vs torch 0.598 -> ~0.5 cell toward the torch). Deliberate:
         genuine mixing would need an energy-normalized accumulation, a different design.
       Writes vec4(best, self.a): the flag is PRESERVED (SOURCE=2 never dies because best starts
       from self.rgb; EMPTY=0 keeps a=0 while its .rgb may rise - sampleLPV only skips
       a in [0.5,1.5], so a lit EMPTY cell is read normally).
     EVERY cell is written every pass (no stale data between A and B). Both images are
     clear=false PERSISTENT and fully rewritten each pass; the forward gbuffers bridge reads the
     field from frame N-1, so do NOT switch them to clear=true - that would kill forward colored
     lights.

   ANTI-LEAK = FULL WALK, not a single midpoint tap: cells t=1..step-1 along the axis are tested
   and the neighbour is REJECTED if any of them is solid. A single-block wall anywhere between c
   and the neighbour blocks propagation even at step=8.

   ===== CL_V2 (MISSION CL2) - ADDITIVE DAMPED DIFFUSION instead of winner-takes-all =====
   Everything above stays the exact CL_V2=0 path. At CL_V2=1 the cell update becomes a
   WEIGHTED SUM (Complementary-style diffusion): air cell = CLV2_KEEP * self
   + CLV2_XFER * LPV_ATTEN^step * (6 face neighbours, same bounds/solid/segment tests as v1)
   [+ at step 1 ONLY: CLV2_XFER * LPV_ATTEN^(step*sqrt(2)) * (12 edge diagonals), each gated
   by "at least one of the two shared FACE neighbours is open" = an air path around the
   corner exists - the corner-leak filter of Complementary's manual trilinear, moved into
   the flood]. Channels sum INDEPENDENTLY: two different-coloured sources genuinely MIX
   (yellow between a red and a green lamp), isophotes lose the v1 hard winner frontier.
   SOURCE cells (a=2) are PINNED to their seed (reseeded by the injection every frame,
   never brightened by neighbours -> bounded); SOLID cells stay forced to zero.
   The field lives in SQUARED space (injection seeds colour^2, readers take sqrt), so this
   linear kernel propagates the dominant hue farther and fronts decode perceptually soft.
   STABILITY (simulated, 49^3, 3x3x3 source cluster, strides 8/4/2/1 + temporal inherit):
   per-frame contraction ~0.44 (stride-1 row sum 2.14 alone, but the 8/4/2 passes damp the
   frame product below 1), field bounded by the seed (max cell = seed, no pumping),
   axial profile monotone, converged in ~8 frames (dRel 3e-4), no oscillation. The
   CLV2_CLAMP min() is a NaN/runaway net only - never reached by a sane field.
   CONVERGENCE vs range: one frame reaches ~15 cells (stride ladder), the temporal
   inheritance (composite.csh keeps air cells) fills the off-axis path combinations the
   4 strides cannot cover in a single frame - full coverage after ~4 frames. */
#ifndef LPV_FLOOD_GLSL
#define LPV_FLOOD_GLSL

const int LPVF_RES = 128;   // MUST equal LPV_RES (lib/lpv.glsl); local copy since lpv.glsl is not included here.

// True when encoded cell L is SOLID (occludes the flood). Same test as sampleLPV (a in [0.5,1.5]).
bool lpvSolid(vec4 L) { return L.a > 0.5 && L.a < 1.5; }

// Full walk along unit axis 'dir' from cell 'c' up to (not including) the neighbour at distance
// 'step': true if any intermediate cell (t = 1 .. step-1) is solid -> wall on the path -> block.
// At step==1 the loop does not run (nothing lies between c and an adjacent neighbour, which is
// tested separately), so step 1 never leaks.
bool lpvSegBlocked(ivec3 c, ivec3 dir, int step) {
    for (int t = 1; t < step; t++) {
        if (lpvSolid(imageLoad(LPVF_SRC, c + dir * t))) return true;
    }
    return false;
}

// Tests ONE axis neighbour (unit direction 'dir') at distance LPVF_STEP. Updates best/bestL by
// MAX-luma when the neighbour is in bounds, non-solid, and the segment is not blocked by a solid.
void lpvFloodDir(ivec3 c, ivec3 dir, float att, inout vec3 best, inout float bestL) {
    ivec3 n = c + dir * LPVF_STEP;
    if (any(lessThan(n, ivec3(0))) || any(greaterThanEqual(n, ivec3(LPVF_RES)))) return; // outside grid
    vec4 L = imageLoad(LPVF_SRC, n);
    if (lpvSolid(L)) return;                          // solid neighbour: no radiance to propagate
    if (lpvSegBlocked(c, dir, LPVF_STEP)) return;     // wall on the segment: blocked (no wall jumping)
    vec3  cand = L.rgb * att;
    float cl   = luma(cand);
    if (cl > bestL) { best = cand; bestL = cl; }
}

#if CL_V2 == 1
// v2 FACE tap: adds the neighbour's contribution (already attenuated) to acc and reports
// whether the direction is OPEN (in bounds, non-solid, segment clear) - the openness feeds
// the edge-diagonal corner gates at step 1. Same three tests as the v1 lpvFloodDir.
vec3 lpvV2Face(ivec3 c, ivec3 dir, float att, out float open) {
    open = 0.0;
    ivec3 n = c + dir * LPVF_STEP;
    if (any(lessThan(n, ivec3(0))) || any(greaterThanEqual(n, ivec3(LPVF_RES)))) return vec3(0.0);
    vec4 L = imageLoad(LPVF_SRC, n);
    if (lpvSolid(L)) return vec3(0.0);
    if (lpvSegBlocked(c, dir, LPVF_STEP)) return vec3(0.0);
    open = 1.0;
    return L.rgb * att;
}

#if LPVF_STEP == 1
// v2 EDGE-diagonal tap (step 1 only): contributes when the diagonal cell is air AND at
// least one of the two shared face neighbours is open (gate = max of their openness) -
// no light around a sealed corner, matches the anti-corner-leak read filter.
vec3 lpvV2Edge(ivec3 c, ivec3 e, float attD, float gate) {
    if (gate < 0.5) return vec3(0.0);
    ivec3 n = c + e;
    if (any(lessThan(n, ivec3(0))) || any(greaterThanEqual(n, ivec3(LPVF_RES)))) return vec3(0.0);
    vec4 L = imageLoad(LPVF_SRC, n);
    if (lpvSolid(L)) return vec3(0.0);
    return L.rgb * attD;
}
#endif
#endif

// ONE flood pass for cell 'c'. Reads LPVF_SRC, writes LPVF_DST, stride = LPVF_STEP.
void lpvFloodCell(ivec3 c) {
    vec4 self = imageLoad(LPVF_SRC, c);

    // SOLID: stays solid with radiance forced to 0 (re-blocks propagation on every pass).
    if (lpvSolid(self)) {
        imageStore(LPVF_DST, c, vec4(0.0, 0.0, 0.0, 1.0));
        return;
    }

#if CL_V2 == 1
    // ===== v2: additive damped diffusion (channels mix), see header block =====
    // SOURCE cells are pinned to their seed: the injection reseeds them every frame and
    // neighbours must never brighten them (boundedness of the whole field).
    if (self.a > 1.5) {
        imageStore(LPVF_DST, c, self);
        return;
    }
    float att = pow(LPV_ATTEN, float(LPVF_STEP)) * CLV2_XFER;
    float oPX, oNX, oPY, oNY, oPZ, oNZ;
    vec3 acc = self.rgb * CLV2_KEEP
             + lpvV2Face(c, ivec3( 1, 0, 0), att, oPX)
             + lpvV2Face(c, ivec3(-1, 0, 0), att, oNX)
             + lpvV2Face(c, ivec3( 0, 1, 0), att, oPY)
             + lpvV2Face(c, ivec3( 0,-1, 0), att, oNY)
             + lpvV2Face(c, ivec3( 0, 0, 1), att, oPZ)
             + lpvV2Face(c, ivec3( 0, 0,-1), att, oNZ);
#if LPVF_STEP == 1
    // 12 edge diagonals at the finest stride only (+12 loads; the corner gates reuse the
    // face openness already computed). Distance sqrt(2) -> LPV_ATTEN^1.41421356.
    float attD = pow(LPV_ATTEN, 1.41421356) * CLV2_XFER;
    acc += lpvV2Edge(c, ivec3( 1, 1, 0), attD, max(oPX, oPY))
         + lpvV2Edge(c, ivec3( 1,-1, 0), attD, max(oPX, oNY))
         + lpvV2Edge(c, ivec3(-1, 1, 0), attD, max(oNX, oPY))
         + lpvV2Edge(c, ivec3(-1,-1, 0), attD, max(oNX, oNY))
         + lpvV2Edge(c, ivec3( 1, 0, 1), attD, max(oPX, oPZ))
         + lpvV2Edge(c, ivec3( 1, 0,-1), attD, max(oPX, oNZ))
         + lpvV2Edge(c, ivec3(-1, 0, 1), attD, max(oNX, oPZ))
         + lpvV2Edge(c, ivec3(-1, 0,-1), attD, max(oNX, oNZ))
         + lpvV2Edge(c, ivec3( 0, 1, 1), attD, max(oPY, oPZ))
         + lpvV2Edge(c, ivec3( 0, 1,-1), attD, max(oPY, oNZ))
         + lpvV2Edge(c, ivec3( 0,-1, 1), attD, max(oNY, oPZ))
         + lpvV2Edge(c, ivec3( 0,-1,-1), attD, max(oNY, oNZ));
#endif
    // Flag preserved (EMPTY=0 with rising rgb, as v1). min() = NaN/runaway net only.
    imageStore(LPVF_DST, c, vec4(min(acc, vec3(CLV2_CLAMP)), self.a));
#else
    vec3  best  = self.rgb;                 // seeded from self -> a SOURCE never loses its radiance
    float bestL = luma(best);
    float att   = pow(LPV_ATTEN, float(LPVF_STEP));  // attenuation over the step distance

    lpvFloodDir(c, ivec3( 1, 0, 0), att, best, bestL);
    lpvFloodDir(c, ivec3(-1, 0, 0), att, best, bestL);
    lpvFloodDir(c, ivec3( 0, 1, 0), att, best, bestL);
    lpvFloodDir(c, ivec3( 0,-1, 0), att, best, bestL);
    lpvFloodDir(c, ivec3( 0, 0, 1), att, best, bestL);
    lpvFloodDir(c, ivec3( 0, 0,-1), att, best, bestL);

    // PRESERVES the .a flag (SOURCE=2 / EMPTY=0). best >= self.rgb in luma, so the field never
    // decays over time on a static scene (frame-to-frame deterministic = no flicker).
    imageStore(LPVF_DST, c, vec4(best, self.a));
#endif
}

// Copies LPVF_SRC->LPVF_DST (pass disabled by LPV_PASSES, or EMISSIVE_LPV=0 fallback): keeps the
// ping-pong PARITY without propagating. Cost = 1 load + 1 store per cell.
void lpvCopyCell(ivec3 c) {
    imageStore(LPVF_DST, c, imageLoad(LPVF_SRC, c));
}

#endif // LPV_FLOOD_GLSL
