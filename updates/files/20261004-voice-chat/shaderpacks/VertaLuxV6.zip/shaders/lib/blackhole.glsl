/*
    VertaLux - END BLACK HOLE (END_BLACKHOLE_ACTIVE, lib/settings.glsl).
    A supermassive black hole replaces the empty spot where the (invisible)
    End sun hangs: shadow, photon ring, gravitationally lensed background and
    a Doppler-beamed, gravitationally redshifted accretion SLAB. Clean-room
    implementation from the Schwarzschild formulas quoted below; no code is
    shared with any other pack.

    REQUIRES (included BEFORE this file by every caller): lib/settings.glsl,
    lib/common.glsl (vnoiseTex), lib/lighting.glsl (shadowLightPosition,
    gbufferModelViewInverse, frameTimeCounter). Included by deferred.fsh,
    prepare.fsh and composite1.fsh, ALWAYS just before lib/sky.glsl.

    ============================ DRAWN ONCE =============================
    AUDIT (why the hole cannot appear twice on one pixel):
      - endBlackHole() has exactly ONE call site in the whole pack:
        skyEndDim() in lib/sky.glsl.
      - skyEndDim() is called from deferred.fsh (the End SKY pixels, depth
        >= 1.0 only) and from getSkyCelestial / getSkyPhysical (lib/sky.glsl),
        which the End branch of getSkyAll forwards to. getSkyAll is a
        REFLECTION path (composite1: water, glass, PBR / SSR fallbacks): it
        runs on SURFACE pixels, never on a sky pixel, so the dome and a
        reflection are never summed into the same fragment.
      - getSkyBase() - the cheap gradient used by every FOG, every cloud base
        and every far reflection - returns dimEndSkyBase(dir) in the End,
        which holds NO black hole term. The fog colour therefore cannot carry
        a second, differently placed copy of the hole.
      - prepare.fsh includes this file only so lib/sky.glsl compiles; its End
        branch bakes the STORM (lib/end_storm.glsl) and never calls skyEndDim,
        so the half-res bake composited by deferred holds no hole either.
      - Everything this file draws lies inside a cone of about
        1.6 x BH_DISK_OUT x theta_s around endBlackHoleDir(): ONE compact body
        at ONE fixed world azimuth. Several bright shapes spread across the
        End sky are the STORM towers of lib/end_storm.glsl, not copies of the
        hole - DEBUG_VIEW 26 false-colours the hole's own contributions
        (RED ring / GREEN lensed far slab / BLUE near slab / MAGENTA shadow)
        so the two can be told apart at a glance.

    GEOMETRY
      The hole sits ON THE SHADOW AXIS. In the End the dimension type pins
      the clock (fixed_time 6000) and this pack ships sunPathRotation -35
      (lib/settings.glsl), so shadowLightPosition is FROZEN at exactly
      90 - 35 = 55.0 deg above the horizon on one constant world azimuth.
      endBlackHoleDir() anchors the hole on
      normalize(mat3(gbufferModelViewInverse) * shadowLightPosition): every
      shadow in the End points exactly away from the black hole, the fog and
      the storm light forward-scatter from the same side (the march light is
      that same axis), and dimEndLight / dimEndAmbient carry the disk colour
      (BLACKHOLE_LIGHT, lib/dimension.glsl). BLACKHOLE_ELEVATION is no longer
      an absolute position but an OFFSET below that anchor: 0 is bit-exact
      on the axis, 1.0 pulls the hole 30 deg lower - back to the old
      25-deg-up framing - at the price of shadows no longer pointing exactly
      away. Nothing depends on where the player looks or stands.
      Apparent shadow radius theta_s = BH_SHADOW_BASE * BLACKHOLE_SIZE, i.e.
      6.1 deg (12.2 deg across) at the 1.75 default. WHY THE DEFAULT IS 0.5
      (hole 40 deg up, 15 deg below the exact shadow axis): at offset 0 the
      hole hangs at 55 deg and NOTHING luminous enters a level FOV-70 frame
      - the slab geometry does reach 26.8 deg below the centre, but that
      band is the tail of the 0.42..1.0 rOut fade and carries ~0.1 % of the
      object's flux (frame max 0.029 HDR, 0.00 % of pixels over 0.5); the
      first bright pixel asks ~14 deg of pitch-up, same as the shadow. At
      0.5 the level frame already holds the bright lower disk (max 15.4
      HDR, 0.49 % of pixels over 0.5) while shadows stay only 15 deg off
      the hole's azimuthal axis - the accepted trade. 0 remains the exact-
      anchoring purist setting.

    LENSING (strong field, the core)
      Write u = theta / theta_s. Because theta_s = (sqrt(27)/2) Rs/D is the
      apparent radius of the CRITICAL impact parameter b_c, u IS b / b_c.
      Two exact limits of the Schwarzschild deflection are known:
        weak field   alpha -> 2 Rs / b = (4/sqrt(27)) / u  [rad]
                     (the 0.76980036 = 4/sqrt(27) of the previous revision)
        photon ring  alpha -> -ln(u - 1) + ln(216 (7 - 4 sqrt3)) - pi,
                     i.e. a LOGARITHMIC divergence with unit coefficient and
                     the constant -0.40009.
      This file uses ONE closed form that reproduces BOTH:
            alpha(u) = ln(1 + A / (u - 1)) + R / u
            A = exp(-0.40009) = 0.67029,   R = 4/sqrt(27) - A = 0.09951
        u -> 1  : -ln(u-1) + ln(A) + R = -ln(u-1) - 0.3006, the strong
                  deflection limit with its constant 0.1 rad high - it errs
                  toward MORE bending, never less.
        u -> oo : (A + R)/u = 0.76980/u, the weak-field law EXACTLY.
      It is monotone, C-infinity on u > 1 and needs no saturation hack: the
      previous revision froze alpha near 0.3 rad, which is why the disk used
      to sit in a flat ring instead of wrapping the shadow. Here alpha reaches
      89 deg at u = 1.2 and 158 deg at u = 1.05, so the sky just outside the
      rim shows what is BEHIND the hole, and the background direction
          bgDir = c cos(beta) + tang sin(beta),   beta = theta - alpha
      wraps through -pi, -2pi ... on its own (cos / sin are periodic): the
      whole cascade of higher-order images falls out of those two lines, with
      no second sampling pass - the BH_SEC_* calibration of the previous
      revision is gone. Only u - 1 is floored (BH_EPS_MIN) to keep the
      wind-up finite; the floor bites 0.35% of theta_s off the rim, well
      inside the shadow's own antialiasing ramp.

    MAGNIFICATION
      Surface brightness is conserved along a ray, so the EXTENDED background
      (gradient, nebula) needs no correction - but a STAR is an unresolved
      point source drawn at a fixed apparent size, so its FLUX must be scaled
      by the lens magnification
          mu = sin(theta) / (|sin(beta)| * dbeta/dtheta)
      with dbeta/dtheta = 1 + (A/((u-1)(u-1+A)) + R/u^2) / theta_s, always
      >= 1 (the map never folds). mu diverges where beta crosses 0: THAT is
      what turns the Einstein ring into a ring of LIGHT instead of a mere
      pile-up of stars, and it is exactly the term the previous revision
      listed as missing. Clamped to BH_MAG_MAX, and the star field to
      BH_STAR_CLAMP. mu also falls as 1/(dbeta/dtheta) toward the rim, which
      demagnifies - and so antialiases - the high-order star images for free.
      The nebula gets the same treatment through bgDetail (a smooth
      BH_DETAIL_K/(dbeta/dtheta)), because an extended texture compressed
      50:1 radially would alias.

    ACCRETION SLAB (this is what gives the 3D)
      NOT a plane any more: a SLAB of half thickness h(r) = BLACKHOLE_THICK * r
      about a world-fixed plane through the centre, inclined from edge-on by
      BLACKHOLE_TILT. The ray crosses it between t_mid -+ h/|dot(d,dn)| and
      BLACKHOLE_STEPS samples are composited FRONT TO BACK with a running
      transmittance, so the near face of the slab really does hide the far
      one, the rim reads as a solid bar seen edge-on instead of a razor line,
      and the grazing path length (capped at BH_PATH_MAX, and fed into the
      optical depth as well so the limb SATURATES) brightens the edge the way
      a real optically thick torus does.
      NEAR / FAR SPLIT. Light from the half of the slab that lies BETWEEN the
      camera and the hole is not lensed at all - and it is not hidden by the
      shadow either. So the slab is marched TWICE:
        - along the LENSED ray, weighted toward the FAR half;
        - along the RAW view ray, weighted toward the NEAR half, and added
          even inside theta_s.
      The weight is a smoothstep on dot(hit, c) - the split of a disk seen
      from outside is a straight diameter, so a straight seam is the right
      answer. The two weights are w and 1 - w of the SAME formula, but each is
      evaluated on its OWN ray (bgDir for the far march, dir for the near
      one), so they only sum to 1 where the two rays coincide - far from the
      hole, where alpha is small and the seam is invisible. Closer in they
      sample two DISTINCT points of the slab along the same line of sight -
      the near arc and the far arc, both physically visible - and the two
      marches are composed by ADDITION: the near arc does not occlude the far
      one. (A true occlusion would weight the far march by the transmittance
      the near march accumulated; at the slab's opacity the difference is
      below the ring's own HDR level, so it is left out.) Near the hole the
      near arc sweeps IN FRONT of the shadow:
      the Gargantua composition the previous revision explicitly could not
      draw ("needs a second, UNLENSED plane intersection kept in front of the
      centre"). BLACKHOLE_FRONT 0 restores the single lensed march over the
      whole slab.

    COLOUR: BLACK BODY + REDSHIFT + BEAMING
      Emitted temperature T(r) = BLACKHOLE_TEMP * (r_in / r)^0.75, the thin
      disc law. The photon then picks up
        gravitational redshift  g_grav = sqrt(1 - Rs/r),
                                r/Rs = r * invS / 0.38490 = r * invS * 2.59806
        Doppler / beaming       g_dop  = 1 / (gamma (1 - beta_los)),
                                beta = 0.5 sqrt(r_in/r) (Keplerian, c/2 at the
                                inner edge - the Schwarzschild value)
      A black body seen through a redshift factor g IS a black body at T*g, so
      colour and beaming collapse into ONE physical statement: the observed
      element is a black body at T_obs = T(r) * g_grav * g_dop, with the
      radiance scaled by g^3 - the SPECIFIC-INTENSITY law from the I_nu/nu^3
      invariant (the bolometric law would be g^4, which blows the HDR budget).
      The inner rim therefore darkens AND reddens on its own - the term most
      imitations miss - while the approaching limb goes blue-white and the
      receding one deep red. vlBlackbody() is Planck's law evaluated at
      600 / 550 / 450 nm and normalised to unit luma, so the ramp is a real
      Planckian locus and the temperature never changes the exposure.

    LIVING SLAB
      Keplerian shear (Omega ~ r^-1.5) carried by a two-layer flow map whose
      raised-cosine weights sum to exactly 1 and vanish with ZERO SLOPE at
      both ends of a BH_SHEAR_PERIOD cycle (3600 s, the frameTimeCounter wrap,
      is an exact multiple of it, so the hourly reset is seamless), two noise
      octaves, a 2-arm LOGARITHMIC SPIRAL density wave rotating at a rigid
      pattern speed (that is what keeps the arms from winding up), and two
      orbiting HOT SPOTS whose angular speeds are the Keplerian speeds of
      their own radii AND exact divisors of the 3600 s wrap (97/3600 and
      41/3600 Hz), so cos/sin of the phase crosses the wrap without a jump.
      All of them are faded by bgDetail and by the grazing-angle guard
      (vnoiseTex has no mip chain).

    INTEGRATION / COST
      Purely additive on the End sky, behind the terrain by construction (only
      depth >= 1.0 pixels reach it) and behind the storm and the haze, which
      are composited over the sky afterwards. Clamped to BH_HDR_CLAMP so TAA
      and bloom stay bounded; everything is a function of the WORLD direction
      and of slow time only - no jitter, no screen-space term, nothing
      TAA-hostile.
      Cost: 2 slab marches of BLACKHOLE_STEPS samples + at most 6 vnoiseTex
      taps per march (the texture is sampled ONCE per march, at the mid
      crossing - the slab is thin enough that the pattern does not move
      across it; the 2 extra taps are the ISCO octave BH_NOISE_C), on End
      sky and End reflection pixels ONLY. END_BLACKHOLE 0 compiles every line
      of this file out.
*/
#ifndef VL_BLACKHOLE_GLSL
#define VL_BLACKHOLE_GLSL

#ifdef END_BLACKHOLE_ACTIVE

// Apparent RADIUS of the shadow at BLACKHOLE_SIZE 1, in radians: 3.5 deg.
// The 1.75 default therefore gives a 6.1 deg radius, 12.2 deg across.
#define BH_SHADOW_BASE 0.061
// Slab extent in shadow radii. 1.45 theta_s is 3.77 Rs, just outside the 3 Rs
// ISCO (and outside the sqrt(1 - Rs/r) singularity): the inner edge now HUGS
// the photon ring the way it does on a real image, instead of floating at the
// 2.6 theta_s of the previous revision. The rim is 4.4, not 6.5: theta_s is
// an ANGLE, so at the 1.75 default size a rim at 6.5 theta_s would put the
// near material 0.3 D from the camera, where it sweeps more than 90 deg of
// sky and buries the End under one solid glow. At 4.4 the bright body spans
// ~34 deg and the lensed arcs ~55 - the Gargantua framing with the sky still
// readable around it.
#define BH_DISK_IN  1.45
#define BH_DISK_OUT 4.4
// Strong-field deflection law alpha(u) = ln(1 + A/(u-1)) + R/u (see header).
#define BH_SDL_A 0.67029
#define BH_WF_R  0.09951
// Floor on u - 1: caps the wind-up at ln(1 + A/eps) = 5.36 rad, i.e. 1.7
// turns. 0.35% of theta_s, inside the shadow's own 1.2% antialiasing ramp.
#define BH_EPS_MIN 0.0035
// Point-source magnification cap, and the clamp on the magnified star field.
// FLICKER BUDGET: skyStars twinkles every star by up to 34% (starLayerV2,
// tw), so a magnified star pulses by 34% of whatever it is scaled to. At 16 a
// floor-brightness star lands around 0.6-1.9 and a bright one saturates
// against BH_STAR_CLAMP - and a star clamped even at the BOTTOM of its
// twinkle does not pulse at all, so the clamp doubles as the flicker guard on
// exactly the stars that would strobe hardest. The ring still sits above
// BLOOM_THRESHOLD (1.5), which is what makes it read as a ring of LIGHT.
#define BH_MAG_MAX    16.0
#define BH_STAR_CLAMP  7.0
// Detail keep factor: 1 while the radial compression dbeta/dtheta <= 6, then
// 6/(dbeta/dtheta). Fades the nebula and the slab texture where the lens
// squeezes the sky faster than the framebuffer can resolve it.
#define BH_DETAIL_K 6.0
// Slab: optical depth per unit density across the crossing, cap on the
// grazing path-length gain, and the vertical profile exp(-VZ (z/h)^2).
#define BH_DISK_TAU 3.2
#define BH_PATH_MAX 3.0
#define BH_DISK_VZ  2.2
// Near / far split of the slab about the diameter perpendicular to the line
// of sight: smoothstep on dot(hit, c). Wide on purpose - the two marches use
// two different rays and only agree far from the hole.
#define BH_SPLIT_LO 0.70
#define BH_SPLIT_HI 1.18
// Keplerian shear flow map: angular speed at the inner edge and the period of
// the two-layer cross-fade (3600 / 1.5 = 2400 exactly, so the
// frameTimeCounter wrap is seamless). At 1.5 s the two half-cycle-apart
// layers are 0.34 rad of differential rotation apart at the inner edge -
// about one cell at the BH_NOISE_A scale, i.e. still CORRELATED: the swap
// reads as continuous shearing instead of a cross-fade between two unrelated
// patterns.
#define BH_SHEAR_PERIOD 1.5
#define BH_OMEGA_IN 0.45
// Noise octaves, in shadow-radius units (so the look is size independent).
// C is the ISCO turbulence: a 2.1x finer octave (finest feature theta_s/14 =
// 0.44 deg at the default size, against theta_s/6.6 = 0.92 deg before)
// confined to the inner orbits (full at the inner edge, gone by 2.6 r_in),
// where the Keplerian shear is strongest - the near-ISCO flow breaks into
// fine filaments while the outer slab keeps its broad cells.
#define BH_NOISE_A 2.2
#define BH_NOISE_B 6.6
#define BH_NOISE_C 14.0
// Logarithmic 2-arm spiral: pitch, and pattern speed in turns per second.
#define BH_SPIRAL_K 2.4
#define BH_SPIRAL_W 0.09
// Hot spots: radius in inner-edge units, frequency (an exact divisor of the
// 3600 s wrap: 97/3600 and 41/3600), phase, amplitude. The radii are the ones
// whose KEPLERIAN speed equals those frequencies at BH_OMEGA_IN.
#define BH_SPOT_A_R 1.9145
#define BH_SPOT_A_F 0.026944
#define BH_SPOT_A_P 0.0
#define BH_SPOT_A_W 1.5
#define BH_SPOT_B_R 3.416
#define BH_SPOT_B_F 0.011389
#define BH_SPOT_B_P 2.1
#define BH_SPOT_B_W 1.1
// HDR levels: photon ring, slab scale, and the bound on the whole feature.
// CALIBRATION (linear HDR, before composite5's exposure and aces(x * 0.6)):
// with no skylight the End sits at the top of the auto-exposure ramp, ~2.7x,
// so a value of 2 tonemaps to white and 0.1 to a dark ember. The reference is
// the storm itself - lib/end_storm.glsl lights its pillars with
// dimEndLight() * 9, i.e. bright faces around 0.5-2. The slab is scaled to
// land in that same band, while the photon ring at 12 sits far above
// everything else and is the only strong bloom source in the End
// (BLOOM_THRESHOLD is 1.5 by default).
// RING 14 (was 12): peak +26% with the wider skirt below - still the only
// strong bloom source in the End and 8 HDR units under BH_HDR_CLAMP.
#define BH_RING_HDR  14.0
#define BH_DISK_HDR   0.60
#define BH_HDR_CLAMP 26.0
// Side selector of endBhSlab: +1 far half, -1 near half, 0 the whole slab.
// With BLACKHOLE_FRONT off there is no near march, so the lensed one takes
// everything and the behaviour is the single-image one.
#if BLACKHOLE_FRONT == 1
#define BH_SIDE_FAR 1.0
#else
#define BH_SIDE_FAR 0.0
#endif
#if BLACKHOLE_JET == 1
// Jet: length and flare of the cone in shadow radii, and its HDR level.
#define BH_JET_LEN   9.0
#define BH_JET_W0    0.10
#define BH_JET_FLARE 0.085
#define BH_JET_HDR   2.6
#endif

// World direction of the hole = THE SHADOW-LIGHT AXIS (header GEOMETRY).
// shadowLightPosition (lib/lighting.glsl) is frozen by fixed_time 6000 +
// sunPathRotation -35 at 55.0 deg of elevation, so the hole stands exactly
// where the light that draws every End shadow comes from. BLACKHOLE_ELEVATION
// is an OFFSET: el = axis - 30 deg x dial. At 0 (default) the vector is
// rebuilt bit-exact (cos(asin(y)) = |xz|, so az * ce == sw.xz); at 1.0 the
// hole hangs 25 deg up, the old framing, and the anchoring is traded away.
// The elevation is clamped to [17, 89] deg so the horizontal component never
// degenerates (the slab basis below is built from it); the azimuth fallback
// only fires if the axis stands at the exact zenith (sunPathRotation 0),
// where it recovers the old End nebula azimuth of lib/dimension.glsl.
vec3 endBlackHoleDir() {
    vec3 sw = normalize(mat3(gbufferModelViewInverse) * shadowLightPosition);
    vec2 az = (dot(sw.xz, sw.xz) > 1e-6) ? normalize(sw.xz) : vec2(0.3846, 0.9231);
    float el = asin(clamp(sw.y, -1.0, 1.0)) - BLACKHOLE_ELEVATION * 0.5236;
    el = clamp(el, 0.30, 1.5533);
    float ce = cos(el);
    return vec3(az.x * ce, sin(el), az.y * ce);
}

// Planck's law at 600 / 550 / 450 nm, normalised to unit luma: the COLOUR of
// a black body at T, with its brightness carried separately. The divisors are
// c2 / lambda (c2 = 14388 um.K) and the numerators lambda^-5, so the channel
// ratios are the real spectral ratios - a Planckian locus, not a hand-painted
// gradient. The exponent is capped at 80 so the cold end cannot overflow a
// mediump float on weaker drivers (with t clamped to >= 1000 the cap never
// actually bites - x peaks at 31.97 - it is a driver-safety belt only).
// The normalisation guard has to sit BELOW the coldest luma this can produce,
// or it stops normalising and starts CRUSHING. Planck's luma at the clamp
// floor of 1000 K is 1.7e-10 (smallest channel 7.1e-13), so 1e-30 keeps every
// observed temperature on the unit-luma locus while still barring a division
// by zero, and stays well clear of float32 denormals (1.2e-38). The old 1e-6
// guard sat AT the luma of 1550 K (1.2e-6): below that - the receding, deep-
// red limb, reached at low BLACKHOLE_TEMP - the colour came back at a
// thousandth of unit luma and rendered black instead of dying-ember red.
vec3 vlBlackbody(float T) {
    float t = clamp(T, 1000.0, 42000.0);
    vec3 x = min(vec3(23980.0, 26160.0, 31973.0) / t, vec3(80.0));
    vec3 b = vec3(12.860, 19.838, 54.191) / (exp(x) - vec3(1.0));
    return b / max(dot(b, vec3(0.2126, 0.7152, 0.0722)), 1e-30);
}

// Radial emission profile of the slab, in units of the inner edge: r^-0.55
// with a soft inner lip and an outer taper from 0.42 rOut (lensing spreads
// the outer orbits over a very wide arc on the limbs, so a late fade would
// wash the sky). The temperature ramp, not this profile, carries the colour.
float endBhProfile(float r, float rIn, float rOut) {
    float rn = r / rIn;
    if (rn <= 1.0) return 0.0;
    return pow(rn, -0.55)
         * smoothstep(0.0, 0.16, rn - 1.0)
         * (1.0 - smoothstep(0.42, 1.0, r / rOut));
}

#if BLACKHOLE_JET == 1
// Optional bipolar jet along +-dn, launched from the centre. Closest approach
// between the view ray (origin, d) and the polar axis line (c, dn), then a
// Gaussian core that flares with the distance travelled and a soft tip fade.
// Additive, cold blue. BLACKHOLE_JET 0 compiles every line of this out.
vec3 endBhJet(vec3 d, vec3 c, vec3 dn, float thS) {
    float b = dot(d, dn);
    float den = 1.0 - b * b;
    if (den < 1e-4) return vec3(0.0);
    float cdj = dot(d, c);
    float dnc = dot(c, dn);
    float sc = (cdj - b * dnc) / den;   // abscissa on the view ray
    if (sc <= 0.0) return vec3(0.0);
    float ac = (b * cdj - dnc) / den;   // abscissa on the jet axis
    float s = abs(ac);
    float len = BH_JET_LEN * thS;
    if (s > len) return vec3(0.0);
    float rr = length(d * sc - (c + dn * ac));
    float w = (BH_JET_W0 + BH_JET_FLARE * s / thS) * thS;
    float core = rr / w;
    float fade = (1.0 - s / len) / (1.0 + 4.0 * s / len);
    return vec3(0.45, 0.72, 1.25) * (exp(-core * core) * fade * BH_JET_HDR);
}
#endif

// ONE crossing of the accretion slab by the ray (camera origin, direction d).
// c = centre (unit vector, distance D = 1), du / dv span the slab plane, dn is
// its normal and dnc = dot(c, dn) = -sin(inclination) < 0, so a crossing in
// front of the camera needs dot(d, dn) < 0 as well. invS = 1 / theta_s (the
// texture rides shadow-radius units, so it keeps its look at every
// BLACKHOLE_SIZE). side: +1 = FAR half, -1 = NEAR half, 0 = whole slab.
// Returns the emission already composited front to back.
vec3 endBhSlab(vec3 d, vec3 c, vec3 du, vec3 dv, vec3 dn, float dnc,
               float rIn, float rOut, float invS, float t, float detail,
               float side) {
    float dd = dot(d, dn);
    if (dd > -1e-3) return vec3(0.0);
    float tMid = dnc / dd;
    if (tMid <= 0.0) return vec3(0.0);
    vec3 rvM = d * tMid - c;
    float rM = length(rvM);
    if (rM <= rIn * 0.55 || rM >= rOut) return vec3(0.0);

    // Near / far partition (header). The two weights sum to exactly 1.
    float fwF = smoothstep(BH_SPLIT_LO, BH_SPLIT_HI, dot(d * tMid, c));
    float fw = (side > 0.5) ? fwF : ((side < -0.5) ? (1.0 - fwF) : 1.0);
    if (fw <= 0.002) return vec3(0.0);

    float h = max(BLACKHOLE_THICK, 0.002) * rM;
    float dtH = h / (-dd);
    // CROSSING BOUNDS, clamped in FRONT of the camera. The camera sits
    // sin(inclination) above the mid plane, so at a nearly edge-on tilt with a
    // thick slab (BLACKHOLE_THICK 0.12+, or any BLACKHOLE_SIZE that pushes the
    // rim past that height) the entry point t_mid - h/|dd| falls BEHIND the
    // eye: the camera is inside the torus. Sampling there would mirror the
    // slab through the origin and paint a ghost. Truncating the interval
    // instead simply drops the material the camera is already inside of.
    float tA = max(tMid - dtH, 1e-4);
    float tB = tMid + dtH;
    if (tB <= tA) return vec3(0.0);
    float dtS = (tB - tA) / float(BLACKHOLE_STEPS);
    // Grazing path-length gain: a ray that skims the slab crosses more
    // material and reads brighter, up to BH_PATH_MAX. The SAME factor goes
    // into the optical depth below, so the limb saturates instead of blowing.
    float pl = min(1.0 / max(-dd, 0.02), BH_PATH_MAX);

    // ---- texture, spiral and hot spots: evaluated ONCE, at the mid crossing.
    vec2 qs = vec2(dot(rvM, du), dot(rvM, dv)) * invS;
    float om = BH_OMEGA_IN * pow(rIn / rM, 1.5) * BH_SHEAR_PERIOD;
    float p0 = fract(t / BH_SHEAR_PERIOD);
    float p1 = fract(t / BH_SHEAR_PERIOD + 0.5);
    float w0 = 0.5 - 0.5 * cos(6.2831853 * p0);
    float a0 = om * p0;
    float a1 = om * p1;
    float c0 = cos(a0);
    float s0 = sin(a0);
    float c1 = cos(a1);
    float s1 = sin(a1);
    vec2 q0 = vec2(c0 * qs.x - s0 * qs.y, s0 * qs.x + c0 * qs.y);
    vec2 q1 = vec2(c1 * qs.x - s1 * qs.y, s1 * qs.x + c1 * qs.y);
    // GRAZING-ANGLE GUARD (poor man's LOD). vnoiseTex is a raw 256^2
    // customTexture with NO mip chain, so nothing filters it when the slab is
    // seen nearly edge-on: |dot(d, dn)| IS the foreshortening of the in-plane
    // lattice along the short axis. detail folds in the lensing compression.
    float sharp = smoothstep(0.02, 0.14, -dd) * detail;
    float tex = mix(vnoiseTex(q1 * BH_NOISE_A + 13.0),
                    vnoiseTex(q0 * BH_NOISE_A + 13.0), w0);
    float wf = 0.30 * sharp;
    tex = tex * (1.0 - wf)
        + mix(vnoiseTex(q1 * BH_NOISE_B + 61.0),
              vnoiseTex(q0 * BH_NOISE_B + 61.0), w0) * wf;
    // ISCO turbulence (BH_NOISE_C): third octave, weighted toward the inner
    // edge only (1 - smoothstep on r/rIn) and by the same sharp/detail guard,
    // so the lens and the grazing angle still antialias it. Every octave has
    // mean 0.5, and this is a convex mix, so tex - and the fil below - keep
    // their exact means: the added definition never moves the exposure.
    float wc = (0.26 * sharp) * (1.0 - smoothstep(1.0, 2.6, rM / rIn));
    tex = tex * (1.0 - wc)
        + mix(vnoiseTex(q1 * BH_NOISE_C + 113.0),
              vnoiseTex(q0 * BH_NOISE_C + 113.0), w0) * wc;
    // Filaments around a mean of exactly 1.0 (vnoiseTex averages 0.5).
    float fil = mix(1.0, 0.30 + 1.40 * tex, sharp);

    // 2-arm logarithmic spiral density wave. BLACKHOLE_SPIRAL 0 leaves fil
    // untouched: mix(1.0, x, 0.0) is exactly 1.0.
    float phi = atan(qs.y, qs.x);
    float sp = 0.5 + 0.5 * cos(2.0 * (phi + BH_SPIRAL_K * log(rM / rIn))
                             - BH_SPIRAL_W * 6.2831853 * t);
    fil *= mix(1.0, 0.60 + 0.85 * sp, BLACKHOLE_SPIRAL * detail);
#if BLACKHOLE_HOTSPOTS == 1
    // Two bright knots orbiting at the Keplerian speed of their own radius.
    // The phase is 2 pi fract(f t + p) with f an exact divisor of the 3600 s
    // frameTimeCounter wrap, so cos/sin of it crosses the wrap continuously.
    float aA = 6.2831853 * fract(t * BH_SPOT_A_F + BH_SPOT_A_P);
    float aB = 6.2831853 * fract(t * BH_SPOT_B_F + BH_SPOT_B_P);
    float dA = phi - aA;
    float dB = phi - aB;
    dA -= 6.2831853 * floor(dA * 0.15915494 + 0.5);
    dB -= 6.2831853 * floor(dB * 0.15915494 + 0.5);
    float eA = (rM - BH_SPOT_A_R * rIn) / (0.28 * BH_SPOT_A_R * rIn);
    float eB = (rM - BH_SPOT_B_R * rIn) / (0.28 * BH_SPOT_B_R * rIn);
    fil += (BH_SPOT_A_W * exp(-dA * dA * 3.0 - eA * eA)
          + BH_SPOT_B_W * exp(-dB * dB * 3.0 - eB * eB)) * detail;
#endif

    // ---- observed black body: T_obs = T(r) * g_grav * g_dop (header).
    float Te = BLACKHOLE_TEMP * pow(rIn / rM, 0.75);
    float rRs = max(rM * invS * 2.59806, 1.05);
    float gGrav = sqrt(max(1.0 - 1.0 / rRs, 0.02));
    float bet = 0.5 * sqrt(rIn / rM);
    vec3 vh = normalize(cross(dn, rvM));
    float bl = bet * dot(vh, -d);
    float gam = sqrt(max(1.0 - bet * bet, 1e-3));   // = 1 / lorentz
    // Doppler factor. The caps 0.30 / 3.00 are SAFETY BOUNDS ONLY, never
    // reached on the emissive range: beta = 0.5*sqrt(rIn/r) <= 0.5 so the
    // raw gam/(1-bl) tops out at sqrt(0.75)/0.5 = 1.732 at DOPPLER 1.0
    // (2.098 at the menu max 1.5). T_obs on the approaching limb at the
    // 7000 K default is ~10.4 kK. Raising these caps is a no-op; beaming
    // legibility lives in the exponent below and in BLACKHOLE_DOPPLER.
    float dop = clamp(gam / max(1.0 - bl, 0.05), 0.30, 3.00);
    dop = mix(1.0, dop, BLACKHOLE_DOPPLER);
    float g = gGrav * dop;
    vec3 col = vlBlackbody(Te * g);
    // Specific intensity: the I_nu / nu^3 invariant. The bolometric law
    // would be g^4; the exponent 3.5 (was 3, half a step toward bolometric)
    // is the beaming-readability dial that actually moves: measured on a
    // 400-ray sweep of the emissive range, approaching/receding limb ratio
    // 27x -> ~47x, peak boost 3.27 -> 3.99 at DOPPLER 1.0 - still under the
    // cap 8 (only a DOPPLER >= 1.5 can reach it) and an order under
    // BH_HDR_CLAMP.
    float boost = clamp(pow(g, 3.5), 0.05, 8.0);

    // ---- front-to-back march across the slab (this is the 3D).
    vec3 em = vec3(0.0);
    float trans = 1.0;
    float invN = 1.0 / float(BLACKHOLE_STEPS);
    for (int k = 0; k < BLACKHOLE_STEPS; k++) {
        float tk = tA + (float(k) + 0.5) * dtS;
        vec3 rv = d * tk - c;
        float z = dot(rv, dn);
        vec3 rp = rv - dn * z;
        float prof = endBhProfile(length(rp), rIn, rOut);
        if (prof > 0.0) {
            float zn = z / h;
            float dens = prof * fil * exp(-BH_DISK_VZ * zn * zn);
            em += col * (boost * trans * dens * fw * pl * invN);
            trans *= exp(-dens * BH_DISK_TAU * pl * invN);
        }
    }
    return em;
}

// MAIN ENTRY (lib/sky.glsl, skyEndDim - the ONE call site, see the audit at
// the top of this file). Returns the ADDITIVE emission of the hole (photon
// ring + far slab through the lens + near slab in front of the shadow) and
// fills:
//   bgDir    the direction the End background must be sampled along,
//   bgW      its weight (0 inside the shadow, 1 outside, narrow AA ramp),
//   bgDetail the high-frequency keep factor (nebula / texture antialiasing),
//   starMul  the POINT-SOURCE weight of the star field: bgW x magnification.
vec3 endBlackHole(vec3 dir, out vec3 bgDir, out float bgW,
                  out float bgDetail, out float starMul) {
    vec3 c = endBlackHoleDir();
    float cd = clamp(dot(dir, c), -1.0, 1.0);
    float theta = acos(cd);
    float thS = BH_SHADOW_BASE * BLACKHOLE_SIZE;
    float invS = 1.0 / thS;

    bgDir = dir;
    bgW = smoothstep(thS * 0.988, thS * 1.012, theta);
    bgDetail = 1.0;
    starMul = 0.0;

    // Slab frame: world-fixed plane through the centre, inclined from edge-on
    // by BLACKHOLE_TILT (2.4 deg at 0 -> 60 deg at 1; the floor keeps the
    // plane from collapsing to a line). The normal is tipped TOWARD the
    // camera, so we look at the slab slightly from above.
    vec3 du = normalize(cross(vec3(0.0, 1.0, 0.0), c));
    vec3 iu = cross(c, du);
    float inc = (0.04 + 0.96 * BLACKHOLE_TILT) * 1.0471976;
    float si = sin(inc);
    vec3 dn = iu * cos(inc) - c * si;
    vec3 dv = cross(dn, du);
    float dnc = -si;

    float rIn = BH_DISK_IN * thS;
    float rOut = BH_DISK_OUT * thS;
    float diskK = BH_DISK_HDR * BLACKHOLE_DISK_BRIGHT;

    // FOREGROUND: the near half of the slab lies BETWEEN camera and hole, so
    // it is not lensed and the shadow does not hide it. Marched along the RAW
    // view ray and added even inside theta_s - this is the arc that sweeps in
    // FRONT of the black disc.
    vec3 fg = vec3(0.0);
#if BLACKHOLE_FRONT == 1
    fg = endBhSlab(dir, c, du, dv, dn, dnc, rIn, rOut, invS,
                   frameTimeCounter, 1.0, -1.0) * diskK;
#endif

    // SHADOW: no background, no ring, no far slab - only what passes in front.
    if (bgW <= 0.0) return min(fg, vec3(BH_HDR_CLAMP));

    // Tangent of the great circle (dir, centre), pointing AWAY from the
    // centre. theta >= theta_s > 0 here, so the subtraction never cancels;
    // the fallback only guards against exact colinearity.
    vec3 tang = dir - c * cd;
    float tl = length(tang);
    tang = (tl > 1e-5) ? tang / tl : normalize(cross(c, vec3(0.0, 0.0, 1.0)));

    // STRONG-FIELD DEFLECTION (header): alpha(u) = ln(1 + A/(u-1)) + R/u.
    // ANTIPODE: exactly opposite the hole the tangent above is undefined (any
    // great circle passes through both poles), so a radial map has to pinch
    // there. The deflection is faded out over the last 14 deg before the
    // antipode; alpha is only 0.9 deg at that distance, so the whole pinch is
    // a sub-degree smear inside a cap on the far side of the sky. The fade
    // makes alpha DECREASE faster with theta, so dbeta/dtheta only grows: the
    // map cannot fold and cannot make a ghost image (dbA below drops that
    // extra positive term, which makes the magnification a safe over-estimate
    // by at most 10% inside that cap). dbA is an over-estimate on the OTHER
    // side too, in the thin annulus u < 1 + BH_EPS_MIN where the eps floor
    // pins alpha to a constant: the true dbeta/dtheta is 1 there, while dadu
    // is still evaluated at eps = BH_EPS_MIN and reports ~284. Both errors
    // land on the safe side (magnification and detail-keep only shrink), and
    // the annulus sits under the photon ring, whose own HDR level swamps the
    // background it dims. Everywhere else dbA is exact.
    float u = theta * invS;
    float eps = max(u - 1.0, BH_EPS_MIN);
    float anti = smoothstep(3.14159265, 2.90, theta);
    float alpha = (log(1.0 + BH_SDL_A / eps) + BH_WF_R / u) * anti;
    float bA = theta - alpha;
    // cos / sin are periodic, so bA sweeping past -pi, -2pi ... walks the
    // background around the sphere on its own: THAT is the cascade of
    // higher-order images, with no second sampling pass.
    bgDir = c * cos(bA) + tang * sin(bA);

    // Jacobian of the radial map, the point-source magnification and the
    // detail-keep factor (header).
    float dadu = BH_SDL_A / (eps * (eps + BH_SDL_A)) + BH_WF_R / (u * u);
    float dbA = 1.0 + dadu * invS * anti;
    starMul = bgW * clamp(sin(theta) / max(abs(sin(bA)) * dbA, 1e-4),
                          0.0, BH_MAG_MAX);
    bgDetail = clamp(BH_DETAIL_K / dbA, 0.0, 1.0);

    // PHOTON RING: the UNRESOLVED pile-up of every image of order >= 2 (the
    // log law crams them into a 3%-of-theta_s annulus, far below one pixel),
    // drawn analytically as a thin white-blue line just outside the rim plus
    // a soft skirt. composite5's bloom turns it into a crisp halo.
    // PRESENCE PASS: core width 0.034 (was 0.030, +13% - reads at distance
    // without smearing), skirt 0.24 x exp(-5.5 |u-1.03|) against the old
    // 0.14 x exp(-7 |u-1.03|): the glow at 1.3 theta_s goes 0.25 -> 0.76 HDR
    // (3x) and the peak 13.5 -> 17.0 (+26%), all under BH_HDR_CLAMP 26 and
    // still the End's only strong source above BLOOM_THRESHOLD (1.5).
    float rd = (u - 1.012) / 0.034;
    float ring = exp(-rd * rd) + 0.24 * exp(-abs(u - 1.03) * 5.5);
    vec3 em = vec3(0.82, 0.90, 1.06) * (ring * BH_RING_HDR);

    // FAR half of the slab, seen through the lens.
    em += endBhSlab(bgDir, c, du, dv, dn, dnc, rIn, rOut, invS,
                    frameTimeCounter, bgDetail, BH_SIDE_FAR) * diskK;

#if BLACKHOLE_JET == 1
    em += endBhJet(dir, c, dn, thS);
#endif

    return min(em * bgW + fg, vec3(BH_HDR_CLAMP));
}

#if DEBUG_VIEW == 26
// DEBUG_VIEW 26 (deferred.fsh, End sky pixels): false colours the hole's OWN
// contributions so "is it drawn more than once?" is a two-second check.
//   RED     photon ring
//   GREEN   far half of the slab, seen through the lens
//   BLUE    near half of the slab, unlensed, in front of the shadow
//   MAGENTA inside the shadow
//   grey    the lensed background, dimmed to 8% so the storm and the terrain
//           stay readable next to it - anything bright that is NOT neon here
//           is the END STORM, not the black hole.
// Compiled ONLY at DEBUG_VIEW 26; not one instruction otherwise.
vec3 endBlackHoleDebug(vec3 dir) {
    vec3 c = endBlackHoleDir();
    float cd = clamp(dot(dir, c), -1.0, 1.0);
    float theta = acos(cd);
    float thS = BH_SHADOW_BASE * BLACKHOLE_SIZE;
    float invS = 1.0 / thS;
    float bgW = smoothstep(thS * 0.988, thS * 1.012, theta);

    vec3 du = normalize(cross(vec3(0.0, 1.0, 0.0), c));
    vec3 iu = cross(c, du);
    float inc = (0.04 + 0.96 * BLACKHOLE_TILT) * 1.0471976;
    float si = sin(inc);
    vec3 dn = iu * cos(inc) - c * si;
    vec3 dv = cross(dn, du);
    float rIn = BH_DISK_IN * thS;
    float rOut = BH_DISK_OUT * thS;

    float near = 0.0;
#if BLACKHOLE_FRONT == 1
    near = length(endBhSlab(dir, c, du, dv, dn, -si, rIn, rOut, invS,
                            frameTimeCounter, 1.0, -1.0)) * BH_DISK_HDR;
#endif
    if (bgW <= 0.0) return vec3(0.30, 0.0, 0.30) + vec3(0.0, 0.0, min(near, 1.0));

    vec3 tang = dir - c * cd;
    float tl = length(tang);
    tang = (tl > 1e-5) ? tang / tl : normalize(cross(c, vec3(0.0, 0.0, 1.0)));
    float u = theta * invS;
    float eps = max(u - 1.0, BH_EPS_MIN);
    float anti = smoothstep(3.14159265, 2.90, theta);
    float alpha = (log(1.0 + BH_SDL_A / eps) + BH_WF_R / u) * anti;
    float bA = theta - alpha;
    vec3 bgDir = c * cos(bA) + tang * sin(bA);
    float dadu = BH_SDL_A / (eps * (eps + BH_SDL_A)) + BH_WF_R / (u * u);
    float dbA = 1.0 + dadu * invS * anti;
    float rd = (u - 1.012) / 0.034;
    float ring = exp(-rd * rd) + 0.24 * exp(-abs(u - 1.03) * 5.5);
    float far = length(endBhSlab(bgDir, c, du, dv, dn, -si, rIn, rOut, invS,
                                 frameTimeCounter, clamp(BH_DETAIL_K / dbA, 0.0, 1.0),
                                 BH_SIDE_FAR)) * BH_DISK_HDR;
    return vec3(min(ring * 3.0, 1.0), min(far, 1.0), min(near, 1.0))
         + vec3(0.05, 0.04, 0.09) * bgW;
}
#endif

#endif // END_BLACKHOLE_ACTIVE

#endif // VL_BLACKHOLE_GLSL
