#version 430 compatibility
/* VertaLux - LPV STAGE 2, FLOOD pass 4/4 (step 1).  PING-PONG: B(lightImgB) -> A(lightImg).
   LAST pass: the result lands in A(lightImg), which is what sampleLPV (composite5) reads.
   The EVEN parity (4 files, A->B->A->B->A) guarantees that return to A with no extra copy,
   whether c/d flood (LPV_PASSES>=4) or copy (LPV_PASSES==2) - a copy keeps the same direction as
   the flood it replaces, so parity is unchanged.
   At step==1 lpvSegBlocked does not loop (nothing lies between c and an adjacent neighbour), so
   this pass is strictly leak-proof: only the immediate neighbour is tested and its solid flag
   blocks it directly.
   Gate: EMISSIVE_LPV=0 OR LPV_PASSES<4 -> copy B->A (parity no-op).
   CL_V3=1: dead code, compiled out entirely (see composite_a.csh header). */
#include "/lib/settings.glsl"
#include "/lib/common.glsl"

layout(local_size_x = 8, local_size_y = 8, local_size_z = 8) in;
const ivec3 workGroups = ivec3(16, 16, 16);

layout(rgba16f) uniform image3D lightImg;     // A
layout(rgba16f) uniform image3D lightImgB;    // B

#define LPVF_SRC  lightImgB                     // reads B
#define LPVF_DST  lightImg                      // writes A
#define LPVF_STEP 1
#include "/lib/lpv_flood.glsl"

void main() {
#if EMISSIVE_LPV == 0
    return; // LPV chain disabled -> no work at all
#endif
    ivec3 c = ivec3(gl_GlobalInvocationID);
    if (any(greaterThanEqual(c, ivec3(LPVF_RES)))) return;
#if EMISSIVE_LPV == 1 && CL_V3 == 0 && LPV_PASSES >= 4
    lpvFloodCell(c);    // B -> A, step 1
#elif EMISSIVE_LPV == 1 && CL_V3 == 0
    lpvCopyCell(c);     // parity: B -> A without propagating
#endif
}
