#version 120
/* Entities (fragment): forward shading + entity damage/hurt flash.
   Writes: colortex0 = shaded color, colortex1 = normal, colortex2 = lightmap + smoothness,
   colortex5 = raw albedo (or shadow debug). */

#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/distort.glsl"
#include "/lib/biome.glsl"
#include "/lib/dimension.glsl"
#include "/lib/lighting.glsl"

uniform sampler2D gtexture;
uniform vec4 entityColor;
#ifdef PBR_TEXTURES
    uniform sampler2D normals;
    uniform sampler2D specular; // labPBR _s map (Iris supplies it for entities too; all-zero default without a pack)
#endif

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 normal;
varying vec4 tangent;
varying vec3 viewPos;

void main() {
    vec4 col = texture2D(gtexture, texcoord) * glcolor;
    if (col.a < 0.1) discard;
    col.rgb = mix(col.rgb, entityColor.rgb, entityColor.a);

    vec3 albedo = toLinear(col.rgb);
    float dither = bayer8(gl_FragCoord.xy);

    vec3 nrm = normalize(normal);
    #ifdef PBR_TEXTURES
    {
        vec2 nXY = texture2D(normals, texcoord).xy * 2.0 - 1.0;
        nXY *= NORMAL_STRENGTH;
        float nZ = sqrt(clamp(1.0 - dot(nXY, nXY), 0.0, 1.0));
        vec3 tang = normalize(tangent.xyz);
        vec3 bitang = cross(nrm, tang) * sign(tangent.w);
        nrm = normalize(tang * nXY.x + bitang * nXY.y + nrm * nZ);
    }
    #endif
    vec3 color = shadeSurface(albedo, nrm, lmcoord, viewPos, dither, 0.0);

/* DRAWBUFFERS:0125 */
    gl_FragData[0] = vec4(color, 1.0); // alpha forced to 1: no residual blending from entity alpha (matches gbuffers_hand)
    gl_FragData[1] = vec4(nrm * 0.5 + 0.5, 1.0);
    // colortex2.a = SMOOTHNESS (0 = matte). NEVER a non-zero constant here
    // (a constant once turned the player into a full mirror). Only valid
    // source: the resource pack's specular map, same labPBR convention and
    // same gate as gbuffers_terrain. Without a PBR pack Iris binds an all-zero
    // default specular texture -> stays exactly 0.0 (matte, legacy behavior;
    // terrain already relies on that same default, see settings.glsl JALON 7b).
    // Blended layers are handled by blend.gbuffers_entities.colortex2=off in
    // shaders.properties.
    float smoothness = 0.0;
    #if defined PBR_TEXTURES && (defined RT_REFLECTIONS || defined PBR_REFLECTIONS)
        smoothness = texture2D(specular, texcoord).r; // labPBR perceptual smoothness (armor reflections)
    #endif
    gl_FragData[2] = vec4(lmcoord, 0.02, smoothness); // 0.02 entity flag unchanged
#if DEBUG_VIEW == 21
    // Debug: shadow factor received by the entity (raw PCF luma). Same colortex5
    // transport as gbuffers_terrain, read by final.fsh view 21.
    gl_FragData[3] = vec4(vec3(luma(getShadow(viewPos, nrm, dither))), 1.0);
#elif DEBUG_VIEW == 22
    gl_FragData[3] = vec4(debugShadowClassify(viewPos, nrm), 1.0);
#else
    gl_FragData[3] = vec4(col.rgb, 1.0);
#endif
}
