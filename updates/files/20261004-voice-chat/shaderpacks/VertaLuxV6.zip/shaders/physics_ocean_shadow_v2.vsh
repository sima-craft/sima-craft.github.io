#version 430 compatibility
/* PHYSICS MOD PRO - programme ombre de l'ocean (vertex).
   Mecanisme officiel du mod (voir physics_ocean_v2.vsh) : compile par le mod
   via Iris comme programme "physics_ocean_shadow" quand son ocean est actif ;
   l'ombre portee de l'ocean suit alors les vagues simulees (meme deplacement
   vertex que physics_ocean_v2.vsh). SANS le mod, Iris ignore ce fichier.
   Meme corps que shadow.vsh. */

#define VLX_PHYSICS_OCEAN_PROGRAM

#include "/lib/program_shadow_vertex.glsl"
