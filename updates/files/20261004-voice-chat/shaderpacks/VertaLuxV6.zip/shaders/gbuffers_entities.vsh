#version 120
/* Entities (vertex). Passes normal + tangent for PBR normal mapping. */

#include "/lib/settings.glsl"
#include "/lib/common.glsl"

attribute vec4 at_tangent;

uniform int frameCounter;   // drives the TAA jitter sequence
uniform float viewWidth;
uniform float viewHeight;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 normal;
varying vec4 tangent;
varying vec3 viewPos;

void main() {
    vec4 pos = gl_ModelViewMatrix * gl_Vertex;
    viewPos = pos.xyz;
    gl_Position = gl_ProjectionMatrix * pos;
    #ifdef TAA
        // TAAU: jitter measured in RENDER BUFFER texels (see gbuffers_terrain.vsh).
        gl_Position.xy += taaJitterNDC(frameCounter) * TAA_JITTER * gl_Position.w * vec2(2.0 / (viewWidth * TAAU_S), 2.0 / (viewHeight * TAAU_S));
    #endif
    // TAAU: bottom-left sub-rect mapping, AFTER the jitter (see gbuffers_terrain.vsh).
    // At TAAU_S = 1.0 this folds away at compile time (no-op).
    gl_Position.xy = gl_Position.xy * TAAU_S + gl_Position.w * (TAAU_S - 1.0);

    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord  = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    glcolor  = gl_Color;
    normal   = normalize(gl_NormalMatrix * gl_Normal);
    tangent  = vec4(normalize(gl_NormalMatrix * at_tangent.xyz), at_tangent.w);
}
