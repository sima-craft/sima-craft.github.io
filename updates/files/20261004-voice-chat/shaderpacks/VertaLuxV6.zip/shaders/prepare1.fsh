#version 120
/*
    prepare1: TEMPORAL RESOLVE of the half-res cloud bake (CLOUD_TEMPORAL=1,
    needs CLOUD_HALF_RES=1). prepare.fsh marched this frame's clouds with a
    reduced budget (VC_SAMPLES_EFF = ceil 0.6 x VC_SAMPLES, start offset
    interleaved over 4 frames) into the lower-left quadrant of colortex15 and
    carried the PREVIOUS resolved quadrant into the unused upper-right area
    (lib/cloud_temporal.glsl). This pass rebuilds the resolved quadrant:
      result  = mix(history, current, a); both sides are the premultiplied
                (rgb, coverage) pair, so the mix is direct;
      history = the previous resolved texel this cloud point projected to:
                the sky ray is anchored on the mid-slab plane y = VC_BASE +
                VC_THICK/2 (capped at VC_RENDER_DISTANCE; half that range
                when the ray never reaches the plane or the camera sits
                inside the slab), moved to the PREVIOUS camera
                (previousCameraPosition, gbufferPreviousModelView /
                Projection: the reprojection reference of composite4's TAA)
                and mapped to quadrant texels with deferred's convention
                (framebuffer uv x 0.5 + a quarter texel, TAAU sub-rect
                included). A static camera lands exactly on its own texel;
                rotation is exact, translation parallax ~ shift / distance;
      a       = 0.18 when the history lands inside last frame's quadrant
                (the tap is then clamped into the copied band, so the edge
                texels without a copy of their own borrow their neighbour's
                history), 1.0 otherwise (off-screen, behind the camera);
      anti-ghosting: the history is clamped per channel (rgb AND coverage)
                into the min/max box of the 3x3 CURRENT neighbourhood
                (texel-center taps, clamped to the written region), widened
                by 10% of its extent.
    CT_V2 (settings.glsl, out of menu, default 1; 0 = the three numbers above
    are the shipped ones and this pass is VERBATIM): a single anchor plane
    cannot stand in for a 160-block-thick slab, so instead of trusting it
    equally always, the blend leaves 0.18 in proportion to how little the
    reprojection deserves it -- (a) by this texel's own SCREEN velocity
    (prevUV and the current position are both already here, so the measure is
    per-texel and exact, rotation and translation alike; every frame of
    rotation costs the history one more bilinear resample and at 82% retention
    it accumulates about five), and (b) by PLANE COHERENCE, the distance
    between the anchored reprojection and the rotation-only one of the same
    ray: identically zero under pure rotation, so it isolates exactly the
    parallax the single plane can get wrong. The 3x3 box also widens by
    CT_V2_EXT instead of 10% (the box is built on a bake that holds a fraction
    of the samples: it is already wider than the signal). Figures at the code.
    Edge cases: first frame, resolution change, TAAU_RENDER_SCALE change,
    return from the Nether/End - the history is garbage or misaligned, but
    the clamp bounds it to the current neighbourhood and the 0.18 blend
    washes the residue out in ~6 frames (0.82^6 = 30% of a difference that
    is itself at most 10% of the local extent): no explicit reset needed.
    Above the clouds the plane hit must be in front of the camera (t > 0);
    looking up from there falls back to the fixed distance. Clouds in front
    of terrain (composite1) and the inline deferred path keep the full
    VC_SAMPLES march and never touch this pass.
    Why a second pass: the resolve needs the 3x3 neighbourhood of the CURRENT
    bake, which only exists once prepare.fsh has finished.
    END_STORM_PREPARE: in the End the same resolve runs on the storm bake of
    prepare.fsh, the sky ray anchored by endStormRepDistance (lib/dimension.
    glsl: ~180 blocks inside the storm band) instead of the cumulus plane.
    CLOUD_TEMPORAL=0: prepare.fsh is the legacy single-pass bake and this
    pass reduces to an exact texel copy of its quadrant (Iris flips colortex15
    once per pass whatever is written; without the copy deferred would read
    the never-written side). The texels deferred reads are bit-identical to
    the legacy pipeline.
    CLOUD_HALF_RES=0: every fragment discards (dead pass, like prepare).
*/

#include "/lib/settings.glsl"
#include "/lib/common.glsl"
// Declares fogColor (VL_FOGCOLOR_DECL) + dimNether()/dimEnd(): the dimension
// test below must be the SAME as prepare.fsh / deferred.fsh.
#include "/lib/dimension.glsl"
#if CLOUD_TEMPORAL == 1
#include "/lib/cloud_temporal.glsl"
#endif

// RENDERTARGETS kept UNGATED (same reasoning as prepare.fsh): the per-pass
// flip must always hit colortex15 and nothing else.
/* RENDERTARGETS: 15 */

uniform sampler2D colortex15;
uniform float viewWidth;
uniform float viewHeight;
// Reprojection / dimension-test uniforms, declared OUT of the gate on purpose
// (harmless when unused): no gated declaration can strand a later use.
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform mat4 gbufferPreviousModelView;
uniform mat4 gbufferPreviousProjection;
uniform vec3 cameraPosition;
uniform vec3 previousCameraPosition;
uniform vec3 skyColor;
// fogColor: declared by lib/dimension.glsl (VL_FOGCOLOR_DECL guard).
uniform ivec2 eyeBrightnessSmooth;

varying vec2 uv;

#if CLOUD_TEMPORAL == 1
// Representative cloud distance of a sky ray: its hit on the mid-slab plane,
// capped at VC_RENDER_DISTANCE (nothing is marched further). Half the range
// when the ray never reaches the plane in front of the camera (looking down
// from below it, up from above it) or when the camera is inside the slab:
// still exact under rotation, approximate under translation.
float ctRepDistance(vec3 dir) {
    // VC_RDIST_EFF (lib/settings.glsl): the VC2 textured path extends the
    // march range x1.5, so this reprojection anchor cap must follow or the
    // far cloud arc would anchor on a too-near plane (edge ghosting).
    // == VC_RENDER_DISTANCE token for token at VC2=0 / on the fallbacks.
    float tRep = VC_RDIST_EFF * 0.5;
    bool inSlab = cameraPosition.y >= VC_BASE && cameraPosition.y <= VC_BASE + VC_THICK;
    if (!inSlab && abs(dir.y) > 1e-4) {
#if CT_ANCHOR == 1
        // Le plan d'ancrage doit etre celui de la SURFACE VISIBLE, pas le
        // milieu geometrique de la dalle : c'est lui que la reprojection
        // suppose immobile, et toute erreur de plan va chercher l'historique
        // au mauvais endroit de l'ecran - on recolte alors le nuage VOISIN
        // (le "je vois les nuages derriere les nuages" du rapport).
        // MESURE (vc33_anchor.py, hauteur ou la transmittance accumulee tombe
        // a 0.5, rayons tires du sol sur le vrai champ) : la surface visible
        // est a la fraction 0.121 de la dalle (y ~ 229), PAS 0.500 (y = 290).
        // 60 blocs d'erreur - et 0.062 avant VC32, donc le defaut est ANCIEN :
        // VC32 l'a seulement rendu voyant en donnant du volume et du contraste
        // aux nuages (l'etalement p25-p75 est passe de 0.046-0.087 a
        // 0.054-0.304, ce qu'un plan unique represente forcement moins bien).
        // Vu d'AU-DESSUS, un rayon descendant rencontre d'abord les DOMES :
        // fraction haute, deduite de la distribution mesuree des hauteurs de
        // colonne (p90 = 138 / 160 = 0.86, moins l'epaule du dome) et NON
        // mesuree directement - la sonde de descente n'etait pas valide.
        float aFrac = (dir.y > 0.0) ? CT_ANCHOR_LOW : CT_ANCHOR_HIGH;
        float tP = (VC_BASE + aFrac * VC_THICK - cameraPosition.y) / dir.y;
#else
        float tP = (VC_BASE + 0.5 * VC_THICK - cameraPosition.y) / dir.y;
#endif
        if (tP > 0.0) tRep = min(tP, VC_RDIST_EFF);
    }
    return tRep;
}
#endif

void main() {
#ifdef CLOUD_PREPARE_ACTIVE
    vec2 res = vec2(viewWidth, viewHeight);
    vec2 pix = 1.0 / res;
    // Written region = prepare's (lower-left quadrant + 2-texel guard band),
    // same expression so both passes agree texel by texel.
    if (uv.x > 0.5 * TAAU_S + 2.0 * pix.x || uv.y > 0.5 * TAAU_S + 2.0 * pix.y) discard;
    vec2 fc = floor(gl_FragCoord.xy); // this quadrant texel
    vec2 tc = (fc + 0.5) * pix;       // its center: exact texel fetch
#if CLOUD_TEMPORAL == 1
    // Dimension detection: EXACT copy of prepare.fsh / deferred.fsh, so the
    // three programs always take the same branch (no stale-texel use).
#if DIMENSION_FX == 1
    // DIMENSION_FX: Iris biome uniforms (lib/dimension.glsl) - the Nether /
    // End early-out, same test as prepare.fsh / deferred.fsh.
    bool overworld = (dimNether() < 0.5 && dimEnd() < 0.5);
#elif DIM_DETECT_FIX == 1
    bool overworld = eyeBrightnessSmooth.y > 8
                  || luma(skyColor) > 0.004
                  || fogColor.g >= fogColor.r;
#else
    bool overworld = luma(skyColor) > 0.004 || fogColor.g > fogColor.r;
#endif
#ifdef END_STORM_PREPARE
    // END_STORM_PREPARE: the End storm bake of prepare.fsh is resolved here
    // too (same gate as prepare.fsh), anchored on the storm distance.
    bool endStorm = (!overworld && dimEnd() > 0.5);
    if (!overworld && !endStorm) discard;
#else
    if (!overworld) discard;
#endif

#if PERF_CAVE_SKIP == 1
    // PERF_CAVE_SKIP (mirror of prepare.fsh): prepare marched nothing this
    // frame, so this resolve would reproject stale onto stale for texels
    // nobody samples (deferred reads the quadrant on sky pixels only,
    // inexistent in a fully enclosed cave). Both passes discarding keeps the
    // ping-pong parity trivially (the per-pass flip is static, both sides
    // freeze); cave-exit recovery is the header's garbage-history case (3x3
    // clamp on the fresh raw + 0.18 blend, a = 1.0 off-quadrant). Same
    // 'overworld &&' guard: the End (y == 0 permanently) must keep resolving
    // the storm bake. The CLOUD_TEMPORAL == 0 copy branch below is left
    // untouched on purpose: it is a 1-tap flip-parity copy with no dimension
    // context of its own - skipping it would buy nothing measurable.
    if (overworld && eyeBrightnessSmooth.y == 0) discard;
#endif

    vec2 G = ctGuard(res);
    vec4 cur = texture2D(colortex15, tc); // this frame's raw bake (premultiplied rgb, coverage)
    // 3x3 min/max box of the CURRENT bake (texel-center taps clamped to the
    // written region), widened by 10% of its extent plus a tiny absolute
    // floor so a uniform neighbourhood (clear sky) tolerates float dust.
    vec4 bMin = cur;
    vec4 bMax = cur;
    for (int ox = -1; ox <= 1; ox++) {
        for (int oy = -1; oy <= 1; oy++) {
            if (ox == 0 && oy == 0) continue;
            vec2 nc = clamp(fc + vec2(float(ox), float(oy)), vec2(0.0), G);
            vec4 n = texture2D(colortex15, (nc + 0.5) * pix);
            bMin = min(bMin, n);
            bMax = max(bMax, n);
        }
    }
#if CT_V2 == 1
    // CT_V2 : 10 % etait large pour une boite deja batie sur un bake qui n'a
    // qu'une fraction des echantillons (marche reduite + depart interleave sur
    // 4 images) : le voisinage 3x3 du bake courant est donc DEJA plus etale que
    // le signal, et l'elargir encore de 10 % laissait passer un historique
    // franchement faux. Le plancher absolu 0.002 (poussiere flottante sur un
    // ciel uniforme) est conserve tel quel.
    vec4 ext = (bMax - bMin) * CT_V2_EXT + 0.002;
#else
    vec4 ext = (bMax - bMin) * 0.10 + 0.002;
#endif
    bMin -= ext;
    bMax += ext;

    // Same sky ray as prepare.fsh: full-res pixel 2*fc, TAAU sub-rect mapping.
    vec2 uvFull = (fc * 2.0 + 0.5) * pix;
    vec4 ndc = vec4(uvFull / TAAU_S, 1.0, 1.0) * 2.0 - 1.0;
    vec4 vw = gbufferProjectionInverse * ndc;
    vec3 worldDir = normalize(mat3(gbufferModelViewInverse) * (vw.xyz / vw.w));
#ifdef END_STORM_PREPARE
    // Storm anchor in the End (lib/dimension.glsl), mid-slab plane otherwise.
    float tRep = endStorm ? endStormRepDistance(worldDir, cameraPosition) : ctRepDistance(worldDir);
#else
    float tRep = ctRepDistance(worldDir);
#endif
    vec3 wp = cameraPosition + worldDir * tRep; // absolute world point
    // Previous-frame clip position of that point (TAA reference, composite4).
    vec4 prevClip = gbufferPreviousProjection
                  * (gbufferPreviousModelView * vec4(wp - previousCameraPosition, 1.0));
    vec4 hist = cur;
    float a = 1.0;
    if (prevClip.w > 0.001) {
        vec2 prevUV = (prevClip.xy / prevClip.w) * 0.5 + 0.5; // visible screen [0,1]
        // visible uv -> sub-rect framebuffer pixel -> quadrant texel units
        // (quadrant texel i = full-res pixel 2i, center at i + 0.5).
        vec2 p = prevUV * TAAU_S * res * 0.5 + 0.25;
        vec2 C = ctCopyMax(res);
        // Valid iff the point was inside the read-back quadrant last frame
        // (texel centers 0.5 .. X - 0.5, half a texel of slack each side).
        // The tap is then clamped into the copied band [1.5, C + 0.5] of
        // lib/cloud_temporal.glsl: the one or two edge texels that have no
        // copy of their own borrow their neighbour's history (bounded by the
        // box below) instead of dropping to the raw march. A static camera
        // lands on its own center (interior) or on 1.5 / C + 0.5 (edges) up
        // to fp32 rounding; the stray bilinear weight this lets in (<= 1e-3,
        // on finite data) is far below anything visible.
        vec2 X = 0.5 * TAAU_S * res;
        if (p.x >= 0.0 && p.y >= 0.0 && p.x < X.x && p.y < X.y) {
            p = clamp(p, vec2(1.5), C + 0.5);
            // History copy lives at + G (lib/cloud_temporal.glsl), bilinear.
            hist = texture2D(colortex15, (p + G) * pix);
            // min/max rather than clamp(): also swallows a NaN from an
            // uninitialised first-frame buffer on IEEE minNum/maxNum hardware.
            hist = min(max(hist, bMin), bMax);
            a = 0.18;
#if CT_V2 == 1
            // ---- CT_V2 : deux garde-fous sur le poids de l'historique ------
            // Le plan d'ancrage unique ne peut pas representer une dalle de
            // nuages de 160 blocs d'epaisseur : des que la reprojection est
            // douteuse, mieux vaut le bruit d'interleave du bake courant que le
            // fantome d'un nuage voisin. Le blend passe donc de 0.18 (camera
            // posee, comportement livre EXACT) vers 1.0 selon :
            //  (a) la VITESSE ECRAN de ce texel, mesuree ici meme -- prevUV et
            //      la position courante sont toutes deux a portee de main, donc
            //      la mesure est per-texel et EXACTE (rotation ET translation),
            //      pas une vitesse angulaire globale. A chaque image de
            //      rotation l'historique subit un reechantillonnage bilineaire
            //      de plus ; a 82 % d'historique il en accumule ~5, ce qui
            //      liquefie la couche demi-res des qu'on tourne la tete.
            //  (b) la COHERENCE DE PLAN : on compare la reprojection ancree a
            //      la reprojection "ciel infini" (rotation pure) du meme rayon.
            //      Sous rotation pure les deux coincident exactement et ce
            //      terme est nul -- il ne mesure QUE la part parallaxe, c'est-
            //      a-dire exactement l'erreur que le plan d'ancrage unique peut
            //      commettre. Plus elle est grande, moins l'historique vaut.
            // MESURES (modele de chaine, scratchpad cl_pick.py), erreur du
            // BAKE RESOLU contre l'anticrenelage exact / energie de fantome :
            //   camera posee       0.1190 -> 0.1137   88.9 % -> 88.9 % (inchange :
            //                      a reste 0.18 au texel pres, seul CT_V2_EXT joue)
            //   20 deg/s           0.1072 -> 0.0779   66.7 % -> 52.3 %
            //   60 deg/s           0.1047 -> 0.0537   33.3 % -> 13.0 %
            //   140 deg/s          0.1049 -> 0.0537   13.9 % ->  5.2 %
            //   marche 5 blocs/s   0.0891 -> 0.0875   70.9 % -> 71.0 %
            //   45 deg/s + marche  0.0711 -> 0.0524   27.8 % -> 15.9 %
            // et la ou la parallaxe passe enfin le plancher de bruit, (b) :
            //   vol 40 blocs/s     0.1146 -> 0.0648   54.2 % -> 33.8 %
            // A la MARCHE (5 blocs/s) la parallaxe ne vaut que ~0.14 px/image a
            // 250 blocs, SOUS le plancher de bruit fp32 de wp -
            // previousCameraPosition loin de l'origine (~0.2 px) : la zone morte
            // CT_V2_COH_PX0 rend donc (b) inerte a la marche -- c'est voulu,
            // l'alternative etant de prendre du bruit de virgule flottante pour
            // de la parallaxe. (b) sert au VOL, ou le plan unique est le plus faux.
            // Prix : scintillement +6 a +18 % selon le cas (le bruit
            // d'interleave que le blend laisse repasser), assume.
            // POURQUOI PAS UNE ANCRE PAR TEXEL (la solution structurelle) :
            // colortex15 est RGBA16F et ses QUATRE canaux sont pris par le bake
            // (rgb premultiplie + couverture) ; la distance d'accumulation
            // devrait etre ECRITE par prepare.fsh, seul endroit ou elle existe.
            // Aucun canal libre, aucune cible libre -> hors de portee de cette
            // passe. C'est (a) + (b) qui bornent le defaut a la place.
            vec2 nowUV = uvFull / TAAU_S;               // uv visible de ce rayon
            float dPix = length((prevUV - nowUV) * TAAU_S * res);   // px pleine res
            float aV = mix(0.18, CT_V2_BLEND_HI, smoothstep(CT_V2_V0, CT_V2_V1, dPix));
            // mat3 only, so the point rides with the camera: pure rotation, and
            // the projection of a direction is scale free, so normalising it to
            // one block changes no NDC. Under pure rotation prevClip above uses
            // wp - previousCameraPosition == worldDir * tRep, the SAME ray, so
            // dCoh is exactly zero and this term cannot fire.
            vec4 prevClipInf = gbufferPreviousProjection
                             * vec4(mat3(gbufferPreviousModelView) * worldDir, 1.0);
            if (prevClipInf.w > 0.001) {
                vec2 prevUVinf = (prevClipInf.xy / prevClipInf.w) * 0.5 + 0.5;
                float dCoh = length((prevUV - prevUVinf) * TAAU_S * res);
                aV = mix(aV, 1.0, smoothstep(CT_V2_COH_PX0, CT_V2_COH_PX1, dCoh)
                                * CT_V2_COH_W);
            }
            a = aV;
#endif
        }
    }
    vec4 resolved = mix(hist, cur, a);
    // Premultiplied contract of the bake: rgb >= 0, coverage <= 1 (the 10%
    // box widening can only be exceeded by a garbage history).
    resolved = max(resolved, 0.0);
    resolved.a = min(resolved.a, 1.0);
    gl_FragData[0] = resolved;
#else
    // CLOUD_TEMPORAL=0: exact copy of prepare's quadrant (flip parity, see
    // the header). Bit-identical texels for deferred.
    gl_FragData[0] = texture2D(colortex15, tc);
#endif
#else
    // CLOUD_HALF_RES=0 (or no cloud layer): dead pass, nothing written.
    discard;
#endif
}
