#version 430 compatibility
/* Shadow pass (vertex) + voxelisation CL_V3. CORPS PARTAGE : tout le programme
   vit dans /lib/program_shadow_vertex.glsl (details et notes fail-closed
   la-bas), compile une seconde fois par physics_ocean_shadow_v2.vsh (ombre de
   l'ocean PHYSICS MOD PRO - PHYSICS_MOD_SUPPORT, lib/settings.glsl).
   Ici : chemin normal, aucun bloc PHYSICS_OCEAN actif. */

#include "/lib/program_shadow_vertex.glsl"
