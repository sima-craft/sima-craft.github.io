#version 120
/*
    deferred1 - PERF_DEFERRED (LOT C piece 2, lib/settings.glsl) : le shading
    du TERRAIN opaque, paye UNE fois par pixel VISIBLE au lieu d'une fois par
    fragment rasterise (l'overdraw feuillage/cutout payait shadeSurface 2-3x).
    ORDRE IRIS : apres "deferred" (le ciel - qui PRESERVE l'alpha-drapeau a
    gate actif) et avant les translucides (gbuffers_water). ATTENTION main :
    contrairement a l'intuition, la main SOLIDE est dessinee AVANT les passes
    deferred (bytecode MixinLevelRenderer : HandRenderer.renderSolid() puis
    beginTranslucents() ; seule la main translucide vient apres) - ses pixels
    EXISTENT donc ici, et ne sont proteges du re-shading QUE par l'alpha 1.0
    force de gbuffers_hand.fsh (l'invariant de securite est CE fichier-la,
    pas l'ordre de dessin). composite.fsh / composite1.fsh lisent ensuite
    colortex0 avec EXACTEMENT la meme semantique qu'avant : couleur HDR shadee.
    PING-PONG : les passes deferred/composite lisent la copie "front" et
    ecrivent la copie "back" de chaque buffer de leur DRAWBUFFERS, flippee
    apres la passe (c'est ce qui permet a deferred.fsh de lire ET ecrire
    colortex0). CONSEQUENCE : cette passe doit ECRIRE CHAQUE pixel - un
    discard laisserait au pixel le contenu PERIME du back-buffer (le ciel de
    deferred.fsh vit dans l'autre copie). Le passthrough est donc une COPIE
    exacte, jamais un discard.
    ENTREES (aucun nouveau colortex - cartographie au bloc PERF_DEFERRED de
    lib/settings.glsl) :
      colortex0.rgb = albedo LINEAIRE (x teinte biome x AO vanilla), ecrit par
                      gbuffers_terrain a gate 1 ; .a = drapeau :
                        < 0.05  -> terrain differe (0.02 = feuillage/subsurface)
                        >= 0.05 -> pixel deja shade (forward / ciel) ->
                                   passthrough exact de colortex0.
      colortex1.rgb = normale vue (*0.5+0.5, RGB16 - la meme que le forward,
                      normal map labPBR comprise).
      colortex2.rg  = lightmap (RGBA8 : quantifiee 1/255, ecart documente au
                      gate). .b (bandes matiere) et .a (smoothness) NON lus,
                      NON reecrits : composite/composite1 les recoivent tels
                      que les gbuffers les ont poses.
      depthtex0     = profondeur -> position vue reconstruite via
                      gbufferProjectionInverse (meme patron TAAU que
                      deferred.fsh / composite1).
    Le shading appelle LE MEME shadeSurface de lib/lighting.glsl ("un seul
    site", zero duplication) : PCSS/SHADOW_V2, cloudShadow (desormais 1 eval
    par pixel visible), LPV/CL, Nether/End, tout suit lighting.glsl.
    A PERF_DEFERRED=0 (ou chemin FPT actif) : la passe compile en passthrough
    trivial - UNE copie plein ecran de colortex0 (lecture + ecriture RGBA16F,
    ~0.05-0.1 ms selon la resolution), incompressible a cause du ping-pong
    ci-dessus et parce qu'Iris ne sait pas desactiver un programme par une
    option a VALEUR hors menu. C'est la limite du rollback, assumee et
    documentee au gate PERF_DEFERRED.
*/

#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/distort.glsl"
#include "/lib/biome.glsl"
#include "/lib/dimension.glsl"
#include "/lib/lighting.glsl"

uniform sampler2D colortex0;
#ifdef VLX_DEFERRED_ACTIVE
uniform sampler2D colortex1;
uniform sampler2D colortex2;
uniform sampler2D depthtex0;
uniform mat4 gbufferProjectionInverse;
#ifdef TAA
// BUG B (ombres qui clignotent) : entrees de la compensation du jitter TAA
// (voir le bloc dans main()). Gate #ifdef TAA : miroir exact du gate du vsh
// gbuffers_terrain.vsh qui APPLIQUE le jitter - pas de jitter ecrit, pas de
// jitter a retirer. taaJitterNDC / TAA_JITTER / TAAU_S viennent de
// lib/common.glsl + lib/settings.glsl (deja inclus).
// Guarded : lib/lighting.glsl declare frameCounter sous SHADOW_V2 avec le
// meme guard (un uniform duplique est une erreur GLSL) - meme patron que
// deferred.fsh / composite.fsh.
#ifndef VL_FRAMECOUNTER_DECL
#define VL_FRAMECOUNTER_DECL
uniform int frameCounter;
#endif
uniform float viewWidth;
uniform float viewHeight;
#endif
#endif

varying vec2 uv;

/* DRAWBUFFERS:0 */
void main() {
#ifndef VLX_DEFERRED_ACTIVE
    // Gate 0 / FPT : passthrough trivial (voir l'en-tete - le ping-pong des
    // passes deferred interdit le discard, la copie est le cout residuel).
    gl_FragData[0] = texture2D(colortex0, uv);
#else
    vec4 c0 = texture2D(colortex0, uv);
    float d0 = texture2D(depthtex0, uv).r;
    // Drapeau (voir gbuffers_terrain.fsh) : < 0.05 = terrain differe. Le test
    // d0 < 1.0 est la ceinture-bretelles (texel jamais ecrit par la geometrie:
    // rien de testable - le ciel, lui, arrive deja etiquete aKeep = 1.0).
    if (c0.a < 0.05 && d0 < 1.0) {
        // Position vue reconstruite - MEME patron TAAU que deferred.fsh
        // (sub-rect [0..TAAU_S] -> ecran visible avant NDC).
        vec4 ndc = vec4(uv / TAAU_S, d0, 1.0) * 2.0 - 1.0;
#ifdef TAA
        // BUG B (ombres qui clignotent) : le depth buffer est rasterise avec
        // le jitter TAA des vsh gbuffers (gbuffers_terrain.vsh:71,
        // gl_Position.xy += taaJitterNDC(frameCounter) * TAA_JITTER * w *
        // vec2(2/(vW*TAAU_S), 2/(vH*TAAU_S))). Le ndc ci-dessus est donc le
        // NDC JITTERE du fragment ; unprojeter par l'inverse NON jitteree
        // faisait trembler la position monde d'un sous-texel d'ecran PAR FRAME
        // -> la recherche de bloqueurs / penombre PCSS sautait de texel shadow
        // map en texel -> bords d'ombre qui clignotent (le forward avait le
        // viewPos exact du vertex, pas ce probleme). On retire LE MEME offset
        // AVANT l'unprojection : meme fonction, meme frameCounter, meme frame
        // => meme valeur ; += a l'ecriture => -= a la lecture ; le terme du
        // vsh est en clip (x w), divise par w au raster il vaut exactement
        // ceci en NDC. viewPos redevient LE point rasterise sur ce texel
        // (l'equivalent exact du viewPos forward, module la quantification du
        // depth), stable dans le temps. A TAA_JITTER 0.0 : no-op des deux
        // cotes (gate par multiplication, jamais #if sur un float).
        ndc.xy -= taaJitterNDC(frameCounter) * TAA_JITTER * vec2(2.0 / (viewWidth * TAAU_S), 2.0 / (viewHeight * TAAU_S));
#endif
        vec4 vw = gbufferProjectionInverse * ndc;
        vec3 viewPos = vw.xyz / vw.w;
        vec3 nrm = normalize(texture2D(colortex1, uv).rgb * 2.0 - 1.0);
        vec2 lm = texture2D(colortex2, uv).rg;
        float subsurface = (c0.a > 0.01) ? 1.0 : 0.0; // 0.02 = feuillage
        float dither = bayer8(gl_FragCoord.xy);       // meme dither que le forward
        vec3 color = shadeSurface(c0.rgb, nrm, lm, viewPos, dither, subsurface);
        // Meme alpha final que l'ecriture historique de deferred.fsh (1.0) ;
        // composite1 reecrit de toute facon vec4(color, 1.0) en aval.
        gl_FragData[0] = vec4(color, 1.0);
    } else {
        // Pixel deja shade (entites, main future, emissifs forward, ciel,
        // DH...) : PASSTHROUGH EXACT - copie, pas discard (ping-pong).
        gl_FragData[0] = c0;
    }
#endif
}
