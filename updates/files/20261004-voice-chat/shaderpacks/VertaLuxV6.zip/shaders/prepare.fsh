#version 120
/*
    prepare: HALF-RES CLOUD PASS (CLOUD_HALF_RES=1).
    Runs BEFORE the gbuffers (Iris prepare stage), so no frame depth exists
    yet - and none is needed: the whole Overworld cloud chain (cirrus / 2D
    alto sheet, volumetric 3D alto, 22-deg halo, rainbow, volumetric cumulus)
    depends only on the view RAY, never on scene geometry.
    Lower-left quadrant of colortex15, GI_HALF_RES / VL_HALF_RES convention:
    1 quadrant texel = 1 full-res pixel at uv*2, rays built with the SAME
    uv -> NDC mapping as deferred.fsh (TAAU sub-rect factor included), so a
    stored texel carries exactly the ray deferred would have marched for its
    even pixel. The layers are folded in deferred's exact order into ONE
    PREMULTIPLIED pair (rgb = over-operator sum, a = total coverage):
    deferred rebuilds the whole sequential mix() chain with a single
    color = rgb + color*(1-a), and premultiplied color survives the bilinear
    upsample without dark fringes at cloud edges. The VC_SAMPLES cumulus
    march (+ alto + cirrus) is paid on ~1/4 of the pixels -> cloud cost / ~4
    on sky-dominated frames; the trade-off is that sky hidden behind terrain
    is baked too (this pass cannot depth-test), so cave/indoor frames pay a
    small fixed cost the inline path did not.
    CLOUD_HALF_RES=0 (or every cloud layer off): every fragment discards and
    deferred.fsh keeps its original inline evaluation - bit-identical output.
    CLOUD_TEMPORAL=1 (temporal bake): this pass becomes the RAW half of a
    two-pass chain. The cumulus is marched with VC_SAMPLES_EFF steps (ceil
    0.6 x VC_SAMPLES) whose start is interleaved over 4 frames, phase rotated
    per texel (lib/clouds.glsl, CLOUD_TEMPORAL_MARCH), and the texels right/
    above the guard
    band receive an exact copy of the PREVIOUS resolved quadrant (colortex15
    main, written by prepare1.fsh last frame) shifted by the guard bound G,
    so that prepare1.fsh - which can only read what this pass wrote (Iris
    main/alt ping-pong) - finds both the raw march and the history on the
    same side. prepare1.fsh reprojects, clamps and blends them back into the
    lower-left quadrant for deferred. Layout: lib/cloud_temporal.glsl.
    CLOUD_TEMPORAL=0: the legacy single-pass bake above, byte for byte.
    END_STORM_PREPARE (DIMENSION_FX + END_STORM on this half-res pass): in
    the End the pass no longer discards but bakes the volumetric storm of
    lib/end_storm.glsl into the same quadrant (same premultiplied contract,
    same temporal interleave); prepare1 resolves it on its own reprojection
    anchor and deferred composes it over the End sky with the same taps.
*/

#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/distort.glsl"
#include "/lib/biome.glsl"
#include "/lib/dimension.glsl"
#include "/lib/lighting.glsl"
#include "/lib/atmosphere.glsl"
#include "/lib/blackhole.glsl"
#include "/lib/sky.glsl"
#if CLOUD_TEMPORAL == 1
// Temporal bake: the cumulus march of lib/clouds.glsl takes VC_SAMPLES_EFF
// steps with the 4-frame interleave (resolved by prepare1.fsh).
#define CLOUD_TEMPORAL_MARCH
#include "/lib/cloud_temporal.glsl"
#endif
#include "/lib/clouds.glsl"
#include "/lib/end_storm.glsl"

// === CLOUD_HALF_RES buffer -- Iris directives parsed INSIDE the /* */ block.
//     DO NOT UNCOMMENT. colortex15 = (premultiplied cloud rgb, coverage),
//     lower-left quadrant texels only. Clear=false: the used quadrant is
//     fully rewritten every Overworld frame and read back the SAME frame
//     (prepare -> deferred), so clearing would be pure cost; with
//     CLOUD_TEMPORAL=1 it is also the frame-to-frame history (never clear).
//     NB: Iris's const scanner is line-by-line and may ignore this #if; that
//     is harmless -- with the gate off the buffer stays unreferenced (the
//     deferred sampler is gated), same contract as the composite.fsh
//     VL_HALF_RES block.
#ifdef CLOUD_PREPARE_ACTIVE
/*
const int  colortex15Format = RGBA16F;
const bool colortex15Clear  = false;
*/
#endif

// RENDERTARGETS kept UNGATED on purpose: with the gate off this pass discards
// every fragment, and a pass whose target list vanished would fall back to
// Iris defaults (several LIVE buffers) -- their flip without a write would
// hand stale content to the rest of the frame. Cost when the gate is off:
// colortex15 stays allocated, nothing else.
/* RENDERTARGETS: 15 */

uniform mat4 gbufferProjectionInverse;
uniform vec3 skyColor;
uniform ivec2 eyeBrightnessSmooth;
// Guarded: lib/lighting.glsl declares frameCounter under SHADOW_V2 with the
// same guard (a duplicate uniform is a GLSL error).
#ifndef VL_FRAMECOUNTER_DECL
#define VL_FRAMECOUNTER_DECL
uniform int frameCounter; // blue-noise slice index (BLUE_NOISE=1)
#endif
uniform float viewWidth;
uniform float viewHeight;
uniform int isEyeInWater; // SUN_HALO / RAINBOW_V2 gate, same as deferred.fsh
#if CLOUD_TEMPORAL == 1
// Previous frame (Iris reads the un-flipped side here): the resolved
// quadrant written by prepare1.fsh, carried into this pass's output.
uniform sampler2D colortex15;
#endif

varying vec2 uv;

void main() {
#ifdef CLOUD_PREPARE_ACTIVE
    vec2 pix = 1.0 / vec2(viewWidth, viewHeight);
#if CLOUD_TEMPORAL == 1
    {
        // History carry (CLOUD_TEMPORAL): texels right/above the guard band
        // receive an exact texel-center copy of the PREVIOUS resolved quadrant
        // (colortex15 main, prepare1.fsh) shifted by G, so the resolve reads it
        // on the alt side next to this frame's raw march (layout and bounds:
        // lib/cloud_temporal.glsl). Decided before the quadrant discard below
        // and in every dimension: 1 tap, only ever sampled where the bake is
        // live (Overworld clouds, End storm under END_STORM_PREPARE).
        vec2 fc = floor(gl_FragCoord.xy);
        vec2 res = vec2(viewWidth, viewHeight);
        vec2 G = ctGuard(res);
        vec2 C = ctCopyMax(res);
        if (fc.x > G.x && fc.y > G.y && fc.x <= G.x + C.x && fc.y <= G.y + C.y) {
            gl_FragData[0] = texture2D(colortex15, (fc - G + 0.5) * pix);
            return;
        }
    }
#endif
    // Lower-left quadrant only. With TAAU the sky lives in the [0..TAAU_S]
    // sub-rect, so only [0 .. TAAU_S/2] of the quadrant is ever read back:
    // keep a 2-texel margin (guard band for the bilinear clamp in deferred)
    // and skip the rest. Folds to the plain 0.5 bound at TAAU_S = 1.0.
    if (uv.x > 0.5 * TAAU_S + 2.0 * pix.x || uv.y > 0.5 * TAAU_S + 2.0 * pix.y) discard;

    // Dimension detection: EXACT copy of deferred.fsh (same uniforms, same
    // frame -> both programs always take the same branch). Clouds are
    // Overworld-only; deferred never reads this buffer elsewhere, so the
    // stale texels a discard leaves behind are never sampled.
    // END_STORM_PREPARE: the End keeps the pass alive and bakes the storm
    // (lib/end_storm.glsl) into the same premultiplied quadrant instead of
    // the cumulus chain, resolved by prepare1 and composed by deferred with
    // the very same taps.
#if DIMENSION_FX == 1
    // DIMENSION_FX: Iris biome uniforms (lib/dimension.glsl) - the Nether /
    // End early-out, same test as deferred.fsh.
    bool overworld = (dimNether() < 0.5 && dimEnd() < 0.5);
#elif DIM_DETECT_FIX == 1
    bool overworld = eyeBrightnessSmooth.y > 8
                  || luma(skyColor) > 0.004
                  || fogColor.g >= fogColor.r;
#else
    bool overworld = luma(skyColor) > 0.004 || fogColor.g > fogColor.r;
#endif
#ifdef END_STORM_PREPARE
    bool endStorm = (!overworld && dimEnd() > 0.5);
    if (!overworld && !endStorm) discard;
#else
    if (!overworld) discard;
#endif

#if PERF_CAVE_SKIP == 1
    // PERF_CAVE_SKIP: eye TOTALLY enclosed (smoothed skylight exactly 0) ->
    // discard BEFORE any ray setup or march. Contract and caveats:
    //   . colortex15 keeps its stale content (clear=false; the per-pass flip
    //     still happens - RENDERTARGETS is ungated, see above - so BOTH
    //     ping-pong sides simply freeze, main and alt alike). deferred only
    //     samples the quadrant on sky pixels (d0 >= 1.0), which do not exist
    //     in a fully enclosed cave, so the stale texels are never read. The
    //     one residual: a long unlit tunnel whose view line still reaches sky
    //     would compose a FROZEN cloud bake on those few pixels until
    //     eyeBrightnessSmooth.y rises above 0 near the opening.
    //   . prepare1.fsh mirrors this early-out (CLOUD_TEMPORAL parity: with
    //     BOTH passes discarding, the two sides stay frozen together). On
    //     cave EXIT the resume is the already-documented garbage-history
    //     case of prepare1 (its header: first frame / dimension return): the
    //     stale history is clamped into the 3x3 min/max box of the FRESH raw
    //     march and the 0.18 blend washes the residue out in ~6 frames, and
    //     an off-quadrant reprojection takes a = 1.0 (pure fresh) anyway.
    //   . 'overworld &&' is REQUIRED: the End has eyeBrightnessSmooth.y == 0
    //     permanently (no skylight there), so a bare test would kill the
    //     END_STORM_PREPARE bake. The Nether never reaches this line.
    //   . The CLOUD_TEMPORAL history-carry copy above still runs (1 tap on
    //     the carry band): nothing reads it while both passes discard, and
    //     gating it too would buy nothing measurable against the march.
    if (overworld && eyeBrightnessSmooth.y == 0) discard;
#endif

    // 1 quadrant texel = 1 full-res pixel at uv*2 (GI/VL half-res convention),
    // then the SAME uv -> NDC mapping as deferred.fsh at d0 = 1.0 (sky ray).
    vec2 uvFull = (floor(gl_FragCoord.xy) * 2.0 + 0.5) * pix;
    vec4 ndc = vec4(uvFull / TAAU_S, 1.0, 1.0) * 2.0 - 1.0;
    vec4 vw = gbufferProjectionInverse * ndc;
    vec3 worldDir = normalize(mat3(gbufferModelViewInverse) * (vw.xyz / vw.w));
    vec3 sunW = normalize(mat3(gbufferModelViewInverse) * sunPosition);
    vec3 lightW = normalize(mat3(gbufferModelViewInverse) * shadowLightPosition);
#if BLUE_NOISE == 1
    // Blue-noise march jitter (TAA-averaged), as in deferred. The pattern is
    // half-res here; the bilinear upsample spreads it and TAA still averages
    // it into smooth gradients.
    float dither = blueDither(gl_FragCoord.xy, frameCounter);
#else
    float dither = bayer8(gl_FragCoord.xy);
#endif

#ifdef END_STORM_PREPARE
    if (endStorm) {
        // END STORM bake (lib/end_storm.glsl): same ray, same premultiplied
        // (rgb, coverage) contract and, under CLOUD_TEMPORAL, the same
        // per-texel 4-frame phase rotation as the cumulus below. Real time:
        // the End world clock is frozen.
        float frameOffE = 0.0;
#if CLOUD_TEMPORAL == 1
        ivec2 fciE = ivec2(floor(gl_FragCoord.xy));
        int phaseE = frameCounter + fciE.x + 2 * fciE.y;
        frameOffE = float(phaseE - (phaseE / 4) * 4);
#endif
        vec4 st = endStormMarch(cameraPosition, worldDir, lightW, dither, frameTimeCounter, 1.0e9, frameOffE);
        gl_FragData[0] = vec4(st.rgb * st.a, st.a);
        return;
    }
#endif

    // Premultiplied back-to-front folding of deferred's exact layer chain:
    // per layer, mix(color, L.rgb, L.a) == the final accP + (1-accA)*color.
    vec3 accP  = vec3(0.0); // premultiplied cloud color
    float accA = 0.0;       // total coverage

#if defined CLOUD_LAYER_ALTO || defined CLOUD_LAYER_CIRRUS
    {
        vec4 hc = highClouds(cameraPosition, worldDir, sunW, cloudWorldTime()); // world time (cirrus + 2D alto)
        accP = hc.rgb * hc.a + accP * (1.0 - hc.a);
        accA = hc.a + accA * (1.0 - hc.a);
    }
#endif

    // Second volumetric layer: 3D altocumulus (same order as deferred)
#if defined CLOUD_LAYER_ALTO && ALTO_VOLUMETRIC == 1
    {
        vec4 av = volumetricAlto(cameraPosition, worldDir, lightW, dither, cloudWorldTime()); // world time (3D alto)
        accP = av.rgb * av.a + accP * (1.0 - av.a);
        accA = av.a + accA * (1.0 - av.a);
    }
#endif

    // 22-degree halo (SUN_HALO), same slot as deferred (after the high
    // layers, before the cumulus). Its x0.96 inner dimming is a BLACK layer of
    // alpha (1 - haloDark) folded over the sum: accP*f + sky*(1 - accA*f -
    // (1-f)) = f*(accP + sky*(1-accA)), exactly deferred's color*f; the
    // ring itself is additive.
#if SUN_HALO == 1 && (defined CLOUD_LAYER_ALTO || defined CLOUD_LAYER_CIRRUS)
    if (isEyeInWater == 0) {
        float haloDark = 1.0;
        vec3 halo = skyHalo22(cameraPosition, worldDir, sunW, cloudWorldTime(), haloDark); // world time (veil fields)
        accP = accP * haloDark + halo;
        accA = accA * haloDark + (1.0 - haloDark);
    }
#endif

    // Rainbow (RAINBOW_V2): same fold as the halo (Alexander's band = black
    // layer, bows additive), same slot as deferred.
#if defined RAINBOW && RAINBOW_V2 == 1
    if (isEyeInWater == 0) {
        float rbDark = 1.0;
        vec3 rb = skyRainbow(worldDir, sunW, rbDark);
        accP = accP * rbDark + rb;
        accA = accA * rbDark + (1.0 - rbDark);
    }
#endif

    // Rainbow: additive in deferred BETWEEN alto and cumulus. Adding it to
    // the premultiplied sum (coverage untouched) reproduces that order
    // exactly: still in front of cirrus/alto, still dimmed by cumulus alpha.
#if RAINBOW_V2 == 0 // legacy bow, replaced by skyRainbow above at 1
#ifdef RAINBOW
    {
        float wetGlow = wetness * (1.0 - rainStrength)
                      * smoothstep(0.05, 0.3, sunW.y);
        if (wetGlow > 0.01) {
            float a = acos(clamp(dot(worldDir, -sunW), -1.0, 1.0));
            float pos = (a - 0.709) / 0.048;
            if (pos > -0.2 && pos < 1.2) {
                float band = smoothstep(0.0, 0.18, pos) * smoothstep(1.0, 0.82, pos);
                vec3 rb = clamp(vec3(smoothstep(0.45, 0.80, pos),
                                     exp(-pow((pos - 0.5) * 3.0, 2.0)),
                                     smoothstep(0.55, 0.20, pos)), 0.0, 1.0);
                accP += rb * band * 0.30 * wetGlow;
            }
            float pos2 = (a - 0.873) / 0.060;
            if (pos2 > -0.2 && pos2 < 1.2) {
                float band2 = smoothstep(0.0, 0.18, pos2) * smoothstep(1.0, 0.82, pos2);
                vec3 rb2 = clamp(vec3(smoothstep(0.55, 0.20, pos2),
                                      exp(-pow((pos2 - 0.5) * 3.0, 2.0)),
                                      smoothstep(0.45, 0.80, pos2)), 0.0, 1.0);
                accP += rb2 * band2 * 0.10 * wetGlow;
            }
        }
    }
#endif
#endif // RAINBOW_V2 == 0

#ifdef VOLUMETRIC_CLOUDS
    {
        vec4 vc;
#if CLOUD_TEMPORAL == 1
        // VC_SAMPLES_EFF march, start interleaved over 4 frames, resolved by
        // prepare1.fsh. The phase (frame index mod 4; v120 has no integer %)
        // is rotated per texel by (x + 2y) so every 2x2 texel block holds all
        // four phases each frame: the 3x3 min/max box of the resolve then
        // spans the whole step (not just this frame's quarter) and the
        // 4-phase history is never clamped back onto one phase. Spatially it
        // is the legacy full-step dither, cycled over time.
        ivec2 fci = ivec2(floor(gl_FragCoord.xy));
        int phase = frameCounter + fci.x + 2 * fci.y;
        float frameOff = float(phase - (phase / 4) * 4);
        vc = volumetricClouds(cameraPosition, worldDir, lightW,
                              getSkyBase(worldDir, sunW),
                              dither, cloudWorldTime(), 1.0e9, frameOff); // world time (cumulus), unbounded like deferred
#else
        vc = volumetricClouds(cameraPosition, worldDir, lightW,
                              getSkyBase(worldDir, sunW),
                              dither, cloudWorldTime(), 1.0e9); // world time (cumulus), unbounded like deferred
#endif
        accP = vc.rgb * vc.a + accP * (1.0 - vc.a);
        accA = vc.a + accA * (1.0 - vc.a);
    }
#endif

    gl_FragData[0] = vec4(accP, accA);
#else
    // CLOUD_HALF_RES=0 (or no cloud layer): dead pass, nothing written.
    discard;
#endif
}
