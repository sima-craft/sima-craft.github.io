#version 120
/* Basic geometry (fragment). Writes flat vertex color to colortex0. */

varying vec4 glcolor;

void main() {
/* DRAWBUFFERS:0 */
    gl_FragData[0] = glcolor;
}
