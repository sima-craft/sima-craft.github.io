#version 430 compatibility
/* VertaLux - LPV STAGE 2, HISTORY REFRESH (CL_V2 only).  COPY A(lightImg) -> B(lightImgB).
   Runs AFTER composite_d, so B ends the frame holding the FINAL post-stride-1 field.
   The CL_V2 injection (composite.csh) inherits air cells from B: without this copy it
   inherited composite_c's post-stride-2 state, whose support is the even sublattice
   {seed + (2a,2b,2c)} - every cell at an all-odd offset from a source stayed at exactly
   0.0 forever (block-scale orange/cyan checkerboard around wall-mounted lights, light
   never crossing a 1-cell doorway). With the post-stride-1 history: zeros within r=12
   = 0.0%, diagonal profile monotone, a 1-cell doorway passes light (simulated).
   The CONSUMED image is untouched: sampleLPV / sampleLPVForward read A, which
   composite_d just wrote - this pass only refreshes the history, parity of the visible
   field is unchanged. Race-free: each invocation writes its own B cell and nothing
   reads B during this pass. Cost: 1 load + 1 store per cell (~2.1M), negligible
   against the ~106 loads/cell of the flood.
   Auto-detected by Iris from the filename (composite slot), like composite_a..d.
   Gate: only useful when the injection reads B -> EMISSIVE_LPV=1 AND CL_V2=1; any
   other combination returns immediately (v1 never reads B between frames).
   CL_V3=1: dead code, compiled out - composite.csh owns BOTH volumes via frame-parity
   ping-pong, an A->B copy here would destroy the odd-frame history. */
#include "/lib/settings.glsl"
#include "/lib/common.glsl"

layout(local_size_x = 8, local_size_y = 8, local_size_z = 8) in;
const ivec3 workGroups = ivec3(16, 16, 16);

layout(rgba16f) uniform image3D lightImg;     // A
layout(rgba16f) uniform image3D lightImgB;    // B

#define LPVF_SRC  lightImg                      // reads A (final post-stride-1 field)
#define LPVF_DST  lightImgB                     // writes B (next frame's history)
#define LPVF_STEP 1
#include "/lib/lpv_flood.glsl"

void main() {
#if EMISSIVE_LPV == 1 && CL_V2 == 1 && CL_V3 == 0
    ivec3 c = ivec3(gl_GlobalInvocationID);
    if (any(greaterThanEqual(c, ivec3(LPVF_RES)))) return;
    lpvCopyCell(c);     // A -> B: history = final state, every parity class present
#endif
}
