#version 330 compatibility
/* Distant Horizons LOD terrain (vertex).
   Iris DH API notes:
   - DH geometry is UNTEXTURED: gl_Color = per-vertex albedo, gl_Normal = per-face
     normal, lightmap already normalized 0..1 in gl_MultiTexCoord1 (aliased to
     gl_MultiTexCoord2 by Iris), dhMaterialId int attribute (DH_BLOCK_* macros).
     mc_Entity DOES NOT EXIST in dh_* programs.
   - Iris REPLACES gl_ProjectionMatrix with the DH projection (extended near/far)
     in dh_* programs, so the usual MVP path is correct here.
   - #version 330 compatibility is required (dhMaterialId is an int attribute,
     illegal in 120); compatibility builtins remain available.
   TAA jitter must stay STRICTLY IDENTICAL to the gbuffers (same taaJitterNDC,
   same screen scale) - composite4 de-jitters the same sequence, and a missing or
   different jitter makes LODs ghost and shimmer under TAA. */

#include "/lib/settings.glsl"
#include "/lib/common.glsl"

uniform int frameCounter;
uniform float viewWidth;
uniform float viewHeight;

varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 normal;
varying vec3 viewPos;
flat varying int dhMatId;

void main() {
    vec4 pos = gl_ModelViewMatrix * gl_Vertex;
    viewPos = pos.xyz;

    gl_Position = gl_ProjectionMatrix * pos;
    #ifdef TAA
        // TAAU: jitter measured in RENDER BUFFER texels (see gbuffers_terrain.vsh).
        gl_Position.xy += taaJitterNDC(frameCounter) * TAA_JITTER * gl_Position.w * vec2(2.0 / (viewWidth * TAAU_S), 2.0 / (viewHeight * TAAU_S));
    #endif
    // TAAU: bottom-left sub-rect mapping AFTER the jitter, IDENTICAL to the
    // gbuffers - DH LODs must land in the same sub-rect as vanilla terrain or
    // the vanilla/DH seam doubles on screen.
    // At TAAU_S = 1.0 this folds away at compile time (no-op).
    gl_Position.xy = gl_Position.xy * TAAU_S + gl_Position.w * (TAAU_S - 1.0);

    // DH lightmap is already normalized 0..1: do NOT apply gl_TextureMatrix[1]
    // here, LODs do not go through the vanilla lightmap matrix.
    lmcoord = clamp(gl_MultiTexCoord1.xy, 0.0, 1.0);
    glcolor = gl_Color;
    normal  = normalize(gl_NormalMatrix * gl_Normal);
    dhMatId = dhMaterialId;

    // No WAVING_FOLIAGE here: past 500 blocks the sway is invisible and would
    // move LOD seams apart (cracks).
}
