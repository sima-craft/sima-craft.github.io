#version 120
/* First-person hand (fragment). Forced OPAQUE so the skin overlay layer does not
   make the arm translucent. Writes colortex0/1/2.
   PBR on held items is FORWARD-only here: the hand depth is squashed by Iris
   (d0 < 0.56), so composite1's screen-space viewPos rebuild - and any SSR ray
   from it - is wrong on hand pixels. viewPos/normal ARE correct in this stage. */

#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/distort.glsl"
#include "/lib/biome.glsl"
#include "/lib/dimension.glsl"
#include "/lib/lighting.glsl"

uniform sampler2D gtexture;
#ifdef PBR_TEXTURES
    uniform sampler2D normals;  // labPBR _n map (Iris supplies it for the hand too)
    uniform sampler2D specular; // labPBR _s map (all-zero default without a pack)
#endif

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 normal;
varying vec4 tangent;
varying vec3 viewPos;

void main() {
    vec4 col = texture2D(gtexture, texcoord) * glcolor;
    if (col.a < 0.5) discard; // cutout: drops the semi-transparent skin overlay layer

    vec3 albedo = toLinear(col.rgb);
    // SUN-term shadow (declared OUTSIDE the LPV gate - used in both branches).
    // Without it the hand stays fully sunlit under a roof: the "not in the game"
    // tell. Sample point is pushed 0.5 block TOWARD the light: the hand itself is
    // never rendered in the shadow map (no self-acne possible), but the player
    // BODY is - the push steps over it so the arm does not flicker in its own
    // silhouette while swinging. Faded by local sky exposure: underground the
    // lightmap already darkens the hand, the shadow must not double that.
    vec3 handShadow = vec3(1.0);
#if PARTICLE_SHADOWS == 1
    // Same escape hatch as particles: PARTICLE_SHADOWS=0 restores the old
    // always-sunlit hand exactly (declaration stays outside the gate).
    if (lmcoord.y > 0.01) {
        vec3 LvH = normalize(shadowLightPosition);
        vec3 shH = getShadow(viewPos + LvH * 0.5, LvH, bayer8(gl_FragCoord.xy));
        #ifdef VOLUMETRIC_CLOUDS
        #ifdef VC_GROUND_SHADOWS
        // Cloud shadow parity: hand darkens with the terrain when a cloud passes.
        vec3 wpH = (gbufferModelViewInverse * vec4(viewPos, 1.0)).xyz + cameraPosition;
        shH *= cloudShadow(wpH, normalize(mat3(gbufferModelViewInverse) * shadowLightPosition));
        #endif
        #endif
        handShadow = mix(vec3(1.0), shH, smoothstep(0.1, 0.7, lmcoord.y));
    }
#endif
#if EMISSIVE_LPV == 1
    // Colored lights: ONE LPV sample at the CAMERA position (worldRelCam ~ 0, no normal
    // offset - the camera cell is always air, never solid) tints the hand's torch term.
    // KNOWN LIMIT (v1 heritage, assumed): unlike shadeSurface - which keeps the HELD term
    // vanilla-warm (getTorchColor() * heldT, the source moves with the player and the LPV
    // never sees it) - the hand's whole lmcoord.x term is tinted by the ROOM's field,
    // including the share contributed by the held item itself: a held soul torch in a
    // torch-lit room shows an orange-tinted hand (room hue), not cyan, and vice versa.
    // A clean split is not possible here: the held share of the hand's lmcoord.x cannot
    // be isolated from the ambient lightmap.
    // Enough for first person; falls back to getTorchColor() when the LPV has no energy.
    vec3 lpvH = sampleLPVForward(vec3(0.0), vec3(0.0));
    vec3 torchH = getTorchColor();
#if CL_V2 == 1 || CL_V3 == 1
    // v2/v3 (parity with shadeSurface): field colour + warm floor, luminance-normalized ->
    // the LPV replaces the hue completely, energy untouched, continuous vanilla fallback.
    vec3 clH = lpvH + torchH * CLV2_WARM_FLOOR;
    // Guard 1e-3 (CL3): never fires in normal operation (floor luma 0.0299); bounds the
    // blow-up on NaN/garbage frames. Keep in sync with shadeSurface (lib/lighting.glsl).
    torchH = clH * (luma(getTorchColor()) / max(luma(clH), 1e-3));
#else
    float lpvHL = luma(lpvH);
    if (lpvHL > 1e-4)
        torchH = mix(torchH, lpvH * (luma(getTorchColor()) / lpvHL), CL_TINT_MIX * smoothstep(0.0005, 0.004, lpvHL));
#endif
    vec3 light = getAmbientColor() * (lmcoord.y * lmcoord.y * 0.9 + 0.05)
               + getLightColor() * 0.35 * lmcoord.y * handShadow
               + torchH * (lmcoord.x * lmcoord.x * 1.8);
#else
    vec3 light = getAmbientColor() * (lmcoord.y * lmcoord.y * 0.9 + 0.05)
               + getLightColor() * 0.35 * lmcoord.y * handShadow
               + getTorchColor() * (lmcoord.x * lmcoord.x * 1.8);
#endif
#if DIMENSION_FX == 1
    // Nether / End have no skylight: complete the dimensional ambient to its
    // full share and add the End's fixed light (both exactly 0 in the Overworld).
    light += getAmbientColor() * (0.9 * (1.0 - lmcoord.y * lmcoord.y) * max(dimNether(), dimEnd()))
           + getLightColor() * (0.35 * dimEnd());
#endif
    // ===== labPBR forward specular: held item / arm =====
    // Same gate as gbuffers_entities. The composite1 SSR path is forbidden for
    // the hand (squashed depth, see header), so the shine is a forward Blinn
    // lobe from the sun/moon plus a faint blurred sky sheen - an ASSUMED
    // approximation: no real geometry reflection on held items.
    float smoothness = 0.0;
#if defined PBR_TEXTURES && (defined RT_REFLECTIONS || defined PBR_REFLECTIONS)
    smoothness = texture2D(specular, texcoord).r; // labPBR perceptual smoothness (all-zero default without a pack)
    if (smoothness > 0.001) { // no-pack path: branch never taken -> output bit-identical to legacy
        // Normal map through the TBN, same decode as gbuffers_entities
        vec3 nrm = normalize(normal);
        vec2 nXY = texture2D(normals, texcoord).xy * 2.0 - 1.0;
        nXY *= NORMAL_STRENGTH;
        float nZ = sqrt(clamp(1.0 - dot(nXY, nXY), 0.0, 1.0));
        vec3 tang = normalize(tangent.xyz);
        vec3 bitang = cross(nrm, tang) * sign(tangent.w);
        nrm = normalize(tang * nXY.x + bitang * nXY.y + nrm * nZ);
        vec3 V = -normalize(viewPos);
        vec3 H = normalize(normalize(shadowLightPosition) + V); // Blinn half-vector
        float specExp = 2.0 + 500.0 * smoothness * smoothness * smoothness;
        float lobe = pow(max(dot(nrm, H), 0.0), specExp);
        float sW = smoothness * (0.35 + 0.65 * smoothness); // same weight curve as composite1 reflW
        // Sun/moon glint: shares the diffuse gating (handShadow + skylight)
        light += getLightColor() * handShadow * (lmcoord.y * lobe * sW * 1.5);
        // Blurred environment sheen: sky-ambient tint instead of SSR (no real mirror)
        float fres = pow(1.0 - clamp(dot(nrm, V), 0.0, 1.0), 5.0);
        light += getAmbientColor() * (lmcoord.y * lmcoord.y) * (0.04 + 0.96 * fres) * sW * 0.5;
    }
#endif
    light = max(light, vec3(MIN_LIGHT));

/* DRAWBUFFERS:012 */
    gl_FragData[0] = vec4(albedo * light, 1.0); // alpha forced to 1 -> hand always opaque
    // Normal STAYS flat on purpose: composite1's contact shadows and RAIN_WET
    // blocks read colortex1 on hand pixels while marching from the SQUASHED
    // depth - a real normal there would change the no-pack image and feed
    // garbage screen-space rays. The real normal lives in this stage only.
    gl_FragData[1] = vec4(0.5, 0.5, 0.0, 1.0);
    gl_FragData[2] = vec4(lmcoord, 0.0, smoothness); // colortex2.a = SMOOTHNESS (0 = matte, real labPBR value only - a constant once turned the hand into a mirror). composite1's opaque PBR block excludes hand pixels (d0 < 0.56). Blended layers are handled by blend.gbuffers_hand.colortex2=off in shaders.properties.
}
