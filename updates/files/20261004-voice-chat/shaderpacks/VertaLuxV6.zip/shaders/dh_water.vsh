#version 330 compatibility
/* Distant Horizons LOD water (vertex).
   DH water sheet: flat plane, biome color in gl_Color, lightmap 0..1 in
   gl_MultiTexCoord1 (see dh_terrain.vsh for the Iris DH API notes).
   NO wave displacement and no swell normal: past 500 blocks waves are sub-pixel,
   they would shimmer under TAA and crack LOD seams - a flat normal gives a
   stable fresnel / sky reflection.
   TAA jitter identical to the gbuffers (same sequence composite4 undoes). */

#include "/lib/settings.glsl"
#include "/lib/common.glsl"

uniform int frameCounter;
uniform float viewWidth;
uniform float viewHeight;

varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 normal;
varying vec3 viewPos;

void main() {
    vec4 pos = gl_ModelViewMatrix * gl_Vertex;
    viewPos = pos.xyz;

    gl_Position = gl_ProjectionMatrix * pos;
    #ifdef TAA
        // TAAU: jitter measured in RENDER BUFFER texels (see gbuffers_terrain.vsh).
        gl_Position.xy += taaJitterNDC(frameCounter) * TAA_JITTER * gl_Position.w * vec2(2.0 / (viewWidth * TAAU_S), 2.0 / (viewHeight * TAAU_S));
    #endif
    // TAAU: bottom-left sub-rect mapping, AFTER the jitter (see dh_terrain.vsh).
    // At TAAU_S = 1.0 this folds away at compile time (no-op).
    gl_Position.xy = gl_Position.xy * TAAU_S + gl_Position.w * (TAAU_S - 1.0);

    lmcoord = clamp(gl_MultiTexCoord1.xy, 0.0, 1.0);
    glcolor = gl_Color;
    normal  = normalize(gl_NormalMatrix * gl_Normal);
}
