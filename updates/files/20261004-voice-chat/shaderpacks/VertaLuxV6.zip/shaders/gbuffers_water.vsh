#version 120
/* Translucents: water, glass, ice (vertex).
   The water surface is displaced vertically by the wave field.
   CORPS PARTAGE : tout le programme vit dans /lib/program_water_vertex.glsl,
   compile une seconde fois par physics_ocean_v2.vsh (variante ocean de
   PHYSICS MOD PRO - voir PHYSICS_MOD_SUPPORT dans lib/settings.glsl).
   Ici : chemin normal, aucun bloc PHYSICS_OCEAN actif. */

#include "/lib/program_water_vertex.glsl"
