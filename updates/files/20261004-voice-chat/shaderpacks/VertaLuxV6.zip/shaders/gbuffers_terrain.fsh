#version 120
/* Terrain (fragment): full forward lighting.
   Emissive blocks (id 20) and lava/fire (id 21, stronger) become real HDR
   sources; terrain writes normal/albedo/flags for the screen-space light pass.
   Writes: colortex0 color, 1 normal, 2 lightmap/flags/smoothness, 5 albedo,
   11 PBR data (+12 direct term in path-trace mode).
   PERF_DEFERRED (LOT C piece 2, lib/settings.glsl, defaut 1) : les fragments
   NON emissifs n'appellent plus shadeSurface ici - colortex0 recoit l'albedo
   lineaire brut + un drapeau dans l'alpha, et deferred1.fsh shade UNE fois
   par pixel visible (l'overdraw feuillage/cutout ne paie plus le PCSS).
   A 0 : ce fichier redevient le forward decrit ci-dessus, AU TEST ALPHA PRES :
   le test injecte par Iris (emulation fixed-function sur l'ALPHA DE SORTIE,
   desactive par alphaTest.gbuffers_terrain=off dans shaders.properties - BUG A
   feuillage invisible) est RELOCALISE dans le discard in-shader de main(),
   meme ensemble de fragments tues aux deux gates - preuve et algebre au bloc
   "TEST ALPHA IN-SHADER" de main(), baseline pd_baseline2.txt. */

#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/distort.glsl"
#include "/lib/biome.glsl"
#include "/lib/dimension.glsl"
#include "/lib/cl_colors.glsl"
#include "/lib/lighting.glsl"

uniform sampler2D gtexture;
#ifdef PBR_TEXTURES
    uniform sampler2D normals;
    uniform sampler2D specular;
#endif

// BUG A (audit jar iris-fabric-1.11.2+mc26.2) : reference du test alpha du
// draw courant, uniforme Iris standard (IrisInternalUniforms "alphaTestRef" <-
// CapturedRenderingState, poussee par ExtendedShader.apply). ATTENTION,
// MESURE au bytecode : c'est LE MEME float que iris_currentAlphaTest, la ref
// du test injecte - avec l'override "alphaTest.gbuffers_terrain=off" de
// shaders.properties il vaut donc 0.0 en permanence (AlphaTest.ALWAYS,
// reference 0.0f). Declare et max()e quand meme : inerte tant que l'override
// tient, et auto-documentant - voir le bloc TEST ALPHA IN-SHADER de main().
uniform float alphaTestRef;

#ifdef VLX_DEFERRED_ACTIVE
// PERF_DEFERRED (audit adversarial C2, preuve au bytecode MC 26.2/Iris 1.11.2) :
// tout ce qu'Iris route vers CE programme mais que MC dessine APRES les passes
// deferred sortirait d'ici en albedo brut sans JAMAIS etre shade par deferred1.
// Membre prouve : la surcouche de cassage de bloc (DamagedBlock -> fallback
// Terrain, phase breakingOverlay, blend multiplicatif 2*src*dst - elle perdait
// tout son eclairage : delave en grotte, trop sombre au soleil). Probable : le
// texte teinte des panneaux (TEXT_BE -> Block -> Terrain, phase texts).
// Le drapeau "differe" n'est donc pose QUE sur les vraies passes terrain de la
// fenetre opaque ; tout autre stage repasse FORWARD au call site : visuel
// correct garanti quel que soit l'ordre de dessin, seul le gain perf est perdu
// sur ces fragments marginaux. Sens de panne : renderStage fige hors stages
// terrain (mod mal eleve) = tout le terrain repasse forward - perf d'avant le
// gate, jamais un visuel casse (l'inverse exact de la lecon fail-open CL round
// 49 : ici l'inclusion est stricte, le doute paie le chemin sur).
uniform int renderStage;
#endif

#if PORTAL_FX == 1
// end_portal / end_gateway are vanilla BLOCK ENTITIES: Iris routes them to
// gbuffers_block, which this pack lacks -> OptiFine fallback lands on THIS
// program. mc_Entity is NOT provided for block entities (mat = 0): only the
// Iris uniform blockEntityId (= block.properties id, 25 here) identifies them.
// Outside block entities it is -1/0, so the == 25 test is inert elsewhere.
uniform int blockEntityId;

#if END_PORTAL_SPACE == 1
// Pixel footprint of the star discs (END_PORTAL_SPACE): one render pixel at
// view depth z covers 2z / (P[1][1] * renderHeight) blocks.
uniform mat4 gbufferProjection;
uniform float viewHeight;

// One layer of the End SPACE window: hashed cell grid, at most one star per
// cell, confined to the cell center (never clipped at edges -> no popping).
// Magnitudes follow hn^2 (most stars faint, a few bright), ~12% blue-white /
// ~8% orange / the rest white, faint haze around the bright ones, slow
// per-star twinkle (6-12 s periods, +-12%, TAA-safe). pxCell = one render
// pixel in cell units: a disc thinner than ~0.9 px widens to the pixel and
// dims by the area ratio (a sub-pixel star is a fainter dot, never a shimmer).
// LINEAR rgb, peaks ~1.1; the caller scales to HDR for the bloom.
vec3 endSpaceStars(vec2 p, float t, float seed, float density, float pxCell) {
    vec2 cell = floor(p);
    vec2 f = fract(p);
    float h0 = hash12(cell + seed);
    if (h0 > density) return vec3(0.0); // empty cell
    float hn = h0 / density;            // uniform 0..1 among the lit cells
    float mag = hn * hn;                // brightness class
    vec2 spos = vec2(hash12(cell + seed + 3.1), hash12(cell + seed + 7.7)) * 0.6 + 0.2;
    float d = length(f - spos);
    float rad0 = 0.018 + mag * 0.035; // cells: ~2-7 px radius at 2 blocks (layer 0)
    float rad = max(rad0, pxCell * 0.9);
    float area = (rad0 * rad0) / (rad * rad);
    float core = smoothstep(rad, rad * 0.25, d) * area;
    float halo = exp(-d * d / (rad0 * rad0 * 8.0)) * 0.10 * mag;
    float hc = hash12(cell + seed + 13.7);
    float ht = hash12(cell + seed + 21.3);
    float tw = 0.88 + 0.12 * sin(t * (0.5 + ht * 0.55) + ht * 47.0);
    vec3 scol = vec3(0.92, 0.95, 1.00);                // white
    if (hc < 0.12)      scol = vec3(0.60, 0.74, 1.15); // blue-white
    else if (hc < 0.20) scol = vec3(1.15, 0.70, 0.42); // orange
    return scol * (core + halo) * (0.18 + 0.82 * mag) * tw;
}
#else
// One layer of the End star field: hashed cell grid, at most one star per
// cell, confined to the cell center (never clipped at edges -> no popping).
// Slow per-star twinkle, End palette (green-cyan dominant, rare gold/violet).
// Multiplied downstream by EMISSIVE_BOOST so stars cross the bloom threshold.
vec3 endStarLayer(vec2 p, float t, float seed) {
    vec2 cell = floor(p);
    vec2 f = fract(p);
    float h0 = hash12(cell + seed);
    if (h0 > 0.55) return vec3(0.0); // empty cell (~45% of cells)
    vec2 spos = vec2(hash12(cell + seed + 3.1), hash12(cell + seed + 7.7)) * 0.6 + 0.2;
    float d = length(f - spos);
    float rad = 0.045 + h0 * 0.10;
    float star = smoothstep(rad, rad * 0.30, d);
    star *= 0.70 + 0.30 * sin(t * (0.8 + h0 * 2.4) + h0 * 41.0);
    float hc = hash12(cell + seed + 13.7);
    vec3 scol = (hc < 0.55) ? vec3(0.45, 1.00, 0.75)
              : ((hc < 0.85) ? vec3(0.80, 1.00, 0.55) : vec3(0.62, 0.52, 1.05));
    return scol * star * (0.45 + h0 * 1.6);
}
#endif // END_PORTAL_SPACE
#endif // PORTAL_FX

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 normal;
varying vec4 tangent;
varying vec3 viewPos;
varying float mat;

void main() {
    vec2 tc = texcoord;

    // ===== POM: parallax from labPBR height maps (height = normals.a) =====
    #if defined PBR_TEXTURES && defined PBR_POM
    {
        vec3 tang = normalize(tangent.xyz);
        vec3 bitang = cross(normalize(normal), tang) * sign(tangent.w);
        mat3 tbn = mat3(tang, bitang, normalize(normal));
        vec3 vdirT = (-normalize(viewPos)) * tbn;     // view direction in tangent space
        float h = texture2D(normals, tc).a;           // height 0..1 (1 = top)
        // Parallax offset (relief carved below the surface)
        vec2 par = vdirT.xy / max(abs(vdirT.z), 0.25) * (h - 1.0) * POM_DEPTH * 0.02;
        par = clamp(par, vec2(-0.03), vec2(0.03)); // clamp offset: no smearing on edges (stairs/slabs/fences)
        tc = texcoord + par;
    }
    #endif

    vec4 col = texture2D(gtexture, tc) * glcolor;
    // The end portal (block entity, minimal vanilla vertex format) may arrive
    // with default UVs -> texture alpha is NOT reliable: never discard it
    // (otherwise the portal turns invisible depending on atlas texel (0,0)).
    bool portalBE = false;
#if PORTAL_FX == 1
    portalBE = (blockEntityId == 25);
#endif
    // ===== TEST ALPHA IN-SHADER (BUG A feuillage invisible, 2026-08) =====
    // MECANISME (preuve bytecode iris-fabric-1.11.2+mc26.2) : Iris emule le
    // fixed-function alpha test en APPENDANT en fin de main() un test sur
    // l'ALPHA DE SORTIE (CommonTransformer.appendMainFunctionBody +
    // AlphaTest.toExpression -> "if (!(gl_FragData[0].a > iris_currentAlphaTest))
    // discard;"). A gate 1, colortex0.a du terrain differe porte le DRAPEAU
    // 0.00/0.02, pas un alpha -> le test injecte de la passe cutout tuait TOUT
    // le feuillage differe (invisible, ombres intactes - passe shadow separee).
    // shaders.properties porte donc "alphaTest.gbuffers_terrain=off" et le test
    // est RELOCALISE ici, sur l'ALPHA TEXTURE col.a, ou il est correct aux deux
    // gates. Refs injectees MESUREES (ShaderKey/AlphaTests, javap) :
    //   passe terrain CUTOUT sodium/vanilla  GREATER 0.5 (HALF_ALPHA)
    //   passe terrain SOLID                  aucun test  (OFF)
    //   fallbacks vers ce programme (block entities, cassage DESTROY, texte
    //   des panneaux TEXT_BE)                GREATER 0.1 (ONE_TENTH_ALPHA)
    // RECONSTRUCTION PAR MATIERE : MC 26.2 ne laisse AUCUN canal par passe -
    // WorldRenderingPhase.fromTerrainRenderType mappe tout le groupe OPAQUE sur
    // TERRAIN_SOLID (renderStage aveugle aux sous-passes sodium SOLID/CUTOUT),
    // et alphaTestRef est ecrase a 0.0 par l'override (voir sa declaration).
    // Or les blocs cutout du pack sont exactement l'id 10 (feuilles, herbe,
    // fleurs, kelp - la ligne subsurface ci-dessous fait le meme test) : seuil
    // 0.5 pour eux (la ref de la passe cutout qui les dessinait), 0.1 pour tout
    // le reste (l'ancien discard in-shader, qui dominait OFF 0.0 / NON_ZERO
    // 1e-4 / ONE_TENTH 0.1).
    // EQUIVALENCE (gate 0 comme gate 1 forward) : avant le differe l'alpha de
    // sortie ETAIT col.a - le test injecte etait donc un test sur col.a, et le
    // deplacer ici tue le MEME ensemble de fragments, a l'egalite exacte pres
    // (col.a == ref : "< 0.5" in-shader vs "<= 0.5" injecte - inatteignable
    // depuis une texture 8 bits x glcolor, 127.5/255 n'existe pas).
    // ECART ASSUME : un bloc cutout NON tagge 10 (rails, verre clair...) passe
    // de 0.5 a 0.1 sur ses texels de mip lointains -> quelques texels de PLUS
    // dessines a distance, jamais un trou. Sens de panne sur : si la ligne
    // properties saute, l'injection revient et le feuillage differe redisparait
    // (signal visible), pendant que max(alphaTestRef, ...) re-serre ce discard.
    float aCut = (mat > 9.5 && mat < 10.5) ? 0.5 : 0.1;
    if (col.a < max(alphaTestRef, aCut) && !portalBE) discard;

    vec3 albedo = toLinear(col.rgb);
    // id 10 = foliage: subsurface scattering (light passes through leaves)
    float subsurface = (mat > 9.5 && mat < 10.5) ? 1.0 : 0.0;
    bool emissive =
           (mat > 16.5 && mat < 24.5)
        || (mat > 25.5 && mat < 26.5)
    #ifdef REDSTONE_BLOCK_GLOW
        || (mat > 26.5 && mat < 27.5)
    #endif
    #ifdef EMERALD_BLOCK_GLOW
        || (mat > 27.5 && mat < 28.5)
    #endif
    #ifdef DIAMOND_BLOCK_GLOW
        || (mat > 28.5 && mat < 29.5)
    #endif
    #ifdef GOLD_BLOCK_GLOW
        || (mat > 30.5 && mat < 31.5)
    #endif
    #ifdef IRON_BLOCK_GLOW
        || (mat > 31.5 && mat < 32.5)
    #endif
    #ifdef NETHERITE_BLOCK_GLOW
        || (mat > 32.5 && mat < 33.5)
    #endif
    #ifdef AMETHYST_BLOCK_GLOW
        || (mat > 33.5 && mat < 34.5)
    #endif
    #ifdef COPPER_BLOCK_GLOW
        || (mat > 34.5 && mat < 35.5)
    #endif
    #ifdef RAW_IRON_BLOCK_GLOW
        || (mat > 35.5 && mat < 36.5)
    #endif
    #ifdef RAW_GOLD_BLOCK_GLOW
        || (mat > 36.5 && mat < 37.5)
    #endif
    #ifdef RAW_COPPER_BLOCK_GLOW
        || (mat > 37.5 && mat < 38.5)
    #endif
        ;
    bool lava = (mat > 20.5 && mat < 21.5);
    bool glass = (mat > 29.5 && mat < 30.5);
    bool portal = (mat > 24.5 && mat < 25.5) || portalBE;
#if SNOW_SPARKLE == 1
    // id 42 = snow layers / snow block / powder snow (block.properties): only
    // tags the material flag below (SNOW band 0.38) for the composite1 glints.
    bool snow = (mat > 41.5 && mat < 42.5);
#endif
    float dither = bayer8(gl_FragCoord.xy);

    vec3 nrm = normalize(normal);

    // labPBR: resource-pack normal map
    #ifdef PBR_TEXTURES
    {
        vec2 nXY = texture2D(normals, tc).xy * 2.0 - 1.0;
        nXY *= NORMAL_STRENGTH;
        float nZ = sqrt(clamp(1.0 - dot(nXY, nXY), 0.0, 1.0));
        vec3 tang = normalize(tangent.xyz);
        vec3 bitang = cross(nrm, tang) * sign(tangent.w);
        nrm = normalize(tang * nXY.x + bitang * nXY.y + nrm * nZ);
    }
    #endif

#if FULL_PATH_TRACE == 1 && VOXEL_GI == 1
    vec3 fptDirect = vec3(0.0);
    vec3 color = shadeSurfaceFPT(albedo, nrm, lmcoord, viewPos, dither, subsurface, fptDirect);
#elif defined VLX_DEFERRED_ACTIVE
    // ===== PERF_DEFERRED (LOT C piece 2, lib/settings.glsl) =====
    // Tap specular HOISTE ici (une seule lecture par fragment, reutilisee par
    // le bloc emission labPBR puis smoothness/metalness plus bas : meme contrat
    // "single specular tap" que le chemin forward).
    #ifdef PBR_TEXTURES
    vec4 specTex = texture2D(specular, tc);
    #endif
    // Restent FORWARD les fragments dont la couleur finale depend de la texture
    // au-dela de l'albedo (termes additifs/remplacements appliques APRES
    // shadeSurface, dans les blocs partages ci-dessous) : emissifs (torches,
    // lave...), portails, emission labPBR. Ils s'etiquettent alpha >= 0.1
    // ("deja shade") a l'ecriture. Tout le reste - l'ecrasante majorite des
    // fragments, feuillage compris - SAUTE shadeSurface : le G-buffer part brut
    // (color = albedo lineaire) et deferred1.fsh shade UNE fois par pixel
    // VISIBLE avec LE MEME shadeSurface de lib/lighting.glsl.
    // Stage gate (voir la declaration de renderStage en tete de fichier) : ne
    // se differencient que les passes TERRAIN de la fenetre opaque ; DESTROY
    // (cassage), BLOCK_ENTITIES (coffres/texte via fallback), NONE et tout
    // stage inconnu shadent forward - correct dans les deux ordres de dessin.
    bool stageTerrain = renderStage == MC_RENDER_STAGE_TERRAIN_SOLID
                     || renderStage == MC_RENDER_STAGE_TERRAIN_CUTOUT
                     || renderStage == MC_RENDER_STAGE_TERRAIN_CUTOUT_MIPPED;
    bool fwdShade = portal || emissive || !stageTerrain;
    #ifdef PBR_TEXTURES
    if (specTex.a < 1.0 && specTex.a > 0.003) fwdShade = true; // emission labPBR -> forward
    #endif
    vec3 color = fwdShade ? shadeSurface(albedo, nrm, lmcoord, viewPos, dither, subsurface)
                          : albedo;
#else
    vec3 color = shadeSurface(albedo, nrm, lmcoord, viewPos, dither, subsurface);
#endif

    // labPBR: texture emission (specular map alpha, 255 = none)
    #ifdef PBR_TEXTURES
    // PERF: single specular tap per fragment; reused below for
    // smoothness/metalness. (PERF_DEFERRED: le tap est deja hoiste AVANT le
    // call site - meme valeur, pas de second tap ; ce bloc n'ajoute alors de
    // l'emission que sur les fragments fwdShade, par construction du gate.)
    #ifndef VLX_DEFERRED_ACTIVE
    vec4 specTex = texture2D(specular, tc);
    #endif
    {
        float emisS = specTex.a;
        if (emisS < 1.0 && emisS > 0.003) {
            color += albedo * emisS * EMISSIVE_BOOST * PBR_EMISSIVE;
        }
    }
    #endif

    if (portal) {
        vec3 wp = (gbufferModelViewInverse * vec4(viewPos, 1.0)).xyz + cameraPosition;
        float t2 = frameTimeCounter;
#if PORTAL_FX == 1
        // Only end_portal / end_gateway (block entities, portalBE) reach this
        // branch: nether_portal is TRANSLUCENT and goes through gbuffers_water.
        // The hue heuristic stays as a safety net for a portal routed as solid
        // by a mod or resource pack.
        bool isEndP = portalBE
                   || luma(col.rgb * vec3(0.5, 1.0, 0.9)) > luma(col.rgb * vec3(1.0, 0.5, 1.0));
        if (isEndP) {
#if END_PORTAL_SPACE == 1
            // ===== End portal: window onto DEEP SPACE =====
            // Face tangent frame from the gbuffer normal (end_portal top face =
            // +Y, end_gateway = any axis), snapped to the world axes; +Y fallback
            // if the block entity ever arrives without a normal. Plane coords are
            // WORLD positions: continuous across the 3x3 pool, no per-block repeat.
            float nlE = length(normal);
            vec3 nWE = (nlE > 0.5) ? mat3(gbufferModelViewInverse) * (normal / nlE) : vec3(0.0, 1.0, 0.0);
            vec3 anE = abs(nWE);
            vec3 tanE, bitE;
            if (anE.y >= anE.x && anE.y >= anE.z) { tanE = vec3(1.0, 0.0, 0.0); bitE = vec3(0.0, 0.0, 1.0); nWE = vec3(0.0, sign(nWE.y), 0.0); }
            else if (anE.x >= anE.z)             { tanE = vec3(0.0, 0.0, 1.0); bitE = vec3(0.0, 1.0, 0.0); nWE = vec3(sign(nWE.x), 0.0, 0.0); }
            else                                 { tanE = vec3(1.0, 0.0, 0.0); bitE = vec3(0.0, 1.0, 0.0); nWE = vec3(0.0, 0.0, sign(nWE.z)); }
            vec2 plE = vec2(dot(wp, tanE), dot(wp, bitE));
            // View ray in the tangent frame, continued BEHIND the window: a layer
            // at depth D blocks is met at plE + vTE.xy / |vTE.z| * D, so the
            // deepest layer slides the most with the view angle. Grazing views
            // clamp at 1/0.25; END_PORTAL_DEPTH scales every depth.
            vec3 vdE = normalize(mat3(gbufferModelViewInverse) * viewPos);
            vec3 vTE = vec3(dot(vdE, tanE), dot(vdE, bitE), dot(vdE, nWE));
            vec2 parE = vTE.xy / max(abs(vTE.z), 0.25) * END_PORTAL_DEPTH;
            // One render pixel in blocks at this depth (star disc footprint).
            float pxE = max(-viewPos.z, 0.05) * 2.0 / (max(gbufferProjection[1][1], 0.1) * viewHeight * TAAU_S);
            // Slight vignette toward the block edges = well depth (x0.8 at the
            // rim at depth 1.0, scales with sqrt(END_PORTAL_DEPTH)).
            vec2 fcE = abs(fract(plE) - 0.5) * 2.0;
            float vigE = 1.0 - 0.20 * sqrt(END_PORTAL_DEPTH) * smoothstep(0.55, 1.0, max(fcE.x, fcE.y));
            // Near-black void + faint violet/blue nebula: 2 octaves of the baked
            // value noise on the far-layer parallax, drifting ~0.001 block/s.
            vec2 nqE = (plE + parE * 3.2) * 0.45 + vec2(t2 * 0.0010, -t2 * 0.0007);
            float nb1 = vnoiseTex(nqE + 37.0);
            float nb2 = vnoiseTex(nqE * 2.3 + 91.0);
            float nebE = smoothstep(0.40, 0.85, nb1 * 0.65 + nb2 * 0.35);
            vec3 endC = vec3(0.0035, 0.0030, 0.0060)
                      + mix(vec3(0.022, 0.007, 0.045), vec3(0.007, 0.013, 0.050), nb2) * nebE * vigE;
            // 4 star layers, finer and deeper with the index (the deepest = dust),
            // each with its own very slow drift (<= 0.0015 block/s). LINEAR peaks
            // ~1.1 x EMISSIVE_BOOST x 0.45 x PORTAL_GLOW = ~4 HDR (bloom).
            vec3 starsE = vec3(0.0);
            starsE += endSpaceStars((plE + parE * 0.5 + vec2(t2 * 0.0015, t2 * 0.0006)) * 2.8, t2, 0.0, 0.42, pxE * 2.8) * 1.00;
            starsE += endSpaceStars((plE + parE * 1.2 + vec2(-t2 * 0.0009, t2 * 0.0012)) * 4.2 + 11.0, t2, 5.0, 0.48, pxE * 4.2) * 0.75;
            starsE += endSpaceStars((plE + parE * 2.2 + vec2(t2 * 0.0007, -t2 * 0.0011)) * 6.3 + 23.0, t2, 9.0, 0.55, pxE * 6.3) * 0.52;
            starsE += endSpaceStars((plE + parE * 3.5 + vec2(-t2 * 0.0012, -t2 * 0.0005)) * 8.0 + 37.0, t2, 17.0, 0.60, pxE * 8.0) * 0.36;
            color = endC + starsE * vigE * (EMISSIVE_BOOST * 0.45 * PORTAL_GLOW);
            col.a = 1.0; // texture alpha unreliable (default UVs) -> force full surface
#else
            // ===== End star well (4 parallax layers) =====
            // OBLIQUE world mapping: independent of normal/UV attributes, since
            // the end_portal block entity arrives in a minimal vertex format
            // where only POSITION is reliable. Deeper layers slide more with the
            // view direction (odE) and weigh less -> bottomless-well feel.
            vec3 vdW = normalize(mat3(gbufferModelViewInverse) * viewPos);
            vec2 plE = vec2(wp.x + wp.y * 0.618, wp.z - wp.y * 0.618);
            vec2 odE = vec2(vdW.x + vdW.y * 0.618, vdW.z - vdW.y * 0.618) * 1.35;
            // Backdrop: deep void + faint slowly drifting nebula
            float neb = fbm(plE * 0.55 + odE * 2.2 + vec2(t2 * 0.010, -t2 * 0.008));
            vec3 endC = vec3(0.010, 0.020, 0.026) + vec3(0.020, 0.085, 0.080) * neb * neb;
            endC += endStarLayer(plE * 1.9 + odE * 0.55, t2, 0.0) * 1.00;
            endC += endStarLayer(plE * 2.6 + odE * 1.35 + 11.0, t2, 5.0) * 0.72;
            endC += endStarLayer(plE * 3.6 + odE * 2.60 + 23.0, t2, 9.0) * 0.50;
            endC += endStarLayer(plE * 4.9 + odE * 4.40 + 37.0, t2, 17.0) * 0.34;
            // HDR: stars land around 4..10 luminance (bloom threshold ~2.2) -> sparkle.
            color = endC * EMISSIVE_BOOST * 0.9 * PORTAL_GLOW;
            col.a = 1.0; // texture alpha unreliable (default UVs) -> force full surface
#endif // END_PORTAL_SPACE
        } else {
            // Fallback for solid mat 25: purple swirl.
            float swirl = fbm(wp.xy * 1.5 + vec2(t2 * 0.3, -t2 * 0.2))
                        + fbm(wp.zy * 1.5 - vec2(t2 * 0.25, t2 * 0.15));
            float pulse = 0.6 + 0.4 * sin(t2 * 2.0 + swirl * 4.0);
            vec3 pcol = vec3(0.85, 0.30, 1.30);
            float bright = smoothstep(0.2, 0.9, swirl * 0.6 + 0.3) * pulse;
            color = albedo * 0.3 + pcol * bright * EMISSIVE_BOOST * 0.8;
        }
#else
        // Portal: animated energy swirl. Purple (Nether) or spectral turquoise
        // (End), picked from the texture hue.
        float swirl = fbm(wp.xy * 1.5 + vec2(t2 * 0.3, -t2 * 0.2))
                    + fbm(wp.zy * 1.5 - vec2(t2 * 0.25, t2 * 0.15));
        float pulse = 0.6 + 0.4 * sin(t2 * 2.0 + swirl * 4.0);
        bool isEnd = luma(col.rgb * vec3(0.5, 1.0, 0.9)) > luma(col.rgb * vec3(1.0, 0.5, 1.0));
        vec3 pcol = isEnd ? vec3(0.25, 1.10, 0.95) : vec3(0.85, 0.30, 1.30);
        float bright = smoothstep(0.2, 0.9, swirl * 0.6 + 0.3) * pulse;
        color = albedo * 0.3 + pcol * bright * EMISSIVE_BOOST * 0.8;
#endif
    } else if (emissive) {
        // Only the bright parts of the texture emit (flame yes, torch stick no).
        // eMask floors and both per-family tables live in lib/cl_colors.glsl
        // (shared with shadow.fsh - the old duplicated-chain sync contract is
        // retired): clScreenTint styles THIS visible texture glow, while the
        // light the block CASTS uses the fixed clLightColor palette.
        float eMask = max(smoothstep(0.30, 0.80, luma(col.rgb)), clMaskFloor(mat));

        // Each emitter family gets its own screen glow tint:
        vec3 eTint = clScreenTint(mat);
        float eStr = lava ? 1.6 : 1.0;

        // Flame flicker (torches, fire, lava, soul fire - NOT the steady
        // emitters: glowstone/amber 19, froglights/lichen 17-18 and the cold
        // blocks stay rock-stable, "ambre uniforme" for a glowstone interior)
        float flick = 1.0;
        #ifdef EMISSIVE_FLICKER
            if (mat > 19.5 && mat < 22.5) {
                flick = 0.90 + 0.07 * sin(frameTimeCounter * 9.0 + mat * 7.0)
                             + 0.04 * sin(frameTimeCounter * 23.0 + lmcoord.x * 40.0);
            }
        #endif

        vec3 emis = albedo * eMask * EMISSIVE_BOOST * eTint * eStr * flick;

        // ===== Stylized lava: black crust + moving incandescent veins =====
        if (lava) {
            vec3 wp = (gbufferModelViewInverse * vec4(viewPos, 1.0)).xyz + cameraPosition;
            float t = frameTimeCounter;
            vec3 lnW = mat3(gbufferModelViewInverse) * nrm;
            float vertical = 1.0 - clamp(abs(lnW.y) * 1.6, 0.0, 1.0);
            #ifdef LAVA_ANIMATE
                vec2 fpH = wp.xz * 1.4 + vec2(t * 0.05, -t * 0.04);
                float heatH = fbm(fpH) * 0.65 + fbm(fpH * 2.7 - t * 0.08) * 0.35;
                float uL = dot(wp.xz, normalize(vec2(lnW.z, -lnW.x) + 1e-4));
                float flow = t * LAVA_FLOW_SPEED;
                vec2 fpV = vec2(uL * 1.4, wp.y * 1.4 - flow);
                float heatV = fbm(fpV) * 0.65 + fbm(fpV * 2.7 + vec2(0.0, -flow * 1.6)) * 0.35;
                float heat = mix(heatH, heatV, vertical);
            #else
                float uL = dot(wp.xz, normalize(vec2(lnW.z, -lnW.x) + 1e-4));
                float heat = mix(fbm(wp.xz * 1.4), fbm(vec2(uL * 1.4, wp.y * 1.4)), vertical);
            #endif
            // Dark cooled crust where heat is low, bright veins elsewhere
            float crust = smoothstep(0.62, 0.34, heat);          // 1 = black crust
            float veins = smoothstep(0.55, 0.78, heat);          // 1 = bright flow
            float hot = smoothstep(0.80, 0.95, heat);            // white-yellow hotspots
            vec3 deepRed  = vec3(0.9, 0.12, 0.02);
            vec3 orange   = vec3(1.7, 0.55, 0.10);
            vec3 yellow   = vec3(2.4, 1.5, 0.45);
            vec3 molten = mix(deepRed, orange, veins) + yellow * hot;
            // slow brightness pulse (magma breathing)
            float pulse = 0.8 + 0.2 * sin(t * 1.3 + heat * 6.0);
            vec3 lavaCol = molten * EMISSIVE_BOOST * 0.7 * LAVA_GLOW * pulse;
            // the black crust kills emission in patches -> strong contrast
            emis = mix(lavaCol, vec3(0.04, 0.01, 0.0), crust * 0.85);
            // tint the albedo too (the rock itself glows red)
            color = mix(color, color * vec3(1.3, 0.7, 0.5), 0.4);
        }

        color += emis;
    }

#if FULL_PATH_TRACE == 1 && VOXEL_GI == 1
/* RENDERTARGETS: 0,1,2,5,11,12 */
#else
/* RENDERTARGETS: 0,1,2,5,11 */
#endif
#ifdef VLX_DEFERRED_ACTIVE
    // PERF_DEFERRED : colortex0.a = drapeau de la fenetre opaque (AUCUN lecteur
    // de colortex0.a entre les gbuffers et la reecriture de composite1 -
    // cartographie au bloc PERF_DEFERRED de lib/settings.glsl) :
    //   >= 0.1 : pixel FORWARD deja shade (ici : emissif/portail/labPBR ET tout
    //            stage hors terrain - cassage, block entities/texte, cf. gate
    //            renderStage au call site ; entites/main/DH forcent 1.0, les
    //            textured discard < 0.05 puis ecrivent col.a, basic ecrit
    //            glcolor.a NON borne - sur aujourd'hui car seuls leash (a=1) et
    //            sky (depth 1.0, exclu par d0<1) y passent en fenetre opaque,
    //            invariant FRAGILE a re-verifier si un consommateur de Basic
    //            apparait) -> deferred1 passthrough exact (copie, jamais un
    //            discard - ping-pong).
    //   0.02   : terrain differe, feuillage (subsurface 1, re-applique la-bas).
    //   0.00   : terrain differe, opaque standard.
    // max(col.a, 0.1) : la branche portail fallback (mat 25 solide) ne force pas
    // col.a = 1.0 comme les branches End - elle doit rester "deja shade".
    gl_FragData[0] = vec4(color, fwdShade ? max(col.a, 0.1) : subsurface * 0.02);
#else
    gl_FragData[0] = vec4(color, col.a);
#endif
    gl_FragData[1] = vec4(nrm * 0.5 + 0.5, 1.0);
    float smoothness = 0.0;
    float metalness  = 0.0;
    float emissionLP = 0.0;
    #if defined PBR_TEXTURES && (defined RT_REFLECTIONS || defined PBR_REFLECTIONS)
        vec4 specSample = specTex; // PERF: reuses the single tap taken above
        smoothness = specSample.r;                       // labPBR perceptual smoothness
        metalness  = step(229.5 / 255.0, specSample.g);  // labPBR: g >= 230/255 = metal
        emissionLP = (specSample.a < 1.0) ? specSample.a : 0.0; // labPBR emission (255 = none)
    #endif
    #ifdef RT_REFLECTIONS
    {
        // VANILLA fallback (no specular map in the resource pack): per-block
        // smoothness/metalness from block.properties ids 40/41 plus the existing
        // metal blocks, so RT reflections still work on vanilla textures. max()
        // means a real, smoother labPBR specular map always wins.
        float mid = floor(mat + 0.5);
        if (mid == 40.0) smoothness = max(smoothness, 0.62);        // polished stone / quartz / glazed terracotta
        else if (mid == 41.0) smoothness = max(smoothness, 0.85);   // packed ice, obsidian
        // (iron full-mirror fallback removed on request: iron is a normal block again)
        else if (mid == 31.0 || mid == 29.0 || mid == 28.0 || mid == 33.0) {
            smoothness = max(smoothness, 0.82);                     // gold, diamond, emerald, netherite
            metalness  = max(metalness, 1.0);
        }
        else if (mid == 35.0) {                                     // copper (all oxidation stages)
            smoothness = max(smoothness, 0.52);
            metalness  = max(metalness, 1.0);
        }
    }
    #endif
#if SNOW_SPARKLE == 1
    // Material flag bands (colortex2.b, RGBA8): water 1.0 / portal 0.85 / glass
    // 0.7 / lava 0.58 / emissive 0.5 / SNOW 0.38 / entity 0.02 / opaque 0.0.
    // The snow band sits between the entity+F5 band (0.01-0.30) and the
    // emissive band (0.45-0.65 in the GI gathers); composite1 neutralises it
    // right after its read, so no legacy band test ever sees it.
    gl_FragData[2] = vec4(lmcoord, glass ? 0.7 : (lava ? 0.58 : ((emissive || portal) ? 0.5 : (snow ? 0.38 : 0.0))), smoothness);
#else
    gl_FragData[2] = vec4(lmcoord, glass ? 0.7 : (lava ? 0.58 : ((emissive || portal) ? 0.5 : 0.0)), smoothness);
#endif
#if DEBUG_VIEW == 21
    // Debug: received shadow factor (RAW sampleShadowPCF luma, recomputed
    // independently of the shading) carried in colortex5 (albedo). final.fsh
    // view 21 reads it AS IS, with no fog/bloom/tonemap.
    gl_FragData[3] = vec4(vec3(luma(getShadow(viewPos, nrm, dither))), 1.0);
#elif DEBUG_VIEW == 22
    // Debug: s0/s1/alpha classification of the shadow texel at the receiver pixel (lighting.glsl).
    gl_FragData[3] = vec4(debugShadowClassify(viewPos, nrm), 1.0);
#else
    gl_FragData[3] = vec4(col.rgb, 1.0);
#endif
    // colortex11 = {smoothness(.r), metalness(.g), labPBR emission(.b)}.
    // .b is forward-compat ONLY: the emission is ALREADY applied in colortex0, so do NOT
    // consume it again without removing the colortex0 path (double counting).
    // gl_FragData[4] is ALWAYS written (0 outside PBR) so the MRT attachment is never
    // undefined; colortex11Clear=true covers non-terrain pixels.
    gl_FragData[4] = vec4(smoothness, metalness, emissionLP, 1.0);
#if FULL_PATH_TRACE == 1 && VOXEL_GI == 1
    // colortex12 = pure albedo-weighted DIRECT term (HDR), re-modulated by the voxel
    // shadow in composite5. Zero on emissive/portal/lava (color is replaced there, so
    // there is no direct shadow to modulate and the subtraction must skip them).
    // RENDERTARGETS 0,1,2,5,11,12 maps FragData[5] -> colortex12.
    gl_FragData[5] = vec4((emissive || portal) ? vec3(0.0) : fptDirect, 1.0);
#endif
}
