/* CORPS PARTAGE du shadow pass (fragment) + VOXELIZATION: writes each block's
   albedo into the 3D grid (voxelImg). gl_FragData[0] is still the colored
   shadow (shadowcolor0).
   Compile deux fois :
     - shadow.fsh                  -> chemin normal ;
     - physics_ocean_shadow_v2.fsh -> programme ombre de l'ocean PHYSICS MOD
       PRO. AUCUN bloc physics ici : le deplacement de vague est 100 % vertex
       (program_shadow_vertex.glsl) ; ce fragment ne fait que tagger l'eau
       (matS 8 -> bande WATER de shadowcolor0) et l'eau est exclue de toute
       voxelisation (vxSkip), ocean du mod compris.
   Emissive blocks (material ids from block.properties) write their emitted
   RADIANCE (alpha = 2.0) instead of albedo (alpha = 1.0). Occupancy is alpha > 0.5
   for both, so an emissive block occludes like a solid.
   The emitted radiance color is the FIXED per-family palette of
   lib/cl_colors.glsl (shared with gbuffers_terrain.fsh) - never a texture
   albedo sample, see that file's header for why. */

#include "/lib/settings.glsl"
// DIMENSION_FX detection only (dimNether): the palette helpers of
// lib/dimension.glsl need lib/common.glsl, which this pass does not include.
#define VL_DIMENSION_DETECT_ONLY
#include "/lib/dimension.glsl"
// Fixed per-family light colors + shared eMask floors (colored lights).
#include "/lib/cl_colors.glsl"

/* ===== PHYSICS MOD PRO : ocean dynamique (voir program_water_vertex.glsl) ==
   PHYSICS_FIELD_SYNC seulement : ce corps n'avait AUCUN bloc physics (le
   deplacement de vague est 100 % vertex). Il en a un maintenant, et un seul -
   la publication du battement, indispensable en plongee (voir la fin de
   main()). Sans le marqueur, sans PHYSICS_MOD_SUPPORT ou sans
   PHYSICS_FIELD_SYNC, aucun symbole physics_* ne survit ici. */
#if defined VLX_PHYSICS_OCEAN_PROGRAM && PHYSICS_MOD_SUPPORT == 1
    #define PHYSICS_OCEAN
#endif
#if defined PHYSICS_OCEAN && PHYSICS_FIELD_SYNC == 1
// L'UBO PhysicsOcean est lie PAR LE MOD a ce programme (meme programme que
// physics_ocean_shadow_v2.vsh, meme liaison par nom) : l'include est ce qui le
// declare cote fragment.
#include "/lib/physicsmod_ocean.glsl"
flat in vec2 vlxPhysDriftV;
flat in float vlxPhysWavV;
layout(rgba32f) uniform image2D physOceanParams;
#if PHYS_REAL == 1
// PHYS_REAL : le pass ombre recopie AUSSI la carte de rides - c'est lui qui la
// tient a jour quand la surface n'est pas a l'ecran (plongee, camera vers le
// fond), exactement comme il tient le battement.
flat in vec2 vlxPhysRipCV;
layout(r16f)    uniform image2D physRipple;
layout(rgba32f) uniform image2D physRipParams;
#endif
#ifndef VL_FRAMECOUNTER_DECL
#define VL_FRAMECOUNTER_DECL
uniform int frameCounter;
#endif
#endif

// NETHER LAVA HEIGHT MAP (DIMENSION_FX, see the end of main() and lavaGlowAt
// in lib/lighting.glsl): non-emitter fragments are DISCARDED in the Nether, so
// the depth stays at the clear value (far plane). No gl_FragDepth write at all:
// a static gl_FragDepth assignment would disable early-z for this program in
// EVERY dimension (Overworld included), discard does not.

uniform sampler2D gtexture;
uniform vec3 cameraPosition;          // world-aligned grid (snapped to the camera block). SAME cameraPosition as composite5/composite6.
layout (rgba16f) uniform image3D voxelImg;
// LPV-only mode (EMISSIVE_LPV=1 without path tracing): ONLY cascade 0 (voxelImg)
// is written. Declarations of cascades > 0 stay gated the same way as their use,
// so no image binding is created for nothing.
#if VOXEL_CASCADES > 1 && (VOXEL_GI == 1 || RT_REFLECT_MODE >= 2)
layout (rgba16f) uniform image3D voxelImg1;
#endif
#if VOXEL_CASCADES > 2 && (VOXEL_GI == 1 || RT_REFLECT_MODE >= 2)
layout (rgba16f) uniform image3D voxelImg2;
#endif
#if VOXEL_CASCADES > 3 && (VOXEL_GI == 1 || RT_REFLECT_MODE >= 2)
layout (rgba16f) uniform image3D voxelImg3;
#endif
#if VOXEL_CASCADES > 4 && (VOXEL_GI == 1 || RT_REFLECT_MODE >= 2)
layout (rgba16f) uniform image3D voxelImg4;
#endif
#if VOXEL_CASCADES > 5 || RT_REFLECT_MODE >= 2
// voxelImg5 = per-BLOCK grid for PT reflections (fixed scale 1.0, block-level
// occupancy). VOXEL_CASCADES is capped at 5 to reserve this image.
layout (rgba16f) uniform image3D voxelImg5;
#endif

in vec2 texcoord;
in vec4 glcolor;
uniform int renderStage; // Iris render stage (used to keep entities out of the voxel grid)
in float matS;
in vec3 voxelPos;

void main() {
    vec4 texCol = texture2D(gtexture, texcoord);
    vec4 col = texCol * glcolor;
#if SHADOW_CUTOUT_FIX == 1
    // Alpha cutout on the TEXTURE alpha ALONE. If gl_Color.a is ~0 for entities or
    // the player in the Iris shadow pass, testing col.a (= tex.a * glcolor.a)
    // discards all their geometry and they cast no shadow at all.
    // Terrain/water/glass have glcolor.a = 1, so behavior is unchanged there.
    if (texCol.a < 0.1) discard;
#else
    if (col.a < 0.1) discard;   // fallback: original combined test
#endif

    // KNOWN LIMIT (LPV feeding, EMISSIVE_LPV): this pass rasterizes ONLY what
    // shadow.culling=true keeps - the view frustum EXTRUDED TOWARD THE SUN, not a
    // 360 deg disc (same dependency as lavaGlowAt and the RSM, documented at
    // shaders.properties:71-92). A light source outside that volume does NOT exist
    // in the voxel grid: a soul lantern a few blocks BEHIND the camera casts no
    // blue until you turn around (the surface falls back to the vanilla-orange
    // getTorchColor term, then the tint snaps in - same 'pop on rotation' family
    // as the RSM). Culled chunks are also absent as OCCLUDERS (EMPTY, not SOLID);
    // that leak stays contained because the additive term is gated by the vanilla
    // lightmap (lib/lighting.glsl, smoothstep(0.035, 0.10, lm.x)). Remedy if ever
    // wanted: shadow.culling=reversed + 'const float voxelDistance = 64.0;' in
    // lib/settings.glsl rasterizes everything within 64 blocks regardless of the
    // light axis - at a real shadow-pass cost in EVERY dimension, which is why it
    // is not the default (same call as the Nether note in shaders.properties).
    // Both lang tooltips carry the user-facing clause.
    // VOXELIZATION: 256^3 WORLD-ALIGNED grid, snapped to the camera BLOCK (anti-shimmer).
    // The SAME formula must be used on write (here), on GI read (composite5 marchVoxel)
    // and on debug read (composite6).
    // camBlock = integer camera block; (cameraPosition - camBlock*scale) is the sub-block
    // remainder, which keeps the floor() operand near the origin (no ULP blowup at far
    // world coordinates).
    // CLIPMAP: the voxel payload is computed ONCE, then written into EVERY cascade it
    // falls in, at scale s = VOXEL_SCALE * 2^i. camBlock and the remainder are RECOMPUTED
    // per cascade with ITS OWN s - never reuse another cascade's values, the snap origin
    // differs per scale. The shadow pass only rasterizes geometry within shadowDistance,
    // so only cells inside that range fill in; coarse cascades stay partially clear
    // beyond it (clear = 0 = miss, no occlusion).
    // CL_V3 (lib/settings.glsl): the LPV no longer feeds from this fragment-side
    // voxelization - shadow.vsh writes the per-block id grid (cl3VoxImg) instead,
    // fail-CLOSED for entities. The EMISSIVE_LPV terms of the three gates below are
    // therefore qualified with CL_V3 == 0: under CL_V3 this whole block only compiles
    // when the dormant PT paths (EMISSIVE_VOXEL / VOXEL_GI / RT_REFLECT_MODE >= 2)
    // need it, and the LPV-only fragment cost disappears.
    vec4 voxPayload;
#if EMISSIVE_VOXEL == 1 || RT_REFLECT_MODE >= 2 || (EMISSIVE_LPV == 1 && CL_V3 == 0)
// PT reflections: light-emitting blocks are voxelized as EMISSIVE, so sea lanterns
// and friends still glow in off-screen reflections (boosted by PT_REFLECT_EMISSIVE).
// Colored lights: the SAME classification feeds the LPV injection in composite.csh -
// the radiance is the FIXED per-family color of lib/cl_colors.glsl (torch != glowstone).
    // Material ids 17..24 are the emissive families (block.properties): 17 verdant,
    // 18 pale violet, 19 amber, 20 warm, 21 lava, 22 soul fire/sculk, 23 cold,
    // 24 amethyst. 26 = redstone torch (always); 27..38 are gated by their own
    // toggles. 25 (portal) is EXCLUDED by the range cut, water = 8 and foliage = 10
    // fall outside and keep plain albedo.
    // matS = mc_Entity.x from shadow.vsh. MUST match the on-screen test in
    // gbuffers_terrain.fsh.
    bool emissive =
           (matS > 16.5 && matS < 24.5)
        || (matS > 25.5 && matS < 26.5)
    #ifdef REDSTONE_BLOCK_GLOW
        || (matS > 26.5 && matS < 27.5)
    #endif
    #ifdef EMERALD_BLOCK_GLOW
        || (matS > 27.5 && matS < 28.5)
    #endif
    #ifdef DIAMOND_BLOCK_GLOW
        || (matS > 28.5 && matS < 29.5)
    #endif
    #ifdef GOLD_BLOCK_GLOW
        || (matS > 30.5 && matS < 31.5)
    #endif
    #ifdef IRON_BLOCK_GLOW
        || (matS > 31.5 && matS < 32.5)
    #endif
    #ifdef NETHERITE_BLOCK_GLOW
        || (matS > 32.5 && matS < 33.5)
    #endif
    #ifdef AMETHYST_BLOCK_GLOW
        || (matS > 33.5 && matS < 34.5)
    #endif
    #ifdef COPPER_BLOCK_GLOW
        || (matS > 34.5 && matS < 35.5)
    #endif
    #ifdef RAW_IRON_BLOCK_GLOW
        || (matS > 35.5 && matS < 36.5)
    #endif
    #ifdef RAW_GOLD_BLOCK_GLOW
        || (matS > 36.5 && matS < 37.5)
    #endif
    #ifdef RAW_COPPER_BLOCK_GLOW
        || (matS > 37.5 && matS < 38.5)
    #endif
        ;
    if (emissive) {
        // eMask: ONLY the bright parts of the texture emit (flame yes, torch stick no;
        // lantern glass yes, frame no) - it is the block's STATE gate (unlit redstone
        // lamps, bare cave vines and idle sculk read dark and do not emit), floored per
        // family by clMaskFloor for textures too dark for the mask (lava crust,
        // redstone torch head, metal blocks - those floors are all > 0.5, so the gate
        // below keeps them emitting on every texel). luma() is inlined here because
        // this pass does not include the lighting lib.
        float lum   = dot(col.rgb, vec3(0.2126, 0.7152, 0.0722));
        float eMask = max(smoothstep(0.30, 0.80, lum), clMaskFloor(matS));
        // Emitted radiance = FIXED per-family light color (lib/cl_colors.glsl) at FULL
        // strength, gated (not scaled) by the mask. The texture albedo is deliberately
        // NOT part of the color (sampling it made the cast light brown-ish and the
        // races + animated textures made the hue dance), and the mask is deliberately
        // NOT a multiplier any more: a per-texel intensity made fragments of the SAME
        // block write DIFFERENT values, so the non-atomic own-cell store + dilation
        // races still decided INTENSITY (a dark texel could claim a halo cell, or
        // overwrite the bright own-cell write) - a few percent of frame-to-frame
        // wobble carried to screen by the additive CL_STRENGTH term. With a binary
        // gate every EMITTING fragment writes the IDENTICAL vec4, so the race is a
        // genuine no-op; dark texels voxelize as the solid they look like (also more
        // correct for the torch stick). Intensity and range on screen stay driven by
        // the vanilla lightmap: the TINT changes, never the reach ("colore vanilla").
        if (eMask > 0.5)
            voxPayload = vec4(clLightColor(matS) * EMISSIVE_VOXEL_STRENGTH, 2.0); // alpha = 2 -> EMISSIVE, rgb = radiance
        else
            voxPayload = vec4(col.rgb, 1.0);  // dark texel: plain solid (stick, frame)
    } else {
        voxPayload = vec4(col.rgb, 1.0);  // block albedo, alpha = 1 -> solid
    }
#else
    voxPayload = vec4(col.rgb, 1.0); // albedo only, alpha = 1 -> solid
#endif

    // ---- Write policy: emissive priority + dilation (EMISSIVE_VOXEL_FILL) ----
    // STORE_VOXEL replaces the bare imageStore of EVERY cascade. The cell formula is
    // UNCHANGED (computed per cascade right before the call), so nothing desyncs from
    // sampleClip (composite5) or the LPV. It is a MACRO rather than a function taking an
    // image3D parameter (the least portable construct in 430 compatibility), so it inlines
    // per image. The body is wrapped in do { ... } while(false) so it behaves as a single
    // STATEMENT at the call site.
    //  OFF: plain bounds-checked imageStore, behavior identical to the simple version.
    //  ON : (a) an ALBEDO payload does NOT overwrite a cell that is already emissive
    //           (a > 1.5);
    //       (b) an EMISSIVE payload writes its cell THEN dilates into the 1-voxel halo,
    //           but ONLY into EMPTY cells (a < 0.5) -> fills the block's 2x2x2 and emits
    //           on all sides without turning an adjacent solid wall into a light source.
    // ON is also gated on EMISSIVE_VOXEL==1 OR EMISSIVE_LPV==1: a = 2.0 payloads exist in
    // LPV-only mode too and must keep priority and dilation. With both off, voxPayload.a
    // is always 1.0 and there is no emissive cell to protect, so the bare store is used
    // and no imageLoad is wasted.
    // NOTE: imageLoad/imageStore are NOT atomic across concurrent fragments, so this is a
    // statistical best effort, not a guarantee; the grid is re-voxelized every frame and
    // temporal accumulation smooths the residual.
    // COST per fragment and PER active cascade (cascade 0 only in LPV-only mode):
    // +1 imageLoad for an ALBEDO fragment; for EMISSIVE, EMI_N imageLoad and up to
    // EMI_N+1 imageStore (EMI_N = 6 or 26 depending on EMISSIVE_FILL_RADIUS; the 3x3x3
    // stamp is the active default).
#if EMISSIVE_VOXEL_FILL == 1 && (EMISSIVE_VOXEL == 1 || (EMISSIVE_LPV == 1 && CL_V3 == 0))
#if EMISSIVE_FILL_RADIUS == 1
    // 3x3x3 stamp (26 neighbors): covers the block's full 2x2x2 plus a SYMMETRIC 1-voxel
    // halo (faces AND diagonals), so E/W cells get seeded even when only the top or bottom
    // face is rasterized.
    const ivec3 EMI_OFF[26] = ivec3[26](
        ivec3(-1,-1,-1), ivec3( 0,-1,-1), ivec3( 1,-1,-1),
        ivec3(-1, 0,-1), ivec3( 0, 0,-1), ivec3( 1, 0,-1),
        ivec3(-1, 1,-1), ivec3( 0, 1,-1), ivec3( 1, 1,-1),
        ivec3(-1,-1, 0), ivec3( 0,-1, 0), ivec3( 1,-1, 0),
        ivec3(-1, 0, 0),                  ivec3( 1, 0, 0),
        ivec3(-1, 1, 0), ivec3( 0, 1, 0), ivec3( 1, 1, 0),
        ivec3(-1,-1, 1), ivec3( 0,-1, 1), ivec3( 1,-1, 1),
        ivec3(-1, 0, 1), ivec3( 0, 0, 1), ivec3( 1, 0, 1),
        ivec3(-1, 1, 1), ivec3( 0, 1, 1), ivec3( 1, 1, 1));
    #define EMI_N 26
#else
    const ivec3 EMI_OFF[6] = ivec3[6](
        ivec3( 1, 0, 0), ivec3(-1, 0, 0), ivec3( 0, 1, 0),
        ivec3( 0,-1, 0), ivec3( 0, 0, 1), ivec3( 0, 0,-1));
    #define EMI_N 6
#endif
    #define IN_GRID(c) (all(greaterThanEqual((c), ivec3(0))) && all(lessThan((c), ivec3(256))))
    #define STORE_VOXEL(IMG, CELL, PAY) do { \
        if (IN_GRID(CELL)) { \
            if ((PAY).a > 1.5) { \
                imageStore(IMG, (CELL), (PAY)); \
                for (int _k = 0; _k < EMI_N; ++_k) { \
                    ivec3 _nc = (CELL) + EMI_OFF[_k]; \
                    if (IN_GRID(_nc)) { \
                        vec4 _ex = imageLoad(IMG, _nc); \
                        if (_ex.a < 0.5) imageStore(IMG, _nc, (PAY)); \
                    } \
                } \
            } else { \
                vec4 _cur = imageLoad(IMG, (CELL)); \
                if (_cur.a < 1.5) imageStore(IMG, (CELL), (PAY)); \
            } \
        } \
    } while (false)
#else
    #define STORE_VOXEL(IMG, CELL, PAY) do { if (all(greaterThanEqual((CELL), ivec3(0))) && all(lessThan((CELL), ivec3(256)))) imageStore(IMG, (CELL), (PAY)); } while (false)
#endif

#if VOXEL_GI == 1 || RT_REFLECT_MODE >= 2 || (EMISSIVE_LPV == 1 && CL_V3 == 0)
    // PT reflections (mode 2): voxelization also runs for off-screen reflections
    // (composite1 / lib/voxelray.glsl reads these cascades).
    // Colored lights (EMISSIVE_LPV=1 without PT, LEGACY CL_V3=0 chain only - the CL3
    // rebuild feeds from shadow.vsh/cl3VoxImg instead): voxelization runs to feed the LPV
    // injection (composite.csh reads cascade 0). Cascades > 0 and the block grid
    // voxelImg5 are NOT written in that mode - the PT gates below keep the cost out.
    // TRANSLUCENTS ARE NOT VOXELIZED: water (8) voxelized as solid makes PT rays that
    // start on the surface hit neighboring water voxels (blue mush); glass (30) and
    // portal (25) would block windows in reflections.
    // THICKNESS DILATION: a rasterized face only fills a half-voxel shell, so a march
    // step could pass THROUGH a 1-block wall (crumbling walls, outdoor light leaking
    // into a sealed room). The cell one step BEHIND the face is written too (geometric
    // normal from derivatives), giving a ~1 block thick shell and no leaks.
    vec3 nrmVx = normalize(cross(dFdx(voxelPos), dFdy(voxelPos)));
    vec3 voxelPosIn = voxelPos - nrmVx * max(VOXEL_SCALE * 0.9, 0.30);
    // BLOCKS ONLY: entities and block entities are NOT voxelized (no ghost player in
    // mirrors). This is an EXCLUSION list and fails open: if renderStage never changes
    // during the shadow pass, we fall back to voxelizing everything, never to an
    // empty grid.
    bool vxEntity = (renderStage == MC_RENDER_STAGE_ENTITIES
                  || renderStage == MC_RENDER_STAGE_BLOCK_ENTITIES);
    bool vxSkip = vxEntity
               || (matS > 7.5 && matS < 8.5) || (matS > 24.5 && matS < 25.5)
               || (matS > 29.5 && matS < 30.5);
    if (!vxSkip) {
#if RT_REFLECT_MODE >= 2
    // BLOCK GRID (voxelImg5, s = 1.0 FIXED): position ROUNDED TO THE BLOCK, so ONE
    // fragment is enough to mark the WHOLE block - no holes, no flicker, no leaks,
    // whatever the shadow map density. The -nrmVx*0.05 nudge keeps a fragment sitting
    // exactly on a face from landing in the neighboring AIR block. The finer cascades
    // below only carry COLOR (texture detail).
    {
        ivec3 camBlockB = ivec3(floor(cameraPosition));
        ivec3 cellB = ivec3(floor(voxelPos - nrmVx * 0.05 + (cameraPosition - vec3(camBlockB)))) + 128;
        // Anti-flicker: (1) QUANTIZED color, so all fragments of one face converge to
        // the same value and the write race becomes invisible; (2) TOP faces get
        // priority (a = 1.2), making the block color deterministic frame to frame
        // (a grass block no longer alternates green/brown). Emissive (a = 2) still wins.
        vec4 payB = voxPayload;
        if (payB.a < 1.5) {
            payB.rgb = floor(payB.rgb * 12.0 + 0.5) / 12.0;
            if (nrmVx.y > 0.6) payB.a = 1.2;
        }
        if (all(greaterThanEqual(cellB, ivec3(0))) && all(lessThan(cellB, ivec3(256)))) {
            vec4 curB = imageLoad(voxelImg5, cellB);
            if (curB.a < 1.1 || payB.a > 1.1) imageStore(voxelImg5, cellB, payB);
        }
    }
#endif
    // Cascade 0 (s = VOXEL_SCALE): identical formula to the single-grid version.
    {
        float s = VOXEL_SCALE;
        ivec3 camBlock = ivec3(floor(cameraPosition / s));
        ivec3 cell = ivec3(floor((voxelPos + (cameraPosition - vec3(camBlock) * s)) / s)) + 128;
        STORE_VOXEL(voxelImg, cell, voxPayload);
        ivec3 cellIn = ivec3(floor((voxelPosIn + (cameraPosition - vec3(camBlock) * s)) / s)) + 128;
        if (any(notEqual(cellIn, cell))) STORE_VOXEL(voxelImg, cellIn, voxPayload);
    }
#if VOXEL_CASCADES > 1 && (VOXEL_GI == 1 || RT_REFLECT_MODE >= 2)
    {
        float s = VOXEL_SCALE * 2.0;
        ivec3 camBlock = ivec3(floor(cameraPosition / s));
        ivec3 cell = ivec3(floor((voxelPos + (cameraPosition - vec3(camBlock) * s)) / s)) + 128;
        STORE_VOXEL(voxelImg1, cell, voxPayload);
        ivec3 cellIn = ivec3(floor((voxelPosIn + (cameraPosition - vec3(camBlock) * s)) / s)) + 128;
        if (any(notEqual(cellIn, cell))) STORE_VOXEL(voxelImg1, cellIn, voxPayload);
    }
#endif
#if VOXEL_CASCADES > 2 && (VOXEL_GI == 1 || RT_REFLECT_MODE >= 2)
    {
        float s = VOXEL_SCALE * 4.0;
        ivec3 camBlock = ivec3(floor(cameraPosition / s));
        ivec3 cell = ivec3(floor((voxelPos + (cameraPosition - vec3(camBlock) * s)) / s)) + 128;
        STORE_VOXEL(voxelImg2, cell, voxPayload);
        ivec3 cellIn = ivec3(floor((voxelPosIn + (cameraPosition - vec3(camBlock) * s)) / s)) + 128;
        if (any(notEqual(cellIn, cell))) STORE_VOXEL(voxelImg2, cellIn, voxPayload);
    }
#endif
#if VOXEL_CASCADES > 3 && (VOXEL_GI == 1 || RT_REFLECT_MODE >= 2)
    {
        float s = VOXEL_SCALE * 8.0;
        ivec3 camBlock = ivec3(floor(cameraPosition / s));
        ivec3 cell = ivec3(floor((voxelPos + (cameraPosition - vec3(camBlock) * s)) / s)) + 128;
        STORE_VOXEL(voxelImg3, cell, voxPayload);
        ivec3 cellIn = ivec3(floor((voxelPosIn + (cameraPosition - vec3(camBlock) * s)) / s)) + 128;
        if (any(notEqual(cellIn, cell))) STORE_VOXEL(voxelImg3, cellIn, voxPayload);
    }
#endif
#if VOXEL_CASCADES > 4 && (VOXEL_GI == 1 || RT_REFLECT_MODE >= 2)
    {
        float s = VOXEL_SCALE * 16.0;
        ivec3 camBlock = ivec3(floor(cameraPosition / s));
        ivec3 cell = ivec3(floor((voxelPos + (cameraPosition - vec3(camBlock) * s)) / s)) + 128;
        STORE_VOXEL(voxelImg4, cell, voxPayload);
        ivec3 cellIn = ivec3(floor((voxelPosIn + (cameraPosition - vec3(camBlock) * s)) / s)) + 128;
        if (any(notEqual(cellIn, cell))) STORE_VOXEL(voxelImg4, cellIn, voxPayload);
    }
#endif
#if VOXEL_CASCADES > 5 && (VOXEL_GI == 1 || RT_REFLECT_MODE >= 2)
    {
        float s = VOXEL_SCALE * 32.0;
        ivec3 camBlock = ivec3(floor(cameraPosition / s));
        ivec3 cell = ivec3(floor((voxelPos + (cameraPosition - vec3(camBlock) * s)) / s)) + 128;
        STORE_VOXEL(voxelImg5, cell, voxPayload);
        ivec3 cellIn = ivec3(floor((voxelPosIn + (cameraPosition - vec3(camBlock) * s)) / s)) + 128;
        if (any(notEqual(cellIn, cell))) STORE_VOXEL(voxelImg5, cellIn, voxPayload);
    }
#endif
    } // !vxSkip (translucents are not voxelized)
#endif

    // Water tag in the shadowcolor0 alpha (used by caustics). Emissive blocks included:
    // the tinted radiance does NOT overwrite col.rgb in shadowcolor0.
    float isWaterS = (matS > 7.5 && matS < 8.5) ? 1.0 : 0.0;
#if SHADOW_TEX1_GATE_FIX == 1
    // BLEND-ROBUST RGB TAG. The 3-state alpha tag was destroyed even with blend.shadow=off
    // (tex0-only texels read back as ~1.0, so light tints became invisible and chickens or
    // saplings cast no shadow). Under an active SRC_ALPHA / ONE_MINUS_SRC_ALPHA blend, only
    // an alpha = 1.0 write survives intact (rgb_out = rgb_src, a_out = 1). So alpha is
    // ALWAYS 1.0 and the 3-state tag moves into disjoint RGB bands (color compressed x0.30):
    //   WATER [0.00..0.30] = rgb*0.30        (caustics + blue tint)
    //   GLASS [0.35..0.65] = rgb*0.30 + 0.35 (glass 30 / portal 25 -> colored shadow)
    //   SOLID [0.70..1.00] = rgb*0.30 + 0.70 (opaque/cutout/entity -> full occlusion)
    // FAIL-SAFE: the default shadowcolor0 clear is WHITE (1.0) = the SOLID band, so a texel
    // present in shadowtex0 whose color write does not land still occludes.
    // Receiver-side classification uses max(rgb): < 0.325 water, < 0.675 glass, else solid
    // (margins >= 6 RGBA8 steps). Decode with (rgb - offset) / 0.30.
    bool isTintS = (matS > 29.5 && matS < 30.5) || (matS > 24.5 && matS < 25.5);
    float tagOff = (isWaterS > 0.5) ? 0.0 : (isTintS ? 0.35 : 0.70);
    gl_FragData[0] = vec4(clamp(col.rgb, 0.0, 1.0) * 0.30 + tagOff, 1.0);
#else
    gl_FragData[0] = vec4(col.rgb, isWaterS);
#endif

#if DIMENSION_FX == 1
    // NETHER LAVA HEIGHT MAP (DIMENSION_FX): in the Nether the sun/moon term is
    // off (lib/lighting.glsl getLightColor) and the shadow map is free, so only
    // the HOT EMITTERS keep their depth - lava family 21 at full weight, warm
    // family 20 (lantern, fire, campfire, magma) and amber family 19
    // (glowstone, shroomlight - ex-20 members, both common in the Nether)
    // x0.35, soul family 22 x0.25, FIXED tints (animated lava would flicker) -
    // and every other fragment is pushed to the far plane. shadowtex0 then
    // holds the topmost emitter of each light column (1.0 = none) and
    // shadowcolor0 its weighted tint, read by lavaGlowAt (surfaces + both VL
    // marches). The voxel writes above are untouched. Other dimensions keep
    // the normal map (no depth write here, early-z preserved everywhere).
    if (dimNether() > 0.5) {
        vec3 hotTint = vec3(0.0);
        if      (matS > 20.5 && matS < 21.5) hotTint = vec3(1.00, 0.42, 0.10);        // 21 lava
        else if (matS > 19.5 && matS < 20.5) hotTint = vec3(0.35, 0.25, 0.12);        // 20 warm x0.35
        else if (matS > 18.5 && matS < 19.5) hotTint = vec3(0.35, 0.26, 0.10);        // 19 amber x0.35 (glowstone/shroomlight, ex-family 20: keeps the Nether glow map)
        else if (matS > 21.5 && matS < 22.5) hotTint = vec3(0.09, 0.21, 0.25);        // 22 soul x0.25
        if (hotTint.r > 0.0) gl_FragData[0] = vec4(hotTint, 1.0);
        else discard; // depth stays at the far plane: same height map as a gl_FragDepth=1.0 push
    }
#endif

#if defined PHYSICS_OCEAN && PHYSICS_FIELD_SYNC == 1
    // ===== PHYSICS_FIELD_SYNC : BATTEMENT DU PASS OMBRE =====================
    // Le pass ombre rasterise l'ocean du mod meme quand la surface n'est pas a
    // l'ecran (frustum extrude vers le soleil) : c'est LUI qui garde le canal
    // vivant en plongee ou camera vers le fond, la ou l'ecriture gbuffer
    // manque. Il ecrit UNIQUEMENT physOceanParams : l'estampille par pixel n'a
    // aucun sens ici (gl_FragCoord est en espace shadow map).
    // ORDRE DANS LA FRAME : ombre puis gbuffer, donc quand la surface EST a
    // l'ecran c'est l'ecriture gbuffer qui l'emporte - la waviness publiee est
    // alors celle d'un fragment visible, ce qui est le bon choix.
    // Meme sous-echantillonnage 1/16 et meme course benigne que cote gbuffer.
    if (isWaterS > 0.5
        && fract(gl_FragCoord.x * 0.25) < 0.25 && fract(gl_FragCoord.y * 0.25) < 0.25) {
        imageStore(physOceanParams, ivec2(0, 0),
                   vec4(physics_gameTime, physics_oceanHeight,
                        physics_oceanWaveHorizontalScale, float(frameCounter)));
        imageStore(physOceanParams, ivec2(1, 0),
                   vec4(vlxPhysDriftV, vlxPhysWavV, float(physics_iterationsNormal)));
#if PHYS_REAL == 1
        // Parametres de la carte de rides (memes valeurs que cote gbuffer).
        float vlxRipTS = float(textureSize(physics_ripples, 0).x);
        float vlxNsd = min(max((physics_rippleRange * 2.0) / max(vlxRipTS, 1.0),
                               0.001),
                           PHYSICS_RIPPLE_NORMAL_SAMPLE_WORLD_DISTANCE);
        imageStore(physRipParams, ivec2(0, 0),
                   vec4(vlxRipTS, physics_rippleRange, vlxNsd, float(frameCounter)));
        imageStore(physRipParams, ivec2(1, 0), vec4(vlxPhysRipCV, 0.0, 0.0));
        // UN texel par fragment ecrivain (donc 1 fragment sur 16) : le pass
        // ombre a beaucoup plus de fragments que l'ecran (shadowMapResolution^2
        // = 16.8 M a SHADOW_QUALITY 3), donc un seul texel suffit largement -
        // un ocean qui couvre tout le pass recopie la carte en 1 frame
        // (pr_m4.py D). Meme index tournant que cote gbuffer, sur l'index
        // COMPACTE de la grille 4x4.
        ivec2 vlxSC = ivec2(gl_FragCoord.xy) / 4;
        uint vlxRMask = uint(PHYS_REAL_RIPN * PHYS_REAL_RIPN - 1);
        uint vlxSB = (uint(vlxSC.y * (shadowMapResolution / 4) + vlxSC.x)
                      + uint(frameCounter) * uint(PHYS_REAL_ROT)) & vlxRMask;
        ivec2 vlxSD = ivec2(int(vlxSB) & (PHYS_REAL_RIPN - 1),
                            int(vlxSB) / PHYS_REAL_RIPN);
        vec2 vlxSUV = (vec2(vlxSD) + 0.5) * (1.0 / float(PHYS_REAL_RIPN));
        imageStore(physRipple, vlxSD,
                   vec4(texture(physics_ripples, vlxSUV).r, 0.0, 0.0, 0.0));
#endif
    }
#endif
}
