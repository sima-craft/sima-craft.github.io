#version 430 compatibility
// 430 compatibility: required for imageLoad (PT reflections). The
// compatibility profile keeps varying/texture2D/gl_FragData.
/*
    composite1 - atmosphere, water and glass pass.
    Reads:  colortex0 (scene), colortex1 (normals), colortex2 (material data),
            colortex4 (GI / screen-space lights), colortex5 (albedo/biome tint),
            colortex6 (AO), colortex11 (PBR), colortex7 (previous TAA frame,
            SSR_PREV_FRAME only), depthtex0/1, shadowtex0/1, shadowcolor0.
    Writes: colortex0 (+ colortex5 under DEBUG_VIEW >= 23).
    Covers: water body/reflections/caustics/foam, glass, nether portal,
    opaque AO + PBR reflections, fog layers, unified volumetric light.
*/

#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/water_sky_tint.glsl"
#include "/lib/distort.glsl"
#include "/lib/biome.glsl"
#include "/lib/dimension.glsl"
#include "/lib/lighting.glsl"
#include "/lib/atmosphere.glsl"
// PHYSICS_FIELD_SYNC (lib/settings.glsl) : ce programme est l'un des deux
// CONSOMMATEURS du champ republie par l'ocean de PHYSICS MOD PRO. Le marqueur
// materialise le bloc vlxPhys* de lib/water.glsl ; les autres includeurs de
// water.glsl (gbuffers_water, les wrappers physics) ne le posent pas et
// restent textuellement inchanges.
// PHYS_REAL : la carte de rides recopiee est lue DANS lib/water.glsl
// (vlxPhysRipRaw), donc son sampler doit etre declare AVANT l'include. La
// condition est mot pour mot celle du VLX_PHYS_REAL de lib/water.glsl (ce
// fichier pose VLX_PHYS_CONSUMER juste apres) : aucune declaration ne peut se
// retrouver orpheline de son usage, ni l'inverse.
#if PHYSICS_MOD_SUPPORT == 1 && PHYSICS_FIELD_SYNC == 1 && PHYS_REAL == 1
uniform sampler2D physRippleSampler;
#endif
#define VLX_PHYS_CONSUMER
#include "/lib/water.glsl"
#include "/lib/blackhole.glsl"
#include "/lib/sky.glsl"
#include "/lib/clouds.glsl"
#include "/lib/end_storm.glsl"

// Per-pixel light colors: computed ONCE at the top of main(), read everywhere
// else. They MUST be declared here, OUTSIDE any #if block -- inside the
// RT_REFLECT_MODE >= 2 block they disappear from the default build, and below
// ptShadeVoxel the PT path stops compiling. Only this position serves both.
vec3 gLightC;
vec3 gAmbC;
/* ===================== WCOL - WATER COLOUR MODEL (V2) =====================
   WATER_COLOR_V2 picks the constant set every water-colour site in this file
   reads: waterColumn() (open water and the water a glass pane hides), the
   horizon sky floor, the eye-submerged fog block, the total-internal-
   reflection fallback and the two culled-water-face columns. At 0 every
   constant below holds its previous value, so the whole pass is BIT-IDENTICAL
   to the build before this model landed. Both branches declare every symbol,
   so nothing here can disappear from a build.

   ---- ABSORPTION IS MEASURED, NOT CHOSEN --------------------------------
   The absorption coefficient of water is published laboratory data, so the V2
   numbers are read off a spectrum instead of dialled in by eye:
     * PURE WATER a_w -- Pope & Fry 1997, "Absorption spectrum (380-700 nm) of
       pure water. II. Integrating cavity measurements", Applied Optics
       36(33):8710. Sampled at the dominant wavelengths of the sRGB primaries
       (R 611 nm, G 549 nm, B 465 nm): a_w = (0.291, 0.063, 0.0102) 1/m.
     * DISSOLVED ORGANICS (CDOM, "yellow substance") -- the standard
       exponential a_g(L) = a_g(440) * exp(-S * (L - 440)) with S = 0.014 1/nm,
       Bricaud, Morel & Prieur 1981, Limnology & Oceanography 26(1):43. A
       clear-coastal a_g(440) = 0.03 1/m adds (0.0027, 0.0065, 0.0211) 1/m.
   Seen from OUTSIDE the pack uses water + CDOM: (0.2937, 0.0695, 0.0313) 1/m,
   ratio R:G:B = 9.4 : 2.2 : 1. Seen from INSIDE it uses the pure-water
   spectrum alone (open ocean, Jerlov type I), ratio 28.5 : 6.2 : 1 -- blue is
   almost not absorbed at all, which is why distant submerged terrain keeps
   its contrast and simply loses its warm channels.

   ---- THE TWO SCALES ARE THE ARTISTIC PART ------------------------------
   A Minecraft block is nominally a metre, but a metre of real coastal water is
   far clearer than a 3-block pond needs to read. Two deliberately different
   "metres of water per block" scales are applied to the measured spectrum, and
   they are the only liberty taken with it:
     OUT x1.36  -- criterion: the floor is crisp through 1 block of view path,
                   half dissolved near 3.4, unreadable past ~7. That range is
                   what sets this number, nothing else.
                   k = (0.399, 0.095, 0.043) per block
                   (per-block transmittance R 0.671 / G 0.909 / B 0.958).
     UW  x0.315 -- criterion: red ~60% gone at 10 blocks and distant terrain
                   still READABLE at 40, i.e. the Secchi range of genuinely
                   clear water. k = (0.0916, 0.0198, 0.0032) per block.
   Surviving floor share (absorption x veil) along the OUT path:
     1 block (0.55, 0.74, 0.78)   3 blocks (0.17, 0.41, 0.48)
     6 blocks (0.03, 0.17, 0.23)  10 blocks (0.00, 0.05, 0.09)
   -> a breath of teal at 1 block, silhouettes only past 6-7, gone by 8.

   ---- IN-SCATTER CHROMA IS A STYLE CHOICE, WITH ONE HARD CRITERION ------
   The veil colour is not measured, it is chosen. Its SHAPE is physical: pure
   water scatters on a Rayleigh-like power law b(L) ~ L^-4.32 (Morel 1974,
   "Optical properties of pure water and pure sea water"), which over the
   absorption above leaves a red/blue ratio near 0.04 -- red is essentially
   absent from the veil. Its GREEN is taste: the single-scatter ratio alone
   reads as ink, so green is lifted to 0.55 of blue and the volume reads as
   sea teal instead.
   THE HARD CRITERION, and the reason this is not merely "make it bluer": the
   V2 chroma carries the SAME Rec.709 LUMINANCE as the desaturated slate it
   replaces (0.3583 for the WATER_FOG_BLUE = 1 endpoint, 0.1281 submerged,
   0.3142 for the shared submerged constant). Switching V2 on rotates the HUE
   and leaves the brightness of the water alone. The "milky powder-blue" that
   was rejected repeatedly came from LUMINANCE, not from saturation, and it
   cannot come back in through THIS door.
   WHAT THE CRITERION DOES NOT COVER, stated because it is the honest half: it
   holds on the CHROMA CONSTANT, not on the delivered pixel. k_G fell from
   0.176 to 0.095 and k_B from 0.092 to 0.043, so more BACKGROUND survives the
   column and the water reads brighter at mid depths even though the veil's own
   luminance did not move. DELIVERED luminance budget, V2 minus legacy, against
   a sand floor (HDR 1.55/1.35/0.95, noon, open sky):
     1 block +6.6%   2 +13.7%   3 +20.6%   4 +26.4%
     6 +32.4% (peak) 8 +29.5%  10 +22.1%
   Submerged it is not a percentage but two orders of magnitude: at 12 blocks
   down and 20 blocks of view, legacy delivered ~(0.0007, 0.0022, 0.0029) - a
   black wall - and V2 delivers (0.112, 0.435, 0.460). That is the intended
   change, but it IS a change in brightness and it is written down here.
   IF IT READS TOO BRIGHT ON SCREEN the two dials that move it are
   WATER_SCATTER_DARKEN (0.80) out of the water and UW_FOG_BRIGHT (1.0)
   submerged. NOT WATER_FOG_BLUE: that one slides the chroma toward neutral
   gray at constant luminance, so it is the dial for "too saturated" and never
   the dial for "too bright". UW_FOG_DESAT is its submerged twin (see below).
*/
#if WATER_COLOR_V2 == 1
    // Out-of-water column
    const vec3  WCOL_K_OUT      = vec3(0.399, 0.095, 0.043);
    const vec3  WCOL_TURB_K     = vec3(0.35, 0.16, 0.30);
    const float WCOL_TURB_W     = WATER_TURBIDITY;
    const vec3  WCOL_SCAT_GRAY  = vec3(0.36);
    const vec3  WCOL_SCAT_BLUE  = vec3(0.038, 0.414, 0.752);
    const float WCOL_TORCH      = 0.055 * WATER_TORCH_SCATTER;
    // Horizon sky floor: much lighter (0.62 -> 0.30) so far water stays a
    // mirror instead of a milky sheet, and far more of the sky CHROMA is kept
    // (0.50 -> 0.85) so a sunset ocean stays warm instead of going gray.
    const float WCOL_HZ_STR     = 0.30;
    const float WCOL_HZ_CHROMA  = 0.85;
    const vec3  WCOL_HZ_FILT    = vec3(0.30, 0.46, 0.60);
    // Eye-submerged column: ONE chroma, no depth staging (depth changes how
    // MUCH light there is, not what colour the water is), flat veil rate
    // (half opacity at 25 blocks) and a far gentler geometric darkening.
    // THE PRICE OF COLLAPSING THE THREE STAGES, measured rather than assumed:
    // the legacy staging was also draining SATURATION with depth, and that
    // drain went with it. At 12 blocks down and 20 blocks of view the
    // DELIVERED max/min channel ratio is 4.3 under V2 against 1.33 under
    // legacy (which turned toward a neutral grey-green), so the far submerged
    // image lands almost entirely on this one saturated hue - and the shipped
    // WATER_FOG_DENSITY 1.5 profile brings that wall 1.5x closer (half opacity
    // at 16.7 blocks, not 25). This is the ONE place "too blue" can genuinely
    // come back; out of the water slateC is R/B 0.124, G/B 0.586, a marine
    // blue with a real green shoulder, which is the opposite of powder-blue.
    // UW_FOG_DESAT puts the drain back as a single dial, at constant Rec.709
    // luminance so it costs nothing in brightness. See the fogBaseC site.
    const vec3  WCOL_K_UW       = vec3(0.0916, 0.0198, 0.0032);
#if WCOL_V3 == 1
    // EAU4 -- ONE MEDIUM, ONE CHROMA. These four constants paint the water
    // seen from INSIDE; slateC (below) paints the SAME water seen from
    // OUTSIDE. V3 rotated slateC and left this half exactly where V2 put it,
    // so the pack was painting one lake in two colours in the same frame:
    // 208.4 deg of hue from inside against 223.1 deg from outside, and 0.950
    // of saturation against 0.885. They now carry the IDENTICAL chroma
    // (R/B 0.0964, G/B 0.5418, hue 210.4 deg) at the SAME Rec.709 luminance
    // these constants always had (0.1281), so the harmonisation costs exactly
    // nothing in brightness. Derivation and measurement: the EAU4 block below.
    // EAU5: the ONE chroma is now the WATER_TINT palier (lib/settings.glsl).
    // WT_UWC_* is this exact triple rotated in hue at constant Rec.709 luminance
    // (0.1281) and constant HSV saturation (0.904); WATER_TINT 2 restores the
    // literals above bit-for-bit.
    const vec3  WCOL_UW_SHALLOW = vec3(WT_UWC_R, WT_UWC_G, WT_UWC_B);
    const vec3  WCOL_UW_MID     = vec3(WT_UWC_R, WT_UWC_G, WT_UWC_B);
    const vec3  WCOL_UW_DEEP    = vec3(WT_UWC_R, WT_UWC_G, WT_UWC_B);
    const vec3  WCOL_UW_TIR     = vec3(WT_UWC_R, WT_UWC_G, WT_UWC_B);
#else
    const vec3  WCOL_UW_SHALLOW = vec3(0.0134, 0.1479, 0.2689);
    const vec3  WCOL_UW_MID     = vec3(0.0134, 0.1479, 0.2689);
    const vec3  WCOL_UW_DEEP    = vec3(0.0134, 0.1479, 0.2689);
    const vec3  WCOL_UW_TIR     = vec3(0.0134, 0.1479, 0.2689);
#endif
    const float WCOL_UW_DENS    = 0.040;
    const float WCOL_UW_DARK    = 0.30;
#if WCOL_V3 == 1
    // EAU4: the same chroma once more, at this constant's own luminance
    // (0.3142). SCAT_UW_BASE reads it, i.e. the water a GLASS PANE hides and
    // the two CULLED-water-face columns -- all three drawn with the eye OUT of
    // the water, immediately beside a real water surface running slateC. Under
    // V3 that neighbour pair differed by 14.7 deg of hue and 6.5 points of
    // saturation, which is how the submerged palette leaked into the view from
    // outside. Now zero.
    // EAU5: same WATER_TINT rotation, at this constant's own luminance (0.3142)
    // -- so the glass column and the culled faces keep landing on the SAME hue
    // as slateC whatever the palier. WATER_TINT 2 = vec3(0.0631, 0.3545, 0.6540).
    const vec3  WCOL_SCAT_UW    = vec3(WT_GLASS_R, WT_GLASS_G, WT_GLASS_B);
#else
    const vec3  WCOL_SCAT_UW    = vec3(0.0330, 0.3629, 0.6599);
#endif
    // Veil rate, DERIVED FROM OUR OWN WCOL_K_OUT rather than picked: the veil
    // reaches half opacity exactly where the floor's RED has fallen to a
    // quarter of its surface value, i.e. where the image has visibly lost its
    // warm content. ln(4) / 0.399 = 3.47 blocks -> rate 1/3.47 = 0.288.
    // (Legacy shipped a hand-set 0.29; the two are within 0.7%, which is why
    // this is documented as a re-derivation and not sold as a new look.)
    const float WCOL_VEIL_RATE  = 0.288;
#else
    const vec3  WCOL_K_OUT      = vec3(0.405, 0.176, 0.092);
    const vec3  WCOL_TURB_K     = vec3(0.35, 0.16, 0.30);
    const float WCOL_TURB_W     = 1.0;
    const vec3  WCOL_SCAT_GRAY  = vec3(0.36);
    const vec3  WCOL_SCAT_BLUE  = vec3(0.22, 0.38, 0.55);
    const float WCOL_TORCH      = 0.055;
    const float WCOL_HZ_STR     = 0.62;
    const float WCOL_HZ_CHROMA  = 0.50;
    const vec3  WCOL_HZ_FILT    = vec3(0.36, 0.48, 0.56);
    const vec3  WCOL_K_UW       = vec3(0.0);
    const vec3  WCOL_UW_SHALLOW = vec3(0.030, 0.155, 0.150);
    const vec3  WCOL_UW_MID     = vec3(0.006, 0.040, 0.048);
    const vec3  WCOL_UW_DEEP    = vec3(0.0006, 0.0040, 0.0060);
    const vec3  WCOL_UW_TIR     = vec3(0.0007, 0.0052, 0.0085);
    const float WCOL_UW_DENS    = 0.080;
    const float WCOL_UW_DARK    = 0.84;
    const vec3  WCOL_SCAT_UW    = vec3(0.19, 0.42, 0.72) * 0.80;
    const float WCOL_VEIL_RATE  = 0.29;
#endif
/* ============ WCOL_V3 (EAU3) - WHAT WAS ACTUALLY WRONG, AND THE NUMBERS =====
   Report: "the water has NOTHING to do with the reference" -- a milky, almost
   UNIFORM light blue, no depth gradient, a washed-out bottom, one smooth
   specular streak. The reference: turquoise-green near-transparent shallows
   over sand, a sustained blue-green middle, a deep SATURATED navy offshore,
   and a fine GRAINY sun sparkle.

   ---- THE DIAGNOSIS WAS MEASURED, AND IT IS NOT WHERE IT WAS EXPECTED ------
   The suspicion was that the IN-SCATTER saturates by 2-3 blocks and whitens
   everything. It does not. Delivered on a sand floor (0.76/0.70/0.50) at noon,
   V2 defaults, the in-scatter's share of the pixel is
     0.5 blk 1.3%   1 blk 2.9%   2 blk 6.7%   3 blk 11.7%   5 blk 24.9%
     8 blk 49.5%   12 blk 77.5%   20 blk 97.1%
   -- it only reaches half the pixel at 8 blocks. The veil is not the culprit
   either, though it is an accomplice (see (2) below).

   THE CULPRIT IS THE LIGHT LEG, and it lives in lib/lighting.glsl. The WATER
   band of the colored shadow returned the water's SURFACE ALBEDO (vanilla
   water_still x biome tint, saturation-boosted x1.4) as if it were a
   TRANSMITTANCE: a CONSTANT (0.0237, 0.1922, 0.7961) multiplying the sun on
   every submerged surface, identical at 0.1 block of water and at 20. It turns
   a sand floor from (5.470, 4.957, 3.375) into (0.350, 1.173, 2.742) BEFORE
   this file's column ever runs, and this file's Beer-Lambert then absorbs a
   SECOND time on top. Delivered colour, V2, sand, noon, view path in blocks:
     0.5 (0.263,1.027,2.453) hue 269.8   3 (0.073,0.553,1.440) hue 269.6
     8   (0.029,0.232,0.599) hue 269.0  20 (0.032,0.152,0.275) hue 252.2
   ONE hue, 269-270 deg, from the shore to eight blocks out. Total travel over
   the whole 0.5 -> 20 block sweep: 17.6 deg of hue for a 7.2x luminance range
   (and only 1.67x over dark stone). That is the flat milky sheet, exactly.

   ---- WHAT V3 CHANGES (three terms, each with its own criterion) -----------
   (1) LIGHT LEG -> lib/lighting.glsl, vlxWaterShadowT(). exp(-k t) over the
       thickness the shadow map already measures, same spectrum, same clarity
       scaling, same WATER_ABSORB_* dials as the view leg. No new constant.
       THE VOLUMETRIC LEG IS THE SAME LEG, and it was missed on the first pass:
       the god-ray march decodes the same shadowcolor0 WATER band per step (this
       file's inline march and its mirror lib/vl_halfres.glsl) and used to read
       it as a light TINT. That left the beam 3.77x darker and 4.2x bluer than
       the light it deposits on the floor it lights - decoded tag
       (0.0741,0.1945,0.6258) luma 0.2000 R/B 0.118, constant at every depth,
       against vlxWaterShadowT's (0.4505,0.8270,0.9176) luma 0.7535 R/B 0.491 at
       2 blocks under a zenith sun; the two only crossed near 13 blocks. Both
       marches now call vlxWaterShadowT on the raw shadowtex0 tap they already
       take for s0, so the cost is zero extra taps and no dial is left out.
   (2) VEIL -> ONE MEDIUM INSTEAD OF TWO ATTENUATIONS. V2 stacked a GRAY
       exp2(-0.288 d) on top of the per-channel absorption: 0.1996 per block of
       ACHROMATIC extinction, 4.6x the blue absorption coefficient, spent
       equally in all three channels -- so what little chroma travel survived
       (1) was flattened by a colourless fade. V3 turns that veil into the
       SCATTERING coefficient b of the same medium, so the column is a single
       honest single-scattering solve, T = exp(-(a + b) d) and in-scatter share
       = 1 - T, per channel.
       WHERE b COMES FROM -- the two criteria in the reference description,
       nothing else. "The bottom is readable through the shallows" ->
       T_blue(3 blk) >= 0.55; "offshore the bottom frankly disappears" ->
       T_blue(12 blk) <= 0.10. Those bracket c_blue in [0.1919, 0.1993]; at
       c_blue = 0.1950 both hold (T_B(3) = 0.557, T_B(12) = 0.096), so
       b_blue = c_blue - a_blue = 0.1950 - 0.043 = 0.152 per block. The SHAPE is
       the coastal particulate law b(L) ~ L^-1 (Gordon & Morel 1983, case-2
       waters), evaluated at the sRGB primaries: b = (0.11571, 0.12874, 0.15200).
       Floor survival exp(-(a+b)d) against V2's absorb x veil:
         3 blk  V3 (0.214,0.511,0.557) vs V2 (0.166,0.413,0.483)  blue +15%
         8 blk  V3 (0.016,0.167,0.210) vs V2 (0.008,0.095,0.144)  blue +46%
        12 blk  V3 (0.002,0.068,0.096) vs V2 (0.001,0.029,0.054)  blue +77%
       and the in-scatter now needs 11.8 blocks (not 8.0) to own half the pixel.
   (3) DEEP CHROMA -> the water-leaving reflectance, not a picked colour.
       R(L) ~ b_b / (a + b_b) with b_b the BACKSCATTERING coefficient:
       b_b = 0.5 * b_w + 0.018 * b_p, i.e. the molecular half of Morel 1974's
       L^-4.32 pure-water scattering (which backscatters ~50%) plus the
       Petzold/Gordon particle backscatter ratio 0.018 on the b above.
       b_b = (0.00291, 0.00363, 0.00543) -> R = (0.0072, 0.0368, 0.1122),
       normalised (0.065, 0.328, 1.000): a marine blue with a real green
       shoulder, saturation 0.935.
       THE HARD CRITERION IS KEPT VERBATIM FROM V2: the endpoint is rescaled to
       carry the SAME Rec.709 luminance as V2's (0.3585), so switching V3 on
       rotates the deep HUE and does not touch the deep BRIGHTNESS. The rejected
       "milky powder-blue" was a LUMINANCE failure, and it cannot come back
       through this door either. Delivered at the shipped WATER_FOG_BLUE 0.85:
       slateC V2 (0.086,0.406,0.693) luma 0.3587 sat 0.876
       slateC V3 (0.115,0.366,1.004) luma 0.3587 sat 0.885
       -- same luminance, marginally MORE saturated, R/B 0.115 vs 0.124.
       THE HUE ROTATES, AND THAT IS THE RISK TO WRITE DOWN, because the property
       V2's own comment cites as its defence against "plastic azure" is the deep
       GREEN SHOULDER, and V3 halves it. Three endpoints at WATER_FOG_BLUE 0.85:
         LEGACY (rejected) (0.2410,0.3770,0.5215) luma 0.3585 sat 0.538
                            G/B 0.723  hue 255.4 deg
         V2                (0.0863,0.4059,0.6932) luma 0.3587 sat 0.876
                            G/B 0.586  hue 248.0 deg
         V3                (0.1154,0.3660,1.0038) luma 0.3587 sat 0.885
                            G/B 0.365  hue 276.9 deg
       The test the rejection was actually about is fully met: same luminance
       (0.35870 -> 0.35875, +0.015%; delivered 20-block luma 0.1492 -> 0.1586,
       +6%) at barely more saturation (0.883 -> 0.891), so the MILKY model - sat
       0.538 at the SAME luma - provably cannot come back through this door. But
       the delivered offshore hue rotates 251.3 -> 275.6 deg, and if "trop bleu"
       is reported again that is the door it will come through.
       WATER_FOG_BLUE IS NOT THE LEVER FOR IT: it slides slateC toward
       WCOL_SCAT_GRAY at constant luminance, i.e. toward neutral, and cannot
       rotate hue back toward green. The lever is WCOL_SCAT_DEEP's own G
       component (or a dial mixing WCOL_SCAT_DEEP toward WCOL_SCAT_BLUE, whose
       G/B is 0.551 against WCOL_SCAT_DEEP's 0.328) - raising G there is what
       puts the green shoulder back. All three rows above were recomputed from
       the constants and mix(WCOL_SCAT_GRAY, ., WATER_FOG_BLUE) directly, and
       luma() is this pack's own Rec.709.

   ---- WHAT THE THREE TOGETHER DELIVER (sand, noon, linear RGB + hue deg) ---
   REPRODUCIBILITY CAVEAT, missing from the first version of this table: the two
   DEEP rows (12 and 20 blk) run through the refracted-sun forward-scatter term
   and therefore depend on the VIEW AZIMUTH, which was not recorded. Recomputed
   with the sun's azimuth PERPENDICULAR to the view, the 20 blk V3 row reads
   (0.0478,0.1632,0.4388) hue 275.6 against the (0.043,0.148,0.402) hue 275.8
   tabulated below - same hue, ~11% of level. Every other entry of both columns
   is azimuth-independent and reproduces to three decimals.
     path   V2                            V3
     0.5    (0.263,1.027,2.453) 269.8     (3.608,4.282,3.045) 129.2  sand read through
     1      (0.198,0.901,2.198) 269.5     (2.387,3.701,2.752) 153.2
     2      (0.116,0.700,1.773) 269.4     (1.061,2.772,2.258) 176.2  turquoise-green
     3      (0.073,0.553,1.440) 269.6     (0.488,2.086,1.867) 187.3
     5      (0.038,0.364,0.978) 270.0     (0.131,1.204,1.311) 203.8  teal
     8      (0.029,0.232,0.599) 269.0     (0.052,0.570,0.839) 230.3
     12     (0.030,0.172,0.384) 263.6     (0.044,0.267,0.557) 259.4
     20     (0.032,0.152,0.275) 252.2     (0.043,0.148,0.402) 275.8  navy, sat 0.893
   DYNAMIC 0.5 -> 20 blk, sand: luminance x7.2 -> x28.1, hue travel 17.6 deg ->
   146.6 deg. Over dark stone: x1.67 -> x6.18, 32.3 deg -> 51.1 deg. With the
   sun at 30 deg instead of the zenith the same sweep gives x4.50 -> x14.96 and
   17.3 deg -> 132.5 deg (the light leg is 2x longer there, which is why the
   shallows lose their turquoise at low sun -- as they do in reality).
   THE COST, stated because it IS a change: shallow water gets much BRIGHTER
   (luma 0.97 -> 4.05 at 0.5 block over sand), because the floor stops being
   pre-multiplied by 0.024 in red. It stays BELOW the dry beach beside it
   (4.05 against 4.95), which is the check that says "transparent", not "blown".
   -- the 4.95 recomputed from this block's own numbers: albedo (0.76,0.70,0.50)
   x (gLightC + gAmbC) = (5.4697,4.9573,3.3750), Rec.709 luma 4.952. An earlier
   revision wrote 4.60 here; the test passes more comfortably than it claimed.
   The DEEP end does not move: 0.1349 -> 0.1443 luma, +7%.

   ==================== EAU4 - THE PREDICTED DOOR, AND IT OPENED ============
   Report, verbatim: "still too blue, kind of... I don't know, maybe the
   volumetric thing inside that makes it so blue too, but there, too blue, it
   looks fake, chemical, American." Read: a POOL blue - saturated, uniform, and
   red-starved - not sea water. Point (3) above wrote down exactly this door
   ("if 'trop bleu' is reported again that is the door it will come through")
   and named the lever (WCOL_SCAT_DEEP's own G). Both halves of the report are
   real and MEASURED, and they are the SAME defect seen twice:

   (A) THE COLUMN. V3 halved the deep GREEN SHOULDER that V2's own comment
       cites as the pack's defence against plastic azure: slateC G/B 0.586 ->
       0.365 at the shipped WATER_FOG_BLUE 0.85, hue 208.4 -> 223.1 deg. A deep
       blue whose green collapses IS a pool blue.
   (B) THE SUBMERGED VOLUME, which the report suspected on its own. The
       submerged in-scatter (WCOL_UW_*) and the shared glass/culled-face
       constant (WCOL_SCAT_UW) were NEVER rotated with it: they still ran V2's
       chroma at 208.4 deg and 0.950 of saturation. So one lake was drawn in
       TWO colours in the same frame - 14.7 deg of hue and 6.5 points of
       saturation apart - one of them worn the moment the eye goes under, the
       other painting water behind glass and every culled water face seen from
       OUTSIDE. Same-medium-same-colour is not a preference here, it is the
       criterion the light leg was already fixed against; two answers is a bug.
       HOW MUCH OF THE PIXEL IT ACTUALLY OWNS, submerged, flat density 0.040
       base-2 at the shipped dials - and the two numbers are NOT the same one:
         MIX WEIGHT (1 - visU) = 1 - 2^(-dist*0.040), i.e. the coefficient the
           code applies:                 5.4% at 2 blocks, 12.9% at 5,
                                        24.2% at 10, 42.6% at 20.
         RADIOMETRIC SHARE of the delivered Rec.709 luminance, over a SUNLIT
           SAND floor, camera 2 blocks under, sun at zenith, same path:
                                         0.05% at 2 blocks, 0.19% at 5,
                                         0.61% at 10, 2.90% at 20 - twenty to a
           hundred times less, because wfogC carries a luma of 0.027-0.054
           (fogBaseC 0.128 x drive 0.75 x uwViewMod 0.30-0.60) against 2.9 for
           the lit floor behind it.
       CONSEQUENCE, MEASURED AND STATED HONESTLY: over a LIT floor by day the
       submerged half of this fix (WCOL_UW_*) does not decide the pixel at all
       - EAU4 and V2 come out identical to 3-4 decimals across 2 floors x 2 sun
       heights x 2 camera depths x 5 distances (e.g. camera 5, sand, zenith,
       20 blocks: EAU4 R/B 0.0284 G/B 0.4415 sat 0.972 hue 214.49 against V2
       0.0273 / 0.4418 / 0.973 / 214.43). It decides the pixel where the floor
       is DARK OR ABSENT: free water with no bottom (EAU4 R/B 0.1635 sat 0.837
       hue 210.31 against V2 0.1203 / 0.880 / 208.32 - the 2 deg rotation is
       real there), flooded caves (19.8% in-scatter share), and night. Those
       are the cases that must not disagree with the view from outside, so the
       harmonisation is still the right move - just not for the "it repaints
       everything" reason an earlier revision of this block gave. The rest of
       the submerged pixel is WCOL_K_UW eating the background's red, which is
       correct for its own scale - see below.

   ---- WHERE V3's DERIVATION ACTUALLY WENT WRONG (same corpus, same formula) -
   (3) is right about the quantity: the deep chroma IS the water-leaving
   reflectance R(L) = b_b/(a + b_b), b_b = 0.5 b_w + 0.018 b_p, with Morel 1974
   L^-4.32 for b_w, Gordon & Morel 1983 L^-1 for b_p, Pope & Fry 1997 + Bricaud
   1981 for a. That is not what changed. What changed is HOW that spectrum was
   turned into a colour. V3 POINT-SAMPLED R(L) at three wavelengths (611, 549,
   465 nm) and used the three numbers as if they were linear sRGB. A spectrum
   does not become a colour that way: the eye integrates it against the CIE
   1931 colour matching functions, which are BROAD (x_bar peaks at 600 nm and
   still has half its mass below 570, where water absorbs 4x less than at
   611). Recomputed properly - R(L) integrated against CIE 1931 2-deg x D65 and
   converted through the sRGB matrix, the pipeline verified on a flat spectrum
   (0.9977, 1.0008, 0.9993 for the required 1,1,1):
     V3 3-point sample     (0.0072, 0.0370, 0.1131)  G/B 0.327  R/B  0.064
     same R(L), integrated (-0.0134, 0.0536, 0.1224)  G/B 0.438  R/B -0.109
   TWO findings, and the second is the one that explains "chemical":
     * the green shoulder is 34% larger than the 3-point sample claimed;
     * the RED IS NEGATIVE. The true colour of this water is OUTSIDE the sRGB
       gamut - no display can show it. V3 shipped a point-sample that landed
       just inside the boundary by accident (R 0.0072), i.e. a colour sitting
       ON the gamut edge with essentially no red in it. A hue pinned to the
       display's own primary edge is the definition of a synthetic, "chemical"
       blue, and it is why the fix could never come from WATER_FOG_BLUE.
   THE FIX IS THE STANDARD ONE FOR AN OUT-OF-GAMUT COLOUR: project it into the
   gamut along the line toward its own achromatic point. That map scales all
   three channel DIFFERENCES by one factor, so it preserves the HUE ANGLE
   exactly and the Rec.709 LUMINANCE exactly - it only spends saturation, which
   is the only currency there is here. HOW FAR TO PROJECT IS NOT A TASTE
   EITHER: the pack already carries the constraint, in (3)'s own guard.
   WATER_FOG_BLUE extrapolates to 1.25, and slateC = 0.36 (1 - s) + s DEEP must
   stay non-negative there, i.e. DEEP_R >= 0.36 * 0.25 / 1.25 = 0.072. That is
   the MINIMUM projection, and it is what is shipped:
     projection factor s = 0.61419 toward luma, hue and luma untouched
     WCOL_SCAT_DEEP  (0.0722,0.3670,1.1174) -> (0.0720,0.4045,0.7462)
     luma 0.35850 -> 0.35848 (-0.005%), R at WATER_FOG_BLUE 1.25 = +0.000000
     so the existing max(slateC, 0) clamp stays a no-op, exactly as documented.
   The submerged pair is the SAME chroma rescaled to the luminance each of them
   already had (0.1281 and 0.3142), which is what closes (B).

   ---- WHAT IT DELIVERS (sand, noon, same reconstruction as the table above) --
     endpoint chroma      R/B     G/B     sat    hue
       V2   slateC       0.1245  0.5855  0.876  208.4
       V3   slateC       0.1149  0.3646  0.885  223.1   <- the report
       EAU4 slateC       0.1674  0.5780  0.833  210.4
       V2/V3 submerged   0.0498  0.5500  0.950  208.4
       EAU4  submerged   0.0964  0.5418  0.904  210.4   <- identical to slateC
     DELIVERED, view path in blocks, V3 -> EAU4:
       0.5  (3.516,4.260,3.046) -> (3.516,4.261,3.033)  G/B 1.399 -> 1.405
       2    (0.969,2.720,2.264) -> (0.969,2.725,2.219)  G/B 1.202 -> 1.228
       5    (0.122,1.162,1.333) -> (0.122,1.171,1.247)  G/B 0.872 -> 0.939
       10   (0.052,0.372,0.711) -> (0.052,0.385,0.593)  G/B 0.524 -> 0.649
       20   (0.050,0.170,0.464) -> (0.050,0.184,0.329)  G/B 0.367 -> 0.559
     The offshore end gains half its green shoulder back (+52%) and 40% more
     red, and B still leads G by 1.79x at 20 blocks, so it is a navy WITH green
     in it and not a cyan.
   ---- THE WASHED-OUT MODEL PROVABLY CANNOT COME BACK THROUGH THIS DOOR ------
   Only CHROMA moved, at constant luminance, and no extinction was touched:
   WCOL_K_OUT, WCOL_B_SCAT, WCOL_K_UW and the V3 light leg are bit-identical.
   Delivered Rec.709 luminance, V3 -> EAU4, over sand: +0.003% at 0.5 block,
   +0.016% at 2, +0.052% at 5, +0.105% at 10, +0.048% at 20 - i.e. unchanged to
   a tenth of a percent at EVERY path. The 0.5 -> 20 block dynamic therefore
   holds at x28.1 (measured x24.19 -> x24.18 in this reconstruction, -0.04%),
   over dark stone x6.18 (x10.22 -> x10.21 here), and hue travel goes 146.6 ->
   134 deg. The rejected milky model was a LUMINANCE failure at sat 0.538; this
   endpoint is sat 0.833 at a luminance that did not move, so it is not that
   model and cannot become it.
   ---- WHAT IS DELIBERATELY *NOT* HARMONISED, stated because it is the honest
   half: WCOL_K_UW (0.0916,0.0198,0.0032) keeps its own spectrum and its own
   x0.315 metres-per-block scale against WCOL_K_OUT's x1.36. That is the
   CLARITY liberty documented in the WCOL block, not a colour: at that scale 20
   blocks is 6.3 m of real water and exp(-0.2937 * 6.3) = 0.157 of red survives,
   which is exactly the 0.160 the constant delivers - it is right for its own
   scale. So the two views still differ in HOW FAST the medium takes over, by
   design; they no longer differ in WHERE it lands, which is the criterion.
   ---- WHAT "SPLIT 0.0" MEANS EXACTLY, since an unconditional 0.0 would be a
   claim this pass cannot make. Two separate residues remain, both bounded and
   both understood:
   (a) DEPTH, in SATURATION not hue. The submerged chroma is pulled toward its
       own luminance by UW_FOG_DESAT (0.35) as the camera goes down, and the
       outside column is fixed. Delivered, free water:
         camera at surface  sat 0.907  R/B 0.0925  hue 210.95
         2 blocks under     sat 0.881  R/B 0.1191  hue 210.71
         5 blocks under     sat 0.837  R/B 0.1635  hue 210.31
         12 blocks under    sat 0.706  R/B 0.2945  hue 209.06
         outside column     sat 0.831  R/B 0.1687  hue 210.23  (fixed)
       So the HUE holds inside 1.2 deg everywhere - that is the win, 14.7 deg
       -> <=1.2 deg - and the exact meeting point (0.08 deg of hue, 0.006 of
       saturation) sits near 5 blocks of camera depth. The rest is a
       SATURATION residue carried by a documented dial, by construction.
   (b) SUN COLOUR, now closed in code. The submerged fog used to be driven by
       a COLOURED light (gAmbC/gLightC), which reopened the split to 11.3 deg
       at sh 0.05 by a mechanism no constant here could reach. EAU4b makes that
       drive achromatic under WCOL_V3 - see the uwDrive site, which carries the
       measurements. Legacy V2 keeps the coloured drive it always had.
*/
/* ===== EAU5 -- EXHAUSTIVE AUDIT OF EVERY SITE THAT TINTS A WATER PIXEL =====
   Report, for the ninth time: "l'eau est toujours trop bleue". Four previous
   passes each found a real defect in the water MODEL and fixed it, and the
   report did not move. This block is the answer to why, and it is not another
   constant: it is a SHARE table. Every number below is the fraction of the
   FINAL LINEAR PIXEL luminance a term actually contributes -- not a mix weight,
   which is the error an earlier pass already made once.
   SETUP: sand floor 3 blocks down, eye 1.8 blocks above the surface, clear sky,
   sunlit, shipped defaults, one horizontal distance L. "open" = the same view
   with NO floor in range (real ocean / large lake).

   ---- WHERE THE PIXEL ACTUALLY COMES FROM, NOON ----------------------------
   The five SHARE rows below sum to 100% at every column (rounding aside). The
   ATMO_FOG line is the odd one out and is labelled: it is a MIX WEIGHT applied
   before the VL veil, not a share of the final pixel.
     L (blocks)              2       5      10      20      60     120
     reflW (mirror weight) 0.045   0.209  0.573   0.939   0.980   0.980
     SKY REFLECTION        7.0%   29.9%  66.7%   89.8%   80.9%   66.4%
       same, open water   15.1%   41.4%  71.8%   90.2%   81.0%      -
     floor transmitted    69.7%   41.9%  14.5%    1.5%    0.4%    0.3%
     column in-scatter    21.9%   25.1%  14.0%    2.0%    0.7%    0.5%
     horizon sky floor       0       0       0       0    0.02%   0.07%
     VL veil (scat)        1.4%    3.1%   4.8%    6.7%   18.0%   32.8%
     HEIGHT_FOG tail          0       0      0       0       0       0
     ATMO_FOG (weight)    0.005   0.008  0.012   0.017   0.049   0.095
   THAT IS THE FIFTH SITE, AND IT WAS NEVER AUDITED: past ~8 blocks the water
   pixel IS SKY, and by two routes at once -- the mirror, and the air the mirror
   is seen THROUGH. The column the last four passes re-derived owns 25% of it at
   5 blocks, 14% at 10 and 2% at 20. A hue rotation of the medium alone is
   therefore MUTE at exactly the distance the lake is judged from -- which is
   why every previous fix was both correct and invisible.
   THE VL VEIL ROW WAS ITSELF MISSING FROM THE FIRST WRITE-UP OF THIS TABLE, and
   it is not small: VOLUMETRIC_LIGHT is on by default (lib/settings.glsl), and
   its application site (this file, "AIR-VEIL MIRROR RELIEF") does
   color = color * transF + scat * fogKeepW. It is a SECOND air veil, distinct
   from ATMO_FOG, and its share is 1 - transF^fogKeepW. Model used for the row,
   anchored on this file's own measured "transF ~0.65 at 60 blocks": transF =
   exp(-0.0071797 * L) and fogKeepW = 1 - 0.55 * wMirror with wMirror = reflW
   (see the reflW site), i.e. fogKeepW 0.975 / 0.885 / 0.685 / 0.484 / 0.461 /
   0.461. That reproduces 18.0% at 60 blocks. The first four rows above are the
   old numbers rescaled by transF^fogKeepW; without that rescale they summed to
   ~100% on their own and overstated SKY REFLECTION by ~18 points at 60 blocks.
   THE CONCLUSION IS UNCHANGED, and that is the point: scat is sky in-scatter,
   chroma ~210 deg (same family as the mirror and as ATMO_FOG). Moving 18 points
   from "reflected sky" to "sky seen through" does not make the water less blue
   -- it only means the blue arrives by three doors instead of one.
   HEIGHT_FOG TAIL: the analytic far haze (this file, guard
   distVol > marchEnd + 1.0 with marchEnd = min(distVol, 160)) is a THIRD
   sky-chroma veil on the water pixel, hcol = skyBaseWD*0.9 + sun, HEIGHT_FOG
   being defined by default. It is identically 0 over the whole table because it
   only exists past 160 blocks -- but it is a site, it is listed, and like the
   other two it is scaled by wMirror, hence by WATER_TINT (see WT_MIRROR).
   DH_WATER.FSH is a SIXTH water-drawing path and the palier does NOT reach it:
   it has its own albedo, Fresnel and reflection (reflDH) and references no WT_*
   / WCOL_* / WATER_REFLECTIVITY, and composite1 never reads the 0.2 flag it
   writes, so those pixels see neither waterColumn nor reflW. Impact at the
   shipped defaults is nil: its own discard confines it past far-32, where the
   0.98 clamp on reflW already pins the vanilla mirror at both paliers -- so the
   palier is mute there anyway. Documented, not fixed.

   ---- CHROMA OF EACH SITE (linear, before the tonemap) ----------------------
     term                          R/B     G/B    sat    hue     notes
     column in-scatter (slateC)   0.167   0.578  0.833  210.4   EAU4 endpoint
     sky mirror @ L=5             0.294   0.553  0.706  218.0   pre REFLECT_DESAT
     sky mirror @ L=5  desat      0.407   0.624  0.593  218.0   post, x0.40
     sky mirror @ L=10 desat      0.485   0.690  0.515  216.0
     sky mirror @ L=20 desat      0.548   0.744  0.452  214.0
     sky mirror @ L=60 desat      0.602   0.790  0.398  211.6
     horizon sky floor            0.339   0.643  0.661  212.4   >48 blocks only
     ATMO_FOG colour              0.633   0.816  0.367  210.0   = sky along view
     submerged fog (wfogC)        0.122   0.555  0.878  210.4   eye 2 blk under
   The mirror is NOT more saturated than the column -- it is PALER (sat 0.45-0.59
   against 0.83). It does not make the water more BLUE, it makes it blue AT A
   LUMINANCE the column can no longer argue with, and it pins the hue at 204-205
   deg from 20 blocks out whatever the medium does. REFLECT_DESAT already spends
   0.40 on it; pushing that to 0.52 moves the delivered hue by 0.7 deg at 20
   blocks (measured), so desaturating harder is NOT the lever. The lever is the
   WEIGHT, and it is WATER_REFLECTIVITY 1.5 -- a x1.5 artistic overdrive of
   physical Fresnel. Physical (x1.0) at 20 blocks: reflW 0.626 instead of 0.939,
   delivered hue 202.2 instead of 205.5. WATER_TINT drives that weight through
   WT_MIRROR; see the reflW site.

   ---- THE OTHER CANDIDATES, ALL MEASURED, ALL CLEARED ----------------------
   * GBUFFER SURFACE ALPHA (gbuffers_water, root cause of pass 1): albedo is the
     vanilla tint desaturated by 0.5*WATER_TINT_DESAT then x0.18, alpha-blended
     at 0.25. It is 1.97% of the background this file then absorbs, i.e. 1.4% of
     the final pixel at 2 blocks, 0.85% at 5, 0.30% at 10, 0.03% at 20. Closed.
   * BIOME TINT in waterColumn: turbid = smoothstep(0.05,0.45, r+g-1.05b) is
     EXACTLY 0 for every blue-water biome (ocean R/G/B 0.247/0.463/0.894 gives
     -0.229). It contributes nothing outside swamps. UW_BIOME_TINT is off by
     default, so the submerged path adds nothing either.
   * WATER_HORIZON_SKY: weight hzB*0.30 with hzB = smoothstep(48,192,dist) --
     identically 0 below 48 blocks, 0.6% of the base at 60, 3% at 120. It cannot
     be the near/mid-field blue. Its anti-black job is left untouched here.
   * EDGE FOAM / WHITECAPS: WATER_FOAM and WHITECAPS are commented out by
     default; the foam band also only exists within 1.6 blocks of a shore.
   * SUN GLINT: additive GGX at alpha 0.006-0.016 (half-width < 0.5 deg), gLightC
     coloured, alive on a handful of facets. No area contribution.
   * CAUSTICS: caTint = mix(1, beerC/beerC.b, 0.35) is a MODULATION AROUND 1 of
     the FLOOR only (inside the "floor transmitted" row above), never of the
     surface or the column.
   * TONEMAP / GRADING (composite5): SATURATION 1.05 + VIBRANCE 1.0 and every
     TC_* at its neutral notch, i.e. all four period factors fold to exactly 1.0.
     Global to the frame, not a water site. It IS included in every delivered
     number quoted here.
   * SUBMERGED VIEW: the in-scatter is only 0.4% of the pixel at 2 blocks of
     sight, 1.1% at 5, 2.6% at 10 and 7.5% at 20 (eye 2 blocks under, noon). The
     colour down there is set by the ABSORPTION spectrum WCOL_K_UW eating the
     red, not by the in-scatter chroma -- which is why WATER_TINT moves the
     submerged hue by only ~5 deg at 20 blocks, and why WCOL_K_UW is deliberately
     NOT rotated: it is an extinction, rotating it would trade the documented
     "floor readable at 3 blocks" clarity for a hue.

   ---- WHAT SHIPS ------------------------------------------------------------
   (1) WATER_TINT, a named 4-step palier (lib/settings.glsl) rotating the hue of
       the medium at EXACT Rec.709 luminance and EXACT HSV saturation, on all
       four medium constants at once; default 0 (Vert), palier 2 = the shipped
       look bit-for-bit.
   (2) WT_MIRROR, carried by the same palier, so the control also owns the term
       that decides the pixel between ~8 and ~45 blocks -- AND NOT BEYOND, see
       the range limit below, which is an assumed limit of this design.
   Delivered hue, sand floor, noon, palier 2 -> palier 0:
       2 blocks 171.1 -> 156.8 | 5 blocks 188.4 -> 172.2
      10 blocks 198.5 -> 187.9 | 20 blocks 204.9 -> 197.0
   Open water, palier 2 -> palier 0: 206.0 -> 176.5 at 2 blocks, 203.9 -> 184.5
   at 5, 203.5 -> 192.0 at 10. Luminance of the column itself is untouched at
   every palier (0.6203 / 0.3750 / 0.1416 at 0.5 / 3 / 20 blocks of path, x4.38
   of dynamic; see the non-regression figures in lib/settings.glsl -- 0.010 /
   0.025 / 0.037% on the complete column, up to 0.80% on the in-scatter term
   taken alone).
   RANGE LIMIT OF WT_MIRROR, WRITTEN OUT BECAUSE THE TABLE ABOVE STOPPED AT 20
   BLOCKS -- JUST BEFORE THE COLLAPSE. The table stopping at 20 was not innocent:
   past that, TWO bounds on the reflW line below eat the WT_MIRROR factor whole.
   (a) The clamp ceiling 0.98 bites from L ~ 22 blocks at palier 2 and L ~ 45 at
       palier 0, so from ~45 blocks out reflW = 0.9800 AT BOTH PALIERS, identical
       to the bit.
   (b) The WATER_REFLECT_FLOOR 0.06 raise bites near 45 deg of incidence
       (reflW = 0.0375 at both paliers) -- and it is also what makes the 0.045 at
       2 blocks in the share table, not Fresnel.
   Delivered-hue DELTA palier 2 -> palier 0, continued past 20 blocks:
       20 blocks 7.5 deg | 30 blocks 3.3 | 45 blocks 0.64
       60 blocks 0.57    | 120 blocks 0.63
   So the 80.9% / 66.4% sky shares in the 60- and 120-block columns of the share
   table are UNTOUCHABLE by this palier. "The control owns the term that decides
   the pixel past 8 blocks" is true from ~8 to ~45 blocks and false beyond; the
   far field keeps the shipped blue whatever the palier says. THAT IS ACCEPTED,
   not an oversight: the ceiling exists so far water can never lose its mirror,
   and lowering it per-palier is what a real lever would require -- e.g.
   clamp(..., 0.0, 0.98 * WT_MIRROR) instead of clamping to a fixed 0.98, or
   carrying the palier into the WATER_HORIZON_SKY hzR clause further down. Both
   trade the anti-black guarantee for hue at distance, and neither ships.
*/
#if WCOL_V3 == 1
    // Scattering coefficient of the column, per block. Criterion in (2) above.
    const vec3  WCOL_B_SCAT    = vec3(0.11571, 0.12874, 0.15200);
    // Saturated endpoint of the WATER_FOG_BLUE slider. Derivation in (3)
    // above, colorimetry and gamut projection in the EAU4 block above.
    // EAU5: the HUE of that endpoint is now the WATER_TINT palier
    // (lib/settings.glsl). The rotation is the SAME projection mechanic, run in
    // the other direction: EAU4 spent saturation to enter the gamut, WATER_TINT
    // spends hue angle and spends NOTHING else -- Rec.709 luminance 0.3585 and
    // HSV saturation 0.904 are identical at all four paliers. WATER_TINT 2
    // restores vec3(0.0720, 0.4045, 0.7462) bit-for-bit.
    // ONE GUARD MOVES WITH IT, stated because EAU4's own text pins it: the
    // WATER_FOG_BLUE 1.25 notch extrapolates past this endpoint and needs
    // DEEP_R >= 0.072 for slateC to stay non-negative. Only palier 2 sits
    // exactly on that minimum (EAU4 solved for it); paliers 0/1/3 land at
    // 0.0435 / 0.0510 / 0.0428, so at that ONE notch the existing
    // max(slateC, 0) clamp does bite on the red -- which is precisely the case
    // it was written for. 1.25 is NOT a menu-reachable value (WATER_FOG_BLUE is
    // not exposed; the shipped 0.85 and every notch up to 1.0 are clean at all
    // four paliers), so no reachable state loses the no-op.
    const vec3  WCOL_SCAT_DEEP = vec3(WT_DEEP_R, WT_DEEP_G, WT_DEEP_B);
#else
    // V3 off: both symbols exist but reproduce V2 exactly (WCOL_B_SCAT is not
    // read at all on that path, the scalar WCOL_VEIL_RATE is).
    const vec3  WCOL_B_SCAT    = vec3(WCOL_VEIL_RATE);
    const vec3  WCOL_SCAT_DEEP = WCOL_SCAT_BLUE;
#endif
// Shared submerged-column in-scatter chroma: ONE constant for the three
// duplicated sites (glass column + culled water faces x2), with the CONFIG
// per-channel dials applied once. Defaults 1.0 reproduce the constant of the
// selected model bit-exactly.
const vec3 SCAT_UW_BASE = WCOL_SCAT_UW * vec3(UW_FOG_R, UW_FOG_G, UW_FOG_B);

// EAU9 / WATER_COLOR_V4 -- THE MEDIUM, AS ONE ANSWER FOR THE WHOLE FILE.
// The three constants above are the CLEAR anchor of the water-type axis; these
// accessors return them blended toward the MID (ocean/lake/river) and DARK
// (swamp/mangrove) anchors by the camera's biome climate. Derivation,
// constants and the measured before/after: the WATER_COLOR_V4 block in
// lib/settings.glsl; the mixer itself is vlxWaterMix3() in lib/biome.glsl.
// WHY ACCESSORS AND NOT NEW CONSTANTS: seven sites in this file build a water
// Beer-Lambert and only ONE of them calls waterColumn(). The other six hand-
// roll exp(-d * WCOL_K_OUT) and are invisible to a grep for waterColumn -- the
// exact trap the EAU7 block documents and fell into once. Routing all seven
// through these three functions makes "one medium, one chroma" a property of
// the code instead of a promise in a comment.
// WHY THE OFF STATE IS MACROS AND NOT FUNCTIONS-THAT-RETURN-THE-CONSTANT, and
// it was measured rather than assumed: with functions, a call anywhere inside
// waterColumn() defers constant folding from glslc to spirv-opt for the WHOLE
// body, and the two folders disagree by ONE ULP on slateC (0.0973193944 against
// 0.0973194018). Every executable instruction was identical -- 56136 lines for
// 56136 -- but a folded constant is not, and "V4 0 is the old pack" should not
// need an asterisk. Expanding to the constant itself makes the V4 0 source
// TEXTUALLY the pre-EAU9 source at all ten call sites, with no duplicated
// expression anywhere. (Function-like macro names, so nothing here can be
// mistaken for an Iris option; there is no // [..] list either.)
#if WCOL_V4 == 1
vec3 vlxWaterK() {
    return vlxWaterMix3(WCOL_K_OUT,
                        vec3(WCOL4_K_MID_R,  WCOL4_K_MID_G,  WCOL4_K_MID_B),
                        vec3(WCOL4_K_DARK_R, WCOL4_K_DARK_G, WCOL4_K_DARK_B));
}
vec3 vlxWaterB() {
    return vlxWaterMix3(WCOL_B_SCAT,
                        vec3(WCOL4_B_MID_R,  WCOL4_B_MID_G,  WCOL4_B_MID_B),
                        vec3(WCOL4_B_DARK_R, WCOL4_B_DARK_G, WCOL4_B_DARK_B));
}
vec3 vlxWaterDeep() {
    return vlxWaterMix3(WCOL_SCAT_DEEP,
                        vec3(WCOL4_C_MID_R,  WCOL4_C_MID_G,  WCOL4_C_MID_B),
                        vec3(WCOL4_C_DARK_R, WCOL4_C_DARK_G, WCOL4_C_DARK_B));
}
// THE SAME CHROMA AT THE OTHER TWO LUMINANCES -- the EAU4/EAU8 rule, carried
// into V4 by a scalar instead of by a second derivation. vlxScatUWBase() paints
// the water a GLASS PANE hides and the two CULLED water faces (all three seen
// from OUTSIDE, all three whose stated job is to match the open-water column --
// and whose ABSORPTION already follows the biome through vlxWaterK(), so their
// in-scatter has to follow or they would be half-converted). vlxWaterUWc() is
// the column seen from UNDER the surface (the UW fog chromas and the TIR
// fallback). Without these two, the MID anchor would leave a 19.7 deg
// inside/outside hue split -- MORE than the 14.7 deg EAU4 was written to close.
// NOT ROUTED THROUGH V4, and deliberately: WCOL_K_UW, the submerged ABSORPTION.
// It keeps its own spectrum and its own x0.315 metres-per-block scale (the
// "clarity liberty" the WCOL block documents and EAU7 explicitly declined to
// touch). V4 moves what the medium LOOKS like, not how far you can see under it.
vec3 vlxScatUWBase() {
    return vlxWaterMix3(WCOL_SCAT_UW,
                        vec3(WCOL4_C_MID_R,  WCOL4_C_MID_G,  WCOL4_C_MID_B)  * WCOL4_L_GLASS,
                        vec3(WCOL4_C_DARK_R, WCOL4_C_DARK_G, WCOL4_C_DARK_B) * WCOL4_L_GLASS)
         * vec3(UW_FOG_R, UW_FOG_G, UW_FOG_B);
}
// Takes the CLEAR anchor as an argument because the four submerged constants
// (SHALLOW / MID / DEEP / TIR) are ONE chroma under V3 but FOUR different ones
// on the legacy V2 path -- and V4 is gated on V3, so at WCOL_V4 0 each site has
// to get its own constant back, not a shared one.
vec3 vlxWaterUWc(vec3 clearV) {
    return vlxWaterMix3(clearV,
                        vec3(WCOL4_C_MID_R,  WCOL4_C_MID_G,  WCOL4_C_MID_B)  * WCOL4_L_UWC,
                        vec3(WCOL4_C_DARK_R, WCOL4_C_DARK_G, WCOL4_C_DARK_B) * WCOL4_L_UWC);
}
#else
#define vlxWaterK() WCOL_K_OUT
#define vlxWaterB() WCOL_B_SCAT
#define vlxWaterDeep() WCOL_SCAT_DEEP
#define vlxScatUWBase() SCAT_UW_BASE
#define vlxWaterUWc(clearV) (clearV)
#endif
#if RT_REFLECT_MODE >= 2
#include "/lib/voxelray.glsl"
// Shade an OFF-SCREEN voxel hit: albedo * (sun * shadow-map visibility + sky
// ambient), emissives boosted. The DDA march supplies the exact FACE NORMAL,
// so this is real Lambert plus a shadow bias along the face (self-acne guard).
// hitPosRel = camera-RELATIVE position (shadowModelView space).
// gLightC/gAmbC are declared above, outside the #if block.
vec3 ptShadeVoxel(vec4 vox, vec3 hitPosRel, vec3 faceN) {
    // Same linear space and same strength slider as the albedo path.
    if (vox.a > 1.5) return toLinear(vox.rgb) * PT_REFLECT_EMISSIVE * PT_REFLECT_STRENGTH;
    float vis = 1.0;
    vec3 sPos = hitPosRel + faceN * 0.08;
    vec4 sc4 = shadowProjection * (shadowModelView * vec4(sPos, 1.0));
    float fPT = getDistortFactor(sc4.xy);
    vec3 spPT = distortShadow(sc4.xyz, fPT) * 0.5 + 0.5;
    if (spPT.x > 0.0 && spPT.x < 1.0 && spPT.y > 0.0 && spPT.y < 1.0) {
        float zbPT = spPT.z - 0.0012 * (VLX_SHADOW_ZSCALE * 2.0);
        if (zbPT < 1.0) vis = step(zbPT, texture2D(shadowtex1, spPT.xy).r);
    }
    vec3 lightWG = normalize(mat3(gbufferModelViewInverse) * normalize(shadowLightPosition));
    float ndlPT = clamp(dot(faceN, lightWG), 0.0, 1.0);
    return toLinear(vox.rgb) * (gLightC * (PT_REFLECT_SUN * (0.15 + 0.85 * ndlPT)) * vis
                              + gAmbC * PT_REFLECT_AMBIENT * (0.75 + 0.25 * faceN.y))
                              * PT_REFLECT_STRENGTH;
}
#endif

// ============ WATER_SKY_TINT ============
// waterSkyTint() MOVED OUT of this file to /lib/water_sky_tint.glsl (included
// at the top of this file). It had to become shared so that dh_water.fsh -- the
// Distant Horizons ocean, which builds its own sky reflection and therefore
// never shows up in a grep for getSky* -- can apply the SAME palier. Full
// documentation, the two gates, the SPIR-V palier-0 proof and the injection
// site list all live in that header and in lib/settings.glsl.

// === Buffer formats (HDR) - DO NOT UNCOMMENT ===
// Iris/OptiFine read these colortexNFormat directives from INSIDE the /* */
// block. Moving them into real code raises C1503 (RGBA16F is not valid GLSL).
// As written, this block does enable HDR (colortex0/3/4 float).
/*
const int colortex0Format = RGBA16F;
const int colortex1Format = RGB16;
const int colortex2Format = RGBA8;
const int colortex3Format = RGB16F;
const int colortex4Format = RGBA16F;
const int colortex5Format = RGB8;
const int colortex6Format = RGBA8;
const int colortex11Format = RGBA8;
const bool colortex4Clear = false;
const bool colortex6Clear = false;
const bool colortex11Clear = true;
*/

uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform sampler2D colortex2;
uniform sampler2D colortex4;
uniform sampler2D colortex5;
uniform sampler2D colortex6;
uniform sampler2D colortex11;
#if defined VOLUMETRIC_LIGHT && VL_HALF_RES == 1
// VL_HALF_RES march endpoints written by composite.fsh in the lower-left
// quadrant (13 = scat/trans at wMirror 0, 14 = scat at wMirror 1 + odUW).
// Samplers gated like the composite5 RTX buffers: with the gate off the
// buffers stay unreferenced and Iris skips their allocation.
uniform sampler2D colortex13;
uniform sampler2D colortex14;
#endif
#if VLX_PHYS_SYNC == 1
// PHYSICS_FIELD_SYNC (lib/settings.glsl) : les deux images publiees par les
// programmes ocean de PHYSICS MOD PRO, relues ICI en samplers (Iris expose
// toute image.* comme sampler dans n'importe quel programme).
//   physOceanParamsSampler : 2 texels rgba32f (parametres + battement)
//   physOceanPixSampler    : plein ecran r32ui (estampille + waviness/pixel)
// Sans le mod ces images existent mais ne sont jamais ecrites : le battement
// est perime et tout le bloc s'eteint.
uniform sampler2D physOceanParamsSampler;
uniform usampler2D physOceanPixSampler;
#if VLX_PHYS_REAL == 1
//   physRipParamsSampler : 2 texels rgba32f (taille source, portee,
//                          normalSampleDistance, battement PROPRE a la carte ;
//                          puis le centre MONDE de la carte)
uniform sampler2D physRipParamsSampler;
#endif
// Categorie de biome de la CAMERA (Iris). Deja declaree par lib/dimension.glsl
// sous DIMENSION_FX == 1, d'ou la garde partagee.
#ifndef VL_BIOMECAT_DECL
#define VL_BIOMECAT_DECL
uniform int biome_category;
#endif
// Iris injecte CAT_* pour chaque constante de son enum BiomeCategories ; ces
// replis sont les ordinaux de cet enum (NONE 0 .. MUSHROOM 15, NETHER 16),
// dans la meme forme que CAT_NETHER / CAT_THE_END de lib/dimension.glsl.
#ifndef CAT_NONE
#define CAT_NONE 0
#endif
#ifndef CAT_BEACH
#define CAT_BEACH 9
#endif
#ifndef CAT_OCEAN
#define CAT_OCEAN 11
#endif
#ifndef CAT_RIVER
#define CAT_RIVER 13
#endif
#endif
uniform sampler2D depthtex0;
uniform sampler2D depthtex1;
uniform mat4 gbufferProjection;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelView;
uniform float far;
// (AO_QUALITY 1) pixel size for the bilateral AO denoise
uniform float viewWidth;
uniform float viewHeight;
uniform int isEyeInWater;
// Guarded: lib/lighting.glsl declares frameCounter under SHADOW_V2 (blue-noise
// PCF rotation) with the same guard, and a duplicate uniform is a GLSL error.
#ifndef VL_FRAMECOUNTER_DECL
#define VL_FRAMECOUNTER_DECL
uniform int frameCounter;
#endif
uniform ivec2 eyeBrightnessSmooth;
#if RIPPLE_BIOME_GATE == 1
// Iris built-in (>= 1.6.1): precipitation of the CAMERA biome.
// 0 = none (desert), 1 = rain, 2 = snow. Gates the RAIN_WET ground gloss.
uniform int biome_precipitation;
#endif
uniform vec4 lightningBoltPosition;
// Do NOT declare previousCameraPosition here: the SSR_PREV_FRAME block below
// already declares it, and a duplicate breaks compilation with WATER_RIPPLES.

varying vec2 uv;

vec3 toView(vec2 coord, float depth) {
    // TAAU: framebuffer UV [0..TAAU_S] is remapped to visible screen [0..1]
    // first (the divide folds away at compile time when TAAU_S = 1.0).
    vec4 ndc = vec4(coord / TAAU_S, depth, 1.0) * 2.0 - 1.0;
    vec4 v = gbufferProjectionInverse * ndc;
    return v.xyz / v.w;
}

#if GI_HALF_RES == 1
// --- GI_HALF_RES upsample ---
// colortex4 (GI rgb + linear depth .a) and colortex6 (AO .r) are computed by
// composite.fsh in the lower-left quadrant only: quadrant texel (i,j) shades
// the full-res pixel (2i,2j). 4-tap bilateral upsample: bilinear weights x
// linear-depth affinity (colortex4.a) x normal affinity (colortex1), so GI
// and especially AO never bleed across silhouettes or corners. Falls back to
// plain bilinear when every bilateral weight collapses (isolated depths).
// fuv = receiver full-res UV, z0 = its linear view depth (-viewPos.z).
// Returns vec4(gi.rgb, ao).
vec4 giUpsample(vec2 fuv, float z0) {
    vec2 vs = vec2(viewWidth, viewHeight);
    vec3 n0 = texture2D(colortex1, fuv).rgb * 2.0 - 1.0;
    vec2 hc = fuv * 0.5 * vs - 0.25;            // quadrant texel index space (-0.25: texel i anchors full-res pixel 2i)
    vec2 base = floor(hc);
    vec2 f = hc - base;
    vec2 maxIx = floor(0.5 * TAAU_S * vs) - 1.0; // last written quadrant texel
    vec4 acc = vec4(0.0);
    vec4 accB = vec4(0.0);                       // plain bilinear fallback
    float wSum = 0.0;
#if defined VLX_DEN_ACTIVE && VLX_DEN_ADAPT == 1
    // Palier 3 (DENOISE_QUALITY): max smoothed sigma of the 4 base texels
    // (colortex6.b, written by composite.fsh) drives the ring weights below.
    // Max, not average: a single disoccluded texel must open the rings.
    float nzMax = 0.0;
#endif
    for (int t = 0; t < 4; t++) {
        vec2 o = vec2(float(t & 1), float(t >> 1));
        vec2 tix = clamp(base + o, vec2(0.0), maxIx);
        vec2 huv = (tix + 0.5) / vs;             // texel-center tap (exact read)
        vec4 s4 = texture2D(colortex4, huv);
#if defined VLX_DEN_ACTIVE && VLX_DEN_ADAPT == 1
        // same fetch as the ungated line, .b selected alongside .r for free
        vec2 sAB = texture2D(colortex6, huv).rb;
        float sAO = sAB.x;
        nzMax = max(nzMax, sAB.y);
#else
        float sAO = texture2D(colortex6, huv).r;
#endif
        vec3 nT = texture2D(colortex1, (tix * 2.0 + 0.5) / vs).rgb * 2.0 - 1.0;
        float wb = mix(1.0 - f.x, f.x, o.x) * mix(1.0 - f.y, f.y, o.y);
        // same depth sigma as the legacy 3x3 AO bilateral (visual parity)
        float wz = exp(-abs(s4.a - z0) / (0.05 * z0 + 0.12));
        float wn = clamp(dot(nT, n0), 0.0, 1.0);
        float w = wb * wz * (0.10 + 0.90 * wn * wn);
        acc  += vec4(s4.rgb, sAO) * w;
        accB += vec4(s4.rgb, sAO) * wb;
        wSum += w;
    }
#if defined VLX_DEN_ACTIVE && VLX_DEN_RINGS >= 1
    // ---- A-TROUS RINGS (mission DEN, spatial stage of the GI denoiser) ----
    // DENOISE_QUALITY >= 1 widens this upsample into a scatter-gather a-trous:
    // ring 1 = 4 cross taps at dilation 2 HALF-RES texels, ring 2 at dilation
    // 4, texel-centered exact reads like the base quad. Per-tap weight =
    // RING_W / 4 so a full ring carries RING_W times the WHOLE base block
    // (whose bilinear weights sum to 1): 0.5 then 0.25, the B3-spline ladder.
    // Depth + normal affinities are the SAME expressions as the base taps, so
    // a ring never crosses an edge the bilateral already rejects. GI only:
    // AO (.a) stays on the 4-tap path -- it never was the flicker complaint,
    // and the rings must not soften contacts. Variance on a flat wall
    // (den_model2.py): sigma x0.75 (1 ring), x0.66 (2 rings) vs the base quad.
    vec3 accR = vec3(0.0);
    float wR = 0.0;
    float ringS = 1.0;
#if VLX_DEN_ADAPT == 1
    // Palier 3: ring weight follows the local sigma memory. Full rings from
    // nzMax >= 1/GAIN (heavy noise, disocclusion flagged .b = 1), nearly
    // closed (ADAPT_MIN) on a settled clean image -> palier-0 sharpness where
    // the filter is not needed, palier-2 smoothing where it is.
    ringS = clamp(nzMax * VLX_DEN_ADAPT_GAIN, VLX_DEN_ADAPT_MIN, 1.0);
#endif
    for (int r = 0; r < VLX_DEN_RINGS; r++) {
        float dil = (r == 0) ? 2.0 : 4.0;
        float wBase = ((r == 0) ? VLX_DEN_RING_W1 : VLX_DEN_RING_W2) * 0.25 * ringS;
        for (int s = 0; s < 4; s++) {
            vec2 o = (s == 0) ? vec2(dil, 0.0) : (s == 1) ? vec2(-dil, 0.0)
                   : (s == 2) ? vec2(0.0, dil) : vec2(0.0, -dil);
            vec2 tix = clamp(base + o, vec2(0.0), maxIx);
            vec2 huv = (tix + 0.5) / vs;
            vec4 s4 = texture2D(colortex4, huv);
            vec3 nT = texture2D(colortex1, (tix * 2.0 + 0.5) / vs).rgb * 2.0 - 1.0;
            float wz = exp(-abs(s4.a - z0) / (0.05 * z0 + 0.12));
            float wn = clamp(dot(nT, n0), 0.0, 1.0);
            float w = wBase * wz * (0.10 + 0.90 * wn * wn);
            accR += s4.rgb * w;
            wR   += w;
        }
    }
    if (wSum + wR > 1e-3) return vec4((acc.rgb + accR) / (wSum + wR),
                                      (wSum > 1e-3) ? acc.a / wSum : accB.a);
    return accB;
#else
    return (wSum > 1e-3) ? acc / wSum : accB;
#endif
}
#endif

#if GI_HALF_RES == 0 && (defined RTGI || defined SS_LIGHTS || defined SSGI || defined VLX_RSM_ACTIVE)
// ---- FULL-RES GI DENOISE (GI_HALF_RES 0, i.e. GI_QUALITY 3 only) ----
// GAP CLOSED BY THE GI-RSM PASS. The half-res path is denoised for free by
// giUpsample's 4-tap depth+normal bilateral above; the full-res path had NO
// spatial filter at all, only the temporal blend. That is a monotonicity break:
// the last notch raises the sample count but each pixel now carries its OWN
// independent noise instead of sharing one estimate with its 2x2 block, so in
// motion - exactly when the temporal history is being rejected - "Very high"
// could read NOISIER than "High". 3x3 bilateral weighted by the LINEAR depth
// already stored in colortex4.a, same sigma and same shape as the AO bilateral
// further down, so GI and AO stay registered on the same edges.
// Cost: 8 extra colortex4 taps + 9 colortex1 taps per opaque pixel, at
// GI_QUALITY 3 only.
// Sky and hand texels write depth 0 into colortex4.a, so their weight collapses
// and they cannot bleed into the surface behind them.
// NORMAL TERM (added by the GI-RSM pass): depth alone does NOT close the
// monotonicity break this filter was written for. giUpsample above (the notch
// 0-2 path) weighs by depth AND normal; with depth only, notch 3 bleeds GI
// across a convex corner whose two faces share the same depth - a case notch 2
// rejects. Notch 3 would then win on noise and lose on normal edges, which is
// exactly the regression the filter exists to prevent. Same expression and same
// shape as giUpsample's line: 0.10 + 0.90 * wn * wn.
vec3 giFilter3(vec2 fuv, float z0) {
    vec2 pxG = 1.5 / vec2(viewWidth, viewHeight);
    vec3 acc = texture2D(colortex4, fuv).rgb;
    vec3 nG0 = texture2D(colortex1, fuv).rgb * 2.0 - 1.0;
    float ws = 1.0;
    for (int gx = -1; gx <= 1; gx++) {
        for (int gy = -1; gy <= 1; gy++) {
            if (gx == 0 && gy == 0) continue;
            vec2 tuvG = fuv + vec2(float(gx), float(gy)) * pxG;
            vec4 sG = texture2D(colortex4, tuvG);
            vec3 nGT = texture2D(colortex1, tuvG).rgb * 2.0 - 1.0;
            float wG = exp(-abs(sG.a - z0) / (0.05 * z0 + 0.12));
            float wnG = clamp(dot(nGT, nG0), 0.0, 1.0);
            wG *= 0.10 + 0.90 * wnG * wnG;
            acc += sG.rgb * wG;
            ws  += wG;
        }
    }
#if defined VLX_DEN_ACTIVE && VLX_DEN_RINGS >= 1
    // ---- A-TROUS RINGS, full-res twin of the giUpsample block above ----
    // (mission DEN). The 3x3 above IS the dilation-1 a-trous pass; rings 1/2
    // add 4 cross taps at 2x then 4x its 1.5-px spacing. Per-tap weight =
    // RING_W directly (0.5 / 0.25): here the reference is ONE full-affinity
    // neighbour tap (the center tap alone is 1.0), not a bilinear block, so
    // the B3 ladder applies per tap. Same depth+normal affinities. Palier 3:
    // one colortex6.b tap (this texel is full-res when GI_HALF_RES = 0)
    // drives the ring weights exactly like nzMax in giUpsample.
    float ringS3 = 1.0;
#if VLX_DEN_ADAPT == 1
    ringS3 = clamp(texture2D(colortex6, fuv).b * VLX_DEN_ADAPT_GAIN, VLX_DEN_ADAPT_MIN, 1.0);
#endif
    for (int r = 0; r < VLX_DEN_RINGS; r++) {
        float dil = (r == 0) ? 2.0 : 4.0;
        float wBase = ((r == 0) ? VLX_DEN_RING_W1 : VLX_DEN_RING_W2) * ringS3;
        for (int s = 0; s < 4; s++) {
            vec2 o = (s == 0) ? vec2(dil, 0.0) : (s == 1) ? vec2(-dil, 0.0)
                   : (s == 2) ? vec2(0.0, dil) : vec2(0.0, -dil);
            vec2 tuvG = fuv + o * pxG;
            vec4 sG = texture2D(colortex4, tuvG);
            vec3 nGT = texture2D(colortex1, tuvG).rgb * 2.0 - 1.0;
            float wG = wBase * exp(-abs(sG.a - z0) / (0.05 * z0 + 0.12));
            float wnG = clamp(dot(nGT, nG0), 0.0, 1.0);
            wG *= 0.10 + 0.90 * wnG * wnG;
            acc += sG.rgb * wG;
            ws  += wG;
        }
    }
#endif
    return acc / ws;
}
#endif

#ifdef DISTANT_HORIZONS
// === Distant Horizons integration ===
// DH LODs write depth into dhDepthTex0/dhDepthTex1 (SEPARATE from depthtex0/1)
// with an EXTENDED near/far frustum -> they must be unprojected with
// dhProjectionInverse, NOT gbufferProjectionInverse.
uniform sampler2D dhDepthTex0;
uniform sampler2D dhDepthTex1;
uniform mat4 dhProjectionInverse;
uniform int dhRenderDistance;

vec3 toViewDH(vec2 coord, float depth) {
    // TAAU: same sub-rect -> visible screen remap as toView.
    vec4 ndc = vec4(coord / TAAU_S, depth, 1.0) * 2.0 - 1.0;
    vec4 v = dhProjectionInverse * ndc;
    return v.xyz / v.w;
}
#endif

// Single-tap sun visibility (masks caustics inside shadows)
// PIXEL_SHADOWS (lib/settings.glsl) : cette fonction sert DEUX familles
// d'appelants qui ne doivent PAS se comporter pareil, donc elle reste NEUTRE
// et le snap vit toujours au site appelant :
//   - receveurs de SURFACE des caustiques (les trois sites : a travers la
//     surface, rivage, immerge) -> l'appelant enveloppe son point dans
//     VLX_PIX_FLOOR(...) pour lire la meme cellule de 1/16 de bloc que le
//     motif qu'il masque ; sans ca le masque d'ombre et le reseau se
//     desaccorderaient au bord des cellules ;
//   - points EN L'AIR de la marche volumetrique (les deux appels
//     shadowVis1(mat3(gbufferModelView) * (dirW * tF)) juste dessous) et
//     sondes de surface NON caustiques (neige, AO, reflets, glints) -> AUCUN
//     snap, par conception : un point de marche n'a pas de texel de bloc a
//     viser, et ces sondes ne dessinent pas de bord d'ombre visible.
float shadowVis1(vec3 vPos) {
    vec3 sc = toShadowClip(vPos, vec3(0.0));
    float f = getDistortFactor(sc.xy);
    vec3 sp = distortShadow(sc, f) * 0.5 + 0.5;
    if (sp.x < 0.0 || sp.x > 1.0 || sp.y < 0.0 || sp.y > 1.0) return 1.0;
    float zv1 = sp.z - 0.001 * (VLX_SHADOW_ZSCALE * 2.0); // constant world-space bias
    if (zv1 >= 1.0) return 1.0; // outside the shadow frustum Z range -> fail-open
    return step(zv1, texture2D(shadowtex1, sp.xy).r);
}

#if FOG_SHADOWS == 1 && (defined ATMO_FOG || defined AERIAL_PERSPECTIVE || DAWN_MIST == 1 || (defined HEIGHT_FOG && defined VOLUMETRIC_LIGHT))
// Derived gate: the shared probe below only exists (and is only paid) when at
// least one consumer fog is compiled in. Every FOG_SHADOWS use site in this
// file tests this, so FOG_SHADOWS=0 keeps the legacy code paths verbatim.
#define FOG_SHADOWS_ACTIVE
// FOG_SHADOWS: mean sun/moon visibility along the view ray, shared by every
// ADDITIVE fog term living OUTSIDE the shadowed VL march (ATMO_FOG vanilla +
// DH mirror, AERIAL_PERSPECTIVE, DAWN_MIST, HEIGHT_FOG analytic tail). The
// marched fog/shafts already take per-step shadow taps + the csA/csB cloud
// probes and must NOT be shadowed twice. These analytic glows used to get the
// sun UNIFORMLY: under a cumulus or behind a shading mountain the haze kept
// glowing toward the sun, which flattened the volumetrics. 3 single-tap
// probes (same raw shadowtex1 depth + constant bias + fail-open contract as
// shadowVis1 above) spread over the WHOLE ray (mean 20/50/80% of rayLen,
// dither-jittered by +/- half a slot), each times the cloud shadow at the same
// world point. The ray is NOT clamped to shadowDistance: a tap that leaves the
// shadow map fails open (1.0) through shadowVis1's own XY/Z bounds tests, so
// the far field is governed by the cloud shadow alone -- clamping instead made
// the near-field occlusion at the player's feet darken the haze all the way to
// the horizon, DH LODs included.
// COST: the 3 shadowtex1 taps are cheap; the cloud factor is not. At the
// default VC_CUMULUS_SHAPES/VC_TEXTURED, cloudShadow costs 1 noise evaluation
// on clear sky and up to 9 under a cumulus deck (lib/lighting.glsl), i.e. up
// to ~27 for the 3 taps -- CLOUD_QUALITY-independent. The v > 0.0 early-out
// below skips it entirely on terrain-occluded taps.
// PERF_FOGVIS=1 trims that bill: 2 probes instead of 3, the sun-height
// early-out hoisted above the loop (zero cloud tap at night), and the cloud
// factor goes through cloudShadowCheap (PERF_CSHADOW_CHEAP: 5-tap field for
// secondary consumers, pass-through at 0) -> at most ~10 field taps by day.
// NOTE: terrain shadows cast ONTO THE CLOUDS themselves are out of reach --
// the cloud slab (VC_BASE 210 blocks up, often 700+ blocks away) sits far
// outside the shadow map; clouds keep their own light-march self-shadowing.
// originW MUST be cameraPosition: the depth probes convert the ray offset
// (dirW * t) straight to view space through mat3(gbufferModelView).
float fogSunVis(vec3 originW, vec3 dirW, float rayLen, float dither) {
    float tEnd = max(rayLen, 0.0);
#if defined VOLUMETRIC_CLOUDS && defined VC_GROUND_SHADOWS && !defined CLOUD_SHAFTS_ACTIVE
    vec3 lwF = normalize(mat3(gbufferModelViewInverse) * shadowLightPosition);
#if PERF_FOGVIS == 1
    // PERF_FOGVIS (a): cloudShadow's own no-shadow early-out (sunUpF =
    // smoothstep(0.06, 0.22, y) with a neutral 1.0 return at y <= 0.06) is
    // HOISTED above the probe loop. Same criterion, same neutral value: at
    // night / grazing sun every probe's cloud factor is 1.0 by that contract,
    // so the per-probe calls (dimension test + uniform reads + the field taps
    // behind them) are skipped wholesale instead of being paid per tap.
    bool fogCloudTaps = lwF.y > 0.06;
#endif
#endif
    float vSum = 0.0;
#if PERF_FOGVIS == 1
    // PERF_FOGVIS (b): 2 probes (mean 20% / 70% of the ray, jitter +/- half a
    // 50% slot -> the pair still sweeps [-5%..95%] of the ray across frames)
    // instead of 3 at 20/50/80. The consumers are smooth ANALYTIC fog terms,
    // already dither-jittered and TAA-resolved: the coarser per-frame
    // quantisation (3 levels instead of 4) integrates to the same gradient.
    for (int i = 0; i < 2; i++) {
        // Jittered fractions - same anti-terracing contract as the legacy
        // 3-tap loop below (binary step() taps need the per-frame slot).
        float tF = tEnd * (0.2 + 0.5 * (float(i) + dither - 0.5));
        float v = shadowVis1(mat3(gbufferModelView) * (dirW * tF));
#if defined VOLUMETRIC_CLOUDS && defined VC_GROUND_SHADOWS && !defined CLOUD_SHAFTS_ACTIVE
        // Early-out: a tap already fully occluded by terrain cannot get
        // darker, so the cloud probe is skipped there at zero visual cost.
        if (fogCloudTaps && v > 0.0) v *= cloudShadowCheap(originW + dirW * tF, lwF);
#endif
        vSum += v;
    }
    // Structural clamp: same "never subtracts light" contract as below.
    return clamp(vSum * 0.5, 0.0, 1.0);
#else
    for (int i = 0; i < 3; i++) {
        // Jittered fractions. shadowVis1 is a binary step(), so 3 FIXED taps
        // quantise the result to 4 levels over the full range -> hard,
        // shadow-shaped terraces crawling through the haze as the camera moves
        // (the tap points are camera-anchored). The per-frame dither slot
        // spreads the samples so TAA resolves a smooth gradient instead.
        float tF = tEnd * (0.2 + 0.3 * (float(i) + dither - 0.5));
        float v = shadowVis1(mat3(gbufferModelView) * (dirW * tF));
#if defined VOLUMETRIC_CLOUDS && defined VC_GROUND_SHADOWS && !defined CLOUD_SHAFTS_ACTIVE
        // Early-out: a tap already fully occluded by terrain cannot get darker,
        // so the expensive cloud probe is skipped there at zero visual cost.
        // cloudShadowCheap = A3 consumer swap (pass-through wrapper when
        // PERF_CSHADOW_CHEAP=0, so gate 0 + gate 0 stays verbatim legacy).
        if (v > 0.0) v *= cloudShadowCheap(originW + dirW * tF, lwF);
#endif
        vSum += v;
    }
    // Structural clamp: keeps the fogShadAmb >= 0.75 floor and the "never
    // subtracts light" contract true even if cloudShadow's darkness slider ever
    // exceeds 1.0. Free, and a no-op for every shipped value.
    return clamp(vSum * (1.0 / 3.0), 0.0, 1.0);
#endif
}

#ifdef CLOUD_SHAFTS_ACTIVE
/*
    CLOUD_SHAFTS -- le facteur NUAGE de fogSunVis devient une INTEGRALE le long
    du rayon, au lieu d'un facteur applique a 2-3 sondes ponctuelles.
    Doc complete, mesures et paliers : bloc "RAYONS DE NUAGES" de
    lib/settings.glsl. Ici, la seule chose qui merite d'etre lue sur place :
    POURQUOI CE PROFIL DE POIDS, et POURQUOI CET ESPACEMENT.

    POIDS. Le resultat pondere des brouillards de Beer-Lambert : ce qu'ils
    "voient" du rayon est w(t) = sigma(t) * exp(-integrale de sigma), pas une
    moyenne uniforme. sigma est pris du modele d'ATMO_FOG lui-meme
    (0.0018 * ATMO_FOG_DENSITY * exp(-max(y - WATER_LEVEL, 0) * 0.012), memes
    boosts crepuscule et pluie), evalue a l'altitude MEDIANE du rayon --
    exactement comme ATMO_FOG evalue la sienne a hMid. Aucun chiffre invente :
    c'est la densite du consommateur, relue.
    La traine HEIGHT_FOG (l'autre consommateur, celui des pixels de CIEL) est
    plus DENSE que ce profil ; la sonde est donc legerement biaisee vers le
    champ PROCHE pour elle. Biais assume et dans le bon sens : le champ proche
    est celui que la marche 0-160 dessine deja finement, donc les deux
    segments racontent la meme histoire.

    ESPACEMENT. Les t_i sont places a POIDS EGAL (echantillonnage par
    importance de w) : t_i = tEnd * ln(1 - f_i (1 - E)) / ln(E), E = exp(-tau).
    Chaque echantillon porte alors 1/n du poids et la moyenne arithmetique EST
    l'integrale. MESURE : contre l'integrale de reference, l'espacement
    exponentiel est non biaise (biais -0.0000, RMS 0.0019 des n = 3) alors que
    l'espacement LINEAIRE garde un biais de -0.021 (soleil 10 deg) a -0.035
    (45 deg) QUEL QUE SOIT n -- il sur-echantillonne un lointain qui ne pese
    presque rien (la moitie du poids tient dans les 265 premiers blocs au
    crepuscule). La forme se degrade proprement : a tau -> 0 elle tend vers
    t_i = f_i * tEnd, ce que le plancher 1e-4 sur tau rend exact.

    tEnd = min(rayLen, SHAFT_FAR_DIST). rayLen est 'dist' : la surface vue pour
    un pixel de terrain ou de LOD DH, 'far' pour un pixel de ciel. C'est le
    MEME bord que celui de tous les consommateurs (ATMO_FOG et
    AERIAL_PERSPECTIVE tarifent fogDist, la traine s'arrete a distVol), donc la
    sonde ne va jamais chercher d'ombre la ou aucun brouillard n'est dessine.
    ECART ASSUME par rapport au cahier des charges, qui proposait
    SHAFT_FAR_DIST pour les pixels de ciel : a une distance de rendu courante
    (256 blocs) cela aurait echantillonne l'ombre 3 fois plus loin que le
    brouillard n'existe. SHAFT_FAR_DIST reste comme PLAFOND, pour les tres
    grandes distances de rendu et les LOD DH.

    PAS de sunUpF : c'est tout l'objet du chantier. Le seul fondu est celui du
    ras de l'horizon, smoothstep(-0.02, 0.06, L.y), derive de la famille
    sunUpF mais 3.5 fois plus bas : il n'eteint la sonde que sous l'horizon,
    la ou le terme direct est nul de toute facon. MESURE de ce qu'il rend :
    sunUpF vaut 0.000 a 1 et 3 deg de soleil et 0.189 a 6 deg ; ce fondu-ci
    vaut 0.452 a 1 deg, 0.974 a 3 deg et 1.000 a 6 deg.

    COUT : SHAFT_STEPS taps bilineaires d'un R8 de 1 MiB. Les sondes
    shadowtex1 de fogSunVis ne bougent PAS (memes 2-3 taps, meme jitter) ;
    seul leur facteur nuage a change de nature.
*/
float fogCloudVis(vec3 originW, vec3 dirW, float rayLen, float dither) {
    vec3 lwF = normalize(mat3(gbufferModelViewInverse) * shadowLightPosition);
    float upF = smoothstep(-0.02, 0.06, lwF.y);
    if (upF <= 0.0) return 1.0;   // etoile sous l'horizon : terme direct nul
    float tEnd = min(max(rayLen, 0.0), SHAFT_FAR_DIST);
    if (tEnd <= 0.0) return 1.0;
    float duskS = clamp(1.0 - abs(sunHeight()) * 4.0, 0.0, 1.0) * smoothstep(-0.14, -0.04, sunHeight()); // asymmetric: keeps it off at night
    float yMid = originW.y + dirW.y * tEnd * 0.5;
    float sigF = 0.0018 * ATMO_FOG_DENSITY * exp(-max(yMid - WATER_LEVEL, 0.0) * 0.012)
               * (1.0 + duskS * 0.6 * ATMO_FOG_DUSK_BOOST)
               * (1.0 + rainStrength * 0.8);
    // Plancher sur tau : rend la forme exponentielle exacte jusqu'a la limite
    // uniforme, sans branche dans la boucle.
    float tauF = max(sigF * tEnd, 1e-4);
    float eF = exp(-tauF);
    float aF = 1.0 - eF;
    float kF = -tEnd / tauF;      // = tEnd / ln(E)
    float cSum = 0.0;
    for (int i = 0; i < SHAFT_STEPS; i++) {
        // Fractions jitterees (meme famille de dither que les sondes
        // shadowtex1 ci-dessus : TAA integre le reste).
        float fF = (float(i) + dither) / float(SHAFT_STEPS);
        float tF = kF * log(max(1.0 - fF * aF, 1e-6));
        cSum += ctmShadow(originW + dirW * tF, lwF, CLOUD_SHADOW_DARKNESS);
    }
    return mix(1.0, clamp(cSum / float(SHAFT_STEPS), 0.0, 1.0), upF);
}
#endif
#endif

#if PIXEL_WATER_FIX == 1
#ifndef VLX_W9_HELPERS
#define VLX_W9_HELPERS
// Convert a shadow-map delta-z into VERTICAL meters of water crossed.
// Calibration: sp.z = clipZ*0.25 + 0.5 (distortShadow packs z*0.5, then the
// receiver does *0.5+0.5) and clipZ = shadowProjection[2].z * z_view (ortho)
// -> meters along the light axis = dz * 4.0 / |shadowProjection[2].z|,
// vertical component = * lightWy. abs() is REQUIRED (the ortho term is
// negative). If distort.glsl ever changes its packing, recalibrate HERE: this
// is the SINGLE site, consumed by waterAboveShadow AND by causticColV.
float shadowZToVertical(float dz, float lightWy) {
    // (2.0 / VLX_SHADOW_ZSCALE) = generic inverse of the packing.
    return max(dz, 0.0) * (2.0 / VLX_SHADOW_ZSCALE) / max(abs(shadowProjection[2].z), 1e-6) * max(lightWy, 0.15);
}
// Real VERTICAL water thickness above a point, measured in the shadow map
// (same buffers as the caustics: shadowtex0/1 + water RGB tag in
// shadowcolor0). FAIL-SAFE contract, the INVERSE of shadowVis1: returns 0.0
// outside the shadow map bounds and in EVERY inconclusive case (no translucent
// in front, non-water tag) -> never any phantom absorption at distance.
float waterAboveShadow(vec3 vPos, float lightWy) {
    vec3 sc = toShadowClip(vPos, vec3(0.0, 1.0, 0.0));
    float f = getDistortFactor(sc.xy);
    vec3 sp = distortShadow(sc, f) * 0.5 + 0.5;
    if (sp.x < 0.0 || sp.x > 1.0 || sp.y < 0.0 || sp.y > 1.0) return 0.0;
    float zb = sp.z - 0.0009 * (VLX_SHADOW_ZSCALE * 2.0); // constant world-space bias
    float z1 = texture2D(shadowtex1, sp.xy).r;
    float z0 = texture2D(shadowtex0, sp.xy).r;
    // Needs a TRANSLUCENT (not an opaque) between the light and the point:
    // tex0 < zb <= tex1, otherwise there is no water above -> 0.0.
    if (zb > z1 || zb <= z0) return 0.0;
    vec4 tcol4 = texture2D(shadowcolor0, sp.xy);
#if SHADOW_TEX1_GATE_FIX == 1
    // RGB tag (shadow.fsh): WATER = low band max(rgb)<0.325, tint rgb/0.30 plus
    // blue-green dominance. Must stay in sync with the caustics site below.
    vec3 tw = clamp(tcol4.rgb / 0.30, 0.0, 1.0);
    float wn = step(max(max(tcol4.r, tcol4.g), tcol4.b), 0.325)
             * clamp((tw.b - tw.r) + (tw.g - tw.r), 0.0, 1.0);
#else
    float wn = step(0.75, tcol4.a)
             * clamp((tcol4.b - tcol4.r) + (tcol4.g - tcol4.r), 0.0, 1.0);
#endif
    if (wn < 0.01) return 0.0;
    return shadowZToVertical(zb - z0, lightWy);
}
// GLASS variant. A pane standing ABOVE or BESIDE the water is itself a
// TRANSLUCENT, so along the light ray it is the fragment that wins shadowtex0
// and shadowcolor0: the tag read back sits in the GLASS band [0.35..0.65], the
// water test above fails and the fail-safe 0.0 comes out even though there IS
// a water column under the pane. In the glass branch that 0.0 collapses BOTH
// consumers at once (the column weight AND the derived surface level), which is
// why a pane laid over a lake got no water treatment at all while the same lake
// seen through a wall window did. It is also sun-dependent: at noon the pane
// sits exactly over its own reflection point, at a low sun it does not -- the
// classic "it worked once and never again" report.
// Repair: when the straight tap comes back empty, retry on a few points offset
// HORIZONTALLY in world space around the receiver. A pane is at most one block
// wide, so a 1.5 / 3.0 block sidestep leaves its shadow footprint and lands on
// the open water beside it, whose column height equals this one to within the
// floor's own slope. The ENTIRE fail-safe contract is preserved: every retry is
// the same helper, so each one still demands a real water RGB tag between the
// light and the point, and a dry room behind a window still measures 0.0.
// Cost: paid on glass pixels only, and only on the ones the straight tap fails.
float waterAboveShadowGlass(vec3 vPos, float lightWy) {
    float v = waterAboveShadow(vPos, lightWy);
    if (v > 0.0) return v;
    // The sidestep fires ONLY on the exact signature of the bug: the shadow map
    // DOES hold a translucent between the light and this point (tex0 < zb <=
    // tex1, the same window the base helper opens) and its tag simply was not
    // water -- i.e. the pane itself won the depth test and hid the column. A
    // point with NOTHING translucent above it (dry ground under open sky, a
    // solid roof, outside the map) returns 0.0 right here, untouched, so the
    // retry cannot invent a column where the straight tap saw clear sky: the
    // fail-safe contract is not widened, only un-blinded.
    vec3 scg = toShadowClip(vPos, vec3(0.0, 1.0, 0.0));
    float fg = getDistortFactor(scg.xy);
    vec3 spg = distortShadow(scg, fg) * 0.5 + 0.5;
    if (spg.x < 0.0 || spg.x > 1.0 || spg.y < 0.0 || spg.y > 1.0) return 0.0;
    float zbg = spg.z - 0.0009 * (VLX_SHADOW_ZSCALE * 2.0); // same bias as above
    if (zbg > texture2D(shadowtex1, spg.xy).r) return 0.0;  // opaque in front
    if (zbg <= texture2D(shadowtex0, spg.xy).r) return 0.0; // nothing translucent above
#if SHADOW_TEX1_GATE_FIX == 1
    // ...and that translucent must be a PANE. The two tests above only prove
    // that SOMETHING translucent stands in the light path; the sidestep is for
    // one single fault (a pane winning the depth test over the water it covers)
    // and must not open a 3-block search for any other translucent. Without
    // this band test a greenhouse roof over a garden, or ice, or a portal, let
    // the loop dress the ground with the column of a decorative pond two blocks
    // away at the same world Y. GLASS band [0.35..0.65], max(rgb) < 0.675 and
    // >= 0.325 -- same decode as the VL shadow probe and as shadow.fsh's own
    // encoding; keep the three in sync. The legacy tag (SHADOW_TEX1_GATE_FIX 0)
    // has no glass band at all, so it keeps the wider behaviour.
    vec4 scgT = texture2D(shadowcolor0, spg.xy);
    float tagMxG0 = max(max(scgT.r, scgT.g), scgT.b);
    if (tagMxG0 < 0.325 || tagMxG0 >= 0.675) return 0.0;
#endif
    // World X / Z axes expressed in view space: the sidestep must be HORIZONTAL
    // in the world, not on the screen, or it would slide along the column.
    vec3 exV = mat3(gbufferModelView) * vec3(1.0, 0.0, 0.0);
    vec3 ezV = mat3(gbufferModelView) * vec3(0.0, 0.0, 1.0);
    for (int kg = 0; kg < 8; kg++) {
        float ag = float(kg) * 1.5707963;      // 4 axes, twice
        float rg = (kg < 4) ? 1.5 : 3.0;       // then the same 4 further out
        v = waterAboveShadow(vPos + (exV * cos(ag) + ezV * sin(ag)) * rg, lightWy);
        if (v > 0.0) return v;
    }
    return 0.0;
}
#endif
#endif

// ==================== G3: SHARED REFLECTION-FALLBACK HELPERS ====================
// Declared HERE, at preprocessor depth 0, on purpose: the three of them are
// called from the water branch, the glass branch, the wet-ground block and the
// opaque PBR branch, which sit under four different gates (SSR_ENABLED,
// GLASS_EFFECTS, RAIN_WET, PBR_REFLECTIONS). Putting them under any one of
// those would delete them from a build that still needs them.

// GROUND radiance a MISSED reflection ray should carry when it points DOWN
// instead of at the sky. Same recipe as ssrLocalAmb (half the pixel's ambient,
// half the pixel's own outgoing radiance -- which already carries albedo,
// block light and GI -- scaled by SSR_AMB_FLOOR), written out instead of
// calling it because ssrLocalAmb only exists under SSR_FALLBACK_V2 and this
// fallback has to work at 0 as well. See REFLECT_GROUND_FB in settings for the
// derivation: a ground albedo (0.06 water .. 0.20 sand) is exactly the factor
// the sky fallback is missing below the horizon, and SSR_AMB_FLOOR (0.35) is
// the pack's own already-calibrated stand-in for it.
vec3 vlxGroundFB(vec3 surfCol) { return (gAmbC * 0.5 + surfCol * 0.5) * SSR_AMB_FLOOR; }

// Validity of the SKY fallback as a function of the REFLECTED ELEVATION.
// Upper bound 0.02: the exact elevation where lib/sky.glsl's getClouds() starts
// fading coverage in (a = cov * smoothstep(0.02, 0.12, dir.y)), so the ground
// blend can never cut into the cloud deck.
// Lower bound -0.04: 2.3 deg under the horizon. At the ~43 deg vertical FOV of
// a default 1080p frame (70 deg horizontal, 16:9) that is ~58 px, so the
// transition reads as a gradient instead of the hard edge being reported; and
// 2.3 deg is small enough that the reflection of the real horizon line (which
// sits AT dir.y = 0) is not pushed off the pane.
float vlxSkyValid(float ry) { return smoothstep(-0.04, 0.02, ry); }

// Extinction of the MIRRORED SOLAR / LUNAR DISC by the shadow visibility
// 'vis', leaving the rest of the dome untouched. bodyW MUST be the direction
// the shadow map actually tests (lightW: sun by day, moon by night), so the
// disc being masked is the one whose occlusion 'vis' measured. Cone = the same
// celestialDisc the sky itself draws, radius x1.5 -- see SUN_MIRROR_SHADOW.
float vlxSunMirror(vec3 rworld, vec3 bodyW, float vis) {
    return mix(1.0, clamp(vis, 0.0, 1.0), celestialDisc(rworld, bodyW, SUN_SIZE * 1.5));
}

#ifdef SSR_ENABLED
// ============================ SSR ENGINE STATE ==============================
// Two globals instead of two extra ssrRay parameters: the function has EIGHT
// call sites and TWO variants, and a gated signature would have to be spelled
// out in every one of them. A global is written/read in the same frame, on the
// same invocation, with no aliasing.
//
// A3 (SSR_STEP_V2): view-space normal of the REFLECTING surface. Set it right
// before the call; a zero vector falls back to the legacy along-the-ray offset,
// so a missed call site degrades instead of breaking.
vec3 ssrOriN = vec3(0.0);
// A4 (SSR_EDGE_V2): distance from the hit that was just returned to the NEAREST
// frame border, in SUB-RECT PIXELS (so it is TAAU- and aspect-correct), taken as
// the minimum of the two axes and clamped at 0. 'hit' already carries the
// geometric fade over SSR_EDGE_PX; a caller that knows the reflected colour
// multiplies in a second, contrast-widened band on top of it -- see the water
// branch. 0.0 on a miss (no caller reads it there).
float ssrEdgePx = 0.0;

#if PERF_SSR_ROUGH == 1
// PERF_SSR_ROUGH: effective march / refine budgets, same global-not-parameter
// pattern as ssrOriN above (eight call sites, two variants). The opaque-PBR
// block LOWERS them on already-blurry lobes (alphaG > 0.09 -> 24 steps /
// 4 bisections: a lobe the footprint filter + GGX jitter already spread does
// not need mirror-grade march precision) and RESTORES them right after its
// last ray; every other consumer (water, glass panes, DH, sky-occlusion)
// marches at the full SSR_STEPS / SSR_REFINE. The caps only ever LOWER the
// budget: a cap >= the compile-time constant is inert by construction.
int ssrStepCap = SSR_STEPS;
int ssrRefineCap = SSR_REFINE;
#endif

#if PERF_WATER_SSR_CB == 1
// C1b (LOT C, lib/settings.glsl): march-step multiplier of the WATER rays,
// same global-not-parameter pattern as ssrStepCap above. 1.0 = neutral
// everywhere (IEEE: x * 1.0 is exact, the march is bit-identical); the water
// branch fades it 1.0 -> 2.0 over 20..30 blocks of pixel distance (eye out
// only) and RESTORES it after its last ray. At mul the three step bounds
// (SSR_STEP0_PIX / SSR_PIX_MIN / pixMax and the SSR_ZSTEP depth guard) are
// multiplied and the march budget divided (break at SSR_STEPS / mul): same
// screen AND depth reach, half the taps at mul 2. SSR_REFINE untouched --
// the residual hit interval doubles (stepLen x2), accepted at 25+ blocks.
float ssrStepMul = 1.0;
#endif

#if SSR_EDGE_V2 == 1
// Overscan limit, a compile-time constant.
const float SSR_NDC_MAX = 1.0 + SSR_OVERSCAN;
// A depth tap taken outside the frame is clamped to the frame: the hit it
// validates is a one-texel extrapolation, which is why the edge fade is already
// small out there.
vec2 ssrClampUV(vec2 s) { return clamp(s, vec2(0.0005), vec2(TAAU_S - 0.0005)); }
// Screen-border fade, expressed as a BAND WIDTH IN PIXELS rather than as an
// exponent on |ndc|. A seam at the border is a screen artefact, so what decides
// whether it is visible is how many pixels wide the transition is; an exponent
// is a different physical width on each axis, at each render scale and at each
// FOV, and none of those should move this fade.
float ssrEdgeFade(float dPx, float bandPx) {
    return smoothstep(0.0, max(bandPx, 0.001), dPx);
}
// Distance from a clip-space position to the nearest frame border (overscan
// included), in sub-rect pixels, min of the two axes.
float ssrBorderPx(vec4 c) {
    vec2 nd = abs(c.xy / c.w);
    vec2 d = (vec2(SSR_NDC_MAX) - nd) * (0.5 * TAAU_S * vec2(viewWidth, viewHeight));
    return max(min(d.x, d.y), 0.0);
}
#else
vec2 ssrClampUV(vec2 s) { return s; }
#endif

#if SSR_HIT_V2 == 1
// A1. Half-width of the acceptance window around the visible surface, in view
// units. Three floors, in order of who wins where:
//   SSR_TOL_REL * |z|  -- the physical term. A depth difference is only
//                         meaningful relative to the depth it is measured at;
//                         every comparable pack uses a relative threshold
//                         (iterationT 20%, Bliss 15%, Complementary 1 + 20%).
//   SSR_TOL_MIN        -- floor near the camera, where 12% of 0.5 block is
//                         below the depth buffer's own quantisation.
//   stepLen / 2^(R+1)  -- HALF the residual bisection interval. Without it the
//                         test becomes structurally unsatisfiable once the
//                         geometric growth makes stepLen / 2^R exceed the
//                         window (that happened past iteration ~25 with the
//                         legacy 1.0 + 0.04d, which is why far SSR never hit).
float ssrTol(float zr, float stepLen) {
#if PERF_SSR_ROUGH == 1
    // The bisection floor tracks the EFFECTIVE refine count: with the rough
    // cap (4 bisections) the residual interval is stepLen / 2^4, and the
    // acceptance window must keep covering HALF of it or far rough hits
    // become structurally unsatisfiable (the very failure this floor fixed).
    // ssrRefineCap == SSR_REFINE outside the capped block -> identical there.
    return max(max(SSR_TOL_MIN, SSR_TOL_REL * zr),
               stepLen * (0.5 / exp2(float(ssrRefineCap))));
#else
    return max(max(SSR_TOL_MIN, SSR_TOL_REL * zr),
               stepLen * (0.5 / exp2(float(SSR_REFINE))));
#endif
}
// A1. How far BEHIND the visible surface the refined point may sit and still
// count as being INSIDE the object rather than past it. Never below the
// acceptance window itself, so the classification is continuous.
float ssrThick(float zr, float tol) {
    return max(tol, SSR_THICK * max(0.5, 0.05 * zr));
}
#if SSR_V3 == 1
// SSR_V3 (b). CONTINUOUS acceptance confidence, replacing the boolean the two
// bounds of ssrTol / ssrThick produce. Same acceptance SET (conf > 0 exactly
// where the boolean was true, minus the measure-zero boundary), graded weight:
// the caller multiplies its 'hit' by it, so a hit that only just fits the
// window is blended with the fallback instead of replacing it outright.
//   behind  = sceneZ - hi.z  (>0 = the refined point sits BEHIND the surface)
//   tolH    = half-width of the acceptance window in FRONT of the surface
//   thickH  = presumed thickness accepted BEHIND it
//   jitFoot = how far the ray's own depth moves when the raster slides by the
//             TAA jitter (see SSR_V3_JIT_TOL in lib/settings.glsl). The ramp is
//             never narrower than that footprint -- a fade whose width is under
//             the jitter it exists to absorb is a step again -- and never wider
//             than the bound itself, so at a footprint larger than the window
//             the confidence degenerates into a triangle on the window and the
//             test simply stops claiming precision it does not have.
// MEASURED (settings block): at SSR_TOL_REL 0.12 this is nearly inert -- the
// window is 12% of the depth and the jitter moves the comparison by half a
// texel, so the ramp is only ever entered on the THICKNESS side, by hits that
// slipped behind a thin silhouette. That is exactly the set it should degrade.
float ssrConf(float behind, float tolH, float thickH, float jitFoot) {
    float wN = max(max(SSR_V3_CONF * tolH,   min(jitFoot, tolH)),   1e-4);
    float wF = max(max(SSR_V3_CONF * thickH, min(jitFoot, thickH)), 1e-4);
    float cN = 1.0 - smoothstep(tolH   - wN, tolH,   max(-behind, 0.0));
    float cF = 1.0 - smoothstep(thickH - wF, thickH, max( behind, 0.0));
    return cN * cF;
}
#endif
#endif

// View-space raymarch with binary refinement; hit = confidence (0 = miss).
// ANY crossing (p.z < sview.z) triggers the binary search, then the refined
// point is VALIDATED against real depth. A thin silhouette in front of a far
// background CONTINUES the march instead of aborting. Growth 1.22 (an UPPER
// bound on the growth once SSR_STEP_V2 clamps the step in pixels), SSR_STEPS
// steps, SSR_REFINE bisections.
// The step is ALREADY adaptive (geometric growth + final binary refine), so
// SSR_FAST does not change the marching scheme; it removes the per-step
// mat4 work instead (see the gated variant below).
#if SSR_FAST == 1
// SSR_FAST: same march (start, growth 1.22, 48 steps, 6-step binary refine,
// surface validation, silhouette pass-through) but clip(p) is AFFINE in p,
// so clip-space positions are tracked INCREMENTALLY: clipP += clipD*stepLen
// replaces a mat4*vec4 per step, and each binary midpoint projects as the
// MEAN of the endpoint clips. ~16 MAD -> 4 MAD per step and per refine step;
// result identical up to float rounding.
vec2 ssrRay(vec3 origin, vec3 dir, float dither, out float hit) {
    hit = 0.0;
    ssrEdgePx = 0.0;
#if SSR_STEP_V2 == 1 || SSR_EDGE_V2 == 1
    float zOri = max(abs(origin.z), 0.05); // VIEW DEPTH of the reflecting surface
#endif
#if SSR_STEP_V2 == 1
    // A3. Offset along the NORMAL, sized in SCREEN PIXELS. Along the RAY (the
    // legacy 0.25 + dither * 0.25) the offset barely leaves the surface at
    // grazing incidence, which is exactly where self-hit acne appears; along the
    // normal the clearance is the same at every incidence. The MAGNITUDE is one
    // texel footprint times SSR_START_PX: the world size of a texel at view
    // depth z is z / f, so this displaces the origin by a CONSTANT number of
    // pixels at every distance instead of by a growing number of blocks. The
    // dither keeps a sub-step jitter along the ray so the march phase still
    // decorrelates.
    float fPx = max(0.5 * viewHeight * TAAU_S * gbufferProjection[1][1], 1.0);
    vec3 nOff = (dot(ssrOriN, ssrOriN) > 0.5) ? ssrOriN : dir;
    vec3 p = origin + nOff * max(0.05, SSR_START_PX * zOri / fPx) + dir * (dither * 0.25);
    float stepLen = 0.0;  // set from the pixel metric on the first iteration
    // TAAU: the march samples the SUB-RECT, so a "pixel" here is a sub-rect
    // texel. Both this cap and the metric below carry TAAU_S, so the FRACTION of
    // the frame covered per step is resolution-scale independent (and the factor
    // folds away at TAAU_S = 1.0).
    float pixMax = length(vec2(viewWidth, viewHeight)) * (TAAU_S / SSR_PIX_DIV);
#else
    vec3 p = origin + dir * (0.25 + dither * 0.25);
    float stepLen = 0.5;
#endif
#if SSR_EDGE_V2 == 1
    float travel = 0.0; // ray length actually walked, for the range fade
#endif
    vec4 clipD = gbufferProjection * vec4(dir, 0.0);
    vec4 clipP = gbufferProjection * vec4(p, 1.0);

    for (int i = 0; i < SSR_STEPS; i++) {
#if PERF_SSR_ROUGH == 1
        if (i >= ssrStepCap) break; // PERF_SSR_ROUGH: rough-lobe march budget
#endif
#if PERF_WATER_SSR_CB == 1
        // C1b: far-water budget = SSR_STEPS / mul (the bounds below are
        // multiplied by the same mul, so the REACH is preserved). Inert at
        // mul 1.0: float(i) < SSR_STEPS holds for every loop index.
        if (float(i) * ssrStepMul >= float(SSR_STEPS)) break;
#endif
#if SSR_STEP_V2 == 1
        // A3. Screen-space step bounding. clipP is the clip of the CURRENT p, so
        // d(ndc)/dt of the projective line is available in closed form here:
        //   d(ndc.xy)/dt = (clipD.xy * w - clipP.xy * clipD.w) / w^2
        // times half the viewport gives pixels per unit of ray length. Without
        // this the fixed 0.5-block first step is ~90 px at 5 blocks (no contact
        // reflections) and step 20 is 23 blocks / >4000 px (tunnelling).
        float wC = max(clipP.w, 1e-4);
        vec2 dpix = (clipD.xy * clipP.w - clipP.xy * clipD.w) / (wC * wC)
                  * vec2(viewWidth, viewHeight) * (0.5 * TAAU_S); // TAAU: sub-rect texels
        float ppu = max(length(dpix), 0.05); // guard: ray nearly along the view axis
        float minPix = (i == 0) ? SSR_STEP0_PIX : SSR_PIX_MIN;
        float maxPix = (i == 0) ? SSR_STEP0_PIX : pixMax;
#if PERF_WATER_SSR_CB == 1
        // C1b: doubled pixel step for far water -- BOTH bounds carry the mul
        // so the clamp chain cannot undo it (x1.0 exact everywhere else).
        minPix *= ssrStepMul;
        maxPix *= ssrStepMul;
#endif
        stepLen = clamp(stepLen, minPix / ppu, maxPix / ppu);
        // A3. RELATIVE DEPTH bound, and it is NOT optional: a pixel bound alone
        // is degenerate for a ray pointing nearly along the view axis, which is
        // exactly the grazing water-to-horizon case. Such a ray barely moves on
        // screen (ppu -> 0), so the pixel cap authorises an enormous world step
        // that skips every surface in DEPTH while moving only 79 px. Capping the
        // step at a fraction of the current view depth keeps the depth resolution
        // RELATIVE, in the same spirit as the acceptance window: by construction
        // the depth then grows by at most x1.35 per step, and ln(192)/ln(1.35) =
        // 17.5, so a 192-block render distance is still crossed in ~18 steps.
#if PERF_WATER_SSR_CB == 1
        // C1b: the depth guard follows the doubled step (x1.35 -> x1.7 of
        // depth growth per step at mul 2: the world is crossed in half the
        // steps, which is the whole point of the halved budget above).
        stepLen = min(stepLen, SSR_ZSTEP * ssrStepMul * max(abs(p.z), 0.25));
#else
        stepLen = min(stepLen, SSR_ZSTEP * max(abs(p.z), 0.25));
#endif
        stepLen = min(stepLen, 512.0); // absolute safety net
#endif
        vec3 prev = p;
        vec4 cPrev = clipP;
        p += dir * stepLen;
        clipP += clipD * stepLen; // incremental projection (affine along the ray)
#if SSR_EDGE_V2 == 1
        travel += stepLen;
#endif
        if (clipP.w <= 0.0) return vec2(0.0);
        vec3 ndc = clipP.xyz / clipP.w;
#if SSR_EDGE_V2 == 1
        // A4. Overscan: the march is allowed a little way outside the frame
        // instead of dying at the border. Taps are clamped back into it.
        if (abs(ndc.x) > SSR_NDC_MAX || abs(ndc.y) > SSR_NDC_MAX) return vec2(0.0);
#else
        if (abs(ndc.x) > 1.0 || abs(ndc.y) > 1.0) return vec2(0.0);
#endif

        vec2 suv = ssrClampUV((ndc.xy * 0.5 + 0.5) * TAAU_S); // TAAU: NDC -> sub-rect UV
        float sd = texture2D(depthtex0, suv).r;
        if (sd < 1.0) {
            vec3 sview = toView(suv, sd);
            if (p.z < sview.z) {
                vec3 lo = prev;  vec4 cLo = cPrev;
                vec3 hi = p;     vec4 cHi = clipP;
                for (int k = 0; k < SSR_REFINE; k++) {
#if PERF_SSR_ROUGH == 1
                    if (k >= ssrRefineCap) break; // PERF_SSR_ROUGH: rough-lobe refine budget
#endif
                    vec3 mid = (lo + hi) * 0.5;
                    vec4 mc = (cLo + cHi) * 0.5; // affine: mean of endpoint clips
                    vec2 muv = ssrClampUV(((mc.xy / mc.w) * 0.5 + 0.5) * TAAU_S); // TAAU
                    float md = texture2D(depthtex0, muv).r;
                    if (mid.z < toView(muv, md).z) { hi = mid; cHi = mc; }
                    else { lo = mid; cLo = mc; }
                }
                vec4 hc = cHi; // clip of the refined point, tracked exactly
                vec2 huv = ssrClampUV(((hc.xy / hc.w) * 0.5 + 0.5) * TAAU_S); // TAAU
                float sceneZ = toView(huv, texture2D(depthtex0, huv).r).z;
#if SSR_HIT_V2 == 1
                // A1. Relative window + thickness model. View z is negative
                // forward, so 'behind' > 0 means the refined point sits BEHIND
                // the visible surface. Behind by less than the presumed
                // thickness = it is INSIDE the object -> hit. Behind by more =
                // the ray slipped past it -> keep marching (that distinction is
                // what the legacy code lacked: it kept marching in BOTH cases,
                // and then validated a surface not visible from the origin).
                float zrH = max(abs(hi.z), 0.05);
                float tolH = ssrTol(zrH, stepLen);
                float behind = sceneZ - hi.z;
                bool ok = (behind <= ssrThick(zrH, tolH)) && (behind >= -tolH);
#if SSR_V3 == 1
                // SSR_V3 (b). The SAME window, graded: ssrCf multiplies 'hit'
                // just before the return, so an acceptance that only just fits
                // fades into the caller's fallback instead of switching to it.
#if SSR_STEP_V2 == 1 && defined TAA
                // Jitter footprint of THIS ray. The raster slides by TAA_JITTER
                // texel; the ray covers ppu sub-rect texels per unit of length
                // and gains |dir.z| of view depth over that same unit, so the
                // depth being compared moves by TAA_JITTER * |dir.z| / ppu when
                // the frame's jitter changes. Both terms are already in
                // registers -- the margin costs one abs, one divide, one mul.
                float ssrJf = SSR_V3_JIT_TOL * TAA_JITTER * abs(dir.z) / ppu;
#else
                float ssrJf = 0.0; // no pixel metric (SSR_STEP_V2 0) or no jitter (TAA off)
#endif
                float ssrCf = ssrConf(behind, tolH, ssrThick(zrH, tolH), ssrJf);
                if (ssrCf <= 0.0) ok = false;
#endif
#if SSR_BACKFACE == 1
                if (ok) {
                    // A1. The hit surface must FACE the ray. length() instead of
                    // normalize() so an unwritten colortex1 texel (n = 0) is
                    // skipped rather than turned into a NaN.
                    // SENTINEL GUARD: gbuffers_textured / textured_lit / hand
                    // write vec4(0.5, 0.5, 0.0, 1.0) into colortex1 instead of a
                    // real normal. That decodes to the unit vector (0, 0, -1),
                    // which passes the length test above and then fails the
                    // facing test for EVERY ray heading away from the camera --
                    // i.e. rain, splashes, fire, smoke and the hand vanished
                    // from every reflection. Only the sentinel has rg EXACTLY at
                    // (0.5, 0.5); a real view normal with x = y = 0 faces
                    // straight along the view axis and is either invisible or a
                    // backface anyway, so skipping the test on it costs nothing.
                    vec2 nHitXY = texture2D(colortex1, huv).rg;
                    if (abs(nHitXY.x - 0.5) + abs(nHitXY.y - 0.5) > 0.002) {
                        vec3 nHit = texture2D(colortex1, huv).rgb * 2.0 - 1.0;
                        float nHitL = length(nHit);
                        if (nHitL > 0.1 && dot(nHit, dir) > SSR_BACKFACE_TOL * nHitL) ok = false;
                    }
                }
#endif
#else
                // The refined point must MATCH the visible surface at this UV
                // (~1 block tolerance + distance margin). A miss means a
                // silhouette depth gap -> no return, keep marching behind it.
                float tolH = 1.0 + length(hi) * 0.04;
                bool ok = (hi.z > sceneZ - tolH && hi.z < sceneZ + tolH);
#endif
                if (ok) {
                    // Reject SELF-intersection only (water hit within 2 blocks of
                    // the origin = the pixel reflecting itself). Distant water
                    // hits (neighbouring swell) are valid reflections.
                    if (texture2D(colortex2, huv).b > 0.95 && length(hi - origin) < 2.0) return vec2(0.0);
#if SSR_EDGE_V2 == 1
                    // A4. Border fade over a band measured in PIXELS instead of
                    // a ramp over a fraction of NDC, and a range fade driven by
                    // the ray's OWN EXCURSION instead of the iteration index
                    // (the legacy 38 -> 48 fade removed precisely the far hits
                    // it was supposed to keep). The excursion is travel minus
                    // the depth the ray started at: a reflection that starts 40
                    // blocks away must not be charged for those 40 blocks, which
                    // is what made far water stop reflecting the far shore.
                    ssrEdgePx = ssrBorderPx(hc);
                    float marchF = 1.0 - smoothstep(far * (SSR_RANGE * 0.80), far * SSR_RANGE,
                                                    max(travel - zOri, 0.0));
                    hit = ssrEdgeFade(ssrEdgePx, SSR_EDGE_PX) * marchF;
#else
                    float edgeF = smoothstep(1.0, 0.70, max(abs(hc.x / hc.w), abs(hc.y / hc.w)));
                    float marchF = 1.0 - smoothstep(float(SSR_STEPS) - 10.0, float(SSR_STEPS), float(i));
                    hit = edgeF * marchF;
#endif
#if SSR_V3 == 1 && SSR_HIT_V2 == 1
                    // SSR_V3 (b): the acceptance confidence joins the two fades
                    // the border and the range already contribute. Under the
                    // legacy SSR_HIT_V2 = 0 test there is no window to grade, so
                    // this term does not exist there.
                    hit *= ssrCf;
#endif
                    if (hit <= 0.0) return vec2(0.0);
                    return huv;
                }
            }
        }
        stepLen *= 1.22;
    }
    return vec2(0.0);
}
#else
vec2 ssrRay(vec3 origin, vec3 dir, float dither, out float hit) {
    hit = 0.0;
    ssrEdgePx = 0.0;
#if SSR_STEP_V2 == 1 || SSR_EDGE_V2 == 1
    float zOri = max(abs(origin.z), 0.05); // VIEW DEPTH of the reflecting surface
#endif
#if SSR_STEP_V2 == 1
    // A3, see the SSR_FAST variant for the derivation. This path pays ONE extra
    // mat4 for clipP before the loop and 4 MAD per step to keep it in sync; the
    // authoritative per-step 'clip' below is untouched, clipP only feeds the
    // pixel metric.
    float fPx = max(0.5 * viewHeight * TAAU_S * gbufferProjection[1][1], 1.0);
    vec3 nOff = (dot(ssrOriN, ssrOriN) > 0.5) ? ssrOriN : dir;
    vec3 p = origin + nOff * max(0.05, SSR_START_PX * zOri / fPx) + dir * (dither * 0.25);
    float stepLen = 0.0;
    // TAAU: the march samples the SUB-RECT, so a "pixel" here is a sub-rect
    // texel. Both this cap and the metric below carry TAAU_S, so the FRACTION of
    // the frame covered per step is resolution-scale independent (and the factor
    // folds away at TAAU_S = 1.0).
    float pixMax = length(vec2(viewWidth, viewHeight)) * (TAAU_S / SSR_PIX_DIV);
    vec4 clipD = gbufferProjection * vec4(dir, 0.0);
    vec4 clipP = gbufferProjection * vec4(p, 1.0);
#else
    vec3 p = origin + dir * (0.25 + dither * 0.25);
    float stepLen = 0.5;
#endif
#if SSR_EDGE_V2 == 1
    float travel = 0.0;
#endif

    for (int i = 0; i < SSR_STEPS; i++) {
#if PERF_SSR_ROUGH == 1
        if (i >= ssrStepCap) break; // PERF_SSR_ROUGH: rough-lobe march budget
#endif
#if PERF_WATER_SSR_CB == 1
        // C1b: far-water budget = SSR_STEPS / mul (the bounds below are
        // multiplied by the same mul, so the REACH is preserved). Inert at
        // mul 1.0: float(i) < SSR_STEPS holds for every loop index.
        if (float(i) * ssrStepMul >= float(SSR_STEPS)) break;
#endif
#if SSR_STEP_V2 == 1
        float wC = max(clipP.w, 1e-4);
        vec2 dpix = (clipD.xy * clipP.w - clipP.xy * clipD.w) / (wC * wC)
                  * vec2(viewWidth, viewHeight) * (0.5 * TAAU_S); // TAAU: sub-rect texels
        float ppu = max(length(dpix), 0.05);
        float minPix = (i == 0) ? SSR_STEP0_PIX : SSR_PIX_MIN;
        float maxPix = (i == 0) ? SSR_STEP0_PIX : pixMax;
#if PERF_WATER_SSR_CB == 1
        // C1b: doubled pixel step for far water -- BOTH bounds carry the mul
        // so the clamp chain cannot undo it (x1.0 exact everywhere else).
        minPix *= ssrStepMul;
        maxPix *= ssrStepMul;
#endif
        stepLen = clamp(stepLen, minPix / ppu, maxPix / ppu);
        // A3. RELATIVE DEPTH bound, and it is NOT optional: a pixel bound alone
        // is degenerate for a ray pointing nearly along the view axis, which is
        // exactly the grazing water-to-horizon case. Such a ray barely moves on
        // screen (ppu -> 0), so the pixel cap authorises an enormous world step
        // that skips every surface in DEPTH while moving only 79 px. Capping the
        // step at a fraction of the current view depth keeps the depth resolution
        // RELATIVE, in the same spirit as the acceptance window: by construction
        // the depth then grows by at most x1.35 per step, and ln(192)/ln(1.35) =
        // 17.5, so a 192-block render distance is still crossed in ~18 steps.
#if PERF_WATER_SSR_CB == 1
        // C1b: the depth guard follows the doubled step (x1.35 -> x1.7 of
        // depth growth per step at mul 2: the world is crossed in half the
        // steps, which is the whole point of the halved budget above).
        stepLen = min(stepLen, SSR_ZSTEP * ssrStepMul * max(abs(p.z), 0.25));
#else
        stepLen = min(stepLen, SSR_ZSTEP * max(abs(p.z), 0.25));
#endif
        stepLen = min(stepLen, 512.0); // absolute safety net
#endif
        vec3 prev = p;
        p += dir * stepLen;
#if SSR_STEP_V2 == 1
        clipP += clipD * stepLen;
#endif
#if SSR_EDGE_V2 == 1
        travel += stepLen;
#endif
        vec4 clip = gbufferProjection * vec4(p, 1.0);
        if (clip.w <= 0.0) return vec2(0.0);
        vec3 ndc = clip.xyz / clip.w;
#if SSR_EDGE_V2 == 1
        if (abs(ndc.x) > SSR_NDC_MAX || abs(ndc.y) > SSR_NDC_MAX) return vec2(0.0);
#else
        if (abs(ndc.x) > 1.0 || abs(ndc.y) > 1.0) return vec2(0.0);
#endif

        vec2 suv = ssrClampUV((ndc.xy * 0.5 + 0.5) * TAAU_S); // TAAU: NDC -> sub-rect UV
        float sd = texture2D(depthtex0, suv).r;
        if (sd < 1.0) {
            vec3 sview = toView(suv, sd);
            if (p.z < sview.z) {
                vec3 lo = prev;
                vec3 hi = p;
                for (int k = 0; k < SSR_REFINE; k++) {
#if PERF_SSR_ROUGH == 1
                    if (k >= ssrRefineCap) break; // PERF_SSR_ROUGH: rough-lobe refine budget
#endif
                    vec3 mid = (lo + hi) * 0.5;
                    vec4 mc = gbufferProjection * vec4(mid, 1.0);
                    vec2 muv = ssrClampUV(((mc.xy / mc.w) * 0.5 + 0.5) * TAAU_S); // TAAU
                    float md = texture2D(depthtex0, muv).r;
                    if (mid.z < toView(muv, md).z) hi = mid; else lo = mid;
                }
                vec4 hc = gbufferProjection * vec4(hi, 1.0);
                vec2 huv = ssrClampUV(((hc.xy / hc.w) * 0.5 + 0.5) * TAAU_S); // TAAU
                float sceneZ = toView(huv, texture2D(depthtex0, huv).r).z;
#if SSR_HIT_V2 == 1
                // A1, see the SSR_FAST variant for the full comment.
                float zrH = max(abs(hi.z), 0.05);
                float tolH = ssrTol(zrH, stepLen);
                float behind = sceneZ - hi.z;
                bool ok = (behind <= ssrThick(zrH, tolH)) && (behind >= -tolH);
#if SSR_V3 == 1
                // SSR_V3 (b), see the SSR_FAST variant for the full comment.
#if SSR_STEP_V2 == 1 && defined TAA
                float ssrJf = SSR_V3_JIT_TOL * TAA_JITTER * abs(dir.z) / ppu;
#else
                float ssrJf = 0.0; // no pixel metric (SSR_STEP_V2 0) or no jitter (TAA off)
#endif
                float ssrCf = ssrConf(behind, tolH, ssrThick(zrH, tolH), ssrJf);
                if (ssrCf <= 0.0) ok = false;
#endif
#if SSR_BACKFACE == 1
                if (ok) {
                    // Sentinel guard, see the SSR_FAST variant for the full
                    // comment: colortex1 carries vec4(0.5, 0.5, 0.0, 1.0) on
                    // particles and on the hand, which decodes to a unit normal
                    // that would fail this test for every outgoing ray.
                    vec2 nHitXY = texture2D(colortex1, huv).rg;
                    if (abs(nHitXY.x - 0.5) + abs(nHitXY.y - 0.5) > 0.002) {
                        vec3 nHit = texture2D(colortex1, huv).rgb * 2.0 - 1.0;
                        float nHitL = length(nHit);
                        if (nHitL > 0.1 && dot(nHit, dir) > SSR_BACKFACE_TOL * nHitL) ok = false;
                    }
                }
#endif
#else
                // The refined point must MATCH the visible surface at this UV
                // (~1 block tolerance + distance margin). A miss means a
                // silhouette depth gap -> no return, keep marching behind it.
                float tolH = 1.0 + length(hi) * 0.04;
                bool ok = (hi.z > sceneZ - tolH && hi.z < sceneZ + tolH);
#endif
                if (ok) {
                    // Reject SELF-intersection only (water hit within 2 blocks of
                    // the origin = the pixel reflecting itself). Distant water
                    // hits (neighbouring swell) are valid reflections.
                    if (texture2D(colortex2, huv).b > 0.95 && length(hi - origin) < 2.0) return vec2(0.0);
#if SSR_EDGE_V2 == 1
                    // A4, see the SSR_FAST variant for the full comment.
                    ssrEdgePx = ssrBorderPx(hc);
                    float marchF = 1.0 - smoothstep(far * (SSR_RANGE * 0.80), far * SSR_RANGE,
                                                    max(travel - zOri, 0.0));
                    hit = ssrEdgeFade(ssrEdgePx, SSR_EDGE_PX) * marchF;
#else
                    float edgeF = smoothstep(1.0, 0.70, max(abs(hc.x / hc.w), abs(hc.y / hc.w)));
                    float marchF = 1.0 - smoothstep(float(SSR_STEPS) - 10.0, float(SSR_STEPS), float(i));
                    hit = edgeF * marchF;
#endif
#if SSR_V3 == 1 && SSR_HIT_V2 == 1
                    hit *= ssrCf; // SSR_V3 (b), see the SSR_FAST variant
#endif
                    if (hit <= 0.0) return vec2(0.0);
                    return huv;
                }
            }
        }
        stepLen *= 1.22;
    }
    return vec2(0.0);
}
#endif

#if SSR_FALLBACK_V2 == 1
// A2. NEVER-BLACK FALLBACK.
// Every reflection branch used `sky * skyl` as its miss fallback, and skyl is
// EXACTLY zero in a cave, in the Nether and in the End. The composition is a
// mix(), so a missed ray there multiplies the surface by (1 - amt) -- down to
// x0.10 on a polished metal. That is the whole "metals are black underground"
// report, seen from the other end.
// LOCAL_AMB is the cheapest honest estimate of the radiance leaving the
// surroundings of the pixel: half the pixel's own ambient term (gAmbC, which
// already carries the dimension's ambient colour) and half the pixel's own
// OUTGOING radiance, which already carries block light, emissives and GI. That
// second half is what Complementary calls "the surface colour" and what Bliss
// initialises its background reflection to.
vec3 ssrLocalAmb(vec3 surfCol) { return (gAmbC * 0.5 + surfCol * 0.5) * SSR_AMB_FLOOR; }
// A2. Skylight-gated no-darkening factor. INDOORS (skyl -> 0) the fallback is
// an estimate, so the composition is not allowed to darken the pixel at all
// (k = 1): a polished iron block in a deep cave is then never darker than the
// same block with reflections off, which is the acceptance test for this gate.
// OUTDOORS the sky fallback is real content, so only a floor is kept.
float ssrNoDark(float skylV) {
    return mix(1.0, clamp(SSR_NO_DARKEN, 0.0, 1.0), smoothstep(0.0, 0.35, skylV));
}
#endif

#if SSR_PREV_FRAME == 1
// REFLECTIONS INSIDE REFLECTIONS: SSR hit color comes from the COMPLETE
// previous frame (colortex7 = TAA output, never cleared -- reflections, fog
// and volumetrics already composited) reprojected onto the hit world position.
// Outside the previous frame / w<=0: falls back to the current frame.
uniform sampler2D colortex7;
uniform mat4 gbufferPreviousModelView;
uniform mat4 gbufferPreviousProjection;
uniform vec3 previousCameraPosition;
vec3 ssrHitColor(vec2 huv) {
    float hd = texture2D(depthtex0, huv).r;
    vec3 hw = mat3(gbufferModelViewInverse) * toView(huv, hd)
            + gbufferModelViewInverse[3].xyz + cameraPosition;
    vec4 pc = gbufferPreviousProjection
            * (gbufferPreviousModelView * vec4(hw - previousCameraPosition, 1.0));
    if (pc.w > 0.0) {
        // TAAU: colortex7 (TAA output) is FULL RES -> full-res UV, NO * TAAU_S
        // here, unlike the pre-TAA scene buffers.
        vec2 puv = (pc.xy / pc.w) * 0.5 + 0.5;
        if (puv.x > 0.001 && puv.x < 0.999 && puv.y > 0.001 && puv.y < 0.999)
            return texture2D(colortex7, puv).rgb;
    }
    return texture2D(colortex0, huv).rgb;
}
#else
vec3 ssrHitColor(vec2 huv) { return texture2D(colortex0, huv).rgb; }
#endif

#if PBR_ROUGHNESS_V2 == 1
// ============ GLOSSY HIT FOOTPRINT (PBR_ROUGHNESS_V2) ============
// A rough reflection is a CONE, not a line: the further the ray travels the
// wider the patch of the scene it averages. The GGX taps below sample the
// LOBE, this filters the FOOTPRINT of each individual tap.
// NOTE on mips: colortex3 is the BLOOM pyramid (bright-pass written by
// composite2/composite3, mips generated in composite5). Both run AFTER this
// pass and colortex3 is cleared every frame, so at composite1 time it is
// BLACK -- it cannot serve as a pre-blurred scene color here, and no other
// buffer read by this pass carries a mip chain (enabling one on colortex0
// would also smear the invalid area outside the TAAU sub-rect into the low
// mips). Hence the documented fallback: a 4-tap rotated cross on the very
// buffer ssrHitColor already reads, at zero pipeline risk.
vec3 crossTap4(sampler2D tex, vec2 c, vec2 e0, vec2 e1, vec2 lo, vec2 hi) {
    vec3 s = texture2D(tex, c).rgb;
    s += texture2D(tex, clamp(c + e0, lo, hi)).rgb;
    s += texture2D(tex, clamp(c - e0, lo, hi)).rgb;
    s += texture2D(tex, clamp(c + e1, lo, hi)).rgb;
    s += texture2D(tex, clamp(c - e1, lo, hi)).rgb;
    return s * 0.2;
}
#if PBR_ROUGHNESS_V3 == 1
// Two-ring 9-tap (PBR_ROUGHNESS_V3). Once V3 lets the radius grow past ~8 px a
// single 5-tap cross stops reading as a blur and starts reading as 5 ghosts:
// the inner ring at 0.5 r, rotated 45 deg, fills the hole for 4 more fetches.
// The centre keeps a slightly higher weight so the reflection does not lose its
// anchor (a flat box would drift the highlight).
vec3 crossTap9(sampler2D tex, vec2 c, vec2 e0, vec2 e1, vec2 lo, vec2 hi) {
    vec3 s = texture2D(tex, c).rgb * 1.4;
    s += texture2D(tex, clamp(c + e0, lo, hi)).rgb;
    s += texture2D(tex, clamp(c - e0, lo, hi)).rgb;
    s += texture2D(tex, clamp(c + e1, lo, hi)).rgb;
    s += texture2D(tex, clamp(c - e1, lo, hi)).rgb;
    vec2 i0 = (e0 + e1) * 0.35355339; // 0.5 * (1/sqrt2): inner ring, rotated 45 deg
    vec2 i1 = (e0 - e1) * 0.35355339;
    s += texture2D(tex, clamp(c + i0, lo, hi)).rgb;
    s += texture2D(tex, clamp(c - i0, lo, hi)).rgb;
    s += texture2D(tex, clamp(c + i1, lo, hi)).rgb;
    s += texture2D(tex, clamp(c - i1, lo, hi)).rgb;
    return s * (1.0 / 9.4);
}
#endif
// Ring dispatch: a narrow footprint keeps the exact 5-tap cross (V2 cost, V2
// result); only a genuinely wide one pays the second ring. rad is SUB-RECT uv.
vec3 roughTap(sampler2D tex, vec2 c, vec2 e0, vec2 e1, vec2 lo, vec2 hi, float rad) {
#if PBR_ROUGHNESS_V3 == 1
    if (rad > 0.0045) return crossTap9(tex, c, e0, e1, lo, hi);
#endif
    return crossTap4(tex, c, e0, e1, lo, hi);
}
// radius is expressed in SUB-RECT uv units (same space as huv).
// Below ~0.7 sub-rect milli-uv the cross degenerates to the exact legacy tap,
// so a mirror pays exactly the legacy cost and returns the legacy color.
vec3 ssrHitColorRough(vec2 huv, float radius, float rot) {
    if (radius < 0.0007) return ssrHitColor(huv);
    float cs = cos(rot);
    float sn = sin(rot);
    // Aspect correction: a radius isotropic in UV is stretched by the aspect
    // ratio once expressed in PIXELS (1.78:1 on 16:9), which smeared the glossy
    // blur horizontally. Scaling Y by viewWidth/viewHeight makes the cross round
    // in pixel space; the HORIZONTAL extent is unchanged, so the radius caps
    // downstream keep their calibration.
    vec2 asp = vec2(1.0, viewWidth / viewHeight);
    vec2 e0 = vec2(cs, sn) * radius * asp;
    vec2 e1 = vec2(-sn, cs) * radius * asp;
#if SSR_PREV_FRAME == 1
    // Same reprojection as ssrHitColor, done ONCE, then the cross is taken in
    // colortex7 space (FULL RES -> the sub-rect radius is rescaled by 1/TAAU_S).
    float hd = texture2D(depthtex0, huv).r;
    vec3 hw = mat3(gbufferModelViewInverse) * toView(huv, hd)
            + gbufferModelViewInverse[3].xyz + cameraPosition;
    vec4 pc = gbufferPreviousProjection
            * (gbufferPreviousModelView * vec4(hw - previousCameraPosition, 1.0));
    if (pc.w > 0.0) {
        vec2 puv = (pc.xy / pc.w) * 0.5 + 0.5;
        if (puv.x > 0.001 && puv.x < 0.999 && puv.y > 0.001 && puv.y < 0.999)
            return roughTap(colortex7, puv, e0 / TAAU_S, e1 / TAAU_S,
                            vec2(0.001), vec2(0.999), radius);
    }
#endif
    return roughTap(colortex0, huv, e0, e1, vec2(0.001), vec2(0.999 * TAAU_S), radius);
}
// GGX half-vector importance sample (Walter et al. 2007) around n.
// alpha IS the labPBR roughness (see the block in the opaque branch): at
// alpha = 0 the formula collapses to cosT = 1, i.e. h = n and the sampled
// direction is reflect(v, n) -- a mirror stays a mirror.
vec3 ggxReflectDir(vec3 v, vec3 n, vec3 tX, vec3 tY, float alpha, float u1, float u2) {
    float phi = 6.2831853 * u1;
    float a2 = alpha * alpha;
    float cosT = sqrt((1.0 - u2) / (1.0 + (a2 - 1.0) * u2));
    float sinT = sqrt(max(1.0 - cosT * cosT, 0.0));
    vec3 h = tX * (sinT * cos(phi)) + tY * (sinT * sin(phi)) + n * cosT;
    vec3 r = reflect(v, h);
    // Below-horizon samples must not be snapped to the MIRROR direction: at
    // grazing angles up to ~45% of the taps fall under the tangent plane, and
    // collapsing them onto reflect(v, n) rebuilt a sharp specular spike inside
    // the lobe (bimodal: crisp mirror + biased halo) -- exactly the "everything
    // looks like a mirror" artefact this path exists to remove. Fold the sample
    // back ABOVE the tangent plane instead: 3 flops, no branch divergence, and
    // the lobe stays wide.
    if (dot(r, n) <= 0.0) r = r - 2.0 * dot(r, n) * n;
    return normalize(r);
}
#endif

#if RT_REFLECT_MODE >= 2
// Voxel hit VISIBLE ON SCREEN -> use the complete previous-frame screen color
// (via ssrHitColor) instead of flat voxel shading: real detail, no voxel
// aliasing, and one extra bounce level accumulated per frame. Depth tolerance
// ~0.6 block + 8% (a voxel is only an approximate cube); off screen or
// inconsistent depth -> fall back to plain voxel shading.
vec3 ptHitColor(vec4 vox, vec3 hitPosRel, vec3 faceN) {
    vec4 vp4 = gbufferModelView * vec4(hitPosRel, 1.0);
    vec4 clipH = gbufferProjection * vp4;
    if (clipH.w > 0.0) {
        vec2 suvH = ((clipH.xy / clipH.w) * 0.5 + 0.5) * TAAU_S; // TAAU: NDC -> sub-rect UV
        if (suvH.x > 0.002 && suvH.x < 0.998 * TAAU_S && suvH.y > 0.002 && suvH.y < 0.998 * TAAU_S) {
            float sdH = texture2D(depthtex0, suvH).r;
            if (sdH < 1.0) {
                float dScene = length(toView(suvH, sdH));
                float dHit = length(vp4.xyz);
                // Soft confidence (anti-flicker): a hard threshold would flip
                // between screen and voxel each frame at the tolerance edge,
                // driven by TAA depth jitter.
                float confH = 1.0 - smoothstep(0.35 + dHit * 0.05, 0.9 + dHit * 0.10, abs(dScene - dHit));
                if (confH > 0.001)
                    return mix(ptShadeVoxel(vox, hitPosRel, faceN), ssrHitColor(suvH), confH);
            }
        }
    }
    return ptShadeVoxel(vox, hitPosRel, faceN);
}
#endif

// TRUE sky reflection for water: when the reflected direction lands on a SKY
// PIXEL visible on screen, sample colortex0 (the deferred pass already painted
// atmosphere AND volumetric clouds there) -> the ocean reflects real cumulus
// and sun. Off screen / screen edge / not a sky pixel: fall back to getSkyAll.
// origin = view-space water point; rdView = reflected dir (view space,
// jittered); rworld = same in world space; skyl = pixel sky light (floor 0.08).
vec3 skyReflect(vec3 origin, vec3 rdView, vec3 rworld, vec3 sunW, float skyl) {
    vec3 sky = getSkyAll(rworld, sunW);
    #ifdef WATER_CLOUD_REFLECT
    if (rworld.y > 0.02) {
        vec4 fc = gbufferProjection * vec4(origin + rdView * 512.0, 1.0);
        if (fc.w > 0.0) {
            vec2 suv = (fc.xy / fc.w * 0.5 + 0.5) * TAAU_S; // TAAU: NDC -> sub-rect UV
            if (suv.x > 0.001 && suv.x < 0.999 * TAAU_S && suv.y > 0.001 && suv.y < 0.999 * TAAU_S
                && texture2D(depthtex0, suv).r > 0.9999) {
                // Edge fade: avoids a hard seam between screen sky and analytic
                // sky (TAAU: the right/top render edge is at TAAU_S, not 1.0)
                float edgeC = smoothstep(0.0, 0.06, min(min(suv.x, TAAU_S - suv.x), min(suv.y, TAAU_S - suv.y)));
                sky = mix(sky, texture2D(colortex0, suv).rgb, edgeC);
            }
        }
    }
    #endif
    // WATER_SKY_TINT sites 1 AND 2 -- this function has exactly two callers and
    // both are water (the open surface ~line 2553, and the surface a pane hides
    // under GLASS_SEE_THROUGH ~line 3431), so the tint lives HERE rather than at
    // the call sites: no future caller can be forgotten, which is the defect
    // class that has already cost this pack five passes. Applied BEFORE the
    // skylight scale on purpose -- the highlight spare then reads an ABSOLUTE
    // sky luminance and a shaded pixel cannot smuggle the solar disc under the
    // threshold. It also covers the FULL sky this function returns, the
    // colortex0 screen tap with its volumetric clouds included. Everything the
    // water branch derives from this value (the blurred 2nd ray, the dark-SSR
    // fades, the PT_REFLECT_WATER take-over, the WATER_HORIZON_SKY floor (a))
    // follows for free. Palier 0 = the argument, returned untouched.
    // UNDERWATER, THE PALIER IS EFFECTIVELY INERT -- corrected claim. This site
    // IS traversed with the eye submerged, but what it feeds is reflSky, the
    // REFLECTED sky, not the refracted one. The refracted sky the eye actually
    // sees through the Snell window is `color`, the colortex0 tap at ruv
    // (~line 2179), which nothing tints. Inside the window the code sets
    // fres = fres * 0.22 (~line 2512), so looking straight up fresSchlick ~ 0.02
    // and reflW = clamp(0.0044 * 0.95 * 1.5, 0, 0.98) ~ 0.006; outside it the
    // colour is the total-internal-reflection fallback uwFB (~line 2732), also
    // untinted. Under water this palier therefore moves LESS THAN 1% of the
    // pixel -- which also removes the seam an earlier note here worried about.
    return waterSkyTint(sky) * max(skyl, 0.08);
}
#endif

// EAU7 -- THE FLOOR CARRIER, ONE FUNCTION, FOUR CALL SITES.
// T is the per-channel transmittance the background travels through; d is the
// water path IN BLOCKS that produced it (the same number the exponent used, so
// a site scaling its path by 0.8 / WATER_CLARITY must pass the SCALED path).
// Part of T's chroma is handed back over the first blocks at EXACTLY constant
// Rec.709 luminance -- mix() toward luma() is luminance-preserving by
// construction, so luma(result) == luma(T) bit-for-bit and every brightness
// property of the column (depth ramp, 0.5 -> 20 block dynamic, floor
// readability) is untouched. Verified: luma ratio 1.000000000 at 0.5/1/2/3/5/
// 8/20 blocks; R/B of the carrier 0.288 -> 0.427 at 2 blocks, and 0.000 ->
// 0.000 at 20 (k = 0.55 * exp(-20/2.5) = 0.0002: open water is inert).
// WHY IT IS A FUNCTION AND NOT THREE COPIES: the three sibling sites below --
// the water a GLASS PANE hides (absorbG) and the two CULLED-water-face columns
// (absorbU) -- exist for the single stated purpose of matching the open-water
// column ("so a lake never changes colour behind a pane", "so culled water
// faces match the real surface"). Correcting waterColumn() alone would have
// re-opened exactly the inside/outside hue split EAU4 was written to close,
// and it would have been invisible to a grep for waterColumn(): these three
// sites build their own Beer-Lambert by hand and never call it.
vec3 vlxFloorCarrier(vec3 T, float dBlocks) {
    return mix(T, vec3(luma(T)), WFLOOR_CHROMA_KEEP * exp(-dBlocks / WFLOOR_KEEP_RANGE));
}

// REFERENCE WATER COLUMN - the calibrated two-term column: one Beer-Lambert
// absorption + one exponential veil, BOTH driven by the in-water VIEW PATH
// length, so the colour climbs with depth AND with viewing distance. Factored OUT of the WATER branch (its only call site until now) so
// GLASS_SEE_THROUGH can dress the water a pane hides with the EXACT same math
// -- one calibration, two call sites, no drifting copy.
//   bg       = color behind the column (already refraction-tapped)
//   wpath    = VIEW path length inside the water, in blocks
//   tintS    = RAW colortex5 biome tint sampled ON the water (not linearized)
//   skylC    = receiver sky light, wShadowC = shadow over the column [0..1]
//   torchL   = block-light channel (colortex2.r) of the receiver
vec3 waterColumn(vec3 bg, float wpath, vec3 tintS, float skylC, float wShadowC,
                 float torchL, vec3 worldDirC, vec3 lightWC) {
    // Swamp/mangrove detector: murky tints carry R+G above B;
    // blue tints (B dominant) give exactly 0.
    float turbid = smoothstep(0.05, 0.45, tintS.r + tintS.g - tintS.b * 1.05);
    // Keying both terms on the PATH instead of the vertical column is the
    // decision this block exists for: the sigmoid veil it replaced was keyed
    // on (surface Y - floor Y), so a grazing look across shallow water came
    // out perfectly clear - the one case where real water is at its murkiest.
    // ABSORPTION: see the WCOL block at the top of this file. WCOL_K_OUT is
    // the published pure-water + CDOM spectrum sampled at the sRGB primaries
    // and scaled by ONE artistic "metres per block" factor, NOT a hand-picked
    // triple. V2 per-block transmittance R 0.671 / G 0.909 / B 0.958: the
    // first block reads near-clear with a whisper of teal (red dies first),
    // blue survives longest so the distant residue is BLUE, never turquoise.
    // (The old comment here quoted 0.67 / 0.84 / 0.91 and called the numbers
    // "calibrated"; they were neither measured nor derived. WATER_COLOR_V2 0
    // still restores them exactly.)
    float wKmul = WATER_DEPTH_DENSITY / WATER_CLARITY; // 1.0 at defaults
    float dPath = wpath * wKmul;
    // WATER_TURBIDITY (V2) scales the swamp/mangrove murk BEFORE both of its
    // consumers, so one dial moves the extra absorption and the hue pull
    // together. Legacy weight is 1.0.
    turbid = clamp(turbid * WCOL_TURB_W, 0.0, 1.0);
    // EAU9: vlxWaterK() is WCOL_K_OUT at WATER_COLOR_V4 0 and, at 1, the same
    // spectrum with the CDOM + chlorophyll of THIS biome added. It is the sole
    // reason the R/B ratio of the filter below stops being 9.28 (Sargasso Sea)
    // on a lake. `turbid` is untouched and still stacks on top: it keys on the
    // per-pixel VANILLA tint, which is a different signal from the climate.
    vec3 aWat = vlxWaterK() + turbid * WCOL_TURB_K;
    // CONFIG per-channel absorption dials (1.0 = calibrated column)
    aWat *= vec3(WATER_ABSORB_R, WATER_ABSORB_G, WATER_ABSORB_B);
    vec3 absorb = exp(-dPath * aWat);
    // Path veil V = 2^(-rate d), rate = WCOL_VEIL_RATE (see the WCOL block:
    // derived from WCOL_K_OUT, not picked). Floor visibility 0.82 at 1 block,
    // 0.45 at 4, 0.27 at 6.5, 0.13 at 10 -- the floor dissolves around
    // 6-7 blocks of view path without ever hitting a wall.
    // CONFIG: WATER_VEIL_START holds the veil off the first blocks
    // of path (absorption untouched), WATER_VEIL_DENSITY scales the
    // rate. Defaults 0.0 / 1.0 = the shipped veil.
    float dVeil = max(dPath - WATER_VEIL_START, 0.0);
    // WCOL_V3: the veil stops being a separate GRAY fade and becomes the
    // SCATTERING coefficient b of the same medium, so absorb * visW is exactly
    // exp(-(a + b) d) -- one extinction, three channels, and the in-scatter
    // share is its exact complement. WATER_VEIL_DENSITY keeps its meaning (how
    // fast the bottom dissolves) but now moves a per-channel b: raising it
    // shortens the blue sight line proportionally MORE than the red one, which
    // is the physically right direction and the one the shipped look expects.
    // See the WCOL_V3 block at the top of this file for the derivation of b and
    // for the floor-survival table this replaces.
    vec3 visW;
#if WCOL_V3 == 1
    // EAU9: same substitution as aWat above -- vlxWaterB() is WCOL_B_SCAT at
    // WATER_COLOR_V4 0. Its SHAPE follows Morel 1988 per biome; its Rec.709
    // MAGNITUDE is deliberately bounded (x1.15 mid, x1.60 swamp) because raising
    // it is a CLARITY change and the report was about COLOUR -- stated, with the
    // measured cost, in the WATER_COLOR_V4 block of lib/settings.glsl.
    visW = exp(-dVeil * (vlxWaterB() * WATER_VEIL_DENSITY));
#else
    visW = vec3(exp2(-dVeil * (WCOL_VEIL_RATE * WATER_VEIL_DENSITY)));
#endif
    // In-scatter: FIXED desaturated SLATE-BLUE chroma scaled by
    // the GRAY luminance of the ambient/sun light. Never multiply
    // by a light COLOR here: a blue-sky or green-tint product is
    // exactly what used to drift the deep water to turquoise or
    // plastic azure. Murky biomes shift toward their own tint;
    // rain grays the volume slightly.
    // WATER_FOG_BLUE slides this chroma between neutral gray and the
    // saturated endpoint of the active model. V2 moves that endpoint from
    // desaturated slate (R/B 0.40) to sea cyan (R/B 0.05) AT EQUAL Rec.709
    // LUMINANCE, so the "uniform powder-blue milk" failure mode -- which was
    // a BRIGHTNESS problem, not a saturation one -- cannot return through it.
    // At the shipped WATER_FOG_BLUE 0.85 the V2 mix reads (0.086, 0.406,
    // 0.693), R/B 0.12: a deep sea blue that still carries a green shoulder.
    // WCOL_SCAT_DEEP == WCOL_SCAT_BLUE at WCOL_V3 0 (bit-identical); at 1 it is
    // the derived water-leaving reflectance b_b/(a + b_b) integrated against
    // CIE 1931 x D65 and projected into the sRGB gamut (EAU4 block at the top
    // of this file), rescaled to the SAME Rec.709 luminance as the V2 endpoint,
    // so this slider still slides gray <-> saturated at constant brightness.
    // Under EAU4 the same mix reads (0.115, 0.398, 0.688), R/B 0.167,
    // G/B 0.578, hue 210.4 deg -- V2's green shoulder, at V3's luminance.
    // EAU9: vlxWaterDeep() is WCOL_SCAT_DEEP at WATER_COLOR_V4 0 and, at 1, the
    // same b_b/(a + b_b) integral re-run on THIS biome's water and projected the
    // same way. All three anchors carry the identical Rec.709 luminance
    // 0.358481, so the WATER_FOG_BLUE slider still slides gray <-> saturated at
    // constant brightness at EVERY biome weight, not just at the two ends.
    vec3 slateC = mix(WCOL_SCAT_GRAY, vlxWaterDeep(), WATER_FOG_BLUE);
    // GUARD: WATER_FOG_BLUE goes to 1.25, which EXTRAPOLATES past the
    // saturated endpoint. The V2 endpoint has R 0.038, so 1.25 lands the red
    // channel below zero and a negative colour would survive all the way to
    // the tonemap. Clamping at 0 is a no-op at every legacy slider notch BUT
    // ONE: 1.25 is itself a shipped notch ([0.25 0.5 0.75 0.85 1.0 1.25],
    // settings.glsl), and under WCOL_V3 0 the endpoint is WCOL_SCAT_BLUE
    // R 0.038, so mix(0.36, 0.038, 1.25).r = -0.042500 and the clamp DOES
    // pull there. That is the correction working as intended - a negative red
    // used to reach the tonemap at that notch - and it is the single exception
    // to "V3 off is byte-for-byte V2"; everything else on that path is.
    // EAU4 endpoint R 0.0720: this guard is what SETS that number (it is the
    // exact minimum 0.36 * 0.25 / 1.25 the gamut projection was solved for), so
    // at 1.25 the red lands at exactly +0.000000 -- the clamp stays a no-op
    // there too and no channel can go negative.
    slateC = max(slateC, vec3(0.0));
    vec3 tintLin = toLinear(tintS);
    vec3 scatC = mix(slateC, slateC * tintLin * (0.85 / max(luma(tintLin), 0.05)), turbid * 0.75);
    scatC = mix(scatC, vec3(luma(scatC)), rainStrength * 0.5);
    float scatDrive = (luma(gAmbC) * 0.75 * skylC
                    + luma(gLightC) * 0.05 * skylC * wShadowC) * WATER_FOG_BRIGHT;
    // CL GAP (documented, v1 parity - OUT of the colored-lights perimeter): this volume
    // term uses getTorchColor() PURE. The LPV tint (CL_V2) is bridged to SURFACES only;
    // water-fog scatter, the water-surface localLight and the cave fog stay vanilla-warm
    // (Complementary has a dedicated coloredLightFog for this). Bridging would be legal
    // here (430, runs after the composite .csh, sampleLPVForward available) - not done.
    vec3 scatter = scatC * WATER_SCATTER_DARKEN * scatDrive
                 + getTorchColor() * (torchL * torchL) * WCOL_TORCH;
    // Refracted-sun forward-scatter: the volume glows toward a low
    // sun (sunset path on the swell), stays quiet at noon and when
    // looking away. Grazing-gated (worldDir.y) so a top-down view
    // keeps the column above intact -- a grazing gate is the deliberate
    // choice here, because the case that must not go gray is DISTANT water
    // at sunset, which is always seen grazing.
    // WHERE (5.2, 5.0, -1.4) COMES FROM: it is Henyey-Greenstein with the
    // asymmetry parameter g = 0.8 that Petzold's measured ocean volume
    // scattering functions give for sea water. HG is
    // (1 + g^2 - 2 g cos)^-1.5 = (1.64 + 1.6 * dot)^-1.5 in this sign
    // convention; the pair above is that denominator prescaled by 3.17 (so
    // the lobe peaks near 1 instead of exploding) with the exponent softened
    // 1.5 -> 1.4, which widens the halo enough to survive TAA.
    vec3 sunRefr = refract(-lightWC, vec3(0.0, 1.0, 0.0), 0.75);
    float phS = pow(max(5.2 + dot(sunRefr, worldDirC) * 5.0, 0.35), -1.4);
    float glowW = clamp(3.0 * pow(1.0 - clamp(-worldDirC.y, 0.0, 1.0), 2.0) * phS, 0.0, 1.0)
                * skylC * wShadowC * (1.0 - rainStrength);
    // CONFIG: sunset refracted-glow weight (1.0 = calibrated)
    glowW = clamp(glowW * WATER_SCATTER_SUNSET, 0.0, 1.0);
    scatter = mix(scatter, scatC * gLightC * 0.55 * skylC * wShadowC, glowW);
    // Reference combination: absorbed floor behind a veiled column
    // (both attenuations apply to the floor; the veil share is the
    // slate in-scatter).
    // EAU7 -- THE CARRIER, and why it is the lever the four chroma re-derivations
    // could never be. absorb * visW is the FILTER the floor's albedo travels
    // through, and the weighted share table (lib/settings.glsl, EAU7 block) says
    // that floor is 97.2% of the delivered pixel at 0.5 block of path and still
    // 91.7% at 3. Normalised to blue this filter reads (0.529,0.917,1.000) at
    // 1 block and (0.288,0.846,1.000) at 2, so SAND (dry hue 49 deg) is
    // delivered at 152 deg then 174 deg: cyan, with no ochre left. The in-scatter
    // -- the only term WATER_TINT moves -- is 1.1% and 2.7% of that same pixel.
    // Tk hands part of the filter's CHROMA back over the first blocks of path at
    // EXACTLY the same Rec.709 luminance: mix() toward luma() is luminance-
    // preserving by construction, so the depth ramp, the 0.5 -> 20 block dynamic
    // and the floor's readability stay carried by luma(Tfl) bit-for-bit. Open
    // water is inert by construction (exp(-8/2.5) = 0.04, and it is 75-98% mirror
    // there anyway). WFLOOR_CHROMA_KEEP 0.0 restores the previous line exactly.
    vec3 Tfl = absorb * visW;
#if WCOL_V3 == 1
    // TEXTBOOK SINGLE-SCATTERING SOLVE, and the reason it cannot stay a mix().
    // For a homogeneous slab L(d) = L_bg e^-cd + (J/c)(1 - e^-cd): the floor
    // keeps exp(-(a + b) d) and the in-scatter takes EXACTLY its complement, the
    // SAME exponential. mix(scatter, bg, visW) cannot express that -- its weight
    // would have to be the veil AND the absorption at once -- and letting visW
    // alone carry the in-scatter share would leave the deep RED at 0.901 of its
    // asymptote while the blue sat at 0.952: a per-channel energy leak of up to
    // 10%, landing exactly where the deep chroma is decided. absorb * visW IS the
    // single extinction exp(-(a + b) d); Tfl = absorb * visW is the transmitted
    // floor's carrier and 1 - Tfl is the veil's own share. (bg no longer carries
    // absorb on this branch -- Tfl does, once, for both terms.)
    // All the hue travel then comes from the per-channel extinction ratio alone
    // (2.64 : 1.15 : 1) -- turquoise shallows and navy offshore with no
    // hand-placed colour anywhere in between -- which is exactly what EAU7 above
    // has to hold back over the first blocks without touching the luminance.
    return bg * vlxFloorCarrier(Tfl, dPath) + scatter * (1.0 - Tfl);
#else
    bg = bg * absorb;
    return mix(scatter, bg, visW);
#endif
}

#if WATER_FOG_HUE == 1
// WATER_FOG_HUE (B) -- GREEN-NOTCH GUARD on the finished water pixel.
// "Mauve" is not a hue range, it is a SHAPE: red and blue both present with
// green in the valley between them. This lifts green back to min(R, B) and
// does nothing else. Measurement, cause and the before/after table: the
// WATER_FOG_HUE block of lib/settings.glsl.
// IT IS SELF-GATING, which is why it carries no time-of-day test: when the
// pixel is not notched, min(R,B) <= G and the max() below returns G unchanged
// -- rigorously the identity, not "nearly". Measured on 1485 samples: not one
// pixel touched above 17 deg of sun elevation.
// LUMINANCE IS EXACT, not approximate: green is the only channel that moves,
// so the Rec.709 luminance moves with it by a known amount and the divide puts
// it back. Measured dLuma over the whole grid: 0.00 %. That is the property
// that lets this sit AFTER every water term without re-opening the exposure
// work the EAU4/EAU5/EAU7 passes closed.
// WHAT IT CANNOT DO: the two veils that follow the water branch (VL apply,
// ATMO_FOG) add their own chroma after this point, and at ~110 deg from a
// setting sun the sky they carry is ALREADY magenta at the source
// (lib/sky.glsl's dusk band is an RGB lerp from blue to a saturated red, and
// every intermediate weight is magenta). This guard cannot reach either, and
// settings.glsl names both with their measured share.
vec3 vlxWaterHueGuard(vec3 c) {
    vec3 o = c;
    o.g = max(c.g, mix(c.g, min(c.r, c.b), WFH_NOTCH));
    float Y = luma(c);
    return o * (Y / max(luma(o), 1e-6));
}
#endif

// gLightC/gAmbC are declared above (outside every #if, before ptShadeVoxel
// reads them) and initialized at the top of main(); all call sites read them
// instead of recomputing sunHeight + smoothsteps.

void main() {
    gLightC = getLightColor();
    gAmbC = getAmbientColor();
    float d0 = texture2D(depthtex0, uv).r;
    vec3 viewPos = toView(uv, d0);
    vec3 viewDir = normalize(viewPos);
    vec3 worldDir = mat3(gbufferModelViewInverse) * viewDir;
    vec3 sunW = normalize(mat3(gbufferModelViewInverse) * sunPosition);
    vec3 lightW = normalize(mat3(gbufferModelViewInverse) * shadowLightPosition);

    vec3 color = texture2D(colortex0, uv).rgb;
    // WATER DEBUG (views 23/24): composite1 re-emits colortex5 as an exact
    // passthrough (Iris ping-pongs the buffer, so downstream readers -- final.fsh
    // views 7/21/22 -- see the same content) and substitutes the reflection data
    // (refl / hit / reflW / fresP) that final.fsh displays. The tap and the
    // variable only exist in water debug builds.
    #if DEBUG_VIEW >= 23
    vec4 aux5 = texture2D(colortex5, uv);
#if DEBUG_VIEW == 28 || DEBUG_VIEW == 31
    // View 28 (glass see-through probe) is a PURE false-colour view: no albedo
    // context, so BLACK means one unambiguous thing -- the GLASS branch never
    // ran on this pixel. Every channel is painted in that branch only.
    // View 31 (PHYS_REAL probe) has the same contract: BLACK = the mod ocean
    // heartbeat is stale, nothing else.
    aux5 = vec4(0.0, 0.0, 0.0, 1.0);
#else
    aux5.rgb *= 0.15; // outside water: dimmed albedo for readable context
#endif
#if DEBUG_VIEW == 27
    // ---- View 27: THE DIRECTION THE UNDERWATER BEAMS USE ----
    // RGB = dir * 0.5 + 0.5. WATER pixels (colortex2.b tag) and a submerged
    // eye get the direction every underwater term is fed; everything else gets
    // the raw air lightW, so one screenshot shows both side by side.
    // READING IT: with UW_SUN_COHERENT on, the water is visibly GREENER than
    // the land (a larger +y) and stops changing once the air incidence passes
    // 48.59 deg -- the Snell cone made visible. With it off, water and land are
    // the SAME colour, which is the bug: the beams were being aimed with the
    // air direction. A water body showing TWO different greens would mean a
    // term escaped the unification.
    // Per-pixel constant on purpose: the beams share ONE direction, so any
    // gradient inside one medium is itself the defect being looked for.
    {
        bool dbgUW27 = (isEyeInWater == 1) || (texture2D(colortex2, uv).b > 0.95);
#if UW_SHAFT_FIX3 == 1
        // ---- View 27 under UW_SHAFT_FIX3: THE THREE CAUSES, ONE SHOT ----
        // The direction readout this view used to paint answered a question
        // that is now settled by construction (the beams ride the shadow map's
        // own axis), so the channels carry the three reported symptoms instead,
        // each one able to say on its own whether it is still alive.
        // LEGEND -- BLACK WATER = all three healthy. Dry land stays black too.
        //   RED   (A) angle between the axis the BEAMS are drawn on
        //         (uwShaftAxis) and the axis the SHADOW MAP projects on
        //         (normalize(lightW)), full red at 30 deg. It is exactly 0
        //         above 8.63 deg of elevation and climbs to 5.66 deg (0.19,
        //         a dark red) at the beam's own cut-off, lightW.y = 0.05.
        //         ANY brighter red = a term escaped and the beams are being
        //         aimed somewhere the cast shadow does not point.
        //   GREEN (B) this pixel is OCCLUDED in the shadow map -- the probe the
        //         march now runs, at the pixel's own opaque surface. Stand so
        //         your shadow falls on the sea floor: the green patch IS your
        //         shadow. If beams stay bright while crossing that patch, the
        //         march is not consulting the map and (B) is still alive.
        //   BLUE  (C) the shadow probe has NO DATA here (outside the map, or
        //         past its frustum Z). This is where `vis` fails OPEN and a
        //         beam would be inventing sunlight. Any blue that coincides
        //         with a visible shaft is the leak, and the shaft should be
        //         fading out across it, not brightening.
        // Purple = a leak zone that is also shadowed; that combination is the
        // signature of (C) hiding behind (B).
        vec3 dbg27 = vec3(0.0);
        if (dbgUW27) {
            vec3 axB = uwShaftAxis(lightW);
            vec3 axS = normalize(lightW);
            dbg27.r = clamp(acos(clamp(dot(axB, axS), -1.0, 1.0)) / 0.5236, 0.0, 1.0); // 0.5236 rad = 30 deg full scale
            // Same probe the march runs: opaque surface of this pixel, no
            // normal offset, same bias, same border/Z validity as shOK.
            // GUARDED ON d1 < 1.0. depthtex1 holds OPAQUES ONLY -- the water
            // surface is translucent and never writes it -- so a submerged eye
            // looking UP at the sky through the surface reads d1 == 1.0 and the
            // probe would be planted on the far plane (>= shadowDistance), out
            // of the map: okD 0, dbg27.b 1.0 on EVERY sky pixel of the frame.
            // The legend calls solid blue "the leak", so the diver would have
            // read a full-screen false positive in the one view meant to
            // confirm the fix. With the guard, sky pixels stay 0 on b and g,
            // consistent with "BLACK WATER = all three healthy". (g shared the
            // same probe: visD is 1.0 at the far plane, so g was already 0 --
            // benign, and the guard covers it too.)
            float d1v27 = texture2D(depthtex1, uv).r;
            if (d1v27 < 1.0) {
                vec3 scD = toShadowClip(toView(uv, d1v27), vec3(0.0));
                float fD = getDistortFactor(scD.xy);
                vec3 spD = distortShadow(scD, fD) * 0.5 + 0.5;
                float visD = 1.0;
                float okD = 0.0;
                if (spD.x > 0.0 && spD.x < 1.0 && spD.y > 0.0 && spD.y < 1.0) {
                    float zbD = spD.z - 0.0008 * (VLX_SHADOW_ZSCALE * 2.0);
                    visD = step(zbD, texture2D(shadowtex1, spD.xy).r);
                    okD = (1.0 - step(1.0, zbD))
                        * smoothstep(0.0, 0.02, min(min(spD.x, 1.0 - spD.x),
                                                    min(spD.y, 1.0 - spD.y)));
                }
                dbg27.g = 1.0 - visD;
                dbg27.b = 1.0 - okD;
            }
        }
        aux5 = vec4(dbg27, 1.0);
#else
        vec3 dbgDir27 = lightW;
#if UW_SUN_COHERENT == 1
        if (dbgUW27) dbgDir27 = uwSunRefract(lightW);
#endif
        aux5 = vec4(dbgDir27 * 0.5 + 0.5, 1.0);
#endif
    }
#endif
    #endif
    float dither = bayer8(gl_FragCoord.xy); // static: no flicker without TAA
#if BLUE_NOISE == 1
    // Volumetric-march jitter ONLY (clouds pass + unified fog/god-ray march):
    // blue noise, new slice per frame, TAA-averaged. SSR / PCF / contact
    // shadows keep the static Bayer above (separate tuning).
    float vlDither = blueDither(gl_FragCoord.xy, frameCounter);
#else
    float vlDither = dither;
#endif

#if VLX_PHYS_SYNC == 1
    // ===== PHYSICS_FIELD_SYNC : lecture du canal lateral (1 fois par pixel) ===
    // Deux texelFetch sur physOceanParams (2 texels absolus) + un sur
    // l'estampille plein ecran, et rien d'autre : tout le reste du bloc est de
    // l'arithmetique sur des scalaires uniformes.
    vec4 vlxPP0 = texelFetch(physOceanParamsSampler, ivec2(0, 0), 0);
    vec4 vlxPP1 = texelFetch(physOceanParamsSampler, ivec2(1, 0), 0);
    // BATTEMENT. Le .w porte le frameCounter de la frame qui a ecrit ; la
    // comparaison est EXACTE en float32 (frameCounter est borne a 720719 par
    // Iris, donc bien sous 2^24). Le 0 est refuse : c'est le contenu d'une image
    // jamais ecrite, et le refuser ne coute qu'une frame de chemin legacy a la
    // frame 0 d'un monde. Au bouclage du compteur (toutes les 720720 frames),
    // une frame de legacy aussi : invisible.
    // TOLERANCE D'UNE FRAME, deliberee. Le cas nominal est l'age 0 (l'ecriture
    // image du pass gbuffer / ombre precede la lecture de composite1 dans la
    // meme frame). Accepter aussi l'age 1 couvre le seul mode de defaillance
    // credible - une barriere memoire inter-passes qui ne serait pas emise entre
    // deux passes FRAGMENT - et ne coute rien : le champ republie serait alors
    // vieux d'une frame (~16 ms), soit exactement le decalage d'une image de
    // rendu. Sans cette tolerance, ce mode eteindrait l'effet EN SILENCE.
    float vlxHB = float(frameCounter) - vlxPP0.w;
    bool vlxPhysLive = (vlxPP0.w > 0.5) && (vlxHB > -0.5) && (vlxHB < 1.5);
    if (vlxPhysLive) {
        vlxPhysT     = vlxPP0.x;                 // physics_gameTime : l'horloge DU MOD
        vlxPhysScale = max(vlxPP0.z, 1e-3);      // physics_oceanWaveHorizontalScale
        vlxPhysDrift = vlxPP1.xy;                // monde -> maillage du mod
#if PHYS_SWELL == 1 || VLX_PHYS_REAL == 1
        vlxPhysAmp   = max(vlxPP0.y, 0.0);      // physics_oceanHeight : amplitude PHYSIQUE (PHYS_SWELL)
#endif
#if VLX_PHYS_REAL == 1
        // ---- PHYS_REAL : octaves de la NORMALE du mod et CARTE DE RIDES ----
        // physics_iterationsNormal (publie au texel 1) est le nombre d'octaves
        // que la normale AFFICHEE utilise ; on le borne (voir PHYS_REAL_MINOCT
        // / PHYS_REAL_MAXOCT dans lib/settings.glsl). Une valeur nulle ou
        // aberrante degenere sur le plancher, jamais sur 0.
        vlxPhysIterF = clamp(vlxPP1.w, float(PHYS_REAL_MINOCT),
                             float(PHYS_REAL_MAXOCT));
        // BATTEMENT PROPRE A LA CARTE DE RIDES, independant de celui du champ :
        // la copie est etalee sur quelques frames quand l'ocean couvre peu de
        // pixels (mesure pr_m4.py D), d'ou une tolerance de 2 frames au lieu
        // d'une. Si la carte n'est pas fraiche, la portee reste a 0 et
        // vlxPhysSlopeReal ne prend AUCUN tap de texture : on retombe sur la
        // houle seule, jamais sur une carte perimee.
        vec4 vlxRP0 = texelFetch(physRipParamsSampler, ivec2(0, 0), 0);
        vec4 vlxRP1 = texelFetch(physRipParamsSampler, ivec2(1, 0), 0);
        float vlxRHB = float(frameCounter) - vlxRP0.w;
        if (vlxRP0.w > 0.5 && vlxRHB > -0.5 && vlxRHB < 2.5 && vlxRP0.y > 0.0) {
            vlxPhysRipC = vlxRP1.xy;
            vlxPhysRipR = vlxRP0.y;
            // normalSampleDistance du mod, mais JAMAIS sous un texel de la
            // COPIE : en dessous, la carte recopiee n'a plus d'information et
            // les differences centrales rendraient une pente nulle - les rides
            // disparaitraient EN SILENCE. Ecart assume et documente.
            vlxPhysRipH = max(vlxRP0.z,
                              (2.0 * vlxRP0.y) * (1.0 / float(PHYS_REAL_RIPN)));
        }
#endif
    }
    // ESTAMPILLE DU PIXEL : ce pixel EST-il une surface d'ocean du mod ?
    // L'estampille porte le frameCounter complet (shaders.properties), donc le
    // test est une egalite d'entiers, pas un compteur modulo : aucun faux
    // positif venant d'un vieux contenu ne peut passer.
    // Le fetch est saute quand le battement est perime (branche uniforme).
    uint vlxPS = 0u;
    if (vlxPhysLive) vlxPS = texelFetch(physOceanPixSampler, ivec2(gl_FragCoord.xy), 0).r;
    uint vlxFC = uint(frameCounter);
    uint vlxST = vlxPS >> 8;
    // Meme tolerance d'une frame que le battement, et pour la meme raison.
    // Faux positif possible : un pixel qui etait l'ocean du mod a la frame
    // precedente et ne l'est plus. Il faudrait qu'une eau VANILLA remplace
    // l'ocean du mod au meme pixel en une frame - geometriquement impossible
    // ailleurs que sur une silhouette, et le TAA l'absorbe.
    bool vlxPhysPix = vlxPhysLive && (vlxST == vlxFC || (vlxFC > 0u && vlxST == vlxFC - 1u));
    float vlxPhysPixWav = float(vlxPS & 255u) * (1.0 / 255.0);
    // HEURISTIQUE AMBIANTE, pour les sites qui n'ont PAS d'estampille (le pixel
    // n'est pas la surface : sol vu dans une ombre d'eau, fond vu par un oeil
    // immerge, pas de la marche VL). On ne peut alors que raisonner sur le
    // contexte : le battement prouve que l'ocean du mod EST rendu quelque part
    // pres du joueur, et la categorie de biome de la camera dit si l'eau du coin
    // peut etre cet ocean. CAT_NONE ne vote pas contre : sur les versions ou
    // Iris ne remplit pas biome_category, la regle degenere proprement vers "le
    // battement seul", au lieu de tout eteindre en silence.
    // ECART ASSUME : un lac perche EN BIOME OCEAN passerait le test de
    // categorie ; il est exclu par l'altitude aux sites qui la testent.
#if VLX_PHYS_BIOME == 1
    bool vlxPhysCat = (biome_category == CAT_OCEAN) || (biome_category == CAT_BEACH)
                   || (biome_category == CAT_RIVER) || (biome_category == CAT_NONE);
#else
    // VLX_PHYS_BIOME 0 (defaut, lib/settings.glsl) : pas de test de biome, le
    // battement et les tests d'altitude decident (le mapping biome_category
    // d'Iris sur cette version n'est pas verifiable, et un faux negatif
    // eteint le site immerge en silence).
    bool vlxPhysCat = true;
#endif
    bool vlxPhysAmb = vlxPhysLive && vlxPhysCat;
    // Waviness de repli : celle du DERNIER fragment d'ocean publie (course
    // benigne assumee, voir PF_NOTES). Le pass gbuffer ecrit apres le pass
    // ombre, donc quand la surface est a l'ecran c'est une waviness visible.
    float vlxPhysAmbWav = clamp(vlxPP1.z, 0.0, 1.0);
    // OEIL IMMERGE DANS L'OCEAN DU MOD : ambiance + oeil dans l'eau + oeil sous
    // le niveau de la mer (l'ocean du mod est A la mer ; cela exclut les lacs
    // perches et les poches d'eau en grotte au-dessus du niveau).
    bool vlxPhysEye = vlxPhysAmb && (isEyeInWater == 1)
                   && (cameraPosition.y < WATER_LEVEL + 0.5);
#if DEBUG_VIEW == 30
    // ---- Vue 30 : SONDE PHYSICS_FIELD_SYNC (legende dans lib/settings.glsl) --
    // NOIR battement perime / ROUGE vivant mais ce pixel n'est pas l'ocean du
    // mod / VERT ce pixel EST l'ocean du mod, luminosite = waviness locale /
    // BLEU hauteur du champ REIMPLEMENTE lue au xz monde du pixel - c'est le
    // test du drift : les franges bleues doivent glisser SANS marche aux
    // frontieres de chunk.
    {
        vec3 dbg30 = vec3(0.0);
        if (vlxPhysLive) {
            dbg30.r = vlxPhysPix ? 0.0 : 0.55;
            dbg30.g = vlxPhysPix ? (0.25 + 0.75 * vlxPhysPixWav) : 0.0;
            // Hauteur du champ au point monde visible (depthtex0 : sur un pixel
            // d'ocean c'est la surface elle-meme). Le ciel est exclu : son
            // viewPos est au plan lointain et n'a pas de xz monde utile.
            if (d0 < 1.0) {
                vec3 w30 = mat3(gbufferModelViewInverse) * viewPos + cameraPosition;
                VLX_PHYS_SET(true, vlxPhysPix ? vlxPhysPixWav : vlxPhysAmbWav, 0.0);
                float h30 = vlxPhysHeightU(w30.xz);
                VLX_PHYS_SET(false, 0.0, 0.0);
                dbg30.b = clamp(0.5 + h30 * 4.0, 0.0, 1.0);
            }
        }
        aux5 = vec4(dbg30, 1.0);
    }
#endif
#if DEBUG_VIEW == 31 && VLX_PHYS_REAL == 1
    // ---- Vue 31 : SONDE PHYS_REAL (legende dans lib/settings.glsl) ---------
    // ROUGE = la CARTE DE RIDES recopiee, lue au xz monde du pixel (valeur
    // BRUTE, saturee a 12 : c'est l'echelle ou le mod lui-meme declenche son
    // ecume de ride, smoothstep(0.10, 0.38, |raw| * 0.01)).
    // VERT  = norme de la pente de la normale que le mod AFFICHE.
    // BLEU  = la densite caustique livree, a une profondeur de sonde FIXE de
    //         5 blocs pour que la vue soit comparable d'un pixel a l'autre.
    {
        vec3 dbg31 = vec3(0.0);
        if (vlxPhysLive && d0 < 1.0) {
            vec3 w31 = mat3(gbufferModelViewInverse) * viewPos + cameraPosition;
            VLX_PHYS_SET(true, vlxPhysPix ? vlxPhysPixWav : vlxPhysAmbWav, 0.0);
            vec4 J31;
            float n31;
            vec2 s31 = vlxPhysSlopeReal(w31.xz, J31, n31);
            float r31 = vlxPhysRipRaw(w31.xz);
            float c31 = vlxPhysCaustic(w31.xz, 5.0, lightW);
            VLX_PHYS_SET(false, 0.0, 0.0);
            dbg31.r = clamp(abs(r31) * (1.0 / 12.0), 0.0, 1.0);
            dbg31.g = clamp(length(s31) * 2.0, 0.0, 1.0);
            dbg31.b = clamp(c31 * 0.4, 0.0, 1.0);
        }
        aux5 = vec4(dbg31, 1.0);
    }
#endif
#endif

    bool isSky = d0 >= 1.0;
    float dist = isSky ? far : length(viewPos);

#ifdef DISTANT_HORIZONS
    // Pixel covered by a DH LOD: d0 >= 1.0 (nothing in depthtex0) BUT dhD0 < 1.0.
    // Its position is rebuilt through the DH frustum (used by fog/clouds below).
    // isSky STAYS true, so the water/glass/opaque branches are skipped (gbuffer
    // data is absent for LODs); the dedicated DH fog runs after them.
    float dhD0 = texture2D(dhDepthTex0, uv).r;
    bool isDHpix = isSky && dhD0 < 1.0;
    if (isDHpix) {
        viewPos  = toViewDH(uv, dhD0);
        viewDir  = normalize(viewPos);
        worldDir = mat3(gbufferModelViewInverse) * viewDir;
        dist     = length(viewPos);
    }
#endif

    // DH_FOG_SCALE (lib/settings.glsl) : facteur d'echelle UNIQUE des
    // brouillards de distance analytiques — ATMO_FOG (vanilla + miroir DH),
    // AERIAL_PERSPECTIVE (les deux sites), traine HEIGHT_FOG, traine
    // DAWN_MIST. Leurs densites par bloc sont calibrees pour un monde qui
    // S'ARRETE a far ; avec DH le terrain porte a dhRenderDistance et les
    // memes constantes absolues effacaient les LODs (~90 % de voile a 512).
    // far/dhRange est la transformation que le fogF de DISTANCE_FOG applique
    // DEJA a sa distance caracteristique (far*0.85 -> dhRange*0.85) : chaque
    // brouillard redevient la meme fonction de la profondeur RELATIVE
    // (dist/portee) qu'en vanilla. UN SEUL facteur, applique aux DEUX cotes
    // de la couture vanilla/DH (jamais deux regimes) -> le brouillard reste
    // une fonction CONTINUE de dist a la frontiere. La marche VL (0-160
    // blocs), CAVE_FOG et les brouillards d'eau/sous-marins ne sont PAS
    // rescales : milieux du champ proche, pas voiles de distance. Sans DH
    // (ou gate a 0) : 1.0, tous les sites bit-identiques.
#if defined DISTANT_HORIZONS && DH_FOG_SCALE == 1
    float dhFogK = far / max(float(dhRenderDistance), far);
#else
    float dhFogK = 1.0;
#endif

    // CSE (memoized): getSkyBase(worldDir, sunW) is requested with IDENTICAL
    // inputs by up to 4 sites per pixel (water horizon floor, aerial fog / DH
    // fog, cloud fog, height-fog tail). worldDir is FINAL past the DH rebuild
    // above and sunW is constant, so one evaluation serves them all. Lazy
    // flag: a pixel where no site fires (e.g. plain sky without the height-fog
    // tail) evaluates nothing, exactly like before.
    vec3 skyBaseWD = vec3(0.0);
    bool skyBaseWDok = false;

    // "Submerged glass" detection (screen probes) is DISABLED: it treated any
    // camera below y=WATER_LEVEL as underwater as soon as one water/glass pixel
    // was on screen -> false blue fog in caves, ravines and low builds. Forced
    // to false; every block that consumes it degrades to its isEyeInWater==1
    // branch. Kept as a variable so those blocks stay compiled.
    bool inGlassUW = false;

    // MIRROR dominance of a water pixel (final reflW * flatW, eye OUT of water
    // only), exported from the water branch to the volumetric light at the end
    // of main(). A ~97% reflective pixel is an AIR ray (sky mirrored by the
    // surface): the water column the VL marches BEHIND the surface is not
    // actually crossed by its light. Must stay in sync with the VL density term.
    float wMirror = 0.0;

    // GLASS_SEE_THROUGH: ray length the DISTANCE fogs below price. Equal to
    // dist everywhere EXCEPT on a translucent pane, where the VISIBLE surface
    // (depthtex0) is the pane itself 1-3 blocks away while the air the fog must
    // dress runs all the way to the OPAQUE surface behind it. That single
    // substitution is why a landscape seen through a window arrived with no
    // haze at all: every Beer-Lambert below was evaluated at ~2 blocks. The
    // GLASS branch moves it to depthtex1 -- or to the water surface the ray
    // crosses first, so a lake seen through a pane is fogged exactly like the
    // open-water pixels next to it. GLASS_SEE_THROUGH = 0 leaves it equal to
    // dist, so every fog below is bit-identical. The SUBMERGED-eye fog keeps
    // reading 'dist' on purpose: the water between the eye and the pane really
    // does end AT the pane.
    float fogDist = dist;

    // CAVE_FOG companion gate of fogDist. CAVE_FOG's DOOR reads the lightmap of
    // the VISIBLE pixel (data2.g) while its Beer-Lambert term now runs on
    // fogDist. On a pane those two describe different places: a window with a
    // low sky lightmap (recessed in a thick wall, under an eave, covered porch)
    // looking out at a bright landscape opens the door on the PANE and prices
    // the distance on the LANDSCAPE -- a ~60% cave haze painted over sunlit
    // terrain, on glass pixels only, where the legacy 2-block reading gave ~3%.
    // The receiver's own lightmap is unreachable here (the pane owns colortex2
    // on this pixel), so the GLASS branch zeroes this weight instead of
    // re-deriving the door: cave haze on glass goes back to exactly what it
    // always was, none, without touching any other fog.
    float fogCaveW = 1.0;

    // EYE sky-exposure gate shared by the DISTANCE fogs below (biome fog tint,
    // ATMO_FOG, AERIAL_PERSPECTIVE -- vanilla AND DH mirrors). Distance haze
    // lives in the AIR along the view path, so its AMOUNT must not depend on
    // the RECEIVER skylight: a canopy floor or cave mouth 120 blocks away sits
    // behind the same air as the sunlit grass beside it. The old per-pixel
    // skyl gates starved those dark receivers of haze -> sharp dark holes in
    // the distance. Keeping caves fog-free while the EYE is underground is the
    // only job the pixel gate really had -> same curve as the VL skyExpo, but
    // WITHOUT its Nether override (pixel skyl was 0 there, so the Nether never
    // had these fogs and must not gain them).
    float fogEyeGate = smoothstep(0.02, 0.40, float(eyeBrightnessSmooth.y) / 240.0);

#ifdef FOG_SHADOWS_ACTIVE
    // FOG_SHADOWS: ONE shared sun-visibility probe per pixel (fogSunVis above),
    // hoisted OUT of the individual fog gates -- ATMO_FOG (vanilla + DH
    // mirror), AERIAL_PERSPECTIVE, DAWN_MIST and the HEIGHT_FOG tail all read
    // the same value. Split as fogShadDir (DIRECT/solar fog glow, fully
    // shadowed) and fogShadAmb (sky-ambient fog part: ambient light arrives
    // from the whole sky, so it only dips to 75% under full occlusion --
    // enough for the shadow to read on the fog without killing it). Probed
    // only when a fog can consume it: eye out of water AND sky-exposed (the
    // same fogEyeGate the fogs use; the Nether/End have zero skylight, so
    // they are excluded here and their dimensional haze is never probed
    // against the repurposed Nether shadow map). Everywhere else the neutral
    // 1.0 keeps every term at its legacy value -- including the underground
    // HEIGHT_FOG tail floor, where a sky-shadow probe would be meaningless.
    float fogSunV = 1.0;
    // RAMPED perf gate. fogEyeGate is a continuous quantity, so a hard
    // threshold on it made the result switch between 1.0 and as little as 0.75
    // as eyeBrightnessSmooth crossed the step. ATMO_FOG / AERIAL_PERSPECTIVE /
    // DAWN_MIST hide that (they are all multiplied by fogEyeGate ~ 0 there),
    // but the HEIGHT_FOG analytic tail is NOT gated by it -- at a cave mouth
    // with a long view out the far haze visibly jumped. Blending the probe in
    // over the first sliver of the gate keeps the underground skip (weight
    // exactly 0 -> no taps paid) and removes the discontinuity.
    float fogProbeW = smoothstep(0.0, 0.02, fogEyeGate);
    if (isEyeInWater == 0 && fogProbeW > 0.0) {
#ifdef CLOUD_SHAFTS_ACTIVE
        // CLOUD_SHAFTS: la visibilite shadow-map (fogSunVis, inchangee) fois
        // l'INTEGRALE de l'ombre des nuages le long du rayon (fogCloudVis).
        // Le produit passe par le MEME fondu fogProbeW que la version
        // d'origine, donc la porte souterraine et sa rampe sont intactes.
        fogSunV = mix(1.0, fogSunVis(cameraPosition, worldDir, dist, vlDither)
                         * fogCloudVis(cameraPosition, worldDir, dist, vlDither), fogProbeW);
#else
        fogSunV = mix(1.0, fogSunVis(cameraPosition, worldDir, dist, vlDither), fogProbeW);
#endif
    }
    // 'dist' here, not fogDist: fogDist is still equal to dist at this point
    // and only the GLASS branch moves it. That branch RE-PROBES these three
    // values on its resolved bound (see the re-price block there), so a window
    // pixel never keeps a probe that landed inside the room.
    float fogShadDir = fogSunV;
#ifdef CLOUD_SHAFTS_ACTIVE
    // CLOUD_SHAFTS: le plancher de la part CIEL devient un PALIER
    // (SHAFT_AMB_K, lib/settings.glsl). K = 0.25 EST le 0.75 + 0.25*v
    // d'origine, donc le palier Discret est iso-amplitude ; les paliers
    // superieurs ouvrent ce terme parce que c'est le SEUL qui puisse porter
    // les colonnes vues DE COTE (a 90 deg du soleil le lobe pow(vdotS, 6) du
    // terme direct est nul).
    float fogShadAmb = (1.0 - SHAFT_AMB_K) + SHAFT_AMB_K * fogSunV;
#else
    float fogShadAmb = 0.75 + 0.25 * fogSunV;
#endif
#endif

    if (isSky) {
        // Sky (atmosphere + clouds) is already painted by the deferred pass,
        // BEFORE translucents: color already holds it.
    } else {
        vec4 data2 = texture2D(colortex2, uv);
#if SNOW_SPARKLE == 1
        // SNOW material band (colortex2.b = 0.38, gbuffers_terrain id 42): read
        // ONCE here, then the flag is neutralised to 0.0 so every legacy band
        // test below (water / glass / portal branches, PBR gate, water-column
        // probes, entity and lava bands) sees the plain opaque it always did.
        // snowSv caches the opaque AO block's shadowtex1 tap for the sparkle
        // (-1.0 = not taken yet).
        float snowW = (data2.b > 0.35 && data2.b < 0.42) ? 1.0 : 0.0;
        if (snowW > 0.5) data2.b = 0.0;
        float snowSv = -1.0;
#endif
        vec3 world0 = mat3(gbufferModelViewInverse) * viewPos + cameraPosition;
        float skyl = data2.g * data2.g;
        // GLASS_SEE_THROUGH companion of fogDist: the world position the two
        // ALTITUDE-dependent fog terms sample (ATMO_FOG's mid-path height,
        // CAVE_FOG's depth below sea level). Same rule -- the pane is not where
        // the ray ends, so on glass it moves to the surface behind it.
        vec3 fogW0 = world0;

        // ===================== WATER =====================
        if (data2.b > 0.95) {
#if DEBUG_VIEW == 28
            // ---- DEBUG VIEW 28, DARK BLUE: an ordinary WATER pixel, taken
            // care of by the water branch below. No pane is involved, so none
            // of it is the glass probe's business. Painted only so BLACK keeps
            // ONE meaning -- neither glass nor water. Without it, water the
            // water branch dressed PERFECTLY came out the same black as the sky
            // or a wall, and the legend read that black as "no glass seen".
            aux5 = vec4(0.0, 0.0, 0.35, 1.0);
#endif
            vec3 normalV = normalize(texture2D(colortex1, uv).rgb * 2.0 - 1.0);

            #ifdef WATER_HORIZON_SKY
                // CSE hoist: horizon-distance weight, shared by the base-color
                // sky floor (hzB), the SSR confidence fade and the grazing
                // reflection raise (hzR) -- one smoothstep instead of three.
                float hzDistW = smoothstep(WATER_HORIZON_DIST * 0.5, WATER_HORIZON_DIST * 2.0, dist);
            #endif

#if PERF_WATER_FAR_SIMPLE == 1 && defined SSR_ENABLED
            // ============ C1c (LOT C, lib/settings.glsl) : EAU LOINTAINE ============
            // Au-dela de ~90 blocs, la ou le poids miroir plafonne (>= ~0.95,
            // cap 0.98 atteint des ~45 blocs en rasant -- table EAU5) et ou la
            // colonne est asymptotique (le fond est invisible), le pixel d'eau
            // se REDUIT a : ciel-miroir teinte + glint GGX + in-scatter
            // asymptotique. Toute la branche lourde (PCSS, refraction,
            // caustiques, colonne integree, ecume, 1-2 rayons SSR, PT,
            // whitecaps) est COURT-CIRCUITEE ; fondu continu 70 -> 90 blocs
            // (dans la bande les deux chemins sont payes, bande ~1 % des
            // pixels ocean a hauteur d'oeil). Garde-fous : oeil dehors, plan
            // quasi horizontal (flatWf), miroir estime dominant -- une vue
            // plongeante (falaise proche, fond visible) garde la branche
            // complete. Ecarts assumes et chiffres au gate (lib/settings.glsl).
            float farW = 0.0;
            vec3 farCol = vec3(0.0);
            float wMirrorF = 0.0;
            if (isEyeInWater == 0) {
                // Meme chaine fresnel/graze/horizon que la branche lourde, SSR
                // a zero (hit = 0) : c'est l'ESTIMATEUR du poids miroir final.
                // Noms suffixes F pour ne pas entrer en collision avec les
                // declarations du bloc SSR de la branche lourde.
                vec3 upVNf = normalize(mat3(gbufferModelView) * vec3(0.0, 1.0, 0.0));
                float flatWf = smoothstep(0.4, 0.8, dot(normalV, upVNf));
                float ndvWf = clamp(dot(normalV, -viewDir), 0.0, 1.0);
                float ndvGeoF = clamp(dot(upVNf, -viewDir), 0.0, 1.0);
                float grazeWf = pow(1.0 - ndvGeoF, 2.6) * flatWf;
                vec3 nFresF = normalize(mix(normalV, upVNf, grazeWf));
                float fresGF = 0.02 + 0.98 * pow(1.0 - clamp(dot(nFresF, -viewDir), 0.0, 1.0), 5.0);
                float fresPF = max(0.02 + 0.98 * pow(1.0 - ndvWf, 5.0), fresGF);
                float reflWF = clamp(fresPF * mix(0.95 * WATER_MIRROR_ANGLE, 1.0, grazeWf)
                                     * (WATER_REFLECTIVITY * WT_MIRROR), 0.0, 0.98);
                #ifdef WATER_HORIZON_SKY
                // Meme releve distance->ciel que la branche lourde, hit = 0.
                reflWF = max(reflWF, hzDistW * clamp(0.80 * WATER_REFLECTIVITY, 0.0, 0.98)
                                     * WATER_HORIZON_SKY_STRENGTH);
                #endif
                // Meme plancher de reflexion (module ciel + angle de vue).
                reflWF = max(reflWF, WATER_REFLECT_FLOOR * smoothstep(0.4, 0.9, skyl)
                                     * mix(1.0, 0.30, smoothstep(0.55, 0.85, ndvGeoF)));
                farW = smoothstep(70.0, 90.0, dist) * smoothstep(0.90, 0.95, reflWF) * flatWf;
                if (farW > 0.0) {
                    // UN tap dur remplace tout le PCSS : a 90+ blocs la
                    // penombre est sub-pixel, mais l'ombre d'une falaise doit
                    // continuer d'eteindre le soleil-miroir et le glint (le
                    // bug historique "reflet du soleil a l'ombre" ne doit pas
                    // revenir par ce raccourci). Fail-open comme wShadow.
                    float wShadowF = shadowVis1(viewPos);
                    // COLONNE ASYMPTOTIQUE : waterColumn avec un chemin si
                    // long que Tfl == 0 -- il ne reste que le in-scatter, la
                    // constante vers laquelle la colonne integree converge de
                    // toute facon ici. Meme fonction, meme calibration, zero
                    // copie qui pourrait deriver.
                    vec3 tintSF = texture2D(colortex5, uv).rgb;
                    farCol = waterColumn(vec3(0.0), 1.0e3, tintSF, skyl, wShadowF,
                                         data2.r, worldDir, lightW);
                    #ifdef WATER_HORIZON_SKY
                    // Meme plancher anti-noir que la branche lourde (site 3).
                    if (!skyBaseWDok) { skyBaseWD = getSkyBase(worldDir, sunW); skyBaseWDok = true; }
                    vec3 hzSkyRawF = waterSkyTint(skyBaseWD);
                    vec3 hzSkyF = mix(vec3(luma(hzSkyRawF)), hzSkyRawF, WCOL_HZ_CHROMA)
                                * WCOL_HZ_FILT * max(skyl, 0.15) * mix(0.60, 1.0, wShadowF);
                    farCol = mix(farCol, hzSkyF, hzDistW * WCOL_HZ_STR * WATER_HORIZON_SKY_STRENGTH);
                    #endif
                    // CIEL-MIROIR : meme normale aplatie et meme skyReflect que
                    // la branche lourde (waterSkyTint est DANS skyReflect), donc
                    // meme teinte, memes nuages ecran quand la direction y est.
                    vec3 nSkyF = normalize(mix(normalV, upVNf, flatWf * (1.0 - WATER_SKY_DISTORT)));
                    vec3 rdSkyVF = reflect(viewDir, nSkyF);
                    vec3 rdSkyWF = normalize(mat3(gbufferModelViewInverse) * rdSkyVF);
                    vec3 reflF = skyReflect(viewPos, rdSkyVF, rdSkyWF, sunW, skyl);
                    #if SUN_MIRROR_SHADOW == 1
                    reflF *= vlxSunMirror(rdSkyWF, lightW, wShadowF * wShadowF);
                    #endif
                    float reflFL = max(luma(reflF), 1e-4);
                    #ifdef WATER_HORIZON_SKY
                    // Plancher (a) de la branche lourde avec hit = 0 (pas de rayon).
                    reflF = max(reflF, mix(reflF, vec3(reflFL), 0.60) * (0.30 * WATER_HORIZON_SKY_STRENGTH));
                    #endif
                    // Meme desaturation du miroir (fond au rasant via grazeWf).
                    reflF = mix(reflF, vec3(luma(reflF)), clamp(REFLECT_DESAT, 0.0, 1.0) * (1.0 - grazeWf));
                    #if SSR_FALLBACK_V2 == 1
                    // A2 : plancher ambiant local (eau de grotte), hit = 0.
                    reflF = max(reflF, ssrLocalAmb(farCol));
                    #endif
                    farCol = mix(farCol, reflF, reflWF);
                    // GLINT GGX : strictement le meme modele que la branche
                    // lourde (lobe, knee WCOL_V3, masque d'ombre au carre) --
                    // c'est la beaute du truc, il n'est PAS simplifie.
                    vec3 Lgf = normalize(shadowLightPosition);
                    vec3 Hgf = normalize(Lgf - viewDir);
                    float ndhF = clamp(dot(normalV, Hgf), 0.0, 1.0);
                    float ndlF = clamp(dot(normalV, Lgf), 0.0, 1.0);
                    float ldhF = clamp(dot(Lgf, Hgf), 0.0, 1.0);
                    float aGlF = mix(0.006, 0.016, clamp(dist / 160.0, 0.0, 1.0)) * WATER_GLINT_SIZE;
#if SSR_V3 == 1 && WAVE_LOD == 1 && WAVES_V3 == 1
                    // SSR_V3 (e). SAME Toksvig term as the heavy branch -- and
                    // this is the branch where it actually fires, because
                    // PERF_WATER_FAR_SIMPLE owns the water past ~90 blocks and
                    // the first WAVE_LOD cut sits at 95.6. Keeping the two
                    // glints on one law is the same contract the comment above
                    // states ("strictement le meme modele"): a discrepancy here
                    // would print the 70 -> 90 block cross-fade band on the sea.
                    // Same sqrt(a*a) guard as the heavy branch: below the first
                    // cut the lobe must be bit-identical, not one ulp away.
                    float aGlVF = (2.0 * SSR_V3_GLINT_VAR * SSR_V3_GLINT_V1)
                                * clamp(log2(max(dist, 1.0) / SSR_V3_GLINT_D0), 0.0, 3.62);
                    if (aGlVF > 0.0) aGlF = sqrt(aGlF * aGlF + aGlVF);
#endif
                    float aGlF2 = aGlF * aGlF;
                    float dDenF = ndhF * ndhF * (aGlF2 - 1.0) + 1.0;
                    float specDF = aGlF2 / (3.14159265 * dDenF * dDenF);
                    float fEgF = 1.0 - ldhF;
                    float fEgF2 = fEgF * fEgF;
                    float specFF = 0.02 + 0.98 * fEgF2 * fEgF2 * fEgF;
                    float kGlF = aGlF * 0.5;
                    float specVF = ndlF / max((ndlF * (1.0 - kGlF) + kGlF)
                                            * (ndvWf * (1.0 - kGlF) + kGlF), 1e-3);
                    float glintVisF = 1.0;
                    #if WATER_GLINT_SHADOW == 1
                    glintVisF = wShadowF * wShadowF;
                    #endif
#if WCOL_V3 == 1
                    float specRawF = specDF * specFF * specVF;
                    float specSunF = WATER_GLINT_KNEE * specRawF / (WATER_GLINT_KNEE + specRawF);
#else
                    float specSunF = min(specDF * specFF * specVF, 40.0);
#endif
#if SSR_V3 == 1
                    // SSR_V3 (e): same absolute ceiling as the heavy branch
                    // (inert at the defaults, see the comment there).
                    vec3 glintAddF = gLightC * specSunF * WATER_SUN_GLINT
                                   * smoothstep(0.7, 0.95, data2.g) * glintVisF
                                   * (1.0 - rainStrength * 0.7);
                    float glintLF = luma(glintAddF);
                    float glintTF = SSR_V3_GLINT_CEIL * 0.4;
                    if (glintLF > glintTF) {
                        float glintCF = SSR_V3_GLINT_CEIL - glintTF;
                        float glintEF = glintLF - glintTF;
                        glintAddF *= (glintTF + glintCF * glintEF / (glintEF + glintCF)) / glintLF;
                    }
                    farCol += glintAddF;
#else
                    farCol += gLightC * specSunF * WATER_SUN_GLINT
                            * smoothstep(0.7, 0.95, data2.g) * glintVisF
                            * (1.0 - rainStrength * 0.7);
#endif
                    // Meme contrat wMirror que la branche lourde (reliefs des
                    // voiles d'air + densite VL immergee).
                    wMirrorF = reflWF * flatWf;
                }
            }
            // Court-circuit total au-dela du fondu ; la branche lourde
            // ci-dessous garde son indentation d'origine (diff minimal).
            if (farW < 0.999) {
#endif
            // SHADOW ON WATER: scalar PCSS penumbra of the terrain
            // (sampleShadowPCF, same LIGHT_SIZE/SHADOW_SOFTNESS radius, reusing
            // the already-computed static bayer8 dither) reduced to luma [0..1].
            // Consumed as-is by scatter, the horizon floor and the glint.
            // STAYS ON THE LEGACY PATH even with SHADOW_V2 = 1: the V2
            // receiver needs dFdx/dFdy of viewPos (geometric normal), which is
            // not reliable on a position reconstructed in this fullscreen pass
            // (only forward passes route through getShadow). Accepted gap: at
            // the shore the same caster is ~6x blurrier at contact on the
            // water (0.6*T0 PCF floor + legacy bias) than on adjacent V2 land.
            // Faded out by sfade BEFORE shadowDistance, then fail-open 1.0
            // beyond it (same contract as shadowVis1: never a black shadow out
            // of range).
            // RECEIVER LIFT +0.25: the shadow map holds the UNDISPLACED water
            // plane (shadow.vsh has no waves) while the visible surface sinks to
            // -0.18 (gbuffers_water.vsh hard clamp [-0.18, +0.03], independent
            // of the wave slider). Without the lift, troughs fall under their own
            // tex0 texel and pick up the blue self-tint of the water tag. The
            // lift must stay small: a vertical lift v shortens the RECEIVED
            // shadow by v/tan(elev) blocks, so at sunset (elev ~15 deg) 0.25
            // already eats ~0.9 block. Real need is 0.18 plus margin; the
            // remaining edge residue is killed on the glint side by
            // glintVis = wShadow^2 below. Sky ambient stays full (shaded water
            // is blue, not black).
            float wShadow = 1.0;
            {
                float sfadeW = smoothstep(0.85, 1.0, dist / shadowDistance);
                if (sfadeW < 1.0) {
                    vec3 vUpW = mat3(gbufferModelView) * vec3(0.0, 1.0, 0.0);
#if PERF_WATER_SHADOW == 1 && SHADOW_V2 == 1
                    // C1a (LOT C, lib/settings.glsl) : version allegee dediee
                    // (3 positions de recherche + 6 taps PCF materiels,
                    // recherche sautee au-dela de 60 blocs). Meme clip, meme
                    // lift +0.25, meme dither, meme fail-open ; retour deja
                    // scalaire (wShadow n'etait consomme qu'en luma).
                    wShadow = mix(clamp(sampleShadowWaterLite(toShadowClip(VLX_PIX_RECV(viewPos + vUpW * 0.25, normalV), normalV), dither, dist), 0.0, 1.0), 1.0, sfadeW);
#else
                    vec3 pcfW = sampleShadowPCF(toShadowClip(VLX_PIX_RECV(viewPos + vUpW * 0.25, normalV), normalV), dither);
                    wShadow = mix(clamp(luma(pcfW), 0.0, 1.0), 1.0, sfadeW);
#endif
                }
            }
            vec3 localLight = gAmbC * skyl
                            + gLightC * 0.5 * skyl * wShadow
                            // CL GAP: vanilla-warm on purpose, see the water-fog scatter note.
                            + getTorchColor() * data2.r * data2.r * 1.5;
            #if defined SS_LIGHTS || defined SSGI || defined VLX_RSM_ACTIVE
#if GI_HALF_RES == 1
                // half-res GI: depth+normal aware upsample at the water surface
                localLight += giUpsample(uv, -viewPos.z).rgb;
#else
                // full-res GI: 3x3 depth bilateral (the half-res path gets its
                // denoise from the upsample; this path had none)
                localLight += giFilter3(uv, -viewPos.z);
#endif
            #endif

            vec3 vp1pre = toView(uv, texture2D(depthtex1, uv).r);
            float wdepth0 = max(distance(viewPos, vp1pre), 0.0);

            vec2 ruv = uv;
            #ifdef WATER_REFRACTION
                // Refraction offset, much weaker when the eye is UNDER water
                // (otherwise the surface seen from below stretches and smears)
                float refScale = (isEyeInWater == 1) ? 0.04 : 0.13;
                // TAAU: screen offset expressed in the sub-rect (*TAAU_S) and
                // edge clamp brought back to TAAU_S - margin.
                vec2 refOff = normalV.xy * (refScale / max(length(viewPos) * 0.5, 1.0))
                            * clamp(wdepth0 * 1.5, 0.0, 1.0) * REFRACTION_STRENGTH * TAAU_S;
                ruv = clamp(uv + refOff, vec2(0.001), vec2(0.999 * TAAU_S));
                if (texture2D(depthtex0, ruv).r >= texture2D(depthtex1, ruv).r - 1e-6) ruv = uv;
                color = texture2D(colortex0, ruv).rgb;
            #endif

            vec3 vp1 = toView(ruv, texture2D(depthtex1, ruv).r);
            float wdepth = max(distance(viewPos, vp1), 0.0);
            vec3 world1 = mat3(gbufferModelViewInverse) * vp1 + cameraPosition;

            if (isEyeInWater == 0) {
                #ifdef WATER_CAUSTICS
                    // vdep = VERTICAL water depth above the floor (the real path
                    // length of the light, not the camera->floor distance)
                    float vdep = max(world0.y - world1.y, 0.0);
                    // Sun/sky pre-gate: at night, in rain, or with a sky-shadowed
                    // floor the whole caustic field would be computed then
                    // multiplied by ~0. No difference when lit.
                    float sunPre = smoothstep(-0.05, 0.2, lightHeight()) * (1.0 - rainStrength);
#if PERF_OCEAN == 1
                    // PERF_OCEAN (3): camera-distance early-out. soft4 below is
                    // a PAID fade (it widens the photon footprint, never zero),
                    // so a daylit shelf at 150 blocks still paid vlCa4Net
                    // (3 slope evals + 9 photons) + shadowVis1 + 2 normal taps
                    // for a modulation the 0.98 mirror cap (~45 blocks on) and
                    // the column absorption hold at the per-mille level. Fade
                    // the WEIGHT over 110->150 blocks (the soft4 fade is fully
                    // wide at 110, so nothing pops), then skip everything.
                    // Honors CAUSTIC_DIST_FADE 0.0 ("no distance fade"): no cut.
#if CAUSTICS_V4 == 0 && CAUSTIC_BLUR_FADE == 0
                    // v3 path without blur-fade: caFadeD below already owns a
                    // hard zero at 120 blocks when CAUSTIC_DIST_FADE is 1.0 --
                    // the cut is then a pure GATE aligned on that zero
                    // (bit-identical render: no double fade over 110..120, and
                    // the 120..150 dead window where the full body -- cached
                    // caustic field, shadowVis1, 2 normal taps -- was paid for
                    // a caW identically 0 is skipped outright). At partial
                    // DIST_FADE (0.5) caFadeD floors above zero, the far field
                    // stays visible, so the wider 110->150 fade keeps ruling.
                    float caCut4 = (CAUSTIC_DIST_FADE >= 1.0)
                                 ? 1.0 - step(120.0, dist)
                                 : ((CAUSTIC_DIST_FADE > 0.0)
                                    ? 1.0 - smoothstep(110.0, 150.0, dist) : 1.0);
#else
                    float caCut4 = (CAUSTIC_DIST_FADE > 0.0)
                                 ? 1.0 - smoothstep(110.0, 150.0, dist) : 1.0;
#endif
                    if (caCut4 > 0.0 && sunPre * skyl > 0.005) {
#else
                    if (sunPre * skyl > 0.005) {
#endif
#if CAUSTICS_V4 == 1
#if CAUSTIC_FACING == 1
                    // ---- CAUSTICS_V4 + CAUSTIC_FACING (lib/settings.glsl, doc complete) ----
                    // Same math as the CAUSTIC_FACING == 0 arm below, REORDERED:
                    // every CHEAP factor of the weight (absorption, shallow
                    // window, screen-space floor normal, sun facing) is paid
                    // BEFORE the field (vlCa4Net, 9 photons + 3 slope evals)
                    // and before the shadowVis1 tap; a weight already <= 0.004
                    // skips both. The weight is a linear product, so outside
                    // the cutoff the result is the product of the same factors.
                    // WHAT THIS ARM DID *NOT* DO, until PERF_CAUSTIC_LOD (A):
                    // the shadow tap sat INSIDE the branch, so a floor entirely
                    // in shadow passed the 0.004 test on the pre-shadow weight,
                    // paid the whole field, and only then multiplied it by
                    // zero. "Skips both" was true of a small weight and false
                    // of a shaded one. The gate folds the tap into the mask.
                    float att4 = exp(-vdep * 0.13);
                    float shal4 = mix(1.0, smoothstep(0.05, 0.55, vdep), CAUSTIC_SHALLOW_FADE);
                    // Floor normal rebuilt from 2 depthtex1 taps (colortex1
                    // holds the WATER normal on this pixel) -- see the verbatim
                    // arm below. Kept as the FULL world vector here: the cross
                    // of screen-space forward differences faces the CAMERA by
                    // construction, so N.L kills exactly the side the player
                    // sees in shadow (kelp cross-quads, fish flanks).
                    vec2 pxC4 = TAAU_S / vec2(viewWidth, viewHeight);
                    vec3 vpG4x = toView(ruv + vec2(pxC4.x, 0.0), texture2D(depthtex1, ruv + vec2(pxC4.x, 0.0)).r);
                    vec3 vpG4y = toView(ruv + vec2(0.0, pxC4.y), texture2D(depthtex1, ruv + vec2(0.0, pxC4.y)).r);
                    vec3 nG4 = cross(vpG4x - vp1, vpG4y - vp1);
                    vec3 nW4 = (mat3(gbufferModelViewInverse) * nG4) / max(length(nG4), 1e-6);
                    // FAIL-CLOSED sun facing: dot <= 0 -> strictly 0. The
                    // CA4_WALL floor now only doses faces that SEE the sun.
                    float caFace4 = smoothstep(0.0, 0.25, dot(nW4, lightW));
                    float caN4 = mix(CA4_WALL, 1.0, smoothstep(0.05, 0.55, nW4.y)) * caFace4;
                    float caW4 = clamp(CAUSTIC_STRENGTH * 0.60, 0.0, 1.0)
                               * skyl * sunPre * att4 * shal4 * caN4;
#if PERF_OCEAN == 1
                    // PERF_OCEAN (3): continuity of the early-out above.
                    caW4 *= caCut4;
#endif
#if PERF_CAUSTIC_LOD == 1
                    // PERF_CAUSTIC_LOD (A): the shadow tap moves INTO the
                    // early-out mask. It used to be taken one line below, i.e.
                    // AFTER the branch that has already paid vlCa4Net's 2166
                    // ALU -- a floor entirely in shadow paid the whole field and
                    // then multiplied it by zero, which the comment above the
                    // arm claimed it did not. Same tap, same predicate, so the
                    // tap COUNT is unchanged; only its position moves. And
                    // shadowVis1 is a step(), so caW4 * 1.0 == caW4 exactly and
                    // caW4 * 0.0 == 0.0: the second test below is exactly
                    // "shadowVis1 != 0", and the skipped body ended in
                    // mix(vec3(1.0), <finite>, 0.0) == vec3(1.0). Bit-identical.
                    if (caW4 > 0.004) caW4 *= shadowVis1(VLX_PIX_FLOOR(vp1));
#endif
                    if (caW4 > 0.004) {
#if PERF_CAUSTIC_LOD == 0
                        caW4 *= shadowVis1(VLX_PIX_FLOOR(vp1)); // a shaded floor has NO caustics
#endif
#if UW_SHAFT_FIX3 == 1
                        // (A) same slide as the beams -- see the verbatim arm.
                        vec2 cpos4 = VLX_PIX_XZ(world1.xz + uwShaftSlide(lightW, vdep));
#else
                        vec2 cpos4 = VLX_PIX_XZ(world1.xz + vlCa4Offset(lightW, vdep));
#endif
                        float soft4 = 1.0 - smoothstep(30.0, 110.0, dist) * 0.65 * CAUSTIC_DIST_FADE;
#if BLUE_NOISE == 1
                        vec2 dth4 = vec2(vlDither, blueDither(gl_FragCoord.xy + vec2(37.0, 17.0), frameCounter));
#else
                        vec2 dth4 = vec2(vlDither, fract(vlDither + hash12(floor(gl_FragCoord.xy))));
#endif
#if VLX_PHYS_SYNC == 1
                        // PHYSICS_FIELD_SYNC, site "A TRAVERS LA SURFACE" : ce
                        // pixel EST la surface, donc l'estampille de la frame
                        // repond exactement, et la waviness lue est CELLE DE CE
                        // PIXEL. C'est le site le mieux arme des trois.
                        // vlxPhysReg rend au champ le decalage VL_CA5_REG que la
                        // ligne suivante lui soustrait (convention du champ du
                        // pack ; celui du mod n'en a pas).
                        VLX_PHYS_SET(vlxPhysPix, vlxPhysPixWav, VL_CA5_REG(world0.y));
#endif
                        // CAUSTIC_DEPTH_BLUR_V4: vdep is the column this pixel
                        // is seen through, i.e. the propagation depth of the
                        // photons that drew the pattern. Gate off -> the old
                        // vlCa4Net(soft4) call, textually.
                        float ca4 = vlCaNetD(cpos4 - VL_CA5_REG(world0.y),
                                             frameTimeCounter, dth4, 0.0, soft4, lightW, vdep);
                        vec3 beerC4 = exp(-vdep * vlxWaterK()); // EAU9: this biome's medium
                        vec3 caTint4 = vlxFloorCarrier(
                            mix(vec3(1.0), beerC4 / max(beerC4.b, 1e-4), 0.35), vdep);
                        color *= mix(vec3(1.0), clamp(vec3(ca4) * caTint4, 0.0, CA_CLAMP_HI), caW4);
                    }
#else
                    // ---- CAUSTICS_V4 (photon density net, lib/water.glsl) ----
                    // Floor seen from OUTSIDE, through the water surface. The
                    // lookup slides along the REFRACTED sun ray (water IOR
                    // 1.3333, the same index the sun refraction below uses) by
                    // the vertical column above THIS floor pixel: the mesh
                    // jumps from one ledge to the next, which is the depth
                    // cue, while its scale and its sharpness stay constant.
                    // lightW is the SHADOW light in world space (rotated by
                    // sunPathRotation), so the net is cast by the same sun as
                    // the shadows - it also stretches the throw along that
                    // azimuth (vlCa4Aniso, passed into vlCa4Net below).
#if UW_SHAFT_FIX3 == 1
                    // (A) the net moves onto the SHADOW MAP's slide with the
                    // volumetric beams (uwShaftSlide, lib/water.glsl), so a
                    // shaft and the spot at its foot stay one object. The
                    // pattern is stochastic and unregistered to anything, so
                    // on a flat bottom this is a rigid translation and reads
                    // identically; what it really changes is the depth SHEAR
                    // on ledges and walls, which now shears the way the cast
                    // shadows do. None of the CAUSTICS_V4/V5 calibration is
                    // touched: this term only translates the lookup, it does
                    // not scale, rotate or sharpen the field.
                    vec2 cpos4 = VLX_PIX_XZ(world1.xz + uwShaftSlide(lightW, vdep));
#else
                    vec2 cpos4 = VLX_PIX_XZ(world1.xz + vlCa4Offset(lightW, vdep));
#endif
                    float sunF4 = sunPre * shadowVis1(VLX_PIX_FLOOR(vp1)); // a shaded floor has NO caustics
#if PERF_CAUSTIC_LOD == 1
                    // PERF_CAUSTIC_LOD (A): this verbatim arm has no early-out
                    // of its own, so a floor in shadow used to pay the full
                    // field (2166 ALU) for a caW4 that sunF4 had already forced
                    // to zero. The outer pre-gate guarantees sunPre > 0, and
                    // shadowVis1 is a step(), so `sunF4 > 0.0` is exactly
                    // "shadowVis1 != 0"; the skipped tail ended in
                    // mix(vec3(1.0), <finite>, 0.0) == vec3(1.0). The braces
                    // are UNCONDITIONAL (the UW_SHAFT_BOUND idiom below), so
                    // gate 0 only loses a scope, not a statement.
                    if (sunF4 > 0.0)
#endif
                    { // PERF_CAUSTIC_LOD (A): scope of the sunF4 early-out
                    // Eye distance widens the photon FOOTPRINT instead of
                    // fading the net out: distant filaments melt into a glow,
                    // they never degenerate into TAA noise.
                    float soft4 = 1.0 - smoothstep(30.0, 110.0, dist) * 0.65 * CAUSTIC_DIST_FADE;
                    // Temporal blue-noise jitter of the 9 photons. The two axes
                    // must be INDEPENDENT: a per-pixel constant offset (the old
                    // fract(vlDither + hash12(fragCoord))) decorrelates PIXELS
                    // from each other but not FRAMES -- over time the sample
                    // point only ever travels the line y = x + h, i.e. one
                    // diagonal of the cell, which left ~30% more residual grain
                    // at convergence. A second blue-noise tap at a shifted
                    // coordinate walks the whole cell instead.
#if BLUE_NOISE == 1
                    vec2 dth4 = vec2(vlDither, blueDither(gl_FragCoord.xy + vec2(37.0, 17.0), frameCounter));
#else
                    vec2 dth4 = vec2(vlDither, fract(vlDither + hash12(floor(gl_FragCoord.xy))));
#endif
#if VLX_PHYS_SYNC == 1
                    // PHYSICS_FIELD_SYNC, site "A TRAVERS LA SURFACE" (bras
                    // CAUSTIC_FACING 0) : meme regle que le bras FACING.
                    VLX_PHYS_SET(vlxPhysPix, vlxPhysPixWav, VL_CA5_REG(world0.y));
#endif
                    // CA5 registration: this site looks THROUGH the sheet,
                    // so world0 IS on it (VL_CA5_REG is 0.0 under v4).
                    // CAUSTIC_DEPTH_BLUR_V4, same contract as the FACING arm.
                    float ca4 = vlCaNetD(cpos4 - VL_CA5_REG(world0.y),
                                         frameTimeCounter, dth4, 0.0, soft4, lightW, vdep);
                    // Depth acts on the AMPLITUDE only - the column above
                    // absorbs the net, it never reshapes it. The shallow
                    // window keeps sunlit sand under a few centimetres of
                    // water from flaring.
                    float att4 = exp(-vdep * 0.13);
                    float shal4 = mix(1.0, smoothstep(0.05, 0.55, vdep), CAUSTIC_SHALLOW_FADE);
                    // Floor normal rebuilt in screen space from 2 depthtex1
                    // taps (colortex1 holds the WATER normal on this pixel).
                    // v4 does NOT mute vertical faces the way v3 had to: a
                    // sheared mesh on a wall IS the pool-wall look, so the
                    // normal only doses it through CA4_WALL.
                    vec2 pxC4 = TAAU_S / vec2(viewWidth, viewHeight);
                    vec3 vpG4x = toView(ruv + vec2(pxC4.x, 0.0), texture2D(depthtex1, ruv + vec2(pxC4.x, 0.0)).r);
                    vec3 vpG4y = toView(ruv + vec2(0.0, pxC4.y), texture2D(depthtex1, ruv + vec2(0.0, pxC4.y)).r);
                    vec3 nG4 = cross(vpG4x - vp1, vpG4y - vp1);
                    float nGy4 = (mat3(gbufferModelViewInverse) * nG4).y / max(length(nG4), 1e-6);
                    float caN4 = mix(CA4_WALL, 1.0, smoothstep(0.05, 0.55, nGy4));
                    // Same desaturated, capped water tint as v3.
                    // EAU7 -- SPECTRUM ALIGNED ON THE PACK'S OWN. This literal
                    // used to be vec3(0.70, 0.30, 0.14): a FOURTH, invented water
                    // spectrum whose R/B slope is 0.56 per block against the
                    // 0.356 of the calibrated WCOL_K_OUT -- 1.57x too steep, and
                    // laid on top of the two legs that already absorb the red.
                    // Since ca4 modulates AROUND 1.0, this site is on average a
                    // pure per-channel filter, worth 8.1% of the red lost at
                    // 2 blocks of path. Reusing WCOL_K_OUT keeps the intent
                    // ("the filaments cool down with depth") and divides the
                    // parasitic slope by ~1.6. CA_CLAMP_HI is unaffected:
                    // caTint4 is still normalised to blue, so its largest
                    // component stays exactly 1.0 and the clamp keeps bounding
                    // the same estimator peak (2.62 in v4/v5, 8.95 in v6).
                    vec3 beerC4 = exp(-vdep * vlxWaterK()); // EAU9: this biome's medium
                    // EAU8 -- SAME SHALLOW CHROMA BOUND AS THE CARRIER. This
                    // tint multiplies the COMPOSED colour (see the SCOPE note
                    // below), so in a 0.5-1 block shallow it was a third
                    // repaint of red already absorbed by the view leg and the
                    // light leg. vlxFloorCarrier() hands its chroma back over
                    // the same first blocks, at the same rate, with the same
                    // knob (WFLOOR_CHROMA_KEEP) -- shallow sand keeps its
                    // ochre, the deep filaments still cool down. Luma of the
                    // tint is preserved (mix toward luma()), so caW4 and
                    // CA_CLAMP_HI keep bounding the exact same estimator.
                    vec3 caTint4 = vlxFloorCarrier(
                        mix(vec3(1.0), beerC4 / max(beerC4.b, 1e-4), 0.35), vdep);
                    float caW4 = clamp(CAUSTIC_STRENGTH * 0.60, 0.0, 1.0)
                               * skyl * sunF4 * att4 * shal4 * caN4;
#if PERF_OCEAN == 1
                    // PERF_OCEAN (3): continuity of the early-out above.
                    caW4 *= caCut4;
#endif
                    // MODULATION around 1.0: focusing REDISTRIBUTES light rather
                    // than adding on top. SCOPE, stated exactly: the factor is
                    // applied to the COMPOSED colour (sun + ambient + skylight +
                    // torch + GI, all already summed above), not to the solar
                    // term alone -- so a torch-lit floor under water also gets
                    // modulated, down to ~0.70 in a dark cell, on light that
                    // never crossed the surface. That is a deliberate
                    // simplification: isolating the direct term here would mean
                    // re-deriving it after the fact. caW4 already gates on
                    // shadow, depth and skylight, which keeps the artefact
                    // confined to genuinely submerged, genuinely lit pixels.
                    // caW4 caps the excursion so the
                    // dark cells keep a lighting floor and never become holes;
                    // CA_CLAMP_HI (lib/water.glsl) is above the estimator's own
                    // peak - 2.62 under v4/v5, 8.95 under v6 - so the cusps keep
                    // their relief instead of being flattened to a uniform white
                    // by a clamp (see the shaping's knee - the ceiling is the
                    // knee, not this line). Under v6 the 2.7 that used to stand
                    // here would clip 1.82% of this site's area and 1.00% of its
                    // light: the term runs 0.237..5.53 from outside, where
                    // CA_OUTGAIN has already compressed it.
                    color *= mix(vec3(1.0), clamp(vec3(ca4) * caTint4, 0.0, CA_CLAMP_HI), caW4);
                    } // PERF_CAUSTIC_LOD (A): scope of the sunF4 early-out
#endif
#else
#if CAUSTIC_FACING == 1
                    // ---- legacy v3 + CAUSTIC_FACING (lib/settings.glsl, doc complete) ----
                    // Same math as the CAUSTIC_FACING == 0 arm below, REORDERED:
                    // cheap weight factors first, then the cached caustic field
                    // (~9 wave trains) and the shadowVis1 tap only if the
                    // weight survives the 0.004 cutoff.
                    #if CAUSTIC_BLUR_FADE == 1
                        float caBlur = smoothstep(40.0, 110.0, dist) * CAUSTIC_DIST_FADE;
                        float attC = exp(-vdep * 0.13);
                        float caFadeD = 1.0 - caBlur * 0.25;
                        float caShallow = mix(1.0, smoothstep(0.05, 0.55, vdep), CAUSTIC_SHALLOW_FADE);
                    #else
                        float attC = exp(-vdep * 0.22);
                        float caFadeD = 1.0 - smoothstep(48.0, 120.0, dist) * CAUSTIC_DIST_FADE;
                        float caShallow = mix(1.0, smoothstep(0.10, 1.10, vdep), CAUSTIC_SHALLOW_FADE);
                    #endif
                    // Screen-space floor normal (see the verbatim arm below for
                    // the full rationale) -- full world vector kept here,
                    // camera-facing by construction.
                    vec2 pxCa = TAAU_S / vec2(viewWidth, viewHeight);
                    vec3 vpGx = toView(ruv + vec2(pxCa.x, 0.0), texture2D(depthtex1, ruv + vec2(pxCa.x, 0.0)).r);
                    vec3 vpGy = toView(ruv + vec2(0.0, pxCa.y), texture2D(depthtex1, ruv + vec2(0.0, pxCa.y)).r);
                    vec3 nGca = cross(vpGx - vp1, vpGy - vp1); // view: +y screen = up -> y>0 for a floor
                    vec3 nWca = (mat3(gbufferModelViewInverse) * nGca) / max(length(nGca), 1e-6);
                    // FAIL-CLOSED sun facing: dot <= 0 -> strictly 0.
                    float caFaceL = smoothstep(0.0, 0.25, dot(nWca, lightW));
                    float caN = smoothstep(0.05, 0.55, nWca.y) * caFaceL; // vertical faces/ceilings ~0, floors/slopes 1
                    float caW = clamp(CAUSTIC_STRENGTH * 0.55, 0.0, 1.0)
                              * skyl * sunPre * attC * caFadeD * caShallow * caN;
#if PERF_OCEAN == 1
                    // PERF_OCEAN (3): continuity of the early-out above (the
                    // CAUSTIC_BLUR_FADE path has no zero of its own: caFadeD
                    // floors at 0.75 there).
                    caW *= caCut4;
#endif
#if PERF_CAUSTIC_LOD == 1
                    // PERF_CAUSTIC_LOD (A): shadow tap folded into the mask --
                    // same reasoning as the v4 arm above, on the ~9 wave trains
                    // of waveCausticSoft/Full_cached instead of vlCa4Net. The
                    // tap count is unchanged (same predicate) and the skipped
                    // tail ended in mix(vec3(1.0), <finite>, 0.0) == vec3(1.0).
                    if (caW > 0.004) caW *= shadowVis1(VLX_PIX_FLOOR(vp1));
#endif
                    if (caW > 0.004) {
#if PERF_CAUSTIC_LOD == 0
                        caW *= shadowVis1(VLX_PIX_FLOOR(vp1));
#endif
                        vec2 cpos = VLX_PIX_XZ(world1.xz + lightW.xz / max(lightW.y, 0.2) * vdep);
                        float cscaleU = 0.70 + 0.60 * vnoise(VLX_PIX_XZ(world1.xz) * 0.13 + frameTimeCounter * 0.04);
                        #if CAUSTIC_BLUR_FADE == 1
                            vec2 caF = waveCausticSoft_cached(cpos, frameTimeCounter, vdep, caBlur);
                            float caV = clamp(caF.x * cscaleU - mix(0.22, 0.08, caBlur), 0.0, 1.0);
                        #else
                            vec2 caF = waveCausticFull_cached(cpos, frameTimeCounter, vdep);
                            float caV = clamp(caF.x * cscaleU - 0.30, 0.0, 1.0);
                        #endif
                        vec3 beerC = exp(-vdep * vlxWaterK()); // EAU9: this biome's medium
                        vec3 caTintC = mix(vec3(1.0), beerC / max(beerC.b, 1e-4), 0.35);
                        vec3 caMod = mix(vec3(1.0), clamp((0.42 + caV * 2.3) * caTintC, 0.0, 1.9), caW);
                        color *= caMod;
                    }
#else
#if PERF_CAUSTIC_LOD == 1
                    // PERF_CAUSTIC_LOD (A): the two sunF lines below (originally
                    // sitting AFTER the field) are hoisted here so the shadow
                    // tap can gate the field instead of following it. Pure code
                    // motion: sunPre and vp1 are both live above this point and
                    // nothing between them is read. sunPre > 0 is guaranteed by
                    // the outer pre-gate and shadowVis1 is a step(), so
                    // `sunF > 0.0` is exactly "shadowVis1 != 0", and the skipped
                    // tail ended in mix(vec3(1.0), <finite>, 0.0) == vec3(1.0).
                    // Braces UNCONDITIONAL (the UW_SHAFT_BOUND idiom): gate 0
                    // keeps both lines where they were and only gains a scope.
                    float sunF = sunPre; // same expression as the pre-gate above
                    sunF *= shadowVis1(VLX_PIX_FLOOR(vp1));
                    if (sunF > 0.0)
#endif
                    { // PERF_CAUSTIC_LOD (A): scope of the sunF early-out
                    vec2 cpos = VLX_PIX_XZ(world1.xz + lightW.xz / max(lightW.y, 0.2) * vdep);
                    float cscaleU = 0.70 + 0.60 * vnoise(VLX_PIX_XZ(world1.xz) * 0.13 + frameTimeCounter * 0.04);
                    #if CAUSTIC_BLUR_FADE == 1
                        // FADE-TO-BLUR: eye distance SOFTENS the filament network
                        // (waveCausticSoft) instead of fading it out. The
                        // threshold drops with the blur because the soft variant
                        // peaks lower -> distant caustics stay present but blurry.
                        float caBlur = smoothstep(40.0, 110.0, dist) * CAUSTIC_DIST_FADE;
                        // CSE: cached variant shares wp2/grp + the swell-train
                        // phases between the fine field and the large octave
                        // (bit-identical output, ~3 vnoise + 1 swell pass saved)
                        vec2 caF = waveCausticSoft_cached(cpos, frameTimeCounter, vdep, caBlur);
                        // Threshold 0.22 near (visible from outside the water),
                        // 0.08 at max blur (soft variant peaks lower).
                        float caV = clamp(caF.x * cscaleU - mix(0.22, 0.08, caBlur), 0.0, 1.0);
                    #else
                        // Depth blur is INTERNAL here (causticSmall sharp) + large octave.
                        // CSE: cached variant, bit-identical (see waveCausticSoft_cached above)
                        vec2 caF = waveCausticFull_cached(cpos, frameTimeCounter, vdep);
                        float caV = clamp(caF.x * cscaleU - 0.30, 0.0, 1.0);
                    #endif
#if PERF_CAUSTIC_LOD == 0
                    float sunF = sunPre; // same expression as the pre-gate above
                    sunF *= shadowVis1(VLX_PIX_FLOOR(vp1));
#endif
                    // Scalar attenuation + slightly desaturated, CAPPED tint:
                    // a bright filament network, never a neon cyan blotch.
                    // EAU7: same spectrum alignment as the v4 site above -- the
                    // legacy path carried the identical invented literal.
                    vec3 beerC = exp(-vdep * vlxWaterK()); // EAU9: this biome's medium
                    vec3 caTintC = mix(vec3(1.0), beerC / max(beerC.b, 1e-4), 0.35);
                    #if CAUSTIC_BLUR_FADE == 1
                        // Depth extinction pushed back ~3-4 blocks (0.13 instead
                        // of 0.22): the internal sharp blur already softens.
                        float attC = exp(-vdep * 0.13);
                        // No alpha distance fade, only a slight hold-back (x0.75
                        // far away) to keep the distant ocean calm; blur does the rest.
                        float caFadeD = 1.0 - caBlur * 0.25;
                        // Tight shallow fade 0.05..0.55 block: sunlit sand under
                        // 0.5-1.5 block of water shows a SHARP network again.
                        float caShallow = mix(1.0, smoothstep(0.05, 0.55, vdep), CAUSTIC_SHALLOW_FADE);
                        // Ceiling is the 1.9 clamp on caMod below, nothing else.
                    #else
                        float attC = exp(-vdep * 0.22);
                        // Distance fade: the ~0.5 block network degenerates into
                        // pure TAA temporal noise far away.
                        float caFadeD = 1.0 - smoothstep(48.0, 120.0, dist) * CAUSTIC_DIST_FADE;
                        // Very shallow = SUBTLE: light has not focused yet
                        // (ripple focal length ~1 block) -> fade over 0.10..1.10
                        // block of column. CAUSTIC_SHALLOW_FADE 0.0 = no fade.
                        float caShallow = mix(1.0, smoothstep(0.10, 1.10, vdep), CAUSTIC_SHALLOW_FADE);
                        // Ceiling is the 1.9 clamp on caMod below, nothing else.
                    #endif
                    // EDGE-SHIMMER GUARD: the caustic pattern is a HORIZONTAL
                    // field projected along the sun. Applied to a VERTICAL face,
                    // cpos varies mostly through vdep -> stretched pattern that
                    // moires and flickers under TAA. Real caustics hit UPWARD
                    // facing surfaces, so weight by the FLOOR normal. colortex1
                    // holds the WATER normal here (DRAWBUFFERS:0125 overwrote it),
                    // so the floor normal is rebuilt in screen space from 2
                    // neighbouring depthtex1 taps (the center ruv tap is already
                    // paid above). At silhouette edges the derivative blows up
                    // exactly where we WANT it damped.
                    // TAAU: screen step expressed in the sub-rect (*TAAU_S).
                    vec2 pxCa = TAAU_S / vec2(viewWidth, viewHeight);
                    vec3 vpGx = toView(ruv + vec2(pxCa.x, 0.0), texture2D(depthtex1, ruv + vec2(pxCa.x, 0.0)).r);
                    vec3 vpGy = toView(ruv + vec2(0.0, pxCa.y), texture2D(depthtex1, ruv + vec2(0.0, pxCa.y)).r);
                    vec3 nGca = cross(vpGx - vp1, vpGy - vp1); // view: +y screen = up -> y>0 for a floor
                    float nGy = (mat3(gbufferModelViewInverse) * nGca).y / max(length(nGca), 1e-6);
                    float caN = smoothstep(0.05, 0.55, nGy); // vertical faces/ceilings ~0, floors/slopes 1
                    // The floor light is MODULATED around 1 -- darker between
                    // filaments, brighter on them: focusing REDISTRIBUTES the sun
                    // rather than adding on top (a plain color *= 1+ca can only
                    // brighten, which reads as a scrolling transparent texture).
                    // With depth, caV converges to its mean, so the modulation
                    // dissolves into blur like a PCSS penumbra.
                    // caN is a factor: caW -> 0 on vertical faces makes caMod
                    // exactly 1 (no filaments, no darkening).
                    float caW = clamp(CAUSTIC_STRENGTH * 0.55, 0.0, 1.0)
                              * skyl * sunF * attC * caFadeD * caShallow * caN;
#if PERF_OCEAN == 1
                    // PERF_OCEAN (3): continuity of the early-out above (the
                    // CAUSTIC_BLUR_FADE path has no zero of its own: caFadeD
                    // floors at 0.75 there).
                    caW *= caCut4;
#endif
                    vec3 caMod = mix(vec3(1.0), clamp((0.42 + caV * 2.3) * caTintC, 0.0, 1.9), caW);
                    color *= caMod;
                    } // PERF_CAUSTIC_LOD (A): scope of the sunF early-out
#endif
#endif
                    } // end caustics pre-gate
                #endif

                // Biome water: the vanilla tint (colortex5) is now ONLY a
                // murk detector + murky-biome hue. Every blue-water biome
                // (ocean, river, default) renders the calibrated REFERENCE
                // column below with a fixed slate palette -- no biome hue
                // drift toward green or azure.
                vec3 tintS = texture2D(colortex5, uv).rgb;
                // REFERENCE COLUMN - the calibrated two-term water column:
                // one Beer-Lambert absorption + one exponential veil, BOTH
                // driven by the in-water VIEW PATH length (wdepth), so the
                // colour climbs with depth AND with viewing distance.
                // Keying both on the PATH instead of the vertical column is
                // the design decision this block exists for. The sigmoid veil
                // it replaced was keyed on (surface Y - floor Y), so a grazing
                // look across shallow water came out perfectly clear - the one
                // case where real water is at its murkiest, since the line of
                // sight through it is long even where the column is thin. One
                // quantity now covers both, and nothing here needs a second
                // depth term. The absorption itself is NOT tuned by eye: see
                // the WCOL block at the top of this file for the published
                // spectrum it is sampled from. V2 per-block transmittance is
                // R 0.671 / G 0.909 / B 0.958 -- the first block reads
                // near-clear with a whisper of teal (R dies first), B survives
                // longest so the distant residue is BLUE, never turquoise.
                // The model itself now lives in waterColumn() above main():
                // GLASS_SEE_THROUGH calls the SAME function for the water a pane
                // hides, so the two views of one lake can never drift apart. The
                // body is unchanged (turbidity detector, per-channel absorption,
                // veil, slate in-scatter, refracted-sun glow), only its locals
                // became parameters.
                color = waterColumn(color, wdepth, tintS, skyl, wShadow, data2.r, worldDir, lightW);

                #ifdef WATER_HORIZON_SKY
                    // SKY FLOOR on the base color: at grazing angles / toward the
                    // horizon, absorption (wdepth is huge when no floor is in
                    // front) crushes the water to black. Blend the base toward a
                    // horizon-sky tint proportionally to distance -> never black.
                    float hzB = hzDistW; // CSE: hoisted at the top of the water block
                    // The floor is NOT a darkened sky copy (a full azure blend is
                    // what turns everything plastic blue wherever Fresnel dips)
                    // but the light coming BACK UP from the water body: sky chroma
                    // halved, then a dark SLATE ocean tint (B above G, aligned
                    // with the reference column palette). Luminance still
                    // follows the sky (sunset -> warm dark base, night -> black).
                    // ORDER MATTERS: this mix acts on the BASE (transmission)
                    // BEFORE the reflection block. At grazing angles the final
                    // pixel is ~97% reflected sky, so this floor never replaces
                    // the mirror -- it only prevents black.
                    // CSE: shared memoized getSkyBase(worldDir, sunW) (see top of main)
                    if (!skyBaseWDok) { skyBaseWD = getSkyBase(worldDir, sunW); skyBaseWDok = true; }
                    // WATER_SKY_TINT site 3 -- the anti-black floor is a SKY
                    // colour landing on a WATER pixel, so it goes through the
                    // same one function as the mirror; left out, far water would
                    // keep an azure floor under a tinted mirror. Written to a
                    // LOCAL: skyBaseWD is the memoized REAL sky shared with the
                    // fogs, the DH haze and the cloud fog, and it must not move.
                    vec3 hzSkyRaw = waterSkyTint(skyBaseWD);
                    // V2 keeps 85% of the sky CHROMA instead of 50%: the old
                    // half-desaturation is what turned a sunset ocean gray.
                    vec3 hzSky = mix(vec3(luma(hzSkyRaw)), hzSkyRaw, WCOL_HZ_CHROMA)
                               * WCOL_HZ_FILT
                               * max(skyl, 0.15) * mix(0.60, 1.0, wShadow);
                    // Strength 0.85 -> 0.62: with the raised distance mirror
                    // (damper 0.95 + hzR) the anti-black duty shifts to the
                    // REFLECTION; the base floor was adding a flat milky
                    // turquoise over 60-150-block water that diluted the mirror.
                    // V2 drops the floor from 0.62 to 0.30: distant water should
                    // be a MIRROR, and a strong base floor was diluting it into a
                    // milky sheet. Anti-black duty stays with the reflection.
                    color = mix(color, hzSky, hzB * WCOL_HZ_STR * WATER_HORIZON_SKY_STRENGTH);
                #endif

                #ifdef WATER_FOAM
                {
                    // ========= EDGE FOAM - organic shoreline foam =========
                    // Uses the VERTICAL column depth (hugs the shore at any view
                    // angle), bounded by wdepth0 so VERTICAL banks keep their
                    // contact line. A uniform band on wdepth0 alone widens at
                    // grazing angles and produces a hard shore-parallel hem.
                    vec3 worldPre = mat3(gbufferModelViewInverse) * vp1pre + cameraPosition;
                    float shoreD = min(max(world0.y - worldPre.y, 0.0), wdepth0);
                    if (shoreD < 1.6 && FOAM_AMOUNT > 0.001) {
                        float tF = frameTimeCounter;
                        // (1) SURGE: the foam line breathes; an fbm spatial phase
                        // makes each stretch of coast advance/retreat at its own
                        // rhythm (never one global synchronous pulse). ~[0.0..0.6].
                        float phase = fbm(world0.xz * 0.14) * 6.2831853;
                        float surge = 0.30 + 0.22 * sin(tF * 0.8 + phase)
                                    + 0.08 * sin(tF * 1.9 + phase * 2.3);
                        // (2) MAIN BAND: IRREGULAR width along the shore (animated
                        // edgeN) that also breathes (surge) -> 0.3..1.2 block of
                        // water column, never a uniform parallel hem.
                        float edgeN = fbm(world0.xz * 0.9 + vec2(tF * 0.05, -tF * 0.04));
                        float band = 1.0 - smoothstep(0.02, 0.30 + surge * (0.5 + 0.9 * edgeN), shoreD);
                        // (3) LACE: multi-octave anti-repetition pattern that PUNCHES
                        // holes in the band (moving holes, threshold breathing with
                        // surge), density modulated by a 2nd frequency -> lace
                        // texture instead of a flat fill.
                        float fScale = mix(1.35, 3.0, clamp(dist / 90.0, 0.0, 1.0));
                        float lace = foamPattern(world0.xz, tF, fScale);
                        float laceHi = fbm(world0.xz * 3.1 + vec2(-tF * 0.06, tF * 0.05));
                        float fmask = smoothstep(0.34 + 0.20 * surge, 0.74, lace + band * 0.30);
                        fmask *= 0.60 + 0.40 * smoothstep(0.30, 0.75, laceHi);
                        float foamB = band * fmask;
                        // (4) CONTACT LINE: dense edging right at the border,
                        // modulated by the lace (not a continuous stroke) -- it is
                        // what DRAWS the shoreline.
                        float contact = 1.0 - smoothstep(0.0, 0.055 + 0.045 * surge, shoreD);
                        contact *= 0.55 + 0.45 * smoothstep(0.22, 0.60, lace);
                        // (5) MICRO-BUBBLES: sparse scatter drifting beyond the band,
                        // dying out with depth (credible residual lace).
                        float bub = vnoise(world0.xz * 7.0 + vec2(tF * 0.12, tF * 0.09));
                        float bubbles = smoothstep(0.80, 0.94, bub)
                                      * (1.0 - smoothstep(0.15, 1.5, shoreD)) * 0.45;
                        float foamA = clamp(foamB + contact * 0.9 + bubbles, 0.0, 1.0);
                        // Distance fade: far away the sub-pixel lace turns into
                        // noise -> soft fade, foam stays suggested without shimmer.
                        foamA *= 1.0 - smoothstep(60.0, 140.0, dist) * 0.65;
                        // Locally lit foam (correct shadow/sun). Weight CLAMPED
                        // <= 0.92: without the clamp the mix extrapolates past 1.0
                        // (out-of-gamut colors); 8% of water stays under the foam
                        // even at FOAM_AMOUNT 8.
                        vec3 foamCol = vec3(0.93, 0.96, 1.0) * localLight * 0.9;
                        color = mix(color, foamCol, clamp(foamA * 0.85 * FOAM_AMOUNT, 0.0, 0.92));
                    }
                }
                #endif
            }

            // --- Reflections: Fresnel + Snell window + SSR + glint ---
            // CSE hoist: ndv on the full wave normal, shared by Schlick here
            // and the SSR geometry weight curve inside the SSR block.
            float ndvW = clamp(dot(normalV, -viewDir), 0.0, 1.0);
            float fres = 0.02 + 0.98 * pow(1.0 - ndvW, 5.0);
            #ifdef UNDERWATER_FX
            if (isEyeInWater == 1) {
                // Physical Snell window: water->air critical angle 48.6 deg,
                // cos ~ 0.661 -> sharp transition (2-3 deg wide in reality)
                float window = smoothstep(0.63, 0.69, worldDir.y);
                // Outside the window (oblique gaze): total internal reflection.
                // Inside the window (looking up): the surface is see-through.
                fres = mix(0.92, fres * 0.22, window);
                // Spectral dispersion at the rim: wavelengths separate slightly
                // at the critical angle -> colored fringe
                float dispEdge = window * (1.0 - window) * 4.0;
                if (dispEdge > 0.02) {
                    vec2 dOff = normalV.xy * dispEdge * 0.006 * TAAU_S; // TAAU: sub-rect offset
                    color.r = mix(color.r, texture2D(colortex0, clamp(ruv + dOff, vec2(0.001), vec2(0.999 * TAAU_S))).r, dispEdge * 0.50);
                    color.b = mix(color.b, texture2D(colortex0, clamp(ruv - dOff, vec2(0.001), vec2(0.999 * TAAU_S))).b, dispEdge * 0.50);
                }
            }
            #endif
            #ifdef SSR_ENABLED
                vec3 rdir2 = reflect(viewDir, normalV);
                float wRough = 0.0;
                #ifdef WATER_ROUGH_REFLECT
                    wRough = WATER_ROUGHNESS * (0.35 + 0.5*clamp(dist/120.0,0.0,1.0) + 0.5*rainStrength);
                #endif
                vec3 tA = normalize(cross(normalV, vec3(0.0,1.0,0.0)) + vec3(1e-4,0.0,0.0));
                vec3 tB = cross(rdir2, tA);
                float blurR = wRough * 0.22;
#if SSR_V3 == 1 && SSR_V3_WATER_RING == 1
                // SSR_V3 (a). MEASURED first cause of the water flicker: this
                // angle carried fract(frameTimeCounter * 0.61), i.e. the SSR ray
                // of every water pixel swept a ring EVERY FRAME. On the 16-frame
                // jitter bench (lib/settings.glsl, SSR_V3 block) that doubled
                // the share of pixels whose reflection changes frame to frame,
                // 11.1 % -> 31.0 %, and raised the total variation of the
                // reflected luminance by 32 %. What it bought is a ring of
                // radius blurR = 0.011 rad = 0.63 deg at the default
                // WATER_ROUGHNESS: invisible as blur, very visible as sparkle.
                // The ring is not removed, it is FROZEN IN TIME: the angle stays
                // fully decorrelated between neighbouring pixels (the static
                // Bayer plus the per-fragment hash12 -- the same pair composite1
                // already uses as its BLUE_NOISE = 0 fallback), so the two-ray
                // average keeps its spatial spread. Same argument the
                // PT_WATER_NORMAL comment makes below: on an animated surface
                // TAA rejects history, so a per-frame direction is never
                // integrated, only re-drawn.
                float angW = fract(dither + hash12(floor(gl_FragCoord.xy))) * 6.2831853;
#else
                float angW = (dither + fract(frameTimeCounter * 0.61)) * 6.2831853;
#endif
                vec3 rdJ = normalize(rdir2 + (tA*cos(angW)+tB*sin(angW))*blurR);
                vec3 rworld = normalize(mat3(gbufferModelViewInverse) * rdJ);
                // ANTI-MOTTLING: a DEDICATED sky-reflection direction, built on a
                // FLATTENED normal (mixed toward the horizontal plane). With the
                // full wave normal, the UV sampled by skyReflect jumps pixel to
                // pixel between "white volumetric cloud" (screen sky pixel) and
                // "blue analytic fallback WITHOUT clouds" (getSkyAll), producing
                // a white-blue reticulated mottling over the whole water plane.
                // Fresnel, glint and SSR geometry KEEP the full normal. flatW
                // limits the flattening to near-horizontal surfaces (waterfalls
                // are untouched).
                vec3 upVN = normalize(mat3(gbufferModelView) * vec3(0.0, 1.0, 0.0));
                float flatW = smoothstep(0.4, 0.8, dot(normalV, upVN));
                vec3 nSky = normalize(mix(normalV, upVN, flatW * (1.0 - WATER_SKY_DISTORT)));
                vec3 rdSkyV = reflect(viewDir, nSky);
                vec3 rdSkyW = normalize(mat3(gbufferModelViewInverse) * rdSkyV);
                // Sky reflection = REAL screen sky pixels (volumetric clouds
                // included) when the direction lands on screen, else getSkyAll.
                // The skyl floor 0.08 (sheltered water is not fully black) lives
                // inside skyReflect.
                vec3 reflSky = skyReflect(viewPos, rdSkyV, rdSkyW, sunW, skyl);
#if SUN_MIRROR_SHADOW == 1
                // ---- THE MIRRORED SUN ----
                // WATER_GLINT_SHADOW masks the surface's OWN GGX lobe further
                // down, and its comment states it touches neither the sky
                // reflection nor the SSR. That is exactly the hole: the sky
                // just fetched carries a SECOND copy of the sun -- getSkyAll
                // adds celestialDisc x25 (x40 under PHYSICAL_SKY), and the
                // colortex0 screen tap skyReflect prefers holds the very same
                // disc the deferred pass painted. So water in the shade of a
                // cliff still showed the sun's mirror image: "on voit le reflet
                // du soleil alors qu'on est a l'ombre".
                // A shaded point cannot see the sun in ANY direction -- the
                // caster sits on that exact line -- so the DISC goes out with
                // the diffuse term, while the diffuse dome (which arrives from
                // everywhere and is only partly blocked) stays untouched: the
                // mask is 1.0 outside the solar cone by construction.
                // wShadow^2 is the same visible-fraction-of-the-disc law
                // glintVis uses, and wShadow is already computed above -- no
                // extra shadow tap. Masked on rdSkyW, the direction this very
                // sky was sampled along.
                reflSky *= vlxSunMirror(rdSkyW, lightW, wShadow * wShadow);
#endif
                vec3 refl = reflSky;
                // CSE hoist: reflSky is final here -- its guarded luma is shared
                // by the 3 dark-hit fades (main SSR, blurred sample, PT water).
                float reflSkyL = max(luma(reflSky), 1e-4);
#if PERF_WATER_SSR_FAR == 1
                // PERF_WATER_SSR_FAR (LOT B, B4a, lib/settings.glsl): distSkyW
                // is HOISTED above the main ray (it only reads dist /
                // isEyeInWater, both ray-independent -- same value as the
                // legacy computation kept below at gate 0) so the ray can be
                // skipped when the geometry->sky fade already dominates.
                float distSkyW = 0.0;
                #ifdef WATER_DIST_SKY_MIX
                    if (isEyeInWater == 0)
                        distSkyW = smoothstep(WATER_DSKY_NEAR, WATER_DSKY_FAR, dist) * WATER_DSKY_STRENGTH;
                #endif
#endif
#if PERF_WATER_SSR_CB == 1
                // C1b (LOT C, lib/settings.glsl): march step of the WATER rays
                // doubled past ~25 blocks (continuous fade 20 -> 30, no seam),
                // eye out only (the TIR ray underwater keeps full precision).
                // Applies to the main ray AND the blurred 2nd ray below; the
                // glint GGX is untouched. Restored after the last water ray.
                if (isEyeInWater == 0) ssrStepMul = 1.0 + smoothstep(20.0, 30.0, dist);
#endif
                float hit;
                #if defined RT_REFLECTIONS && RT_REFLECT_MODE == 3
                // PURE PT: NO screen ray, everything goes through the voxel world (+ sky)
                vec2 hituv = vec2(0.5); hit = 0.0;
                #else
#if PERF_WATER_SSR_FAR == 1
                // B4a: skip the WHOLE main ray (SSR_STEPS + SSR_REFINE) when
                // the sky mix is quasi total -- the SAME 0.85 threshold the
                // 2nd-ray skip below already treats as "already faded". refl
                // stays reflSky; a bright hit (darkH -> 0) is lost there too,
                // accepted and documented (LOT B block: at the default
                // WATER_DSKY_STRENGTH 0.65 this cannot fire; it only acts at
                // the 0.85/1.0 menu notches, beyond ~160/132 blocks).
                // hituv is only read under hit > 0.0, so 0.5 is a dead value.
                vec2 hituv = vec2(0.5);
                if (distSkyW >= 0.85) {
                    hit = 0.0;
                } else {
                    ssrOriN = normalV; // A3: normal-anchored start offset
                    hituv = ssrRay(viewPos, rdJ, dither, hit);
                }
#else
                ssrOriN = normalV; // A3: normal-anchored start offset
                vec2 hituv = ssrRay(viewPos, rdJ, dither, hit);
#endif
                #endif
                #if SSR_EDGE_V2 == 1
                // A4: the border distance of THIS ray in pixels, captured before
                // any other ssrRay call overwrites it. The contrast-widened band
                // is applied once the hit colour is known, a few lines down.
                float edgeMainPx = ssrEdgePx;
                #endif
                #ifdef WATER_HORIZON_SKY
                    // Toward the horizon, grazing SSR only hits dark/shadowed
                    // distant terrain -> fade its confidence toward 0 with
                    // distance so far water reflects the clean analytic sky
                    // instead of a black smear. Above water only (the underwater
                    // branch consumes the raw 'hit').
                    if (isEyeInWater == 0)
                        hit *= 1.0 - hzDistW * (0.35 * WATER_HORIZON_SKY_STRENGTH); // SSR keeps >=65% confidence far away (CSE: hoisted hzDistW)
                #endif
                // Mid-distance BLACK WATER guard: weight of the geometry->sky
                // fade, computed ONCE (reused by the blurred sample below). Zero
                // up close (near SSR stays 100% intact), full at WATER_DSKY_FAR.
                // Never underwater (TIR deliberately consumes a dark reflection).
                // PERF_WATER_SSR_FAR == 1 computes the SAME value above the main
                // ray instead (B4a hoist); this site keeps gate 0 verbatim.
#if PERF_WATER_SSR_FAR == 0
                float distSkyW = 0.0;
                #ifdef WATER_DIST_SKY_MIX
                    if (isEyeInWater == 0)
                        distSkyW = smoothstep(WATER_DSKY_NEAR, WATER_DSKY_FAR, dist) * WATER_DSKY_STRENGTH;
                #endif
#endif
                if (hit > 0.0) {
                    vec3 hitCol = ssrHitColor(hituv);
                    #if SSR_EDGE_V2 == 1
                    // A4: CONTRAST-WIDENED border band, multiplied on top of the
                    // geometric one the ray already carries. The geometric band
                    // exists to hide the depth EXTRAPOLATION past the border and
                    // is deliberately narrow; what makes the border SEAM visible
                    // is something else, the step in luminance between the
                    // reflected content and the pixel it is covering. So the
                    // band is widened in proportion to the Michelson contrast of
                    // that step: 0 when the reflection blends into its
                    // surroundings (no seam to hide, nothing removed), 1 for a
                    // full black-on-white step (band tripled). A ratio, so it is
                    // scale-free on HDR input and needs no clamp against a
                    // specular highlight.
                    if (SSR_EDGE_CTR_PX > 0.0 && edgeMainPx < SSR_EDGE_PX + SSR_EDGE_CTR_PX) {
                        float lHit = luma(hitCol), lSurf = luma(color);
                        float ctrE = abs(lHit - lSurf) / (lHit + lSurf + 1e-4);
                        hit *= ssrEdgeFade(edgeMainPx, SSR_EDGE_PX + SSR_EDGE_CTR_PX * clamp(ctrE, 0.0, 1.0));
                    }
                    #endif
                    // Physics: choppy water seen from FAR reflects mostly sky
                    // (micro-facets). So an SSR hit DARKER than the sky (terrain
                    // or trees ahead -- the cause of the near-black ocean band at
                    // 40-120 blocks, where the (1-hit) weighted sky floor is
                    // inactive) fades toward reflSky with distance. Hits BRIGHTER
                    // than the sky (sun on a wall, a white sail) stay intact
                    // (darkH -> 0). Do not replace this with a full-sky max():
                    // that washes out near reflections.
                    float darkH = 1.0 - smoothstep(0.35, 1.0, luma(hitCol) / reflSkyL); // CSE: hoisted reflSkyL
                    hitCol = mix(hitCol, reflSky, distSkyW * darkH);
                    refl = mix(refl, hitCol, hit);
                }
                // The 2nd ray (48 steps) is skipped when its contribution is
                // already faded toward the sky (distSkyW >= 0.85) or when the 1st
                // ray missed AND the sky fade dominates (> 0.5).
#if PERF_WATER_SSR_FAR == 1
                // B4b: ignition raised 0.01 -> 0.015 and the sky-fade cutoff
                // lowered 0.85 -> 0.5. At the default WATER_ROUGHNESS 0.05 the
                // 2nd ray only ever lit in rain (blurR 0.0149 at dist >= 120)
                // where it weighed ~10% of a reflection already half-faded to
                // sky -- it now stays off at that default; menu roughness
                // 0.08+ keeps it, minus the > ~125-block band the 0.5 cutoff
                // removes (WATER_DSKY_STRENGTH 0.65 * smoothstep = 0.5 there).
                // The legacy !(hit <= 0 && distSkyW > 0.5) clause is subsumed
                // by distSkyW < 0.5. Numbers: LOT B block, lib/settings.glsl.
                if (blurR > 0.015 && distSkyW < 0.5) {
#else
                if (blurR > 0.01 && distSkyW < 0.85 && !(hit <= 0.0 && distSkyW > 0.5)) {
#endif
                    vec3 rdJ2 = normalize(rdir2 + (tA*cos(angW+2.094)+tB*sin(angW+2.094))*blurR);
                    #if defined RT_REFLECTIONS && RT_REFLECT_MODE == 3
                    float hit2 = 0.0; vec2 huv2 = vec2(0.5); // pure PT: no screen ray
                    #else
                    ssrOriN = normalV; // A3: normal-anchored start offset
                    float hit2; vec2 huv2 = ssrRay(viewPos, rdJ2, fract(dither+0.5), hit2);
                    #endif
                    #if SSR_EDGE_V2 == 1
                    float edge2Px = ssrEdgePx; // A4: border distance of the blurred ray
                    #endif
                    // Same SMOOTH sky reflection for the blurred sample (blur only
                    // applies to SSR geometry) -> no mottling reintroduced by rdJ2.
                    vec3 r2 = reflSky;
                    if (hit2 > 0.0) {
                        vec3 hitCol2 = ssrHitColor(huv2);
                        #if SSR_EDGE_V2 == 1
                        // A4: the SAME contrast band as the main sample. Without
                        // it the two samples that get blended together fade by
                        // different laws at the border, which puts back exactly
                        // the seam this gate exists to remove -- and it does so
                        // under rain, where the roughness makes this second ray
                        // active and the water is most visible.
                        if (SSR_EDGE_CTR_PX > 0.0 && edge2Px < SSR_EDGE_PX + SSR_EDGE_CTR_PX) {
                            float lHit2 = luma(hitCol2), lSurf2 = luma(color);
                            float ctr2 = abs(lHit2 - lSurf2) / (lHit2 + lSurf2 + 1e-4);
                            hit2 *= ssrEdgeFade(edge2Px, SSR_EDGE_PX + SSR_EDGE_CTR_PX * clamp(ctr2, 0.0, 1.0));
                        }
                        #endif
                        // Same distance->sky fade as the main sample, otherwise the
                        // blurred sample reintroduces black at distance.
                        float darkH2 = 1.0 - smoothstep(0.35, 1.0, luma(hitCol2) / reflSkyL); // CSE: hoisted reflSkyL
                        hitCol2 = mix(hitCol2, reflSky, distSkyW * darkH2);
                        r2 = mix(r2, hitCol2, hit2);
                    }
                    refl = mix(refl, 0.5*(refl+r2), clamp(wRough*3.0,0.0,1.0));
                }
#if PERF_WATER_SSR_CB == 1
                // C1b: restore after the last water ray (same contract as the
                // PERF_SSR_ROUGH caps: never leave a march modifier armed).
                ssrStepMul = 1.0;
#endif
                #if RT_REFLECT_MODE >= 2 && PT_REFLECT_WATER == 1
                // PT WATER: the screen ray hit nothing -> continue into the VOXEL
                // world (banks/trees BEHIND the camera, hidden geometry). Treated
                // as a real hit so everything downstream (hit weights, horizon
                // floors) weighs it like real geometry.
                // COHERENCE: the water voxel ray starts along the FLATTENED normal
                // (rdSkyW, same as the sky reflection) and WITHOUT jitter. A choppy
                // normal plus per-pixel jitter sends every pixel into a different
                // voxel each frame, and TAA cannot smooth that on an animated
                // surface (history is rejected). Static metal accumulates fine.
                // Start lifted by +0.35: never self-hits the submerged terrain.
                // A PARTIAL hit (screen edge) is completed pro rata (1-hit) instead
                // of letting the reflection fade to sky.
                if (isEyeInWater == 0 && hit < 0.9 && rdSkyW.y > 0.02) {
                    // PT_WATER_NORMAL: how much the WAVES steer the off-screen ray
                    // -- 0 = flattened normal (stable), 1 = full normal (maximum
                    // distortion). Block DDA keeps hits stable, so a moderate
                    // dose does not shimmer.
                    vec3 rdPT = normalize(mix(rdSkyW, rworld, PT_WATER_NORMAL));
                    if (rdPT.y < 0.02) rdPT = rdSkyW;
                    vec3 vHitW; vec3 fNW;
                    vec3 ptOriW = (world0 - cameraPosition) + vec3(0.0, 0.35, 0.0) + rdPT * max(VOXEL_SCALE, 0.3);
                    vec4 voxW = marchVoxelPT(ptOriW, rdPT, PT_REFLECT_STEPS, PT_REFLECT_DISTANCE, vHitW, fNW);
                    if (voxW.a > 0.5) {
                        vec3 ptCol = ptHitColor(voxW, vHitW, fNW);
                        // RANGE fade over the ray's TRAVEL distance -- must not use
                        // the camera->hit distance, which kills reflections of
                        // distant surfaces.
                        float fadeW = clamp((length(vHitW - ptOriW) - PT_REFLECT_DISTANCE * 0.55)
                                            / max(PT_REFLECT_DISTANCE * 0.45, 1.0), 0.0, 1.0);
                        float darkV = 1.0 - smoothstep(0.35, 1.0, luma(ptCol) / reflSkyL); // CSE: hoisted reflSkyL
                        ptCol = mix(ptCol, reflSky, max(distSkyW * darkV, fadeW));
                        refl = mix(refl, ptCol, 0.65 * (1.0 - hit));
                        hit = max(hit, 0.5);
                    }
                }
                #endif
                #ifdef UNDERWATER_FX
                if (isEyeInWater == 1 && hit < 0.5) {
                    // Total internal reflection: fallback is deep water, not sky
                    float windowFB = smoothstep(0.63, 0.69, worldDir.y);
                    if (windowFB < 0.8) {
                        float camD = clamp((WATER_LEVEL - cameraPosition.y) / 10.0, 0.0, 1.0);
                        // TIR reflects the light coming BACK UP from the water
                        // body: dark desaturated turquoise (G ~= B, same family as
                        // shallowC in the UW fog). A saturated azure here makes the
                        // distant surface look synthetic.
                        vec3 uwFB = mix(vlxWaterUWc(WCOL_UW_SHALLOW), vlxWaterUWc(WCOL_UW_TIR), camD * camD)
                                  * (gAmbC * 0.35 + gLightC * 0.05 * skyl);
                        refl = mix(uwFB, refl, windowFB + hit * (1.0 - windowFB));
                    }
                }
                #endif
                // CSE hoist: 'hit' is final past this point -- clamp it once for
                // the geometry weight, the sky floor, the grazing raise and the
                // debug view below.
                float hitC = clamp(hit, 0.0, 1.0);
                // PHYSICAL FRESNEL: pure Schlick (water F0 0.02, exponent 5 --
                // 'fres' computed above). No perceptual floor here: seen from
                // ABOVE (ndv -> 1) it stays ~2-3% so you see INTO the water, and
                // at GRAZING angles Schlick climbs to ~1 on its own. The residual
                // sheen under a bright sky is carried by WATER_REFLECT_FLOOR a few
                // lines below. Cap 0.98 leaves 2% of base water so the swell stays
                // readable. The final application is a mix() -> ENERGY CONSERVING
                // (the floor/scatter dims as the reflection rises, never additive).
                // Underwater, fres carries the TIR value (0.92).
                // (ndvW hoisted next to 'fres' above -- CSE, same expression.)
                // GRAZING MIRROR: Schlick evaluated on the WAVE normal caps out
                // around 0.15-0.30 at grazing angles, because a swell facet always
                // partly faces the viewer (ndv stays ~0.3-0.5) -- you see the dull
                // base instead of the sunset sky. So the FRESNEL TERM is
                // re-evaluated on a normal pulled back toward the geometric water
                // plane (upVN) as the VIEW (ndvGeo, the PLANE angle, not the facet
                // angle) becomes grazing. Refraction, glint, TIR and SSR geometry
                // KEEP the full normal (original 'fres' untouched); flatW limits
                // the fix to near-horizontal surfaces (waterfalls intact); grazeW
                // is forced to 0 underwater so the TIR / Snell window path is
                // preserved.
                float ndvGeo = clamp(dot(upVN, -viewDir), 0.0, 1.0);
                float grazeW = (isEyeInWater == 0) ? pow(1.0 - ndvGeo, 2.6) * flatW : 0.0;
                vec3 nFres = normalize(mix(normalV, upVN, grazeW));
                float fresG = 0.02 + 0.98 * pow(1.0 - clamp(dot(nFres, -viewDir), 0.0, 1.0), 5.0);
                // max(): looking down grazeW -> 0 so fresG == fres (exact
                // continuity); underwater fresP == fres (TIR intact). Name kept
                // because debug view 24 displays it.
                float fresP = (isEyeInWater == 0) ? max(fres, fresG) : fres;
                // The artistic damper (which stops the reflection looking the
                // same everywhere at mid angles) FADES to 1.0 at grazing angles.
                // Raised 0.86 -> 0.95: the missing MID-ANGLE mirror was the real
                // complaint -- the diffuse blue is handled by the fog/floor fixes
                // elsewhere, not by crushing the Fresnel term.
                // Reference numbers (WATER_REFLECTIVITY 1.5):
                //   ndvGeo 0.05 -> grazeW ~0.86, fresG ~0.78 -> reflW hits the
                //   0.98 cap: the pixel is ~98% REFLECTED sky + ~2% base.
                //   ndvGeo 0.20 -> fresG ~0.34 -> reflW ~0.50 (real Fresnel at
                //   ~78 deg is ~0.33; the x1.5 slider carries the rest). No
                //   downstream clamp bites and the final mix conserves energy.
                // CONFIG: WATER_MIRROR_ANGLE scales the 0.95 MID-ANGLE damper
                // only (the grazing end still blends to 1.0 -> horizon intact).
                // EAU5 -- WT_MIRROR. THE measurement of this pass: this weight,
                // and not any water constant, is what the eye reads as "the
                // colour of the water" past a few blocks. Share of the FINAL
                // linear pixel taken by the reflected sky, sand floor 3 blocks
                // down, eye 1.8 above, noon: 1.1% at 2 blocks, 16.9% at 5,
                // 74.5% at 10, 97.9% at 20, 99.4% at 60. Over open water with no
                // floor in view: 15.3 / 42.7 / 75.4 / 96.7 / 98.8%. That is why
                // four successive re-derivations of the column chroma could all
                // be right and all be invisible PAST ~8 BLOCKS -- and, EAU7,
                // why the mirror is NOT the lever below that: the first two
                // columns used to read 7.1% and 30.9% here, recomputed from this
                // site's own geometry (ndvGeo = 1.8/L, path = 3/ndvGeo, the real
                // fresP x damper x WATER_REFLECTIVITY x floor expression) they
                // are 1.1% and 16.9%. The far half of the table stands to within
                // 2-4 points; the NEAR half did not, and that overestimate is
                // what made the mirror look like it decided the shallow-water
                // pixel when it decides 0.5-2.0% of it. What decides it is the
                // chroma of the carrier the floor travels through -- see the
                // EAU7 block in lib/settings.glsl and the end of waterColumn().
                // WT_MIRROR (lib/settings.glsl)
                // lets the WATER_TINT palier move this weight too -- 1.0 at
                // palier 2 (x1.0 is neutral in IEEE: the shipped look is
                // bit-identical), 0.80 / 0.90 / 0.85 on the greener paliers.
                // Delivered hue over sand at 20 blocks: 204.9 deg at palier 2,
                // 197.0 deg at palier 0, for -2.5% of LDR luminance. The two
                // OTHER max() clauses below are deliberately NOT scaled: the
                // SSR geometry clause reflects banks and trees (not blue sky),
                // and the WATER_HORIZON_SKY raise is the anti-black floor -- far
                // water keeps its full mirror and still cannot go black.
                // RANGE OF THE FACTOR -- ASSUMED LIMIT. The 0.98 clamp on the
                // very next line bites from L ~ 22 blocks at palier 2 and L ~ 45
                // at palier 0, so past ~45 blocks reflW = 0.9800 at BOTH paliers,
                // bit-identical, and WT_MIRROR is INERT there. Delivered-hue
                // delta palier 2 -> palier 0: 7.5 deg at 20 blocks, 3.3 at 30,
                // 0.64 at 45, 0.57 at 60, 0.63 at 120. The share table's 60/120
                // columns are therefore out of this control's reach; a real far
                // lever would need clamp(..., 0.0, 0.98 * WT_MIRROR) or the
                // WATER_HORIZON_SKY hzR clause, both of which trade the
                // anti-black guarantee for hue. Not shipped, see the EAU5 block.
                // The WATER_REFLECT_FLOOR raise further down is likewise NOT
                // scaled. (EAU7 correction: it is NOT what sets reflW in the near
                // field. At ndvGeo 0.9 -- the 2-block case of the table above --
                // the floor is 0.06 * mix(1.0, 0.30, 1.0) = 0.018 and Fresnel
                // gives 0.0285, so FRESNEL wins there. The old note claiming
                // "reflW 0.045 at 2 blocks, set by the floor and not by Fresnel"
                // was wrong on both halves.)
                // SECOND-ORDER REACH, STATED SO IT IS NOT A SURPRISE: reflW is
                // also the source of wMirror (wMirror = reflW * flatW, a few
                // lines below), and wMirror is the mirror-relief weight of FOUR
                // other sites -- the ATMO_FOG relief, the submerged VL step
                // density uw*0.008*(1-wMirror*0.85), the HEIGHT_FOG analytic
                // tail, and the VL-apply fogKeepW. So WATER_TINT moves the three
                // AIR VEILS over the water too, not just the mirror weight.
                // Sign and size at 20 blocks, palier 2 -> palier 0: wMirror
                // 0.9389 -> 0.7511, so fogKeepW 0.4836 -> 0.5869, i.e. +1.4
                // point of sky-blue veil that gives back ~0.2 deg of the 7.5 deg
                // of rotation. Real, measured, and negligible -- but it is why
                // the delivered hue moves slightly less than the medium does.
                float reflW = clamp(fresP * mix(0.95 * WATER_MIRROR_ANGLE, 1.0, grazeW) * (WATER_REFLECTIVITY * WT_MIRROR), 0.0, 0.98); // mirror boost (clearer water pairs with stronger reflections)
                // A strong SSR hit means real reflected geometry (banks, trees),
                // weighted by (a) hit confidence (smooth transition to the sky
                // fallback, no hard patch), (b) a FRESNEL-CONSISTENT angle curve
                // pow(1-ndv, 1.3) -- still near zero looking down (~5% at ndv
                // 0.9: water stays see-through), but geometry now keeps STRONG
                // weight at mid angles (~24% at ndv 0.64, vs ~16% at the old
                // 1.7): a mirror is SEEN by its details, and the SSR hit is the
                // only high-frequency reflection content available (the sky
                // fallback is a featureless gradient off screen); a much softer
                // exponent still reads "same reflection everywhere" -- keep the
                // looking-down guard, (c) WATER_REFLECTIVITY
                // capped at 0.92 (reflected geometry is never a full mirror).
                // NEVER underwater (TIR deliberately consumes a dark reflection).
                if (isEyeInWater == 0)
                    reflW = max(reflW, hitC // CSE: hoisted clamp(hit)
                                     * clamp(0.70 * WATER_REFLECTIVITY, 0.0, 0.92)
                                     * pow(1.0 - ndvW, 1.3));
                // Reflection floor at normal incidence, MODULATED by sky light
                // (sheltered/forest water stays dark); NEVER underwater (TIR
                // deliberately consumes a dark reflection). 0.0 disables it.
                // VIEW-ANGLE GATE: looking straight DOWN (ndvGeo -> 1) the floor
                // collapses to 30% of itself. At vertical incidence the reflected
                // content is the featureless analytic zenith (never on screen),
                // and its permanent 6% azure film over shallow floors was a main
                // "not transparent up close" term. Mid angles keep the sheen.
                if (isEyeInWater == 0)
                    reflW = max(reflW, WATER_REFLECT_FLOOR * smoothstep(0.4, 0.9, skyl)
                                     * mix(1.0, 0.30, smoothstep(0.55, 0.85, ndvGeo)));
                #ifdef WATER_HORIZON_SKY
                  // Above water only: underwater 'refl' carries the deliberately
                  // DARK total internal reflection, so it must not be floored.
                  if (isEyeInWater == 0) {
                    // (a) the reflection can no longer be darker than the pure sky:
                    //     kills residual dark SSR hits at the horizon. The floor is
                    //     only 30% of a DESATURATED (60% toward luma) sky -- at
                    //     100% the max() would crush EVERY geometry reflection
                    //     darker than the sky, and a SATURATED floor is worse
                    //     still: max() is PER CHANNEL, so a full-blue sky floor
                    //     lifted B alone inside dark geometry reflections (the
                    //     diffuse azure film read as "blue water", never as a
                    //     mirror). A neutral silver floor keeps the anti-black
                    //     job without recoloring. It is WEIGHTED by SSR
                    //     confidence, SQUARED (1-hit)^2: a confident hit erases
                    //     the floor fast, a miss keeps it. At the horizon hit is
                    //     already faded (WATER_HORIZON_DIST), so the anti-black
                    //     floor is fully active exactly where it is needed.
                    refl = max(refl, mix(reflSky, vec3(reflSkyL), 0.60) * (0.30 * WATER_HORIZON_SKY_STRENGTH) * pow(1.0 - hitC, 2.0)); // CSE: hoisted clamp(hit) + reflSkyL
                    // (b) at grazing angles / at distance, a Fresnel dip on a wave
                    //     face lets the black base water through -> RAISE the
                    //     reflection weight toward the sky with distance (distant
                    //     water is a sky mirror, physically correct at grazing
                    //     incidence). Cap 0.98 leaves 2% base so the swell stays
                    //     readable; full cap is reached from WATER_REFLECTIVITY
                    //     ~1.22 upward.
                    float hzR = hzDistW; // CSE: hoisted at the top of the water block
                    // Faded by SSR confidence: with a confident geometry hit the
                    // pixel keeps its physical Fresnel weight and its geometry
                    // content instead of being boosted into a sky-heavy wash --
                    // open horizon (hit ~0) keeps the FULL sunset mirror.
                    reflW = max(reflW, hzR * clamp(0.80 * WATER_REFLECTIVITY, 0.0, 0.98) * WATER_HORIZON_SKY_STRENGTH
                                     * (1.0 - 0.5 * hitC)); // CSE: hoisted clamp(hit)
                  }
                #endif
                // REFLECT_DESAT: slightly desaturates the FINAL reflection (SSR +
                // sky + horizon floor combined) toward its luma -> less "candy
                // blue" water, a more silvery photographic mirror. Gated by
                // MULTIPLICATION (never a #if on a float); NEVER underwater (TIR
                // carries a deliberate dark tint). The desaturation FADES OUT at
                // grazing angles (grazeW) so the sunset horizon mirror keeps its
                // gold/red chroma. 0.0 disables it entirely.
                if (isEyeInWater == 0)
                    refl = mix(refl, vec3(luma(refl)), clamp(REFLECT_DESAT, 0.0, 1.0) * (1.0 - grazeW));
                // Export the mirror dominance to the volumetric light (see the
                // submerged-step weighting near the end of main()) AND to the
                // air-veil reliefs (ATMO_FOG, height-fog tail, VL apply: same
                // wMirror contract, keep all sites in sync). flatW limits
                // it to near-horizontal water planes (a waterfall really is a
                // water column); NEVER underwater (TIR and the UW fog keep full
                // extinction). Without this export, the "~97% reflected sky"
                // result above is undone by the volumetric march (azure veil +
                // extinction). MUST stay in sync with that VL density term.
                if (isEyeInWater == 0) wMirror = reflW * flatW;
                #if SSR_FALLBACK_V2 == 1
                // A2 on the water branch. skyReflect already floors skylight at
                // 0.08, so this only bites where there is NO sky at all: water in
                // a cave, and the End / Nether pools. NEVER underwater -- the TIR
                // fallback is deliberately dark and must not be floored.
                if (isEyeInWater == 0) {
                    refl = max(refl, ssrLocalAmb(color) * (1.0 - hitC));
                    // CONFIDENCE-WEIGHTED, like the ambient floor on the line
                    // above: the clause protects a GUESS from darkening the
                    // pixel, so it must vanish where the ray actually hit
                    // something. Unweighted it would forbid every confident
                    // reflection darker than 40% of the surface.
                    color = mix(color, max(refl, color * (ssrNoDark(skyl) * (1.0 - hitC))),
                                clamp(reflW, 0.0, 1.0));
                } else
                #endif
                color = mix(color, refl, clamp(reflW, 0.0, 1.0));
                #if DEBUG_VIEW == 23
                    // View 23: FINAL water reflection (SSR + sky + TIR), LDR clamped.
                    aux5 = vec4(clamp(refl, 0.0, 1.0), 1.0);
                #elif DEBUG_VIEW == 24
                    // View 24: R = SSR confidence (hit), G = reflection weight
                    // (reflW), B = pure Schlick Fresnel (fresP, the base of reflW).
                    aux5 = vec4(hitC, clamp(reflW, 0.0, 1.0), clamp(fresP, 0.0, 1.0), 1.0);
                #endif
            #endif
            vec3 L = normalize(shadowLightPosition);
            vec3 H = normalize(L - viewDir);
            // Glint shadow mask: no direct sun on the surface (cliff, building)
            // means no sun reflection. wShadow is the PCSS penumbra (luma [0..1],
            // fail-open at distance), so the sun spot fades out inside the
            // penumbra instead of cutting hard. Applied to the GGX glint and
            // the sparkle -- NEVER to the sky/SSR reflection.
            float glintVis = 1.0;
            #if WATER_GLINT_SHADOW == 1
                // wShadow^2, not linear: the specular follows the VISIBLE fraction
                // of the solar disc, so at half penumbra the glint drops to 25%
                // instead of 50% -- clean extinction inside the shadow, soft fade
                // kept at the edge. wShadow is already computed above (no extra tap).
                glintVis = wShadow * wShadow;
            #endif
            // --- Sun glint: SINGLE tight GGX lobe (reference-style model,
            // rewritten from scratch). The sparkle FIELD comes from the
            // per-pixel wave normals themselves -- each wavelet facing the
            // half vector fires its own pin-point -- while the BRDF lobe
            // stays micro-tight. The old 2-lobe Blinn pair and the wide sun
            // trail (the painted white blob) are REMOVED; bloom is what
            // flowers around the surviving HDR points.
            float ndhSun = clamp(dot(normalV, H), 0.0, 1.0);
            float ndlSun = clamp(dot(normalV, L), 0.0, 1.0);
            float ldhSun = clamp(dot(L, H), 0.0, 1.0);
            float distGl = clamp(dist / 160.0, 0.0, 1.0);
            float glintSky = smoothstep(0.7, 0.95, data2.g);
            // GGX alpha 0.006 near -> 0.016 far: sub-pixel wavelets resolve
            // into a stable narrow sun path under TAAU instead of fireflies.
            float aGl = mix(0.006, 0.016, distGl) * WATER_GLINT_SIZE; // CONFIG: lobe size dial
#if SSR_V3 == 1 && WAVE_LOD == 1 && WAVES_V3 == 1
            // SSR_V3 (e). TOKSVIG/LEAN TERM, DERIVED AND MEASURED (the numbers
            // and the per-rung table live at the SSR_V3 block of
            // lib/settings.glsl). WAVE_LOD drops the wave rungs whose crest
            // pitch has fallen under WAVE_LOD_K pixel footprints; because a
            // rung's SLOPE goes as its Pierson-Moskowitz factor alone (the
            // amplitude goes as lambda and the slope as amplitude/lambda, so
            // lambda cancels), those fine rungs carry MOST of the slope
            // variance: 20.8 % of it goes at the first cut, 40.8 % at the
            // second. The variance is dropped from the NORMAL and nothing puts
            // it back into the BRDF, so every far pixel keeps evaluating a
            // 0.5-deg lobe against a normal that no longer represents its own
            // footprint -- one facet in N lands on the sun, spikes to the knee
            // and drops out again next frame. That is the far-water sparkle.
            // Putting it back is the standard NDF convolution alpha'^2 =
            // alpha^2 + 2*sigma_slope^2. The variance increment per dropped
            // rung is near constant (measured 0.001789 / 0.001727 / 0.001639 /
            // 0.001325), so the count of dropped rungs -- log2(dist / first
            // cut) -- enters LINEARLY, and using the CONTINUOUS count instead
            // of WAVE_LOD's integer one also removes the ring that the integer
            // step would print on the sea. Exactly zero below the first cut
            // (95.6 blocks at the defaults): near and mid water is untouched.
            // The guard is not cosmetic: sqrt(a*a) is only correctly rounded to
            // within an ulp, so applying the formula unconditionally would
            // perturb EVERY near-water pixel by a rounding step for nothing.
            // With it, below the first cut the lobe is bit-identical.
            float aGlV = (2.0 * SSR_V3_GLINT_VAR * SSR_V3_GLINT_V1)
                       * clamp(log2(max(dist, 1.0) / SSR_V3_GLINT_D0), 0.0, 3.62);
            if (aGlV > 0.0) aGl = sqrt(aGl * aGl + aGlV);
#endif
            float aGl2 = aGl * aGl;
            float dDen = ndhSun * ndhSun * (aGl2 - 1.0) + 1.0;
            float specD = aGl2 / (3.14159265 * dDen * dDen);
            // Schlick fresnel on the sun lobe (water F0 0.02): the glint dims
            // looking straight down, climbs at grazing angles -- replaces the
            // old external *fres factor.
            float fEg = 1.0 - ldhSun;
            float fEg2 = fEg * fEg;
            float specF = 0.02 + 0.98 * fEg2 * fEg2 * fEg;
            // Schlick-Smith visibility, k = alpha/2 (floored denominator)
            float kGl = aGl * 0.5;
            float specV = ndlSun / max((ndlSun * (1.0 - kGl) + kGl)
                                     * (ndvW  * (1.0 - kGl) + kGl), 1e-3);
            // HDR clamp: the brightest facet stays a bloomable point, never a
            // white sheet (raw GGX peaks in the thousands at this alpha).
            // WCOL_V3 -- WHY THE STREAK WAS SMOOTH, MEASURED. The lobe itself is
            // not too wide: alpha 0.00663 at 10 blocks / 0.00725 at 20 is a
            // half-width of 0.451 / 0.494 deg, i.e. under twice the sun's own
            // 0.265 deg angular radius, so the BRDF is not the problem and the
            // wave field is not over-smoothed at a top-down view (wave3NormalWorld
            // attenuates on the VIEW angle, att = 0.967 at |vdirW.y| = 0.7).
            // The problem is this line: with specF * specV ~ 0.03 the raw value
            // peaks at 218 (10 blk) / 182 (20 blk), so min(.., 40) fires out to a
            // half-angle of 0.580 / 0.606 deg -- WIDER than the lobe's own
            // half-width. Every facet within the visible core of every sparkle
            // therefore returned the SAME radiance 40: a flat-topped top-hat, no
            // per-grain intensity variation left, and bloom welds the identical
            // dots into one continuous painted trail.
            // The fix is a SOFT knee with the same ceiling: strictly monotonic,
            // so two facets 0.1 deg and 0.5 deg off specular no longer land on
            // the same number (raw 265 -> 34.8, raw 40 -> 20.0, raw 10 -> 8.0),
            // and the brightest grain sits slightly BELOW the old ceiling
            // instead of on it, so this cannot add fireflies -- provably, not
            // by inspection: K*x/(K+x) < min(x, K) for every x > 0, so the soft
            // knee is everywhere at or under the old clip. Cap on
            // WATER_GLINT_KNEE.
            // HOW MUCH CONTRAST IT ACTUALLY RESTORES, corrected. An earlier
            // revision claimed "4.3x where V2 had 1.0x" by taking the pair
            // (raw 265, raw 10) -- but raw 10 was never clamped, V2 returned it
            // untouched, so V2's contrast for that pair was 4.0x and V3's is
            // 4.34x. The pairs V2 GENUINELY flattened are the ones with
            // raw >= 40, all of which it returned as exactly 40, and over those
            // the true figure is peak / 40-level: 33.80/20.0 = 1.69x at this
            // file's own measured 10-block peak of 218, 34.75/20.0 = 1.74x at
            // the raw 265 example. 1.69x of structure inside the visible core
            // of every sparkle against a perfectly flat top is still the whole
            // point -- the mechanism and the direction were right, the headline
            // number was about 2.5x too large.
#if WCOL_V3 == 1
            float specRaw = specD * specF * specV;
            float specSun = WATER_GLINT_KNEE * specRaw / (WATER_GLINT_KNEE + specRaw);
#else
            float specSun = min(specD * specF * specV, 40.0);
#endif
            // Seen from below, the old glint was damped by the Snell-window
            // fresnel; keep an equivalent damp (validated UW ambiance).
            if (isEyeInWater == 1) specSun *= 0.3;
#if SSR_V3 == 1
            // SSR_V3 (e). ABSOLUTE PER-PIXEL CEILING on the glint, the one the
            // knee above does NOT provide: WATER_GLINT_KNEE caps specSun, but
            // what lands in the framebuffer is specSun x gLightC x
            // WATER_SUN_GLINT, and none of those three is bounded. At the
            // shipped defaults the term peaks at 33.8 x 6.9 = 233 in HDR luma,
            // which is three times under the knee below, so this block is
            // INERT and the pixel is bit-identical; the menu however allows
            // KNEE 140 x GLINT 12 x SUN_INTENSITY 20, i.e. ~1.5e5 on a single
            // pixel feeding the bloom. Soft knee starting at 40 % of the
            // ceiling, so the cap is monotonic and asymptotic (never a clip
            // plateau -- the same argument the WCOL_V3 knee makes above) and
            // the chroma is preserved (one scalar on the vec3).
            vec3 glintAdd = gLightC * specSun * WATER_SUN_GLINT
                          * glintSky * glintVis * (1.0 - rainStrength * 0.7);
            float glintL = luma(glintAdd);
            float glintT = SSR_V3_GLINT_CEIL * 0.4;
            if (glintL > glintT) {
                float glintC = SSR_V3_GLINT_CEIL - glintT;
                float glintE = glintL - glintT;
                glintAdd *= (glintT + glintC * glintE / (glintE + glintC)) / glintL;
            }
            color += glintAdd;
#else
            color += gLightC * specSun * WATER_SUN_GLINT
                   * glintSky * glintVis * (1.0 - rainStrength * 0.7);
#endif
            #ifdef WATER_SPARKLE
                // Optional extra glitter: noise-gated micro-facets, tightened
                // (pow 64) so they hug the GGX sun path instead of dusting the
                // whole swell.
                float sparkN = vnoise(world0.xz * 2.2 + frameTimeCounter * 0.8);
                float spark = smoothstep(0.70, 0.92, sparkN) * pow(ndhSun, 64.0)
                            * WATER_SPARKLE_AMOUNT;
                color += gLightC * spark
                       * glintSky * (1.0 - rainStrength) * glintVis;
            #endif

            // Whitecaps on the highest crests (more of them in wind/rain)
            #ifdef WHITECAPS
            {
                // Gates BEFORE the expensive work: capDist zeroes everything below
                // WHITECAP_NEAR_FADE (the pixel-densest area) and the crest
                // threshold is zero over most of the surface, so waveHeight
                // (10 seaOctave) and foamPattern (~25 vnoise) are rarely paid.
                float capDist = smoothstep(WHITECAP_NEAR_FADE, WHITECAP_NEAR_FADE * 2.6, dist);
                if (capDist > 0.003) {
                #if WAVES_V3 == 1
                // Same sheet the normal is built from, remapped into the v2
                // numeric range so this gate (1.02) keeps its meaning: MEASURED
                // 4.4% of the surface above it against v2's 6.2%.
                float hCrest = wave3Height(world0, frameTimeCounter);
                #else
                float hCrest = waveHeight(world0.xz, frameTimeCounter);
                #endif
#if VLX_PHYS_SYNC == 1
                // PHYSICS_FIELD_SYNC : sur un pixel d'ocean du mod, la crete lue
                // devient LA SIENNE, remappee dans la meme plage numerique (v2)
                // pour que la porte 1.02 et le curseur FOAM_AMOUNT gardent leur
                // sens. Sans cela l'ecume du pack se posait sur les cretes d'un
                // AUTRE champ, donc regulierement dans les creux visibles.
                // MESURE (pf_m4_mask.py) : la porte 1.02 laisse passer 6.37 % de
                // la surface sur le champ du mod contre 3.93 % sur wave3 - dans
                // la plage que le pack a deja livree (v2 en donnait 6.2 %).
                // L'ecume PROPRE du mod (physics_wavePixel, ajoutee dans
                // lib/program_water_fragment.glsl) reste dessous : les deux
                // couches se posent desormais sur les MEMES cretes, ce qui est
                // exactement le but.
                if (vlxPhysPix) {
                    VLX_PHYS_SET(true, vlxPhysPixWav, 0.0);
#if VLX_PHYS_REAL == 1
                    // PHYS_REAL : la crete lue est celle du mod A SON AMPLITUDE
                    // REELLE. vlxPhysHeightU rend la hauteur PAR UNITE de
                    // (oceanHeight x waviness) : le remappage v2 etait donc
                    // amplitude-INVARIANT et laissait de l'ecume du pack sur une
                    // mer PLATE - une des trois plaintes du createur. Le facteur
                    // A2 = amplitude reelle / 2 (2 = le point de calibration, ou
                    // le remappage redevient celui d'avant) la rend
                    // proportionnelle. MESURE (pr_m4.py B) : 4.5 % de la surface
                    // au-dessus de la porte 1.02 a amplitude 2, 0.00 % a
                    // amplitude 1 et a amplitude 0.
                    float hA2 = (vlxPhysAmp * vlxPhysPixWav) * 0.5;
                    hCrest = W3_V2_MEAN + (W3_V2_STD * hA2)
                           * (vlxPhysHeightU(world0.xz) - VLX_PF_HMEAN) * (1.0 / VLX_PF_HSTD);
#else
                    hCrest = W3_V2_MEAN + W3_V2_STD
                           * (vlxPhysHeightU(world0.xz) - VLX_PF_HMEAN) * (1.0 / VLX_PF_HSTD);
#endif
                    VLX_PHYS_SET(false, 0.0, 0.0); // hygiene : chaque site rearme
                }
#endif
                float capThresh = 1.02 - rainStrength * 0.20;
                float cap = smoothstep(capThresh, capThresh + 0.25, hCrest);
                if (cap > 0.002) {
                float capScale = mix(1.1, 2.4, clamp(dist / 120.0, 0.0, 1.0));
                cap *= smoothstep(0.38, 0.72, foamPattern(world0.xz, frameTimeCounter, capScale));
                cap *= capDist;
                // Consistency: the DIRECT (sun) share of the foam is shadow-masked
                // like the glint (glintVis = 1.0 when WATER_GLINT_SHADOW = 0);
                // the ambient share stays.
                vec3 capCol = vec3(0.92, 0.96, 1.0)
                            * (gAmbC + gLightC * 0.5 * glintVis) * 0.85 * skyl;
                color = mix(color, capCol, clamp(cap, 0.0, 1.0) * 0.60 * FOAM_AMOUNT);
                }
                }
            }
            #endif

#if PERF_WATER_FAR_SIMPLE == 1 && defined SSR_ENABLED
            } // fin du saut de branche lourde C1c (farW < 0.999)
            if (farW > 0.0) {
                // Fondu 70 -> 90 blocs : la couleur lourde (payee dans la
                // bande seulement) glisse vers le pixel simple ; au-dela du
                // seuil farW == 1.0 et color n'est que farCol. wMirror suit le
                // meme fondu (contrat VL / voiles d'air, sites synchronises).
                color = mix(color, farCol, farW);
                wMirror = mix(wMirror, wMirrorF, farW);
            }
#endif

#if WATER_FOG_HUE == 1
        // WATER_FOG_HUE (B): last statement of the WATER branch, so it covers
        // the heavy path AND the PERF_WATER_FAR_SIMPLE takeover in one place
        // (farCol has already been blended in above). Identity on any pixel
        // that is not in the magenta wedge -- see the function.
        color = vlxWaterHueGuard(color);
#endif

        // ===================== GLASS =====================
        } else if (data2.b > 0.6 && data2.b < 0.8) {
#if DEBUG_VIEW == 28
            // ---- DEBUG VIEW 28, channel RED: this pixel took the GLASS
            // branch. Painted FIRST so it survives every early exit below; the
            // green and blue channels are added at their own decision points.
            aux5 = vec4(1.0, 0.0, 0.0, 1.0);
#endif
            // GLASS_EFFECTS DECOUPLING. The see-through rebuild used to live
            // INSIDE the GLASS_EFFECTS block, so a player who turned glass
            // refraction/reflection off for FPS silently lost it while the menu
            // still displayed GLASS_SEE_THROUGH = 1. The fog half had already
            // been rescued by a duplicated bound under "#ifndef GLASS_EFFECTS";
            // the water half had not, which is EXACTLY the reported asymmetry
            // ("I can see the fog now, it is just the water"). Instead of
            // duplicating 200 more lines, the block below now opens on either
            // switch: with GLASS_EFFECTS off there is simply no refraction to
            // follow, so guv = uv (uv IS the ray) and the pane's own
            // refraction / reflection / specular tail stays compiled out under
            // its own #ifdef further down. The old duplicated fog bound is gone
            // with this change -- it was the same bound, computed twice.
#if defined GLASS_EFFECTS || GLASS_SEE_THROUGH == 1
            #ifdef GLASS_EFFECTS
                vec3 normalV = normalize(texture2D(colortex1, uv).rgb * 2.0 - 1.0);

                // Passe "MEN" (refraction OFF par defaut, cout nul a OFF) :
                // GLASS_REFRACTION est un litteral de compilation (0.0 livre),
                // donc la branche ci-dessous est une BRANCHE CONSTANTE, morte
                // a 0.0 - le verre sans refraction ne paie plus ni les 2 taps
                // de profondeur ni la re-lecture colortex0 pour un offset nul.
                // guv = uv est exactement le contrat du #else : colortex0 en
                // uv EST deja 'color' du haut de main. (Un "#if" est
                // impossible ici : le preprocesseur ne compare pas de float.)
                vec2 guv = uv;
                if (GLASS_REFRACTION != 0.0) {
                    guv = clamp(uv + normalV.xy * 0.006 * GLASS_REFRACTION * TAAU_S,
                                vec2(0.001), vec2(0.999 * TAAU_S)); // TAAU
                    if (texture2D(depthtex0, guv).r >= texture2D(depthtex1, guv).r - 1e-6) guv = uv;
                    color = texture2D(colortex0, guv).rgb;
                }
            #else
                // No refraction: uv IS the ray, and colortex0 at uv already
                // holds the pane alpha-blended over its background (that is
                // 'color' at the top of main), so no extra tap is taken.
                vec2 guv = uv;
            #endif

                // Underwater base: pane + floor below sea level AND REAL water
                // nearby on screen (otherwise a pane placed below y=WATER_LEVEL
                // on dry land would wrongly get the water treatment).
                float glassWaterNear = 0.0;
                // LOCAL water surface level: max world Y over the 8 probes (NO
                // break -- the max must scan all of them). Initialized very low
                // (-1e4) so it stays inert until water is probed; every consumer
                // is already gated by glassWaterNear. Known limit: the on-screen
                // water may be unrelated to this particular pane.
                float glassWSurfY = -1e4;
#if GLASS_SEE_THROUGH == 1
                // Biome water tint of the FIRST water neighbour, taken from the
                // SAME source the WATER branch uses (colortex5 = the biome
                // glcolor gbuffers_water writes). Read from a NEIGHBOUR, not
                // from this pixel: colortex5 at 'uv' only carries a water tint
                // when a water fragment happened to be drawn behind the pane in
                // the same translucent pass (gbuffers_water.fsh:404 writes
                // alpha = 0 on glass, so a pane does NOT overwrite what is
                // already there -- but on a pane with dry terrain behind it the
                // slot still holds whatever the opaque pass left). The
                // neighbour tap is the only reading GUARANTEED to come off a
                // water pixel, which is why it is kept. Known limit, shared
                // with the culled-face rebuild in the opaque branch: the water
                // beside the pane may belong to another body of water, and a
                // window that covers a lake edge to edge finds no neighbour at
                // all. Ocean default until a probe lands on water.
                vec3 gsTint = vec3(0.247, 0.463, 0.894);
#endif
                for (int gi = 0; gi < 8; gi++) {
                    float ga = float(gi) * 0.7853982;
                    vec2 gnuv = uv + vec2(cos(ga), sin(ga)) * 0.06 * TAAU_S; // TAAU: sub-rect radius
                    if (gnuv.x > 0.0 && gnuv.x < TAAU_S && gnuv.y > 0.0 && gnuv.y < TAAU_S) {
                        if (texture2D(colortex2, gnuv).b > 0.95) {
#if GLASS_SEE_THROUGH == 1
                            // First water neighbour only: one extra tap, and only
                            // on panes that actually have water beside them.
                            if (glassWaterNear < 0.5) gsTint = texture2D(colortex5, gnuv).rgb;
#endif
                            glassWaterNear = 1.0;
#if PIXEL_WATER_FIX == 1
                            vec3 gws = toView(gnuv, texture2D(depthtex0, gnuv).r);
                            glassWSurfY = max(glassWSurfY, (mat3(gbufferModelViewInverse) * gws + cameraPosition).y);
#endif
                        }
                    }
                }
#if GLASS_SEE_THROUGH == 1
                // ============ GLASS_SEE_THROUGH ============
                // A translucent pane must not SWALLOW the treatment of what
                // stands behind it. Two independent losses were stacking up on
                // every glass pixel:
                //   (a) gbuffers_water writes the PANE's material flag (0.7) over
                //       the WATER flag (>0.95) of the lake behind it -- colortex2
                //       is not blend-disabled for that pass -- so this pixel takes
                //       the glass branch and the water model never runs on it. The
                //       symptom is documented at the WATER_SURFACE_PRESENCE floor
                //       in gbuffers_water.fsh: "water seen through glass skips the
                //       composite dressing entirely".
                //   (b) the pane also owns depthtex0, so every DISTANCE fog prices
                //       the ray at the pane (1-3 blocks) instead of the surface
                //       behind it.
                // Both are repaired here, in PHYSICAL order along the ray:
                //   1. fogDist/fogW0 move to the OPAQUE surface (depthtex1), so the
                //      whole air path is hazed -- or to the water surface the ray
                //      crosses first, which is exactly where the open-water pixels
                //      beside the pane stop their own haze.
                //   2. the water column between eye and opaque is dressed with the
                //      SHARED waterColumn(), plus its flat-surface sky mirror.
                //   3. the pane's own tint and reflections stay where they were,
                //      i.e. ON TOP (colortex0 already holds the pane alpha-blended
                //      over this background; the reflection block runs below).
                // The VL march and the HEIGHT_FOG tail already ran to depthtex1
                // and needed nothing here.
                // KNOWN, ACCEPTED OVERLAP on the submerged leg. The distance
                // fogs stop cleanly at the water surface (fogDist = gsEnter
                // below), but the VL march does not: its per-step water probe
                // tests colortex2.b > 0.95 and reads the PANE's 0.7, so it
                // marches [pane .. lake floor] at AIR density (~0.008/block)
                // and the analytic HEIGHT_FOG tail runs to the floor too. That
                // thin air dressing now sits UNDER the water column added here,
                // where the free-water pixel beside the pane would have used
                // the water density instead. Left as is on purpose: fixing it
                // means teaching the march to treat a pane as water, and the
                // march is contractually MIRRORED in lib/vl_halfres.glsl -- the
                // two would have to be changed and re-diffed in lockstep for a
                // difference well below the noise floor of the water veil.
                {
                    float gsD1 = texture2D(depthtex1, guv).r;
                    bool gsOpq = gsD1 < 1.0;
                    vec3 gsVp = toView(guv, gsD1);
                    // ---- CUTOUT-LAYER GLASS GUARD ----
                    // Material id 30 is flagged 0.7 by BOTH passes: by
                    // gbuffers_water.fsh (stained / tinted panes, a real
                    // translucent) AND by gbuffers_terrain.fsh (the CUTOUT
                    // layer, where vanilla minecraft:glass and glass_pane
                    // actually render). On a CUTOUT pane the pane IS the
                    // opaque surface: depthtex1 == depthtex0, so every reading
                    // taken below describes THE PANE and not what stands behind
                    // it. gsW1 is the pane's own world point (the fog move is a
                    // no-op), and waterAboveShadowGlass then measures the column
                    // standing ABOVE the pane -- 0 for a window over a lake, or,
                    // worse, the column of a pond the 3-block sidestep happens
                    // to land on. Same separation test the refraction tap makes
                    // ~20 lines above, in the same direction: depthtex0 holds
                    // translucents and depthtex1 does not, so depthtex1 strictly
                    // greater than depthtex0 is the proof that something really
                    // is behind this pane.
                    bool gsBehind = gsD1 > texture2D(depthtex0, guv).r + 1e-6;
#if DEBUG_VIEW == 28
                    // ---- DEBUG VIEW 28, CYAN: this pane is OPAQUE in
                    // depthtex1 (cutout layer). There is nothing hidden behind
                    // it to rebuild and the column below is skipped BY DESIGN --
                    // this is NOT the undetected case that RED marks.
                    if (!gsBehind) aux5 = vec4(0.0, 0.55, 0.85, 1.0);
#endif
#ifdef DISTANT_HORIZONS
                    // A DH LOD behind the pane is invisible to depthtex1 AND to the
                    // isDHpix fog block (which needs isSky, false on a pane), so it
                    // used to get no fog from either side. The vanilla ATMO/AERIAL
                    // formulas below are exact mirrors of the DH ones, so feeding
                    // them the LOD distance is all that is needed.
                    float gsDh = texture2D(dhDepthTex1, guv).r;
                    if (!gsOpq && gsDh < 1.0) { gsVp = toViewDH(guv, gsDh); gsOpq = true; }
#endif
                    // Nothing opaque behind the pane = sky. colortex0 already holds
                    // the deferred sky (atmosphere + clouds), which carries its own
                    // haze and which sky pixels never re-fog -- leave fogDist alone.
                    // The submerged eye is likewise left untouched: its fog really
                    // does end at the pane.
                    if (gsOpq && isEyeInWater == 0) {
                        vec3 gsW1 = mat3(gbufferModelViewInverse) * gsVp + cameraPosition;
                        float gsLen = length(gsVp);
                        fogDist = gsLen;
                        fogW0 = gsW1;

                        // ---- water hidden behind the pane ----
                        // 'glassWaterNear' (a REAL water pixel within 6% of the
                        // screen) used to be a HARD gate here, and it deleted
                        // the flagship case of this whole feature: a window that
                        // fills the view with water has NO open-water neighbour
                        // left on screen, so the column was skipped -- while the
                        // fog bound, set a few lines ABOVE this gate, kept
                        // working. That asymmetry is precisely the report the
                        // fix answers ("I can see the fog now, it is just the
                        // water"). The known limit was even written down at the
                        // gsTint declaration: "a window that covers a lake edge
                        // to edge finds no neighbour at all".
                        // Under PIXEL_WATER_FIX the column is MEASURED in the
                        // shadow map, and that measurement IS the false-positive
                        // guard the screen probe was standing in for: it demands
                        // a water-tagged translucent between the light and the
                        // receiver, so a dry room behind a window still measures
                        // 0 and gets nothing at any altitude. The probe stays --
                        // as the biome tint source, as the gate of the Y-level
                        // fallback below (which has no measurement of its own)
                        // and as the gate of uwGlass -- it just no longer has a
                        // veto over a column that was physically measured.
                        // Note the difference in blast radius with the identical
                        // probe in the OPAQUE branch, which is kept as a hard
                        // gate there: that one runs on every opaque pixel in the
                        // world, this one only on glass.
                        // gsBehind: never rebuild a column for a pane that
                        // owns depthtex1 itself (cutout glass) -- see the
                        // guard at the top of this block.
#if PIXEL_WATER_FIX == 1
                        if (gsBehind && skyl > 0.05) {
#else
                        if (gsBehind && glassWaterNear > 0.5 && skyl > 0.05) {
#endif
#if PIXEL_WATER_FIX == 1
                            // Vertical metres of water standing above the surface
                            // behind the pane, read from the shadow map (water RGB
                            // tag + delta-z). Fail-safe: 0.0 outside the shadow map
                            // and on every inconclusive case, so a dry room behind a
                            // window can never gain a water column at any altitude.
                            // GLASS variant of the helper: the pane is itself a
                            // translucent and hides the water from shadowtex0
                            // whenever it stands in the light path, so the tap is
                            // retried a few blocks to the side (see the helper).
                            float gsColV = waterAboveShadowGlass(gsVp, lightW.y);
                            float gsSurfY = gsW1.y + gsColV;
                            float gsWt = smoothstep(0.1, 0.5, gsColV);
#if DEBUG_VIEW == 28
                            // ---- DEBUG VIEW 28, channel GREEN: a water column
                            // was measured above the surface behind the pane.
                            if (gsColV > 0.1) aux5.g = 1.0;
#endif
#else
                            float gsSurfY = WATER_LEVEL - 0.1;
                            float gsWt = 1.0;
#if DEBUG_VIEW == 28
                            if (glassWaterNear > 0.5) aux5.g = 1.0;
#endif
#endif
                            // SUBMERGED SPAN of the ray [gsEnter, gsExit], solved
                            // from the EYE and not from the pane: a pane can sit
                            // anywhere along the column, and starting at the pane
                            // would drop the water standing IN FRONT of a submerged
                            // one (a pane in a lake seen from the bank -- the case
                            // where Minecraft also culls the water face flush
                            // against the glass, so nothing else would price it).
                            // f = surfY - y is positive under water, so the ray is
                            // submerged where f > 0 and crosses at fA / (fA - fB).
                            float fA = gsSurfY - cameraPosition.y;
                            float fB = gsSurfY - gsW1.y;
                            float gsEnter = 0.0;
                            float gsExit = 0.0;
                            if (fA > 0.0 && fB > 0.0) { gsExit = gsLen; }
                            else if (fA > 0.0 || fB > 0.0) {
                                // Exactly one endpoint is submerged, so |fA - fB| is
                                // at least the positive one: never a zero divide.
                                float tX = gsLen * (fA / (fA - fB));
                                if (fA > 0.0) { gsExit = tX; }        // starts wet, leaves the water
                                else { gsEnter = tX; gsExit = gsLen; } // enters the water, stays in
                            }
                            // AIR POCKET: the eye is below the local surface yet
                            // isEyeInWater is 0, so it stands in AIR (underwater
                            // base, dry ravine below sea level). The water cannot
                            // begin before the PANE, which is the wall of that
                            // pocket -- without this clamp an underwater base would
                            // absorb its own indoor air. Same span the legacy
                            // submerged-pane block measured, from the pane onward.
                            if (fA > 0.0) gsEnter = max(gsEnter, dist);
                            gsExit = max(gsExit, gsEnter);
                            float gsPath = gsExit - gsEnter;
                            // Same darkness gate as the legacy submerged-pane block.
                            gsWt *= smoothstep(0.08, 0.35, data2.g);
#if DEBUG_VIEW == 28
                            // ---- DEBUG VIEW 28, channel BLUE: the ray really
                            // crosses a submerged span, brightness = its length
                            // (floor 0.20 so a one-block span is still visible,
                            // full blue at 24 blocks).
                            if (gsPath > 0.02) aux5.b = 0.20 + 0.80 * clamp(gsPath / 24.0, 0.0, 1.0);
#endif
                            if (gsPath > 0.02 && gsWt > 0.002) {
                                // Haze now stops at the WATER SURFACE, like the open
                                // water beside the pane: the submerged part of the
                                // path is the water column's job, not the air fog's.
                                fogDist = gsEnter;
                                fogW0 = cameraPosition + worldDir * gsEnter;
                                // Water surface point directly ABOVE the receiver:
                                // well defined at any view angle (unlike the ray
                                // crossing, which degenerates when the eye is only
                                // just above the surface) and it is the point whose
                                // shadow actually darkens THIS column.
                                vec3 gsSurfV = mat3(gbufferModelView)
                                             * (vec3(gsW1.x, gsSurfY, gsW1.z) - cameraPosition);
                                // Shadow over the column, same recipe as the WATER
                                // branch (+0.25 receiver lift, PCF, fail-open past
                                // shadowDistance) so both sides of the pane edge
                                // darken together.
                                float gsShadow = 1.0;
                                float gsFade = smoothstep(0.85, 1.0, length(gsSurfV) / shadowDistance);
                                if (gsFade < 1.0) {
                                    vec3 gsUpV = mat3(gbufferModelView) * vec3(0.0, 1.0, 0.0);
                                    vec3 gsPcf = sampleShadowPCF(toShadowClip(VLX_PIX_RECV(gsSurfV + gsUpV * 0.25, gsUpV), gsUpV), dither);
                                    gsShadow = mix(clamp(luma(gsPcf), 0.0, 1.0), 1.0, gsFade);
                                }
                                vec3 gsCol = waterColumn(color, gsPath, gsTint, skyl,
                                                         gsShadow, data2.r, worldDir, lightW);
                                #ifdef WATER_HORIZON_SKY
                                // Same anti-black SKY FLOOR the WATER branch
                                // applies immediately after waterColumn(). It
                                // is not optional here: gsPath is bounded by
                                // NOTHING (unlike the culled-face rebuild in
                                // the opaque branch, capped at 48 blocks), so a
                                // lake looked at in a grazing line through a bay
                                // window drives absorption and the veil to zero
                                // and the pixel collapses to the bare slate
                                // in-scatter, while the open-water pixels one
                                // block to the side keep their horizon floor --
                                // a hard seam on the window frame. Same tint,
                                // same WCOL_HZ_* constants (the model switch moves
                                // both sides at once), same distance curve,
                                // measured on the FULL eye-to-
                                // exit path so the two sides agree.
                                {
                                    float gsHzB = smoothstep(WATER_HORIZON_DIST * 0.5,
                                                             WATER_HORIZON_DIST * 2.0,
                                                             gsEnter + gsPath);
                                    if (gsHzB > 0.001) {
                                        if (!skyBaseWDok) { skyBaseWD = getSkyBase(worldDir, sunW); skyBaseWDok = true; }
                                        // WATER_SKY_TINT site 4 -- the SAME
                                        // floor for the water a pane hides. It
                                        // exists precisely so the two sides of
                                        // one lake cannot drift apart, so it
                                        // must carry the palier too, or a bay
                                        // window would show an azure floor next
                                        // to a tinted open-water one. Local
                                        // copy: skyBaseWD is the shared REAL sky.
                                        vec3 gsHzRaw = waterSkyTint(skyBaseWD);
                                        vec3 gsHzSky = mix(vec3(luma(gsHzRaw)), gsHzRaw, WCOL_HZ_CHROMA)
                                                     * WCOL_HZ_FILT
                                                     * max(skyl, 0.15) * mix(0.60, 1.0, gsShadow);
                                        gsCol = mix(gsCol, gsHzSky, gsHzB * WCOL_HZ_STR * WATER_HORIZON_SKY_STRENGTH);
                                    }
                                }
                                #endif
                                color = mix(color, gsCol, gsWt);
                                #ifdef SSR_ENABLED
                                // The water SURFACE mirror, rebuilt on a FLAT normal:
                                // the pane owns colortex1, so the wave normal behind
                                // it is gone and a screen ray would start on the pane
                                // (no SSR possible). skyReflect still gives the real
                                // screen sky with its volumetric clouds where the
                                // reflected direction lands on one. Without this the
                                // lake reads as a bare floor through the window --
                                // the "reflets disparus" half of the report.
                                // ONLY when the ray really crosses the surface, i.e.
                                // the eye is ABOVE it (fA <= 0). From inside an air
                                // pocket the ray runs pane -> water -> floor without
                                // ever meeting the surface, and a mirror there would
                                // paste sky onto a basement wall.
                                if (fA <= 0.0) {
                                vec3 gsUpVN = normalize(mat3(gbufferModelView) * vec3(0.0, 1.0, 0.0));
                                vec3 gsRdV = reflect(viewDir, gsUpVN);
                                vec3 gsRdW = normalize(mat3(gbufferModelViewInverse) * gsRdV);
                                float gsNdv = clamp(dot(gsUpVN, -viewDir), 0.0, 1.0);
                                float gsFres = 0.02 + 0.98 * pow(1.0 - gsNdv, 5.0);
                                // EAU5: same WT_MIRROR weight as the open-water
                                // surface, so the water a pane hides never
                                // carries a different amount of sky than the
                                // water beside it (palier 2 = x1.0, unchanged).
                                float gsRefW = clamp(gsFres * (WATER_REFLECTIVITY * WT_MIRROR), 0.0, 0.98) * gsWt;
                                if (gsRefW > 0.002) {
                                    vec3 gsSky = skyReflect(viewDir * gsEnter, gsRdV, gsRdW, sunW, skyl);
#if SUN_MIRROR_SHADOW == 1
                                    // ---- THE MIRRORED SUN, 4th and last site ----
                                    // skyReflect carries the solar disc TWICE
                                    // (getSkyAll -> celestialDisc x25, x40 under
                                    // PHYSICAL_SKY; and the colortex0 screen tap,
                                    // which re-reads the very disc the deferred
                                    // pass painted). Unmasked here, water seen
                                    // THROUGH a pane kept showing the sun's mirror
                                    // image while standing in the shade -- the same
                                    // defect the WATER branch masks at its own
                                    // skyReflect, on a path that is ON by default
                                    // (GLASS_SEE_THROUGH 1).
                                    // gsShadow is this column's shadow, already
                                    // computed in the ENCLOSING scope above: zero
                                    // extra shadow tap. It is a PCF penumbra (like
                                    // wShadow, unlike the binary shadowVis1 of the
                                    // pane branch), so the SQUARE is the real
                                    // "visible fraction of the disc" law that
                                    // glintVis and the WATER branch both apply --
                                    // not a no-op here. Masked on gsRdW, the
                                    // direction this very sky was sampled along.
                                    gsSky *= vlxSunMirror(gsRdW, lightW, gsShadow * gsShadow);
#endif
                                    color = mix(color, gsSky, gsRefW);
                                }
                                }
                                #endif
                            }
                        }
                        // ---- shared fog quantities re-priced on the RESOLVED bound ----
                        // fogDist has just left the pane (opaque surface behind
                        // it, or the water surface the ray crosses first). Two
                        // quantities computed from 'dist' BEFORE this branch
                        // would otherwise still describe the pane:
                        //   * the FOG_SHADOWS sun probe, whose taps sit at
                        //     0.2/0.5/0.8 x length (0.2/0.7 with PERF_FOGVIS)
                        //     -- on 'dist' that is 0.4-1.6 blocks in front of
                        //     the eye, i.e. INSIDE the
                        //     room. An indoor player got shadowVis 0 at all
                        //     three, so fogShadDir = 0 and fogShadAmb = 0.75:
                        //     the distance haze restored above arrived on the
                        //     window at 75% and with NO solar glow, while the
                        //     identical air seen through an open door beside it
                        //     was at 100% with the full glow -- a seam exactly
                        //     on the pixels this branch exists for. Re-probed
                        //     here, same ray, resolved length. Paid on glass
                        //     pixels only (this whole block is the GLASS branch).
                        //   * CAVE_FOG, see fogCaveW at its declaration.
                        fogCaveW = 0.0;
#ifdef FOG_SHADOWS_ACTIVE
                        if (fogProbeW > 0.0) {
#ifdef CLOUD_SHAFTS_ACTIVE
                            // CLOUD_SHAFTS: le site verre suit, a l'identique
                            // du site principal -- meme produit, meme palier.
                            // Sans cela une vitre garderait une integrale
                            // calculee sur 2 blocs de piece.
                            fogSunV = mix(1.0, fogSunVis(cameraPosition, worldDir, fogDist, vlDither)
                                             * fogCloudVis(cameraPosition, worldDir, fogDist, vlDither), fogProbeW);
                            fogShadDir = fogSunV;
                            fogShadAmb = (1.0 - SHAFT_AMB_K) + SHAFT_AMB_K * fogSunV;
#else
                            fogSunV = mix(1.0, fogSunVis(cameraPosition, worldDir, fogDist, vlDither), fogProbeW);
                            fogShadDir = fogSunV;
                            fogShadAmb = 0.75 + 0.25 * fogSunV;
#endif
                        }
#endif
                    }
                }
#else
#if PIXEL_WATER_FIX == 1
                // Gated on the REAL probed water level, not on Y63.
                if (world0.y < glassWSurfY - 0.1 && isEyeInWater == 0 && glassWaterNear > 0.5) {
#else
                if (world0.y < WATER_LEVEL - 0.2 && isEyeInWater == 0 && glassWaterNear > 0.5) {
#endif
                    vec3 vpB = toView(guv, texture2D(depthtex1, guv).r);
                    vec3 worldB = mat3(gbufferModelViewInverse) * vpB + cameraPosition;
#if PIXEL_WATER_FIX == 1
                    if (worldB.y < glassWSurfY - 0.05) {
#else
                    if (worldB.y < WATER_LEVEL - 0.1) {
#endif
                        float wd = max(distance(vpB, viewPos), 0.0);
                        float gateUw = smoothstep(0.08, 0.35, data2.g);
                        // Same column constants as open water (WCOL_K_OUT,
                        // in-scatter on a GRAY light drive, no hue drift), so
                        // a lake never changes colour behind a pane.
                        vec3 absorbG = exp(-wd * vlxWaterK() * 1.0); // EAU9: this biome's medium
                        vec3 scatG = vlxScatUWBase()
                                   * (luma(gAmbC) + luma(gLightC) * 0.14) * skyl;
                        // EAU7: same carrier-chroma correction as waterColumn(),
                        // through the SAME function, so the lake behind the pane
                        // and the lake beside it stay one colour. The in-scatter
                        // share still uses the raw absorbG, so the energy split
                        // is untouched -- only the floor's chroma moves.
                        vec3 fogged = color * vlxFloorCarrier(absorbG, wd) + scatG * (1.0 - absorbG);
                        color = mix(color, fogged, gateUw);
                    }
                }
#endif // GLASS_SEE_THROUGH

            // ---- the pane's OWN dressing (refraction was above, reflection and
            // specular are here) stays a GLASS_EFFECTS feature. Everything from
            // here to the end of the branch reads 'normalV', which only exists
            // when GLASS_EFFECTS is on.
            #ifdef GLASS_EFFECTS
                float fres = 0.04 + 0.96 * pow(1.0 - clamp(dot(normalV, -viewDir), 0.0, 1.0), 5.0);
                // Submerged glass: reflections + specular dimmed and water-tinted,
                // ONLY when real water is present on screen (glassWaterNear);
                // otherwise dry panes below y=WATER_LEVEL get blued reflections.
#if PIXEL_WATER_FIX == 1
                float uwGlass = clamp((glassWSurfY - world0.y) / 4.0, 0.0, 1.0)
                              * float(isEyeInWater == 0) * glassWaterNear;
#else
                float uwGlass = clamp((WATER_LEVEL - world0.y) / 4.0, 0.0, 1.0)
                              * float(isEyeInWater == 0) * glassWaterNear;
#endif
                // SUN_MIRROR_SHADOW: sun visibility AT THE PANE. One binary
                // shadowtex1 tap (shadowVis1: opaque casters only, fail-open
                // 1.0 outside the map -- the same contract and the same
                // infrastructure as the caustics and AO probes), paid on glass
                // pixels only. Consumed TWICE below: to extinguish the MIRRORED
                // solar disc inside the reflected sky, and to extinguish the
                // pane's own Blinn sun lobe. A pane under a roof was showing
                // both, while the wall right next to it was correctly dark.
                // 1.0 with the gate off -> every consumer below is a x1.0
                // multiply the compiler folds away, so the build is
                // bit-identical at SUN_MIRROR_SHADOW 0.
                float gSunVis = 1.0;
#if SUN_MIRROR_SHADOW == 1
                gSunVis = shadowVis1(viewPos);
#endif
                #ifdef SSR_ENABLED
                    vec3 rdir = reflect(viewDir, normalV);
                    float gRough = 0.0;
                    #ifdef GLASS_ROUGH_REFLECT
                        // WARNING -- data2.a IS NOT A labPBR SMOOTHNESS HERE.
                        // gbuffers_water.fsh writes gl_FragData[2] = vec4(lmcoord,
                        // flag, 1.0) UNCONDITIONALLY for every translucent (water,
                        // glass, portal), and colortex2 is not blend-disabled for that
                        // pass, so a glass pixel always reads data2.a == 1.0. The
                        // specular map therefore never reaches this branch:
                        // grBase = 0 -> gRough = 0 -> gBlur = 0, the second tap below
                        // (`if (gBlur > 0.01)`) is dead code and GLASS_ROUGH_REFLECT is
                        // currently INERT. For the same reason glPow further down is
                        // the constant 850, not a cap.
                        // The formula is kept because it is the correct conversion the
                        // day gbuffers_water actually writes the pane smoothness --
                        // (1 - smoothness)^2 is the labPBR linear roughness / GGX
                        // alpha, matching 'rough' in the opaque branch, and the
                        // WATER_ROUGHNESS * 1.4 factor after it is an artistic dial
                        // (frosted-glass amount), not a unit conversion. Wiring that
                        // write is deliberately out of scope: gl_FragData[2].a is also
                        // read on the WATER path, so it cannot be repurposed blind.
                        float grBase = 1.0 - data2.a; grBase *= grBase;
                        gRough = grBase * WATER_ROUGHNESS * 1.4;
                    #endif
                    vec3 gtA = normalize(cross(normalV, vec3(0.0,1.0,0.0)) + vec3(1e-4,0.0,0.0));
                    vec3 gtB = cross(rdir, gtA);
                    float gBlur = gRough * 0.22;
                    float gAng = (dither + fract(frameTimeCounter * 0.61)) * 6.2831853;
                    vec3 rdirJ = normalize(rdir + (gtA*cos(gAng)+gtB*sin(gAng))*gBlur);
                    vec3 rworld = normalize(mat3(gbufferModelViewInverse) * rdirJ);
                    // Underwater fallback: deep water instead of open sky, in the
                    // same dark desaturated turquoise family as shallowC
                    vec3 uwReflFB = vec3(0.030, 0.140, 0.150)
                                  * (gAmbC * 0.45 + gLightC * 0.06);
                    // ---- WHAT A MISSED PANE RAY IS ALLOWED TO PAINT ----
                    // Split out of the mix() below so the SKY half can be
                    // corrected before it is blended with the underwater one
                    // (uwReflFB is already a dark deep-water colour and needs
                    // neither correction).
                    // NOTE on the answer to "is the pane's sky fallback applied
                    // without any skylight attenuation?": it is NOT -- the
                    // * skyl is right there and has always been. On an outdoor
                    // pane skyl is 1.0, so that factor changes nothing and it
                    // is not where the whitening comes from.
                    vec3 gSkyFB = getSkyAll(rworld, sunW) * skyl;
#if SUN_MIRROR_SHADOW == 1
                    // Mirrored solar disc, extinguished where the pane itself
                    // is in shadow. shadowVis1 is a binary step(), so squaring
                    // it would be a no-op here (unlike the water branch, whose
                    // wShadow is a PCF penumbra) -- used linear on purpose.
                    gSkyFB *= vlxSunMirror(rworld, lightW, gSunVis);
#endif
#if REFLECT_GROUND_FB == 1
                    // BELOW THE HORIZON THERE IS NO SKY TO REFLECT.
                    // getSkyBase clamps dir.y at 0, so every downward direction
                    // gets its FLAT, BRIGHTEST horizon colour -- measured
                    // (0.757, 0.976, 1.196), luma 0.93 at noon on the shipped
                    // constants. A vertical pane mirrors elevation exactly, so
                    // that plate lands as a bright horizontal band right at the
                    // horizon line, in the grazing zone where the screen ray
                    // leaves the frame and misses: the "bande claire" and the
                    // "plaque blanche laiteuse" of the report. Ground radiance
                    // instead (see REFLECT_GROUND_FB for the albedo argument).
                    // 'color' is the scene behind this pane, which at a lake
                    // edge is the very surface the pane is mirroring -- the
                    // best on-hand estimate, and the SSR hit overrides it
                    // wherever the ray actually lands on screen.
                    // NO-DARKENING PROOF (SSR_FALLBACK_V2 == 1): vlxGroundFB is
                    // the SAME expression as ssrLocalAmb, and ~60 lines below
                    // this branch already runs refl = max(refl, ssrLocalAmb(
                    // color) * (1 - gConf)). On a MISS (gConf 0) that max()
                    // pins the result at exactly the ground estimate, so this
                    // change can only REMOVE brightness that stood ABOVE the
                    // floor SSR_FALLBACK_V2 was already enforcing -- it can
                    // never push a pane below it. At SSR_FALLBACK_V2 = 0 there
                    // is no such floor and a grazing pane really does darken
                    // toward the ground, which is the physical answer.
                    gSkyFB = mix(vlxGroundFB(color), gSkyFB, vlxSkyValid(rworld.y));
#endif
                    vec3 refl = mix(gSkyFB, uwReflFB, uwGlass * 0.80);
                    float hit;
                    ssrOriN = normalV; // A3: normal-anchored start offset
                    vec2 hituv = ssrRay(viewPos, rdirJ, dither, hit);
                    if (hit > 0.0) refl = mix(refl, ssrHitColor(hituv), hit);
                    if (gBlur > 0.01) {
                        vec3 rdirJ2 = normalize(rdir + (gtA*cos(gAng+2.094)+gtB*sin(gAng+2.094))*gBlur);
                        vec3 rw2 = normalize(mat3(gbufferModelViewInverse) * rdirJ2);
                        // Same two corrections as the main tap, so the blurred
                        // sample can never drag the milky plate (or a mirrored
                        // sun the main tap just removed) back into the average.
                        // Currently INERT with the rest of this block: gRough is
                        // pinned at 0 because gbuffers_water writes data2.a = 1.0
                        // (documented at GLASS_ROUGH_REFLECT above), so gBlur
                        // never clears 0.01 -- kept in lockstep for the day that
                        // write lands.
                        vec3 gSkyFB2 = getSkyAll(rw2, sunW) * skyl;
#if SUN_MIRROR_SHADOW == 1
                        gSkyFB2 *= vlxSunMirror(rw2, lightW, gSunVis);
#endif
#if REFLECT_GROUND_FB == 1
                        gSkyFB2 = mix(vlxGroundFB(color), gSkyFB2, vlxSkyValid(rw2.y));
#endif
                        vec3 gr2 = mix(gSkyFB2, uwReflFB, uwGlass * 0.80);
                        ssrOriN = normalV; // A3: normal-anchored start offset
                        float gh2; vec2 ghuv2 = ssrRay(viewPos, rdirJ2, fract(dither+0.5), gh2);
                        if (gh2 > 0.0) gr2 = mix(gr2, ssrHitColor(ghuv2), gh2); // consistent with the main tap
                        refl = mix(refl, 0.5*(refl+gr2), clamp(gRough*3.0,0.0,1.0));
                    }
                    float ssrAmt = mix(0.85, 0.38, uwGlass);
                    #if SSR_FALLBACK_V2 == 1
                    // A2 on the glass branch. This is where the old fallback was
                    // worst: a constant 0.85 SSR weight times a Fresnel that never
                    // goes below 0.04, multiplied by a sky term that is EXACTLY
                    // black indoors -- so an indoor pane darkened whatever was
                    // behind it, at every angle.
                    float gConf = clamp(hit, 0.0, 1.0);
                    refl = max(refl, ssrLocalAmb(color) * (1.0 - gConf));
                    // Confidence-weighted, same contract as the water and opaque
                    // branches: the no-darkening clause is a guard on a GUESS.
                    color = mix(color, max(refl, color * (ssrNoDark(skyl) * (1.0 - gConf))),
                                clamp(fres, 0.0, 1.0) * ssrAmt);
                    #else
                    color = mix(color, refl, clamp(fres, 0.0, 1.0) * ssrAmt);
                    #endif
                #endif

                vec3 L = normalize(shadowLightPosition);
                vec3 H = normalize(L - viewDir);
                // Exponent driven by labPBR smoothness (data2.a): frosted glass =
                // wide lobe, smooth glass = tight point. Falls back to ~250 without PBR.
                float glPow = 80.0 + data2.a * data2.a * 600.0 + 170.0;
                float spec = pow(clamp(dot(normalV, H), 0.0, 1.0), glPow);
                float specStr = mix(5.0, 1.0, uwGlass);
                // gSunVis: the pane's DIRECT sun lobe dies in shadow, exactly
                // like the diffuse term of the block beside it and like the
                // water glint under WATER_GLINT_SHADOW. It was added on a pure
                // SKYLIGHT gate (smoothstep on data2.g), which says "this pane
                // is outdoors", not "the sun reaches this pane" -- so a window
                // in the shade of its own roof kept a full sun spot. The gate
                // stays (it still kills indoor panes); the visibility is the
                // missing factor, not a replacement. 1.0 when the gate is off.
                color += gLightC * spec * fres * specStr * smoothstep(0.5, 0.9, data2.g) * gSunVis;
            #endif // GLASS_EFFECTS (pane reflection / specular)
#endif // GLASS_EFFECTS || GLASS_SEE_THROUGH

        // ============== NETHER PORTAL (material flag 0.85) ==============
        // gbuffers_water writes the VANILLA portal texture (native animation,
        // vanilla alpha) lifted to HDR; colortex0 already holds it blended over
        // the background, so 'color' is final here. The former "magic glass"
        // dressing (vnoise wobble at ~0.7 cell/s + chromatic dispersion + rim
        // ember) is gone: it shimmered everything seen through the sheet at
        // 1+ Hz. Only NETHER_PORTAL_WOBBLE remains: a slow, sub-pixel,
        // world-anchored travelling wave (|offset| <= 0.5 screen px, periods
        // 5 s / 6.3 s) of the sheet and of what is seen through it.
        } else if (data2.b > 0.82 && data2.b < 0.93) {
            #if PORTAL_FX == 1 && NETHER_PORTAL_WOBBLE == 1
                float t5 = frameTimeCounter;
                vec2 wob = vec2(sin(t5 * 1.2566 + world0.y * 2.6 + (world0.x + world0.z) * 0.9),
                                sin(t5 * 0.9975 + (world0.x + world0.z) * 2.2 - world0.y * 1.3));
                // 0.35 screen px per axis (TAAU: sub-rect texels), faded past ~16 blocks
                vec2 pOff = wob * 0.35 * TAAU_S / vec2(viewWidth, viewHeight) / max(dist * 0.0625, 1.0);
                // Take the offset texel ONLY if a translucent is really in front of
                // it, otherwise the obsidian frame bleeds into the sheet.
                vec2 puv = clamp(uv + pOff, vec2(0.001), vec2(0.999 * TAAU_S));
                if (texture2D(depthtex0, puv).r >= texture2D(depthtex1, puv).r - 1e-6) puv = uv;
                color = texture2D(colortex0, puv).rgb;
            #endif

        // ============== OPAQUE SURFACES ==============
        } else {
#if GI_HALF_RES == 1 && (defined AO || defined RTGI || defined SS_LIGHTS || defined SSGI || defined VLX_RSM_ACTIVE)
            // Shared half-res AO+GI upsample: ONE 4-tap bilateral feeds both
            // the AO application here and the GI reinjection below. Hand
            // pixels (squashed depth d0 < 0.56) are excluded at compute
            // (composite.fsh) AND at application: neutral gi = 0 / ao = 1,
            // so the upsample can never paint scene GI/AO onto the hand.
            vec4 giao = (d0 < 0.56) ? vec4(0.0, 0.0, 0.0, 1.0)
                                    : giUpsample(uv, -viewPos.z);
#endif
            #ifdef AO
              #if AO_QUALITY == 0
                // ---- AO_QUALITY 0: simple fallback application ----
#if GI_HALF_RES == 1
                float ao = giao.a;
#else
                float ao = texture2D(colortex6, uv).r;
#endif
                // Non-linear AO (deeper crevices), applied moderately to the
                // direct term (the sun must not be eaten by AO) -- AO mostly
                // weighs on the ambient/indirect reinjected below.
                float aoC = pow(ao, 1.4);
                color *= mix(1.0, aoC, 0.6);
              #else
                // ---- AO_QUALITY 1: 3x3 bilateral + sun-aware application ----
#if GI_HALF_RES == 1
                // Half-res: the shared 4-tap depth+normal upsample (giao)
                // already denoises (each tap is a temporally accumulated
                // half-res texel covering 2x2 pixels) -> the legacy 3x3
                // bilateral is redundant and skipped entirely.
                float aoC = pow(giao.a, 1.15);
#else
                // Denoise weighted by LINEAR depth (colortex4.a, written by
                // composite.fsh) -> smooth grain WITHOUT bleeding across
                // silhouettes (a neighbour at a different depth weighs ~0).
                float z0AO = texture2D(colortex4, uv).a;
                vec2 pxAO = 1.5 / vec2(viewWidth, viewHeight);
                float aoSum = texture2D(colortex6, uv).r;
                float aoWs = 1.0;
                for (int bx = -1; bx <= 1; bx++) {
                    for (int by = -1; by <= 1; by++) {
                        if (bx == 0 && by == 0) continue;
                        vec2 buv = uv + vec2(float(bx), float(by)) * pxAO;
                        float zn = texture2D(colortex4, buv).a;
                        float wb = exp(-abs(zn - z0AO) / (0.05 * z0AO + 0.12));
                        aoSum += texture2D(colortex6, buv).r * wb;
                        aoWs += wb;
                    }
                }
                float aoC = pow(aoSum / aoWs, 1.15);
#endif
                // AO occludes AMBIENT light; direct sun is already handled by the
                // shadow map. One shadowtex1 tap (shadowVis1, also used by the
                // caustics): in full sun AO fades out (0.40 -> no soot on sunlit
                // surfaces), in shadow/indoors it carries (0.95 -> corners and
                // contacts well anchored). Strongly torch-lit areas (data2.r) are
                // partially protected.
#if SNOW_SPARKLE == 1
                // The single shadowtex1 tap is cached for the snow sparkle
                // below (same value, same operation order as the line it replaces).
                snowSv = shadowVis1(viewPos);
                float sunVisAO = snowSv * smoothstep(0.0, 0.15, lightHeight())
                               * skyl * (1.0 - rainStrength);
#else
                float sunVisAO = shadowVis1(viewPos) * smoothstep(0.0, 0.15, lightHeight())
                               * skyl * (1.0 - rainStrength);
#endif
                float litAO = clamp(max(sunVisAO, data2.r * 0.7), 0.0, 1.0);
                color *= mix(1.0, aoC, mix(0.95, 0.40, litAO));
              #endif
            #endif

            #ifdef CONTACT_SHADOWS
            // Screen-space contact shadows: a short view-space ray-march toward
            // the sun, recovering the shadows between adjacent blocks that a 2k
            // shadow map misses (a block occluding its immediate neighbour).
            if (skyl > 0.08) {
                vec3 lightVS = normalize(shadowLightPosition);
                vec3 nCS = normalize(texture2D(colortex1, uv).rgb * 2.0 - 1.0);
                // start biased along the normal: kills grazing self-shadow acne
                vec3 csPos = viewPos + nCS * CONTACT_SHADOW_BIAS;
                // per-pixel dithered step: breaks banding, catches thin occluders
                float csStep = (0.05 + 0.012 * length(viewPos)) * (0.6 + 0.8 * dither);
                float sscs = 1.0;
                for (int csi = 0; csi < CONTACT_SHADOW_STEPS; csi++) {
                    csPos += lightVS * csStep;
                    csStep *= 1.18;
                    vec4 clip = gbufferProjection * vec4(csPos, 1.0);
                    if (clip.w <= 0.0) break;
                    vec2 csUV = (clip.xy / clip.w * 0.5 + 0.5) * TAAU_S; // TAAU: NDC -> sub-rect UV
                    if (csUV.x < 0.0 || csUV.x > TAAU_S || csUV.y < 0.0 || csUV.y > TAAU_S) break;
                    float csD = texture2D(depthtex0, csUV).r;
                    if (csD >= 1.0) break;
                    vec3 csVP = toView(csUV, csD);
                    float diff = csPos.z - csVP.z;
                    // thickness test: a real occluder in front, not a distant background
                    if (diff > 0.035 && diff < CONTACT_SHADOW_THICKNESS) { sscs = 0.0; break; }
                }
                color *= mix(1.0, sscs, skyl * CONTACT_SHADOW_STRENGTH);
            }
            #endif

            #if defined RTGI || defined SS_LIGHTS || defined SSGI || defined VLX_RSM_ACTIVE
                // Indirect light (GI bounce) reinjected, tinted by the albedo
                vec3 alb = toLinear(texture2D(colortex5, uv).rgb);
#if GI_HALF_RES == 1
                color += giao.rgb * alb; // shared half-res upsample (top of branch)
#else
                // full-res GI: 3x3 depth bilateral, see giFilter3 near giUpsample.
                // Hand pixels are neutral at compute AND here (gi = 0), same
                // contract as the half-res branch.
                color += ((d0 < 0.56) ? vec3(0.0) : giFilter3(uv, -viewPos.z)) * alb;
#endif
            #endif

            // ===== Ray-traced reflections: smooth surfaces (labPBR or per-block fallback) =====
            // RT_REFLECTIONS supersedes PBR_REFLECTIONS: same ssrRay engine as the
            // water, plus pure/combined RT modes and desaturation. Water is NOT
            // handled here -- it keeps its own SSR in the water branch.
            #if defined PBR_TEXTURES && defined SSR_ENABLED && (defined RT_REFLECTIONS || defined PBR_REFLECTIONS)
            {
                // PBR reflections are inhibited when data2.b is high (a pixel
                // alpha-blended with water: a particle/entity in front of water
                // inherits the water flag)
                float smooth2 = data2.a * (1.0 - smoothstep(0.01, 0.12, data2.b));
                // Hand pixels (squashed depth): viewPos rebuilt from d0 is wrong
                // there -> SSR rays aberrant. The hand now writes real labPBR
                // smoothness; its shine is done in forward (gbuffers_hand).
                if (d0 < 0.56) smooth2 = 0.0;
                if (smooth2 > 0.04) {
                    vec3 nO = normalize(texture2D(colortex1, uv).rgb * 2.0 - 1.0);
                    // Perceptual roughness -> linear roughness (labPBR smoothness
                    // is perceptual)
                    float rough = (1.0 - smooth2) * (1.0 - smooth2);
                    float ndv5 = pow(1.0 - clamp(dot(nO, -viewDir), 0.0, 1.0), 5.0);
                    #if PBR_ROUGHNESS_V2 == 1
                    // Roughness-aware Fresnel (Karis' F_SchlickRoughness). Required
                    // once the reflection WEIGHT stops collapsing with roughness
                    // (reflW below): the microfacet masking term that caps the
                    // horizon response is not modelled here, so without this a rough
                    // dielectric would become a grazing-angle mirror. rough = 0
                    // gives back the exact legacy curve 0.03 + 0.97 * ndv5.
                    float fres = 0.03 + (max(1.0 - rough, 0.03) - 0.03) * ndv5;
                    #else
                    float fres = 0.03 + 0.97 * ndv5;
                    #endif
                    // MAXIMUM reflection weight computed BEFORE paying for the rays
                    // (48-110 taps). Below 1.5% the reflection is invisible, so the
                    // whole block is skipped.
                    float metalness = texture2D(colortex11, uv).g;
                    // Entities never write colortex11 (DRAWBUFFERS:0125), so .g
                    // holds the STALE terrain PBR drawn behind them (e.g. a gold
                    // block -> metal-tinted armor). Force dielectric on the entity
                    // flag band (0.02, same band as the F5 VL fix): armor still
                    // shines via smoothness + Fresnel. Glass 0.7 / water 0.95 sit
                    // outside the band and keep their own paths.
                    if (data2.b > 0.01 && data2.b < 0.30) metalness = 0.0;
                    #if PBR_ROUGHNESS_V2 == 1
                    // ENERGY vs SHARPNESS. Legacy: smooth2*(0.35+0.65*smooth2) --
                    // a quadratic that drops the reflected ENERGY to 16% at
                    // smooth2 = 0.3 and 7% at 0.15, so a rough material simply lost
                    // its reflection and only the sharp survivors stayed visible.
                    // Physically a rough concrete reflects about as much light as
                    // polished marble, it just spreads it over a wide lobe. The
                    // small residual drop keeps the energy that micro-facets scatter
                    // OUTSIDE the visible cone (and outside the screen-space ray's
                    // reach), which is real but far smaller than the legacy curve.
                    //   smooth2 1.00 -> 1.000 (legacy 1.000)  identical: existing
                    //                                          mirrors do not move
                    //   smooth2 0.85 -> 0.933 (legacy 0.765)
                    //   smooth2 0.60 -> 0.820 (legacy 0.444)
                    //   smooth2 0.30 -> 0.685 (legacy 0.164)   ~4.2x
                    //   smooth2 0.15 -> 0.618 (legacy 0.067)   ~9.2x, but the
                    //                                          rough Fresnel above
                    //                                          caps its horizon
                    //                                          response at 0.28
                    // The 0.55 floor is the single strongest dial in this whole block:
                    // it is what keeps a near-mirror (metal or not) at nearly full
                    // strength however the rest of the lobe is shaped, so it is exposed.
                    // PBR_REFLECT_FLOOR 0.55 = the calibrated default, bit-identical.
                    float reflW = mix(PBR_REFLECT_FLOOR, 1.0, smooth2);
                    #else
                    float reflW = smooth2 * (0.35 + 0.65 * smooth2);
                    #endif
                    #if PBR_ROUGHNESS_V2 == 1 && PBR_ROUGHNESS_V3 == 1
                    // METAL HORIZON (V3). mix(fres, 1.0, metalness) hands every metal
                    // a flat 1.0 -- no roughness term, no view term. With reflW's 0.55
                    // floor that made even the roughest possible metal overwrite 55%
                    // of its own shading head-on (94% for iron at smoothness 0.871),
                    // while a dielectric at the same angle got 3%: metals were the
                    // only material in the pack rendering a full-strength reflection,
                    // which is exactly the "metals are perfect mirrors" report.
                    // Metals now get the same roughness-aware horizon as dielectrics.
                    // F0 stays the albedo (applied as 'tint' further down), only the
                    // reachable fraction of the lobe shrinks with roughness.
                    //   rough 0.000 (a true mirror)   -> 1.000  EXACTLY legacy
                    //   rough 0.017 (iron, s 0.871)   -> 0.983 head-on, 1.0 grazing
                    //   rough 0.230 (copper, s 0.52)  -> 0.770 head-on
                    //   rough 0.640 (a matte metal)   -> 0.360 head-on
                    // HONEST SCOPE, measured on the enabled pack: this term bites on
                    // ROUGH metals (amtMax 0.6175 -> 0.1714 at smoothness 0.15, -72%)
                    // and is nearly a no-op on POLISHED ones. Iron at smoothness 0.871
                    // goes from 0.9420 to 0.9263 -- MINUS 1.7%. That is correct
                    // physics, not a bug: the specular map asks for a mirror, so the
                    // shader draws a mirror. If an iron block still looks too much like
                    // a mirror, the lever is PBR_REFLECT_FLOOR above (its weight), or
                    // lowering iron_block_s.R in the resource pack -- NOT this line.
                    float metalF = max(1.0 - rough, 0.06);
                    metalF += (1.0 - metalF) * ndv5;
                    float baseRefl = mix(fres, metalF, metalness);
                    #else
                    float baseRefl = mix(fres, 1.0, metalness);
                    #endif
                    float amtMax = reflW * baseRefl * PBR_REFLECT_STRENGTH;
                    #if PBR_ROUGHNESS_V2 == 1
                    // ROUGHNESS-DEPENDENT pre-gate. A flat 2.0% threshold does not
                    // work here: reflW has a 0.55 floor, so amtMax >= 0.55 * fres *
                    // strength whatever the smoothness, and the whole 0.26-0.65
                    // smoothness band (stone, brick, planks, concrete -- the bulk of
                    // a full labPBR pack) opened a 48-step ray plus refinement plus
                    // 3 getSkyAll for a 2-3% blend nobody can see, and at that weight
                    // amtMax < 0.04 forces nTaps = 1 and alphaDir <= 0.12, so the
                    // result was not even glossy. Scaling the threshold with
                    // smoothness keeps those pixels skipped HEAD-ON (they still light
                    // up toward grazing angles, where the reflection is real) while a
                    // near-mirror keeps the legacy 1.5% gate -- so nothing the legacy
                    // path drew is lost at any PBR_REFLECT_STRENGTH, including the
                    // 0.5 preset exposed in the menu.
                    #if PBR_ROUGHNESS_V3 == 1
                    // V3 lowers the ROUGH end of that threshold from 4.5% to 3.8%. A
                    // dielectric reflects 3% at normal incidence, so amtMax head-on is
                    // mix(0.55, 1, s) * 0.03 = 0.0165 + 0.0135 * s, and the head-on
                    // crossing point with the threshold moves like this:
                    //   V2, mix(0.045, 0.015) -> lights up head-on above smoothness 0.655
                    //   V3, mix(0.038, 0.015) -> lights up head-on above smoothness 0.589
                    // That is what the option is for: obsidian (0.79), quartz, packed
                    // ice and wet stone sat just under the V2 line and showed NO
                    // reflection head-on rather than a blurry one.
                    // THIS IS NOT FREE, and the cost is NOT the "+2 getSkyAll" the sky
                    // lobe adds -- it is the pixels that paid NOTHING before and now run
                    // a full ssrRay (up to 48 steps + refinement) plus a getSkyAll plus
                    // the footprint taps. Newly lit fraction of the projected hemisphere
                    // at this threshold: ~+4% at smoothness 0.15-0.34 (grass, cobble,
                    // sand, stone -- these stay skipped head-on and only gain a slice
                    // near grazing), ~+18% at oak planks (0.471), ~+25% at 0.55-0.65.
                    // An earlier draft used 0.030, which pulled the crossing point down
                    // to smoothness 0.474 and lit the entire 0.50-0.65 band from 0 deg
                    // -- +55 to +66% of the hemisphere on those materials. 0.038 keeps
                    // the named materials and roughly halves that bill.
                    if (amtMax > mix(0.038, 0.015, smooth2)) {
                    #else
                    if (amtMax > mix(0.045, 0.015, smooth2)) {
                    #endif
                    #else
                    if (amtMax > 0.015) {
                    #endif
                    vec3 rdir = reflect(viewDir, nO);
                    #if PBR_ROUGHNESS_V2 == 1
                    // ============== GGX GLOSSY LOBE (PBR_ROUGHNESS_V2) ==============
                    // labPBR stores PERCEPTUAL smoothness; the standard conversion is
                    // perceptualRoughness = 1 - smoothness and GGX alpha =
                    // perceptualRoughness^2. 'rough' above IS therefore ALREADY the
                    // GGX alpha -- squaring it once more (alpha = rough^2 = (1-s)^4)
                    // is the classic mistake that maps a smoothness-0.5 material to
                    // alpha 0.06, i.e. a mirror. Same convention as the glass branch
                    // (grBase = (1 - data2.a)^2) and unrelated to the water, whose
                    // wRough is an artistic wave dial, not a labPBR value.
                    float alphaG = rough;
                    // Orthonormal frame around the NORMAL: the GGX half-vector lives
                    // around n, not around the reflected ray (that was the legacy
                    // ring-jitter approximation).
                    vec3 tA = normalize(cross(nO, vec3(0.0, 1.0, 0.0)) + vec3(1e-4, 0.0, 0.0));
                    vec3 tB = cross(nO, tA);
                    // Adaptive tap count. A near-mirror keeps ONE ray (exact legacy
                    // cost) and a reflection too faint to read (< 4%, the legacy
                    // second-tap gate) is never refined either.
                    int nTaps = 1;
                    if (alphaG > 0.012 && amtMax > 0.04) {
                        nTaps = (alphaG < 0.09) ? 2 : ((alphaG < 0.30) ? 3 : 4);
#if PBR_ROUGHNESS_V3 == 1
                        // A METAL is the only surface whose reflection runs at full
                        // strength head-on (baseRefl ~ 1), so its lobe is the one the
                        // eye actually reads -- and the polished-metal band lands
                        // exactly in the 2-tap slot (iron alpha 0.017, gold 0.047).
                        // Two samples of a 1-2 deg lobe read as two ghosts, not as a
                        // spread highlight; a third closes it. Dielectrics are left on
                        // 2 taps, so this costs one extra ray on metal pixels only.
                        if (alphaG < 0.09 && metalness > 0.5) nTaps = 3;
#endif
                        nTaps = min(nTaps, PBR_ROUGH_TAPS);
                    }
                    // The DIRECTION jitter is capped by the number of rays actually
                    // available: a wide lobe sampled with too few screen rays is noise
                    // TAA cannot resolve, but a FIXED 0.40 cap made every material
                    // below smoothness 0.368 render the identical lobe (alpha 0.49 and
                    // 0.7225 were numerically indistinguishable), which contradicts the
                    // menu promise that rougher = blurrier. The cap now grows with
                    // nTaps (2 -> 0.43, 3 -> 0.52, 4 -> 0.61) so the rough half of the
                    // scale keeps differentiating. With a SINGLE tap there is nothing
                    // to average within the frame, so the spread stays narrow and the
                    // blur comes from the footprint filter plus TAA.
                    float alphaDir = min(alphaG, (nTaps == 1) ? 0.12 : (0.25 + 0.09 * float(nTaps)));
                    // Spatio-temporal sequence: the static 8x8 Bayer (spatial
                    // decorrelation) rotated every frame by the golden ratio, so
                    // successive frames land on different points of the lobe and TAA
                    // integrates them into a smooth glossy blur.
                    float rSeed = dither;
                    #ifdef TAA
                    // frameCounter is masked before the float conversion: Iris wraps it
                    // at 720720, and near that value the float32 ULP reaches 1/32, so a
                    // raw fract() would degenerate the golden sequence into ~32 states
                    // after a couple of hours -- residual glossy noise TAA can no longer
                    // integrate. 256 golden rotations are ample and stay exact.
                    rSeed = fract(rSeed + float(frameCounter & 255) * 0.6180339887);
                    #endif
                    vec3 rworld = normalize(mat3(gbufferModelViewInverse) * rdir);
                    // V3 wide-lobe cone average and its blend weight. Declared here,
                    // OUTSIDE every #if, because the tap loop reads them; they stay at
                    // 0 in pure-RT mode and whenever PBR_ROUGHNESS_V3 = 0.
                    vec3 skyWide = vec3(0.0);
                    float skyWideW = 0.0;
                    #if defined RT_REFLECTIONS && RT_REFLECT_MODE == 0
                    // PURE RT MODE: no sky fallback -- only geometry actually HIT by
                    // the ray reflects (intensity follows the confidence).
                    vec3 skyF = vec3(0.0);
                    #else
                    #if PBR_ROUGHNESS_V3 == 1
                    // ============ V3 SKY LOBE ============
                    // Half of the bug behind "metals are perfect mirrors". The sky
                    // fallback is the dominant content of every Overworld reflection
                    // that leaves the screen (it is weighted by the pixel SKYLIGHT, so
                    // it is exactly 0 in the End and the Nether -- there the fix that
                    // matters is the footprint further down). V2 sampled it in ONE
                    // direction, so it came back pixel-sharp whatever alpha said. The
                    // widening below it only fired above alpha 0.15, i.e. smoothness
                    // < 0.613: iron (alpha 0.017), gold (0.047), obsidian, quartz and
                    // packed ice all sat under that line and got a razor-sharp sky.
                    // V3 instead lets EACH GGX tap evaluate its OWN direction inside
                    // the loop, so the lobe genuinely integrates the sky (and TAA
                    // integrates across frames through the golden rotation). The mean
                    // evaluation is then only needed for a TRUE MIRROR, where it is the
                    // exact V2 cost and the exact V2 value -- one getSkyAll, crisp.
                    //
                    // The condition is alphaG, NOT nTaps. nTaps is forced to 1 by the
                    // second-tap gate (amtMax > 0.04) for every DIELECTRIC seen head-on,
                    // because a dielectric reflects 3% at normal incidence and reflW
                    // caps amtMax at mix(0.55, 1, s) * 0.03 = 0.027..0.030 there.
                    // Keying the mean sample on nTaps alone therefore left the whole
                    // dielectric band -- obsidian (alpha 0.043), quartz, packed ice, wet
                    // stone, smoothness 0.65 in general -- with a pixel-SHARP sky, sun
                    // disc and stars included, out to ~57 deg of incidence: exactly the
                    // materials the option text promises to fix. It was also internally
                    // inconsistent, because above alphaG 0.012 the SCREEN ray already
                    // leaves along a per-frame jittered GGX direction (rdirT / raySeed
                    // below) while the sky was read along the fixed mean one.
                    // Cost is UNCHANGED: still exactly one getSkyAll when nTaps == 1,
                    // evaluated inside the loop instead of here.
                    vec3 skyF = vec3(0.0);
                    if (nTaps == 1 && alphaG <= 0.012) skyF = getSkyAll(rworld, sunW) * skyl;
                    // 3 rays cannot integrate a WIDE lobe on their own, so a cone
                    // average is mixed in. V2 tilted on Y only, which left every
                    // AZIMUTHAL feature (sun disc, stars, the End black hole) crisp
                    // however rough the surface was; this pair is taken along a random
                    // axis of the plane ORTHOGONAL to the reflected ray, re-drawn per
                    // pixel and per frame, so the dither and TAA sweep the full ring.
                    // Trigger and budget match V2's: V2 already paid 2 extra getSkyAll
                    // above alpha 0.15, and this pays the same 2 -- the wide-lobe cost
                    // is unchanged, only its shape (a ring instead of a vertical bar).
                    if (alphaG > 0.15) {
                        float cw = min(alphaG * 1.25, 0.75);
                        // The frame is built around rworld in WORLD space: tA/tB above
                        // are VIEW-space tangents of the NORMAL and cannot be added to
                        // a world direction, and a frame orthogonal to the reflected
                        // ray keeps the two offsets symmetric at any incidence.
                        vec3 cA = normalize(cross(rworld, vec3(0.0, 1.0, 0.0)) + vec3(1e-4, 0.0, 0.0));
                        vec3 cB = cross(rworld, cA);
                        float cAng = rSeed * 6.2831853;
                        vec3 cD = cA * cos(cAng) + cB * sin(cAng);
                        skyWide = (getSkyAll(normalize(rworld + cD * cw), sunW)
                                 + getSkyAll(normalize(rworld - cD * cw), sunW)) * (0.5 * skyl);
                        // Capped short of 1.0 so the tap's own direction always keeps a
                        // share: a 2-sample ring alone would shimmer before TAA lands.
                        skyWideW = clamp(alphaG * 1.7, 0.0, 0.85);
                    }
                    #else
                    // Sky fallback evaluated ONCE along the MEAN direction (the sky
                    // is low frequency) and BLURRED for wide lobes: two extra
                    // evaluations tilted by +-0.5*alpha on Y -- the only axis with a
                    // real gradient, horizon -> zenith -- are averaged in, so a rough
                    // surface reflects a broad glow instead of a crisp sun disc.
                    // Still cheaper than the legacy path, which re-evaluated
                    // getSkyAll for its second tap.
                    vec3 skyF = getSkyAll(rworld, sunW) * skyl;
                    if (alphaG > 0.15) {
                        vec3 skyUp = getSkyAll(normalize(rworld + vec3(0.0, 0.5 * alphaG, 0.0)), sunW) * skyl;
                        vec3 skyDn = getSkyAll(normalize(rworld - vec3(0.0, 0.5 * alphaG, 0.0)), sunW) * skyl;
                        skyF = mix(skyF, (skyF + skyUp + skyDn) * (1.0 / 3.0), clamp(alphaG * 1.4, 0.0, 1.0));
                    }
                    #endif
                    #endif
                    #if PERF_SSR_ROUGH == 1
                    // PERF_SSR_ROUGH: alphaG > 0.09 is exactly the 3/4-tap
                    // band above -- a lobe whose result is jittered per tap,
                    // footprint-blurred (ssrHitColorRough) and TAA-integrated.
                    // Mirror-grade precision cannot survive that averaging, so
                    // the march budget drops to 24 steps / 4 bisections for
                    // EVERY ray of this tap loop. Near-mirrors (alphaG <=
                    // 0.09, 1-2 taps) keep the full budget. Restored after the
                    // block's last ray (see the reset below the legacy path).
                    if (alphaG > 0.09) { ssrStepCap = 24; ssrRefineCap = 4; }
                    #endif
                    vec3 refl = vec3(0.0);
                    float rtConf = 0.0;
                    for (int t = 0; t < nTaps; t++) {
                        // Two decorrelated low-discrepancy streams (R2 additive
                        // recurrence) -- no extra texture fetch, no noise texture.
                        float ft = float(t);
                        float u1 = fract(rSeed + ft * 0.7548776662);
                        // Capped short of 1.0: at alpha = 0 the GGX cosine formula
                        // degenerates to 0/0 exactly at u2 = 1.
                        float u2 = min(fract(rSeed * 1.6180339887 + 0.5 + ft * 0.5698402909), 0.9995);
                        vec3 rdirT = ggxReflectDir(viewDir, nO, tA, tB, alphaDir, u1, u2);
                        vec3 rT = skyF;
                        #if PBR_ROUGHNESS_V3 == 1
                        #if !(defined RT_REFLECTIONS && RT_REFLECT_MODE == 0)
                        // V3: this tap reads the sky along ITS OWN lobe direction, so
                        // the glossy blur applies to the sky exactly as it applies to
                        // the screen-space hit. skyF above holds the mean sample ONLY
                        // for a true mirror (alphaG <= 0.012), which is the one case
                        // that must stay bit-identical to V2. A single-tap GLOSSY pixel
                        // (the whole dielectric band head-on, see the skyF comment) is
                        // evaluated here as well, for the same one getSkyAll it paid
                        // before -- with alphaDir = min(alphaG, 0.12) the direction is a
                        // real lobe sample, and the dither plus the golden TAA rotation
                        // integrate it across frames.
                        if (nTaps > 1 || alphaG > 0.012) rT = getSkyAll(normalize(mat3(gbufferModelViewInverse) * rdirT), sunW) * skyl;
                        if (skyWideW > 0.0) rT = mix(rT, skyWide, skyWideW);
                        #endif
                        #endif
                        #if defined RT_REFLECTIONS && RT_REFLECT_MODE == 3
                        float hT = 0.0; vec2 huvT = vec2(0.5); // pure PT: no screen ray
                        #else
                        float hT;
                        // TRUE MIRROR (alphaG <= 0.012, single tap): keep the static
                        // Bayer the legacy path passed to ssrRay. Feeding it the
                        // frame-rotated seed moved the march's start offset every
                        // frame, so the quantised hit point -- and thus the mirror
                        // image -- shifted frame to frame; reflections are not
                        // reprojectable by motion vectors, so TAA clamps rather than
                        // resolves that, which reads as boiling. Glossy taps keep the
                        // rotation, which is what lets TAA integrate the lobe.
#if SSR_V3 == 1 && SSR_V3_MARCH_SEED == 1
                        // SSR_V3 (a). The comment above diagnosed the mechanism
                        // and then applied it to the TRUE MIRROR only. The same
                        // argument holds for every glossy tap: the golden
                        // rotation is what lets TAA integrate the LOBE, and the
                        // lobe is sampled by rdirT (u1 / u2, still built from
                        // rSeed just above -- untouched). The seed handed to
                        // ssrRay does something else entirely: it offsets the
                        // START of the march along the ray, which moves the
                        // quantised hit point without sampling anything new.
                        // Decoupling the two keeps the estimator's mean and
                        // drops its variance. Bench: alternations per pixel
                        // 0.004 -> 0.002 (lib/settings.glsl, SSR_V3 block).
                        // The mirror branch keeps 'dither' BYTE-IDENTICAL --
                        // bayer8 can exceed 1.0, so fract(dither) is not dither.
                        float raySeed = (nTaps > 1 || alphaG > 0.012) ? fract(dither + ft * 0.5) : dither;
#else
                        float raySeed = (nTaps > 1 || alphaG > 0.012) ? fract(rSeed + ft * 0.5) : dither;
#endif
                        ssrOriN = nO; // A3: normal-anchored start offset
                        vec2 huvT = ssrRay(viewPos, rdirT, raySeed, hT);
                        #endif
                        if (hT > 0.0) {
                            // Cone footprint: the further the ray travelled ON SCREEN,
                            // the wider the patch of scene it averages. Capped so the
                            // 4-tap cross still reads as a blur and not as 5 ghosts;
                            // alpha 0 -> radius 0 -> the exact single legacy tap.
                            // The cap itself widens on the rough half of the scale,
                            // otherwise it saturated after ~1.5% of screen travel and
                            // every alpha above 0.40 produced the same footprint.
                            #if PBR_ROUGHNESS_V3 == 1
                            // V3 footprint. Two separate V2 defects here, and this is
                            // the ONLY one of the three that bites in the End, where
                            // skylight is zero so skyF is zero and the whole reflection
                            // IS the screen-space hit:
                            //  - the RAMP. A perturbed NORMAL spreads the REFLECTED ray
                            //    by twice its own angle, so the cone half-width is about
                            //    2 * alpha, not 0.55 * alpha. Under-counted 3x, iron
                            //    needed to travel 66% of the screen just to reach its
                            //    cap and sat at ~4 px over normal distances -- a mirror.
                            //    1.7 is the physical factor (2, minus the usual GGX
                            //    single-scatter trim).
                            //  - the CAP. It topped out at 0.006 sub-rect uv (~11 px at
                            //    1920) and switched in one step at alpha 0.45, so
                            //    smoothness 0.5, 0.3 and 0.15 shared one footprint. It
                            //    is now continuous in alpha up to 0.024 (~46 px), and
                            //    past 0.0045 the two-ring 9-tap takes over so a wide
                            //    radius reads as a blur and not as 5 ghosts.
                            //   alpha 0.0025 (s 0.95) -> radT ~0.001 (~2 px) crisp mirror
                            //   alpha 0.017  (iron)   -> caps at 0.0065 (~12 px) past 23% travel
                            //   alpha 0.25   (s 0.50) -> caps at 0.0127 (~24 px) visibly blurred
                            //   alpha 0.72   (s 0.15) -> caps at 0.0240 (~46 px) diffuse lustre
                            // Caveat on "a true mirror pays the exact V2 cost": that
                            // holds for the RAYS and the getSkyAll count, not for the
                            // texture taps. At s 0.95 and a quarter-screen ray, radT
                            // 0.00106 clears ssrHitColorRough's 0.0007 bypass (V2 sat
                            // at 0.00034, under it), so the mirror goes from 1 tap to 5.
                            // The iron figures above assume that same 25% travel; a
                            // short 5% hop gives ~2.7 px, not 12.
                            float radCap = mix(0.006, 0.024, clamp(alphaG * 1.5, 0.0, 1.0)) * TAAU_S * PBR_ROUGH_BLUR;
                            float radT = min(alphaG * length(huvT - uv) * 1.7, radCap);
                            #else
                            float radCap = (alphaG > 0.45 ? 0.010 : 0.006) * TAAU_S;
                            float radT = min(alphaG * length(huvT - uv) * 0.55, radCap);
                            #endif
                            rT = mix(rT, ssrHitColorRough(huvT, radT, (u1 + 0.37 * ft) * 6.2831853), hT);
                        }
                        refl += rT;
                        rtConf = max(rtConf, hT);
                    }
                    refl /= float(nTaps);
                    float hit = rtConf;
                    #else
                    // Glossy blur: the reflected direction is perturbed by the
                    // roughness. 2 laterally scattered taps (orthonormal basis from
                    // viewDir/nO) -> sharp reflection at rough ~0, progressively
                    // diffuse when rough. Compile-safe on GLSL 120.
                    vec3 tA = normalize(cross(nO, vec3(0.0, 1.0, 0.0)) + vec3(1e-4, 0.0, 0.0));
                    vec3 tB = cross(rdir, tA);
                    float blurR = rough * 0.22;
                    float ang = dither * 6.2831853;
                    vec3 jit = (tA * cos(ang) + tB * sin(ang)) * blurR;
                    vec3 rdirJ = normalize(rdir + jit);
                    vec3 rworld = normalize(mat3(gbufferModelViewInverse) * rdirJ);
                    #if PERF_SSR_ROUGH == 1
                    // PERF_SSR_ROUGH (legacy 2-tap path): same rough-lobe cap,
                    // keyed on rough (== alphaG of the V2 path, both are the
                    // linear GGX alpha). Covers BOTH rays of this path (the
                    // main jittered one and the second glossy tap below);
                    // restored after the second one.
                    if (rough > 0.09) { ssrStepCap = 24; ssrRefineCap = 4; }
                    #endif
                    #if defined RT_REFLECTIONS && RT_REFLECT_MODE == 0
                    // PURE RT MODE: no sky fallback -- only geometry actually HIT by
                    // the ray reflects (intensity follows the confidence).
                    vec3 refl = vec3(0.0);
                    #else
                    vec3 refl = getSkyAll(rworld, sunW) * skyl;       // fallback: sky
                    #endif
                    float hit;
                    #if defined RT_REFLECTIONS && RT_REFLECT_MODE == 3
                    // PURE PT: no screen ray on smooth surfaces either
                    vec2 huv = vec2(0.5); hit = 0.0;
                    #else
                    ssrOriN = nO; // A3: normal-anchored start offset
                    vec2 huv = ssrRay(viewPos, rdirJ, dither, hit);
                    #endif
                    if (hit > 0.0) refl = mix(refl, ssrHitColor(huv), hit);
                    float rtConf = hit;
                    #endif
                    #if RT_REFLECT_MODE >= 2
                    // PT: the screen ray hit nothing -> it CONTINUES into the voxel
                    // copy of the world (off screen, behind the camera, anything).
                    if (hit < 0.9) { // partial hit -> pro-rata voxel completion
                        // Denoiser: per-pixel/per-frame cone jitter turns voxel
                        // aliasing into fine noise that TAA resolves into soft blur.
                        vec3 rjO = rworld;
                        if (PT_REFLECT_SOFT > 0.001) {
                            float ajO = (dither + fract(frameTimeCounter * 0.61)) * 6.2831853;
                            vec3 tjO = normalize(cross(rworld, vec3(0.0, 1.0, 0.001)));
                            vec3 bjO = cross(rworld, tjO);
                            rjO = normalize(rworld + (tjO * cos(ajO) + bjO * sin(ajO))
                                  * PT_REFLECT_SOFT * 0.20 * fract(dither * 7.13 + 0.37));
                        }
                        vec3 vHitO; vec3 fNO;
                        vec3 ptOriO = (world0 - cameraPosition) + rjO * max(VOXEL_SCALE, 0.3);
                        vec4 voxO = marchVoxelPT(ptOriO, rjO, PT_REFLECT_STEPS, PT_REFLECT_DISTANCE, vHitO, fNO);
                        if (voxO.a > 0.5) {
                            vec3 ptcO = ptHitColor(voxO, vHitO, fNO);
                            // RANGE fade over the TRAVEL distance -- using the
                            // camera->hit distance kills distant mirrors.
                            float fadeO = clamp((length(vHitO - ptOriO) - PT_REFLECT_DISTANCE * 0.55)
                                                / max(PT_REFLECT_DISTANCE * 0.45, 1.0), 0.0, 1.0);
                            ptcO = mix(ptcO, refl, fadeO);
                            refl = mix(refl, ptcO, 0.85 * (1.0 - hit));
                            rtConf = max(rtConf, 0.85 * (1.0 - hit));
                        }
                    }
                    #endif
                    #if PBR_ROUGHNESS_V2 == 0
                    // Second glossy tap (only on rough surfaces) to smooth the blur.
                    // Also skipped when the final weight is low (<4%): smoothing an
                    // almost invisible reflection is not visible.
                    // (PBR_ROUGHNESS_V2 replaces this ring jitter with the adaptive
                    // GGX tap loop above -- the taps are already averaged there.)
                    if (blurR > 0.01 && amtMax > 0.04) {
                        vec3 jit2 = (tA * cos(ang + 2.094) + tB * sin(ang + 2.094)) * blurR;
                        vec3 rdir2 = normalize(rdir + jit2);
                        #if defined RT_REFLECTIONS && RT_REFLECT_MODE == 3
                        float hit2 = 0.0; vec2 huv2 = vec2(0.5); // pure PT: no screen ray
                        #else
                        float hit2;
                        ssrOriN = nO; // A3: normal-anchored start offset
                        vec2 huv2 = ssrRay(viewPos, rdir2, fract(dither + 0.5), hit2);
                        #endif
                        #if defined RT_REFLECTIONS && RT_REFLECT_MODE == 0
                        vec3 r2 = vec3(0.0);
                        #else
                        vec3 r2 = getSkyAll(normalize(mat3(gbufferModelViewInverse) * rdir2), sunW) * skyl;
                        #endif
                        if (hit2 > 0.0) r2 = mix(r2, ssrHitColor(huv2), hit2);
                        refl = mix(refl, 0.5 * (refl + r2), clamp(rough * 1.5, 0.0, 1.0));
                        rtConf = max(rtConf, hit2);
                    }
                    #endif
                    #if PERF_SSR_ROUGH == 1
                    // PERF_SSR_ROUGH: last ray of the opaque-PBR block is
                    // behind us on BOTH sub-paths -> full budget back for
                    // every later ssrRay consumer of this invocation.
                    ssrStepCap = SSR_STEPS; ssrRefineCap = SSR_REFINE;
                    #endif
                    // Metal tint (metalness/reflW/baseRefl already computed by the
                    // pre-gate above -- same formulas, no difference)
                    vec3 alb2 = toLinear(texture2D(colortex5, uv).rgb);
                    vec3 tint = mix(vec3(1.0), alb2, metalness);
                    float amt = amtMax;
                    #if defined RT_REFLECTIONS && RT_REFLECT_MODE == 0
                    // Pure RT: the ray hit nothing -> no reflection at all
                    amt *= clamp(rtConf, 0.0, 1.0);
                    #endif
                    #if SUN_MIRROR_SHADOW == 1
                    {
                        // MIRRORED SOLAR DISC on the OPAQUE PBR branch, the
                        // third door the same defect walks through: this branch
                        // falls back to getSkyAll too, so a polished block in
                        // the shade of a wall mirrored a sun that physically
                        // cannot reach it.
                        // Masked on the SPECULAR AXIS rdir = reflect(viewDir,
                        // nO), declared once above the roughness split and in
                        // scope for BOTH sub-branches (V3 taps and the legacy
                        // 2-tap blur), so one site covers every path. A rough
                        // material spreads its taps far wider than the 2.3 deg
                        // disc, so the central axis is the only place a disc
                        // can survive the averaging anyway.
                        // The shadow tap is INSIDE the cone test: it is paid
                        // only on the handful of pixels that really mirror the
                        // disc, not on every reflective pixel in the frame.
                        // ORDER CAVEAT, and why the mask is weighted here.
                        // The two other sites mask the SKY FALLBACK ALONE and
                        // do it BEFORE the screen ray is composited (water:
                        // reflSky masked, then ssrRay; pane: gSkyFB masked,
                        // then ssrRay). This site runs AFTER the composition,
                        // so 'refl' already holds ssrHitColor / the averaged V3
                        // taps / the voxel RT completion -- MEASURED screen
                        // content. Masking that by shadowVis1 (binary, so down
                        // to 0) would delete the radiance of the very occluder
                        // that casts the shadow, which is the correct answer
                        // for those pixels, not zero.
                        // rtConf is exactly the "how much of refl is real
                        // measured content" weight the branch already keeps
                        // (assigned at the V3 tap loop and at the legacy hit,
                        // and consumed by the two SSR_FALLBACK_V2 clauses just
                        // below). Weighting the mask by (1 - rtConf) keeps the
                        // full extinction on a pure sky fallback -- the case
                        // that actually mirrors a phantom disc -- and fades it
                        // out as real geometry takes over. rtConf 1 (solid
                        // screen hit) -> mask 1.0, the hit survives untouched.
                        vec3 rwSun = normalize(mat3(gbufferModelViewInverse) * rdir);
                        float oDisc = celestialDisc(rwSun, lightW, SUN_SIZE * 1.5);
                        oDisc *= 1.0 - clamp(rtConf, 0.0, 1.0);
                        if (oDisc > 0.001) refl *= mix(1.0, shadowVis1(viewPos), oDisc);
                    }
                    #endif
                    // Desaturation (same REFLECT_DESAT slider as the water); metals
                    // keep their hue (iron reflects ITS own color).
                    refl = mix(refl, vec3(luma(refl)), clamp(REFLECT_DESAT, 0.0, 1.0) * 0.8 * (1.0 - metalness));
                    // FULL MIRROR (iron): a perfectly smooth metal rises to 0.98
                    // instead of the 0.9 cap, and its tint moves toward white
                    // (a mirror reflects ~95%, not 60% of a grey albedo).
                    float mirrorF = metalness * smoothstep(0.97, 1.0, smooth2);
                    tint = mix(tint, vec3(1.0), mirrorF * 0.6);
                    #if SSR_FALLBACK_V2 == 1
                    // A2 on the opaque PBR branch -- the one the "black metals in
                    // the End / the Nether / a cave" report is about. The
                    // environment part of 'refl' is floored by the local ambient
                    // estimate, weighted by (1 - confidence) so a real geometry hit
                    // keeps its own colour; then the composition itself is not
                    // allowed to darken. Without the second clause the cap alone
                    // (0.98 on a polished metal) still multiplies the surface by
                    // 0.02 wherever the floor is dim.
                    float oConf = clamp(rtConf, 0.0, 1.0);
                    refl = max(refl, ssrLocalAmb(color) * (1.0 - oConf));
                    vec3 reflT = refl * tint;
                    // Confidence-weighted, exactly like the ambient floor above.
                    // Unweighted, a polished metal (amt up to 0.98) reflecting a
                    // shaded corner outdoors could not go below 0.40 x its own
                    // colour: a permanent bright veil on the material this gate
                    // is meant to fix.
                    color = mix(color, max(reflT, color * (ssrNoDark(skyl) * (1.0 - oConf))),
                                clamp(amt, 0.0, mix(0.9, 0.98, mirrorF)));
                    #else
                    color = mix(color, refl * tint, clamp(amt, 0.0, mix(0.9, 0.98, mirrorF)));
                    #endif
                    } // end amtMax pre-gate
                }
            }
            #endif

            // Minecraft culls water faces flush against glass: a submerged floor
            // seen through a pane arrives here with NO water in front of it, so
            // the absorption of the crossed water column is rebuilt.
#if PIXEL_WATER_FIX == 1
            // The water column is MEASURED (water RGB tag + shadow-map delta-z),
            // never inferred from "below Y63" -- dry terrain gives colV = 0 and
            // therefore NO effect at any Y (this is what removes the cyan patches
            // in dry ravines). Test order matters: waterAboveShadow first (2-4
            // taps, early-out on the common no-water case), then the TIGHT screen
            // probes (0.035/0.08) as a false-positive guard. The dist < 160
            // pre-gate is free: the helper returns 0.0 outside the shadow map
            // anyway, so distant pixels degrade softly instead of turning cyan.
            if (isEyeInWater == 0 && skyl > 0.05 && data2.b < 0.01 && dist < 160.0) {
                float colV = waterAboveShadow(viewPos, lightW.y);
                if (colV > 0.1) {
                    float waterNear = 0.0;
                    for (int i = 0; i < 16; i++) {
                        float aa = float(i) * 0.7853982;
                        float rr = ((i < 8) ? 0.035 : 0.08) * TAAU_S; // TAAU: sub-rect radius
                        vec2 nuv = uv + vec2(cos(aa), sin(aa)) * rr;
                        if (nuv.x > 0.0 && nuv.x < TAAU_S && nuv.y > 0.0 && nuv.y < TAAU_S) {
                            // early-out on the first water neighbour
                            if (texture2D(colortex2, nuv).b > 0.95) { waterNear = 1.0; break; }
                        }
                    }
                    if (waterNear > 0.5) {
                        // Angular stretch CAPPED (x6): a 1-2 block puddle can no
                        // longer become a 30+ block path at grazing angles. The
                        // smoothstep on colV gives a soft edge fringe (raise 0.1
                        // toward 0.25 if a fringe shows at pond borders).
                        float stretch = clamp(1.0 / max(abs(worldDir.y), 0.17), 1.0, 6.0);
                        float wd = min(min(colV * stretch, dist), 48.0);
                        float wWeight = smoothstep(0.1, 0.5, colV);
                        // Palette aligned with the open-water column
                        // (WCOL_K_OUT absorption, in-scatter on a GRAY light
                        // drive) so culled water faces match the real surface
                        vec3 absorbU = exp(-wd * vlxWaterK() * 0.8 / WATER_CLARITY); // EAU9: this biome's medium
                        vec3 scatU = vlxScatUWBase()
                                   * (luma(gAmbC) + luma(gLightC) * 0.14) * skyl;
                        // EAU7: carrier chroma through the shared helper. The
                        // path passed is the SCALED one (0.8 / WATER_CLARITY),
                        // i.e. exactly the number the exponent above used.
                        color = mix(color, color * vlxFloorCarrier(absorbU, wd * 0.8 / WATER_CLARITY)
                                         + scatU * (1.0 - absorbU), wWeight);
                    }
                }
            }
#else
            if (isEyeInWater == 0 && world0.y < WATER_LEVEL - 0.2 && skyl > 0.05 && data2.b < 0.01) {
                float waterNear = 0.0;
                for (int i = 0; i < 16; i++) {
                    float aa = float(i) * 0.7853982;
                    float rr = ((i < 8) ? 0.10 : 0.24) * TAAU_S; // TAAU: sub-rect radius
                    vec2 nuv = uv + vec2(cos(aa), sin(aa)) * rr;
                    if (nuv.x > 0.0 && nuv.x < TAAU_S && nuv.y > 0.0 && nuv.y < TAAU_S) {
                        // early-out on the first water neighbour found
                        // (identical result, up to 15 taps saved per pixel)
                        if (texture2D(colortex2, nuv).b > 0.95) { waterNear = 1.0; break; }
                    }
                }
                if (waterNear > 0.5) {
                    float tCross = (cameraPosition.y > WATER_LEVEL - 0.1 && abs(worldDir.y) > 1e-4)
                                 ? max((WATER_LEVEL - 0.1 - cameraPosition.y) / worldDir.y, 0.0) : 0.0;
                    float wd = clamp(dist - tCross, 0.0, 48.0);
                    // Same palette as the PIXEL_WATER_FIX branch above
                    vec3 absorbU = exp(-wd * vlxWaterK() * 0.8 / WATER_CLARITY); // EAU9: this biome's medium
                    vec3 scatU = vlxScatUWBase()
                               * (luma(gAmbC) + luma(gLightC) * 0.14) * skyl;
                    // EAU7: same carrier correction as the PIXEL_WATER_FIX branch.
                    color = color * vlxFloorCarrier(absorbU, wd * 0.8 / WATER_CLARITY)
                          + scatU * (1.0 - absorbU);
                }
            }
#endif

            #ifdef RAIN_WET
                if (wetness > 0.01) {
                    vec3 nV = normalize(texture2D(colortex1, uv).rgb * 2.0 - 1.0);
                    vec3 nWup = mat3(gbufferModelViewInverse) * nV;
                    // smoothstep: dry ground under shelter (skyl<0.08), wet outdoors
                    float wet = wetness * smoothstep(0.08, 0.55, skyl) * clamp(nWup.y, 0.0, 1.0);
                    #if RIPPLE_BIOME_GATE == 1
                    // No wet gloss where the camera biome has no rainfall
                    // (desert) or snows instead of raining (frozen biomes).
                    wet *= float(biome_precipitation == 1);
                    #endif
                    if (wet > 0.001) {
                        // Rippled puddles: raindrops make the reflections wobble
                        if (rainStrength > 0.02) {
                            // nWup is the same mat3(gbufferModelViewInverse) * nV
                            // computed above with the still-unperturbed nV -> reused
                            vec3 nWr = nWup;
                            vec2 cellR = floor(world0.xz * 1.5);
                            vec2 frR = fract(world0.xz * 1.5) - 0.5;
                            vec2 hitR = vec2(hash12(cellR + 3.7), hash12(cellR + 8.1)) - 0.5;
                            vec2 dxzR = frR - hitR * 0.5;
                            float rrR = length(dxzR);
                            float phR2 = fract(frameTimeCounter * 1.3 + hash12(cellR) * 9.0);
                            // pow(negative, 2.0) is undefined in GLSL (NaN on some drivers):
                            // explicit quadratic form, mathematically identical.
                            float dRq = (rrR - phR2 * 0.4) * 10.0;
                            float ringR = cos((rrR - phR2 * 0.4) * 30.0)
                                        * exp(-dRq * dRq) * (1.0 - phR2);
                            nWr.xz += (dxzR / max(rrR, 0.03)) * ringR * 0.7 * rainStrength * wet;
                            nV = normalize(mat3(gbufferModelView) * normalize(nWr));
                        }
                        // Dark, glossy ground
                        color *= 1.0 - 0.22 * wet;
                        float fresW = 0.05 + 0.70 * pow(1.0 - clamp(dot(nV, -viewDir), 0.0, 1.0), 5.0);
                        vec3 rVS = reflect(viewDir, nV);
                        vec3 rwd = normalize(mat3(gbufferModelViewInverse) * rVS);
                        // During rain: overcast sky but clearly visible puddles
                        float reflSky = max(skyl, rainStrength * 0.40);
                        // CSE hoist: the sky term is IDENTICAL in all three
                        // branches below (SSR hit / SSR miss / no SSR) and
                        // exactly one of them runs -- same single evaluation,
                        // deduplicated text. Left-to-right factor order kept.
                        vec3 wetSkyRefl = getSkyBase(rwd, sunW) * reflSky * fresW * wet * 0.80;
                        #ifdef SSR_ENABLED
                        {
                            // SSR: looks for reflected nearby geometry (block edges, walls)
                            float ssrHit;
                            ssrOriN = nV; // A3: normal-anchored start offset
                            vec2 ssrUV = ssrRay(viewPos, rVS, dither, ssrHit);
                            if (ssrHit > 0.0) {
                                color += texture2D(colortex0, ssrUV).rgb * fresW * wet * 0.65 * ssrHit;
                                color += wetSkyRefl * (1.0 - ssrHit);
                            } else {
                                color += wetSkyRefl;
                            }
                        }
                        #else
                            color += wetSkyRefl;
                        #endif
                        // Sun glint even under rain
                        vec3 Hw = normalize(normalize(shadowLightPosition) - viewDir);
                        float gl2 = pow(clamp(dot(nV, Hw), 0.0, 1.0), 90.0);
                        // SUN_MIRROR_SHADOW: this is a DIRECT sun lobe on wet
                        // ground and must die in shadow exactly like the water
                        // glint under WATER_GLINT_SHADOW. It was added
                        // unconditionally, gated only by 'wet' (a skylight +
                        // wetness term), so a puddle under a tree or in a
                        // building's shadow still carried the sun spot -- the
                        // same defect the water report describes, on the other
                        // material. shadowVis1 is binary, so it is applied
                        // linear (squaring it would be a no-op).
                        // The tap is inside the lobe test: pow(ndh, 90) is
                        // already zero over almost the whole surface, so this
                        // costs nothing outside the highlight itself. The
                        // wetSkyRefl above is DIFFUSE dome (getSkyBase carries
                        // no disc) and is deliberately left alone -- shaded wet
                        // ground still mirrors the sky, which is correct.
                        float wSunV = 1.0;
#if SUN_MIRROR_SHADOW == 1
                        if (gl2 > 0.001) wSunV = shadowVis1(viewPos);
#endif
                        color += gLightC * gl2 * wet * fresW * 2.5 * (0.20 + 0.80 * (1.0 - rainStrength)) * wSunV;
                    }
                }
            #endif

            #if SNOW_SPARKLE == 1
            // ===== SNOW SPARKLE: world-anchored micro-facet glints =====
            // Every 1/12-block cell of the snow surface (tangent grid on the
            // dominant normal axis) owns ONE facet: a random normal on a 25 deg
            // cap around the surface normal and a random spot inside the cell.
            // The facet glints when it mirrors the active light toward the eye
            // (facet normal within ~5 deg of the half vector = the ~4% most
            // aligned cells of the cap), through a narrow GGX lobe (alpha 0.02)
            // capped at 4.0 so one glint peaks near 12 HDR by day (bloom feeds
            // on it). World cells: the points sit still on the snow and only
            // change when the PLAYER moves - no temporal jitter under TAA. Spot
            // radius 1.5 cm, widened to ~0.8 px far away with its energy
            // preserved (dissolves into a faint glitter instead of aliasing),
            // gone past 100 blocks. Intensity = light color x shadow visibility
            // (snowSv: the AO block's shadowtex1 tap, re-taken only when that
            // block is off) x cumulus shadow x 0.8 x strength; moon x0.35; none
            // in rain or on wet snow, none without sky light (caves).
            if (snowW > 0.5 && dist < 100.0) {
                float dayS = smoothstep(-0.03, 0.12, sunHeight());
                float sparkW = smoothstep(0.0, 0.06, lightHeight()) * mix(0.35, 1.0, dayS)
                             * (1.0 - wetness) * (1.0 - rainStrength)
                             * smoothstep(0.30, 0.75, data2.g)
                             * (1.0 - smoothstep(40.0, 100.0, dist))
                             * SNOW_SPARKLE_STRENGTH;
                vec3 nWs = vec3(0.0, 1.0, 0.0);
                if (sparkW > 0.002) {
                    nWs = normalize(mat3(gbufferModelViewInverse)
                                  * normalize(texture2D(colortex1, uv).rgb * 2.0 - 1.0));
                    sparkW *= smoothstep(0.02, 0.20, dot(nWs, lightW));
                }
                if (sparkW > 0.002) {
                    float svS = (snowSv >= 0.0) ? snowSv : shadowVis1(viewPos);
                    #if defined VOLUMETRIC_CLOUDS && defined VC_GROUND_SHADOWS
                    svS *= cloudShadow(world0, lightW);
                    #endif
                    sparkW *= svS;
                }
                if (sparkW > 0.002) {
                    // Tangent grid, 12 cells per block, on the dominant-axis plane
                    vec3 aN = abs(nWs);
                    vec2 p2; float pc;
                    if (aN.y >= aN.x && aN.y >= aN.z) { p2 = world0.xz; pc = world0.y; }
                    else if (aN.x >= aN.z)            { p2 = world0.zy; pc = world0.x; }
                    else                              { p2 = world0.xy; pc = world0.z; }
                    vec2 gp = p2 * 12.0;
                    vec2 cellS = floor(gp);
                    // Wrapped, plane-seeded hash input (float precision far from spawn)
                    vec2 cH = mod(cellS, 4096.0) + floor(pc * 12.0 + 0.5) * 0.731;
                    float hA = hash12(cH);
                    float hB = hash12(cH + 7.3);
                    float hC = hash12(cH + 19.1);
                    vec2 hO = vec2(hash12(cH + 3.7), hash12(cH + 11.9));
                    // Facet normal: uniform on the 25 deg cap (cos 25 deg = 0.9063)
                    float ctS = mix(0.9063078, 1.0, hB);
                    float stS = sqrt(max(1.0 - ctS * ctS, 0.0));
                    float phS = hA * 6.2831853;
                    vec3 tXs = normalize(cross(nWs, (aN.y < 0.9) ? vec3(0.0, 1.0, 0.0) : vec3(1.0, 0.0, 0.0)));
                    vec3 tYs = cross(nWs, tXs);
                    vec3 nF = normalize(tXs * (stS * cos(phS)) + tYs * (stS * sin(phS)) + nWs * ctS);
                    vec3 Hs = normalize(lightW - worldDir);
                    float nfh = clamp(dot(nF, Hs), 0.0, 1.0);
                    // Acceptance window: soft edge between 5.5 and 4.5 deg off the half vector
                    float winS = smoothstep(0.99540, 0.99692, nfh);
                    if (winS > 0.001) {
                        // GGX lobe, alpha 0.02 (a2 = 0.0004), capped at 4.0
                        float ddS = nfh * nfh * (0.0004 - 1.0) + 1.0;
                        float lobeS = min(0.0004 / (3.14159265 * ddS * ddS), 4.0);
                        // Spot: 1.5 cm = 0.18 cell, at least 0.8 px wide (pxW = world
                        // size of one render pixel at this distance), never past
                        // half a cell (no neighbour search); energy (0.18/r)^2 kept.
                        float pxW = dist * 2.0 / (viewHeight * TAAU_S * gbufferProjection[1][1]);
                        float rC = clamp(pxW * 9.6, 0.18, 0.5);
                        float eC = 0.0324 / (rC * rC);
                        vec2 dS = gp - (cellS + 0.5 + (hO - 0.5) * 0.5);
                        float spotS = exp(-2.0 * dot(dS, dS) / (rC * rC));
                        color += min(gLightC * (lobeS * winS * spotS * eC * mix(0.45, 1.0, hC) * 0.8 * sparkW),
                                     vec3(12.0));
                    }
                }
            }
            #endif

            #ifdef WATER_CAUSTICS
            {
                // PHYSICAL CAUSTICS: they appear where the sun CROSSES water
                // before reaching the ground, i.e. inside the colored water
                // shadow (detected through the shadow map). Light refracted by
                // the waves focuses into a dancing light web -- no phantom
                // caustics everywhere.
                float causticAmt = 0.0;
                float causticColV = 0.0; // real measured water depth (shadow delta-z)
                vec3 waterTint = vec3(0.2, 0.6, 0.8);

#if PERF_OCEAN == 1
                // PERF_OCEAN (3): same camera-distance early-out as the
                // through-surface site -- under CAUSTICS_V4 this shore-band
                // weight (caW4S) carried NO distance fade at all, so a wet-sand
                // band 150+ blocks away still paid the detection taps + the
                // full net. Fade 110->150 blocks, then skip the detection too
                // (causticAmt stays 0 -> the whole body is skipped).
                // Honors CAUSTIC_DIST_FADE 0.0 ("no distance fade"): no cut.
                float caCutS = (CAUSTIC_DIST_FADE > 0.0)
                             ? 1.0 - smoothstep(110.0, 150.0, dist) : 1.0;
                if (isEyeInWater == 0 && caCutS > 0.0) {
#else
                if (isEyeInWater == 0) {
#endif
                    // Above water: check whether the light passes through water
                    vec3 sc = toShadowClip(VLX_PIX_FLOOR(viewPos), vec3(0.0, 1.0, 0.0));
                    float fdc = getDistortFactor(sc.xy);
                    vec3 sp = distortShadow(sc, fdc) * 0.5 + 0.5;
                    if (sp.x > 0.0 && sp.x < 1.0 && sp.y > 0.0 && sp.y < 1.0) {
                        float zb = sp.z - 0.0009 * (VLX_SHADOW_ZSCALE * 2.0); // constant world-space bias
                        float opaqueClear = step(zb, texture2D(shadowtex1, sp.xy).r);
                        float allClear    = step(zb, texture2D(shadowtex0, sp.xy).r);
                        // Light blocked by a translucent, not by the opaque
                        if (opaqueClear > 0.5 && allClear < 0.5) {
                            vec4 tcol4 = texture2D(shadowcolor0, sp.xy);
#if SHADOW_TEX1_GATE_FIX == 1
                            // RGB tag (see shadow.fsh): WATER = low band
                            // max(rgb)<0.325, decoded color rgb/0.30. Glass (middle
                            // band) and solid/clear white (high band) do NOT trigger
                            // caustics. Keep in sync with waterAboveShadow above.
                            vec3 tcol = clamp(tcol4.rgb / 0.30, 0.0, 1.0);
                            float tagMxW = max(max(tcol4.r, tcol4.g), tcol4.b);
                            float waterness = step(tagMxW, 0.325) * clamp((tcol.b - tcol.r) + (tcol.g - tcol.r), 0.0, 1.0);
#else
                            vec3 tcol = tcol4.rgb;
                            // tcol4.a = water tag (1) vs glass/other translucent (0): excludes stained glass
                            float waterness = step(0.75, tcol4.a) * clamp((tcol.b - tcol.r) + (tcol.g - tcol.r), 0.0, 1.0);
#endif
                            causticAmt = waterness;
                            if (waterness > 0.01) {
                                waterTint = tcol / max(luma(tcol), 0.1);
#if PIXEL_WATER_FIX == 1
                                // Real depth: RAW re-sample of shadowtex0 (1 tap, water
                                // branch only -- the step() in opaqueClear/allClear
                                // discards the value), converted to vertical meters by
                                // the single shadowZToVertical helper (same calibration
                                // as waterAboveShadow; its internal max() keeps it >= 0).
                                float z0raw = texture2D(shadowtex0, sp.xy).r;
                                causticColV = shadowZToVertical(zb - z0raw, lightW.y);
#endif
                            }
                        }
                    }
                }

                if (causticAmt > 0.01) {
                    // Real water depth above the fragment (capped at 8 blocks)
#if PIXEL_WATER_FIX == 1
                    // REAL water depth (shadow delta-z measured at the RGB-tag
                    // detection site) instead of WATER_LEVEL - y: dry ground in a
                    // lateral water shadow no longer gets 8 fictitious blocks.
                    float wdepAbove = clamp(causticColV, 0.5, 8.0);
#else
                    float wdepAbove = clamp(WATER_LEVEL - world0.y, 0.5, 8.0);
#endif
#if CAUSTICS_V4 == 1
#if CAUSTIC_FACING == 1
                    // ---- CAUSTICS_V4 + CAUSTIC_FACING (lib/settings.glsl, doc complete) ----
                    // Same math as the CAUSTIC_FACING == 0 arm below, REORDERED:
                    // cheap weight factors (sun height/rain, colortex1 normal +
                    // sun facing, absorption) BEFORE the field (vlCa4Net,
                    // 9 photons + 3 slope evals); weight <= 0.004 skips it.
                    // No shadowVis1 here: the colored-shadow detection above
                    // already is the shadow test of this site.
                    float sunF4S = smoothstep(-0.05, 0.2, lightHeight()) * (1.0 - rainStrength);
                    // This pixel is opaque, so colortex1 really holds ITS
                    // normal (raw vanilla normal, no gl_FrontFacing flip --
                    // vanilla cross models carry two opposed one-sided quads,
                    // so this IS the outward normal of the visible face).
                    vec3 nCa4S = normalize(texture2D(colortex1, uv).rgb * 2.0 - 1.0);
                    vec3 nW4S = mat3(gbufferModelViewInverse) * nCa4S;
                    // FAIL-CLOSED sun facing: dot <= 0 -> strictly 0. The
                    // CA4_WALL floor now only doses faces that SEE the sun.
                    float caFace4S = smoothstep(0.0, 0.25, dot(nW4S, lightW));
                    float caN4S = mix(CA4_WALL, 1.0,
                                      smoothstep(0.05, 0.55, nW4S.y)) * caFace4S;
                    float caW4S = clamp(CAUSTIC_STRENGTH * 0.60, 0.0, 1.0)
                                * causticAmt * sunF4S * exp(-wdepAbove * 0.13) * caN4S;
#if PERF_OCEAN == 1
                    // PERF_OCEAN (3): continuity of the early-out above.
                    caW4S *= caCutS;
#endif
                    if (caW4S > 0.004) {
#if UW_SHAFT_FIX3 == 1
                        // (A) same slide as the surface site and the beams.
                        vec2 cpos4S = VLX_PIX_XZ(world0.xz + uwShaftSlide(lightW, wdepAbove));
#else
                        vec2 cpos4S = VLX_PIX_XZ(world0.xz + vlCa4Offset(lightW, wdepAbove));
#endif
                        float soft4S = 1.0 - smoothstep(30.0, 110.0, dist) * 0.65 * CAUSTIC_DIST_FADE;
#if BLUE_NOISE == 1
                        vec2 dth4S = vec2(vlDither, blueDither(gl_FragCoord.xy + vec2(37.0, 17.0), frameCounter));
#else
                        vec2 dth4S = vec2(vlDither, fract(vlDither + hash12(floor(gl_FragCoord.xy))));
#endif
#if VLX_PHYS_SYNC == 1
                        // PHYSICS_FIELD_SYNC, site "RIVAGE" : ce pixel n'est PAS
                        // la surface (c'est un sol opaque eclaire a travers une
                        // nappe d'eau detectee lateralement dans la shadow map),
                        // donc il n'y a pas d'estampille a lire ici. Regle :
                        // ambiance (battement + biome cotier) ET la nappe
                        // traversee est au NIVEAU DE LA MER a 1.5 bloc pres -
                        // l'ocean du mod est a la mer, un bassin perche ne peut
                        // pas etre lui. Waviness = celle du dernier fragment
                        // publie (assume, voir PF_NOTES).
                        VLX_PHYS_SET(vlxPhysAmb
                                     && abs((world0.y + wdepAbove) - WATER_LEVEL) < 1.5,
                                     vlxPhysAmbWav, VL_CA5_REG(world0.y + wdepAbove));
#endif
                        // CAUSTIC_DEPTH_BLUR_V4: the column the SUN crossed to
                        // reach this dry-looking pixel (shadow delta-z, capped
                        // at 8 blocks) is the propagation depth here.
                        float ca4S = vlCaNetD(cpos4S - VL_CA5_REG(world0.y + wdepAbove),
                                              frameTimeCounter, dth4S, 0.0, soft4S, lightW, wdepAbove);
                        vec3 beer4S = exp(-wdepAbove * vlxWaterK()); // EAU9: this biome's medium
                        vec3 tint4S = vlxFloorCarrier(
                            mix(vec3(1.0), beer4S / max(beer4S.b, 1e-4), 0.35), wdepAbove);
                        color *= mix(vec3(1.0), clamp(vec3(ca4S) * tint4S, 0.0, CA_CLAMP_HI), caW4S);
                    }
#else
                    // ---- CAUSTICS_V4 (photon density net, lib/water.glsl) ----
                    // OPAQUE pixel standing in a WATER shadow: the sun crossed
                    // water before reaching it. The column is still the
                    // shadow-map delta-z of v3; what changes is the pattern
                    // and the way it lands - MULTIPLICATIVE around 1.0, so the
                    // cells between the filaments are genuinely darker instead
                    // of merely "less bright added".
#if UW_SHAFT_FIX3 == 1
                    // (A) same slide as the surface site and the beams.
                    vec2 cpos4S = VLX_PIX_XZ(world0.xz + uwShaftSlide(lightW, wdepAbove));
#else
                    vec2 cpos4S = VLX_PIX_XZ(world0.xz + vlCa4Offset(lightW, wdepAbove));
#endif
                    float soft4S = 1.0 - smoothstep(30.0, 110.0, dist) * 0.65 * CAUSTIC_DIST_FADE;
                    // Independent second axis, see the dth4 comment on the
                    // surface site: a constant per-pixel offset only walks one
                    // diagonal of the cell over time.
#if BLUE_NOISE == 1
                    vec2 dth4S = vec2(vlDither, blueDither(gl_FragCoord.xy + vec2(37.0, 17.0), frameCounter));
#else
                    vec2 dth4S = vec2(vlDither, fract(vlDither + hash12(floor(gl_FragCoord.xy))));
#endif
#if VLX_PHYS_SYNC == 1
                    // PHYSICS_FIELD_SYNC, site "RIVAGE" (bras CAUSTIC_FACING 0) :
                    // meme regle que le bras FACING (ambiance + nappe au niveau
                    // de la mer).
                    VLX_PHYS_SET(vlxPhysAmb
                                 && abs((world0.y + wdepAbove) - WATER_LEVEL) < 1.5,
                                 vlxPhysAmbWav, VL_CA5_REG(world0.y + wdepAbove));
#endif
                    // Camera is out of the water here -> compressed contrast.
                    // CA5 registration: the sheet that cast this shadow sits
                    // wdepAbove over the fragment (VL_CA5_REG is 0.0 under v4).
                    // CAUSTIC_DEPTH_BLUR_V4, same contract as the FACING arm.
                    float ca4S = vlCaNetD(cpos4S - VL_CA5_REG(world0.y + wdepAbove),
                                          frameTimeCounter, dth4S, 0.0, soft4S, lightW, wdepAbove);
                    float sunF4S = smoothstep(-0.05, 0.2, lightHeight()) * (1.0 - rainStrength);
                    // This pixel is opaque, so colortex1 really holds ITS
                    // normal. Vertical faces are DOSED by CA4_WALL, not muted:
                    // the lookup slide makes the mesh shear along the sun
                    // azimuth there, which is the pool-wall look.
                    vec3 nCa4S = normalize(texture2D(colortex1, uv).rgb * 2.0 - 1.0);
                    float caN4S = mix(CA4_WALL, 1.0,
                                      smoothstep(0.05, 0.55, (mat3(gbufferModelViewInverse) * nCa4S).y));
                    // EAU8 -- THE SHORE-BAND CYANIZER, MISSED BY EAU7. That
                    // pass aligned the through-surface site on WCOL_K_OUT and
                    // left THIS one on (0.65, 0.28, 0.12) -- a FIFTH invented
                    // spectrum, 1.5x steeper than the calibrated column --
                    // MULTIPLIED by the luma-normalised vanilla water colour
                    // (ocean: (0.53, 1.00, 1.93) -- yes, a 1.93 BLUE GAIN laid
                    // on the composed colour, ambient and torch included).
                    // Every opaque pixel standing in a lateral water shadow --
                    // i.e. the wet sand band the shore transition is made of,
                    // wdepAbove clamped to >= 0.5 -- was repainted cyan by up
                    // to R x0.68 / B x1.2 at caW4S 0.6. Same treatment as the
                    // surface site: the pack's own spectrum, the same shallow
                    // chroma bound, and the vanilla-tint chroma push is gone
                    // (its absorption is already priced by vlxWaterShadowT on
                    // the direct term; waterTint stays live in the legacy
                    // CAUSTICS_V4 0 branch below).
                    vec3 beer4S = exp(-wdepAbove * vlxWaterK()); // EAU9: this biome's medium
                    vec3 tint4S = vlxFloorCarrier(
                        mix(vec3(1.0), beer4S / max(beer4S.b, 1e-4), 0.35), wdepAbove);
                    float caW4S = clamp(CAUSTIC_STRENGTH * 0.60, 0.0, 1.0)
                                * causticAmt * sunF4S * exp(-wdepAbove * 0.13) * caN4S;
#if PERF_OCEAN == 1
                    // PERF_OCEAN (3): continuity of the early-out above.
                    caW4S *= caCutS;
#endif
                    // CA_CLAMP_HI (lib/water.glsl) is above the estimator's own
                    // peak - 2.62 under v4/v5, 8.95 under v6: the shaping's knee
                    // is the ceiling, not this line.
                    color *= mix(vec3(1.0), clamp(vec3(ca4S) * tint4S, 0.0, CA_CLAMP_HI), caW4S);
#endif
#else
#if CAUSTIC_FACING == 1
                    // ---- legacy v3 + CAUSTIC_FACING (lib/settings.glsl, doc complete) ----
                    // Same math as the CAUSTIC_FACING == 0 arm below, REORDERED:
                    // cheap scalar factors of the ADDITIVE term first, then the
                    // chromatic field (waveCausticChroma / 3x waveCausticFull)
                    // only if their product survives the 0.004 cutoff.
                    #if CAUSTIC_BLUR_FADE == 1
                        float caBlurS = smoothstep(40.0, 110.0, dist) * CAUSTIC_DIST_FADE;
                        float attS = exp(-wdepAbove * 0.13);
                        float caThrS = mix(0.20, 0.07, caBlurS);
                        float caDistS = 1.0 - caBlurS * 0.25;
                    #else
                        float attS = exp(-wdepAbove * 0.22);
                        float caThrS = 0.25;
                        float caDistS = 1.0 - smoothstep(48.0, 120.0, dist) * CAUSTIC_DIST_FADE;
                    #endif
                    // Opaque pixel -> colortex1 holds ITS normal (see the
                    // verbatim arm below). FAIL-CLOSED sun facing on top of the
                    // legacy facing-up guard.
                    vec3 nCaS = normalize(texture2D(colortex1, uv).rgb * 2.0 - 1.0);
                    vec3 nWS = mat3(gbufferModelViewInverse) * nCaS;
                    float caFaceS = smoothstep(0.0, 0.25, dot(nWS, lightW));
                    float caNS = smoothstep(0.05, 0.55, nWS.y) * caFaceS;
                    float sunF = smoothstep(-0.05, 0.2, lightHeight()) * (1.0 - rainStrength);
                    // UNCLAMPED strength in the mask: the cutoff must bound
                    // the real additive term, which scales with the raw dial.
                    float caMaskS = causticAmt * CAUSTIC_STRENGTH * 0.15
                                  * sunF * caDistS * attS * caNS;
#if PERF_OCEAN == 1
                    // PERF_OCEAN (3): continuity of the early-out above.
                    caMaskS *= caCutS;
#endif
                    if (caMaskS > 0.004) {
                        vec2 cpos = VLX_PIX_XZ(world0.xz + lightW.xz / max(lightW.y, 0.15) * wdepAbove);
                        float cscaleS = 0.70 + 0.60 * vnoise(VLX_PIX_XZ(world0.xz) * 0.13 + frameTimeCounter * 0.04);
                        #if CAUSTIC_BLUR_FADE == 1
                            vec3 caChr = waveCausticChroma(cpos, frameTimeCounter, wdepAbove, caBlurS, lightW.xz * 0.013);
                        #else
                            vec3 caChr = vec3(
                                waveCausticFull(cpos + lightW.xz * 0.013, frameTimeCounter, wdepAbove).x,
                                waveCausticFull(cpos,                     frameTimeCounter, wdepAbove).x,
                                waveCausticFull(cpos - lightW.xz * 0.013, frameTimeCounter, wdepAbove).x
                            );
                        #endif
                        vec3 beerS = exp(-wdepAbove * vec3(0.65, 0.28, 0.12));
                        vec3 caTintS = mix(vec3(1.0), beerS / max(beerS.b, 1e-4), 0.35);
                        vec3 caV2 = clamp(caChr - caThrS, 0.0, 1.0) * cscaleS * attS * caTintS * caNS;
                        vec3 wTintS = mix(vec3(1.0), waterTint, 0.35);
#if PERF_OCEAN == 1
                        color += gLightC * wTintS * caV2 * causticAmt
                               * CAUSTIC_STRENGTH * 0.15 * sunF * caDistS * caCutS;
#else
                        color += gLightC * wTintS * caV2 * causticAmt
                               * CAUSTIC_STRENGTH * 0.15 * sunF * caDistS;
#endif
                    }
#else
                    vec2 cpos = VLX_PIX_XZ(world0.xz + lightW.xz / max(lightW.y, 0.15) * wdepAbove);
                    float cscaleS = 0.70 + 0.60 * vnoise(VLX_PIX_XZ(world0.xz) * 0.13 + frameTimeCounter * 0.04);
                    #if CAUSTIC_BLUR_FADE == 1
                        // Fade-to-blur here too: 3 offset soft caustic samples
                        // (chromatic dispersion PRESERVED), threshold lowered with
                        // the blur, depth extinction pushed back -- distance
                        // SOFTENS instead of fading out.
                        float caBlurS = smoothstep(40.0, 110.0, dist) * CAUSTIC_DIST_FADE;
                        // Physical field evaluated 1x, filament network 3x
                        vec3 caChr = waveCausticChroma(cpos, frameTimeCounter, wdepAbove, caBlurS, lightW.xz * 0.013);
                        float attS = exp(-wdepAbove * 0.13);
                        float caThrS = mix(0.20, 0.07, caBlurS);
                        float caDistS = 1.0 - caBlurS * 0.25;
                    #else
                        // Chromatic dispersion: 3 offset waveCausticFull samples (offset lightW.xz*0.013).
                        vec3 caChr = vec3(
                            waveCausticFull(cpos + lightW.xz * 0.013, frameTimeCounter, wdepAbove).x,
                            waveCausticFull(cpos,                     frameTimeCounter, wdepAbove).x,
                            waveCausticFull(cpos - lightW.xz * 0.013, frameTimeCounter, wdepAbove).x
                        );
                        float attS = exp(-wdepAbove * 0.22);
                        float caThrS = 0.25;
                        float caDistS = 1.0 - smoothstep(48.0, 120.0, dist) * CAUSTIC_DIST_FADE;
                    #endif
                    // Colored Beer-Lambert: red dies fast, blue persists
                    vec3 beerS = exp(-wdepAbove * vec3(0.65, 0.28, 0.12));
                    // Threshold (edges only) + desaturated/capped tint via beerS;
                    // waterTint is softened (mix toward white 0.35) to avoid an
                    // over-cyan cast.
                    vec3 caTintS = mix(vec3(1.0), beerS / max(beerS.b, 1e-4), 0.35);
                    // Edge guard: the pattern (a horizontal field projected along
                    // the sun) stretches on VERTICAL faces into TAA-flickering
                    // moire -> weight by "facing up". This pixel is OPAQUE, so
                    // colortex1 really holds ITS normal (same-uv tap already paid
                    // by the wetness / contact-shadow blocks when enabled).
                    vec3 nCaS = normalize(texture2D(colortex1, uv).rgb * 2.0 - 1.0);
                    float caNS = smoothstep(0.05, 0.55, (mat3(gbufferModelViewInverse) * nCaS).y);
                    vec3 caV2 = clamp(caChr - caThrS, 0.0, 1.0) * cscaleS * attS * caTintS * caNS;
                    float sunF = smoothstep(-0.05, 0.2, lightHeight()) * (1.0 - rainStrength);
                    vec3 wTintS = mix(vec3(1.0), waterTint, 0.35);
#if PERF_OCEAN == 1
                    // PERF_OCEAN (3): continuity of the early-out above (the
                    // CAUSTIC_BLUR_FADE path floors caDistS at 0.75).
                    color += gLightC * wTintS * caV2 * causticAmt
                           * CAUSTIC_STRENGTH * 0.15 * sunF * caDistS * caCutS;
#else
                    color += gLightC * wTintS * caV2 * causticAmt
                           * CAUSTIC_STRENGTH * 0.15 * sunF * caDistS;
#endif
#endif
#endif
                }

                // UNDERWATER caustics (eye submerged): no reliable colored-shadow
                // detection here -> dedicated branch straight on the opaque floor.
                if (isEyeInWater == 1) {
#if PIXEL_WATER_FIX == 1
                    // Estimated local surface >= submerged eye (same trick as the
                    // god-ray surface clamp): in a lake above Y63 the floor
                    // caustics get a plausible depth again. Unchanged in the ocean.
                    float wdepUW = clamp(max(WATER_LEVEL, cameraPosition.y + 0.4) - world0.y, 0.5, 12.0);
#else
                    float wdepUW = clamp(WATER_LEVEL - world0.y, 0.5, 12.0);
#endif
#if PERF_CAUSTIC_LOD == 1
                    // PERF_CAUSTIC_LOD (B): THE DISTANCE CUT THIS SITE NEVER
                    // HAD. The two eye-dry sites stop at 150 blocks (PERF_OCEAN
                    // caCut4 / caCutS); this one paid the full field to the far
                    // plane. Underwater it does not have to: the fog is
                    // exp2(-0.040 * dist) (WCOL_UW_DENS, FLAT with depth), so
                    // 25.0% of the floor's own colour survives at 50 blocks and
                    // 17.0% at 64 -- and what the caustic modulates is that
                    // remainder. Measured residual removed: <= 2.8% rms of the
                    // pixel across the fade band, <= 1.8% at the cut.
                    // BOTH BOUNDS ARE ANCHORED, NOT PICKED. 50 is where soft4U
                    // (16 -> 50) has finished widening the photon footprint, so
                    // no second distance law overlaps the first -- the argument
                    // CALIBRATION V5 E makes about `att`. 64 is where the pack's
                    // OWN submerged caustic weight already reaches exactly zero
                    // under v3 (caDistU = 1 - smoothstep(28, 64, dist)), which
                    // is why the CAUSTICS_V4 == 0 && CAUSTIC_BLUR_FADE == 0 form
                    // below is a pure GATE on an already-zero weight: bit-
                    // identical render there, exactly like caCut4's own
                    // special case at the through-water site.
                    // Honors CAUSTIC_DIST_FADE 0.0 ("no distance fade"): no cut.
#if CAUSTICS_V4 == 0 && CAUSTIC_BLUR_FADE == 0
                    float caCutU = (CAUSTIC_DIST_FADE >= 1.0)
                                 ? 1.0 - step(64.0, dist)
                                 : ((CAUSTIC_DIST_FADE > 0.0)
                                    ? 1.0 - smoothstep(50.0, 64.0, dist) : 1.0);
#else
                    float caCutU = (CAUSTIC_DIST_FADE > 0.0)
                                 ? 1.0 - smoothstep(50.0, 64.0, dist) : 1.0;
#endif
                    if (caCutU > 0.0) {
#else
                    { // PERF_CAUSTIC_LOD (B): scope of the distance cut
#endif
#if CAUSTICS_V4 == 1
#if CAUSTIC_FACING == 1
                    // ---- CAUSTICS_V4 + CAUSTIC_FACING (lib/settings.glsl, doc complete) ----
                    // THE reported-bug site (submerged eye): caustics painted on
                    // the shadow side of kelp cross-quads and fish flanks.
                    // shadowVis1 cannot save zero-thickness geometry (its own
                    // depth ~= the tap's depth under a constant bias), and
                    // CA4_WALL floored every non-up face at 0.75 -- only a
                    // normal test can kill the back side. Same math as the
                    // CAUSTIC_FACING == 0 arm below, REORDERED: cheap weight
                    // factors BEFORE the field (vlCa4Net) AND the shadowVis1
                    // tap; weight <= 0.004 skips both.
                    float sunPre4U = smoothstep(-0.05, 0.2, lightHeight()) * (1.0 - rainStrength);
                    // Opaque pixel -> colortex1 holds ITS normal (raw vanilla
                    // normal, no gl_FrontFacing flip; vanilla cross models
                    // carry two opposed one-sided quads, so this is the
                    // outward normal of the face the camera sees).
                    vec3 nCa4U = normalize(texture2D(colortex1, uv).rgb * 2.0 - 1.0);
                    vec3 nW4U = mat3(gbufferModelViewInverse) * nCa4U;
                    // FAIL-CLOSED sun facing: dot <= 0 (face turned away from
                    // the sun, kelp back side, fish shadow flank) -> strictly
                    // 0. The CA4_WALL floor only doses sun-facing walls now.
                    float caFace4U = smoothstep(0.0, 0.25, dot(nW4U, lightW));
                    float caN4U = mix(CA4_WALL, 1.0,
                                      smoothstep(0.05, 0.55, nW4U.y)) * caFace4U;
                    float caW4U = clamp(CAUSTIC_STRENGTH * UW_CAUSTIC_LIGHT * 0.75, 0.0, 1.0)
                                * sunPre4U * exp(-wdepUW * 0.13) * caN4U;
#if PERF_CAUSTIC_LOD == 1
                    // (B): continuity of the distance cut above.
                    caW4U *= caCutU;
                    // (A): the shadow tap moves INTO the early-out mask. It used
                    // to be taken one line below, i.e. AFTER the branch that has
                    // already paid vlCa4Net's 2166 ALU -- a shadowed floor paid
                    // the whole field and then multiplied it by zero, which the
                    // "weight <= 0.004 skips both" above claimed it did not.
                    // Same tap, same predicate: the tap COUNT does not change.
                    // shadowVis1 is a step(), so caW4U * 1.0 == caW4U exactly
                    // and caW4U * 0.0 == 0.0 -- the second test is exactly
                    // "shadowVis1 != 0" and the skipped body ended in
                    // mix(vec3(1.0), <finite>, 0.0) == vec3(1.0). Bit-identical.
                    if (caW4U > 0.004) caW4U *= shadowVis1(VLX_PIX_FLOOR(viewPos));
#endif
                    if (caW4U > 0.004) {
#if PERF_CAUSTIC_LOD == 0
                        caW4U *= shadowVis1(VLX_PIX_FLOOR(viewPos)); // a shadowed floor gets NO caustics
#endif
#if UW_SHAFT_FIX3 == 1
                        // (A) same slide as the shafts -- see the verbatim arm.
                        vec2 cpos4U = VLX_PIX_XZ(world0.xz + uwShaftSlide(lightW, wdepUW));
#else
                        vec2 cpos4U = VLX_PIX_XZ(world0.xz + vlCa4Offset(lightW, wdepUW));
#endif
                        float soft4U = 1.0 - smoothstep(16.0, 50.0, dist) * 0.65 * CAUSTIC_DIST_FADE;
#if BLUE_NOISE == 1
                        vec2 dth4U = vec2(vlDither, blueDither(gl_FragCoord.xy + vec2(37.0, 17.0), frameCounter));
#else
                        vec2 dth4U = vec2(vlDither, fract(vlDither + hash12(floor(gl_FragCoord.xy))));
#endif
#if VLX_PHYS_SYNC == 1
                        // PHYSICS_FIELD_SYNC, site "OEIL IMMERGE" : le pixel est
                        // le FOND, jamais la surface, donc aucune estampille.
                        // Regle : vlxPhysEye (battement + biome cotier + oeil
                        // dans l'eau + oeil sous le niveau de la mer) ET la
                        // nappe reconstruite au-dessus du fond est bien a la mer.
                        VLX_PHYS_SET(vlxPhysEye
                                     && abs((world0.y + wdepUW) - WATER_LEVEL) < 1.5,
                                     vlxPhysAmbWav, VL_CA5_REG(world0.y + wdepUW));
#endif
                        // CAUSTIC_DEPTH_BLUR_V4: eye submerged, wdepUW is the
                        // column above the lit floor -- the same propagation
                        // depth, read from the other side of the surface.
                        float ca4U = vlCaNetD(cpos4U - VL_CA5_REG(world0.y + wdepUW),
                                              frameTimeCounter, dth4U, 1.0, soft4U, lightW, wdepUW);
                        vec3 tint4U = mix(vec3(1.0), vec3(0.35, 0.80, 1.0), 0.5);
                        color *= mix(vec3(1.0), clamp(vec3(ca4U) * tint4U, 0.0, CA_CLAMP_HI), caW4U);
                    }
#else
#if PERF_CAUSTIC_LOD == 1
                    // PERF_CAUSTIC_LOD (A): sunF4U's declaration (originally
                    // sitting AFTER the field) is hoisted here so the shadow tap
                    // gates the field instead of following it. Pure code motion:
                    // lightHeight(), rainStrength and viewPos are all live above
                    // this point and nothing between them is read. shadowVis1 is
                    // a step() and the two smoothstep/rain factors are the same
                    // ones the weight carries, so `sunF4U > 0.0` skips exactly
                    // the pixels whose caW4U was already 0, and the skipped tail
                    // ended in mix(vec3(1.0), <finite>, 0.0) == vec3(1.0).
                    // Braces UNCONDITIONAL (the UW_SHAFT_BOUND idiom): gate 0
                    // keeps the declaration where it was and only gains a scope.
                    float sunF4U = smoothstep(-0.05, 0.2, lightHeight()) * (1.0 - rainStrength)
                                 * shadowVis1(VLX_PIX_FLOOR(viewPos)); // a shadowed floor gets NO caustics
                    if (sunF4U > 0.0)
#endif
                    { // PERF_CAUSTIC_LOD (A): scope of the sunF4U early-out
                    // ---- CAUSTICS_V4 (photon density net, lib/water.glsl) ----
                    // Eye SUBMERGED: full contrast, no compression toward 1.0
                    // (the estimator's own range: 10.07:1 under v4, 12.4:1
                    // under v5 - one figure, unified with lib/water.glsl's
                    // CALIBRATION V5 F and M).
                    // There is no moving interface between the eye and
                    // the floor down here, so the hard net reads as light
                    // instead of as noise. Same field and same lookup as the
                    // volumetric shafts below, so the beams land exactly on
                    // the spots they light.
#if UW_SHAFT_FIX3 == 1
                    // (A) THE registration that must not break: the comment
                    // above states it -- "same field and same lookup as the
                    // volumetric shafts below, so the beams land exactly on
                    // the spots they light". The shafts now slide along
                    // uwShaftSlide, so this site does too.
                    vec2 cpos4U = VLX_PIX_XZ(world0.xz + uwShaftSlide(lightW, wdepUW));
#else
                    vec2 cpos4U = VLX_PIX_XZ(world0.xz + vlCa4Offset(lightW, wdepUW));
#endif
                    // Underwater visibility is short -> the photon footprint
                    // widens over a much closer window than from the bank.
                    float soft4U = 1.0 - smoothstep(16.0, 50.0, dist) * 0.65 * CAUSTIC_DIST_FADE;
                    // Independent second axis, see the dth4 comment on the
                    // surface site: a constant per-pixel offset only walks one
                    // diagonal of the cell over time.
#if BLUE_NOISE == 1
                    vec2 dth4U = vec2(vlDither, blueDither(gl_FragCoord.xy + vec2(37.0, 17.0), frameCounter));
#else
                    vec2 dth4U = vec2(vlDither, fract(vlDither + hash12(floor(gl_FragCoord.xy))));
#endif
#if VLX_PHYS_SYNC == 1
                    // PHYSICS_FIELD_SYNC, site "OEIL IMMERGE" (bras
                    // CAUSTIC_FACING 0) : meme regle que le bras FACING.
                    VLX_PHYS_SET(vlxPhysEye
                                 && abs((world0.y + wdepUW) - WATER_LEVEL) < 1.5,
                                 vlxPhysAmbWav, VL_CA5_REG(world0.y + wdepUW));
#endif
                    // CA5 registration: the surface is wdepUW over the floor,
                    // which is the estimated local sheet under PIXEL_WATER_FIX
                    // and WATER_LEVEL otherwise (VL_CA5_REG is 0.0 under v4).
                    // CAUSTIC_DEPTH_BLUR_V4, same contract as the FACING arm.
                    float ca4U = vlCaNetD(cpos4U - VL_CA5_REG(world0.y + wdepUW),
                                          frameTimeCounter, dth4U, 1.0, soft4U, lightW, wdepUW);
#if PERF_CAUSTIC_LOD == 0
                    float sunF4U = smoothstep(-0.05, 0.2, lightHeight()) * (1.0 - rainStrength)
                                 * shadowVis1(VLX_PIX_FLOOR(viewPos)); // a shadowed floor gets NO caustics
#endif
                    vec3 nCa4U = normalize(texture2D(colortex1, uv).rgb * 2.0 - 1.0);
                    float caN4U = mix(CA4_WALL, 1.0,
                                      smoothstep(0.05, 0.55, (mat3(gbufferModelViewInverse) * nCa4U).y));
                    // Softened cyan cast, as v3. The net itself has NO colour
                    // of its own: it multiplies the sun, which is in turn
                    // multiplied by the block albedo - the blue comes from the
                    // water tint applied elsewhere.
                    vec3 tint4U = mix(vec3(1.0), vec3(0.35, 0.80, 1.0), 0.5);
                    // Submerged weight 0.75 vs 0.60 at the two from-outside
                    // sites: the term is centred on 1.0, so a stronger weight
                    // buys contrast without touching the exposure, and this is
                    // the one viewpoint where the description wants the net at
                    // full strength. UW_CAUSTIC_LIGHT still doses it.
                    float caW4U = clamp(CAUSTIC_STRENGTH * UW_CAUSTIC_LIGHT * 0.75, 0.0, 1.0)
                                * sunF4U * exp(-wdepUW * 0.13) * caN4U;
#if PERF_CAUSTIC_LOD == 1
                    // (B): continuity of the distance cut above.
                    caW4U *= caCutU;
#endif
                    // CA_CLAMP_HI (lib/water.glsl) is above the estimator's own
                    // peak - 2.62 under v4/v5, 8.95 under v6: the shaping's knee
                    // is the ceiling, not this line. This is the SUBMERGED site,
                    // where the term runs at full contrast (0.014..6.86), so it
                    // is the one that would have lost the most to the old 2.7 -
                    // 3.49% of its area clipped and 2.58% of its light thrown
                    // away, i.e. exactly the cusps v6 exists to restore.
                    color *= mix(vec3(1.0), clamp(vec3(ca4U) * tint4U, 0.0, CA_CLAMP_HI), caW4U);
                    } // PERF_CAUSTIC_LOD (A): scope of the sunF4U early-out
#endif
#else
#if CAUSTIC_FACING == 1
                    // ---- legacy v3 + CAUSTIC_FACING (lib/settings.glsl, doc complete) ----
                    // Same math as the CAUSTIC_FACING == 0 arm below, REORDERED:
                    // cheap scalar factors of the ADDITIVE term first, then the
                    // chromatic field (waveCausticChroma / 3x waveCausticFull)
                    // AND the shadowVis1 tap only past the 0.004 cutoff.
                    #if CAUSTIC_BLUR_FADE == 1
                        float caBlurU = smoothstep(20.0, 56.0, dist) * CAUSTIC_DIST_FADE;
                        float attU = exp(-wdepUW * 0.13);
                        float caThrU = mix(0.20, 0.07, caBlurU);
                        float caDistU = 1.0 - caBlurU * 0.25;
                    #else
                        float attU = exp(-wdepUW * 0.22);
                        float caThrU = 0.25;
                        float caDistU = 1.0 - smoothstep(28.0, 64.0, dist) * CAUSTIC_DIST_FADE;
                    #endif
#if PERF_CAUSTIC_LOD == 1
                    // (B): continuity of the distance cut above. caDistU is the
                    // ONE factor both consumers share (caMaskU and the additive
                    // term), so one multiply carries the fade into both. Under
                    // CAUSTIC_BLUR_FADE == 0 with CAUSTIC_DIST_FADE 1.0 this is
                    // multiplying an already-zero factor past 64 blocks -- which
                    // is exactly why the gate is bit-identical there.
                    caDistU *= caCutU;
#endif
                    float sunPreU = smoothstep(-0.05, 0.2, lightHeight()) * (1.0 - rainStrength);
                    // Opaque pixel -> colortex1 holds the floor normal (see the
                    // verbatim arm). FAIL-CLOSED sun facing on top of the
                    // legacy facing-up guard: kelp back sides and fish shadow
                    // flanks go strictly to 0.
                    vec3 nCaU = normalize(texture2D(colortex1, uv).rgb * 2.0 - 1.0);
                    vec3 nWU = mat3(gbufferModelViewInverse) * nCaU;
                    float caFaceU = smoothstep(0.0, 0.25, dot(nWU, lightW));
                    float caNU = smoothstep(0.05, 0.55, nWU.y) * caFaceU;
                    // UNCLAMPED strength in the mask: the cutoff must bound
                    // the real additive term, which scales with the raw dials.
                    float caMaskU = CAUSTIC_STRENGTH * 0.16 * UW_CAUSTIC_LIGHT
                                  * sunPreU * caDistU * attU * caNU;
#if PERF_CAUSTIC_LOD == 1
                    // (A): the shadow tap moves INTO the early-out mask. It used
                    // to be taken one line below -- first statement of the body,
                    // but the body still ran the 3 chromatic field evaluations
                    // for a term sunFU had already forced to zero. caMaskU is a
                    // TEST-ONLY quantity (it never reaches the colour), so
                    // folding the tap into it changes nothing but the branch,
                    // and shadowVis1 is a step(), so sunFU below is exactly
                    // sunPreU * 1.0 on every pixel that survives. Same tap,
                    // same predicate: the tap COUNT does not change.
                    if (caMaskU > 0.004) caMaskU *= shadowVis1(VLX_PIX_FLOOR(viewPos));
#endif
                    if (caMaskU > 0.004) {
#if PERF_CAUSTIC_LOD == 1
                        float sunFU = sunPreU; // the tap is already in caMaskU
#else
                        float sunFU = sunPreU * shadowVis1(VLX_PIX_FLOOR(viewPos));
#endif
                        vec2 cposU = VLX_PIX_XZ(world0.xz + lightW.xz / max(lightW.y, 0.15) * wdepUW);
                        float cscaleUW = 0.70 + 0.60 * vnoise(VLX_PIX_XZ(world0.xz) * 0.13 + frameTimeCounter * 0.04);
                        #if CAUSTIC_BLUR_FADE == 1
                            vec3 caUWc = waveCausticChroma(cposU, frameTimeCounter, wdepUW, caBlurU, lightW.xz * 0.013);
                        #else
                            vec3 caUWc = vec3(
                                waveCausticFull(cposU + lightW.xz * 0.013, frameTimeCounter, wdepUW).x,
                                waveCausticFull(cposU,                     frameTimeCounter, wdepUW).x,
                                waveCausticFull(cposU - lightW.xz * 0.013, frameTimeCounter, wdepUW).x
                            );
                        #endif
                        vec3 beerU = exp(-wdepUW * vec3(0.65, 0.28, 0.12));
                        vec3 caTintU = mix(vec3(1.0), vec3(0.35, 0.80, 1.0), 0.5);
                        color += gLightC * caTintU
                               * clamp(caUWc - caThrU, 0.0, 1.0) * cscaleUW * attU * beerU
                               * CAUSTIC_STRENGTH * 0.16 * sunFU * caDistU * caNU
                               * UW_CAUSTIC_LIGHT; // CONFIG: submerged floor caustics dial
                    }
#else
#if PERF_CAUSTIC_LOD == 1
                    // PERF_CAUSTIC_LOD (A): sunFU's declaration (originally
                    // sitting AFTER the field) is hoisted here so the shadow tap
                    // gates the 3 chromatic field evaluations instead of
                    // following them. Pure code motion: lightHeight(),
                    // rainStrength and viewPos are all live above this point and
                    // nothing between them is read. shadowVis1 is a step(), so
                    // `sunFU > 0.0` skips exactly the pixels whose additive term
                    // was already identically zero. Braces UNCONDITIONAL (the
                    // UW_SHAFT_BOUND idiom): gate 0 keeps the declaration where
                    // it was and only gains a scope.
                    float sunFU = smoothstep(-0.05, 0.2, lightHeight()) * (1.0 - rainStrength) * shadowVis1(VLX_PIX_FLOOR(viewPos));
                    if (sunFU > 0.0)
#endif
                    { // PERF_CAUSTIC_LOD (A): scope of the sunFU early-out
                    vec2 cposU = VLX_PIX_XZ(world0.xz + lightW.xz / max(lightW.y, 0.15) * wdepUW);
                    float cscaleUW = 0.70 + 0.60 * vnoise(VLX_PIX_XZ(world0.xz) * 0.13 + frameTimeCounter * 0.04);
                    #if CAUSTIC_BLUR_FADE == 1
                        // Submerged eye: same fade-to-blur, closer window
                        // (20..56 blocks) since underwater visibility is short.
                        float caBlurU = smoothstep(20.0, 56.0, dist) * CAUSTIC_DIST_FADE;
                        // Physical field evaluated 1x, filament network 3x
                        vec3 caUWc = waveCausticChroma(cposU, frameTimeCounter, wdepUW, caBlurU, lightW.xz * 0.013);
                        float attU = exp(-wdepUW * 0.13);
                        float caThrU = mix(0.20, 0.07, caBlurU);
                        float caDistU = 1.0 - caBlurU * 0.25;
                    #else
                        vec3 caUWc = vec3(
                            waveCausticFull(cposU + lightW.xz * 0.013, frameTimeCounter, wdepUW).x,
                            waveCausticFull(cposU,                     frameTimeCounter, wdepUW).x,
                            waveCausticFull(cposU - lightW.xz * 0.013, frameTimeCounter, wdepUW).x
                        );
                        float attU = exp(-wdepUW * 0.22);
                        float caThrU = 0.25;
                        float caDistU = 1.0 - smoothstep(28.0, 64.0, dist) * CAUSTIC_DIST_FADE;
                    #endif
#if PERF_CAUSTIC_LOD == 1
                    // (B): continuity of the distance cut above (see the
                    // CAUSTIC_FACING == 1 arm for why this is bit-identical
                    // under CAUSTIC_BLUR_FADE == 0 / CAUSTIC_DIST_FADE 1.0).
                    caDistU *= caCutU;
#else
                    float sunFU = smoothstep(-0.05, 0.2, lightHeight()) * (1.0 - rainStrength) * shadowVis1(VLX_PIX_FLOOR(viewPos));
#endif
                    vec3 beerU = exp(-wdepUW * vec3(0.65, 0.28, 0.12));
                    // Submerged eye: threshold + softened cyan tint (mix toward white 0.5).
                    vec3 caTintU = mix(vec3(1.0), vec3(0.35, 0.80, 1.0), 0.5);
                    // Edge guard for the submerged eye (border flicker): this pixel
                    // is opaque, so colortex1 holds the floor normal.
                    vec3 nCaU = normalize(texture2D(colortex1, uv).rgb * 2.0 - 1.0);
                    float caNU = smoothstep(0.05, 0.55, (mat3(gbufferModelViewInverse) * nCaU).y);
                    // Reference case (defaults, noon, sand 3 blocks under the
                    // surface, dist < 20 so caBlurU = 0, block top so caNU = 1):
                    // wdepUW = 3 gives spectral sigma ~0.15, so the 6 short wave
                    // trains survive; focal cf = 0.75 -> intensity ~2..6 on the
                    // folds. With caThrU 0.20 the filaments saturate to 1.0 while
                    // the flat background sits at ~0.16, attU = 0.68 and beerU =
                    // (0.14, 0.43, 0.70): sharp cyan-white filaments dancing on the
                    // sand, ~6x contrast over the background glow. If the spectral
                    // sigma is raised too far, only the long swell survives and the
                    // output goes flat -- a uniform milky veil with no filaments.
                    color += gLightC * caTintU
                           * clamp(caUWc - caThrU, 0.0, 1.0) * cscaleUW * attU * beerU
                           * CAUSTIC_STRENGTH * 0.16 * sunFU * caDistU * caNU
                           * UW_CAUSTIC_LIGHT; // CONFIG: submerged floor caustics dial
                    } // PERF_CAUSTIC_LOD (A): scope of the sunFU early-out
#endif
#endif
                    } // PERF_CAUSTIC_LOD (B): scope of the distance cut
                }
            }
            #endif
        }

        // Lightning strike: the landscape flares around the impact point
        #ifdef LIGHTNING_FX
        if (lightningBoltPosition.w > 0.5) {
            float ldist = distance(world0.xz, lightningBoltPosition.xz);
            float burst = 16.0 / (1.0 + ldist * ldist * 0.002);
            color += vec3(0.72, 0.80, 1.0) * burst * 0.13 * skyl;
        }
        #endif

        // --- Light aerial perspective (the volumetrics do the rest) ---
        // CSE: shared memoized getSkyBase(worldDir, sunW) (see top of main)
        if (!skyBaseWDok) { skyBaseWD = getSkyBase(worldDir, sunW); skyBaseWDok = true; }
        vec3 fogCol = skyBaseWD;
        // Per-biome atmosphere: Minecraft supplies fogColor (warm/tan in the
        // desert, green in swamps, icy in taiga) -- used to tint the haze
        #ifdef BIOME_ATMOSPHERE
            vec3 biomeFog = toLinear(fogColor) * 1.6;
            if (luma(fogColor) > 0.001) {
                // EYE gate, not pixel skyl: fog COLOR must match across
                // neighbours at equal distance (see fogEyeGate declaration).
                fogCol = mix(fogCol, biomeFog * (0.4 + luma(fogCol)),
                             0.55 * BIOME_ATMO_STRENGTH * fogEyeGate);
            }
        #endif
// DISTANCE_FOG=0 (default): the vanilla fog "wall" is CUT -- depth is dressed
// only by the volumetric fogs below (ATMO_FOG/HEIGHT_FOG/VL/CAVE_FOG), which
// stay fully active. fogCol is still computed: ATMO_FOG consumes it.
#if DISTANCE_FOG == 1
#ifdef DISTANT_HORIZONS
        // DH active: the vanilla fog wall that hid the end of the render distance
        // is pushed out to the LOD edge (the world continues past far). Same
        // formula, dhRenderDistance scale -> fog stays a CONTINUOUS function of
        // dist on both sides of the vanilla/DH seam.
        float fogF = 1.0 - exp(-pow(fogDist / (max(float(dhRenderDistance), far) * 0.85), 2.5) * 0.75 * FOG_DENSITY);
#else
        float fogF = 1.0 - exp(-pow(fogDist / (far * 0.85), 2.5) * 0.75 * FOG_DENSITY);
#endif
        color = mix(color, fogCol, clamp(fogF, 0.0, 1.0));
#endif

        #ifdef ATMO_FOG
        // Mid-field atmospheric fog (Beer-Lambert): the vanilla layer above only
        // acts at the very end of far, while this one lays a progressive haze from
        // ~60 blocks, modulated by altitude (CONTINUOUS exp from WATER_LEVEL) and
        // reinforced at dusk. Gated by the EYE (fogEyeGate), NOT the receiver
        // skylight: the old per-pixel skyl gate starved dark distant receivers
        // (canopy floors, cave mouths, overhangs) of the very haze that should
        // blend them -> unfogged dark holes at equal distance. Caves stay
        // fog-free through the eye gate when YOU are underground.
        if (isEyeInWater == 0) {
            float atmoSky = fogEyeGate;
            if (atmoSky > 0.001) {
                float atmoDusk = clamp(1.0 - abs(sunHeight()) * 4.0, 0.0, 1.0) * smoothstep(-0.14, -0.04, sunHeight()); // asymmetric: keeps it off at night
                float hMid = (cameraPosition.y + fogW0.y) * 0.5; // GLASS_SEE_THROUGH: surface behind the pane, not the pane
                float atmoH = exp(-max(hMid - WATER_LEVEL, 0.0) * 0.012);
                // MIRROR RELIEF (same wMirror contract as the VL density): a
                // mirror-dominant water pixel shows SKY light that crossed the
                // sea-level haze once, steeply -- not the full grazing air
                // column this Beer-Lambert prices. Without it, ~10% of blue
                // fogCol at 60 blocks repaints the mirror as a flat veil that
                // no water-volume constant can touch. Opaque/sky/underwater
                // pixels (wMirror = 0) keep the exact previous fog.
                // dhFogK : rescale DH de la densite (voile de profondeur, pas
                // mur — voir la declaration). 1.0 sans DH.
                float atmoTau = fogDist * dhFogK * 0.0018 * ATMO_FOG_DENSITY * atmoH
                              * (1.0 + atmoDusk * 0.6 * ATMO_FOG_DUSK_BOOST)
                              * (1.0 + rainStrength * 0.8)
                              * (1.0 - 0.55 * clamp(wMirror, 0.0, 1.0));
                #if BIOME_CLIMATE == 1
                // Biome climate (lib/biome.glsl, uniform): hot +15%, humid
                // +15%, cold -15% density. MIRRORED in the DH block below.
                atmoTau *= biomeFogDensMul();
                #endif
                float atmoF = 1.0 - exp(-atmoTau);
                // Warm in-scatter toward the sun (sunset aerial perspective)
                float vdotS = max(dot(worldDir, sunW), 0.0);
#ifdef FOG_SHADOWS_ACTIVE
                // FOG_SHADOWS: the solar glow follows the shared shadow probe,
                // the sky-ambient haze keeps its 75% floor (see fogSunVis).
                vec3 atmoCol = fogCol * (0.85 + 0.15 * atmoDusk) * fogShadAmb
                             + gLightC * pow(vdotS, 6.0) * 0.25 * (0.3 + 0.7 * atmoDusk) * fogShadDir;
#else
                vec3 atmoCol = fogCol * (0.85 + 0.15 * atmoDusk)
                             + gLightC * pow(vdotS, 6.0) * 0.25 * (0.3 + 0.7 * atmoDusk);
#endif
                #if BIOME_CLIMATE == 1
                atmoCol *= biomeFogTint(); // warm dust (hot) / faint grey-green (humid)
                #endif
                color = mix(color, atmoCol, clamp(atmoF, 0.0, 0.85) * atmoSky);
            }
        }
        #endif

        #ifdef AERIAL_PERSPECTIVE
            // Aerial perspective: in-scattering that strengthens with distance and
            // tints toward the sun -> golden halo on distant relief, more depth.
            float apVdotS = max(dot(worldDir, sunW), 0.0);
            // dhFogK : meme rescale DH que les autres voiles de distance.
            float apAmt = 1.0 - exp(-fogDist * dhFogK / (far * 0.55));
            vec3 apCol = gLightC * (0.35 + 0.65 * pow(apVdotS, 5.0));
            // Eye gate: even in-scatter at equal dist (no receiver-skyl holes)
#ifdef FOG_SHADOWS_ACTIVE
            // FOG_SHADOWS: pure sun in-scatter -> fully follows the probe.
            color += apCol * apAmt * 0.10 * fogEyeGate * fogShadDir;
#else
            color += apCol * apAmt * 0.10 * fogEyeGate;
#endif
        #endif

        // --- Cave ambience: colored haze in sky-less areas ---
        #ifdef CAVE_FOG
#if DIMENSION_FX == 1
        // Nether / End: skylight is 0 everywhere, the dimensional fog owns
        // the haze (uniform branch, exact no-op in the Overworld).
        if (isEyeInWater == 0 && dimNether() < 0.5 && dimEnd() < 0.5) {
#else
        if (isEyeInWater == 0) {
#endif
            float cave = (1.0 - skyl) * smoothstep(0.0, 0.35, 1.0 - data2.g);
            float depthCave = clamp((WATER_LEVEL - fogW0.y) / 64.0, 0.0, 1.0);
            // fogCaveW: 1.0 everywhere except on a pane whose fogDist moved
            // past it -- 'cave' would then read the PANE's lightmap while the
            // Beer-Lambert term reads the landscape behind it. See fogCaveW at
            // its declaration.
            float cf = (1.0 - exp(-fogDist * 0.018)) * cave * CAVE_FOG_STRENGTH * fogCaveW;
            // Deep target is NEUTRAL dark gray-blue, only darker than the shallow
            // color. The old (0.10, 0.05, 0.08) target (R = 2xG) tinted every
            // deep cave MAGENTA -- fog must never gain chroma with depth.
            vec3 caveCol = mix(vec3(0.04, 0.06, 0.10), vec3(0.030, 0.036, 0.045), depthCave)
                         // CL GAP: vanilla-warm on purpose, see the water-fog scatter note.
                         + getTorchColor() * data2.r * data2.r * 0.15;
            color = mix(color, caveCol, clamp(cf, 0.0, 0.7));
        }
        #endif
    }

#ifdef DISTANT_HORIZONS
    // ============ FOG ON DH TERRAIN (distant LODs) ============
    // LODs do NOT go through the opaque branch above (their gbuffer data does
    // not exist, so isSky stayed true). The SAME aerial perspective + ATMO fog
    // as vanilla terrain is applied here with the DH-reconstructed position:
    // this fog is what blends the vanilla terrain -> DH LOD transition.
    if (isDHpix && isEyeInWater == 0) {
        // Gates below use the SAME fogEyeGate as the vanilla fog blocks. The
        // old skylDH (pixel skylight floored at 0.75) made every smoothstep a
        // constant 1.0: outdoors this is identical, and matching gates on both
        // sides is MANDATORY for seam continuity with the eye-gated vanilla fogs.
        vec3 world0DH = mat3(gbufferModelViewInverse) * viewPos + cameraPosition;

        // CSE: shared memoized getSkyBase(worldDir, sunW). Safe on DH pixels:
        // worldDir was rebuilt through the DH frustum BEFORE the memo was
        // declared, and the vanilla sites (water/aerial fog) never ran for
        // this pixel (isSky stayed true), so the cache cannot hold a stale dir.
        if (!skyBaseWDok) { skyBaseWD = getSkyBase(worldDir, sunW); skyBaseWDok = true; }
        vec3 fogColDH = skyBaseWD;
        #ifdef BIOME_ATMOSPHERE
            vec3 biomeFogDH = toLinear(fogColor) * 1.6;
            if (luma(fogColor) > 0.001) {
                fogColDH = mix(fogColDH, biomeFogDH * (0.4 + luma(fogColDH)),
                               0.55 * BIOME_ATMO_STRENGTH * fogEyeGate);
            }
        #endif
        // Same formula as vanilla terrain (DH scale): exact continuity at the
        // seam, LODs near the vanilla edge get ~the same fog.
        // DISTANCE_FOG=0 cuts the wall here too -- vanilla/DH symmetry is
        // MANDATORY or the seam reappears. fogColDH is still computed (used by
        // ATMO_FOG and the edge fade).
#if DISTANCE_FOG == 1
        float fogFDH = 1.0 - exp(-pow(dist / (max(float(dhRenderDistance), far) * 0.85), 2.5) * 0.75 * FOG_DENSITY);
        color = mix(color, fogColDH, clamp(fogFDH, 0.0, 1.0));
#endif

        #ifdef ATMO_FOG
        {
            // Exact mirror of the vanilla ATMO_FOG block (Beer-Lambert over dist,
            // modulated by altitude and dusk) applied to the LODs.
            float atmoSkyDH = fogEyeGate;
            float atmoDuskDH = clamp(1.0 - abs(sunHeight()) * 4.0, 0.0, 1.0) * smoothstep(-0.14, -0.04, sunHeight()); // asymmetric: keeps it off at night
            float hMidDH = (cameraPosition.y + world0DH.y) * 0.5;
            float atmoHDH = exp(-max(hMidDH - WATER_LEVEL, 0.0) * 0.012);
            // dhFogK : MEME facteur que le bloc vanilla (couture continue).
            float atmoTauDH = dist * dhFogK * 0.0018 * ATMO_FOG_DENSITY * atmoHDH
                            * (1.0 + atmoDuskDH * 0.6 * ATMO_FOG_DUSK_BOOST)
                            * (1.0 + rainStrength * 0.8);
            #if BIOME_CLIMATE == 1
            // Mirror of the vanilla block (seam continuity): same biome
            // climate density multiplier and tint.
            atmoTauDH *= biomeFogDensMul();
            #endif
            float atmoFDH = 1.0 - exp(-atmoTauDH);
            float vdotSDH = max(dot(worldDir, sunW), 0.0);
#ifdef FOG_SHADOWS_ACTIVE
            // FOG_SHADOWS: exact mirror of the vanilla split (seam continuity)
            // -- same shared probe, so both sides of the seam darken alike.
            vec3 atmoColDH = fogColDH * (0.85 + 0.15 * atmoDuskDH) * fogShadAmb
                           + gLightC * pow(vdotSDH, 6.0) * 0.25 * (0.3 + 0.7 * atmoDuskDH) * fogShadDir;
#else
            vec3 atmoColDH = fogColDH * (0.85 + 0.15 * atmoDuskDH)
                           + gLightC * pow(vdotSDH, 6.0) * 0.25 * (0.3 + 0.7 * atmoDuskDH);
#endif
            #if BIOME_CLIMATE == 1
            atmoColDH *= biomeFogTint();
            #endif
            color = mix(color, atmoColDH, clamp(atmoFDH, 0.0, 0.85) * atmoSkyDH);
        }
        #endif

        #ifdef AERIAL_PERSPECTIVE
        {
            // Same formula (function of dist only) as the vanilla block -> continuous.
            float apVdotSDH = max(dot(worldDir, sunW), 0.0);
            // dhFogK : MEME facteur que le bloc vanilla (couture continue).
            float apAmtDH = 1.0 - exp(-dist * dhFogK / (far * 0.55));
            vec3 apColDH = gLightC * (0.35 + 0.65 * pow(apVdotSDH, 5.0));
#ifdef FOG_SHADOWS_ACTIVE
            // FOG_SHADOWS: mirror of the vanilla aerial-perspective apply.
            color += apColDH * apAmtDH * 0.10 * fogEyeGate * fogShadDir;
#else
            color += apColDH * apAmtDH * 0.10 * fogEyeGate;
#endif
        }
        #endif

        #if DH_EDGE_FADE == 1
        {
            // DH EDGE FADE: without a fog wall (DISTANCE_FOG=0), the LAST LOD ring
            // cuts hard against the sky at dhRenderDistance (a truncated terrain
            // silhouette that pops as you move). Soft fade over the last ~10%
            // toward the horizon color (fogColDH: analytic sky + biome tint,
            // already computed above) so LOD geometry dissolves into the
            // atmosphere. DH pixels ONLY (isDHpix branch): vanilla terrain and
            // real sky pixels untouched. Applied LAST so it dominates the fog at
            // the extreme edge, which is intended.
            float dhFadeEnd = max(float(dhRenderDistance), far);
            float dhEdgeF = smoothstep(dhFadeEnd * 0.90, dhFadeEnd * 0.99, dist);
            color = mix(color, fogColDH, dhEdgeF);
        }
        #endif
    }
#endif

    // --- Submerged glass: reproduces the water effects inside a structure ---
    if (inGlassUW) {
        float gwDepth = max(WATER_LEVEL - cameraPosition.y, 0.0);
        float gwDeep  = clamp(gwDepth / 10.0, 0.0, 1.0);
        float eyeSK   = float(eyeBrightnessSmooth.y) / 240.0;
        float d_gw    = max(gwDeep * gwDeep, 1.0 - eyeSK);
        // EAU5 AUDIT FOLLOW-UP -- these three chromas (near fog, deep fog and
        // the UNDERWATER_FX halo below) used to be HARD-CODED and were the only
        // water-medium constants left OUT of the WATER_TINT palier. This path is
        // alive at the shipped defaults (UNDERWATER_FX defined,
        // GLASS_SEE_THROUGH = 1), so at palier 0 the water seen from outside sat
        // at 168.0 deg while the fog seen from inside a submerged glass dome
        // stayed at 204.0 / 219.5 / 206.3 -- a 36 to 51 deg inside/outside split,
        // exactly the defect class EAU4 exists to kill. NOT the same site as
        // WCOL_SCAT_UW, which is the column BEHIND the glass seen from OUTSIDE.
        // Same rotation mechanic as every other WT_* family: hue moves, Rec.709
        // luminance and HSV saturation do not, palier 2 = the old literals bit
        // for bit. Details and per-palier table in lib/settings.glsl.
        vec3 gwShallow = vec3(WT_GWS_R, WT_GWS_G, WT_GWS_B);
        vec3 gwDeepC   = vec3(WT_GWD_R, WT_GWD_G, WT_GWD_B);
        vec3 gwFogC = mix(gwShallow, gwDeepC, d_gw * d_gw)
                    * (gAmbC * (0.38 - d_gw * 0.25) + gLightC * 0.09);
        // Raised density for a real underwater feel
        float gwFogDens = 0.055 + gwDeep * gwDeep * gwDeep * 0.22;
        color = mix(color, gwFogC, 1.0 - exp(-dist * gwFogDens * WATER_FOG_DENSITY));
        #ifdef UNDERWATER_FX
            float eyeSkyGW = float(eyeBrightnessSmooth.y) / 240.0;
            // Base isotropic ambient
            color += gAmbC * 0.032 * eyeSkyGW * (1.0 - gwDeep);
            // Blue-green halo filtered from the water above (dies off with depth)
            // WT_GWH: third chroma of this path, on the palier since EAU5.
            color += vec3(WT_GWH_R, WT_GWH_G, WT_GWH_B) * 0.024 * eyeSkyGW * (1.0 - gwDeep * gwDeep);
        #endif
    }

    // --- Volumetric cumulus: also IN FRONT of distant terrain ---
    #ifdef VOLUMETRIC_CLOUDS
    {
#if PERF_CLOUD_REMARCH == 1
        // PERF_CLOUD_REMARCH (lib/settings.glsl, bloc en fin de fichier) : la
        // moitie RAYON-SEUL de la sortie anticipee de volumetricClouds(), hissee
        // DEVANT les taps de profondeur. Le prologue de lib/clouds.glsl rend
        // vec4(0.0) sans jamais regarder maxDist quand le rayon ne rencontre pas
        // le slab [VC_BASE, VC_BASE+VC_THICK] devant la camera ; en resolvant les
        // signes de ta/tb cela vaut EXACTEMENT la condition ci-dessous. Un pixel
        // ecarte ici aurait recu mix(color, 0.0, 0.0) == color : sortie identique
        // au bit. Ce qui est economise : depthtex1 / dhDepthTex1 / depthtex0 /
        // colortex2, le toView + length de distO, le memo getSkyBase et l'entree
        // dans le corps inline du march.
        // Le cas restant (le slab est bien traverse, mais le TERRAIN est atteint
        // avant l'entree dans le slab) depend de maxDist et reste, lui, traite
        // par le prologue de clouds.glsl -- il ne peut pas etre hisse ici.
        float vcTopC = VC_BASE + VC_THICK;
        bool vcRayHitsSlab = (cameraPosition.y >= VC_BASE && cameraPosition.y <= vcTopC)
                          || (cameraPosition.y <  VC_BASE && worldDir.y >=  1e-3)
                          || (cameraPosition.y >  vcTopC  && worldDir.y <= -1e-3);
        if (vcRayHitsSlab) { // <PERF_CLOUD_REMARCH> accolade fermee au #if jumeau, bas du bloc
#endif
        // Pixels whose background is the sky already have their clouds (deferred
        // pass, under the translucents). Here: only the clouds that pass IN
        // FRONT of distant opaque terrain.
        float d1c = texture2D(depthtex1, uv).r;
#if DIMENSION_FX == 1
        // No cumulus in front of Nether / End terrain (the deferred sky pass
        // already skips the whole cloud chain there).
        bool cloudsHere = (dimNether() < 0.5 && dimEnd() < 0.5);
#else
        bool cloudsHere = true;
#endif
#ifdef DISTANT_HORIZONS
        // Clouds also pass IN FRONT of DH LODs (VC_RENDER_DISTANCE may be < the
        // LOD distance): occlusion uses the opaque DH depth (dhDepthTex1) when
        // depthtex1 is empty. The deferred pass no longer paints clouds on DH
        // pixels -> they appear HERE, correctly cut by nearer LOD mountains.
        float dhD1c = texture2D(dhDepthTex1, uv).r;
        if (isEyeInWater == 0 && cloudsHere && (d1c < 1.0 || dhD1c < 1.0)) {
            float distO = (d1c < 1.0) ? length(toView(uv, d1c)) : length(toViewDH(uv, dhD1c));
#else
        if (isEyeInWater == 0 && cloudsHere && d1c < 1.0) {
            float distO = length(toView(uv, d1c));
#endif
            // F5 ghost: the translucent player body is absent from depthtex1 --
            // clamp the cloud march to the visible surface on entity pixels too.
            {
                float d0c = texture2D(depthtex0, uv).r;
                if (d0c < 1.0) {
                    float matBc = texture2D(colortex2, uv).b;
                    if (matBc > 0.01 && matBc < 0.30) distO = min(distO, length(toView(uv, d0c)));
                }
            }
            // CSE: shared memoized getSkyBase(worldDir, sunW) -- on terrain /
            // DH pixels the fog blocks above already filled the cache, so this
            // is usually a free read instead of a 2nd/3rd evaluation.
            if (!skyBaseWDok) { skyBaseWD = getSkyBase(worldDir, sunW); skyBaseWDok = true; }
            vec3 cloudFog = skyBaseWD;
            vec4 vc = volumetricClouds(cameraPosition, worldDir, lightW, cloudFog,
                                       vlDither, cloudWorldTime(), distO); // world time: SAME clock as deferred (exact sky/terrain match)
            color = mix(color, vc.rgb, vc.a);
        }
#if PERF_CLOUD_REMARCH == 1
        } // <PERF_CLOUD_REMARCH> ferme le if (vcRayHitsSlab) du #if jumeau, haut du bloc
#endif
    }
    #endif

#ifdef END_STORM_ACTIVE
    // --- END STORM in front of distant terrain (lib/end_storm.glsl) ---
    // Sky pixels got the storm in deferred (half-res bake); here the pillars
    // that stand IN FRONT of far islands, bounded by the opaque depth (same
    // DH / F5 bounds as the cumulus block). Nothing exists within the camera
    // clearing, so near terrain (< 40 blocks) skips the march. Applied before
    // the volumetric fog, which hazes it like the sky. Uniform branch.
    if (dimEnd() > 0.5 && isEyeInWater == 0) {
        float d1e = texture2D(depthtex1, uv).r;
#ifdef DISTANT_HORIZONS
        float dhD1e = texture2D(dhDepthTex1, uv).r;
        if (d1e < 1.0 || dhD1e < 1.0) {
            float distE = (d1e < 1.0) ? length(toView(uv, d1e)) : length(toViewDH(uv, dhD1e));
#else
        if (d1e < 1.0) {
            float distE = length(toView(uv, d1e));
#endif
            {
                float d0e = texture2D(depthtex0, uv).r;
                if (d0e < 1.0) {
                    float matBe = texture2D(colortex2, uv).b;
                    if (matBe > 0.01 && matBe < 0.30) distE = min(distE, length(toView(uv, d0e)));
                }
            }
            if (distE > 40.0) {
                vec4 st = endStormMarch(cameraPosition, worldDir, lightW, vlDither, frameTimeCounter, distE, 0.0);
                color = mix(color, st.rgb, st.a);
            }
        }
    }
#endif

    // --- DAWN MIST: low valley mist at dawn / dusk / after rain (DAWN_MIST) ---
    #if DAWN_MIST == 1
    // Its own analytic height-fog layer (closed-form Beer-Lambert along the
    // ray, no march): independent of VOLUMETRIC_LIGHT and HEIGHT_FOG, the two
    // transmittances simply multiply. ONE site for every pixel kind (terrain,
    // DH LOD, sky: dist = far at the horizon, like the HEIGHT_FOG tail) so
    // silhouettes and the sky beside them always match. Applied BEFORE the
    // VL apply below so the sun shafts still pierce the mist.
    if (isEyeInWater == 0 && fogEyeGate > 0.001) {
        // Hour weight from the world clock (0 = 6h): dense 4h30-7h (build-up
        // from 3h30), dissipating until 9h30, faint at dusk (18h-19h30,
        // x0.35), zero by day; plus the wet haze lingering once the rain
        // stops (wetness lags rainStrength).
        float tf = float(worldTime);
        float mistW = max(smoothstep(21500.0, 22500.0, tf), 1.0 - smoothstep(1000.0, 3500.0, tf));
        mistW = max(mistW, 0.35 * smoothstep(11500.0, 12200.0, tf) * (1.0 - smoothstep(13500.0, 14300.0, tf)));
        mistW = clamp(mistW + wetness * (1.0 - rainStrength) * 0.6, 0.0, 1.0);
        // Keep it low: fades out between ~12 and ~30 deg of elevation, for
        // all pixel kinds alike (a far peak and the sky next to it agree).
        float dyM = worldDir.y;
        mistW *= 1.0 - smoothstep(0.2, 0.5, dyM);
#ifdef DAWN_MIST_VOL_ACTIVE
        // DAWN_MIST_VOL: the VL march further down already carries the mist
        // over [0, min(dist, 160)] as a REAL medium (same d0M, same profile,
        // times a mean-1.0 noise field), so what is left for this analytic
        // layer is the TAIL beyond the march -- and nothing at all for a pixel
        // the march covered whole. Same 160-block constant as marchEnd and as
        // the DIMENSION_FX tail at the end of main().
        if (mistW > 0.001 && fogDist > 160.0) {
#else
        if (mistW > 0.001) {
#endif
            // Exponential profile anchored 2 blocks under the eye (local
            // ground): density d0 at the anchor, / e every DAWN_MIST_HEIGHT
            // blocks up, capped at 6x below it (ravines, cliff views).
            float kM = 1.0 / DAWN_MIST_HEIGHT;
            // dhFogK (DH_FOG_SCALE) : meme classe de defaut que la traine
            // HEIGHT_FOG — a l'aube cette couche donnait ~65 % de brume a 512
            // blocs et remurait la distance DH. Avec DAWN_MIST_VOL_ACTIVE
            // (defaut) cette couche est la traine AU-DELA de la marche (160) :
            // la brume d'aube du champ proche (marchee, milieu reel) garde sa
            // densite pleine, et le raccord a 160 reste continu (la traine
            // part de tau=0 la, seule la pente change).
            float d0M = 0.0030 * dhFogK * mistW * DAWN_MIST_STRENGTH * fogEyeGate;
            // Altitude weight: the anchor follows the eye, so without this a
            // flying player would drag the mist up with him. Full density up
            // to sea level + 30, then / e every 40 blocks (lowlands only).
            d0M *= exp(-max(cameraPosition.y - (WATER_LEVEL + 30.0), 0.0) / 40.0);
            float u0M = 2.0;                          // eye height above the anchor
            float uCapM = -1.7918 * DAWN_MIST_HEIGHT; // ln(6) scale heights under it
#ifdef DAWN_MIST_VOL_ACTIVE
            // Origin shifted to the march limit: the ray height THERE becomes
            // the new u0 and the integrated segment becomes [0, lenM]. The
            // point-wise density on both sides of the limit is the same
            // d0M * min(exp(-u * kM), 6) (the march multiplies it by a field
            // of mean 1.0), so tau is continuous across 160 blocks: no seam.
            // u0M is floored at the cap -- below it the density is the
            // constant 6*d0M anyway, and the floor keeps exp(-u0M * kM) from
            // overflowing on a steep downward ray (u0M would reach -158).
            // The legacy integral is duplicated VERBATIM in the #else so that
            // DAWN_MIST_VOL = 0 preprocesses to the original token stream.
            float lenM = fogDist - 160.0;
            u0M = max(u0M + dyM * 160.0, uCapM);
            // Uncapped segment [0, tU] + capped constant 6*d0 on [tU, lenM]
            // (only a downward ray can reach the cap).
            float tU = (dyM < 0.0) ? clamp((uCapM - u0M) / dyM, 0.0, lenM) : lenM;
            float xM = dyM * kM * tU;
            float tauM = d0M * exp(-u0M * kM)
                       * ((abs(xM) < 1e-4) ? tU : (1.0 - exp(-xM)) / (dyM * kM));
            tauM += 6.0 * d0M * (lenM - tU);
#else
            // Uncapped segment [0, tU] + capped constant 6*d0 on [tU, dist]
            // (only a downward ray can reach the cap).
            float tU = (dyM < 0.0) ? clamp((uCapM - u0M) / dyM, 0.0, fogDist) : fogDist;
            float xM = dyM * kM * tU;
            float tauM = d0M * exp(-u0M * kM)
                       * ((abs(xM) < 1e-4) ? tU : (1.0 - exp(-xM)) / (dyM * kM));
            tauM += 6.0 * d0M * (fogDist - tU);
#endif
            // Same mirror relief as the ATMO_FOG / VL veils (fogKeepW contract).
            tauM *= 1.0 - 0.55 * clamp(wMirror, 0.0, 1.0);
            // Tint from the LOCAL sky luminance only (cool grey-blue, never the
            // raw sky RGB - same lesson as the water), lit by the grazing sun
            // toward its direction (gLightC is lunar below the horizon, so the
            // glow only shows once the sun is up).
            if (!skyBaseWDok) { skyBaseWD = getSkyBase(worldDir, sunW); skyBaseWDok = true; }
#ifdef FOG_SHADOWS_ACTIVE
            // FOG_SHADOWS: the grazing-sun glow follows the shared probe; the
            // sky-lit mist body keeps the 75% ambient floor, so mist pooling
            // in a cloud-shaded valley reads darker instead of golden.
            vec3 mistCol = vec3(0.82, 0.89, 1.0) * (luma(skyBaseWD) * 0.92) * fogShadAmb
                         + gLightC * pow(max(dot(worldDir, sunW), 0.0), 5.0) * 0.08 * fogShadDir;
#else
            vec3 mistCol = vec3(0.82, 0.89, 1.0) * (luma(skyBaseWD) * 0.92)
                         + gLightC * pow(max(dot(worldDir, sunW), 0.0), 5.0) * 0.08;
#endif
            color = mix(color, mistCol, clamp(1.0 - exp(-tauM), 0.0, 0.9));
        }
    }
    #endif

    // --- Underwater: graded fog + sun glow + particles ---
    if (isEyeInWater == 1) {
        float deep = 1.0 - float(eyeBrightnessSmooth.y) / 240.0;
        float camDepth = max(WATER_LEVEL - cameraPosition.y, 0.0);
        float physDeep = clamp(camDepth / 12.0, 0.0, 1.0);
        // Absorb the residual MIN_LIGHT at depth. Without this, the Minecraft
        // engine keeps a minimum lighting visible even 15 m down; it is crushed
        // progressively here.
        // V2 cuts this from 0.84 to 0.30: going deep should drain SATURATION
        // toward blue, not collapse the exposure. The residual MIN_LIGHT it
        // was fighting is now mostly eaten by the per-channel absorption below.
        color *= 1.0 - physDeep * physDeep * WCOL_UW_DARK;
        // Reference for "how dark is it down here": V2 uses the eye SKY
        // LIGHTMAP only (a flooded cave is dark, a 30-block-deep open sea is
        // not), legacy also folded in the geometric depth.
        float d = (WATER_COLOR_V2 == 1) ? deep : max(deep, physDeep * physDeep);
        // CLEAR TROPICAL WATER. The milky white-cyan veil comes from the
        // LUMINANCE of the scatter: a saturated cyan target (B/G ~1.6) pushed by
        // gLightC veils everything, including nearby sand. These targets are
        // therefore ~2x DARKER and DESATURATED, shifted blue-GREEN (G ~= B:
        // ocean turquoise, never azure or navy) -> at 2-4 blocks the sand keeps
        // its WARM color under a light turquoise cast, and at distance the veil
        // fades toward a desaturated ocean rather than a plastic blue wall.
        // 3 stages: 0-3 m dark turquoise -> 4-8 m deep blue-green -> >8 m near black
        // Fine retouch (validated ambiance kept): a touch less blue, a hint
        // of green -- G nudged just above/near B at each stage, nothing else.
        // V2: the three stages collapse to ONE chroma. Depth changes how much
        // light reaches the volume, not what colour the volume is; the
        // "turquoise near / near-black deep" staging was doing the job the
        // per-channel absorption below now does properly. Legacy keeps the
        // three separate targets. The UW_BIOME_TINT block still works on both.
        vec3 shallowC = vlxWaterUWc(WCOL_UW_SHALLOW);
        vec3 midC     = vlxWaterUWc(WCOL_UW_MID);
        vec3 deepC    = vlxWaterUWc(WCOL_UW_DEEP);
        #ifdef UW_BIOME_TINT
          if (luma(fogColor) > 0.001) {
            vec3 fbN = toLinear(fogColor) / max(luma(toLinear(fogColor)), 0.04);
            float s = UW_BIOME_TINT_STRENGTH;
            shallowC = mix(shallowC, shallowC * fbN, s);
            midC     = mix(midC,     midC     * fbN, s);
            deepC    = mix(deepC,    deepC    * fbN * UW_FOG_DEPTH_TINT, s);
          }
        #endif
        float midBlend  = smoothstep(0.0, 0.55, physDeep);
        float deepBlend = smoothstep(0.55, 1.0,  physDeep);
        vec3 fogBaseC = mix(mix(shallowC, midC, midBlend * midBlend),
                            deepC, deepBlend * deepBlend);
        // RESIDUAL DEPTH DESATURATION (V2 only). V2 collapsed the three staged
        // chromas into one, which also removed the saturation drain the
        // staging used to carry - see the WCOL_UW_* comment at the top of this
        // file for the measurement. The pull is toward the chroma's OWN
        // Rec.709 luminance, so deep water becomes LESS COLOURED and not one
        // shade darker or brighter, which is the same criterion the whole V2
        // chroma was built on. float(WATER_COLOR_V2) leaves legacy builds
        // bit-identical: the staged constants already do this job there.
        fogBaseC = mix(fogBaseC, vec3(luma(fogBaseC)),
                       clamp(physDeep * UW_FOG_DESAT * float(WATER_COLOR_V2), 0.0, 1.0));
        // V2 view-direction modulation: x1.0 looking UP at the bright ceiling
        // of water, x0.6 horizontal, x0.2 looking DOWN into the dark. It is
        // the cheapest honest stand-in for "where the light comes from" and it
        // is what stops a single flat chroma from reading as painted fog.
        // mix() with float(WATER_COLOR_V2) -> exactly 1.0 in legacy builds.
        float uwViewMod = mix(1.0, clamp(worldDir.y, -1.0, 1.0) * 0.4 + 0.6,
                              float(WATER_COLOR_V2));
        // EAU4b -- ACHROMATIC DRIVE (WCOL_V3 only). This is the SAME medium as
        // slateC, and slateC's own comment states the rule in writing: never
        // multiply this in-scatter by a light COLOUR. This site was the last
        // one that still did, and therefore the last place where one lake was
        // painted in two colours - by a mechanism EAU4's constants cannot
        // reach, because it lives in the DRIVE and not in the chroma.
        // MEASURED, free water with no floor, camera 5 blocks under, against
        // the outside column at 48 blocks:
        //   noon    drive (0.734,0.750,0.764), near neutral -> split 0.07 deg
        //   sh 0.30                                         -> split 0.20 deg
        //   sh 0.12                                         -> split 1.04 deg
        //   sh 0.05 drive (0.344,0.167,0.114), R/B 3.03     -> split 11.26 deg
        //           of hue and 0.306 of saturation, i.e. 77% of the 14.7 deg
        //           defect EAU4 closed, reopened at the sunset hour alone.
        // The three other sites of this same medium (slateC below, the glass
        // column and the two culled water faces) were already driven by a GRAY
        // luma(); this one now matches them. The pull is on CHROMA only: the
        // Rec.709 luminance of the drive is unchanged at noon and +10% at
        // sh 0.05, so no brightness dial moves with it. Gated on WCOL_V3 --
        // the legacy V2 path keeps its coloured drive bit-for-bit, this defect
        // being PRE-EXISTING and identical there.
        vec3 uwDrive;
#if WCOL_V3 == 1
        uwDrive = vec3(luma(gAmbC) * (0.38 - d * 0.30) + luma(gLightC) * 0.09);
#else
        uwDrive = gAmbC * (0.38 - d * 0.30) + gLightC * 0.09;
#endif
        vec3 wfogC = fogBaseC * uwDrive
                   * UW_FOG_BRIGHT * uwViewMod; // CONFIG: UW fog luminance dial
        // Density calibrated on real tropical water visibility (~15-20 m).
        // Distance -> floor transmittance (this fog * VL extinction ~e^(-0.021d),
        // defaults, eye near the surface):
        //   2 blocks  : ~85% (sharp floor, warm sand barely veiled)
        //   8 blocks  : ~45% (clear turquoise veil, floor still readable)
        //   20 blocks : ~12% (veil dominant, silhouettes only)
        // The veil must exist in DENSITY while staying dark; a veil that exists
        // only in luminance is exactly the milky look to avoid.
        // CONFIG: UW_CLARITY divides the density (underwater sight range)
#if WATER_COLOR_V2 == 1
        // V2 SUBMERGED COLUMN -- the same two-term shape as the view from
        // outside, which the old code did NOT have: a per-channel Beer term on
        // the background plus one achromatic veil. What that buys, and what the
        // achromatic mix could never do, is that distant terrain keeps its
        // CONTRAST while losing its warm channels, instead of fading uniformly
        // into a coloured wall.
        // Density is FLAT: 0.040 base-2 = half opacity at 25 blocks, 95% at
        // ~108, and it does NOT change with depth. The old cubic ramp reached
        // 0.270 (half opacity at 2.6 blocks) at 12 blocks down, which is why
        // deep water was a wall. Real water does not get foggier because the
        // floor is further away.
        float fogDens = WCOL_UW_DENS * UW_DENSITY_BOOST * WATER_FOG_DENSITY / UW_CLARITY;
        vec3  absU = exp(-dist * WCOL_K_UW);
        float visU = clamp(exp2(-dist * fogDens), 0.0, 1.0);
        color = mix(wfogC, color * absU, visU);
#else
        float fogDens = (0.080 + physDeep * physDeep * physDeep * 0.190) * UW_DENSITY_BOOST / UW_CLARITY;
        color = mix(color, wfogC, 1.0 - exp(-dist * fogDens * WATER_FOG_DENSITY));
#endif

        #ifdef UNDERWATER_FX
            // ISOTROPIC ambient based on eyeBrightness -> no fake vertical shaft
            // (the real god rays are handled by the VL, not here)
            float eyeSkyFr = float(eyeBrightnessSmooth.y) / 240.0;
            color += gAmbC * 0.030 * eyeSkyFr * (1.0 - physDeep * physDeep);
            #ifdef UW_VIGNETTE
            // TAAU: sub-rect center is at 0.5*TAAU_S, not 0.5 screen
            float uvVig = dot(uv - 0.5 * TAAU_S, uv - 0.5 * TAAU_S);
            color *= 1.0 - uvVig * physDeep * physDeep * 3.0;
            #endif
        #endif

        #ifdef UW_PARTICLES
            // Marine snow / plankton: suspended particles lit by the sun
            float sunFP = smoothstep(-0.05, 0.2, lightHeight()) * (1.0 - rainStrength);
            for (int i = 0; i < 5; i++) {
                float fi = float(i);
                float pd = 1.5 + fi * 3.0;
                if (pd > dist) break;
                // Slow drift (rise + lateral current)
                vec3 drift = vec3(frameTimeCounter * 0.018, frameTimeCounter * (0.05 + fi * 0.009), frameTimeCounter * 0.013);
                vec3 wp = cameraPosition + worldDir * pd + drift;
                float n1 = vnoise3(wp * 5.5);
                float n2 = vnoise3(wp * 13.0 + 19.3);
                // Dense small particles + rare large ones
                float sp = smoothstep(0.970, 0.999, n1 * 0.55 + n2 * 0.45)
                         + smoothstep(0.992, 1.000, n1) * 0.30;
                // Blue-green tint, brighter where the light comes from above
                vec3 pCol = mix(vec3(0.28, 0.55, 0.70), vec3(0.50, 0.78, 0.90), n2)
                          * (0.10 + 0.22 * sunFP * max(lightW.y, 0.0));
                color += sp * pCol * exp(-pd * 0.11)
                       * (0.5 + 0.5 * (1.0 - physDeep)) * (1.0 - physDeep * 0.55);
            }
        #endif
    }

    /*
        --- UNIFIED VOLUMETRIC FOG ---
        One raymarch: height fog (valleys fill up, builds emerge) + sun shafts in
        the air, all shadowed by the shadow map, so mountains carve shadow wells
        into the haze. Underwater: god rays sculpted by the wave field.
    */
    #ifdef VOLUMETRIC_LIGHT
    {
        // The march runs to OPAQUE terrain (depthtex1), not to glass or the water
        // surface: shafts and fog therefore cross transparent surfaces
        // (underwater bases, glass walls).
        float d1v = texture2D(depthtex1, uv).r;
#ifdef DISTANT_HORIZONS
        // DH terrain: the analytic height-fog tail runs to the LOD (dhDepthTex1)
        // instead of stopping at far when depthtex1 is empty. The shadowed march
        // itself stays capped at 160 blocks.
        float dhD1v = texture2D(dhDepthTex1, uv).r;
        float distVol = (d1v < 1.0) ? length(toView(uv, d1v))
                      : ((dhD1v < 1.0) ? length(toViewDH(uv, dhD1v)) : far);
#else
        float distVol = (d1v >= 1.0) ? far : length(toView(uv, d1v));
#endif
        // F5 GHOST (translucent skins, MC 1.21.4+): the third-person player is
        // rendered in the TRANSLUCENT phase, so it is ABSENT from depthtex1. The
        // volumetric fog would march 160 blocks straight THROUGH it (white veil
        // in front of sun/sky, ~x25 forward phase facing the star) while the held
        // item (cutout, opaque phase) and the cape (entitySolid) stayed sharp --
        // the "cape visible through the torso" artifact. Bound the march by the
        // VISIBLE surface (depthtex0) EXCEPT for water (flag > 0.95) and glass
        // (0.7), which must stay traversed (underwater bases, glass walls).
        // NOTE (2026-08): this VL bound is the SOLE F5 ghost fix. The Iris key
        // separateEntityDraws=false was removed from shaders.properties: it only
        // moves entities/block entities (never translucent terrain), and forcing
        // that legacy path on MC 26.x made glass blocks show through opaque walls.
        {
            float d0vF5 = texture2D(depthtex0, uv).r;
            if (d0vF5 < 1.0 && d0vF5 < d1v - 1e-6) {
                float matBvF5 = texture2D(colortex2, uv).b;
                // Entity flag band only (0.02): ice/honey/slime (0.0) and emissive
                // translucents (0.5) stay fog-traversed like before the F5 fix.
                if (matBvF5 > 0.01 && matBvF5 < 0.30) distVol = min(distVol, length(toView(uv, d0vF5)));
            }
        }
        float marchEnd = min(distVol, (isEyeInWater == 1) ? UW_RAY_DISTANCE : 160.0);
        // scat/transF live in the common trunk: both the VL_HALF_RES upsample
        // and the inline march below fill them, the tail applies them.
        vec3 scat;
        float transF;
#if VL_HALF_RES == 1
        // === VL_HALF_RES upsample ===========================================
        // composite.fsh marched this ray family at HALF res (lower-left
        // quadrant, texel (i,j) = full-res pixel (2i,2j)) into two endpoint
        // sets: colortex13 = (scat, trans) integrated with the FULL submerged
        // density coefficient (wMirror = 0) and colortex14 = (scat at
        // wMirror = 1, odUW = unweighted submerged optical depth). Since the
        // ONLY wMirror-dependent quantity of the march is the submerged step
        // density uw*0.008*(1 - wMirror*0.85), the recombination is:
        //   transF(w) = trans13 * exp(0.85 * w * odUW)
        //             = transAir * exp(-odUW * (1 - 0.85*w))     [EXACT]
        //   scat(w)   = mix(scat13, scat14, w)          [endpoint-exact lerp]
        // scat is exact at w = 0 and w = 1; the validated sunset mirror sits
        // at w ~ 0.9-0.98, next to the exact w = 1 endpoint. In between, the
        // lerp of the two Beer-Lambert integrals deviates by less than
        // ~(0.85*odUW)^2/8 relative (odUW <= ~1.3 for 160 m of water column
        // -> < 8% of the submerged veil worst case, typically < 2%): invisible
        // in fog and TAA-averaged. VL_BLOCKLIGHT is already folded into both
        // stored scats (its apply below is gated off).
        // 4-tap bilateral (giUpsample pattern): bilinear weights x opaque ray
        // distance affinity, so fog/shaft edges never bleed across
        // silhouettes; plain bilinear fallback when all weights collapse.
        {
            vec2 vsV = vec2(viewWidth, viewHeight);
            // Receiver reference: raw opaque ray distance (pre-F5 clamp),
            // the same metric recomputed per tap below.
            float dCw;
#ifdef DISTANT_HORIZONS
            dCw = (d1v < 1.0) ? length(toView(uv, d1v))
                : ((dhD1v < 1.0) ? length(toViewDH(uv, dhD1v)) : far);
#else
            dCw = (d1v >= 1.0) ? far : length(toView(uv, d1v));
#endif
            vec2 hcV = uv * 0.5 * vsV - 0.25;            // quadrant texel index space (-0.25: texel i anchors full-res pixel 2i)
            vec2 baseV = floor(hcV);
            vec2 fV = hcV - baseV;
            vec2 maxIxV = floor(0.5 * TAAU_S * vsV) - 1.0; // last written quadrant texel
            vec4 accA = vec4(0.0);
            vec4 accB = vec4(0.0);
            vec4 accbA = vec4(0.0);                      // plain bilinear fallback
            vec4 accbB = vec4(0.0);
            float wSumV = 0.0;
#if UW_SHAFT_FIX3 == 1
            // ---- UW_SHAFT_FIX3 (C): the half-res fallback that OVERFLOWS ----
            // NOT mirrored: this is the RECEIVER, it exists only here (the
            // producer is composite.fsh / lib/vl_halfres.glsl).
            // When every one of the four taps is rejected by the depth
            // affinity, wSumV collapses and the code below falls back to the
            // PLAIN BILINEAR of the same four rejected taps -- the worst answer
            // available. It happens on thin geometry: a 1-block ledge, a kelp
            // stalk, a coral branch whose whole 2x2 half-res neighbourhood
            // marched into open water 100+ blocks behind it. The pixel then
            // receives the full open-water beam PASTED ONTO the solid block,
            // at full brightness, with no shadow of its own. That is one of the
            // shapes "de la lumiere passe a travers" takes, and the only one
            // the shadow map cannot fix, because the leak happens after the
            // march.
            // The collapse case has exactly one defensible value: the tap whose
            // ray ended NEAREST this pixel's own surface. It is the only one of
            // the four that ever saw a comparable ray, it costs one compare per
            // tap, and it changes nothing whenever the bilateral holds
            // (wSumV > 1e-3, i.e. every pixel that is not on a silhouette).
            vec4 bestA = vec4(0.0);
            vec4 bestB = vec4(0.0);
            float bestE = 1e9;
#endif
            for (int t = 0; t < 4; t++) {
                vec2 o = vec2(float(t & 1), float(t >> 1));
                vec2 tix = clamp(baseV + o, vec2(0.0), maxIxV);
                vec2 huv = (tix + 0.5) / vsV;            // texel-center tap (exact read)
                vec2 ruv = (tix * 2.0 + 0.5) / vsV;      // full-res pixel it marched
                float dS;
                float d1s = texture2D(depthtex1, ruv).r;
#ifdef DISTANT_HORIZONS
                float dhs = texture2D(dhDepthTex1, ruv).r;
                dS = (d1s < 1.0) ? length(toView(ruv, d1s))
                   : ((dhs < 1.0) ? length(toViewDH(ruv, dhs)) : far);
#else
                dS = (d1s >= 1.0) ? far : length(toView(ruv, d1s));
#endif
                vec4 sA = texture2D(colortex13, huv);
                vec4 sB = texture2D(colortex14, huv);
                float wb = mix(1.0 - fV.x, fV.x, o.x) * mix(1.0 - fV.y, fV.y, o.y);
                // Looser sigma than giUpsample: fog varies slowly along a
                // surface, only true silhouette gaps must be rejected.
                float wz = exp(-abs(dS - dCw) / (0.10 * dCw + 0.8));
                float w = wb * wz;
                accA += sA * w;   accB += sB * w;
                accbA += sA * wb; accbB += sB * wb;
                wSumV += w;
#if UW_SHAFT_FIX3 == 1
                float eS = abs(dS - dCw);   // (C) nearest-surface tap, see above
                if (eS < bestE) { bestE = eS; bestA = sA; bestB = sB; }
#endif
            }
            vec4 vA; vec4 vB;
            if (wSumV > 1e-3) { vA = accA / wSumV; vB = accB / wSumV; }
#if UW_SHAFT_FIX3 == 1
            else              { vA = bestA;        vB = bestB; }   // (C)
#else
            else              { vA = accbA;        vB = accbB; }
#endif
            float wmV = clamp(wMirror, 0.0, 1.0);
            scat = mix(vA.rgb, vB.rgb, wmV);
            transF = clamp(vA.a * exp(0.85 * wmV * vB.a), 0.0, 1.0);
        }
#else
#if PERF_VL_ADAPTIVE == 1
        // PERF_VL_ADAPTIVE (LOT B, B5, lib/settings.glsl): effective step
        // count follows the ray length -- full budget only on long rays (an
        // interior at marchEnd 20 pays 6 steps, not VL_SAMPLES). The
        // SUBMERGED eye keeps VL_SAMPLES: the UW slab is calibrated at
        // 6.0/4.0 blocks per step and the whole caustic/filament machinery
        // (nSubU = floor(dt/4)+1, UW_SHAFT windows) is indexed on that dt.
        // dt = marchEnd/vlN still covers the whole slab. The lower bound is
        // written in float form (int min/clamp are 130+, this block is
        // MIRRORED into the v120 half-res pass) and never RAISES the budget
        // at the low tiers (VL_SAMPLES 4/8). MIRRORED in lib/vl_halfres.glsl
        // -- keep the two blocks identical.
        int vlN = (isEyeInWater == 1) ? VL_SAMPLES
                : int(clamp(floor(marchEnd * 0.1),
                            (VL_SAMPLES < 6) ? float(VL_SAMPLES) : 6.0,
                            float(VL_SAMPLES)));
        float dt = marchEnd / float(vlN);
#else
        float dt = marchEnd / float(VL_SAMPLES);
#endif
        vec3 stepV = viewDir * dt;
        // Init at (dither-1) because the loop increments BEFORE sampling, giving
        // positions dt*(i+dither) in [0..marchEnd[. Any other init samples up to
        // a FULL step behind walls (dark veil on silhouettes) and skips the first
        // segment in front of the camera.
        vec3 p = stepV * (vlDither - 1.0);
        #ifdef VOLUMETRIC_CLOUDS
        #ifdef VC_GROUND_SHADOWS
#ifndef CLOUD_SHAFTS_ACTIVE
        // cloudShadow (~17 noise evaluations) is too expensive to pay at EVERY
        // march step (12-20 per pixel). The cloud shadow field varies over
        // HUNDREDS of blocks, so 2 probes (at 1/4 and 3/4 of the march) are
        // linearly interpolated along the ray: same light bands, ~10x less noise.
        // This proxy duplicates the cumulus mask -- keep it in sync with
        // cloudShadow in clouds.glsl.
        // PERF_CSHADOW_CHEAP: the probes go through cloudShadowCheap (5-tap
        // field, lib/lighting.glsl; pure pass-through at 0). MIRRORED in
        // lib/vl_halfres.glsl -- keep the two call pairs identical.
        float csA = cloudShadowCheap(cameraPosition + worldDir * (marchEnd * 0.25), lightW);
        float csB = cloudShadowCheap(cameraPosition + worldDir * (marchEnd * 0.75), lightW);
#endif
        #endif
        #endif
        scat = vec3(0.0);   // declared in the trunk above (shared with the upsample path)
        transF = 1.0;
        vec3 blockFog = vec3(0.0);
#endif // VL_HALF_RES (march-only setup; the scalar setup below stays shared:
       // the analytic tail needs hfDens/skyExpo/cosT on BOTH paths)

        float duskF = clamp(1.0 - abs(sunHeight()) * 4.0, 0.0, 1.0) * smoothstep(-0.14, -0.04, sunHeight()); // asymmetric: keeps it off at night
        float eyeSky = float(eyeBrightnessSmooth.y) / 240.0;
        // Sky exposure of the EYE: gates every sky/dusk chroma applied to the fog
        // below. gLightC/gAmbC carry the golden-hour tint at sunset, so without
        // this gate the in-scatter painted deep caves with a magenta veil.
        float skyExpo = smoothstep(0.02, 0.40, eyeSky);
        // Nether has zero skylight but its fog is legitimately warm: without this
        // the gate would repaint it cool gray. Same heuristic as the sky pass.
        if (fogColor.r > fogColor.g * 1.4) skyExpo = 1.0;
#if DIMENSION_FX == 1
        // ---- DIMENSION_FX (MIRRORED in lib/vl_halfres.glsl, keep in sync) ----
        // Nether / End have no skylight: the eye gate is forced open so the
        // fog keeps its chroma. dimN / dimE are exactly 0.0 in the Overworld.
        float dimN = dimNether();
        float dimE = dimEnd();
        skyExpo = max(skyExpo, max(dimN, dimE));
#endif
        float hfDens = 0.0;
        #ifdef HEIGHT_FOG
            hfDens = HEIGHT_FOG_DENSITY * (0.004 + duskF * 0.009 + rainStrength * 0.012)
                   * (0.35 + 0.65 * eyeSky)
                   * (1.0 + duskF * 0.35 * ATMO_FOG_DUSK_BOOST); // height fog reinforced at dusk (BOOST=0 -> x1.0)
        #endif
        float airDens = 0.0008 * VL_STRENGTH;
#if DIMENSION_FX == 1
        // Height fog (patchy banks) off in both dimensions; the air density
        // becomes the dimensional fog: Nether dense warm 1/110 blocks
        // (NETHER_FOG_DENSITY), End thin violet END_HAZE_DENSITY/450 (dial
        // live with or without the storm; the altitude profile is storm-only).
        // (MIRRORED in vl_halfres)
        hfDens *= (1.0 - dimN) * (1.0 - dimE);
        airDens = mix(airDens, NETHER_FOG_DENSITY / 110.0, dimN);
        airDens = mix(airDens, END_HAZE_DENSITY / 450.0, dimE);
#endif

        float cosT = dot(viewDir, normalize(shadowLightPosition));
        // Underwater: slightly directional (water forward-scatters at ~gP 0.5-0.6)
        // -> beams stay visible without being as laser-like as in air
        float gP = (isEyeInWater == 1) ? 0.58 : 0.60;
        // Sharper phase at dusk (more directional shafts).
        // The 0.86 CLAMP IS MANDATORY: the HG phase degenerates (NaN/inf) as g -> 1.
        if (isEyeInWater == 0) gP = min(gP + 0.10 * duskF * VL_DUSK_BOOST, 0.86);
        float phase = (1.0 - gP * gP) / (12.566 * pow(1.0 + gP * gP - 2.0 * gP * cosT, 1.5));
#if UW_SUN_COHERENT == 1
        // ---- UW_SUN_COHERENT: the ONE underwater light direction ----
        // (MIRRORED in lib/vl_halfres.glsl, keep in sync)
        // cosT above is dot(view, AIR sun): correct for every air term, wrong
        // for every submerged one. Below the surface the light arrives
        // REFRACTED, at asin(sin(theta_air)/1.3333) -- 44.8 deg off vertical
        // for a 20-deg sun against the air's 70 deg, and never past the 48.59
        // deg Snell cone. uwSunRefract (lib/water.glsl) is that direction, and
        // its xz/y slide is EXACTLY vlCa4Offset's, i.e. the very geometry the
        // shaft lookup already rides. Declared in the SHARED trunk (outside
        // every VL_HALF_RES / UW_* gate) because both the phase terms and the
        // shadow probe below read it.
#if UW_SHAFT_FIX3 == 1
        // ---- UW_SHAFT_FIX3 (A): the SHADOW MAP's axis, both caustic
        // generations. (MIRRORED in lib/vl_halfres.glsl, keep in sync)
        // uwShaftAxis(lightW) IS normalize(lightW) above 8.63 deg of elevation,
        // so every term built on uwLightW below -- the beam HG lobe (phaseU),
        // its pedestal, the striation phase floor, the UW_SUNGAZE_SOFT
        // vanishing point and the LOCK==0 blade basis -- points exactly where
        // the shadow map projects, i.e. where the diver's own shadow goes. The
        // v4 / v3 split disappears here on purpose: uwShaftAxis IS the v3
        // slope, so the two generations now agree by construction instead of
        // needing a branch to keep them apart.
        vec3 uwLightW = uwShaftAxis(lightW);
#elif CAUSTICS_V4 == 1
        vec3 uwLightW = uwSunRefract(lightW);
#else
        // CAUSTICS_V4 == 0 keeps the v3 projection on the AIR axis (see
        // the cprjOff comment in the underwater godray block: the v3
        // FLOOR sites slide the raw way, so the beam must slide the raw
        // way too). UW_SUN_COHERENT is a SEPARATE switch, so the two can
        // ship as 1 and 0: with the Snell vector here the shadow probe
        // slideV cut the beam at 44.81 deg while the striation and the
        // floor spot were drawn at 70.00 deg -- the very "two directional
        // structures 25 deg apart, multiplied together" this option
        // exists to remove. This vector has xz / y == lightW.xz /
        // max(lightW.y, 0.15), i.e. EXACTLY cprjOff, so slideV comes back
        // bit-identical to v3 and both paths agree again. v3 stays
        // untouched: it is wrong as a whole, and coherently so.
        vec3 uwLightW = normalize(vec3(lightW.x, max(lightW.y, 0.15), lightW.z));
#endif
        // Same product as cosT, in world space: worldDir and uwLightW are both
        // unit, and dot(view, L_view) == dot(world, L_world) for a rotation.
        float cosTU = dot(worldDir, uwLightW);
        // Water HG (g = 0.58, the submerged value gP already uses) on the
        // REFRACTED axis: the in-scatter lobe of a submerged step now peaks
        // where the beams actually point instead of 25 deg away from them.
        float phaseU = (1.0 - 0.3364) / (12.566 * pow(1.3364 - 1.16 * cosTU, 1.5));
#if UW_SHAFT_V4 == 1
        // ---- UW_SHAFT_V4 (B): the phase of a beam SEEN FROM THE BANK ------
        // (MIRRORED in lib/vl_halfres.glsl, keep in sync)
        // cosTU above is dot(AIR view, beam axis). With the eye SUBMERGED that
        // is right: there is no interface between the eye and the step, and
        // the axis is the one the columns are drawn on. With the eye DRY it is
        // wrong twice over -- the scattering event happens under the surface,
        // between the REFRACTED view ray and the REFRACTED sun ray, and BOTH
        // vectors here are air vectors.
        // It is not a small correction and it does not average out. Refraction
        // steepens both rays toward the vertical; seen from the bank they sit
        // on OPPOSITE sides of the horizontal (the view goes down, the sun
        // comes down from the other way), so their angles ADD where the air
        // pair had them partly cancelling. Both refracted rays are inside the
        // 48.59 deg Snell cone, hence
        //     cos(dev) = sinTv*sinTl*cos(dAz) - cosTv*cosTl <= 0.563 - 0.437,
        // i.e. from a dry eye the in-water scattering deviation is ALWAYS
        // >= 82.8 deg: the forward lobe of the water HG cannot be entered from
        // above the surface at all. The shipped air cosT enters it routinely
        // (dev 25 deg for a 5-deg sun looked at 20 deg down), and the beam is
        // then drawn with a forward-scatter brightness it physically cannot
        // have -- 2.15x too bright at this pack's noon, 3.29x at a 20-deg sun,
        // 9.43x at a 5-deg one. That elevation dependence is the signature:
        // the beams read wrong at golden hour and nearly right at noon.
        // uwSunRefract(v) keeps the azimuth and returns the +y refracted
        // direction, so -uwSunRefract(-worldDir) is the view ray after the
        // interface (worldDir is unit, so its xz length IS sin(theta_i) --
        // the same identity the function already relies on for lightW).
        // NO DIAL: this is a wrong vector, not a taste. The diver is excluded
        // by the branch, not by tuning, so his render is bit-identical.
        // The COLUMN axis is deliberately NOT touched here: cosTU keeps
        // driving UW_SUNGAZE_SOFT's vanishing point, which must sit where the
        // columns converge and not where the light comes from.
        // Cost: two uwSunRefract per RAY (not per step), uniform branch.
        if (isEyeInWater == 0 && !inGlassUW) {
            float cosTP = dot(-uwSunRefract(-worldDir), uwSunRefract(lightW));
            phaseU = (1.0 - 0.3364) / (12.566 * pow(1.3364 - 1.16 * cosTP, 1.5));
        }
#endif
#endif
        vec3 lightC = gLightC;
        lightC = max(lightC, vec3(0.10, 0.15, 0.26) * smoothstep(0.04, 0.30, lightHeight()));
        vec3 ambC = gAmbC;
        #ifdef FOG_BIOME_TINT
        // The volumetric fog takes the biome tint - AIR ONLY (the underwater path
        // already applies UW_BIOME_TINT; double tinting squares the swamp green).
        // Chroma normalized by luma (adds no energy), clamped to 2.0.
        if (isEyeInWater == 0 && !inGlassUW && luma(fogColor) > 0.001) {
            vec3 fbCh = toLinear(fogColor) / max(luma(toLinear(fogColor)), 0.04);
            fbCh = min(fbCh, vec3(2.0));
            ambC *= mix(vec3(1.0), fbCh, FOG_BIOME_TINT_STRENGTH);
        }
        #endif
        // AIR PATH ONLY (the UW branch keeps its own palette): with the eye
        // underground, fade the fog light/ambient CHROMA to a neutral slightly
        // cool gray, luma preserved -- depth fog reads discreet gray-blue, never
        // the dusk pink/fire tint.
#if UW_SHAFTS_UNIFIED == 1
        // Beam colour reference, taken BEFORE that desaturation: a submerged
        // eye never runs the branch below, so rebuilding the beam from the
        // desaturated lightC would still leave it side-dependent under an
        // overhang or in a cave mouth (skyExpo ~0.5 -> ~x0.87 R, x1.23 B).
        // Identical to lightC in the open air, where skyExpo is exactly 1.0.
        // (MIRRORED in lib/vl_halfres.glsl, keep in sync)
        vec3 lightCraw = lightC;
#endif
        if (isEyeInWater == 0 && !inGlassUW) {
            vec3 coolN = vec3(0.85, 0.95, 1.10);
            lightC = mix(vec3(luma(lightC)) * coolN, lightC, skyExpo);
            ambC   = mix(vec3(luma(ambC))   * coolN, ambC,   skyExpo);
        }
        if (isEyeInWater == 1 || inGlassUW) {
            // Saturated blue-green tint, bright enough for the shafts to show
            // (glass slightly dimmed at x0.85 vs direct water x1.05)
            float uwMult = (isEyeInWater == 1) ? 1.05 : 0.85;
            vec3 uwLightTint = vec3(0.32, 0.68, 0.92);
            vec3 uwAmbTint   = vec3(0.08, 0.28, 0.48);
            #ifdef UW_BIOME_TINT
              if (luma(fogColor) > 0.001) {
                vec3 fbN = toLinear(fogColor) / max(luma(toLinear(fogColor)), 0.04);
                float s = UW_BIOME_TINT_STRENGTH;
                uwLightTint = mix(uwLightTint, uwLightTint * fbN, s);
                uwAmbTint   = mix(uwAmbTint,   uwAmbTint   * fbN, s);
              }
            #endif
            lightC *= uwLightTint * uwMult;
            ambC   *= uwAmbTint;
        }
        // Directional shafts only exist when the star is up: no "noon rays" at
        // night or underground
        float lightUp = smoothstep(-0.04, 0.14, lightHeight());
        // Shafts do not die exactly at sunset: the window is widened at dusk (a
        // star just below the horizon keeps ~55%, full fade-out at -0.12).
        lightUp = max(lightUp, smoothstep(-0.12, -0.02, lightHeight()) * 0.55);
#if DIMENSION_FX == 1
        // DIMENSION_FX light terms (MIRRORED in lib/vl_halfres.glsl): Nether ->
        // no sun/moon shafts (the shadow map is the lava height map there),
        // ambient in-scatter = the fog limit dimNetherFog() (ambM is 0.22 in
        // air); End -> shafts at 65% (was 50%: +30% of the DIRECT term, the
        // one the frozen-noon shadow map carves between pillars - so the
        // island-shadow columns in the violet haze read, the same pass as the
        // storm's x1.30 direct in lib/end_storm.glsl), ambient = dimEndFog().
        lightC = mix(lightC, vec3(0.0), dimN);
        lightC *= 1.0 - 0.35 * dimE;
        ambC = mix(ambC, dimNetherFog() * (1.0 / 0.22), dimN);
        ambC = mix(ambC, dimEndFog() * (1.0 / 0.22), dimE);
        float lightWyN = abs(lightW.y); // vertical share of the light axis (lava height map)
#ifdef END_STORM_ACTIVE
        // END STORM lightning (MIRRORED in lib/vl_halfres.glsl): the bolt
        // state is drawn once per ray for the per-step point-light in-scatter
        // (the END_HAZE_DENSITY dial now sits on the base End air density
        // above; only the altitude profile stays storm-only). Uniform branch.
        vec3 bPE = vec3(0.0);
        vec3 bCE = vec3(0.0);
        float flE = 0.0;
        if (dimE > 0.5) flE = endLightningState(frameTimeCounter, cameraPosition, bPE, bCE);
#endif
#endif

#if VL_HALF_RES == 0
#ifdef DAWN_MIST_VOL_ACTIVE
        // ---- DAWN_MIST_VOL per-ray scalars (MIRRORED in lib/vl_halfres.glsl) ----
        // All camera-uniform, so the per-step test below is a UNIFORM branch:
        // the two noise taps are paid only during the MIST HOURS OR THE
        // AFTER-RAIN WINDOW, and cost nothing the rest of the time. (The hour
        // weight is not purely hourly: dawnMistHourW adds
        // wetness * (1 - rainStrength), and wetness lags rainStrength by
        // minutes, so dmOn stays true at any hour for a while after a shower --
        // which is when the damp haze is meant to show.) Same hour / humidity
        // weight, same 2-blocks-under-the-eye anchor, same eye sky-exposure
        // gate (smoothstep(0.02, 0.40, eyeSky) IS fogEyeGate, WITHOUT the
        // Nether override skyExpo carries) and the same lowlands altitude
        // weight as the analytic layer. The VIEW-ELEVATION fade of that layer
        // is deliberately NOT reproduced here: a marched ray climbing out of
        // the layer loses the mist on its own, through the height profile.
        float dmK = 1.0 / DAWN_MIST_HEIGHT;
        float dmAnchorY = cameraPosition.y - 2.0;
        float dmD0 = 0.0030 * dawnMistHourW(float(worldTime), wetness, rainStrength)
                   * DAWN_MIST_STRENGTH * smoothstep(0.02, 0.40, eyeSky)
                   * exp(-max(cameraPosition.y - (WATER_LEVEL + 30.0), 0.0) / 40.0);
        bool dmOn = (isEyeInWater == 0) && (dmD0 > 1e-6);
        // WORLD clock for the bank drift, like the clouds (lib/common.glsl
        // cloudWorldTime) and unlike the frameTimeCounter siblings above: this
        // field is driven by the world HOUR (dawnMistHourW reads worldTime), so
        // /time set, sleeping or a changed tick speed must move the banks WITH
        // the world instead of leaving them where the real clock put them. It
        // also removes the jump when Iris wraps frameTimeCounter at 3600 s.
        // cloudWorldTime() advances 1.0/s in normal play, so the drift speeds
        // inside dawnMistDens need no rescaling.
        float dmT = cloudWorldTime();
        // NYQUIST guard on the bank amplitude: the march step is
        // marchEnd / VL_SAMPLES = 20 blocks at the shipped VOLUMETRIC_QUALITY 1
        // (8 samples over 160 blocks), 40 at quality 0, against a bank lattice
        // of ~42 blocks horizontal / ~11 vertical -- at or below the sampling
        // limit, so a full-amplitude field makes tau swing frame to frame and
        // the banks crawl until TAA dissolves them. Fade the amplitude with the
        // step count instead (full from 12 samples up, floor 0.35): the coarse
        // tiers get a smoother sheet, the fine tiers get the dial as written.
        // The remap in dawnMistDens keeps the MEAN at 1.0 for any amplitude, so
        // the analytic tail stays joined at 160 blocks whatever this evaluates
        // to. (MIRRORED in lib/vl_halfres.glsl, keep in sync)
#if PERF_VL_ADAPTIVE == 1
        // B5: the Nyquist guard follows the EFFECTIVE step count -- an
        // adaptive short ray steps coarser, so the bank amplitude drops with
        // it (exactly this guard's intent; the dawnMistDens remap keeps the
        // MEAN at 1.0, so no brightness shift). MIRRORED in lib/vl_halfres.glsl.
        float dmPatchy = DAWN_MIST_PATCHY * clamp(float(vlN) / 12.0, 0.35, 1.0);
#else
        float dmPatchy = DAWN_MIST_PATCHY * clamp(float(VL_SAMPLES) / 12.0, 0.35, 1.0);
#endif
#endif
#if UW_SHAFTS_UNIFIED == 1
        // ---- UNIFIED UNDERWATER BEAM: side-independent per-ray scalars ----
        // (MIRRORED in lib/vl_halfres.glsl, keep in sync)
        // The beam must read the same on both sides of the surface. With the
        // eye submerged, lightC already carries the water tint and gP is
        // already the water 0.58; with a dry eye lightC is the AIR colour and
        // gP carries the dusk boost, so the very same water column produced a
        // cold, neutral, sharper beam seen from the bank. Rebuild both from
        // the WATER values here, for the beam term ONLY (the fog, the ambient
        // and the air shafts keep their own palette and their own phase).
        // EAU5: the beam tint follows the WATER_TINT palier too (WT_SHAFT_*,
        // lib/settings.glsl) -- the shafts ARE this water, so they must not stay
        // on a hue the medium no longer has. Palier 2 keeps vec3(0.32,0.68,0.92)
        // and the * 1.05 exactly as written, so it is bit-identical there.
        // MIRROR THIS LINE IN lib/vl_halfres.glsl (half-res twin of this march).
        vec3 uwShaftTint = vec3(WT_SHAFT_R, WT_SHAFT_G, WT_SHAFT_B) * 1.05; // = uwLightTint * uwMult(water)
        #ifdef UW_BIOME_TINT
          if (luma(fogColor) > 0.001) {
            vec3 fbNS = toLinear(fogColor) / max(luma(toLinear(fogColor)), 0.04);
            uwShaftTint = mix(uwShaftTint, uwShaftTint * fbNS, UW_BIOME_TINT_STRENGTH);
          }
        #endif
#if UW_SUN_COHERENT == 1
        // Water HG on the REFRACTED axis. phaseU (shared trunk) IS this exact
        // expression at g = 0.58, evaluated against cosTU instead of the air
        // cosT, so the beam pedestal, the striation floor and the submerged
        // in-scatter all read ONE lobe pointing where the shafts point -- and
        // no second pow() is paid. (MIRRORED in lib/vl_halfres.glsl)
        float phaseW = phaseU;
#else
        // Water HG phase (g = 0.58), never the dusk-boosted air one. The 0.86
        // degeneracy clamp is not needed here: g is a literal.
        float gPW = 0.58;
        float phaseW = (1.0 - gPW * gPW) / (12.566 * pow(1.0 + gPW * gPW - 2.0 * gPW * cosT, 1.5));
#endif
        // World-space march step, for the sub-sampling of the caustic field.
        vec3 wStepU = mat3(gbufferModelViewInverse) * stepV;
        // Ray entry into the water: 0 when the eye is already submerged (so a
        // diver's look is unchanged), otherwise captured at the first
        // submerged step. Turns UW_SHAFT_RENDER_DIST into a WATER-PATH limit
        // instead of a camera-distance one.
        float uwEntryT = (isEyeInWater == 1) ? 0.0 : -1.0;
#endif
#if PERF_VL_ADAPTIVE == 1
        for (int i = 0; i < vlN; i++) {   // B5: effective count (see dt above)
#else
        for (int i = 0; i < VL_SAMPLES; i++) {
#endif
            p += stepV;
            vec3 wp = mat3(gbufferModelViewInverse) * p + cameraPosition;

            // Submerged segment: either the eye IS in water, or this ray point is
            // BEHIND a water surface seen from outside (the point is projected to
            // screen and checked for water in front) -> shafts are sculpted by the
            // waves in BOTH cases (underwater AND looking at water from the bank).
            float uw = (isEyeInWater == 1) ? 1.0 : 0.0;
            // World Y of the water surface actually crossed by this march step
            // (captured below when isWater, no extra cost); falls back to WATER_LEVEL.
            float uwSurfY = WATER_LEVEL;
            // Screen projection + colortex2 tap SHARED between water detection and
            // the lava halo (2 -> 1 per step).
            vec2 puvS = vec2(-1.0);
            float matBS = 0.0;
            bool onScrS = false;
            if (isEyeInWater == 0) {
                vec4 pc = gbufferProjection * vec4(p, 1.0);
                puvS = ((pc.xy / pc.w) * 0.5 + 0.5) * TAAU_S; // TAAU: shared projection (VL water + lava halo)
                onScrS = (puvS.x > 0.0 && puvS.x < TAAU_S && puvS.y > 0.0 && puvS.y < TAAU_S);
                if (onScrS) matBS = texture2D(colortex2, puvS).b;
                vec2 puv = puvS;
                if (onScrS) {
                    float matB = matBS;
                    bool isWater = matB > 0.95;
                    // "Submerged glass" DISABLED as a water proxy: matB is glass,
                    // and wp.y < WATER_LEVEL does not prove water is present (dry
                    // glass below y63 was getting blue shafts). Only real water
                    // (isWater) sculpts the shafts when the eye is outside.
                    bool isGlass = false;
                    if (isWater || isGlass) {
                        vec3 wsv = toView(puv, texture2D(depthtex0, puv).r);
                        if (p.z < wsv.z) {
                            uw = isWater ? 1.0 : 0.55;
#if PIXEL_WATER_FIX == 1
                            // wsv is the water surface SEEN in front of this step:
                            // its world Y replaces the Y63 assumption for god rays
                            // viewed from outside (ravine puddle, high lake).
                            // No extra cost: wsv is already computed.
                            if (isWater) uwSurfY = (mat3(gbufferModelViewInverse) * wsv + cameraPosition).y;
#endif
                        }
                    }
                    // Submerged glass: every area below the water level gets the
                    // shafts even from inside the structure
                    if (inGlassUW && uw < 0.5 && wp.y < WATER_LEVEL - 0.2) uw = 0.60;
                }
            }
            float dens;
#if UW_SHAFTS_UNIFIED == 1
            // AIR part of this step's extinction: everything the march would
            // weight the step with if there were no water behind it. The
            // unified beam gain reads it (see (d3) below), so it MUST stay
            // wMirror-INDEPENDENT -- the two half-res endpoints (w = 0 and
            // w = 1) have to produce the same beam. Exactly the densBase /
            // kUW split lib/vl_halfres.glsl already uses.
            // (MIRRORED in lib/vl_halfres.glsl, keep in sync)
            float densNoUW = 0.0;
#endif
#ifdef DAWN_MIST_VOL_ACTIVE
            // Share of this step's density that IS dawn mist, kept so the
            // in-scatter below can give the mist its own ambient weight
            // (DAWN_MIST_AMB) instead of the 0.22 haze weight. Declared HERE,
            // at the same scope as dens, because the consumer sits OUTSIDE the
            // air / water branch. Stays 0 on every submerged step.
            // (MIRRORED in lib/vl_halfres.glsl, keep in sync)
            float dmAdd = 0.0;
#endif
            if (isEyeInWater == 1 || (inGlassUW && uw > 0.4)) {
                dens = 0.026 * WATER_FOG_DENSITY * UW_DENSITY_BOOST;
                #ifdef UW_VOLUMETRICS
#if PIXEL_WATER_FIX == 1
                // Estimated local surface >= submerged eye (same trick as the
                // god-ray surface clamp): correct UW density in a high lake,
                // identical in the ocean (below Y63 the max changes nothing).
                float uwY = clamp((max(WATER_LEVEL, cameraPosition.y + 0.4) - wp.y) / 16.0, 0.0, 1.0);
#else
                float uwY = clamp((WATER_LEVEL - wp.y) / 16.0, 0.0, 1.0);
#endif
                dens *= (0.6 + 0.9 * uwY);
                #endif
                // A march step ABOVE the surface returns to AIR density (no blue
                // veil pasted on the emerged bank while swimming toward land).
                float subVL = smoothstep(0.0, 0.4, max(WATER_LEVEL, cameraPosition.y + 0.4) - wp.y);
                dens = mix(airDens, dens, subVL);
            } else {
                // PATCHY fog: irregular drifting banks
#if DIMENSION_FX == 1
                // patchy has ONE consumer, the hfDens term below, and hfDens is
                // forced to 0.0 in the Nether (airDens block above), so the tap
                // is paid for a product that is identically zero. Fold it into
                // the same uniform ternary: Overworld bit-identical (dimN = 0.0
                // -> the legacy expression), Nether bit-identical too
                // (0.0 * exp(...) * patchy == 0.0 for any patchy), one texture
                // fetch per march step saved there.
                // (MIRRORED in lib/vl_halfres.glsl, keep in sync)
                float patchy = (dimN > 0.5) ? 0.0 : 0.45 + 1.10 * vnoiseTex(wp.xz * 0.012 + frameTimeCounter * 0.015);
#else
                float patchy = 0.45 + 1.10 * vnoiseTex(wp.xz * 0.012 + frameTimeCounter * 0.015);
#endif
#if DIMENSION_FX == 1 && NETHER_VOLUMETRIC == 1
                // NETHER_VOLUMETRIC (MIRRORED in lib/vl_halfres.glsl): the
                // Nether air density rolls through the animated smoke field
                // (lib/dimension.glsl netherFogNoise, mean 1.0 -> same
                // average transmittance); the shared Beer-Lambert step makes
                // the ambient in-scatter follow the same pockets, so the
                // sheets read everywhere and the lava columns pierce them
                // brighter. Exactly airDens outside the Nether (dimN = 0.0).
                float dimAirD = (dimN > 0.5) ? airDens * netherFogNoise(wp, frameTimeCounter) : airDens;
#else
                float dimAirD = airDens;
#endif
                dens = dimAirD + hfDens * exp(-max(wp.y - WATER_LEVEL, 0.0) * 0.025 / HEIGHT_FOG_FALLOFF) * patchy;
                     // SUBMERGED share of the step, added at the END of this
                     // branch now (see densNoUW there) instead of here, so the
                     // air terms below join it in the same order as
                     // densBase / kUW in lib/vl_halfres.glsl.
                     // Reduced submerged extinction when the eye is outside: the
                     // water absorption is already done in the water branch, and a
                     // higher value blackens distant water along the long submerged
                     // path of a grazing ray. WEIGHTED by the pixel's mirror
                     // dominance (wMirror): at grazing angles the pixel is ~97%
                     // REFLECTED sky, so its light does NOT cross the water column
                     // the march follows behind the surface. Without this weight,
                     // ~120 submerged blocks dim the sunset mirror to ~35% and
                     // replace it with the blue ambM veil. Caustic shafts seen from
                     // the bank and the sun halo go through the same (1-a) factor,
                     // so they are protected too. The 15% floor is the genuinely
                     // transmitted share (reflW <= 0.98). Air (airDens/hfDens) is
                     // UNCHANGED -> exact continuity between mirror water and the
                     // neighbouring sky at the horizon. MUST stay in sync with
                     // wMirror in the water branch.
#ifdef END_STORM_ACTIVE
                // End haze altitude profile (MIRRORED in lib/vl_halfres.glsl)
                if (dimE > 0.5) dens += airDens * (endHazeProfile(wp.y) - 1.0);
#endif
                // Mist sheet just above the water, at dawn and dusk
                #ifdef SEALEVEL_MIST
#if DIMENSION_FX == 1
                // EXPLICIT dimensional lock (MIRRORED in lib/vl_halfres.glsl):
                // this was the only density term of the march whose extinction
                // in the Nether / End was implicit, resting on duskF = 0 - true
                // only because vanilla freezes those suns (fixed_time 18000 /
                // 6000). A datapack restoring a solar cycle would paste a mist
                // sheet at WATER_LEVEL + 1.3 inside the dimensional fog. Every
                // neighbouring term (hfDens, VL_RAIN, lightC, ambC) already
                // carries this weight; both factors are exactly 1.0 in the
                // Overworld, so the render there is bit-identical.
                dens += exp(-abs(wp.y - (WATER_LEVEL + 1.3)) * 0.55) * duskF * 0.012 * HEIGHT_FOG_DENSITY
                      * (0.3 + 0.7 * vnoiseTex(wp.xz * 0.025 + frameTimeCounter * 0.02))
                      * (1.0 - dimN) * (1.0 - dimE);
#else
                dens += exp(-abs(wp.y - (WATER_LEVEL + 1.3)) * 0.55) * duskF * 0.012 * HEIGHT_FOG_DENSITY
                      * (0.3 + 0.7 * vnoiseTex(wp.xz * 0.025 + frameTimeCounter * 0.02));
#endif
                #endif
                // DAWN MIST as a REAL medium (DAWN_MIST_VOL): one more per-step
                // density term, exactly like the SEALEVEL_MIST sheet above, so
                // it inherits the per-step shadow taps, the cloud shadows, the
                // phase and the dither of this march -- banks carved by trees
                // and hills instead of a flat veil. (1 - uw): no dawn mist
                // inside a water column (uw goes to 1 as soon as the step sits
                // behind a water surface). An AIR term, hence wMirror-
                // INDEPENDENT like airDens / hfDens: exact continuity between
                // mirror water and the sky beside it at the horizon.
                // (MIRRORED in lib/vl_halfres.glsl, keep in sync)
#ifdef DAWN_MIST_VOL_ACTIVE
                if (dmOn) {
                    dmAdd = dawnMistDens(wp, dmD0, dmAnchorY, dmK, dmT,
                                         dmPatchy) * (1.0 - uw);
                    dens += dmAdd;
                }
#endif
                // Precipitation: downward-animated rain filaments, visible inside
                // the volumetric shafts (the drops scatter light)
                #ifdef VL_RAIN
#if DIMENSION_FX == 1
                // Vanilla syncs the global rain state into every dimension
                // (the Nether / End level data derive from the Overworld's):
                // no rain filaments inside the dimensional fog. Uniform
                // branch, exact legacy test in the Overworld.
                // (MIRRORED in lib/vl_halfres.glsl)
                if (rainStrength > 0.01 && dimN < 0.5 && dimE < 0.5) {
#else
                if (rainStrength > 0.01) {
#endif
                    vec3 rp3 = vec3(wp.x * 3.5 + wp.z * 3.5,
                                    wp.y * 0.05 - frameTimeCounter * 5.0,
                                    wp.x * 2.1 - wp.z * 2.1);
                    float rn = vnoise3(rp3);
                    dens += rainStrength * smoothstep(0.80, 0.94, rn) * 0.0028;
                }
                #endif
#if UW_SHAFTS_UNIFIED == 1
                // Air part frozen here (mist sheets, dawn banks and rain
                // included: they all weight a submerged step exactly like the
                // haze does), THEN the wMirror-weighted submerged share.
                // (MIRRORED in lib/vl_halfres.glsl, keep in sync)
                densNoUW = dens;
#endif
                dens += uw * 0.008 * (1.0 - wMirror * 0.85);
            }

            // Sun visibility (cast shadows in the haze, stained glass colors)
            vec3 vis = vec3(1.0);
#if UW_SUN_COHERENT == 1
            // ---- UW_SUN_COHERENT: SUBMERGED shadow probe ----
            // (MIRRORED in lib/vl_halfres.glsl, keep in sync)
            // The shadow map is an AIR structure: sampled at a submerged step
            // it answers "is the star visible from here ALONG THE AIR RAY?",
            // and the light/dark bands it carves into the beam therefore tilt
            // at theta_air -- 70 deg off vertical for a 20-deg sun, while the
            // beam itself rides the 44.8-deg refracted ray built two blocks
            // below. TWO directional structures, 25 deg apart, multiplied
            // together: that is a shaft system which visibly does not follow
            // the sun, and it survived the previous unification because vis
            // was never part of it.
            // The light that lands on this step crossed the surface at ONE
            // point, and it is THAT point whose air occlusion decides the
            // beam. Probe there: same wLev the shaft term uses (real crossed
            // surface from outside, eye level or WATER_LEVEL when submerged),
            // slid by the SAME refracted direction, so a cliff / a boat / a
            // bank enters the water at the shaft angle. Cost: zero extra taps.
            // Trade-off, deliberate: an occluder BETWEEN the step and the
            // surface no longer shadows the beam. It used to, at the wrong
            // angle; and the two probes only separate as the column grows
            // (~0.22 block per block at this pack's noon, ~1.75 at 20 deg).
            // AIR steps keep the EXACT legacy call: mat3(gbufferModelViewInverse)
            // * p is what toShadowClip builds internally, and it is used here
            // rather than the cheaper (wp - cameraPosition) because that
            // subtraction cancels ~4 significant digits at large world
            // coordinates and would jitter the probe a whole shadow texel far
            // from spawn. The mat3 is paid on SUBMERGED steps only.
            vec3 sc;
#if UW_SHAFT_FIX3 == 1
            // ---- UW_SHAFT_FIX3 (B): the probe comes back TO THE STEP ----
            // (MIRRORED in lib/vl_halfres.glsl, keep in sync)
            // The surface probe below only existed because the beam rode an
            // axis the shadow map does not know. It no longer does (A), so the
            // shadow map's own bands ARE the beam's bands when read AT the
            // step: one structure instead of two multiplied together.
            // What that buys is the whole of symptom (B). The PLAYER is
            // rasterized into the shadow map (shadowEntities / shadowPlayer,
            // shaders.properties), and so is every submerged wreck, hull and
            // coral head. Probing at the step tests them. Probing at the
            // surface crossing point could NOT, by construction: the segment
            // between the step and the surface was never sampled at all, which
            // is exactly why the beams went through the diver. And the dark
            // notch this cuts in the beam is now the SAME OBJECT as the shadow
            // he casts on the floor -- same map, same texel, same direction --
            // which is the test the report is built on.
            // It also removes the (C) half of that probe: the slide pushed the
            // tap up to 1.42x the column length away from the step (a 30-block
            // column probed 42 blocks off, sqrt(1 + tan^2(48.59 deg))), i.e.
            // straight out of the shadow map, where the fog's fail-open relit
            // the beam at full strength through whatever stood in the way.
            // Cost: NEGATIVE. This is the EXACT legacy call, and the mat3, the
            // divide and the two ternaries the surface probe paid on every
            // submerged step are gone.
            sc = toShadowClip(p, vec3(0.0));
#else
            if (uw > 0.25 && lightW.y > 0.05) {
#if PIXEL_WATER_FIX == 1
                float wLevV = (isEyeInWater == 1) ? max(WATER_LEVEL, cameraPosition.y + 0.4) : uwSurfY;
#else
                float wLevV = (isEyeInWater == 1) ? max(WATER_LEVEL, cameraPosition.y + 0.4) : WATER_LEVEL;
#endif
                float toSurfV = max(wLevV - wp.y, 0.0);
                // uwLightW.xz / uwLightW.y * depth is EXACTLY the slide the
                // caustic lookup uses, under BOTH caustic generations: it is
                // vlCa4Offset(lightW, depth) with CAUSTICS_V4 on, and the raw
                // v3 cprjOff (lightW.xz / max(lightW.y, 0.15) * depth) with it
                // off, because uwLightW itself falls back to that slope. So the
                // probe lands on the very texel the caustic lookup reads either
                // way, and the beam can never be cut 25 deg away from the spot
                // it lights.
                vec2 slideV = uwLightW.xz * (toSurfV / uwLightW.y);
                sc = toShadowClipWorld(mat3(gbufferModelViewInverse) * p
                                       + vec3(slideV.x, toSurfV, slideV.y));
            } else {
                sc = toShadowClip(p, vec3(0.0));
            }
#endif
#else
            vec3 sc = toShadowClip(p, vec3(0.0));
#endif
            float f = getDistortFactor(sc.xy);
            vec3 sp = distortShadow(sc, f) * 0.5 + 0.5;
            // ---- UW_SHAFT_FIX3 (C): does this probe have any DATA? ----
            // (MIRRORED in lib/vl_halfres.glsl, keep in sync)
            // Declared in the COMMON trunk, before the #if that fills it: the
            // consumer is the beam term far below, outside every gate here.
            // 1.0 = the probe answered from real shadow-map data. The two
            // fail-open cases below (outside the map, past the frustum Z) are
            // RIGHT for the fog -- a false dark anti-sun shaft is worse than a
            // missing one -- and are a LIGHT LEAK on the beam, which is what
            // "de la lumiere passe a travers" is: the sun claimed at full
            // strength precisely where nothing is known about occlusion.
            // Weights the underwater beam ONLY; fog, ambient and every air
            // term keep the legacy fail-open untouched.
            float shOK = 1.0;
#if UW_SHAFT_FIX3 == 1
            shOK = 0.0; // no tap at all -> no claimed sunlight
#endif
            if (sp.x > 0.0 && sp.x < 1.0 && sp.y > 0.0 && sp.y < 1.0) {
                float zb = sp.z - 0.0008 * (VLX_SHADOW_ZSCALE * 2.0); // constant world-space bias
                float s1 = step(zb, texture2D(shadowtex1, sp.xy).r);
                // z0G hoisted out of the step(): WCOL_V3 prices the VOLUMETRIC
                // light leg from the RAW depth of the translucent blocker, the
                // same way sampleShadowPCF prices the surface one. No extra tap,
                // and step() sees exactly the value it always did.
                float z0G = texture2D(shadowtex0, sp.xy).r;
                float s0 = step(zb, z0G);
                vec3 c = vec3(1.0);
#if SHADOW_TEX1_GATE_FIX == 1
                // RGB tag: mirror of the receiver in lighting.glsl -- RGB bands
                // (water max(rgb)<0.325 decoded tint, glass <0.675 decoded tint,
                // otherwise solid/clear white = full occlusion of the shafts).
                // Encoding is documented in shadow.fsh; keep both receivers in sync.
                // WCOL_V3 (MIRRORED in lib/vl_halfres.glsl): the WATER band is a
                // TRANSMITTANCE now, not an albedo read as a tint. Under V2 both
                // legs of the column were the same constant and agreed by
                // construction; V3 moved the SURFACE leg to Beer-Lambert and left
                // this one decoding the tag, so the beam was 3.77x darker and 4.2x
                // bluer than the light it deposited on the floor it lit
                // (decoded tag (0.0741,0.1945,0.6258) luma 0.2000 R/B 0.118 at
                // EVERY depth, against vlxWaterShadowT at 2 blocks under a zenith
                // sun (0.4505,0.8270,0.9176) luma 0.7535 R/B 0.491 - the two only
                // crossed near 13 blocks). Same function, same spectrum, same
                // dials, so WATER_ABSORB_*, WATER_CLARITY and WATER_DEPTH_DENSITY
                // now really do reach both legs. The thickness is read from the
                // SAME biased zb the tap already holds, which is what
                // waterAboveShadow does with its own 0.0009 - so the beam and
                // the pack's other water-thickness probe share one small
                // constant under-read instead of disagreeing with each other.
                if (s0 < s1) {
                    vec4 scG = texture2D(shadowcolor0, sp.xy);
                    float tagMxG = max(max(scG.r, scG.g), scG.b);
#if WCOL_V3 == 1
                    if (tagMxG < 0.325)      c = vlxWaterShadowT(zb - z0G);
#else
                    if (tagMxG < 0.325)      c = clamp(scG.rgb / 0.30, 0.0, 1.0);
#endif
                    else if (tagMxG < 0.675) c = clamp((scG.rgb - 0.35) / 0.30, 0.0, 1.0);
                    else s1 = 0.0;
                }
#else
                if (s0 < s1) c = texture2D(shadowcolor0, sp.xy).rgb;
#endif
                vis = vec3(s1) * mix(c, vec3(1.0), s0);
                // Fog sample BEYOND the shadow frustum Z range: no data ->
                // fail-open (otherwise false dark anti-sun shafts appear).
                vis = mix(vis, vec3(1.0), step(1.0, zb));
#if UW_SHAFT_FIX3 == 1
                // ---- UW_SHAFT_FIX3 (C): validity of THIS tap ----
                // (MIRRORED in lib/vl_halfres.glsl, keep in sync)
                // Same two data-free cases the line above fails open on, read
                // as a weight instead of as light: 0 past the frustum Z, and a
                // smooth ramp over the last 0.02 of the DISTORTED map.
                // WHY 0.02 -- DERIVED ON THE EXACT ACTIVE DISTORTION, not
                // linearised. (The naive read "one sp unit is
                // 2 * shadowDistance, so 0.02 = 7.68 blocks at 192" treats
                // getDistortFactor as a constant 1.0 at the border; it is
                // not.) Along an axis, 1 - sp = 0.02 means u = sc/f = 0.96
                // (sp = u*0.5+0.5), so the ramp spans
                //   (1 - h(0.96)) * shadowDistance
                // with h the inverse curve of lib/distort.glsl. Solved on
                // BOTH curves (figures match the SHADOW LOD block of
                // lib/settings.glsl):
                //   plateau curve (SHADOW_LOD_V2 1, shipped), default L2/R0:
                //     31.5 / 32.1 / 37.0 / 48.8 blocks at SHADOW_QUALITY
                //     0/1/2/3; over the 64 axis couples, 15.2 (narrowest,
                //     L0/R0 at SQ0) to 122.7 (L2/R3 at SQ3);
                //   legacy curve (SHADOW_LOD_V2 0, S = 0.90):
                //     37.6 / 56.5 / 75.3 / 112.9 blocks.
                // CRITERION: the ramp must be at least as wide as the widest
                // feature the beam draws, or it cuts a hard ring across the
                // shafts instead of dissolving them. causticShaftMask draws
                // 3-6 block blades spaced 4-10 (lib/water.glsl:887-888), and
                // 2-4 block shafts separated by 10-20 of penumbra at the
                // shipped UW_SHAFT_FINESSE: the narrowest couple (15.2
                // blocks) still clears the 6-block blades, and every default
                // clears the 20-block penumbra spacing too -- no ring at any
                // quality.
                // COST -- shOK at the END of the march, i.e. how much of the
                // far half of a beam this ramp costs (default L2/R0):
                //   dry eye, marchEnd 160, SQ1 (192): the ramp now only
                //     starts near 160 blocks, 1 - sp = 0.0199, smoothstep
                //     -> 1.00 (the legacy curve paid 0.818 here);
                //   diver, UW_RAY_DISTANCE 128 (VOLUMETRIC_QUALITY 3 since
                //     the VQ3 re-stage), SQ0 (128): the ray now ENDS exactly
                //     at the map's world span, so shOK dissolves to 0 over
                //     the march's last ~31 blocks (pre-VQ3 range 112 paid
                //     0.47; legacy curve: 0.537).
                // That second combination (lowest shadow quality + longest
                // underwater ray) is the only one where the attenuation is
                // large. If it is ever judged excessive, the upper bound can
                // drop -- but the replacement must carry its OWN measurement,
                // solved the same way on the active curve, and stay above the
                // 6-block blades at every couple.
                shOK = (1.0 - step(1.0, zb))
                     * smoothstep(0.0, 0.02, min(min(sp.x, 1.0 - sp.x),
                                                 min(sp.y, 1.0 - sp.y)));
#endif
            }

            // Clouds above shade the haze (sky/ground consistency)
            #ifdef VOLUMETRIC_CLOUDS
            #ifdef VC_GROUND_SHADOWS
#ifdef CLOUD_SHAFTS_ACTIVE
                // ---- CLOUD_SHAFTS : ombre des nuages PAR PAS ----
                // (MIRRORED in lib/vl_halfres.glsl -- blocs textuellement
                // identiques, diff obligatoire)
                // Les 2 sondes csA/csB interpolees lineairement ne pouvaient
                // dessiner aucune structure LE LONG du rayon -- et en
                // fabriquaient une FAUSSE en travers. MESURE (marche 0-160 b,
                // ombre pure, phase retiree) : a 10 et 45 deg de soleil leur
                // ecart-type vaut 0.0933 / 0.0809 contre 0.0093 / 0.0218 pour
                // la meme marche prise pas a pas avec le proxy exact -- 10 a 4
                // fois TROP de "structure", parce que ce sont deux silhouettes
                // de nuage tamponnees sur le ciel. Un tap bilineaire de la
                // carte cuite par prepare2 remplace la paire, AU PAS COURANT,
                // et restitue 96.6 a 99.5 % de l'amplitude de structure de
                // la reference SANS grille (proxy exact au point projete),
                // sur les 8 des 9 vues (3 hauteurs de soleil x 3 azimuts,
                // champ de vue entier) qui portent une structure -- la 9e
                // est un ciel uniforme des DEUX cotes. Biais de moyenne
                // nul a 1e-4 pres, 0.00 % du poids hors carte.
                // ctmShadow n'a PAS de sunUpF : a 1/2/3 deg de soleil les
                // sondes rendaient 1.000 (aucune ombre du tout) ; ici la
                // visibilite moyenne tombe a 0.989 / 0.987 / 0.560. C'est
                // exactement la demande du createur. Le fondu au ras de
                // l'horizon reste porte par lightUp, plus bas.
                // Cout : 1 tap bilineaire d'un R8 de 1 MiB par pas, contre
                // 2 evaluations completes du champ (~2 taps + ~40 ALU + un
                // pow() chacune) par rayon.
                vis *= ctmShadow(wp, lightW, CLOUD_SHADOW_DARKNESS);
#else
                // interpolation of the 2 precomputed probes (see loop header)
#if PERF_VL_ADAPTIVE == 1
                // B5: index -> ray-fraction over the EFFECTIVE count, so the
                // two probes still span [0, marchEnd]. MIRRORED in vl_halfres.
                vis *= mix(csA, csB, clamp((float(i) + 0.5) / float(vlN), 0.0, 1.0));
#else
                vis *= mix(csA, csB, clamp((float(i) + 0.5) / float(VL_SAMPLES), 0.0, 1.0));
#endif
#endif
            #endif
            #endif

            // Submerged segment (eye underwater OR glass base): caustic shafts are
            // computed PER MARCH STEP in the UW_VOLUMETRICS block below -- each wp
            // is projected to the surface ALONG lightW (cprj), so the light columns
            // are parallel to the sun/moon axis BY CONSTRUCTION and follow the
            // star; the shadow map (vis) still carves geometric occlusion on top.

            // Underwater the ambient is near zero: the light comes ONLY from the
            // surface, and that is what creates the directional shafts rather than
            // an isotropic glow. But with the eye OUTSIDE the water, submerged
            // steps with no in-scatter (ambM ~ 0 and phase ~ 0 facing away from the
            // sun) render distant water black -- so with the eye outside, the water
            // column DIFFUSES sky light in blue-green. Eye inside (or glass base)
            // keeps the near-zero ambient so the shafts stay intact.
            float eyeDry = (isEyeInWater == 1 || inGlassUW) ? 0.0 : 1.0;
#if UW_SHAFTS_UNIFIED == 1
            // The eye-dry 0.15 (against the diver's 0.008) was ALSO paying,
            // implicitly, for the direct light a submerged step loses when the
            // eye is dry -- that was the stated reason for leaving the beam
            // PEDESTAL out of the out-gain. (d3)/(d4) below now carry that half
            // explicitly, with the beam's own colour and shape, so this ambient
            // goes back to its own job (sky diffusion inside the column, never
            // black water) at about half the weight. Compensating twice would
            // wash the distant column out. UW_SHAFTS_UNIFIED 0 keeps 0.15.
            // (MIRRORED in lib/vl_halfres.glsl, keep in sync)
            float ambM = (uw > 0.25) ? mix(0.008, 0.08, eyeDry) : 0.22;
#else
            float ambM = (uw > 0.25) ? mix(0.008, 0.15, eyeDry) : 0.22;
#endif
#ifdef DAWN_MIST_VOL_ACTIVE
            // RADIANCE continuity with the analytic tail (DAWN_MIST_VOL): the
            // march lights every medium with the 0.22 HAZE ambient weight,
            // while the tail beyond 160 blocks lights the SAME mist with
            // ~0.92 of the local sky luminance. With the back to the sun the
            // phase term is ~3e-3, so the mist body was carried almost entirely
            // by ambC * 0.22 and read 4-5x darker than the layer it replaces --
            // a virage of tint with distance, and the 0.0030 calibration (done
            // for the analytic radiance) no longer matching. Blend the ambient
            // weight toward DAWN_MIST_AMB in proportion to the mist's share of
            // this step, so a pure-mist step is lit like the tail and a step
            // with no mist is bit-identical to before (mix(a, b, 0) == a).
            // The density continuity across 160 blocks is untouched: this only
            // changes the in-scatter, never dens. DAWN_MIST_AMB = 0.22 restores
            // the legacy look. (MIRRORED in lib/vl_halfres.glsl, keep in sync)
            float dmShare = clamp(dmAdd / max(dens, 1e-6), 0.0, 1.0);
            ambM = mix(ambM, DAWN_MIST_AMB, dmShare);
#endif
            // Column diffusion seen from outside, aligned with the ocean palette
            // (B ~= G, desaturated). A higher B/G ratio here re-azures the water
            // at mid distance on top of the corrected palettes, because it is
            // multiplied by an already blue gAmbC (blue squared).
            vec3 ambTint = (uw > 0.25 && eyeDry > 0.5) ? vec3(0.42, 0.75, 0.80) : vec3(1.0);
#if UW_SUN_COHERENT == 1
            // ---- UW_SUN_COHERENT: phase of the GENERIC direct in-scatter ----
            // (MIRRORED in lib/vl_halfres.glsl, keep in sync)
            // Same gate the shaft term uses. A submerged step reads the
            // REFRACTED lobe; an air step keeps its own, dusk boost included.
            // With UW_SHAFTS_UNIFIED on this only reaches the 0.8-block surface
            // window (uwDirW is 0 below it), and both sides of that window are
            // now built on one direction, so the handover stays continuous.
            // With UW_SHAFTS_UNIFIED off it carries the whole submerged direct
            // light, which is exactly the term that was pointing at the air sun.
            float phaseD = (uw > 0.25) ? phaseU : phase;
#else
            float phaseD = phase;
#endif
#if UW_SHAFTS_UNIFIED == 1
            // ---- UNIFIED UNDERWATER BEAM (a): kill the SECOND shaft family ----
            // (MIRRORED in lib/vl_halfres.glsl, keep in sync)
            // A submerged step used to get the generic direct in-scatter
            // lightC*vis*phase*lightUp -- an unmodulated beam family carved by
            // the shadow map alone -- AND, right below, the caustic shaft term.
            // Two additive sun beams of comparable magnitude, overlapping with
            // different geometry: THAT is the doubling seen while diving. The
            // direct light of a submerged step is now carried by the single
            // beam term below, whose own surface window is subW: uwDirW is its
            // exact complement, so the handover is continuous across the
            // surface (sum stays 1) and total once fully submerged. Air steps,
            // a sunk star (lightW.y <= 0.05) and UW_VOLUMETRICS off all keep
            // uwDirW = 1, i.e. the legacy term.
            float uwDirW = 1.0;
#ifdef UW_VOLUMETRICS
            if (uw > 0.25 && lightW.y > 0.05) {
#if UW_SURFACE_CLAMP == 1
#if PIXEL_WATER_FIX == 1
                float wLevD = (isEyeInWater == 1) ? max(WATER_LEVEL, cameraPosition.y + 0.4) : uwSurfY;
#else
                float wLevD = (isEyeInWater == 1) ? max(WATER_LEVEL, cameraPosition.y + 0.4) : WATER_LEVEL;
#endif
                uwDirW = 1.0 - smoothstep(0.0, 0.8, wLevD - wp.y);
#else
                uwDirW = 0.0; // no surface window in legacy clamp mode: subW is 1 there
#endif
                // Water entry of this ray (see the per-ray scalars): first
                // submerged step wins; stays 0 when the eye is submerged.
                if (uwEntryT < 0.0) uwEntryT = length(p);
            }
#endif
            vec3 S = lightC * vis * phaseD * lightUp * uwDirW + ambC * ambM * ambTint;
#else
            vec3 S = lightC * vis * phaseD * lightUp + ambC * ambM * ambTint;
#endif
#if DIMENSION_FX == 1
            // Nether lava columns (MIRRORED in lib/vl_halfres.glsl): height-map
            // glow at this step, same distorted shadow position as the
            // visibility taps above -> one shadowcolor0 tap, same step count.
            if (dimN > 0.5) S += lavaGlowAt(sp, f, lightWyN) * (0.30 * NETHER_VL);
#ifdef END_STORM_ACTIVE
            // End lightning in the haze (MIRRORED in lib/vl_halfres.glsl):
            // point light at the bolt, soft inverse square. Scaled by
            // END_LIGHTNING_POWER like the other three consumers (end_storm's
            // point light and bolt channel, deferred's sky haze halo), so the
            // dial really does reach every glow a strike makes - at 0 the
            // volumetric fog stays dark, as option.END_LIGHTNING_POWER says.
            // The default 1.0 multiplies exactly, so this is bit-identical.
            if (flE > 0.001) {
                vec3 tbE = bPE - wp;
                S += bCE * (flE * (1.2e4 * END_LIGHTNING_POWER) / (dot(tbE, tbE) + 2500.0));
            }
#endif
#endif
            // The gate below is uw > 0.25 (NOT isEyeInWater), so submerged steps of
            // a ray whose eye is on the bank get the same striations: uw goes to
            // 1.0 as soon as the step is behind a water surface seen from outside
            // (screen projection matB > 0.95 at the top of the step). Transmission
            // through the surface AND the grazing-mirror protection both act via
            // the eye-outside step density uw*0.008*(1-wMirror*0.85) inside the
            // in-scatter factor (1-a): at grazing angles the mirror wins, seen from
            // above wMirror ~ 0 and the striations show.
            #ifdef UW_VOLUMETRICS
            if (uw > 0.25 && lightW.y > 0.05) {
#if UW_SURFACE_CLAMP == 1
                // Anti-starburst (a): LOCAL surface level -- at least the eye
                // height when submerged (lakes above y63), otherwise WATER_LEVEL.
                // The caustic term only applies to the segment that is REALLY
                // submerged (subW): the march runs to OPAQUE terrain (depthtex1)
                // and crosses the surface, so without this the steps above water
                // get sharp unattenuated caustics (toSurf=0 -> beerR=1, shrp=1),
                // i.e. a frozen radial starburst around the sun seen from below.
#if PIXEL_WATER_FIX == 1
                // Eye OUTSIDE the water: the shaft reference surface is the REAL Y
                // of the crossed water surface (uwSurfY), not WATER_LEVEL. The
                // submerged branch (anti-starburst clamp) is unchanged.
                float wLev = (isEyeInWater == 1) ? max(WATER_LEVEL, cameraPosition.y + 0.4) : uwSurfY;
#else
                float wLev = (isEyeInWater == 1) ? max(WATER_LEVEL, cameraPosition.y + 0.4) : WATER_LEVEL;
#endif
                float toSurf = max(wLev - wp.y, 0.0);
                // 0.8 window: softer ENTER/EXIT fade right at the surface
                // (swimming, diving). Above the surface subW stays exactly 0, so
                // the anti-starburst contract holds.
                float subW = smoothstep(0.0, 0.8, wLev - wp.y);
#else
                float toSurf = max(WATER_LEVEL - wp.y, 0.0);
                float subW = 1.0;
#endif
                // ---- UW_SHAFT_BOUND: render limit hoisted ABOVE the taps ----
                // (MIRRORED in lib/vl_halfres.glsl, keep in sync)
                // Same fade as ever -- 0.7x..1.0x of UW_SHAFT_RENDER_DIST,
                // along the SUBMERGED path under UW_SHAFTS_UNIFIED (d1) and
                // the camera distance otherwise -- computed BEFORE the caustic
                // taps so a step past the bound can SKIP them: shaftFade is
                // exactly 0 there and the filament term it multiplies is
                // exactly 0 whatever the taps would have returned. The fade
                // lives entirely inside the paid zone, so the beams are
                // already gone where the taps stop -- no wall at the bound.
                float uwPathB = length(p);
#if PERF_OCEAN == 1
                // PERF_OCEAN (1): camera distance of the STEP, captured before
                // the submerged-path subtraction below. Consumed by the view
                // bound right after shaftFade and by the nSubU decay (2).
                // (MIRRORED in lib/vl_halfres.glsl, keep in sync)
                float uwCamB = uwPathB;
#endif
#if UW_SHAFTS_UNIFIED == 1
                uwPathB -= max(uwEntryT, 0.0);
#endif
                float shaftFade = 1.0 - smoothstep(UW_SHAFT_RENDER_DIST * 0.7, UW_SHAFT_RENDER_DIST, uwPathB);
#if PERF_OCEAN == 1
                // PERF_OCEAN (1): seen from the bank the filaments ALSO die by
                // CAMERA distance -- a 0.3-block striation is ~2 px at
                // UW_SHAFT_VIEW_DIST 96 (see MESURE 4, lib/settings.glsl).
                // Honest cost: the filament term weighs ~2x the pedestal in
                // the beam bracket (outGU already doubles the step amplitude
                // by construction), so this fade removes ~2/3 of the beam
                // luminosity over 69..96 blocks -- a few % of a grazing ocean
                // pixel's luminance, with NO discontinuity (continuous fade,
                // and 96 = 12*dt at VOLUMETRIC_QUALITY 3 so the skip frontier
                // lands on a whole step index). Multiplying shaftFade keeps
                // the existing shaftFade > 0 skip (UW_SHAFT_BOUND) as the REAL
                // early-out past the bound, filament term only (the pedestal
                // UW_SHAFT_BASE and the fog continue, as with the path bound).
                // A diver (isEyeInWater == 1) keeps the pure path bound.
                // (MIRRORED in lib/vl_halfres.glsl, keep in sync)
                if (isEyeInWater == 0)
                    shaftFade *= 1.0 - smoothstep(UW_SHAFT_VIEW_DIST * 0.72, UW_SHAFT_VIEW_DIST, uwCamB);
#endif
                // PER-STEP projection along the sun/moon axis: cprj is CONSTANT
                // along a light line -> bright/dark columns parallel to that
                // axis by construction, tilted with the star and following it.
                // WHICH axis, exactly: UNDER water the light lines are the
                // REFRACTED rays, not the ones in air. v3 slid along the raw
                // lightW.xz/lightW.y, which at a low sun tilts the columns up
                // to 81 deg off vertical - past the 48.6 deg Snell cone that
                // is the hard limit of anything entering water - and, with
                // CAUSTICS_V4, put the wide sheaves in a different place from
                // the fine net they are supposed to group (6x the slide at
                // sunset). Under v4 the sheaves now take the SAME Snell slide
                // as the net, from the same rotated shadow-light direction, so
                // shafts, striations and floor spots are one geometry. The v3
                // path keeps its own projection so its render stays
                // bit-identical (its floor sites slide the same raw way).
                // UW_SUN_COHERENT deliberately does NOT touch this v3 line: the
                // v3 FLOOR sites (the caustic drawn on the sand) slide the same
                // raw way, so refracting the column alone would put the beam
                // and the spot it lights in two different places -- the exact
                // fault being fixed. v3 is wrong as a whole, and coherently so.
                vec2 cprjOff = lightW.xz / max(lightW.y, 0.15) * toSurf;
#if UW_SHAFT_FIX3 == 1
                // ---- UW_SHAFT_FIX3 (A): THE anchor that sets the axis ----
                // (MIRRORED in lib/vl_halfres.glsl, keep in sync)
                // This is the term the eye actually reads as "the direction of
                // the shafts": cprj is CONSTANT along the direction it slides,
                // so the bright/dark columns are parallel to that direction by
                // construction. vlCa4Offset slid it along the Snell ray -- a
                // beam at 44.81 deg beside a shadow at 70.00 deg for a 20-deg
                // sun, same azimuth, 25.19 deg of elevation apart. uwShaftSlide
                // is the SHADOW MAP's own projection of a vertical drop, so the
                // columns and the cast shadow are one geometry.
                // NOT a new constant: uwShaftSlide(lightW, d) IS the v3
                // expression on the line above, floor included. The three
                // CAUSTICS_V4 floor sites move with it (composite1 water
                // branch), so a beam still lands on the spot it lights.
                cprjOff = uwShaftSlide(lightW, toSurf);
#elif CAUSTICS_V4 == 1
                cprjOff = vlCa4Offset(lightW, toSurf);
#endif
                vec2 cprj = wp.xz + cprjOff;
                // Beam extinction: lower = the column CARRIES further toward the
                // floor (0.06 vs 0.07 is ~+35% survival at 30 blocks of column)
                // without a single extra march step.
#if UW_GODRAY_CAUSTIC_LOCK == 1
                float beerR = exp(-toSurf * 0.06); // extended range
#else
                float beerR = exp(-toSurf * 0.07); // legacy LOCK=0 extinction
#endif
                // Phase and tint DEDICATED to the striation term -- declared HERE,
                // in the COMMON trunk. #if trap: they are used after the LOCK
                // #endif, so they must never be declared inside a gated block.
                // These neutral values make the LOCK==0 path identical.
                // phaseD is `phase` when UW_SUN_COHERENT is 0, and the
                // refracted lobe otherwise -- this block only ever runs inside
                // the uw > 0.25 gate, so the substitution is total here.
                float phaseShaft = phaseD;
                vec3 teinteShaft = vec3(0.80, 1.0, 0.94);
#if UW_GODRAY_CAUSTIC_LOCK == 1
                // The shaft pattern IS the projected caustic (shafts are the
                // caustic apertures of the surface), world-anchored.
                // TWO SCALES:
                //  - fine sub-block STRIATIONS: the pattern is the analytic fine
                //    caustic of the ripples (causticSmall, 0.1-0.4 block wide near
                //    the surface, softened going down). Real striations are
                //    10-30 cm wide -- they are ripple caustic filaments, not swell
                //    lenses, so the fine caustic that draws the floor is what must
                //    be projected into the column.
                //  - wide SHEAVES: causticShaftMask (water.glsl, a DEDICATED
                //    variant; causticLarge and the rendering caustic sites are
                //    untouched) only GROUPS the rays into fans with penumbra
                //    between them via the FINESSE/SPACING sliders. It no longer
                //    sets their width; used alone it produces needles at any gain.
                // sharp decreases with the column (spectral sigma rises): the
                // striations soften going down -- physical and anti-aliasing at once.
                // COST: causticSmall (~9 analytic trains) at EVERY submerged step
                // (~12-20). If the GPU budget is tight, lower VOLUMETRIC_QUALITY
                // rather than touching this block.
#if UW_SHAFTS_UNIFIED == 1 && CAUSTICS_V4 == 1
                // ---- UNIFIED UNDERWATER BEAM (b): SUB-SAMPLED wavefront ----
                // (MIRRORED in lib/vl_halfres.glsl, keep in sync)
                // Same field, same shaping and the same SHARED Snell lookup as
                // the reference branch below (under v4, cprjOff IS vlCa4Offset,
                // so the wide sheaves and the fine striations already ride one
                // wavefront); the ONLY difference here is that the step is
                // BOX-AVERAGED instead of point-sampled.
                // WHY: seen from the bank the march is bounded by the OPAQUE
                // floor, not by UW_RAY_DISTANCE, so a whole water column can
                // fall inside one 4-20 block step and the beams alias into TAA
                // noise -- part of why they did not read as "the same" from
                // outside. Averaging the field over the step IS the correct
                // integral for the weight that step carries. A submerged eye
                // always takes 1 tap, and nSubU = 1 lands exactly on wp, i.e.
                // on the reference expression: the step is already short there
                // and a diver must not pay for this.
                // TAP COUNT follows the STEP LENGTH: the aliasing these taps
                // fix is a function of how much column one step spans, and dt
                // is 5 blocks at VOLUMETRIC_QUALITY 3 (VQ3 re-stage)
                // against 20-40 at quality 0/1. One tap per ~4 blocks of step,
                // capped by the dial: the fine tiers stop paying for a
                // wavefront they already resolve, the coarse tiers keep the
                // full box average. Submerged: always 1 (a diver must not pay).
                // (float clamp then cast: the integer overloads of clamp are
                // GLSL 1.30+, and this block is mirrored into a #version 120
                // consumer, lib/vl_halfres.glsl via composite.fsh.)
                int nSubU = (isEyeInWater == 0)
                          ? int(clamp(floor(dt / 4.0) + 1.0, 1.0, float(UW_SHAFT_SUBSTEPS)))
                          : 1;
#if PERF_OCEAN == 1
                // PERF_OCEAN (2): the box average exists for aliasing where the
                // filaments are RESOLVED on screen -- decay the tap count with
                // the step's camera distance. Window ALIGNED BEHIND the
                // amplitude fade (1): full budget below
                // max(0.55 * UW_SHAFT_VIEW_DIST, 30) = ~53 blocks (steps there
                // are bit-identical), taps only start dropping once the
                // filament amplitude is itself falling (fade starts at 0.72x),
                // so the added estimator variance lands where the signal is
                // already dimming -- the single tap still lands exactly on wp,
                // i.e. on the reference expression. int(x + 0.5) rounds
                // (x >= 0). The skip stays wavefront-granular (SIMD pays the
                // max nSubU of the lanes; thresholds are not multiples of dt).
                // (MIRRORED in lib/vl_halfres.glsl, keep in sync)
                if (isEyeInWater == 0 && nSubU > 1) {
                    float subKU = 1.0 - smoothstep(max(UW_SHAFT_VIEW_DIST * 0.55, 30.0),
                                                   max(UW_SHAFT_VIEW_DIST * 0.95, 60.0), uwCamB);
                    nSubU = 1 + int(float(nSubU - 1) * subKU + 0.5);
                }
#endif
                float caAccU = 0.0;
                float wAccU = 0.0;
                // UW_SHAFT_BOUND: past the render limit the whole box average
                // is skipped (caShaft falls to 0 through the wAccU guard); the
                // term it feeds is multiplied by shaftFade == 0 anyway, so
                // this trades no pixels, only the taps.
#if UW_SHAFT_BOUND == 1
                if (shaftFade > 0.0)
#endif
                for (int ks = 0; ks < UW_SHAFT_SUBSTEPS; ks++) {
                    if (ks >= nSubU) break;
                    vec3 wpU = wp + wStepU * ((float(ks) + 0.5) / float(nSubU) - 0.5);
#if UW_SURFACE_CLAMP == 1
                    float toSurfU = max(wLev - wpU.y, 0.0);
                    // PER-TAP surface window, same curve as subW: the box sweeps
                    // +-dt/2 around the step centre, so from the bank a tap can
                    // land ABOVE the surface -- exactly where the field is
                    // sharpest and strongest (toSurf = 0 -> shrp = 1), which is
                    // what the anti-starburst clamp forbids everywhere else. Its
                    // weight is renormalised out below, so the average stays an
                    // average of SUBMERGED samples only. nSubU == 1 keeps weight
                    // 1 and lands on wp, i.e. the reference expression.
                    float wSubU = (nSubU > 1) ? smoothstep(0.0, 0.8, wLev - wpU.y) : 1.0;
#else
                    float toSurfU = max(WATER_LEVEL - wpU.y, 0.0);
                    float wSubU = (nSubU > 1) ? smoothstep(0.0, 0.8, WATER_LEVEL - wpU.y) : 1.0;
#endif
                    float shrpU = clamp(1.0 - toSurfU / 45.0, 0.20, 1.0);
                    // (A) same anchor as cprj above, per sub-tap.
                    // (MIRRORED in lib/vl_halfres.glsl, keep in sync)
#if UW_SHAFT_FIX3 == 1
                    vec2 lookU = wpU.xz + uwShaftSlide(lightW, toSurfU);
#else
                    vec2 lookU = wpU.xz + vlCa4Offset(lightW, toSurfU);
#endif
#if VLX_PHYS_SYNC == 1
                    // PHYSICS_FIELD_SYNC, PUITS DE LUMIERE (sous-tap du box
                    // average). Le pas n'a pas d'estampille (il est dans le
                    // volume, pas sur la surface) : meme regle ambiante que le
                    // site immerge, plus le test d'altitude sur la nappe a
                    // laquelle CE tap se projette. causticShaftMask lit lookU
                    // BRUT (aucun VL_CA5_REG) -> reg 0 ; vlCa4Vol lit la meme
                    // position moins le REG -> on le lui rend.
                    // (MIRRORED in lib/vl_halfres.glsl, keep in sync)
                    bool vlxPhU = vlxPhysAmb && abs((wpU.y + toSurfU) - WATER_LEVEL) < 1.5;
                    VLX_PHYS_SET(vlxPhU, vlxPhysAmbWav, 0.0);
#endif
                    float caWideU = causticShaftMask(lookU, frameTimeCounter, toSurfU);
#if VLX_PHYS_SYNC == 1
                    VLX_PHYS_SET(vlxPhU, vlxPhysAmbWav, VL_CA5_REG(wpU.y + toSurfU));
#if VLX_PHYS_REAL == 1
                    // PHYS_REAL : vlCa4Vol n'a pas d'argument de profondeur, et
                    // sous PHYS_REAL sa densite en a besoin. Le tap la connait :
                    // il la pose ici (colonne d'eau au-dessus du pas).
                    // (MIRRORED in lib/vl_halfres.glsl, keep in sync)
                    vlxPhysDepth = toSurfU;
#endif
#endif
                    // CA5 registration: wpU.y + toSurfU IS the sheet altitude
                    // this tap projects to (VL_CA5_REG is 0.0 under v4).
                    float caFineU = vlCa4Vol(lookU - VL_CA5_REG(wpU.y + toSurfU),
                                             frameTimeCounter, shrpU, lightW);
                    float fineU = clamp((caFineU - 0.42) * 1.45, 0.0, 1.5);
                    float openU = fineU * (0.38 + 0.62 * caWideU);
                    float gmaU = mix(1.30, 1.10, clamp(toSurfU * 0.045, 0.0, 1.0));
                    caAccU += wSubU * clamp(0.02 + 2.9 * pow(clamp(openU, 0.0, 1.3), gmaU), 0.0, 3.0);
                    wAccU += wSubU;
                }
                // caAccU <= 3 * wAccU by construction, so the guard can only
                // return 0 when every tap of the box is emerged -- a step whose
                // own subW is already fading the beam out.
                float caShaft = caAccU / max(wAccU, 1e-4);
                // The flat 0.22 floor of the legacy mix moves to UW_SHAFT_BASE
                // (ONE pedestal, not two): UW_GODRAY_DIRECTIONAL is now purely
                // the striation contrast. 0.8*caShaft vs 0.044 + 0.8*caShaft.
                float caDir = caShaft * UW_GODRAY_DIRECTIONAL;
#else
                // UW_SHAFT_BOUND: same skip as the box-averaged branch above --
                // past the render limit the point-sample of the field is not
                // paid; caDir = 0 is multiplied by shaftFade == 0 in the S
                // term, so the skip changes no pixel.
                float caDir = 0.0;
#if UW_SHAFT_BOUND == 1
                if (shaftFade > 0.0)
#endif
                {
#if VLX_PHYS_SYNC == 1
                // PHYSICS_FIELD_SYNC, PUITS DE LUMIERE (branche point-sample) :
                // meme regle que la branche box-average ci-dessus.
                // (MIRRORED in lib/vl_halfres.glsl, keep in sync)
                bool vlxPhS = vlxPhysAmb && abs((wp.y + toSurf) - WATER_LEVEL) < 1.5;
                VLX_PHYS_SET(vlxPhS, vlxPhysAmbWav, 0.0);
#endif
                float caWide = causticShaftMask(cprj, frameTimeCounter, toSurf);
                // Spread-out sharpness fade: striations stay readable deeper before
                // dissolving into haze (0.20 floor).
                float shrpU = clamp(1.0 - toSurf / 45.0, 0.20, 1.0);
#if CAUSTICS_V4 == 1
#if VLX_PHYS_SYNC == 1
                // VL_CA5_REG n'existe QUE sous CAUSTICS_V4 == 1 (bloc v4 de
                // lib/water.glsl) : le SET qui le porte doit vivre ici, pas
                // au-dessus du #if. Sous CAUSTICS_V4 == 0 les striations fines
                // restent causticSmall, le champ du pack, et seules les gerbes
                // larges suivent le mod - documente.
                VLX_PHYS_SET(vlxPhS, vlxPhysAmbWav, VL_CA5_REG(wp.y + toSurf));
#if VLX_PHYS_REAL == 1
                // PHYS_REAL : profondeur de propagation du tap (voir la branche
                // box-average ci-dessus).
                // (MIRRORED in lib/vl_halfres.glsl, keep in sync)
                vlxPhysDepth = toSurf;
#endif
#endif
                // v4 (MIRRORED in lib/vl_halfres.glsl, keep in sync): the fine
                // striations ARE the photon-density net, read at the same
                // world lookup as the floor sites (projected along the
                // REFRACTED sun ray), so a beam and the spot it lights are the
                // same mesh at the same world position. One field evaluation
                // per step, no Jacobian, no extra jitter -> ~2.3x cheaper than
                // the causticSmall it replaces, which matters at 4-12
                // submerged steps per ray. It reads cprj DIRECTLY now: under
                // v4 the sheaf mask above already uses that same Snell slide,
                // so the two cannot drift apart, and the second vlCa4Offset
                // call this used to pay is gone.
                // CA5 registration: wp.y + toSurf IS the sheet altitude cprj
                // projects to (VL_CA5_REG is 0.0 under v4).
                float caFine = vlCa4Vol(cprj - VL_CA5_REG(wp.y + toSurf),
                                        frameTimeCounter, shrpU, lightW);
#else
                float caFine = causticSmall(cprj, frameTimeCounter, shrpU);
#endif
                // Subtract the flat base (0.42): REAL penumbra between striations.
                float fineM = clamp((caFine - 0.42) * 1.45, 0.0, 1.5);
                // Grouping floor: striations live a bit everywhere while the
                // sheaves stay readable (same energy at max, caWide = 1).
                float caOpen = fineM * (0.38 + 0.62 * caWide);
                float gmaD = mix(1.30, 1.10, clamp(toSurf * 0.045, 0.0, 1.0));
                // Gain and cap for the shaft brightness; 0.02 penumbra floor.
                float caShaft = clamp(0.02 + 2.9 * pow(clamp(caOpen, 0.0, 1.3), gmaD), 0.0, 3.0);
                caDir = mix(0.22, caShaft, UW_GODRAY_DIRECTIONAL);
                }
#endif
                // The forward HG phase (g ~0.6) would kill the striations when
                // looking away from the sun (~x50 front to back). An isotropic
                // floor is mixed in for the STRIATION TERM ONLY -- the general fog
                // keeps its physical phase. Result: ~40-50% intensity facing away.
#if UW_SHAFTS_UNIFIED == 1
                // (c) side-independent phase: phaseW is the WATER HG (g = 0.58)
                // whatever the camera does. Identical to `phase` when the eye is
                // submerged (gP is already 0.58 and the dusk boost is air-only),
                // so this only stops the beam from sharpening when seen from
                // the bank at dusk.
                phaseShaft = mix(phaseW, 0.30, 0.35);
#else
                // UW_SUN_COHERENT folds into phaseD: refracted axis when the
                // gate is on, plain `phase` when it is off.
                phaseShaft = mix(phaseD, 0.30, 0.35);
#endif
                // Near the surface the beam tint pulls toward the REAL sun color
                // (gLightC chroma normalized by luma, clamped to 2.0 -- same
                // pattern as FOG_BIOME_TINT): GOLDEN rays like daylight at the
                // surface, cooling to cyan-green at depth (water absorbs red).
                // Tints ONLY the god-ray term.
                vec3 shChroma = min(gLightC / max(luma(gLightC), 1e-3), vec3(2.0));
                teinteShaft = mix(vec3(0.80, 1.0, 0.94), shChroma,
                                  0.45 * clamp(1.0 - toSurf / 20.0, 0.0, 1.0));
#else
                // UW_SHAFT_BOUND: the legacy blades pay waveCausticFull per
                // step; past the render limit the whole term is multiplied by
                // shaftFade == 0, so the field is skipped here too.
                float caDir = 0.0;
#if UW_SHAFT_BOUND == 1
                if (shaftFade > 0.0)
#endif
                {
                vec2 caF = waveCausticFull(cprj, frameTimeCounter, toSurf);
                float caLarge = caF.y;
                // In sync with the modulative caustic in water.glsl: caF.x no
                // longer carries an additive large-octave term -> subtract nothing,
                // just threshold.
                float caSmall = clamp(caF.x - 0.20, 0.0, 1.0);
                float caM = clamp((0.35 + 0.65 * caLarge) * (0.4 + 1.1 * caSmall), 0.0, 1.5);
                // Light blades ALIGNED on the sun/moon axis (lightW), not pasted
                // vertically. Orthonormal basis (baxA, baxB) in the plane
                // perpendicular to lightW, with a degeneracy guard when lightW is
                // nearly vertical (alternate up vector).
#if UW_SUN_COHERENT == 1
                // LOCK == 0 legacy blades, on the ONE refracted axis like every
                // other underwater term (uwLightW is already unit).
                vec3 Ldir = uwLightW;
#else
                vec3 Ldir = normalize(lightW);
#endif
                vec3 upRef = (abs(Ldir.y) > 0.95) ? vec3(1.0, 0.0, 0.0) : vec3(0.0, 1.0, 0.0);
                vec3 baxA = normalize(cross(Ldir, upRef));
                vec3 baxB = cross(Ldir, baxA);
                vec3 rel = wp - cameraPosition;
                float sa = dot(rel, baxA);
                float sb = dot(rel, baxB);
                // Blade profile: tilted on the sun axis and animated -> they sweep with the cycle.
                float shaftDir = 0.55 + 0.45 * sin(sa * UW_GODRAY_TILT
                               + sin(sb * UW_GODRAY_TILT * 0.7) * 1.3
                               + frameTimeCounter * 0.25);
                caDir = caM * mix(1.0, shaftDir, UW_GODRAY_DIRECTIONAL);
                }
#endif
#if UW_SUNGAZE_SOFT == 1
                // Anti-starburst (b): staring at the star (cosT -> 1, ~<17 deg off
                // axis), columns parallel to lightW degenerate on screen into radial
                // rays converging on the disc (vanishing point). The caustic
                // modulation is faded toward its mean (0.55) near the axis -> smooth
                // halo around the disc, tilted columns intact everywhere else.
#if UW_SUN_COHERENT == 1
                // The columns converge on the REFRACTED axis, so that is where
                // the vanishing point sits and where the softening belongs. On
                // the air cosT this smoothing was applied 25 deg off at a
                // 20-deg sun: it blurred empty water and left the real
                // starburst untouched -- one more structure sitting beside the
                // sun instead of on it. (MIRRORED in lib/vl_halfres.glsl)
                float gazeW = smoothstep(0.955, 0.9985, cosTU);
#else
                float gazeW = smoothstep(0.955, 0.9985, cosT);
#endif
                caDir = mix(caDir, 0.55, gazeW * 0.75);
#endif
                // Slightly CYAN-GREEN column tint (water re-greens the light INSIDE
                // the beam) applied to the god-ray term ONLY: the ambient and the
                // UW fog keep their own palette. phaseShaft carries the isotropic
                // floor facing away from the sun, teinteShaft the golden surface
                // tint; both fall back to (phase, cyan-green) when LOCK == 0.
                // Eye-distance render limit on the god-ray term ONLY: shafts
                // melt away between 0.7x and 1.0x UW_SHAFT_RENDER_DIST like a
                // real dive where distant rays drown in the haze. The march,
                // the UW fog and the ambient continue past it unchanged.
#if UW_SHAFTS_UNIFIED == 1
                // ---- UNIFIED UNDERWATER BEAM: the SINGLE additive term ----
                // (MIRRORED in lib/vl_halfres.glsl, keep in sync)
                // (d1) RENDER LIMIT measured along the SUBMERGED path instead
                //      of from the camera. uwEntryT is 0 when the eye is in the
                //      water (a diver keeps exactly the legacy fade) and the
                //      water entry of the ray otherwise, so a lake 40 blocks
                //      away keeps its beams instead of having them fully faded
                //      before its surface even starts. It still weights the
                //      CAUSTIC part only: UW_SHAFT_RENDER_DIST has always meant
                //      "the shafts melt away, fog and darkness continue".
                // (d2) COLOUR: the water light tint whatever the camera side,
                //      rebuilt from lightCraw -- the value BEFORE the eye-dry
                //      underground desaturation (skyExpo), a branch a submerged
                //      eye never runs. In the open air skyExpo is 1.0 and the
                //      two are the same value; under an overhang or in a wreck
                //      it is what stops the beam from turning grey-blue for the
                //      man on the bank while the diver beside him sees colour.
                // (d3) OUT GAIN: the march weights a submerged step with the
                //      step's OWN density. With a dry eye that density is
                //      densNoUW + 0.008/block (the air haze the ray also
                //      crosses is NOT negligible: it is ~40% of the total at
                //      the shipped defaults), against the water's ~0.026/block
                //      for the diver. So the gain that equalises the beam is
                //      the RATIO of the two, not a constant: UW_SHAFT_OUT_GAIN
                //      is expressed in units of 0.008/block (3.0 ~= the water
                //      coefficient) and is divided by what this step actually
                //      weighs. densNoUW excludes the wMirror-weighted share on
                //      purpose, so the two half-res endpoints agree and the
                //      grazing sunset mirror keeps its tuned transmittance.
                // (d4) PEDESTAL: UW_SHAFT_BASE takes over from the generic
                //      in-scatter term uwDirW just removed, INSIDE the same
                //      product -- so the submerged direct light is one additive
                //      term with one geometry, and UW_GODRAY_STRENGTH stays a
                //      shaft dial instead of becoming a light switch. It rides
                //      the true water HG (phaseW), NOT the striation floor
                //      phaseShaft: that floor exists to keep the FILAMENTS
                //      readable facing away from the sun and, used on the
                //      pedestal, it rescaled the diver's background light from
                //      x0.40 (facing the sun) to x4.25 (back to it). At
                //      UW_SHAFT_BASE = 1.0 the removed term is reproduced as
                //      written; below 1.0 the submerged background is
                //      deliberately darkened.
                //      outGU multiplies the WHOLE bracket. Applied to the
                //      caustic half only, it made the filament/background
                //      contrast exactly outGU times higher seen from the bank
                //      than seen from inside -- by construction, at any
                //      setting: geometry unified, modulation not.
                // shaftFade: computed in the common trunk above (UW_SHAFT_BOUND
                // hoist), same submerged-path expression as before -- it also
                // gates the caustic taps now.
                vec3 lightCw = (isEyeInWater == 1 || inGlassUW) ? lightC : lightCraw * uwShaftTint;
                float outGU = (isEyeInWater == 1 || inGlassUW)
                            ? 1.0
                            : UW_SHAFT_OUT_GAIN * 0.008 / max(densNoUW + 0.008, 1e-6);
                // ---- UW_SHAFT_FIX3 (C): the beam claims no unknown light ----
                // (MIRRORED in lib/vl_halfres.glsl, keep in sync)
                // shOK is the shadow probe's own validity (declared at the
                // probe): 0 where the tap fell outside the shadow map or past
                // its frustum Z, i.e. where `vis` was failed OPEN for the fog.
                // That fail-open is right for haze and is a light leak on a
                // beam -- it is the sun asserted at full strength exactly where
                // occlusion is unknown, which is how a wide shaft ends up
                // crossing solid terrain. The BEAM alone is weighted by it;
                // fog, ambient and every air term keep `vis` as it was.
#if UW_SHAFT_FIX3 == 1
                vec3 visBeam = vis * shOK;
#else
                vec3 visBeam = vis;
#endif
#if UW_SHAFT_V4 == 1
                // ---- UW_SHAFT_V4 (C)+(D): the column that gets DARKER, and
                // GREENER, going down. (MIRRORED in lib/vl_halfres.glsl.)
                // (C) The bracket has two halves and only one of them knew
                //     about depth: the filaments carry beerR, the PEDESTAL --
                //     the submerged direct light UW_SHAFT_BASE took over from
                //     the removed generic in-scatter (d4) -- carried nothing at
                //     all. At 30 blocks the filaments are at 16% and the
                //     pedestal still at 100%, so the deep column is ~80% flat
                //     glow with its structure dissolved out: the "even slab of
                //     light" a bank observer sees, since he has the WHOLE
                //     column on screen at once while a diver only ever has
                //     24-48 blocks of it. Putting the pedestal on the
                //     filaments' OWN curve (rather than inventing a second
                //     extinction constant) is what makes the SHAPE of the
                //     bracket stop depending on depth. Measured contrast of
                //     the in-scatter reaching the eye, surface to 30 blocks:
                //     4.55:1 before, 16.45:1 after.
                // (D) beerR is achromatic, so the shipped beam keeps a frozen
                //     chroma at every depth (R/G = 0.800 at the surface AND at
                //     40 blocks). Water is a spectral filter and red goes
                //     first. Applied NORMALISED on the green (R and B only
                //     ever darker, never brighter) so no luminance is invented
                //     and only ~15% is lost at 20 blocks. Gentle on purpose --
                //     the water COLUMN's own spectrum is a separately tuned
                //     system and this must not race it; see UW_SHAFT_SPECTRAL.
                // Eye-dry ONLY, by the branch and not by tuning: a diver keeps
                // the shipped bracket bit-identical.
                vec3 uwBeamK = vec3(1.0);
                float uwPed = UW_SHAFT_BASE;
                if (isEyeInWater == 0 && !inGlassUW) {
                    uwPed *= mix(1.0, beerR, UW_SHAFT_PED_FALL);
                    uwBeamK = vec3(exp(-toSurf * (UW_SHAFT_SPEC_KR * UW_SHAFT_SPECTRAL)),
                                   1.0,
                                   exp(-toSurf * (UW_SHAFT_SPEC_KB * UW_SHAFT_SPECTRAL)));
                }
                S += lightCw * visBeam * lightUp * subW * teinteShaft * outGU * uwBeamK
                   * (phaseW * uwPed
                      + phaseShaft * caDir * beerR * 0.9 * UW_GODRAY_STRENGTH * shaftFade);
#else
                S += lightCw * visBeam * lightUp * subW * teinteShaft * outGU
                   * (phaseW * UW_SHAFT_BASE
                      + phaseShaft * caDir * beerR * 0.9 * UW_GODRAY_STRENGTH * shaftFade);
#endif
#else
                // shaftFade: computed in the common trunk above (UW_SHAFT_BOUND
                // hoist), camera distance in this legacy branch as before.
                // (C) see the UW_SHAFTS_UNIFIED == 1 branch above.
#if UW_SHAFT_FIX3 == 1
                vec3 visBeam = vis * shOK;
#else
                vec3 visBeam = vis;
#endif
                S += lightC * visBeam * phaseShaft * lightUp * caDir * beerR * 0.9 * UW_GODRAY_STRENGTH * subW
                   * teinteShaft * shaftFade;
#endif
            }
            #endif
            float a = exp(-dens * dt);
            scat += transF * S * (1.0 - a);
            transF *= a;
            // Transmittance collapsed -> the rest of the march contributes <0.5%
            // -> stop (dense fog, deep water).
            if (transF < 0.005) break;

            // Thermal halo of incandescent blocks (lava, fire, torches): the
            // surrounding air lights up with a warm orange-red glow
            #ifdef LAVA_ANIMATE
            // reuses the shared projection/tap from the top of the step (puvS/matBS)
            if (isEyeInWater == 0 && onScrS) {
                vec2 lvuv = puvS;
                {
                    float matB = matBS;
                    // Strict LAVA band around 0.58: a wider 0.45..0.65 window also
                    // catches the generic emissive flag 0.5 (a cyan sea lantern
                    // would get a false ORANGE halo)
                    if (matB > 0.55 && matB < 0.62) {
                        float lvd = texture2D(depthtex0, lvuv).r;
                        if (lvd < 1.0) {
                            float emDist = length(p - toView(lvuv, lvd));
                            scat += vec3(0.92, 0.36, 0.08) * exp(-emDist * 0.60)
                                   * 0.009 * LAVA_GLOW * transF;
                        }
                    }
                }
            }
            #endif

            #if defined VL_BLOCKLIGHT && (defined SS_LIGHTS || defined RTGI)
                vec4 fc = gbufferProjection * vec4(p, 1.0);
                vec2 fuv = ((fc.xy / fc.w) * 0.5 + 0.5) * TAAU_S; // TAAU: NDC -> sub-rect UV
                if (fuv.x > 0.0 && fuv.x < TAAU_S && fuv.y > 0.0 && fuv.y < TAAU_S) {
                    float fd = texture2D(depthtex0, fuv).r;
                    if (fd >= 1.0 || p.z > toView(fuv, fd).z) {
#if GI_HALF_RES == 1
                        // Half-res GI: plain bilinear inside the quadrant is
                        // enough for fog accumulation (low frequency, summed
                        // along the march); clamp keeps taps off stale texels.
                        blockFog += texture2D(colortex4,
                            min(fuv * 0.5, 0.5 * TAAU_S - 1.5 / vec2(viewWidth, viewHeight))).rgb;
#else
                        blockFog += texture2D(colortex4, fuv).rgb;
#endif
                    }
                }
            #endif
        }
#ifdef SHAFT_FAR_ACTIVE
        // ---- CLOUD_SHAFTS (ROUND 2) : SEGMENT LOINTAIN ---------------------
        // (MIRRORED in lib/vl_halfres.glsl -- bloc textuellement IDENTIQUE,
        //  indentation comprise ; diff obligatoire. Le CORPS du segment vit
        //  dans vlShaftFar (lib/lighting.glsl) : SOURCE UNIQUE, donc il n'y a
        //  aucune arithmetique a tenir en phase entre les deux chemins.)
        // POURQUOI. La boucle ci-dessus s'arrete a marchEnd = min(distVol, 160)
        // et son milieu est airDens. Sans brouillard analytique (ATMO_FOG,
        // HEIGHT_FOG, DAWN_MIST, AERIAL_PERSPECTIVE eteints) plus rien n'existe
        // au-dela : MESURE, soleil 10 deg, bande d'horizon, en fraction de
        // lightC, l'amplitude des colonnes vaut 0.00453 face au soleil,
        // 0.00026 a 90 deg et 0.00001 DE DOS. Le segment lointain porte son
        // PROPRE milieu d'aerosols (SHAFT_TAU) et une phase melant le HG du
        // tronc et un terme Rayleigh (SHAFT_ISO) : au palier Naturel
        // l'amplitude des colonnes est multipliee par 1.3 face au soleil, 2.1 a
        // 90 deg et 34 DE DOS. Doc, constantes et mesures : bloc "ROUND 2 :
        // SEGMENT LOINTAIN" de lib/settings.glsl.
        // PORTEE. Pixel de ciel : SHAFT_FAR_END (= CTM_RANGE, la portee de la
        // carte, au-dela de laquelle il n'y a plus d'ombre a lire). Pixel
        // terrain ou LOD DH : min(distVol, SHAFT_FAR_END) -- la longueur du
        // segment croit donc CONTINUMENT depuis 0 quand distVol franchit
        // 160 blocs, il n'y a pas de couture au raccord.
        // OEIL SEC uniquement : sous l'eau ou derriere une base vitree le
        // milieu est l'eau, et la marche proche le traite deja.
        vec3 scatFar = vec3(0.0);
        if (isEyeInWater == 0 && !inGlassUW) {
#ifdef DISTANT_HORIZONS
            float farEndS = (d1v >= 1.0 && dhD1v >= 1.0) ? SHAFT_FAR_END
                                                         : min(distVol, SHAFT_FAR_END);
#else
            float farEndS = (d1v >= 1.0) ? SHAFT_FAR_END : min(distVol, SHAFT_FAR_END);
#endif
            scatFar = vlShaftFar(worldDir, lightW, lightC, phase, cosT, lightUp,
                                 marchEnd, farEndS, vlDither);
        }
#endif
#ifdef SHAFT_FAR_ACTIVE
        // Le segment est de l'AIR PUR au-dessus de toute colonne d'eau : il ne
        // depend pas de wMirror. Il est ajoute APRES la boucle, pondere par la
        // transmittance de fin de marche, et n'attenue RIEN (transF intact) :
        // l'extinction serait le brouillard de distance que le pack laisse au
        // choix de l'utilisateur, et sa borne est chiffree au bloc "ROUND 2".
        // Le miroir demi-res ajoute la MEME valeur a ses DEUX points de sortie,
        // chacun avec sa propre transmittance.
        scat += scatFar * transF;
#endif
#endif // VL_HALF_RES (inline march path)

        // Analytic haze for the path beyond the march
        #ifdef HEIGHT_FOG
        if (distVol > marchEnd + 1.0 && isEyeInWater == 0) {
            float rem = distVol - marchEnd;
            float y0 = cameraPosition.y + worldDir.y * marchEnd;
            float fall = 0.025 / HEIGHT_FOG_FALLOFF;
            float dy = worldDir.y;
            float fogAmt;
            if (abs(dy) < 0.01) {
                fogAmt = hfDens * exp(-max(y0 - WATER_LEVEL, 0.0) * fall) * rem;
            } else {
                fogAmt = hfDens / fall * exp(-max(y0 - WATER_LEVEL, 0.0) * fall)
                       * (1.0 - exp(-rem * dy * fall)) / dy;
            }
            // dhFogK (DH_FOG_SCALE) : la traine courait jusqu'a distVol, donc
            // jusqu'aux LODs — a densite pleine elle atteignait ~75 % a 512
            // blocs et saturait son clamp 0.9 : LE mur principal. Le rescale
            // s'applique a la traine SEULE (fogAmt est lineaire en hfDens) :
            // la marche VL 0-160 garde ses vallees pleines, et comme la
            // traine part de 0 a marchEnd quelle que soit sa densite, le
            // raccord a 160 blocs reste continu (seule la pente change).
            fogAmt = 1.0 - exp(-max(fogAmt * dhFogK, 0.0));
            // MIRROR RELIEF: on a water pixel the remaining path is mostly
            // BELOW the surface, yet this tail priced it as sea-level air --
            // a sky-colored wash pasted over the far mirror (open ocean,
            // floor beyond the 160-block march). Same wMirror contract as
            // the march density and the ATMO_FOG/VL-apply reliefs.
            fogAmt *= 1.0 - 0.55 * clamp(wMirror, 0.0, 1.0);
            // CSE: shared memoized getSkyBase(worldDir, sunW) (see top of main)
            if (!skyBaseWDok) { skyBaseWD = getSkyBase(worldDir, sunW); skyBaseWDok = true; }
#ifdef FOG_SHADOWS_ACTIVE
            // FOG_SHADOWS: the tail covers [marchEnd, distVol], i.e. beyond the
            // 160-block march. The shared probe spans the WHOLE ray (unclamped
            // since the tEnd fix), so its far taps land in this segment: past
            // shadowDistance they fail open and the cloud-shadow factor carries
            // the far haze alone, while the near taps still contribute terrain
            // occlusion from the marched part of the same ray. That mixing is
            // the approximation here -- acceptable because the tail is a slowly
            // varying analytic term. Sky part keeps the 75% floor.
            vec3 hcol = skyBaseWD * 0.9 * fogShadAmb
                      + gLightC * 0.20 * pow(clamp(cosT, 0.0, 1.0), 4.0) * fogShadDir;
#else
            vec3 hcol = skyBaseWD * 0.9
                      + gLightC * 0.20 * pow(clamp(cosT, 0.0, 1.0), 4.0);
#endif
            #ifdef FOG_BIOME_TINT
            // Same biome tint on the analytic tail as on the marched haze
            if (luma(fogColor) > 0.001) {
                vec3 fbCh2 = toLinear(fogColor) / max(luma(toLinear(fogColor)), 0.04);
                fbCh2 = min(fbCh2, vec3(2.0));
                hcol *= mix(vec3(1.0), fbCh2, FOG_BIOME_TINT_STRENGTH * 0.7);
            }
            #endif
            // Same eye sky-exposure gate as the marched haze (AFTER the biome
            // tint): the tail is sky/sun colored (pink at dusk) and must go
            // neutral underground.
            hcol = mix(vec3(luma(hcol)) * vec3(0.85, 0.95, 1.10), hcol, skyExpo);
            color = mix(color, hcol, clamp(fogAmt, 0.0, 0.9));
        }
        #endif

        // AIR-VEIL MIRROR RELIEF: the march's SUBMERGED density is already
        // wMirror-weighted, but the AIR height-fog/in-scatter integrated over
        // 60-160 grazing blocks still dimmed the mirror (transF ~0.65 at 60
        // blocks) and replaced it with a flat blue veil -- the dominant "blue
        // water, no mirror" term that no water-volume constant touches.
        // Density rescale at APPLICATION time, identical on BOTH VL paths
        // (half-res upsample and inline march both land here, so the
        // lib/vl_halfres.glsl mirror contract is untouched): transF^k =
        // exp(-k*tau) is exact for a density scale, and scat ~ tau to first
        // order for these thin veils (in-scatter, bank-view shafts included,
        // scales alike). Keeps >= 45% of the veil at full mirror so water
        // never detaches from the horizon haze; opaque/sky/underwater pixels
        // (wMirror = 0) are bit-identical.
        float fogKeepW = 1.0 - 0.55 * clamp(wMirror, 0.0, 1.0);
        // Ternary keeps wMirror=0 pixels bit-identical (pow(x,1.0) is not
        // guaranteed bit-exact on all drivers).
        transF = (wMirror > 0.0) ? pow(transF, fogKeepW) : transF;
        color = color * transF + scat * fogKeepW;

        // VL_HALF_RES == 1: the block-light fog term is already folded into
        // the stored scat endpoints by lib/vl_halfres.glsl -> apply only on
        // the inline (full-res) path.
        #if defined VL_BLOCKLIGHT && (defined SS_LIGHTS || defined RTGI) && VL_HALF_RES == 0
#if PERF_VL_ADAPTIVE == 1
            blockFog /= float(vlN);   // B5: mean over the steps actually paid
#else
            blockFog /= float(VL_SAMPLES);
#endif
            // fogKeepW: path parity -- the half-res path folds this term into
            // the stored scat, which the mirror relief above already scales.
            color += blockFog * (1.0 - exp(-marchEnd * 0.04)) * 0.30 * VL_BLOCK_STRENGTH * fogKeepW;
        #endif
    }
    #endif

#if DIMENSION_FX == 1
    // ---- DIMENSION_FX: distance fog beyond the march + End void mist ----
    // The volumetric march covers at most 160 blocks (nothing at all when
    // VOLUMETRIC_LIGHT is off): the rest of the path gets the same
    // Beer-Lambert density and the same in-scatter limit, so the fog wall and
    // the dimensional sky stay one color. Uniform branch, Overworld untouched.
    {
        float dimNT = dimNether();
        float dimET = dimEnd();
        if ((dimNT > 0.5 || dimET > 0.5) && isEyeInWater == 0) {
            float coveredT = 0.0;
            #ifdef VOLUMETRIC_LIGHT
            coveredT = min(fogDist, 160.0);
            #endif
            float remT = max(fogDist - coveredT, 0.0);
            float densT = (dimNT > 0.5) ? NETHER_FOG_DENSITY / 110.0 : END_HAZE_DENSITY / 450.0;
#ifdef END_STORM_ACTIVE
            // END_STORM: altitude profile at the mid-point of the remaining
            // path (same terms as the marched haze; the dial is applied above).
            if (dimET > 0.5) densT *= endHazeProfile(cameraPosition.y + worldDir.y * (coveredT + remT * 0.5));
#endif
            vec3 fogCT = (dimNT > 0.5) ? dimNetherFog() : dimEndFog();
            color = mix(color, fogCT, 1.0 - exp(-remT * densT));
#ifndef END_STORM_ACTIVE
            // END_STORM_ACTIVE replaces this closed-form mist by the storm
            // sea of lib/end_storm.glsl (deferred sky / march above).
            if (dimET > 0.5) {
                // VOID MIST: density d(y) = kV * (40 - y) / 40 below y = 40 (zero
                // above, still growing under y = 0), integrated in closed form
                // along the ray: the islands stay clear, the drop toward the void
                // fills with black-violet haze.
                // Bounded by fogDist, like the dimensional Beer-Lambert tail
                // just above: on 'dist' the void mist still stopped at a pane
                // while the haze around it ran to the surface behind, and the
                // two layers split visibly along the window frame. fogDist is
                // equal to dist on every non-glass pixel.
                float y0V = cameraPosition.y;
                float dyV = worldDir.y;
                float tA = 0.0;
                float tB = fogDist;
                if (abs(dyV) > 1e-4) {
                    float tcV = (40.0 - y0V) / dyV;      // ray crossing of y = 40
                    if (dyV > 0.0) tB = clamp(tcV, 0.0, fogDist); // rising ray: misty until y = 40
                    else           tA = clamp(tcV, 0.0, fogDist); // falling ray: misty from y = 40 down
                } else if (y0V >= 40.0) {
                    tB = 0.0;
                }
                float tauV = (0.02 / 40.0) * ((40.0 - y0V) * (tB - tA) - dyV * (tB * tB - tA * tA) * 0.5);
                color = mix(color, vec3(0.012, 0.007, 0.024), clamp(1.0 - exp(-max(tauV, 0.0)), 0.0, 0.95));
            }
#endif // !END_STORM_ACTIVE (void mist)
        }
    }
#endif

// colortex5 is only rewritten for debug views 23/24. Outside debug it was an
// EXACT passthrough, so the gbuffer content stays valid and one full-screen
// write per frame is saved.
#if DEBUG_VIEW >= 23
/* DRAWBUFFERS:05 */
    gl_FragData[0] = vec4(color, 1.0);
    gl_FragData[1] = aux5;
#else
/* DRAWBUFFERS:0 */
    gl_FragData[0] = vec4(color, 1.0);
#endif
}
