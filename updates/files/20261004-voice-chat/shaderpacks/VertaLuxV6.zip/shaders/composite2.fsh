#version 120
/* Bloom pass 1: bright-pass extraction + wide horizontal blur. Reads colortex0, writes colortex3. */

#include "/lib/settings.glsl"
#include "/lib/common.glsl"

uniform sampler2D colortex0;
uniform float viewWidth;
uniform float viewHeight;   // TAAU: sub-rect vertical bound

varying vec2 uv;

vec3 brightPass(vec2 coord) {
#if BLOOM_HALF_RES == 1
    // Half-res: 'coord' is a lower-left-quadrant coordinate; the full-res
    // scene sits at coord * 2 (GL edge clamp handles taps past the screen
    // border, exactly like the legacy full-res path). The TAAU clamp below
    // then applies to the SCENE coordinate, which is what it bounds.
    coord *= 2.0;
#endif
#if TAA_UPSCALING == 1
    // TAAU: wide taps (up to +-48 texels) must not sample the dead zone
    // beyond the render sub-rect. Compiled out at TAA_UPSCALING=0.
    coord = min(coord, vec2(TAAU_S) - 1.0 / vec2(viewWidth, viewHeight));
#endif
    vec3 col = texture2D(colortex0, coord).rgb;
#if BLOOM_MIP == 1
    // BLOOM_MIP bright-pass: lower threshold + wide knee + firefly compression
    // HERE, before the mip descent, so high LODs do not carry the sun disk.
    float brM = luma(col);
    float thM = BLOOM_THRESHOLD * 0.6; // raise 0.6 -> 0.8 if sunset haze is too strong
    float kneeM = 1.5;
    float softM = clamp(brM - thM + kneeM, 0.0, 2.0 * kneeM);
    softM = softM * softM / (4.0 * kneeM + 1e-4);
    float contribM = max(brM - thM, softM) / max(brM, 1e-4);
    col *= clamp(contribM, 0.0, 1.0);
    col /= (1.0 + luma(col) * 0.25); // soft compression keeps water/sun glints punchy
    return col;
#elif BLOOM_PHYSICAL == 1
    float br = luma(col);
    float knee = 1.0;
    float soft = clamp(br - BLOOM_THRESHOLD + knee, 0.0, 2.0 * knee);
    soft = soft * soft / (4.0 * knee + 1e-4);
    float contrib = max(br - BLOOM_THRESHOLD, soft) / max(br, 1e-4);
    col *= clamp(contrib, 0.0, 1.0);
    col /= (1.0 + luma(col));
    return col;
#else
    // wide soft knee: gradual threshold, less edge shimmer
    return col * smoothstep(BLOOM_THRESHOLD, BLOOM_THRESHOLD + 3.0, luma(col));
#endif
}

void main() {
    vec3 bloom = vec3(0.0);
    #ifdef BLOOM_ACTIVE
    #if BLOOM_HALF_RES == 1
    // Half-res: shade only the lower-left quadrant (of the TAAU sub-rect when
    // active). Outside it, write black so the BLOOM_MIP pyramid never averages
    // stale texels into its high LODs.
    if (uv.x < 0.5 * TAAU_S && uv.y < 0.5 * TAAU_S)
    #endif
    {
        #if BLOOM_HALF_RES == 1
        // 1.5 quadrant texels: brightPass doubles the coordinate, so the scene
        // taps land on the exact legacy 3-texel full-res offsets -> identical
        // on-screen blur radius (the signal is merely stored on a half grid).
        vec2 px = vec2(1.5 / viewWidth, 0.0);
        #else
        vec2 px = vec2(3.0 / viewWidth, 0.0);
        #endif
        // Normalized gaussian taps (weights sum to 1.0): energy-conserving, no ringing.
        // Must stay identical to the vertical pass in composite3.
        bloom += brightPass(uv) * 0.153;
        bloom += (brightPass(uv + px * 1.0) + brightPass(uv - px * 1.0)) * 0.144;
        bloom += (brightPass(uv + px * 2.0) + brightPass(uv - px * 2.0)) * 0.122;
        bloom += (brightPass(uv + px * 3.0) + brightPass(uv - px * 3.0)) * 0.093;
        bloom += (brightPass(uv + px * 4.0) + brightPass(uv - px * 4.0)) * 0.065;
        bloom += (brightPass(uv + px * 5.5) + brightPass(uv - px * 5.5)) * 0.030;
        bloom += (brightPass(uv + px * 7.5) + brightPass(uv - px * 7.5)) * 0.012;
        // separate low-frequency halo term (wide dreamy glow), low weights to avoid ringing
        bloom += (brightPass(uv + px * 12.0) + brightPass(uv - px * 12.0)) * 0.006;
        bloom += (brightPass(uv + px * 20.0) + brightPass(uv - px * 20.0)) * 0.003;
        #if BLOOM_PHYSICAL == 1
        bloom += (brightPass(uv + px * 32.0) + brightPass(uv - px * 32.0)) * 0.0015;
        bloom += (brightPass(uv + px * 48.0) + brightPass(uv - px * 48.0)) * 0.0008;
        #endif
    }
    #endif

/* DRAWBUFFERS:3 */
    gl_FragData[0] = vec4(bloom, 1.0);
}
