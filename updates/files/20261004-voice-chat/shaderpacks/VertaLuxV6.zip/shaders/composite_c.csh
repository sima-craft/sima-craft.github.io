#version 430 compatibility
/* VertaLux - LPV STAGE 2, FLOOD pass 3/4 (step 2).  PING-PONG: A(lightImg) -> B(lightImgB).
   Gate: EMISSIVE_LPV=0 OR LPV_PASSES<4 -> copy A->B (parity no-op). LPV_PASSES==2 therefore
   disables this pass and the next: shorter range (steps 8+4 only), parity still even.
   CL_V3=1: dead code, compiled out entirely (see composite_a.csh header). */
#include "/lib/settings.glsl"
#include "/lib/common.glsl"

layout(local_size_x = 8, local_size_y = 8, local_size_z = 8) in;
const ivec3 workGroups = ivec3(16, 16, 16);

layout(rgba16f) uniform image3D lightImg;     // A
layout(rgba16f) uniform image3D lightImgB;    // B

#define LPVF_SRC  lightImg                      // reads A
#define LPVF_DST  lightImgB                     // writes B
#define LPVF_STEP 2
#include "/lib/lpv_flood.glsl"

void main() {
#if EMISSIVE_LPV == 0
    return; // LPV chain disabled -> no work at all
#endif
    ivec3 c = ivec3(gl_GlobalInvocationID);
    if (any(greaterThanEqual(c, ivec3(LPVF_RES)))) return;
#if EMISSIVE_LPV == 1 && CL_V3 == 0 && LPV_PASSES >= 4
    lpvFloodCell(c);    // A -> B, step 2
#elif EMISSIVE_LPV == 1 && CL_V3 == 0
    lpvCopyCell(c);     // parity: A -> B without propagating
#endif
}
