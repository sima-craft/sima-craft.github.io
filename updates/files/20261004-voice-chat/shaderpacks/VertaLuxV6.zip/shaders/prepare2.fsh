#version 120
/*
    prepare2 : CUISSON DE LA CARTE DE TRANSMITTANCE DES NUAGES (CLOUD_SHAFTS).

    Un texel = l'OPACITE du proxy 2D des cumulus en un point du PLAN DES
    NUAGES (VC_BASE + VC_THICK*0.33, le barycentre de densite que cloudShadow
    projette deja), calculee par vlCloudOpacityAtPlane() de lib/lighting.glsl
    -- la MEME fonction que cloudShadowCheap : un bord de faisceau tombe donc
    exactement la ou tombe le bord d'ombre au sol, par construction.
    Doc complete du mecanisme, mesures, paliers, cout et rollback : bloc
    "RAYONS DE NUAGES" de lib/settings.glsl.

    POURQUOI UN PASSAGE prepare : il tourne avant les gbuffers, ne depend
    d'AUCUNE profondeur (la carte est en espace MONDE) et surtout ne touche
    PAS colortex15 -- le ping-pong temporel prepare/prepare1 des nuages reste
    intact. Il rend UNIQUEMENT dans colortex12 : un programme ne peut ecrire
    que dans des tampons de MEME taille, et colortex12 a ici une taille FIXE
    (size.buffer.colortex12, shaders.properties), independante de l'ecran.

    GRILLE : ancree MONDE, origine = floor(cpCam / CTM_CELL) * CTM_CELL -
    CTM_RANGE, avec cpCam = point camera projete sur le plan des nuages.
    Cuiseur et lecteurs recalculent cette expression a l'identique a partir des
    seuls uniformes cameraPosition / shadowLightPosition du MEME frame : ils
    tombent sur la meme grille par construction (aucun uniform custom, aucune
    origine stockee).

    TAAU : aucune dependance ecran. Ce passage n'utilise ni le sous-rectangle
    TAAU_S ni viewWidth/viewHeight -- il couvre son propre tampon, point.

    CLOUD_SHAFTS = 0 (ou nuages / ombres de nuages eteints, ou branche
    procedurale) : chaque fragment fait discard, comme prepare.fsh quand son
    propre gate est ferme. Cout residuel : colortex12 reste alloue, rien
    d'autre.
*/

#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/distort.glsl"
#include "/lib/biome.glsl"
#include "/lib/dimension.glsl"
#include "/lib/lighting.glsl"

// === Format de colortex12 -- directive Iris parsee DANS le bloc /* */.
//     NE PAS DECOMMENTER. R8 : un seul canal, l'opacite dans [0,1] ; la
//     quantification 8 bits est incluse dans les mesures du bloc RAYONS DE
//     NUAGES (erreur moyenne 0.0035 a la cellule livree, quantification
//     comprise). Clear=false : la carte est entierement reecrite chaque frame
//     ou le gate est ouvert, et lue le MEME frame (prepare2 -> composite /
//     composite1), donc l'effacer serait du cout pur.
//     NB : le scanner de const d'Iris est ligne a ligne et peut ignorer ce
//     #if ; c'est sans danger -- gate ferme, le tampon reste non reference,
//     meme contrat que les blocs de prepare.fsh et composite.fsh. En revanche
//     un conflit REEL avec FULL_PATH_TRACE (qui veut colortex12 en RGBA16F
//     plein ecran) est refuse par un #error de lib/settings.glsl.
#ifdef CLOUD_SHAFTS_ACTIVE
/*
const int  colortex12Format = R8;
const bool colortex12Clear  = false;
*/
#endif

// RENDERTARGETS volontairement NON GATE : gate ferme, ce passage fait discard
// sur chaque fragment, et un passage dont la liste de cibles disparait
// retomberait sur les defauts d'Iris (plusieurs tampons VIVANTS) -- leur flip
// sans ecriture livrerait du contenu perime au reste de la frame. Meme idiome
// et meme raison que prepare.fsh.
/* RENDERTARGETS: 12 */

varying vec2 uv;

void main() {
#ifdef CLOUD_SHAFTS_ACTIVE
#if DIMENSION_FX == 1
    // Pas de couche de cumulus dans le Nether / l'End : le cuiseur se tait et
    // les lecteurs y rendent 1.0 d'eux-memes (meme test dans ctmShadow, meme
    // neutralite que cloudShadow). Branche uniforme, gratuite en Overworld.
    if (dimNether() > 0.5 || dimEnd() > 0.5) discard;
#endif
    // Robustesse : si size.buffer.colortex12 n'etait pas applique, le tampon
    // serait a la taille de l'ecran et les texels au-dela de la carte
    // n'auraient aucun sens -- on ne les ecrit pas. (Ce n'est PAS une
    // solution de repli : la carte serait alors lue au mauvais facteur ; c'est
    // une garde pour que l'erreur reste visible et locale plutot que
    // d'ecrire du bruit sur tout le tampon.)
    vec2 tix = floor(gl_FragCoord.xy);
    if (tix.x >= float(CTM_RES) || tix.y >= float(CTM_RES)) discard;

    vec3 lightW = normalize(mat3(gbufferModelViewInverse) * shadowLightPosition);
    // MEME geometrie que les lecteurs (lib/lighting.glsl, source unique).
    vec2 shear = vlCtmShear(lightW);
    vec2 cpCam = vlCtmCpCam(shear);
    // cp du centre de ce texel. La forme "cpCam + petit offset" evite de
    // reconstruire l'origine absolue puis de lui soustraire une grande
    // coordonnee : c'est la meme algebre que le lecteur, dans le meme ordre.
    vec2 cp = cpCam + ((tix + 0.5) * CTM_CELL - vlCtmSnap(cpCam) - CTM_RANGE);

    gl_FragData[0] = vec4(vlCloudOpacityAtPlane(cp), 0.0, 0.0, 1.0);
#else
    // Gate ferme : passage mort, rien n'est ecrit.
    discard;
#endif
}
