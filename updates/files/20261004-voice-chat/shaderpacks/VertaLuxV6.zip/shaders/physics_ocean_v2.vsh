#version 120
/* PHYSICS MOD PRO - programme ocean (vertex).
   Mecanisme d'integration OFFICIEL du mod (Physics Mod Pro v1.85g, auteur
   Haubna) : quand le mod est actif avec Iris, il ajoute physics_ocean_v2.vsh /
   .fsh aux sources du pack et les compile comme programme "physics_ocean"
   (ShaderKey TERRAIN_TRANSLUCENT). Son ocean simule - qui REMPLACE la
   geometrie d'eau vanilla des oceans - est dessine avec ce programme, et le
   mod y lie ses UBO / attributs / samplers physics_* par nom
   (lib/physicsmod_ocean.glsl, copie conforme de son interface embarquee).
   SANS le mod, Iris ignore totalement ce fichier ("physics_ocean_v2" n'est
   pas un nom de programme Iris) : le pack reste 100 % autonome.
   Meme corps que gbuffers_water.vsh ; le marqueur ci-dessous + le gate
   PHYSICS_MOD_SUPPORT (lib/settings.glsl) activent les blocs PHYSICS_OCEAN :
   deplacement vertex = vagues du mod, normale gbuffer = normale du mod. */

#define VLX_PHYSICS_OCEAN_PROGRAM

#include "/lib/program_water_vertex.glsl"
