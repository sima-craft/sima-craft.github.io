#version 120
/* Bloom pass 2: wide vertical blur. Reads and writes colortex3. */

#include "/lib/settings.glsl"
#include "/lib/common.glsl"

uniform sampler2D colortex3;
uniform float viewHeight;
uniform float viewWidth;   // TAAU: sub-rect horizontal bound

varying vec2 uv;

// TAAU: clamp taps to the render sub-rect (beyond it = garbage).
// Compiled out at TAA_UPSCALING=0.
vec3 bloomTap(vec2 c) {
#if BLOOM_HALF_RES == 1
    // Half-res: taps must stay inside the lower-left quadrant (of the TAAU
    // sub-rect) -- beyond it colortex3 is black and sampling it would darken
    // the top screen edge. Subsumes the TAA_UPSCALING clamp below.
    c = min(c, vec2(0.5 * TAAU_S) - 1.0 / vec2(viewWidth, viewHeight));
#elif TAA_UPSCALING == 1
    c = min(c, vec2(TAAU_S) - 1.0 / vec2(viewWidth, viewHeight));
#endif
    return texture2D(colortex3, c).rgb;
}

void main() {
    vec3 bloom = vec3(0.0);
    #ifdef BLOOM_ACTIVE
    #if BLOOM_HALF_RES == 1
    // Half-res: shade only the lower-left quadrant, black outside (see composite2).
    if (uv.x < 0.5 * TAAU_S && uv.y < 0.5 * TAAU_S)
    #endif
    {
        #if BLOOM_HALF_RES == 1
        // 1.5 quadrant texels = the legacy 3-texel on-screen offsets. Unlike
        // composite2 (which re-samples the full-res scene), these are bilinear
        // taps between half-res texels: a touch of extra smoothing, invisible
        // on an already-gaussian bloom.
        vec2 px = vec2(0.0, 1.5 / viewHeight);
        #else
        vec2 px = vec2(0.0, 3.0 / viewHeight);
        #endif
        // Vertical weights MUST match the horizontal pass (composite2) for a clean separable blur.
        bloom += bloomTap(uv) * 0.153;
        bloom += (bloomTap(uv + px * 1.0) + bloomTap(uv - px * 1.0)) * 0.144;
        bloom += (bloomTap(uv + px * 2.0) + bloomTap(uv - px * 2.0)) * 0.122;
        bloom += (bloomTap(uv + px * 3.0) + bloomTap(uv - px * 3.0)) * 0.093;
        bloom += (bloomTap(uv + px * 4.0) + bloomTap(uv - px * 4.0)) * 0.065;
        bloom += (bloomTap(uv + px * 5.5) + bloomTap(uv - px * 5.5)) * 0.030;
        bloom += (bloomTap(uv + px * 7.5) + bloomTap(uv - px * 7.5)) * 0.012;
        bloom += (bloomTap(uv + px * 12.0) + bloomTap(uv - px * 12.0)) * 0.006;
        bloom += (bloomTap(uv + px * 20.0) + bloomTap(uv - px * 20.0)) * 0.003;
        #if BLOOM_PHYSICAL == 1
        bloom += (bloomTap(uv + px * 32.0) + bloomTap(uv - px * 32.0)) * 0.0015;
        bloom += (bloomTap(uv + px * 48.0) + bloomTap(uv - px * 48.0)) * 0.0008;
        #endif
    }
    #endif

/* DRAWBUFFERS:3 */
    gl_FragData[0] = vec4(bloom, 1.0);
}
