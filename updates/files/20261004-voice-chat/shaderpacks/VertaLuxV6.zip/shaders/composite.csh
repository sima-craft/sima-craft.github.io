#version 430 compatibility
/* VertaLux - COLORED LIGHTS compute pass.
   CL_V3 = 1 (lib/settings.glsl, default): THE single pass of the rebuilt chain -
   PERSISTENT TEMPORAL DIFFUSION, one relaxation step per frame, frame-parity
   ping-pong between lightImg (A) and lightImgB (B):
     - frameCounter EVEN: reads B (last frame's field), writes A; ODD: the reverse.
       Each invocation writes its own cell of the destination volume and only ever
       READS the source volume -> race-free by construction, no stride ladder, no
       hysteresis, no history copy (composite_a..e are compiled out under CL_V3).
     - Cell classification comes from cl3VoxImg (r32ui id grid written by shadow.vsh,
       vertex stage, per BLOCK - see that file's fail-closed header):
         SOURCE (emissive family id, toggles applied here in cl3Emissive):
                reseeded every frame = palette color SQUARED (lib/cl_colors.glsl;
                readers take the square root AFTER their trilinear -> soft fronts);
         SOLID (id 1, or a toggled-off metal family): forced to (0,0,0, a=1);
         AIR   (id 0): new value = sum of the 6 FACE neighbours of the previous
                field / CL3_DIV (6.42). Additive diffusion: two different-coloured
                sources genuinely MIX by construction. Spectral radius 6/6.42 =
                0.9346 < 1 -> the field is bounded by the seed and converges in
                ~30 frames (~0.5 s, WANTED anti-pop) - proven in scratchpad
                cl3v3_sim.py (a: spherical convergence, b: continuous soul+torch
                gradient, c: zero trailing on camera motion, d: sealed 4-torch room
                bounded, e: player never occludes, f: corner sample stable).
     - Camera scroll: an air cell reads its neighbours SHIFTED by the whole-block
       camera delta (previousCameraPosition), so the field stays glued to the world.
       Teleport guard: a jump >= CL3_TELEPORT blocks drops the history for that frame.
     - Alpha encoding kept from the legacy chain (0 air / 1 solid / 2 source) so the
       DEBUG_VIEW 29 autopsy (final.fsh) keeps reading walls and sources correctly.
   CL_V3 = 0: the legacy STAGE-1 injection below runs unchanged (followed by the
   composite_a..e flood chain) - bit-identical escape hatch.
   Auto-detected by Iris from the filename (composite slot): runs after the shadow pass
   (which voxelizes) and before every composite fragment pass (which reads). Readers
   deliberately sample the OTHER volume (last completed frame): forward gbuffers run
   BEFORE this pass, so both sides of the pipeline see the SAME finished field. */
#include "/lib/settings.glsl"
#include "/lib/common.glsl"

layout(local_size_x = 8, local_size_y = 8, local_size_z = 8) in;
const ivec3 workGroups = ivec3(16, 16, 16);   // 16*8 = 128 per axis

#if EMISSIVE_LPV == 1 && CL_V3 == 1
// ===================== CL_V3: one-pass persistent temporal diffusion =====================
uniform int frameCounter;
uniform vec3 cameraPosition;
uniform vec3 previousCameraPosition;
layout(r32ui) uniform uimage3D cl3VoxImg;     // per-block id grid (shadow.vsh, clear=0)
layout(rgba16f) uniform image3D lightImg;     // A (written on even frames, read on odd)
layout(rgba16f) uniform image3D lightImgB;    // B (written on odd frames, read on even)
// Fixed per-family light colors (single palette table, shared with shadow.fsh legacy
// path and gbuffers_terrain.fsh).
#include "/lib/cl_colors.glsl"

// Per-family glow toggles applied ONCE, here (shadow.vsh writes raw candidate ids):
// a disabled family falls through to the SOLID branch of main() - the block still
// occludes, it just does not emit. 17..24 and 26 are always-on families.
bool cl3Emissive(uint id) {
    if (id >= 17u && id <= 24u) return true;   // fixed palette families
    if (id == 26u) return true;                // redstone torch (lit-only via block.properties)
#ifdef REDSTONE_BLOCK_GLOW
    if (id == 27u) return true;
#endif
#ifdef EMERALD_BLOCK_GLOW
    if (id == 28u) return true;
#endif
#ifdef DIAMOND_BLOCK_GLOW
    if (id == 29u) return true;
#endif
#ifdef GOLD_BLOCK_GLOW
    if (id == 31u) return true;
#endif
#ifdef IRON_BLOCK_GLOW
    if (id == 32u) return true;
#endif
#ifdef NETHERITE_BLOCK_GLOW
    if (id == 33u) return true;
#endif
#ifdef AMETHYST_BLOCK_GLOW
    if (id == 34u) return true;
#endif
#ifdef COPPER_BLOCK_GLOW
    if (id == 35u) return true;
#endif
#ifdef RAW_IRON_BLOCK_GLOW
    if (id == 36u) return true;
#endif
#ifdef RAW_GOLD_BLOCK_GLOW
    if (id == 37u) return true;
#endif
#ifdef RAW_COPPER_BLOCK_GLOW
    if (id == 38u) return true;
#endif
    return false;
}

// One history tap from LAST frame's volume (B on even frames, A on odd). Out of
// bounds = 0 (natural edge fade). NaN/Inf scrub BEFORE the clamp (min/max against a
// NaN returns the OTHER operand: clamping first would launder garbage into CL3_CAP).
// Solid history cells hold exactly 0, so no flag test is needed here.
vec3 cl3Tap(ivec3 n, bool prevIsB) {
    if (any(lessThan(n, ivec3(0))) || any(greaterThanEqual(n, ivec3(CL3_RES)))) return vec3(0.0);
    vec3 h = prevIsB ? imageLoad(lightImgB, n).rgb : imageLoad(lightImg, n).rgb;
    if (any(isnan(h)) || any(isinf(h))) return vec3(0.0);
    return clamp(h, vec3(0.0), vec3(CL3_CAP));
}

void main() {
    ivec3 c = ivec3(gl_GlobalInvocationID);
    if (any(greaterThanEqual(c, ivec3(CL3_RES)))) return;
    uint id = imageLoad(cl3VoxImg, c).r;
    bool writeA = ((frameCounter & 1) == 0);   // prev volume = the other one (prevIsB = writeA)
    vec4 o;
    if (id >= 2u && cl3Emissive(id)) {
        // SOURCE: reseeded from the palette every frame, SQUARED (sqrt at read).
        // A source culled out of the shadow pass simply voxelizes as air next frame
        // and its lobe decays at 0.9346/frame - a smooth fade, never a strobe.
        vec3 col = clLightColor(float(id));
        o = vec4(col * col, 2.0);
    } else if (id != 0u) {
        // SOLID (including toggled-off glow families): zero radiance, blocks diffusion.
        o = vec4(0.0, 0.0, 0.0, 1.0);
    } else {
        // AIR: one damped Jacobi step over last frame's field, scrolled by the
        // whole-block camera delta so cell c reads the SAME WORLD position's history.
        vec3 acc = vec3(0.0);
        ivec3 camOff = ivec3(floor(cameraPosition)) - ivec3(floor(previousCameraPosition));
        if (all(lessThan(abs(camOff), ivec3(CL3_TELEPORT)))) {
            ivec3 pc = c + camOff;
            acc = cl3Tap(pc + ivec3( 1, 0, 0), writeA)
                + cl3Tap(pc + ivec3(-1, 0, 0), writeA)
                + cl3Tap(pc + ivec3( 0, 1, 0), writeA)
                + cl3Tap(pc + ivec3( 0,-1, 0), writeA)
                + cl3Tap(pc + ivec3( 0, 0, 1), writeA)
                + cl3Tap(pc + ivec3( 0, 0,-1), writeA);
        }
        o = vec4(acc * (1.0 / CL3_DIV), 0.0);
    }
    if (writeA) imageStore(lightImg, c, o);
    else        imageStore(lightImgB, c, o);
}

#else
// ===================== LEGACY (CL_V3 = 0): STAGE-1 injection =====================
/* LPV STAGE 1: INJECTION ONLY (no propagation).
   For EACH LPV cell (128^3) it samples the cascade-0 voxels covering it (1 LPV cell = 2 voxels per
   axis since LPV_SCALE = 2*VOXEL_SCALE) and writes lightImg:
     - SOURCE (radiance, a=2) if an emissive voxel (voxel.a>1.5) falls inside (brightest wins);
     - SOLID (a=1) otherwise if a solid voxel (voxel.a>0.5) falls inside (blocks the Stage 2 flood);
     - EMPTY (0) otherwise.
   CL_V2=1 (MISSION CL2) changes two things ONLY: sources seed their palette radiance
   SQUARED (x CLV2_SEED_BOOST, sqrt at read) and EMPTY cells INHERIT last frame's field
   (read from lightImgB, scrolled by the camera-block delta) instead of being zeroed -
   the flood becomes temporally convergent (soft chromatic fade on place/break).
   MISSION CL3 adds two temporal guards to that inheritance (see lib/settings.glsl,
   CLV2_INHERIT_CAP / CLV2_SRC_HOLD): air inherits capped at 2x the max legitimate
   seed (kills enable/alt-tab garbage in ~6 frames), and an ex-SOURCE cell that is NOT
   verifiably observed this frame (outside the view frustum or past 0.9*shadowDistance
   under shadow.culling=true) keeps a pinned seed decaying x0.90/frame, for at most
   CLV2_HOLD_FRAMES frames and only within the legitimate-seed envelope - torches
   behind the camera stop strobing in and out of the culled shadow pass, while
   uninitialized history (lightImgB is never cleared) cannot ride the hold.
   Runs after shadow (which voxelizes) and before composite1..composite5 (which read).
   Gated on EMISSIVE_LPV: at 0 the kernel returns immediately, so the fallback costs nothing. */

uniform vec3 cameraPosition;
layout(rgba16f) uniform image3D voxelImg;     // cascade-0 voxel grid (read)
layout(rgba16f) uniform image3D lightImg;     // LPV field (written)
#if CL_V2 == 1
// CL_V2 temporal inheritance reads LAST frame's field from B. composite_e copies the
// FINAL post-stride-1 field A->B at the end of every frame, so B carries EVERY parity
// class. (Before that copy existed, B held composite_c's post-stride-2 state: by
// recurrence its support was the even sublattice {seed + (2a,2b,2c)}, so any cell at an
// all-odd offset from a source stayed at exactly 0.0 forever - block-scale orange/cyan
// checkerboard around wall lights, and light never crossing a 1-cell doorway.)
// Race-free: nothing writes B while this kernel runs, whereas reading A shifted would
// race with our own imageStore. previousCameraPosition scrolls the volume.
// Both declarations are used ONLY inside the CL_V2 block below.
layout(rgba16f) uniform image3D lightImgB;
uniform vec3 previousCameraPosition;
// CL3 frustum-hold hysteresis: the "observed" test projects the cell through the
// CURRENT view frustum (a cell inside it is guaranteed rasterized by the shadow
// pass under shadow.culling=true; a cell outside may have been culled, so a
// missing source there means "not seen", not "broken"). Used ONLY below.
uniform mat4 gbufferModelView;
uniform mat4 gbufferProjection;
#endif

#include "/lib/lpv.glsl"

void main() {
#if EMISSIVE_LPV == 0
    return; // LPV chain disabled -> no work at all (128^3 dispatch would just write zeros)
#endif
    ivec3 c = ivec3(gl_GlobalInvocationID);
    if (any(greaterThanEqual(c, ivec3(LPV_RES)))) return;
#if EMISSIVE_LPV == 1
    vec3 wc = lpvCellToWorld(c);
    vec3 bestE = vec3(0.0);
    bool isSrc = false;
    bool solid = false;
    // 8 sub-points (LPV cell corners) at +-0.5*VOXEL_SCALE: covers the 2x2x2 voxels underneath.
    for (int k = 0; k < 8; k++) {
        vec3 off = (vec3(k & 1, (k >> 1) & 1, (k >> 2) & 1) - 0.5) * VOXEL_SCALE;
        vec4 v = sampleVoxC0(wc + off);
        if (v.a > 1.5) { isSrc = true; if (luma(v.rgb) > luma(bestE)) bestE = v.rgb; }
        else if (v.a > 0.5) solid = true;
    }
    vec4 o;
#if CL_V2 == 1
    // ===== CL_V2: squared-space seeds + TEMPORAL field (air cells inherit) =====
    if (isSrc) {
        // Seed = palette radiance SQUARED x CLV2_SEED_BOOST (sqrt taken at read: the
        // dominant hue travels farther, fronts decode soft). Hue-preserving cap.
        vec3 sq = bestE * bestE * CLV2_SEED_BOOST;
        float mx = max(sq.r, max(sq.g, sq.b));
        if (mx > CLV2_CLAMP) sq *= CLV2_CLAMP / mx;
        o = vec4(sq, 2.0);                            // SOURCE (reseeded every frame)
    } else if (solid) {
        o = vec4(0.0, 0.0, 0.0, 1.0);                 // SOLID (occludes the Stage 2 flood)
    } else {
        // AIR: inherit last frame's field at the SAME WORLD CELL (volume scrolls with the
        // camera-block snap: old index = c + (camBlockNow - camBlockPrev)). This is what
        // turns pose/casse into a soft chromatic fade (~5-10 frames) instead of a 1-frame
        // snap, and what fills the off-axis path combinations the 4 strides cannot cover
        // in a single frame. A removed source keeps decaying here (the seed is gone, the
        // residue contracts ~x0.44/frame and the luminance-normalized application makes
        // it invisible wherever the lightmap already dropped).
        vec3 h = vec3(0.0);
        float hFlag = 0.0;
#if LPV_PASSES >= 2
        // Gated on LPV_PASSES >= 2: at 0 every flood pass is a plain copy, so inheriting
        // here would make the frame-to-frame operator the IDENTITY - a broken source's
        // seed would persist forever (permanent ghost light glued to the old block
        // position, scrolling with the camera). With no flood to contract the residue,
        // fall back to the v1 zeroed-air behaviour.
        float sLP = LPV_SCALE;
        ivec3 camOff = ivec3(floor(cameraPosition / sLP)) - ivec3(floor(previousCameraPosition / sLP));
        // Teleport guard: a huge jump means no usable history (also keeps camOff sane).
        if (all(lessThan(abs(camOff), ivec3(24)))) {
            ivec3 pc = c + camOff;
            if (all(greaterThanEqual(pc, ivec3(0))) && all(lessThan(pc, ivec3(LPV_RES)))) {
                vec4 H = imageLoad(lightImgB, pc);
                if (!(H.a > 0.5 && H.a < 1.5)) {
                    // Persistent images are never cleared: scrub NaN/Inf garbage (first
                    // frames, alt-tab) BEFORE the clamp - min/max against a NaN returns
                    // the OTHER operand on most GPUs, so clamping first would launder a
                    // NaN into 0.0 or the cap (a full-strength parasite seed in an
                    // air cell) and hide it from isnan.
                    vec3 hr = H.rgb;
                    if (any(isnan(hr)) || any(isinf(hr))) hr = vec3(0.0);
                    // CL3: cap at CLV2_INHERIT_CAP (2x the max legitimate seed), NOT at
                    // CLV2_CLAMP - allocation garbage then dies in ~6 frames at a
                    // legitimate-glow amplitude instead of ~11 frames of 1024-strength
                    // rainbow on enable/alt-tab (simulated, lib/settings.glsl comment).
                    // Hue-preserving (rescale, like the seed cap above), NOT a per-channel
                    // min(): TORCH_R up to 1.4 puts a legit warm seed at 98% of the cap,
                    // so a per-channel clamp would desaturate the whole warm family the
                    // day a hotter palette entry ships (r clipped, g/b untouched).
                    hr = max(hr, vec3(0.0));
                    float mh = max(hr.r, max(hr.g, hr.b));
                    if (mh > CLV2_INHERIT_CAP) hr *= CLV2_INHERIT_CAP / mh;
                    h = hr;
                    // CL3 FRUSTUM-HOLD HYSTERESIS (shadow.culling=true): the history says
                    // SOURCE but this frame's voxels do not. Two very different causes:
                    // either the block was BROKEN, or it was CULLED out of the shadow pass
                    // (behind the camera / past the screen edge) and simply was not seen.
                    // A cell inside the CURRENT view frustum is guaranteed rasterized, so
                    // absence there is a real break -> plain air inheritance, the flood
                    // dissolves it in ~2 frames (simulated). A cell we cannot vouch for
                    // (outside the frustum shrunk to 92%, or beyond 0.9*shadowDistance
                    // when the volume reaches that far) keeps a PINNED seed decaying
                    // x CLV2_SRC_HOLD/frame for at most CLV2_HOLD_FRAMES frames: the
                    // 3on/3off culling blink that pumped the tint by 90.6% at 2 blocks
                    // now ripples 13.4% (simulated). The hold is NOT invisible by
                    // construction: the 92-100% band is ON screen (~9% of visible cells
                    // at FOV 90) and a held cell shines into the frustum interior, so
                    // the frame bound is what keeps a torch broken in that band from
                    // ghosting (>= 3 frames covers the blink, the bound caps the rest).
                    // The 92% shrink keeps boundary cells (chunk-granular culling) on
                    // the safe "held" side, so the classification cannot flip-flop.
                    // The alpha encodes the held AGE (2 = fresh source, +1 per held
                    // frame): downstream only ever tests a>1.5 (source) or 0.5<a<1.5
                    // (solid), and both the flood (pinned cells store self verbatim,
                    // lib/lpv_flood.glsl) and the composite_e A->B copy preserve alpha,
                    // so the age survives the frame intact.
                    if (H.a > 1.5 && H.a < 2.0 + float(CLV2_HOLD_FRAMES)) {
                        vec4 clipH = gbufferProjection * (gbufferModelView * vec4(wc, 1.0));
                        // Distance clause gated on relevance: at the default 64-block
                        // half-reach the farthest cell (sqrt(3)*64 = 110.9) sits inside
                        // the smallest shipped threshold (0.9*128 = 115.2), so the clause
                        // could never fire; it only matters at VOXEL_SCALE 1.0 where the
                        // volume outreaches the rasterized shadow span.
                        float distCap = shadowDistance * 0.9;
                        bool distBites = float(LPV_HALF) * LPV_SCALE > distCap;
                        bool seen = clipH.w > 0.0
                                 && all(lessThan(abs(clipH.xy), vec2(clipH.w * 0.92)))
                                 && clipH.z < clipH.w
                                 && (!distBites || dot(wc, wc) < distCap * distCap);
                        if (!seen) {
                            // Legitimacy envelope: lightImgB is never cleared, so on the
                            // first frame after allocation/F3+R a garbage alpha in
                            // (1.5,inf) would pin garbage rgb as a "held source" - and
                            // pinned cells escape the flood's ~x0.44 contraction. A real
                            // seed is bounded by (palette max channel * EVS)^2 * boost
                            // with palette max = 1.0*max TORCH dial (lib/cl_colors.glsl);
                            // uniform garbage rides at the inherit cap, above the
                            // envelope -> hold refused, plain air inheritance, dead in
                            // ~6 frames like any other allocation garbage.
                            float maxTorch = max(TORCH_R, max(TORCH_G, TORCH_B));
                            float maxSeed  = min(CLV2_CLAMP, maxTorch * maxTorch
                                * EMISSIVE_VOXEL_STRENGTH * EMISSIVE_VOXEL_STRENGTH * CLV2_SEED_BOOST);
                            vec3 held = h * CLV2_SRC_HOLD;
                            // Demotion floor: a dead ember returns to plain air (never an
                            // eternally pinned epsilon cell blocking real inheritance).
                            if (luma(held) > 1e-4 && max(h.r, max(h.g, h.b)) <= maxSeed * 1.01) {
                                h = held;
                                hFlag = min(H.a + 1.0, 2.0 + float(CLV2_HOLD_FRAMES));
                            }
                        }
                    }
                }
            }
        }
#endif
        o = vec4(h, hFlag);                           // EMPTY air, or held decaying seed (flag 2)
    }
#else
    if (isSrc)      o = vec4(bestE, 2.0);            // SOURCE
    else if (solid) o = vec4(0.0, 0.0, 0.0, 1.0);    // SOLID (occludes the Stage 2 flood)
    else            o = vec4(0.0);                    // EMPTY
#endif
    imageStore(lightImg, c, o);
#endif
    // EMISSIVE_LPV=0 is handled by the early return above; no #else branch here.
}
#endif
