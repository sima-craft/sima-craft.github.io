#version 430 compatibility
#define VERTEX
#include "/lib/uniforms.glsl"
#include "/program/composite/c3_dof.glsl"
